package mx.santander.h2h.monitoreo.repository;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import lombok.extern.slf4j.Slf4j;
import mx.isban.h2h.comprobantefiscal.BeanDatosOperMasiva;
import mx.isban.h2h.comprobantefiscal.BeanRespuestaConcepto;
import mx.isban.h2h.comprobantefiscal.BeanRespuestaGeneracion;
import mx.isban.h2h.comprobantefiscal.BeanRespuestaValidacion;
import mx.isban.h2h.comprobantefiscal.ComprobanteSelloDigitalWSServiceFII;
import mx.isban.h2h.comprobantefiscal.ConsultaInfoConcepto;
import mx.isban.h2h.comprobantefiscal.ConsultaInfoConceptoResponse;
import mx.isban.h2h.comprobantefiscal.GeneraComprobante;
import mx.isban.h2h.comprobantefiscal.GeneraComprobanteResponse;
import mx.isban.h2h.comprobantefiscal.RegistraMovimiento;
import mx.isban.h2h.comprobantefiscal.RegistraMovimientoResponse;
import mx.isban.h2h.comprobantefiscal.Respuesta;
import mx.isban.h2h.comprobantefiscal.ValidaComprobante;
import mx.isban.h2h.comprobantefiscal.ValidaComprobanteResponse;
import mx.santander.h2h.monitoreo.constants.ApiConstants;
import mx.santander.h2h.monitoreo.constants.ErrorConstant;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.service.ComprobanteSelloDigitalWSServiceFIIService;

/**
 * ComprobanteSelloDigitalRepository clase principal para la definicion de la
 * logica de las operaciones del servicio web ComprobanteSelloDigital
 * 
 * @author Omar Rosas
 * @since 18/10/2023
 *
 */
@Repository
@Slf4j
public class ComprobanteSelloDigitalRepository implements IComprobanteSelloDigitalRepository {

	@Autowired
	private ComprobanteSelloDigitalWSServiceFIIService wsservice;

	@Override
	public ConsultaInfoConceptoResponse consultaInfoConcepto(ConsultaInfoConcepto request, String url) {
		log.info("Inicia operacion: Consulta info concepto");
		StringBuilder sb = new StringBuilder();
		sb.append(ApiConstants.LINEA_CAPUTRA).append(Encode.forJava(request.getLinCap())).append(ApiConstants.COMMA);
		sb.append(ApiConstants.NUMERO_CUENTA).append(Encode.forJava(request.getNumCta())).append(ApiConstants.COMMA);
		sb.append(ApiConstants.CANAL).append(Encode.forJava(request.getIdCanal() + ""));
		log.info(ErrorConstant.REQUEST + sb);
		ConsultaInfoConceptoResponse response = new ConsultaInfoConceptoResponse();
		try {
			ComprobanteSelloDigitalWSServiceFII service = wsservice.getWSComprobanteSelloDigitalWSServiceFII(url);
			BeanRespuestaConcepto respuesta = service.getComprobanteSelloDigitalWSFIIImplPort()
					.consultaInfoConcepto(request.getLinCap(), request.getIdCanal(), request.getNumCta());
			response.setReturn(respuesta);
			log.info(ErrorConstant.RESPONSE + response.getReturn().getCodError() + " "
					+ response.getReturn().getMsgError());
			log.info("Fin operacion: Consulta info concepto");
		} catch (MalformedURLException e) {
			log.error("Error general al invocar el servicio de Consulta info concepto: ", e);
			throw new BusinessException(e.getMessage());
		}
		return response;
	}

	@Override
	public RegistraMovimientoResponse registraMovimiento(RegistraMovimiento request, String url) {
		log.info("Inicia operacion: Registro de movimientos");
		log.info(ErrorConstant.REQUEST + getRequestMovimientosToString(request.getMovimientos()));
		RegistraMovimientoResponse response = new RegistraMovimientoResponse();
		try {
			ComprobanteSelloDigitalWSServiceFII service = wsservice.getWSComprobanteSelloDigitalWSServiceFII(url);
			Respuesta respuestaMovimientos = service.getComprobanteSelloDigitalWSFIIImplPort()
					.registraMovimiento(request.getMovimientos());
			response.setReturn(respuestaMovimientos);
			log.info(ErrorConstant.RESPONSE + response.getReturn().getCodError() + " "
					+ response.getReturn().getMsgError());
			log.info("Fin operacion: Registro de movimientos");
			return response;
		} catch (MalformedURLException e) {
			log.error("Error general al invocar el servicio de Registro de movimientos: ", e);
			throw new BusinessException(e.getMessage());
		}
	}

	@Override
	public ValidaComprobanteResponse validaComprobante(ValidaComprobante request, String url) {
		log.info("Inicia operacion: Validacion de comprobante");
		StringBuilder sb = new StringBuilder();
		sb.append(ApiConstants.FECHA).append(Encode.forJava(request.getFec())).append(ApiConstants.COMMA);
		sb.append(ApiConstants.LINEA_CAPUTRA).append(Encode.forJava(request.getLinCap())).append(ApiConstants.COMMA);
		sb.append(ApiConstants.NUMERO_CUENTA).append(Encode.forJava(request.getNumCuenta())).append(ApiConstants.COMMA);
		sb.append(ApiConstants.REFERENCIA).append(Encode.forJava(request.getRef())).append(ApiConstants.COMMA);
		sb.append(ApiConstants.CANAL).append(Encode.forJava(request.getIdCanal() + "")).append(ApiConstants.COMMA);
		sb.append(ApiConstants.IMPORTE).append(Encode.forJava(request.getImp() + ""));

		log.info(ErrorConstant.REQUEST + sb.toString());
		ValidaComprobanteResponse response = new ValidaComprobanteResponse();
		try {
			ComprobanteSelloDigitalWSServiceFII service = wsservice.getWSComprobanteSelloDigitalWSServiceFII(url);
			BeanRespuestaValidacion respuesta = service.getComprobanteSelloDigitalWSFIIImplPort().validaComprobante(
					request.getLinCap(), request.getImp(), request.getRef(), request.getFec(), request.getIdCanal(),
					request.getNumCuenta());
			response.setReturn(respuesta);
			log.info(ErrorConstant.RESPONSE + response.getReturn().getCodError() + " "
					+ response.getReturn().getMsgError());
			log.info("Fin operacion: Validacion de comprobante");
			return response;
		} catch (MalformedURLException e) {
			log.error("Error general al invocar el servicio de Validacion de comprobante: ", e);
			throw new BusinessException(e.getMessage());
		}
	}

	@Override
	public GeneraComprobanteResponse generaComprobante(GeneraComprobante request, String url) {
		log.info("Inicia operacion: Generacion de comprobante");
		StringBuilder sb = new StringBuilder();
		sb.append(ApiConstants.FECHA).append(Encode.forJava(request.getFec())).append(ApiConstants.COMMA);
		sb.append(ApiConstants.LINEA_CAPUTRA).append(Encode.forJava(request.getLinCap())).append(ApiConstants.COMMA);
		sb.append(ApiConstants.NUMERO_CUENTA).append(Encode.forJava(request.getNumCta())).append(ApiConstants.COMMA);
		sb.append(ApiConstants.REFERENCIA).append(Encode.forJava(request.getRef())).append(ApiConstants.COMMA);
		sb.append(ApiConstants.CANAL).append(Encode.forJava(request.getIdCanal() + "")).append(ApiConstants.COMMA);
		sb.append(ApiConstants.IMPORTE).append(Encode.forJava(request.getImp() + ""));
		sb.append("Campos adicionales: ").append(Encode.forJava(request.getCamposAdicionales()))
				.append(ApiConstants.COMMA);
		GeneraComprobanteResponse response = new GeneraComprobanteResponse();
		try {
			ComprobanteSelloDigitalWSServiceFII service = wsservice.getWSComprobanteSelloDigitalWSServiceFII(url);
			BeanRespuestaGeneracion respuesta = service.getComprobanteSelloDigitalWSFIIImplPort().generaComprobante(
					request.getLinCap(), request.getImp(), request.getRef(), request.getFec(), request.getIdCanal(),
					request.getNumCta(), request.getNombre(), request.getDomicilio(), request.getColonia(),
					request.getCp(), request.getDelegacion(), request.getEstado(), request.getCamposAdicionales());
			response.setReturn(respuesta);
			log.info(ErrorConstant.RESPONSE + response.getReturn().getCodError() + " "
					+ response.getReturn().getMsgError());
			log.info("Fin operacion: Generacion de comprobante");
			return response;
		} catch (MalformedURLException e) {
			log.error("Error general al invocar el servicio de Generacion de comprobante: ", e);
			throw new BusinessException(e.getMessage());
		}
	}

	/**
	 * Metodo que devuelve el request de la peticion en formato de cadena
	 * 
	 * @param movimientos Lista de datos de entrada
	 * @return Request con formato
	 */
	private String getRequestMovimientosToString(List<BeanDatosOperMasiva> movimientos) {
		StringBuilder request = new StringBuilder();
		movimientos.forEach(mov -> {
			StringBuilder sb = new StringBuilder();
			sb.append("[").append(ApiConstants.FECHA).append(Encode.forJava(mov.getFecha())).append(ApiConstants.COMMA);
			sb.append(ApiConstants.LINEA_CAPUTRA).append(Encode.forJava(mov.getLineaCaptura()))
					.append(ApiConstants.COMMA);
			sb.append(ApiConstants.NUMERO_CUENTA).append(Encode.forJava(mov.getNumCuenta())).append(ApiConstants.COMMA);
			sb.append(ApiConstants.REFERENCIA).append(Encode.forJava(mov.getReferencia())).append(ApiConstants.COMMA);
			sb.append(ApiConstants.CANAL).append(Encode.forJava(mov.getIdCanal() + "")).append(ApiConstants.COMMA);
			sb.append(ApiConstants.IMPORTE).append(Encode.forJava(mov.getImporte() + "")).append("]");
			request.append(sb).append(ApiConstants.COMMA);
		});

		return request.toString().substring(1, request.toString().length() - 1);
	}

	public ComprobanteSelloDigitalWSServiceFII getWSComprobanteSelloDigitalWSServiceFII(String url)
			throws MalformedURLException {
		return new ComprobanteSelloDigitalWSServiceFII(new URL(url));
	}

}
