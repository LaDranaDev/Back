/**
* Santander SCIB - Banco Santander Negocios Globales
* Todos los derechos reservados
* NivelOperacionHistRequest.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <20 nov 2024 09:16:27>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.model.request;

import java.io.Serializable;

import jakarta.validation.constraints.Pattern;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NivelOperacionHistRequest implements Serializable {

	/** Declaracion de Constante serialVersionUID. */
	private static final long serialVersionUID = -289479419019753541L;
	
	/** Declaracion de String para nomCliente. */
	@Pattern(regexp = "(^[0-9A-Za-z_. - ]+$)?", message = "Datos no validos")
	private String nomCliente;
	
	/** Id de movimiento H2H. */
	private Integer idReg;

}
