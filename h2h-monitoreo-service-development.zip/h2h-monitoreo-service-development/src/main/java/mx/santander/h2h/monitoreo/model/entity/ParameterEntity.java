package mx.santander.h2h.monitoreo.model.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * ParameterEntity
 * Entidad para los horarios de intradia.
 *
 * @author Felipe Monzon
 * @since 05/05/2022
 */
@Entity
@Getter
@Setter
@ToString
@Table(name = "H2H_PARAM")
public class ParameterEntity implements Serializable {
	/**
	 * serial.
	 */
	private static final long serialVersionUID = 2354243347020045792L;
	/**
	 * Identificador del parametro.
	 */
	@Id
	@Column(name = "ID_PARAM")
	private Integer id;
	/**
	 * valor del parametro.
	 */
	@Column(name = "VALOR")
	private String value;
	/**
	 * nombre del parametro.
	 */
	@Column(name = "NMBR_PARAM")
	private String name;

	/**
	 * descripcion del parametro.
	 */
	@Column(name = "DESRIPCION")
	private String description;

	/**
	 * Columna BAND_ACTIV
	 */
	@Column(name = "BAND_ACTIVO")
	private String status;

}
