package mx.santander.h2h.monitoreo.repository;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.constants.MonitorOperacionesConstants;
import mx.santander.h2h.monitoreo.constants.QueryConstant;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorCatalogsResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorCatalogsResponse.Pair;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.util.UtilMapeoData;
import mx.santander.h2h.monitoreo.util.UtilMonitorFnc;


/**
 * Implementación del acceso a Base de Datos del Monitor de Operaciones.
 *
 * @author Daniel Ruiz
 * @since 13/04/2023
 */

/** Declaracion de Constante log. */
@Slf4j
@Repository
public class OperationsMonitorEntityManagerRepository implements IOperationsMonitorEntityManagerRepository {
	
	
	/** Declaracion de EntityManager para entityManager. */
	@Autowired
    @PersistenceContext
    private EntityManager entityManager;
    
    /**  Mapa de las tablas de los productos de monitor de operaciones. */
    protected static final Map<String, String> TABLAS = new HashMap<String, String>(){
        /** Constante version*/
        private static final long serialVersionUID = 1L;
        {
            put("H2H_PROD_TRAN","02"); /**Nomina Interbancaria*/
            put("H2H_PROD_TRAN_MISM_BANC","98"); /**TMB*/
            put("H2H_PROD_NOMI_MISM_BANC","99"); /**Nomina Mismo Banco*/
            put("H2H_PROD_ALTA_PAGO","91"); /**ALTA PAGO PROVEEDORES CONFIRMING*/
            put("H2H_PROD_ORDN_PAGO","81"); /**ORDEN DE PAGO CANCELADO*/
            put("H2H_ACTA_BENI","96"); /**Alta Cuenta Beneficiarias*/
            put("H2H_PROD_ALTA_EMPL","93"); /**ALTA MASIVA EMPLEADOS*/
            put("H2H_PROD_DOMI","30"); /**DOMICILIACIONES*/
            put("H2H_PROD_DOMI_CXH","29"); /**DOMICILIACIONES*/
            put("H2H_PROD_MTTO_PROV","11"); /**CONFIRMING*/
            put("H2H_PROD_IMPU_FEDE","21");/**Pago de impuestos federales**/
            put("H2H_PROD_APO_OBRE_PATR","23");/**Aportaciones Obrero Patronales H2H_PROD_APO_OBRE_PATR**/
            put("H2H_PROD_PAGO_REFE","22");/**Pagos Referenciados**/
            put("H2H_MX_PROD_TRAN_INTN","31");/**TIMD**/
            put("H2H_MX_PROD_BANC_CAMB","33");/**TMBC**/
            put("H2H_MX_PROD_SPID","09");/**TMBC**/
            put("H2H_MX_PROD_PAGO_DIR","40");/**Pago Directo PGODIRECT**/
            put("H2H_MX_PROD_TVMB", "39");/**TABLA Transferencias Vostro Mismo Banco**/
            put("H2H_MX_PROD_TVIB", "38");/**TABLA Transferencias Vostro Interbancarias**/
            put("H2H_MX_PROD_TRAN_INTN", "32");/**TABLA Transferencias Internacionales Cambiarias**/
            put("H2H_MX_PROD_ORDN_PAGO_ATM","85");
            put("H2H_MX_PROD_PECE","25");
        }
        
        
        @Override
        public String toString(){
            final StringBuilder cveProdopersStr = new StringBuilder();
            cveProdopersStr.append("'01','97','95','80','41','42','47','48','49'"); /**Productos de una misma tabla*/
            for (Map.Entry<String, String> cveProdOper : entrySet()) {
                cveProdopersStr.append(",");
                cveProdopersStr.append("'").append(cveProdOper.getValue()).append("'");
            }
            return cveProdopersStr.toString();
        }
    };

    
    /**
     * Realiza la consulta de las operaciones.
     *
     * @param consultaOperaciones - Parámetros de consulta
     * @return Lista de operaciones realizadas
     */
    @Override
    public List<OperationsMonitorQueryResponse> consultaOperaciones(OperationsMonitorQueryRequest consultaOperaciones) {
        log.info("Realizando consulta de operaciones");
        // Declaramos los objetos del SQL Query y Paramtros
        final StringBuilder querySQL = new StringBuilder();
        Map<String, Object> params = new HashMap<>();
        
        int pagina = Integer.parseInt(consultaOperaciones.getPagina());
        int tamPagina = Integer.parseInt(consultaOperaciones.getTamanioPagina());
        
        // Llamamos a la funcion para ontener el QUERY de Consulta
        String querys = MonitorOperacionesRepository.preparaConsultaOperaciones(consultaOperaciones, querySQL, params);
        
        //MonitorOperacionesRepository.getViews(consultaOperaciones, querySQL, params);
        
        final StringBuilder queryCountSQL = new StringBuilder();
        Map<String, Object> paramsCount = new HashMap<>();
        
        UtilMonitorFnc.getQueryPaginado(querys, queryCountSQL, paramsCount, pagina, tamPagina);
        params.putAll(paramsCount);
        
        Query query = entityManager.createNativeQuery(queryCountSQL.toString(), Tuple.class );
        params.forEach(query::setParameter);
        
        // Recorremos los datos
        List<?> resultList = query.getResultList();
        List<OperationsMonitorQueryResponse> respuestaOperaciones = new ArrayList<OperationsMonitorQueryResponse>();

        for (Object result : resultList ) {
            if (result instanceof Tuple) {
                Tuple row = (Tuple) result;
                respuestaOperaciones.add(mapRowToResponse(row, false));
            }
        }

        log.info("Se realizo la consulta con exito, se encontraron " + respuestaOperaciones.size() + " registros.");
        return respuestaOperaciones;
    }

    
    /**
     * Consulta el total de registros.
     *
     * @param consultaOperaciones - Parámetros de consulta
     * @return Numero de total de registros
     */
    @Override
    public long countConsultaOperaciones(final OperationsMonitorQueryRequest consultaOperaciones) {
        final Map<String, Object> params = new HashMap<>();
        StringBuilder querySQL = new StringBuilder();
        // Llamamos a la funcion para ontener el QUERY de Consulta
        String querys = MonitorOperacionesRepository.preparaConsultaOperaciones(consultaOperaciones, querySQL, params);
        String queryCount = OperationsMonitorEntityManagerHelper2Repository.getQueryCount( querys );
        
        Query query = entityManager.createNativeQuery(queryCount, Tuple.class );
        params.forEach(query::setParameter);
        String resultado = query.getSingleResult().toString();
        resultado = resultado.replace("[", "");
        resultado = resultado.replace("]", "");
        
        return Long.parseLong( resultado );
    }

    
    /**
     * Obtiene los correos enviados.
     * @param consultaOperaciones - Parámetros de consulta
     * @return Total de correos enviados
     */
    @Override
    public long countCorreosEnv(OperationsMonitorQueryRequest consultaOperaciones) {
        final Map<String, Object> params = new HashMap<>();
        StringBuilder querySQL = new StringBuilder();
        MonitorOperacionesRepository.getCorreosEnvQuery(consultaOperaciones, querySQL, params);

        Query query = entityManager.createNativeQuery( querySQL.toString(), Tuple.class );
        params.forEach(query::setParameter);
        String cadResp = query.getSingleResult().toString();
        cadResp = cadResp.replace("[", "");
        cadResp = cadResp.replace("]", "");
        return Long.parseLong( cadResp );
    }

    
    /**
     * Obtiene el número de archivos.
     * @param consultaOperaciones - Parámetros de consulta
     * @return Total de archivos
     */
    @Override
    public long countArchivos(OperationsMonitorQueryRequest consultaOperaciones) {
        final Map<String, Object> params = new HashMap<>();
        final StringBuilder querySQL = new StringBuilder();
        
        String querys = MonitorOperacionesRepository.getCountArchivos(consultaOperaciones, querySQL, params);
        
		String queryCountSQL = OperationsMonitorEntityManagerHelper2Repository.getQueryCount(querys);
		
        Query query = entityManager.createNativeQuery( queryCountSQL, Tuple.class );
        // Se agregan los parametros
        params.forEach(query::setParameter);
        String cadResp = query.getSingleResult().toString();
        cadResp = cadResp.replace("[", "");
        cadResp = cadResp.replace("]", "");
        return Long.parseLong( cadResp );
    }
    

    /**
     * Obtiene importe global.
     * @param consultaOperaciones - Parámetros de consulta
     * @return Importe global
     */
    @Override
    public double getImporteGlobal(OperationsMonitorQueryRequest consultaOperaciones) {
        final Map<String, Object> params = new HashMap<>();
        StringBuilder querySQL = new StringBuilder();
        // Iniciamos la generacion de la Consulta
        MonitorOperacionesRepository.getImporteGlobalQuery(consultaOperaciones, querySQL, params);
		
		// Generamos la consulta con los parametros
		Query query = entityManager.createNativeQuery( querySQL.toString(), Tuple.class );
		// Se agregan los parametros
        params.forEach(query::setParameter);
        
        String cadResp = query.getSingleResult().toString();
        cadResp = cadResp.replace("[", "");
        cadResp = cadResp.replace("]", "");
        
        return Double.parseDouble( cadResp );
    }

    
    /**
     * Realiza la consulta de las operaciones para exportar.
     *
     * @param consultaOperaciones - Parámetros de consulta
     * @return Lista de operaciones realizadas
     */
    @Override
    public String consultaOperacionesExportar(
            OperationsMonitorQueryRequest consultaOperaciones ) {
    	
    	log.info("OperationsMonitorEntityManagerRepository - consultaOperacionesExportar - Inicia");
        Map<String, Object> params = new HashMap<>();
        final StringBuilder queryViewsSQL = new StringBuilder();
        // Obtenemos la consulta de datos
        MonitorOperacionesRepository.getViews(consultaOperaciones, queryViewsSQL, params);
        log.info("OperationsMonitorEntityManagerRepository - consultaOperacionesExportar: Termino consultaOperacionesExportar - getViews: " + queryViewsSQL.toString());
        Query queryViews = entityManager.createNativeQuery(queryViewsSQL.toString(), Tuple.class);
        params.forEach(queryViews::setParameter);
        // Iniciamos la consulta de Elementos de Tablas de Views
        List<?> viewsResult = queryViews.getResultList();
        List<String> views = new ArrayList<>();
        for (Object result : viewsResult) {
            if (result instanceof Tuple) {
                Tuple row = (Tuple) result;
                views.add(UtilMonitorFnc.getData(row.get("VIST_PROD")));
            }
        }
        if( views.size() == 0 ) {
        	log.info("No se encontraron datos VIST_PROD al consultar tabla, se cancela ejecución de operaciones");
//        	return new ArrayList<>();
        }
        
        Map<String, Object> paramsExporta = new HashMap<>();
        final StringBuilder queryExportSQL = new StringBuilder();
        log.info("OperationsMonitorEntityManagerRepository - getConsultaExportar: Llego");
        queryExportSQL.append(" SELECT * FROM ( ");
//        OperationsMonitorEntityManagerHelper2Repository.getConsultaExportar(views, consultaOperaciones, queryExportSQL, paramsExporta);
        queryExportSQL.append(OperationsMonitorEntityManagerHelper2NewRepository.getConsultaExportar(views, consultaOperaciones, queryExportSQL, paramsExporta));
        queryExportSQL.append(" ) ");
//        Query query = entityManager.createNativeQuery(queryExportSQL.toString(), Tuple.class);
//        paramsExporta.forEach(query::setParameter);
//        List<?> resultList = query.getResultList();
//        List<OperationsMonitorQueryResponse> operaciones = new ArrayList<>(resultList.size());
//        for (Object result : resultList) {
//            if (result instanceof Tuple) {
//                Tuple row = (Tuple) result;
//                operaciones.add(mapRowToResponse(row, true));
//            }
//        }
        String cadQuery = queryExportSQL.toString();
        
        //Recorremos los parametros para convertir a SQL
        for(Map.Entry<String, Object> item : params.entrySet()) {
        	//Reemplazar los datos
        	cadQuery = cadQuery.replace(":" + item.getKey(), "'" + item.getValue().toString() + "'");
        }
        log.info("OperationsMonitorEntityManagerRepository - getConsultaExportar: TERMINA");

        return cadQuery;
    }

    
    /**
     * Catalogs.
     *
     * @return el operations monitor catalogs response
     */
    @Override
    public OperationsMonitorCatalogsResponse catalogs() {
    	log.info("Iniciamos con la obtención de catalogos............");
        OperationsMonitorCatalogsResponse response = new OperationsMonitorCatalogsResponse();
        response.setDivisas(new ArrayList<>());
        response.setEstatus(new ArrayList<>());
        response.setProductos(new ArrayList<>());

        List<?> divisas = entityManager.createNativeQuery(QueryConstant.LISTA_DIVISAS, Tuple.class).getResultList();
        divisas.forEach(object -> {
            if (!(object instanceof Tuple)) return;
            Tuple tuple = (Tuple) object;
            String value = String.valueOf(tuple.get("value"));
            response.getDivisas().add(new Pair(value, value));
        });

        List<?> estatus = entityManager.createNativeQuery(QueryConstant.LISTA_ESTATUS, Tuple.class).getResultList();
        estatus.forEach(object -> {
            if (!(object instanceof Tuple)) return;
            Tuple tuple = (Tuple) object;
            String key = String.valueOf(tuple.get("key"));
            String value = String.valueOf(tuple.get("value"));
            response.getEstatus().add(new Pair(key, value));
        });

        List<?> productos = entityManager.createNativeQuery(QueryConstant.LISTA_PRODUCTOS, Tuple.class).getResultList();
        productos.forEach(object -> {
            if (!(object instanceof Tuple)) return;
            Tuple tuple = (Tuple) object;
            String key = String.valueOf(tuple.get("key"));
            String value = String.valueOf(tuple.get("value"));
            response.getProductos().add(new Pair(key, value));
        });

        return response;
    }

    
    /**
     * Función para mapear una row del resultado de la query al DTO del response.
     *
     * @param row Tupla con los datos de la row
     * @param export Bandera para definir si el response se usa para exportación o no
     * @return Response con los datos de la operación
     */
    private OperationsMonitorQueryResponse mapRowToResponse(Tuple row, boolean export) {
        OperationsMonitorQueryResponse respuesta = new OperationsMonitorQueryResponse();

        DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols();
        formatSymbols.setDecimalSeparator('.');
        formatSymbols.setGroupingSeparator(',');
        DecimalFormat decimalFormat = new DecimalFormat("###,###,###,###,##0.00", formatSymbols);

        respuesta.setIdOperacion(row.get("ID_REG") == null || row.get("ID_REG").toString().isEmpty() ? MonitorOperacionesConstants.CERO : row.get("ID_REG").toString());
        respuesta.setCodCli(UtilMonitorFnc.getData(row.get("BUC")));
        respuesta.setCtaCargo(UtilMonitorFnc.getData(row.get("NUM_CTA_CARGO")));
        respuesta.setCtaAbono(UtilMonitorFnc.getData(row.get("NUN_CTA_ABONO")));
        respuesta.setProducto(UtilMonitorFnc.getData(row.get("DESC_PROD")));
        respuesta.setNomArch(UtilMonitorFnc.getData(row.get("NOMBRE_ARCH")));
        respuesta.setCanal(UtilMonitorFnc.getData(row.get("NOMB_CANL")));

        respuesta.setReferencia(row.get("REFERENCIA") == null  ? StringUtils.EMPTY : row.get("REFERENCIA").toString().trim());
        if (MonitorOperacionesConstants.CERO.equals(respuesta.getReferencia()) || "null".equals(respuesta.getReferencia())){
            respuesta.setReferencia(StringUtils.EMPTY);
        }

        respuesta.setEstatus(UtilMonitorFnc.getData(row.get("DESC_ESTATUS")));
        respuesta.setImporte(row.get(MonitorOperacionesConstants.IMPORTE) == null || row.get(MonitorOperacionesConstants.IMPORTE).toString().isEmpty()
                ? "$0.00" : "$" + decimalFormat.format(Double.valueOf(row.get(MonitorOperacionesConstants.IMPORTE).toString())));

        respuesta.setImporteSinFormato(row.get(MonitorOperacionesConstants.IMPORTE) == null || row.get(MonitorOperacionesConstants.IMPORTE).toString().isEmpty()
                ? new BigDecimal("0.00") : new BigDecimal(row.get(MonitorOperacionesConstants.IMPORTE).toString()));

        respuesta.setFechaAplic(OperationsMonitorEntityManagerHelper3Repository.getFecha(row.get("FECHA_APLICACION")));
        respuesta.setFechaCaptura(OperationsMonitorEntityManagerHelper3Repository.getFecha(row.get("FECHA_REGISTRO")));
        respuesta.setBancoOrdenante("BANCO SANTANDER MEXICANO, S.A.");
        respuesta.setIdEstatus(row.get(MonitorOperacionesConstants.ID_ESTATUS) == null 
        		? MonitorOperacionesConstants.CERO : row.get(MonitorOperacionesConstants.ID_ESTATUS).toString());
        respuesta.setIdProducto(row.get(MonitorOperacionesConstants.CVE_PROD_OPER) == null 
        		? MonitorOperacionesConstants.CERO : row.get(MonitorOperacionesConstants.CVE_PROD_OPER).toString());
        respuesta.setVistProd(UtilMonitorFnc.getData(row.get("VIST_PROD")));
        respuesta.setDivisa(UtilMonitorFnc.getData(row.get("DIVISA")));
        if (MonitorOperacionesConstants.MN.equals(respuesta.getDivisa().trim())) {
            respuesta.setDivisa(MonitorOperacionesConstants.MXP);
        }
        if (MonitorOperacionesConstants.DL.equals(respuesta.getDivisa().trim())) {
            respuesta.setDivisa(MonitorOperacionesConstants.USD);
        }

        if (export) {
            respuesta.setComentario1(UtilMonitorFnc.getData(row.get("COMENTARIO_1")).trim());
            respuesta.setComentario2(UtilMonitorFnc.getData(row.get("COMENTARIO_2")).trim());
            respuesta.setComentario3(UtilMonitorFnc.getData(row.get("COMENTARIO_3")).trim());
            // Obtenemos el tipo de Divisa
            respuesta.setDivisa( UtilMonitorFnc.valDivisa(UtilMonitorFnc.getData(row.get("DIVISA"))) );
            respuesta.setDivisaOrd( UtilMonitorFnc.valDivisa(UtilMonitorFnc.getData(row.get("DIVISA_ORD"))) );

            respuesta.setFechaAplic(OperationsMonitorEntityManagerHelper3Repository.getFecha(row.get("FECHA_APLICACION")));
            respuesta.setFechaCaptura(OperationsMonitorEntityManagerHelper3Repository.getFecha(row.get("FECHA_REGISTRO")));
            respuesta.setFechaLimitPago(OperationsMonitorEntityManagerHelper3Repository.getFecha(row.get("FECHA_LIMITE_PAGO")));
            respuesta.setFechaOper(OperationsMonitorEntityManagerHelper3Repository.getFecha(row.get("FECHA_OPERACION")) );
            respuesta.setFechaPresIni(OperationsMonitorEntityManagerHelper3Repository.getFecha(row.get("FECHA_PRESENTACION_INICIAL")) );
            respuesta.setImporteCargo(row.get("IMPORTE_CARGO") == null || row.get("IMPORTE_CARGO").toString().isEmpty() ?
            respuesta.getImporte() : "$" + decimalFormat.format(Double.valueOf(row.get("IMPORTE_CARGO").toString().trim())));
            respuesta.setNombreOrd(UtilMonitorFnc.getData(row.get("TITULAR")));
            respuesta.setIntermOrd(UtilMonitorFnc.getData(row.get("INTERMEDIARIO_ORD")));
            respuesta.setIntermRec(UtilMonitorFnc.getData(row.get("INTERMEDIARIO_REC")));
            respuesta.setModalidad(UtilMonitorFnc.getData(row.get("MODALIDAD")));
            respuesta.setNombreBenef(UtilMonitorFnc.getData(row.get("BENEFICIARIO")).trim());
            respuesta.setNumSucursal(UtilMonitorFnc.getData(row.get("NUM_SUCURSAL")).trim());
            respuesta.setNumOrden(UtilMonitorFnc.getData(row.get("NUM_ORDEN")).trim());
            respuesta.setTipoPago(UtilMonitorFnc.getData(row.get("TIPO_PAGO")).trim());
            respuesta.setBancoReceptor(UtilMonitorFnc.getData(row.get("BANCO_RECEPTOR")).trim());
            respuesta.setMensaje(UtilMonitorFnc.getData(row.get("MSG_H2H")).trim());
            respuesta.setIdEstatus(row.get(MonitorOperacionesConstants.ID_ESTATUS) == null ? MonitorOperacionesConstants.CERO : row.get(MonitorOperacionesConstants.ID_ESTATUS).toString().trim());
            respuesta.setIdProducto(row.get(MonitorOperacionesConstants.CVE_PROD_OPER) == null ? MonitorOperacionesConstants.CERO : row.get(MonitorOperacionesConstants.CVE_PROD_OPER).toString().trim());
            respuesta.setMensajeOrden(row.get("MSG_ORDEN_PAGO") == null ? MonitorOperacionesConstants.CERO : row.get("MSG_ORDEN_PAGO").toString().trim());
            respuesta.setNombreEmpleado(UtilMonitorFnc.getData(row.get("NOMBRE_EMPLEADO")).trim());
            respuesta.setBucEmpleado(UtilMonitorFnc.getData(row.get("BUC_EMPLEADO")).trim());
            respuesta.setNumEmpleado(UtilMonitorFnc.getData(row.get("NUMERO_EMPLEADO")).trim());
            respuesta.setRfc(UtilMonitorFnc.getData(row.get("RFC")).trim());
            respuesta.setNumTarjeta(UtilMonitorFnc.getData(row.get("NUMERO_TARJETA")).trim());
            respuesta.setNumeroCuenta(UtilMonitorFnc.getData(row.get("NUMERO_CUENTA")).trim());
            respuesta.setSucTutora(UtilMonitorFnc.getData(row.get("SUCURSAL_TUTORA")).trim());

            if (!respuesta.getModalidad().isEmpty()) {
                respuesta.setModalidad("T".equals(respuesta.getModalidad()) ? "Al momento de hacer la orden" : "Al momento de hacer la liquidaci\u00F3n");
            }
            if (!respuesta.getTipoPago().isEmpty()) {
                respuesta.setTipoPago("E".equals(respuesta.getTipoPago()) ? "E-EFECTIVO" : ("C".equals(respuesta.getTipoPago()) ? "C-CHEQUE" : "OTRO" ));
            }
            
        } else {
            respuesta.setTabla(UtilMonitorFnc.getData(row.get("TABLA")));
        }
        // Enmascaramos la tarjeta y Cuentas Abonos
        if( respuesta != null ) {
        	// Tarjetas
        	respuesta.setNumTarjeta(
        		UtilMapeoData.getMascara(respuesta.getNumTarjeta(), "tarjeta")
        	);
        	respuesta.setNumTarjetaAct(
        		UtilMapeoData.getMascara(respuesta.getNumTarjetaAct(), "tarjeta")
        	);
        	// Cuentas
        	respuesta.setCtaAbono(
        		UtilMapeoData.getMascara(respuesta.getCtaAbono(), "abono")
        	);
        }
        return respuesta;
    }
    
    
    /**
     * Consulta parametro.
     *
     * @param name para name
     * @return el string
     */
    @Override
    public String consultaParametro(String name) {
        String queryParam = "SELECT VALOR FROM H2H_PARAM WHERE NMBR_PARAM = :name";
        Query query = entityManager.createNativeQuery(queryParam);
        query.setParameter("name", name);
        return ((String) query.getSingleResult());
    }

    
	/**
	 * Consulta operaciones export.
	 *
	 * @param request para request
	 * @return el string
	 */
	@Override
	public String consultaOperacionesExport(OperationsMonitorQueryRequest request) {
		final StringBuilder queryPROD = new StringBuilder();
		Map<String, Object> paramsViews = new HashMap<>();
		
		// Iniciamos consulta de productos
		String querySQLGet = OperationsMonitorEntityManagerHelper2Repository.getViews(request, queryPROD, paramsViews);
	    
		
	    // Consultamos el listado de Productos --------------
		Query queryViews = entityManager.createNativeQuery(querySQLGet, Tuple.class );
		paramsViews.forEach(queryViews::setParameter);
		
		List<?> viewsResult = queryViews.getResultList();
		List<String> views = new ArrayList<>(viewsResult.size());
		for (Object result : viewsResult) {
			if (result instanceof Tuple) {
				Tuple row = (Tuple) result;
				views.add(UtilMonitorFnc.getData(row.get("VIST_PROD")));
			}
		}
		
		final StringBuilder querySQL = new StringBuilder();
		 Map<String, Object> params = new HashMap<>();
		// Obtenemos el SQL SCRIPT
		OperationsMonitorEntityManagerHelper2Repository.getConsultaExportar(views, request, querySQL, params);
		String cadQuery = querySQL.toString();
		
		// Recorremos los parametros para convertir a SQL
		for(Map.Entry<String, Object> item : params.entrySet() ) {
			// Remplazamos los datos
			cadQuery = cadQuery.replace(":"+item.getKey(), "'"+item.getValue().toString()+"'");
		}
		
		// Retornamos el SQL generado
		return cadQuery;
	}
}
