package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.model.response.CancelOperationResponse;

/**
 * Interfas con las servcios disponibles
 * @author NTTDATA-NRL
 * @version 1.0
 */
public interface ICancelOperationConsultaService {

    /**
     * Función para hacer la consulta de operaciones que se pueden
     * cancelar
     * @param bucCliente buc del cliente
     * @return CancelOperationResponse
     */
    CancelOperationResponse consultaCancel(String bucCliente);

   
}
