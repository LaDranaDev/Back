package mx.santander.h2h.monitoreo.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Repository;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.constants.MonitorOperacionesConstants;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.util.UtilOperacionMonitorNew;
import mx.santander.h2h.monitoreo.util.UtilOrdenesPagoAtmDatosExportarNew;
import mx.santander.h2h.monitoreo.util.UtilVostroDatosExportar;
import mx.santander.h2h.monitoreo.util.UtilVostroDatosExportarNew;

@Slf4j
@Repository
public class OperationsMonitorEntityManagerHelper2NewRepository implements IOperationsMonitorEntityManagerHelper2Repository {

	/**
	 * Constante UNION_ALL
	 * TCs (sonar)
	 */
	protected static final String UNION_ALL = " UNION ALL ";
	/**SELECT REG.ID_REG, REG.CVE_PROD_OPER, REG.CNTA_CARG, REG.CNTA_ABON, REG.REFE_BE, REG.ID_ESTATUS, REG.MONT */
	protected static final String SELECT_REG_ID_REG_REG_CVE_PROD_OPER_REG_CNTA_CARG_REG_CNTA_ABON_REG_REFE_BE_REG_ID_ESTATUS_REG_MONT = "SELECT REG.ID_REG, REG.CVE_PROD_OPER, REG.CNTA_CARG, REG.CNTA_ABON, REG.REFE_BE, REG.ID_ESTATUS, REG.MONT, ";
	/**REG.FECH_APLI, REG.FECH_OPER, REG.FECH_ENVI_BACK, REG.ID_MSG, REG.DIVI, */
	protected static final String REG_FECH_APLI_REG_FECH_OPER_REG_FECH_ENVI_BACK_REG_ID_MSG_REG_DIVI = "REG.FECH_APLI, REG.FECH_OPER, REG.FECH_ENVI_BACK, REG.ID_MSG, REG.DIVI, ";
	/**ARCH.FECHA_REGISTRO, ARCH.NOMBRE_ARCH, ARCH.ID_CNTR, CANL.NOMB_CANL */
	protected static final String ARCH_FECHA_REGISTRO_ARCH_NOMBRE_ARCH_ARCH_ID_CNTR_CANL_NOMB_CANL = "ARCH.FECHA_REGISTRO, ARCH.NOMBRE_ARCH, ARCH.ID_CNTR, CANL.NOMB_CANL ";
	/**WHERE ((ARCH.FECHA_REGISTRO >= TO_DATE('*/
	protected static final String WHERE_ARCH_FECHA_REGISTRO_TO_DATE = "WHERE ((ARCH.FECHA_REGISTRO >= TO_DATE('";
	/**NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD, */
	protected static final String NULL_INTERMEDIARIO_ORD_NULL_DIVISA_ORD="null INTERMEDIARIO_ORD, TMP.DIVI DIVISA_ORD, ";
	/**NULL INTERMEDIARIO_REC, NULL BENEFICIARIO, */
	protected static final String NULL_INTERMEDIARIO_REC_NULL_BENEFICIARIO="MSG.MSG_H2H INTERMEDIARIO_REC, NULL BENEFICIARIO, ";
	/**MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, */
	protected static final String MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN="MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, ";
	/**  NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, *. */
	public static final String NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA = "NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, ";
	/** NULL BUC_EMPLEADO, */
	protected static final String NULL_BUC_EMPLEADO = " NULL BUC_EMPLEADO, ";
	/**"NULL SUCURSAL_TUTORA, NULL RFC, NULL TIPO, "**/
	protected static final String NULL_SUCURSAL_TUTORA_NULL_RFC_NULL_TIPO="NULL SUCURSAL_TUTORA, NULL RFC, NULL TIPO, ";
	/**NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA,**/
	protected static final String NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA="NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, ";
	/** Tabla PROD */
	protected static final String TABLA_PROD = ") PROD ";
	/**INNER JOIN H2H_CNTR CNTR USING (ID_CNTR) */
	protected static final String INNER_JOIN_H2H_CNTR_CNTR_USING_ID_CNTR = " INNER JOIN H2H_CNTR CNTR USING (ID_CNTR) ";
	/**
	 * constante para
	 * la tabla de 
	 * H2H_MX_PROD_TRAN_INTN
	 *   
	 */
	private static final String H2H_MX_PROD_TRAN_INTN="H2H_MX_PROD_TRAN_INTN";
	/**
	 * constante para el query de la 
	 * obtencion del monitor de 
	 * operaciones, en especifico
	 * el inner con CTa INFO
	 * PART_QUERY_SELECT_INNER_CTA_INFO
	 */
	private static final String PART_QUERY_SELECT_INNER_CTA_INFO="LEFT JOIN H2H_CTA_INFO CNTA_CARG ON TMP.CNTA_CARG = CNTA_CARG.NUME_CTA AND CNTA_CARG.TIPO_CTA = 'O' ";
	/**
	 * constante para el query de la 
	 * obtencion del monitor de 
	 * operaciones, en especifico
	 * el inner con H2H_CAT_DIVISA
	 * de la divisa abono
	 * PART_QUERY_JOIN_DIVI_ABONO
	 */
	private static final String PART_QUERY_JOIN_DIVI_ABONO="LEFT JOIN H2H_CAT_DIVISA DIVI_ABON ON DIVI_ABON.ID_CAT_DIVISA = CNTA_ABON.ID_CAT_DIVISA ";
	/**
	 * constante para el query de la 
	 * obtencion del monitor de 
	 * operaciones, en especifico
	 * el inner con H2H_CAT_DIVISA
	 * de la divisa Cargo
	 * PART_QUERY_JOIN_DIVI_CARG
	 */
	private static final String PART_QUERY_JOIN_DIVI_CARG="LEFT JOIN H2H_CAT_DIVISA DIVI_CARG ON DIVI_CARG.ID_CAT_DIVISA = CNTA_CARG.ID_CAT_DIVISA ";
	/** Constante CERO */
	protected static final String CERO = "0";
	/** Constante DIVISA MXP*/
	protected static final transient String MXP = "MXP";
	/** Constante DIVISA COD_DIVS_SAL*/
	protected static final transient String MN = "MN";
	/** Constante DIVISA CLAV_CAPTA*/
	protected static final String USD = "USD";
	/** Constante DIVISA COD_DIVS_SAL*/
	protected static final String DL = "DL";
	/** Constante producto proveedor confirming */
	protected static final String PROD_PROV_CONFIRMING = "11";
	
	/** Mapa de las tablas de los productos de monitor de operaciones */
	protected static final transient Map<String, String> TABLAS = new HashMap<String, String>(){
		/** Constante version*/
		private static final long serialVersionUID = 1L;
		{ 
			put("H2H_PROD_TRAN","02"); /**Nomina Interbancaria*/
			put("H2H_PROD_TRAN_MISM_BANC","98"); /**TMB*/
			put("H2H_PROD_NOMI_MISM_BANC","99"); /**Nomina Mismo Banco*/
			put("H2H_PROD_ALTA_PAGO","91"); /**ALTA PAGO PROVEEDORES CONFIRMING*/
			put("H2H_PROD_ORDN_PAGO","81"); /**ORDEN DE PAGO CANCELADO*/
			put("H2H_ACTA_BENI","96"); /**Alta Cuenta Beneficiarias*/	
			put("H2H_PROD_ALTA_EMPL","93"); /**ALTA MASIVA EMPLEADOS*/
			put("H2H_PROD_DOMI_CXH","29"); /**DOMICILIACIONES*/
			put("H2H_PROD_DOMI","30"); /**DOMICILIACIONES*/
			put("H2H_PROD_MTTO_PROV","11"); /**CONFIRMING*/
			put("H2H_PROD_IMPU_FEDE","21");/**Pago de impuestos federales**/
			put("H2H_PROD_APO_OBRE_PATR","23");/**Aportaciones Obrero Patronales H2H_PROD_APO_OBRE_PATR**/
			put("H2H_PROD_PAGO_REFE","22");/**Pagos Referenciados**/
			put(H2H_MX_PROD_TRAN_INTN,"31");/**TIMD**/
			put("H2H_MX_PROD_BANC_CAMB","33");/**TMBC**/
			put("H2H_MX_PROD_SPID","09");/**TMBC**/
			put("H2H_MX_PROD_PAGO_DIR","40");/**Pago Directo PGODIRECT**/
			put("H2H_MX_PROD_TVMB", "39");/**TABLA Transferencias Vostro Mismo Banco**/
			put("H2H_MX_PROD_TVIB", "38");/**TABLA Transferencias Vostro Interbancarias**/
			put(H2H_MX_PROD_TRAN_INTN, "32");/**TABLA Transferencias Internacionales Cambiarias**/
			put("H2H_MX_PROD_ORDN_PAGO_ATM","85");
			put("H2H_MX_PROD_PECE","25");//Este no lo veo en el codigo anterior
		}
		
		@Override
		public String toString(){
			final StringBuilder cveProdopersStr = new StringBuilder();
			cveProdopersStr.append("'01','97','95','80'"); /**Productos de una misma tabla*/
//			cveProdopersStr.append("'01','97','95','80','41','42','47','48','49'"); /**Productos de una misma tabla*/
			for (Map.Entry<String, String> cveProdOper : entrySet()) {
				cveProdopersStr.append(",");
				cveProdopersStr.append("'").append(cveProdOper.getValue()).append("'");
			}
			return cveProdopersStr.toString();
		}
	};
	
	/**
	 * Obtiene operaciones por producto.
	 *
	 * @param views               nombres de las vistas de productos
	 * @param consultaOperaciones el parametro consulta operaciones
	 * @return String de la cosnulta de las poeraciones por producto
	 */
	protected static String getConsultaExportar(List<String> views, OperationsMonitorQueryRequest consultaOperaciones, final StringBuilder querys, Map<String, Object> params) {
		log.info("OperationsMonitorEntityManagerHelper2NewRepository - getConsultaExportar - Inicia el flujo");
		final StringBuilder query = new StringBuilder();
		boolean union = false;
//		query.append("SELECT * FROM ( ");
		log.info("OperationsMonitorEntityManagerHelper2NewRepository - getConsultaExportar - Inicia el flujo - getArchTemp");
		query.append(getArchTemp(consultaOperaciones, query, params));
		log.info("OperationsMonitorEntityManagerHelper2NewRepository - getConsultaExportar - Paso el flujo - getArchTemp");
		query.append(" SELECT PROD.*, ROWNUM FROM ( ");
		log.info("OperationsMonitorEntityManagerHelper2NewRepository - getConsultaExportar - Llego al flujo for: " + views.size());
		for (String view : views){
			log.info("For: " + view);
			if (union){
				query.append(UNION_ALL);
			} 
			query.append(getConsultaByProducto(view, consultaOperaciones, query, params));
			union = true;
		}
		log.info("OperationsMonitorEntityManagerHelper2NewRepository - getConsultaExportar - Paso el flujo for");
		query
			.append(" ) PROD ")
//			.append(" GROUP BY  PROD.NOMB_CANL, PROD.ID_REG, PROD.BUC, PROD.NUM_CTA_CARGO, " )
//	        .append(" PROD.NUN_CTA_ABONO, PROD.CVE_PROD_OPER,      PROD.DESC_PROD,      PROD.NOMBRE_ARCH,      PROD.REFERENCIA,      PROD.ID_ESTATUS, " )
//	        .append(" PROD.DESC_ESTATUS,  PROD.IMPORTE,      PROD.NUM_CNTR,      PROD.DIVISA,      PROD.FECHA_REGISTRO, " )
//	        .append(" PROD.FECHA_APLICACION,  PROD.VIST_PROD,      PROD.INTERMEDIARIO_ORD,      PROD.DIVISA_ORD,      PROD.INTERMEDIARIO_REC, " )
//	        .append(" PROD.BENEFICIARIO,      PROD.COMENTARIO_1,      PROD.COMENTARIO_2,      PROD.COMENTARIO_3,      PROD.TITULAR, " )
//	        .append(" PROD.BANCO_RECEPTOR,    PROD.TIPO_PAGO,      PROD.MODALIDAD,      PROD.IMPORTE_CARGO,      PROD.MSG_H2H, " )
//	        .append(" PROD.MSG_ORDEN_PAGO,    PROD.NUM_ORDEN,      PROD.FECHA_LIMITE_PAGO,      PROD.NUM_SUCURSAL,      PROD.NUMERO_EMPLEADO, " )
//	        .append(" PROD.NUMERO_TARJETA,    PROD.BUC_EMPLEADO,      PROD.SUCURSAL_TUTORA,      PROD.RFC,      PROD.TIPO, " )
//	        .append(" PROD.NOMBRE_EMPLEADO,   PROD.NUMERO_CUENTA,      PROD.FECHA_PRESENTACION_INICIAL,      PROD.FECHA_OPERACION ")
//			.append(" ) PRODUCTOS ")
			.append(" ORDER BY PROD.ID_REG DESC ");
//		query.append(" ) ");
		
		log.info("OperationsMonitorEntityManagerHelper2NewRepository - getConsultaExportar - Termina el flujo con el querie: " + query.toString());
		
		return query.toString();
	}
	
	/**
	 * Metodo par crear un tabla temporal de las operaciones que se van a consultar
	 * @param consultaOperaciones opciones de la consulta
	 * @return String de la tabla temporal
	 */
	protected static String getArchTemp(OperationsMonitorQueryRequest consultaOperaciones, final StringBuilder querys, Map<String, Object> params){
		final StringBuilder query = new StringBuilder();
		query
		.append("WITH TEMP_ARCH AS (");
		if(OperationsMonitorEntityManagerHelper3Repository.isDateToday(consultaOperaciones.getFechaInicial())){
			query.append(SELECT_REG_ID_REG_REG_CVE_PROD_OPER_REG_CNTA_CARG_REG_CNTA_ABON_REG_REFE_BE_REG_ID_ESTATUS_REG_MONT)
			.append(REG_FECH_APLI_REG_FECH_OPER_REG_FECH_ENVI_BACK_REG_ID_MSG_REG_DIVI)
			.append(ARCH_FECHA_REGISTRO_ARCH_NOMBRE_ARCH_ARCH_ID_CNTR_CANL_NOMB_CANL)
			.append(", id_arch_be ") // PGODIRECT
			.append("FROM H2H_REG_TRAN REG ")
			.append("INNER JOIN H2H_ARCHIVO_TRAN ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ")
			.append(" INNER JOIN H2H_CAT_CANL CANL ON ARCH.ID_CANL = CANL.ID_CANL ")
			.append(WHERE_ARCH_FECHA_REGISTRO_TO_DATE)
			.append(consultaOperaciones.getFechaInicial())
			.append(MonitorOperacionesConstants.HORARIOINICIAL)
			.append("', 'DD/MM/YYYY HH24:MI:SS')")
			.append(" AND ARCH.FECHA_REGISTRO <= TO_DATE('")
			.append(consultaOperaciones.getFechaFinal())
			.append(MonitorOperacionesConstants.HORARIOFINAL)
			.append("', 'DD/MM/YYYY HH24:MI:SS')) OR (REG.FECH_APLI >= TO_DATE('")
			.append(consultaOperaciones.getFechaInicial())
			.append(MonitorOperacionesConstants.HORARIOINICIAL)
			.append("', 'DD/MM/YYYY HH24:MI:SS')")
			.append(" AND REG.FECH_APLI <= TO_DATE('")
			.append(consultaOperaciones.getFechaFinal())
			.append(MonitorOperacionesConstants.HORARIOFINAL).append("'")
			.append(MonitorOperacionesConstants.FORMATO_FECHA);
			
		} else {
			query.append(SELECT_REG_ID_REG_REG_CVE_PROD_OPER_REG_CNTA_CARG_REG_CNTA_ABON_REG_REFE_BE_REG_ID_ESTATUS_REG_MONT)
			.append(REG_FECH_APLI_REG_FECH_OPER_REG_FECH_ENVI_BACK_REG_ID_MSG_REG_DIVI)
			.append(ARCH_FECHA_REGISTRO_ARCH_NOMBRE_ARCH_ARCH_ID_CNTR_CANL_NOMB_CANL)
			.append(", id_arch_be ") // PGODIRECT
			.append("FROM H2H_REG REG ")
			.append("INNER JOIN H2H_ARCHIVO ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ")
			.append("INNER JOIN H2H_CAT_CANL CANL ON ARCH.ID_CANL = CANL.ID_CANL  ")
			.append(MonitorOperacionesConstants.CONS_RANGO_FECHA)
			.append(consultaOperaciones.getFechaInicial())
			.append(MonitorOperacionesConstants.HORARIOINICIAL)
			.append("', 'DD/MM/YYYY HH24:MI:SS')  AND ARCH.FECHA_REGISTRO <= TO_DATE('")
			.append(consultaOperaciones.getFechaFinal())
			.append(MonitorOperacionesConstants.HORARIOFINAL)
			.append("', 'DD/MM/YYYY HH24:MI:SS'))  OR (REG.FECH_APLI >= TO_DATE('")
			.append(consultaOperaciones.getFechaInicial())
			.append(MonitorOperacionesConstants.HORARIOINICIAL)
			.append("', 'DD/MM/YYYY HH24:MI:SS')  AND REG.FECH_APLI <= TO_DATE('")
			.append(consultaOperaciones.getFechaFinal())
			.append(MonitorOperacionesConstants.HORARIOFINAL).append("'")
			.append(MonitorOperacionesConstants.FORMATO_FECHA)
			
			.append(MonitorOperacionesConstants.UNION_ALL)
			
			.append(SELECT_REG_ID_REG_REG_CVE_PROD_OPER_REG_CNTA_CARG_REG_CNTA_ABON_REG_REFE_BE_REG_ID_ESTATUS_REG_MONT)
			.append(REG_FECH_APLI_REG_FECH_OPER_REG_FECH_ENVI_BACK_REG_ID_MSG_REG_DIVI)
			.append(ARCH_FECHA_REGISTRO_ARCH_NOMBRE_ARCH_ARCH_ID_CNTR_CANL_NOMB_CANL)
			.append(", id_arch_be ") // PGODIRECT
			.append("FROM H2H_REG_TRAN REG ")
			.append("INNER JOIN H2H_ARCHIVO_TRAN ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ")
			.append("INNER JOIN H2H_CAT_CANL CANL ON ARCH.ID_CANL = CANL.ID_CANL  ")
			.append("WHERE ((ARCH.FECHA_REGISTRO >= TO_DATE('")
			.append(consultaOperaciones.getFechaInicial())
			.append(MonitorOperacionesConstants.HORARIOINICIAL)
			.append("', 'DD/MM/YYYY HH24:MI:SS') AND ARCH.FECHA_REGISTRO <= TO_DATE('")
			.append(consultaOperaciones.getFechaFinal())
			.append(MonitorOperacionesConstants.HORARIOFINAL)
			.append("', 'DD/MM/YYYY HH24:MI:SS')) OR (REG.FECH_APLI >= TO_DATE('")
			.append(consultaOperaciones.getFechaInicial())
			.append(MonitorOperacionesConstants.HORARIOINICIAL)
			.append("', 'DD/MM/YYYY HH24:MI:SS') AND REG.FECH_APLI <= TO_DATE('")
			.append(consultaOperaciones.getFechaFinal())
			.append(MonitorOperacionesConstants.HORARIOFINAL).append("'")
			.append(MonitorOperacionesConstants.FORMATO_FECHA);
		
		}
//		query.append(MonitorOperacionesConstants.CONS_RANGO_FECHA);
		query.append(")");
		
//		params.put("fechaInicial", consultaOperaciones.getFechaInicial() + MonitorOperacionesConstants.HORARIOINICIAL);
//		params.put("fechaFinal", consultaOperaciones.getFechaFinal() + MonitorOperacionesConstants.HORARIOFINAL);
		return query.toString();
	}
	
	/**
	 * Crea el query por producto y si el dlel dia de hoy o el de tres meses
	 * @param cveOperProd clave del producto
	 * @param consultaOperaciones DTO de restricciones
	 * @return SQL del producto
	 */
	protected static String getConsultaByProducto(String cveOperProd, OperationsMonitorQueryRequest consultaOperaciones, final StringBuilder querys, Map<String, Object> params) {
		log.info("OperationsMonitorEntityManagerHelper2NewRepository - getConsultaByProducto - Inicia metodo");
		log.info("Valor de view: " + cveOperProd);
		final StringBuilder query = new StringBuilder();
		final String tablaProd = cveOperProd;
		cveOperProd = TABLAS.get(tablaProd);
		log.info("OperationsMonitorEntityManagerHelper2NewRepository - getConsultaByProducto - CVE PROD despues de TABLAS: " + cveOperProd);
		query
		.append("SELECT PROD.* FROM (SELECT NOMB_CANL, ")
		.append("ID_REG, CLTE.BUC, TMP.CNTA_CARG NUM_CTA_CARGO, ");

//		String qryCadVal = UtilOperacionMonitorNew.getCadValidacion(query, cveOperProd);
//		query.append(qryCadVal)
		
		if("31".equals(cveOperProd) || "33".equals(cveOperProd) || "32".equals(cveOperProd)){
			query.append("DETA.NUM_CTA_BENE NUN_CTA_ABONO, PROD.CVE_PROD_OPER, PROD.DESC_PROD, ");
		}else{
			query.append("TMP.CNTA_ABON NUN_CTA_ABONO, PROD.CVE_PROD_OPER, PROD.DESC_PROD, ");
		}
		query.append("TMP.NOMBRE_ARCH, ");
		if("21".equals(cveOperProd) || "22".equals(cveOperProd) || "23".equals(cveOperProd)){
			query.append("DETA.REFE_MOV REFERENCIA,");
		}else if("31".equals(cveOperProd) || "32".equals(cveOperProd)){
			query.append("DETA.TXT_REF REFERENCIA,");
		}else if("33".equals(cveOperProd)){
			query.append("to_char(DETA.NUM_ORDEN) REFERENCIA,");
		}else{
			query.append("TMP.REFE_BE REFERENCIA,");
		}
		
		query.append(" TMP.ID_ESTATUS, ").append("EST.DESC_ESTATUS, TMP.MONT IMPORTE, CNTR.NUM_CNTR, TMP.DIVI DIVISA, ")
			.append("TMP.FECHA_REGISTRO, TMP.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, ");
		
		if ("01".equals(cveOperProd) || "97".equals(cveOperProd) || "02".equals(cveOperProd)) {/**SPEI - TEF - Nomina Interbancaria*/
			query.append(UtilOperacionMonitorNew.agrega01y97y02(query));
		} else if ("80".equals(cveOperProd) || "81".equals(cveOperProd)) {/**ORDEN DE PAGO*/
			query.append(UtilOperacionMonitorNew.agrega80y81(query));
		} else 	if ("95".equals(cveOperProd)  || "96".equals(cveOperProd)) {/**Alta Cuenta Beneficiarias*/
			query.append(UtilOperacionMonitorNew.agrega95y96(query));
		} else 	if ("98".equals(cveOperProd)   || "99".equals(cveOperProd)) {/**TMB  -  Nomina Mismo Banco*/
			query.append(UtilOperacionMonitorNew.agrega9y99(query));
		} else if ("91".equals(cveOperProd) || "93".equals(cveOperProd) || "30".equals(cveOperProd)|| "29".equals(cveOperProd)) {/**ALTA PAGO PROVEEDORES CONFIRMING*/
			query.append(UtilOperacionMonitorNew.completaQueryProducto919330(cveOperProd));
		}else if("21".equals(cveOperProd) || "22".equals(cveOperProd) || "23".equals(cveOperProd)){
			query.append(UtilOperacionMonitorNew.agregaPifconsulta(query,cveOperProd));
		}else if("31".equals(cveOperProd) || "33".equals(cveOperProd) || "32".equals(cveOperProd)){
			query.append(UtilOperacionMonitorNew.agregaTIconsulta(query,cveOperProd));
		}else{										
			query
				.append(NULL_INTERMEDIARIO_ORD_NULL_DIVISA_ORD)
				.append(NULL_INTERMEDIARIO_REC_NULL_BENEFICIARIO)
				.append("NULL COMENTARIO_1, NULL COMENTARIO_2, ")
				.append(" NULL COMENTARIO_3, NULL TITULAR, NULL BANCO_RECEPTOR, ")
				.append("NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO, ")
				.append(MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN)
				.append(" NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL,  ")
				.append(NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA)
				.append(NULL_BUC_EMPLEADO)
				.append(NULL_SUCURSAL_TUTORA_NULL_RFC_NULL_TIPO)
				.append(NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA);
		}
		
//		String qryValCve = UtilOperacionMonitorNew.getValidacionCve(query, cveOperProd);
		query.append("TMP.FECH_OPER FECHA_PRESENTACION_INICIAL, TMP.FECH_ENVI_BACK FECHA_OPERACION ");
		
		log.info("Antes de vostro querie: " + query.toString());
		query.append(UtilVostroDatosExportarNew.getQuerySelectExportar(cveOperProd,query));
		log.info("Despues de vostro querie: " + query.toString());
		query.append(UtilOrdenesPagoAtmDatosExportarNew.getQuerySelectExportar(cveOperProd,query));
		log.info("Despues de PagoAtm querie: " + query.toString());
		
		log.info("Validacion para NOT IN, valor de tablaProd: " + tablaProd);
		if (!TABLAS.containsKey(tablaProd)){
			log.info("Entro a if de NOT IN");
			query.append("FROM (SELECT TMP.* FROM TEMP_ARCH TMP WHERE TMP.CVE_PROD_OPER NOT IN(")
			.append(TABLAS.toString())
			.append(")) TMP ");
		} else {
			log.info("Entro a else de NOT IN");
			query.append("FROM TEMP_ARCH TMP INNER JOIN (SELECT * FROM ");
			if(OperationsMonitorEntityManagerHelper3Repository.isDateToday(consultaOperaciones.getFechaInicial())){
				query.append(tablaProd).append("_TRAN ) DETA USING (ID_REG) ");
			} else {
				query.append(tablaProd).append("_TRAN UNION ALL SELECT * FROM ")
						.append(tablaProd).append(") DETA USING (ID_REG) ");
			}
		}
		log.info("*****MIGAJA 4 *****");
		query.append(addINNERS()).append(UtilVostroDatosExportar.addInnerVostro(cveOperProd));
		if ("40".equals(cveOperProd)) { 						/**PGODIRECT*/
	    	query.append("LEFT JOIN H2H_MX_CNTR_ENL ctre ON DETA.ID_CNTR_ENLA = TO_CHAR(ctre.ID_CNTR_ENLA) ");
	    	query.append("LEFT JOIN H2H_CNTR_CTA ccta ON ctre.ID_CNTR = ccta.ID_CNTR ");
	    	query.append("LEFT JOIN H2H_CTA_INFO info ON ccta.NUM_CTA = info.NUME_CTA ");
	    	query.append("LEFT JOIN H2H_ARCH_BACK_TRAN abt ON  TMP.id_arch_be = abt.id_arch_back ");
	    }
		log.info("*****consultaOperaciones.getCveProveedor()*****"+consultaOperaciones.getCveProveedor()+"\n*****consultaOperaciones.getTipOperacion()*****"+consultaOperaciones.getTipOperacion());
		
		String qryPrd = (completaConsultaByProducto(cveOperProd, consultaOperaciones, query, params));
		if (qryPrd != null && !qryPrd.isEmpty()) {
			query.append(qryPrd);
		}
		
		query.append(TABLA_PROD);
		log.info("Llego al Where qryConOper");
		String qryConOper = getWhereConsultaOperaciones(consultaOperaciones, query, params, true);
		query.append(qryConOper);
		log.info("OperationsMonitorEntityManagerHelper2NewRepository - getConsultaByProducto - Termina metodo");
		return query.toString();
	}
	
	/**
	 * Crea el query por producto y si el dlel dia de hoy o el de tres meses
	 * @param cveOperProd clave del producto
	 * @param consultaOperaciones DTO de restricciones
	 * @return SQL del producto
	 */
	protected static String completaConsultaByProducto(String cveOperProd, OperationsMonitorQueryRequest consultaOperaciones, final StringBuilder querys, Map<String, Object> params) {
		StringBuilder query = new StringBuilder();
		if ("11".equals(consultaOperaciones.getIdProducto())
				&& (consultaOperaciones.getCveProveedor() != null || consultaOperaciones
						.getTipOperacion() != null)
				&& (!StringUtils.EMPTY.equals(consultaOperaciones
						.getCveProveedor()) || !StringUtils.EMPTY
						.equals(consultaOperaciones.getTipOperacion()))) {
			log.info("*****AGREGA EL WHERE EN CASO DE SER CONFIRMING Y QUE ALGUNO DE LOS PARAMTROS NO SEA VACIO*****");
			query.append("  WHERE  ");
			if (!StringUtils.EMPTY.equals(consultaOperaciones.getTipOperacion()) && consultaOperaciones.getTipOperacion() != null) {
				log.info("*****SI NO ES VACIO AGREGA TIPO OPERACION*****");
				query.append(" DETA.CLVE_OPER = ")
						.append(consultaOperaciones.getTipOperacion())
						.append(" ");
			}
			if (!StringUtils.EMPTY.equals(consultaOperaciones.getCveProveedor()) && consultaOperaciones.getCveProveedor() != null) {
				log.info("*****SI NO ES VACIO AGREGA CLAVE DE PROVEEDOR*****");
				if (!StringUtils.EMPTY.equals(consultaOperaciones.getTipOperacion()) && consultaOperaciones.getTipOperacion() != null) {
					query.append("AND  DETA.CLVE_PROV LIKE '%")
							.append(consultaOperaciones.getCveProveedor())
							.append("%' ");
				} else {
					query.append("  DETA.CLVE_PROV LIKE '%")
							.append(consultaOperaciones.getCveProveedor())
							.append("%' ");
				}
			}
		}

		if ("01".equals(cveOperProd) || "97".equals(cveOperProd) || "02".equals(cveOperProd)) {
			query.append("LEFT JOIN H2H_CAT_BNCO BNCO ON DETA.CLAV_INTER_RECE  = BNCO.CODI_TRAN AND BNCO.BAND_ACTIVO = 1 ");
		}
		if ("95".equals(cveOperProd) || "96".equals(cveOperProd)) {
			query.append("LEFT JOIN H2H_CAT_BNCO BNCO USING(ID_BANCO) ");
		}
		if ("98".equals(cveOperProd) || "99".equals(cveOperProd)) {
			query.append("LEFT JOIN H2H_CAT_BNCO BNCO ON DETA.ID_BANC = BNCO.ID_BANCO ");
		}
		query.append(UtilVostroDatosExportarNew.completaQueryByCveProdOper(query, params));
		return query.toString();
	}
	
	/***
	 * metodo de ayuda para concatenar los inners faltantes
	 * @return string de inner joins
	 */
	private static String addINNERS() {
		return new StringBuffer().append(INNER_JOIN_H2H_CNTR_CNTR_USING_ID_CNTR)
		.append("INNER JOIN H2H_CLTE CLTE USING (ID_CLTE)  ")
		.append("INNER JOIN H2H_CAT_PROD PROD ON TMP.CVE_PROD_OPER=PROD.CVE_PROD_OPER  ")
		.append("INNER JOIN H2H_CAT_ESTATUS EST ON TMP.ID_ESTATUS = EST.ID_CAT_ESTATUS ")
		.append("LEFT JOIN H2H_MSG MSG ON MSG.ID_MSG = TMP.ID_MSG ").toString();
	}
	
	/**
	 * Agrega el where de parametros de consulta.
	 * @param consultaOperaciones DTO de restricciones
	 * @param exportar true para flujo de exportacion
	 * @return String gener el where de la cosnulta
	 */
	public static String getWhereConsultaOperaciones(OperationsMonitorQueryRequest consultaOperaciones, StringBuilder querySQLOrigen, Map<String, Object> params, boolean exportar){		
		StringBuilder query = new StringBuilder();
		boolean someFilter =  false;
		if (exportar){
			query.append("WHERE ");
		} else {
			someFilter = true;
			query.append("WHERE ((PROD.FECHA_REGISTRO >= TO_DATE(") 
			.append(consultaOperaciones.getFechaInicial())
			.append(MonitorOperacionesConstants.HORARIOINICIAL)
			.append("', 'DD/MM/YYYY HH24:MI:SS') ")
			.append("AND PROD.FECHA_REGISTRO <= TO_DATE('")
			.append(consultaOperaciones.getFechaFinal())
			.append(MonitorOperacionesConstants.HORARIOFINAL)
			.append("', 'DD/MM/YYYY HH24:MI:SS')) OR (PROD.FECHA_APLICACION >= TO_DATE('")
			.append(consultaOperaciones.getFechaInicial())
			.append(MonitorOperacionesConstants.HORARIOINICIAL)
			.append("', 'DD/MM/YYYY HH24:MI:SS') ")
			.append("AND PROD.FECHA_APLICACION <= TO_DATE('")
			.append(consultaOperaciones.getFechaFinal())
			.append(MonitorOperacionesConstants.HORARIOFINAL).append("'")
			.append(MonitorOperacionesConstants.FORMATO_FECHA);
		}
		
		String qCont = UtilOrdenesPagoAtmDatosExportarNew.getWhereConsultaOperacionesCont(consultaOperaciones, params, someFilter);
		if(qCont != null && !qCont.isEmpty()) {
			query.append(qCont);
			someFilter = true;
			log.info("QUERY qCont NEW getWhereConsultaOperaciones : " + query.toString());
		}
		
		if (consultaOperaciones.getDivisa() != null && !CERO.equals(consultaOperaciones.getDivisa())) {
			if (MXP.equals(consultaOperaciones.getDivisa())) {
				query.append(someFilter ? "AND (PROD.DIVISA = '" : "(PROD.DIVISA = '").append(MXP).append("' OR PROD.DIVISA = '").append(MN).append("') ");
			} else {
				if (USD.equals(consultaOperaciones.getDivisa())) {
					query.append(someFilter ? "AND (PROD.DIVISA = '" : "(PROD.DIVISA = '").append(USD).append("' OR PROD.DIVISA = '").append(DL).append("') ");
				} else {
					query.append(someFilter ? "AND PROD.DIVISA = '" : "PROD.DIVISA = '").append(consultaOperaciones.getDivisa()).append("' ");
				}
			}
			someFilter = true;
		}

//		query.append(UtilOrdenesPagoAtmDatosExportarNew.isPif2(consultaOperaciones, query, params, someFilter));
		if (consultaOperaciones.getNumeroOrden()!= null && !StringUtils.EMPTY.equals(consultaOperaciones.getNumeroOrden())) {		
			query.append(someFilter ? "AND PROD.NUM_ORDEN = " : "PROD.NUM_ORDEN = ").append(consultaOperaciones.getNumeroOrden()).append(" ");
//			params.put("numeroOrden", consultaOperaciones.getNumeroOrden());
			someFilter = true;
		}
		if (consultaOperaciones.getNombreBeneficiario() != null && !StringUtils.EMPTY.equals(consultaOperaciones.getNombreBeneficiario())) {	
			query.append(someFilter ? "AND UPPER(PROD.BENEFICIARIO)  LIKE '%'" : "UPPER(PROD.BENEFICIARIO)  LIKE '%' ")
				.append(consultaOperaciones.getNombreBeneficiario()).append("'%'   ");
//			params.put("nombreBeneficiario", consultaOperaciones.getNombreBeneficiario());
			someFilter = true;
		}
		//Falta la parte de personalidad
//		if (consultaOperaciones.getPersonaAutorizada() != null && !StringUtils.EMPTY.equals(consultaOperaciones.getPersonaAutorizada())) {	
//			query.append(someFilter ? "AND UPPER(PROD.NOMB_PERS_AUT_EXT)  LIKE '%" : "UPPER(PROD.NOMB_PERS_AUT_EXT)  LIKE '%")
//				.append(consultaOperaciones.getPersonaAutorizada()).append("%' ");
//			someFilter = true;
//		}
		log.info("ID REG: " + consultaOperaciones.getIdReg());
		if (consultaOperaciones.getIdReg() != null && !StringUtils.EMPTY.equals(consultaOperaciones.getIdReg())) {		
			query.append(someFilter ? "AND PROD.ID_REG = " : "PROD.ID_REG = ").append(consultaOperaciones.getIdReg()).append(" ");
//			params.put("idReg", consultaOperaciones.getIdReg());
			someFilter = true;
		}
		
		if (consultaOperaciones.getNumEmpleado() != null && !StringUtils.EMPTY.equals(consultaOperaciones.getNumEmpleado())	&& !PROD_PROV_CONFIRMING.equals(consultaOperaciones.getIdProducto())) {		
			query.append(someFilter ? "AND TRIM(PROD.NUMERO_EMPLEADO) = " : "PROD.NUMERO_EMPLEADO = ").append(consultaOperaciones.getNumEmpleado()).append(" ");
//			params.put("numEmpleado", consultaOperaciones.getNumEmpleado());
			someFilter = true;
		}
		if (consultaOperaciones.getNumTarjeta() != null && !StringUtils.EMPTY.equals(consultaOperaciones.getNumTarjeta()) && !PROD_PROV_CONFIRMING.equals(consultaOperaciones.getIdProducto())) {		
			query.append(someFilter ? "AND TRIM(PROD.NUMERO_TARJETA) = " : "PROD.NUMERO_TARJETA = ").append(consultaOperaciones.getNumTarjeta()).append(" ");
//			params.put("numTarjeta", consultaOperaciones.getNumTarjeta());
			someFilter = true;
		}
		if (consultaOperaciones.getSucTutora() != null && !StringUtils.EMPTY.equals(consultaOperaciones.getSucTutora()) && !PROD_PROV_CONFIRMING.equals(consultaOperaciones.getIdProducto())) {		
			query.append(someFilter ? "AND TRIM(PROD.SUCURSAL_TUTORA) = " : "PROD.SUCURSAL_TUTORA = ").append(consultaOperaciones.getSucTutora()).append(" ");
//			params.put("sucTutora", consultaOperaciones.getSucTutora());
			someFilter = true;
		}
		if (consultaOperaciones.getTipo() != null && !CERO.equals(consultaOperaciones.getTipo())) {
			if ("PREEXISTENTE".equals(consultaOperaciones.getTipo())){
				query.append(someFilter ? "AND PROD.TIPO IS NOT NULL " : "PROD.TIPO IS NOT NULL ");
			} else {
				query.append(someFilter ? "AND PROD.TIPO IS NULL " : "PROD.TIPO IS NULL ");
			}
			someFilter = true;
		}
		//Esta parte es de PIF
		query.append(UtilOrdenesPagoAtmDatosExportarNew.agregaQueryPIF(query,consultaOperaciones,params,exportar));
		if(consultaOperaciones.isEsLiquidaciones()){
			query.append(" AND PROD.CVE_PROD_OPER in(21,23) ");
		}
		if(!"Todos".equals(consultaOperaciones.getHoraProgramacion()) && consultaOperaciones.getHoraProgramacion() != null
				 && !consultaOperaciones.getHoraProgramacion().isEmpty() ) {
			query.append("AND to_char(prod.HORA_APLI,'HH24:MI')= '")
			.append(consultaOperaciones.getHoraProgramacion())
			.append("' ");
		}
		// Validamos si se trata de exportar y el contenido de los filtros
		log.info(exportar + " - " + someFilter);
		if( exportar && !someFilter) {
			// Limpiamos los datos
			query.setLength(0);
			params = new HashMap<>();
			return "";
		}
//		querySQLOrigen.append( query.toString() );
		return query.toString();
	}
}
