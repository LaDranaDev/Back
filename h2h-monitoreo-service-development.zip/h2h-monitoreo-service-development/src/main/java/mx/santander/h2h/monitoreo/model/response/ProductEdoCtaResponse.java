package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * ProductEdoCtaResponse
 * Dtop para la respuesta del catalogo productos
 * 
 * @author Felipe Cazarez
 * @since 12/07/2022
 */
@Getter
@Setter
@NoArgsConstructor
public class ProductEdoCtaResponse implements Serializable{

	/**
	 * id serial
	 */
	private static final long serialVersionUID = 1106175691123187092L;
	/**
	 * Id del producto que se tiene asignado
	 */
	private Integer id;
	/**
	 * Clave del producto
	 */
	private String clave;
	/**
	 * Descripcion del producto que se esta utilizando
	 */
	private String descripcion;
	/**
	 * Define si el prodcuto va a manejar algun tipo de cargo
	 */
	private String aplicaTipoCargo;
	/**
	 * Define si en el producto aplica alguna vigencia
	 */
	private String aplicaVigencia;
	/**
	 * Define si en el producto se va a manejar el envio de email
	 */
	private String aplicaEmail;
	/**
	 * Define si el producto va a manejar reintentos
	 */
	private String aplicaReintentos;
	/**
	 * Numero de contrato
	 */
	private String numeroContrato;
	/**
	 * Indica si el producto fue asignado o no al contrato
	 */
	private String asignado;
	/**
	 * Indicador de si el producto se encuentra activo o no
	 */
	private String activo;
	/**
	 * Tipo de cargo que se va a menejar en el producto
	 */
	private String tipoCargo;
	/**
	 * Vigencia de una orden de pago
	 */
	private Integer vigencia;
	/**
	 * Indicador de si el producto va a permitir el envio de email
	 */
	private String envioEmail;
	/**
	 * Numero de reintentos permitidos para el producto
	 */
	private Integer numeroReintentos;
	/**
	 * Intervalo entre el numero de reintentos
	 */
	private Integer intervaloReintentos;
	/**
	 * Aplica contratos confirming
	 */
	private String aplicaContratoConfirming;
	/**
	 * Aplica contratos proveedor confirming
	 */
	private String aplicaContratoProvConfirming;
	/**
	 * Aplica contratos proveedor confirming
	 */
	/**
	 * Id de la relacion entre el Contrato y el Producto, viene de la tabla
	 * H2H_CNTR_PROD
	 */
	private int idContratoProducto;

}
