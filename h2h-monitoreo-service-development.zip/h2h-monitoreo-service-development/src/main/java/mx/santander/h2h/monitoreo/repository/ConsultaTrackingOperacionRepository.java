/**
* Santander SCIB - Banco Santander Negocios Globales
* Todos los derechos reservados
* ConsultaTrackingOperacionRepository.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <12 jul. 2024 20:00:19>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import mx.santander.h2h.monitoreo.commons.utils.ConsultaTrackingUtil;
import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import mx.santander.h2h.monitoreo.model.response.OperacionArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ProductoArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ResultTrackingResponse;
import mx.santander.h2h.monitoreo.util.UtilData;
import mx.santander.h2h.monitoreo.util.UtilMapeoData;

@Repository
public class ConsultaTrackingOperacionRepository implements IConsultaTrackingOperacionRepository {
	
	@Autowired
	private EntityManager entityManager;

	
	@Override
	public ResultTrackingResponse obtenerCatalogoEstatus(String tipoStatus) {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder = queryObtenerCatalogos();
		
		Query query = entityManager.createNativeQuery(queryBuilder.toString());
		setParamsObtenerCatalogos(tipoStatus, query);
		
		List<Object[]> resultQueryCatalogos = query.getResultList();
		
		List<ComboResponse> listCombo = new ArrayList<ComboResponse>();
		
		if (resultQueryCatalogos != null) {
			for (Object[] map : resultQueryCatalogos) {
				ComboResponse bean = new ComboResponse();
				bean.setId( UtilData.toInt(map[0]) );
				bean.setValor( UtilData.toString(map[1]) );
				listCombo.add(bean);
			}
		}
		
		resultTrackingResponse.setListCombo(listCombo);
		
		return resultTrackingResponse;
	}
	
	public StringBuilder queryObtenerCatalogos() {
		StringBuilder querySql = new StringBuilder()
				
		.append("SELECT ID_CAT_ESTATUS, DESC_ESTATUS ")
		.append("FROM H2H_CAT_ESTATUS ")
		.append("WHERE BAND_ACTIVO = 'A' ")
		.append("AND TIPO_ESTATUS = :tipoEstatus ")
		.append("ORDER BY DESC_ESTATUS ");
		
		return querySql;
	}
	
	public void setParamsObtenerCatalogos(String tipoEstatus, Query query) {
		query.setParameter("tipoEstatus", tipoEstatus);
	}

	@Override
	public ResultTrackingResponse obtenerConteoArchivo(String codCliente, Integer idArchivo, Integer idProducto, Integer idEstatus) {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder = queryObtenerConteoArchivos(idProducto, idEstatus);
		
		Query query = entityManager.createNativeQuery(queryBuilder.toString());
		this.setParamsObtenerConteoArchivos(codCliente, idArchivo, idProducto, idEstatus, query);
		
		List<Object[]> detalleArchivosResult = query.getResultList();
		
		ProductoArchivoResponse prdArchResponse = new ProductoArchivoResponse();
		
		if (detalleArchivosResult != null) {
			for (Object[] map : detalleArchivosResult) {
				prdArchResponse.setNombreArchivo( UtilData.toString(map[0]) );
				prdArchResponse.setFechaRecep( UtilData.toString(map[2]) );
				prdArchResponse.setEstatus( UtilData.toString(map[1]) );
				prdArchResponse.setTotalOperaciones( UtilData.toInt(map[3]) );
				prdArchResponse.setMonto( UtilData.toBigDecimal(map[4]) );
			}
		}
		
		resultTrackingResponse.setArchProd(prdArchResponse);
		
		return resultTrackingResponse;
	}
	
	
	
	public StringBuilder queryObtenerConteoArchivos(Integer idProducto, Integer idEstatus) {
		StringBuilder querySql = new StringBuilder()
				
			.append("SELECT A.NOMBRE_ARCH, B.DESC_ESTATUS AS DESC_ESTATUS, ")
			.append("TO_CHAR(A.FECHA_REGISTRO,'dd/mm/yyyy hh24:mi:ss') AS FECHA_ARCH, ")
			.append("count(*) AS NUM_OP, ")
			.append("SUM(mont) AS IMP_OP ")
			.append("FROM h2h_archivo_tran A, ")
			.append(" h2h_cat_estatus B,")
			.append(" h2h_cntr C,")
			.append(" h2h_clte D, ")
			.append(" h2h_reg_tran E, ")
			.append(" h2h_cat_prod F ")
			.append("WHERE B.id_cat_estatus = A.id_estatus ")
			.append(" and A.id_cntr = C.id_cntr ")
			.append(" and C.id_clte = D.id_clte ")
			.append(" and A.id_archivo = E.id_arch ")
			.append("and E.cve_prod_oper = F.cve_prod_oper ")
			.append("AND D.buc = :codCliente ")
			.append("AND A.ID_ARCHIVO = :idArchivo ");
			if (idProducto != null && idProducto > 0) {
				querySql.append(" AND F.id_prod = :idProducto ");
			}
			if (idEstatus != null && idEstatus > 0) {
				querySql.append(" and E.id_estatus = :idEstatus ");
			}
			querySql.append(" group by A.NOMBRE_ARCH, A.FECHA_REGISTRO, B.DESC_ESTATUS ");
		
		return querySql;
	}
	
	public void setParamsObtenerConteoArchivos(String codCliente, Integer idArchivo, Integer idProducto, Integer idEstatus, Query query) {
		query.setParameter("codCliente", codCliente);
		query.setParameter("idArchivo", idArchivo);
		if (idProducto != null && idProducto > 0) {
			query.setParameter("idProducto", idProducto);
		}
		if (idEstatus != null && idEstatus > 0) {
			query.setParameter("idEstatus", idEstatus);
		}
	}

	@Override
	public Page<OperacionArchivoResponse> obtenerDetalleArchivo(Pageable page, Integer idArchivo, Integer idProducto, Integer idEstatus) {

		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder = queryObtenerDetalleArchivos(idProducto, idEstatus);
		
		Query query = entityManager.createNativeQuery(queryBuilder.toString());
		this.setParamsObtenerDetalleArchivos(idArchivo, idProducto, idEstatus, query);
		
		query.setFirstResult(page.getPageNumber() * page.getPageSize());
		query.setMaxResults(page.getPageSize());
		
		List<Object[]> detalleArchivosResult = query.getResultList();
		
		List<OperacionArchivoResponse> lista = new ArrayList<OperacionArchivoResponse>();
		
		if (detalleArchivosResult != null) {
			for (Object[] map : detalleArchivosResult) {
				OperacionArchivoResponse bean = new OperacionArchivoResponse();
				bean.setIdReg( UtilData.toInt(map[0]) );
				bean.setStatusOpe( UtilData.toString(map[3]) );
				bean.setProducto( UtilData.toString(map[4]) );
				bean.setImporte( UtilData.toBigDecimal(map[5]) );
				bean.setCtaCargo( UtilData.toString(map[7]) );
				bean.setCtaAbono( UtilData.toString(map[6]) );
				// Enmascaramos la Cuenta
				bean.setCtaAbono(UtilMapeoData.getMascara(bean.getCtaAbono(), "abono"));
				
				bean.setReferenciaBE( UtilData.toString(map[1]) );
				bean.setFechaAplic( UtilData.toString(map[2]) );
				if(map[8] != null) {
					bean.setUmbr( UtilData.toString(map[8]) );
				}else {
					bean.setUmbr("");
				}
				bean.setFchEnvioBE( UtilData.toString(map[9]) );
				bean.setFchRespuestaBE( UtilData.toString(map[10]) );
				
				lista.add(bean);
			}
		}
		
		for (int i = 0; i < lista.size(); i++) {
			lista.get(i).setImporteFmt(ConsultaTrackingUtil.formateaImporteOperacion(lista.get(i).getImporte()));
        }
		
		query.setFirstResult(0);
		query.setMaxResults(Integer.MAX_VALUE);
		
		Integer totalRows = query.getResultList().size();
		return new PageImpl<>(lista, page, totalRows);
	}
	
	public StringBuilder queryObtenerDetalleArchivos(Integer idProducto, Integer idEstatus) {
		StringBuilder querySql = new StringBuilder()
				
		.append("SELECT A.id_reg, Refe_BE as cve_rastreo_spei, ")
		.append(" TO_CHAR(fech_apli,'dd/mm/yyyy') || ' '||  NVL(TO_CHAR(A.HORA_APLI, 'hh24:mi'),' ') AS FECHA_APLI, ")
		.append(" B.DESC_ESTATUS as desc_estatus, C.DESC_PROD, ")
		.append(" mont as IMPORTE, A.cnta_abon as cta_ben,  A.cnta_carg as cta_ord,  ")
		.append(" D.umbr, ")
		.append(" TO_CHAR( d.fech_envi_be,'dd/mm/yyyy hh24:mi:ss') AS fech_envi_be, ")
		.append(" TO_CHAR( d.fech_resp_be,'dd/mm/yyyy hh24:mi:ss') AS fech_resp_be ")
		.append("FROM h2h_reg_tran A, ")
		.append("h2h_cat_estatus B, ")
		.append("h2h_cat_prod C, ")
		.append(" h2h_arch_back_tran D  ")
		.append("WHERE B.id_cat_estatus = A.id_estatus " )
		.append(" and A.Cve_prod_oper = C.cve_prod_oper " )
		.append(" and A.id_arch_be = D.id_arch_back(+)  " )
		.append(" and A.id_arch = :idArchivo ");
		if (idProducto != null && idProducto > 0) {
			querySql.append("  and C.id_prod = :idProducto");
		}
		if (idEstatus != null && idEstatus > 0) {
			querySql.append(" and B.id_cat_estatus = :idEstatus");
		}		
		querySql.append(" ORDER BY  A.id_reg  ASC ");
		
		return querySql;
	}
	
	public void setParamsObtenerDetalleArchivos(Integer idArchivo, Integer idProducto, Integer idEstatus, Query query) {
		query.setParameter("idArchivo", idArchivo);
		if (idProducto != null && idProducto > 0) {
			query.setParameter("idProducto", idProducto);
		}
		if (idEstatus != null && idEstatus > 0) {
			query.setParameter("idEstatus", idEstatus);
		}
	}

	@Override
	public List<OperacionArchivoResponse> obtenerListDetalleArchivo(Integer idArchivo, Integer idProducto, Integer idEstatus) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder = queryObtenerDetalleArchivos(idProducto, idEstatus);
		
		Query query = entityManager.createNativeQuery(queryBuilder.toString());
		this.setParamsObtenerDetalleArchivos(idArchivo, idProducto, idEstatus, query);
		
		List<Object[]> detalleArchivosResult = query.getResultList();
		
		List<OperacionArchivoResponse> lista = new ArrayList<OperacionArchivoResponse>();
		
		if (detalleArchivosResult != null) {
			for (Object[] map : detalleArchivosResult) {
				OperacionArchivoResponse bean = new OperacionArchivoResponse();
				bean.setIdReg( UtilData.toInt(map[0]) ); 
				bean.setStatusOpe( UtilData.toString(map[3]) );
				bean.setProducto( UtilData.toString(map[4]) );
				bean.setImporte( UtilData.toBigDecimal(map[5]) );
				bean.setCtaCargo( UtilData.toString(map[7]) );
				bean.setCtaAbono( UtilData.toString(map[6]) );
				// Enmascaramos la Cuenta
				bean.setCtaAbono(UtilMapeoData.getMascara(bean.getCtaAbono(), "abono"));
				
				bean.setReferenciaBE( UtilData.toString(map[1]) );
				bean.setFechaAplic( UtilData.toString(map[2]) );
				if(map[8] != null) {
					bean.setUmbr( UtilData.toString(map[8]) );
				}else {
					bean.setUmbr("");
				}
				bean.setFchEnvioBE( UtilData.toString(map[9]) );
				bean.setFchRespuestaBE( UtilData.toString(map[10]) );
				lista.add(bean);
			}
		}
		
		for (int i = 0; i < lista.size(); i++) {
			lista.get(i).setImporteFmt(ConsultaTrackingUtil.formateaImporteOperacion(lista.get(i).getImporte()));
        }
		
		return lista;
	}

}
