package mx.santander.h2h.monitoreo.constants;


/**
 * MonitorOperacionesConstants.
 *
 * Define los valores constantes de el modulo.
 *
 * @author Omar Rosas
 * @since 31/08/2023
 */
public final class MonitorOperacionesConstants {
    
    /**  Constante DIVISA MXP. */
    public static final String MXP = "MXP";
    
    /**  Constante DIVISA MXN. */
    public static final String MXN = "MXN";
    
    /**  Constante DIVISA COD_DIVS_SAL. */
    public static final String MN = "MN";
    
    /**  Constante DIVISA CLAV_CAPTA. */
    public static final String USD = "USD";
    
    /** Importe. */
    public static final String IMPORTE = "IMPORTE";
    
    /**  Clave prod. */
    public static final String CVE_PROD_OPER = "CVE_PROD_OPER";
    
    /**  ID estatus. */
    public static final String ID_ESTATUS = "ID_ESTATUS";
    
    /**  Constante DIVISA COD_DIVS_SAL. */
    public static final String DL = "DL";
    
    /**  Constante CERO. */
    public static final String CERO = "0";
    
    /**  Constante producto proveedor confirming. */
    public static final String PROD_PROV_CONFIRMING = "11";
    
    public static final String SQLPROD1 = "SELECT DISTINCT PROD.VIST_PROD  FROM ( ";
    
    /**  SELECT prod. */
    public static final String SEL_PROD = "SELECT PROD.* FROM (";
    
    public static final String SQLPRODVIEW1 = " SELECT PROD.*, ROWNUM FROM ( "; 
    public static final String SQLUNIONALL = "UNION ALL ";
    
    /**  Tabla PROD. */
    public static final String TABLA_PROD = ") PROD ";
    public static final String TABLA_PROD2 = ") PRODUCTOS ";
    public static final String TABLA_PRODFIN = "ORDER BY PROD.ID_REG DESC ";
    
    /**  Tabla PROD. */
    public static final String TMP_DIVI = "TMP.DIVI DIVISA,";
    
	
    /**
	 * SELECT REG.ID_REG, REG.CVE_PROD_OPER, REG.CNTA_CARG, REG.CNTA_ABON,
	 * REG.REFE_BE, REG.ID_ESTATUS, REG.MONT
	 */
	public static final String SERCH_ARCH_TMP = "SELECT REG.ID_REG, REG.CVE_PROD_OPER, REG.CNTA_CARG, REG.CNTA_ABON, REG.REFE_BE, REG.ID_ESTATUS, REG.MONT, "
			+ "REG.FECH_APLI, REG.FECH_OPER, REG.FECH_ENVI_BACK, REG.ID_MSG, REG.DIVI, "
			+ "ARCH.FECHA_REGISTRO, ARCH.NOMBRE_ARCH, ARCH.ID_CNTR, CANL.NOMB_CANL ";
	
	/**  SELECT 'H2H_REG' TABLA,. */
	public static final String SELECT_H2H_REG_TABLA = "SELECT 'H2H_REG' TABLA, ";
	
	/**  SELECT 'H2H_REG_TRAN' TABLA,. */
	public static final String SELECT_H2H_REG_TRAN_TABLA = "SELECT 'H2H_REG_TRAN' TABLA, ";

	/** REG.ID_REG, CLTE.BUC, REG.CNTA_CARG NUM_CTA_CARGO, */
	public static final String REG_ID_REG_CLTE_BUC_REG_CNTA_CARG_NUM_CTA_CARGO = "REG.ID_REG, CLTE.BUC, REG.CNTA_CARG NUM_CTA_CARGO, ";
	/** REG.CNTA_ABON NUN_CTA_ABONO, CVE_PROD_OPER, PROD.DESC_PROD, **/
	public static final String REG_CNTA_ABON_NUN_CTA_ABONO_CVE_PROD_OPER_PROD_DESC_PROD = "REG.CNTA_ABON NUN_CTA_ABONO, PROD.CVE_PROD_OPER, PROD.DESC_PROD, ";
	/** REG.CNTA_ABON NUN_CTA_ABONO, CVE_PROD_OPER, PROD.DESC_PROD, **/
	public static final String ARCH_NOMBRE_ARCH_REG_REFE_BE_REFERENCIA_REG_ID_ESTATUS = "ARCH.NOMBRE_ARCH, DECODE( PROD.CVE_PROD_OPER,85 , DECODE(REG.REFE_BE,null,'' ,'****'|| SUBSTRB(REG.REFE_BE,-4,4)), REG.REFE_BE) REFERENCIA, REG.ID_ESTATUS, ";
	/** EST.DESC_ESTATUS, REG.MONT IMPORTE, CNTR.NUM_CNTR, REG.DIVI DIVISA, " */
	public static final String EST_DESC_ESTATUS_REG_MONT_IMPORTE_CNTR_NUM_CNTR_REG_DIVI_DIVISA = "EST.DESC_ESTATUS, REG.MONT IMPORTE, CNTR.NUM_CNTR, REG.DIVI DIVISA, ";
	/** INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS */
	public static final String INNER_JOIN_H2H_CAT_ESTATUS_EST_ON_REG_ID_ESTATUS_EST_ID_CAT_ESTATUS = "INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS ";
	
	/**  NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD,. */
	public static final String NULL_INTERMEDIARIO_ORD_NULL_DIVISA_ORD = "null INTERMEDIARIO_ORD, TMP.DIVI DIVISA_ORD, ";
	
	/**  NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD,. */
	public static final String PIF_INTERMEDIARIO_ORD_NULL_DIVISA_ORD = "DETA.OBSE_ABO INTERMEDIARIO_ORD, TMP.DIVI DIVISA_ORD, ";
	
	/**  NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD,. */
	public static final String NULL_INTERMEDIARIO_OTROSPROD = "NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD, ";
	
	/**  NULL INTERMEDIARIO_REC, NULL BENEFICIARIO,. */
	public static final String NULL_INTERMEDIARIO_REC_NULL_BENEFICIARIO = "MSG.MSG_H2H INTERMEDIARIO_REC, NULL BENEFICIARIO, ";
	
	/**  NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, *. */
	public static final String NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA = "NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, ";
	
	/**  NULL BUC_EMPLEADO,. */
	public static final String NULL_BUC_EMPLEADO = " NULL BUC_EMPLEADO, ";
	
	/**  "NULL SUCURSAL_TUTORA, NULL RFC, NULL TIPO, " *. */
	public static final String NULL_SUCURSAL_TUTORA_NULL_RFC_NULL_TIPO = "NULL SUCURSAL_TUTORA, NULL RFC, NULL TIPO, ";
	
	/**  NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, *. */
	public static final String NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA = "NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, ";
	/** MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, */
	public static final String MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN = "MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, ";
	
	/**  INNER JOIN H2H_CNTR CNTR USING (ID_CNTR). */
	public static final String INNER_JOIN_H2H_CNTR_CNTR_USING_ID_CNTR = " INNER JOIN H2H_CNTR CNTR USING (ID_CNTR) ";
	/** WHERE ((ARCH.FECHA_REGISTRO >= TO_DATE(' */
	public static final String WHERE_ARCH_FECHA_REGISTRO_TO_DATE = "WHERE ( TRUNC(ARCH.FECHA_REGISTRO) BETWEEN TO_DATE( ";
	
	/** * FORMATO_FECHA String. */
	public static final String FORMATO_FECHA = ", 'DD/MM/YYYY HH24:MI:SS'))) ";
	
	/** Formato para el rango de Fechas */
	public static final String CONS_RANGO_FECHA = "WHERE ((ARCH.FECHA_REGISTRO >= TO_DATE('";
	
	/**  Constante para definir la hora inicial de busqueda de un producto. */
	public static final String HORARIOINICIAL = " 00:00:00";
	
	/**  Constante para definir la hora final de busqueda de un producto. */
	public static final String HORARIOFINAL = " 23:59:59";
	
	public static final String H2H_REG_TABLE = "FROM H2H_REG REG ";
	
	public static final String H2H_REG_TRAN_TABLE = "FROM H2H_REG_TRAN REG ";
	
	/**  Tabla principal del producto. */
	public static final String SELECT_TABLA_REG = "H2H_MX_PROD_SPID";
	
	/**  Tabla Tran del producto *. */
	public static final String SELECT_TABLA_REG_TRAN = SELECT_TABLA_REG + "_TRAN";
	
	/**  tabla historica del producto *. */
	public static final String SELECT_TABLA_REG_HIST = SELECT_TABLA_REG + "_HIST";
	
	/** * inner Join con H2HCLTE usando IDCLTE. */
	public static final String INNER_JOIN_H2H_CLTE = "INNER JOIN H2H_CLTE CLTE USING (ID_CLTE) ";
	
	/** constante para el query de la obtencion del monitor de operaciones, en especifico el inner con CAT PROD PART_QUERY_SELECT_INNER_CAT_PROD. */
	public static final String PART_QUERY_SELECT_INNER_CAT_PROD = "INNER JOIN H2H_CAT_PROD PROD  ON PROD.CVE_PROD_OPER = REG.CVE_PROD_OPER ";
	
	/** Declaracion de Constante INNER_CAT_PROD. */
	public static final String INNER_CAT_PROD = "INNER JOIN H2H_CAT_PROD PROD USING(CVE_PROD_OPER) ";
	
	/** * inner Join con H2H_CAT_CANL usando id de canal en query. */
	public static final String INNER_JOIN_H2H_CAT_CANL = "INNER JOIN H2H_CAT_CANL CANL ON ARCH.ID_CANL = CANL.ID_CANL ";
	
	/** constante para la tabla de H2H_MX_PROD_TRAN_INTN. */
	public static final String H2H_MX_PROD_TRAN_INTN = "H2H_MX_PROD_TRAN_INTN";
	
	/** * parte de los queryes para obtener las operaciones PART_QUERY_SELECT_FECHA_REGISTRO_APLI_PROD. */
	public static final String PART_QUERY_SELECT_FECHA_REGISTRO_APLI_PROD = "ARCH.FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, REG.NUM_EMAIL, ";
    
    /** Declaracion de Constante H2H_PROD_TRAN. */
    public static final String H2H_PROD_TRAN = "H2H_PROD_TRAN";
    
    /** Declaracion de Constante IMP_RECEP. */
    public static  final String IMP_RECEP = "IMP_RECEP";
    /** Constante Banco. */
    public static final String BANCO = "BANCO SANTANDER (MÉXICO) S.A.";
    /** MonitorOperaciones. */
    public static final String MONITOR_OPER = "MonitorOperacionesDAOImpl";
    /** MON002. */
    public static final String MON002 ="MON002";
    /**  Codigo de operacion. */
    protected static final String OPERATION_CODE = "DetalleOperaciones";
    /**  Codigo de operacion. */
    public static final String HISTORIAL_CODE = "HistorialOperacion";
    /** REPROCESAR.*/
    public static final String REPROCESAR = "REPROCESAR";
    /** PROCESADO.*/
    public static final String PROCESADO = "PROCESADO";
    /**  Constante DEBUG_ERROR. */
    public static final String DEBUG_ERROR = "Consulta realizada con codigo de error: ";
    
    /**  Constante ERROR_NO_EXITO. */
    public static final String ERROR_NO_EXITO = "La consulta no fue realizada con exito: ";
    /** Constante de operacion en proceso. */
    public static final String OPERACION_EN_PROCESO = "OPERACION_EN_PROCESO";
    /**  Version serial de la clase. */
    public static final long serialVersionUID = 1L;
    /**REG.DIVI DIVISA**/
    public static final String REG_DIVI_DIVISA="REG.DIVI DIVISA,";
    /** NULL_REFERENCIA_ABONO_NULL_REFERENCIA_CARGO*. */
    public static final String NULL_REFERENCIA_ABONO_NULL_REFERENCIA_CARGO="NULL REFERENCIA_ABONO, NULL REFERENCIA_CARGO, ";
    /** private NULL COMENTARIO_1, NULL COMENTARIO_2, *. */
    public static final String NULL_COMENTARIO_1_NULL_COMENTARIO_2="NULL COMENTARIO_1, NULL COMENTARIO_2, ";
    /** NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO, *. */
    public static final String NULL_TIPO_PAGO_NULL_MODALIDAD_NULL_IMPORTE_CARGO="NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO, ";
    /** NULL SUCURSAL_TUTORA, NULL RFC,. */
    public static final String NULL_SUCURSAL_TUTORA_NULL_RFC="NULL SUCURSAL_TUTORA, NULL RFC, ";
    /** NULL DESCRIPCION,. */
    public static final String NULL_DESCRIPCION="NULL DESCRIPCION, ";
    /** constante para nombre de empleado. */
    public static final String NOMBRE_EMPLEADO="NOMBRE_EMPLEADO";
    /** String FECHA. */
    public static final String FECHA = "FECHA";
    /** String UPDATE. */
    public static final String UPDATE = "UPDATE ";
    /** String SET_ESTATUS_REPROCESAR. */
    public static final String SET_ESTATUS_REPROCESAR = " SET ID_ESTATUS =  ( SELECT DECODE(ID_ESTATUS,7,8,81,82,ID_ESTATUS) FROM H2H_REG_TRAN WHERE ID_REG = ";
    
    /** String SET_ESTATUS. */
    public static final String SET_ESTATUS = " SET ID_ESTATUS = (SELECT ID_CAT_ESTATUS FROM H2H_CAT_ESTATUS";
    
    
    /** Declaracion de Constante WHERE_DESC. */
    public static final String WHERE_DESC = " WHERE DESC_ESTATUS LIKE ";
    
    
    /** Declaracion de Constante WHERE_ID_REG. */
    public static final String WHERE_ID_REG = " WHERE ID_REG = ";
    
    /** String IMPORTE_CARGO. */
    public static final String IMPORTE_CARGO = "IMPORTE_CARGO";
    
    /** String UNION_ALL. */
    public static final String UNION_ALL = " UNION ALL ";
    
    /** String NULL_COMENTARIO. */
    public static final String NULL_COMENTARIO = "NULL COMENTARIO_3, NULL TITULAR, NULL BANCO_RECEPTOR, ";
    
    /** String FECHA_LIMITE. */
    public static final String FECHA_LIMITE = "NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, NULL FECH_VENC, ";
    
    /** String LEFT_JOIN_CONS. */
    public static final String LEFT_JOIN_CONS = "LEFT JOIN H2H_CTA_INFO CNTA_ABON ON REG.CNTA_ABON = CNTA_ABON.NUME_CTA AND CNTA_ABON.TIPO_CTA = 'B' ";
    /** String LEFT_JOIN_CONS_DOS. */
    public static final String LEFT_JOIN_CONS_DOS = "LEFT JOIN H2H_CTA_INFO CNTA_CARG ON REG.CNTA_CARG = CNTA_CARG.NUME_CTA AND CNTA_CARG.TIPO_CTA = 'O' ";
    /** String LEFT_JOIN_CONS_TRES. */
    public static final String LEFT_JOIN_CONS_TRES = "LEFT JOIN H2H_CAT_DIVISA DIVI_ABON ON DIVI_ABON.ID_CAT_DIVISA = CNTA_ABON.ID_CAT_DIVISA ";
    /** String LEFT_JOIN_CONS_CUATRO. */
    public static final String LEFT_JOIN_CONS_CUATRO = "LEFT JOIN H2H_CAT_DIVISA DIVI_CARG ON DIVI_CARG.ID_CAT_DIVISA = CNTA_CARG.ID_CAT_DIVISA ";
    /** String ID_MSG. */
    public static final String ID_MSG = "2623";
    
    /**  DESC_ERROR. */
    public static final String DESC_ERROR = "DESC_ERR";
        
    /**  DESC_ERROR. */
    public static final String CLVE_CONV = "CLVE_CONV";

    /** Parte de consulta de Monitor de Operaciones*/
    public static final String SQL_MON_OPER1 = " REG.ID_REG, CLTE.BUC, REG.CNTA_CARG NUM_CTA_CARGO, "
		+ "REG.CNTA_ABON NUN_CTA_ABONO, PROD.CVE_PROD_OPER, PROD.DESC_PROD, "
		+ "ARCH.NOMBRE_ARCH, REG.REFE_BE REFERENCIA, REG.ID_ESTATUS, "
		+ "EST.DESC_ESTATUS, REG.MONT IMPORTE, CNTR.NUM_CNTR, REG.DIVI DIVISA, "
		+ "ARCH.FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, REG.NUM_EMAIL, PIF.OBSE_ABO";
	
    public static final String SQL_MON_OPER2 = "REG.ID_REG, CLTE.BUC, REG.CNTA_CARG NUM_CTA_CARGO, "
    	+ "REG.CNTA_ABON NUN_CTA_ABONO, PROD.CVE_PROD_OPER, PROD.DESC_PROD, "
    	+ "ARCH.NOMBRE_ARCH, REG.REFE_BE REFERENCIA, REG.ID_ESTATUS, "
    	+ "EST.DESC_ESTATUS, REG.MONT IMPORTE, CNTR.NUM_CNTR, REG.DIVI DIVISA, "
    	+ "ARCH.FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, REG.NUM_EMAIL, "
    	+ "CANL.NOMB_CANL, PAGO.NUM_ORDEN, PAGO.NOMB_BENE BENEFICIARIO ";

    public static final String SQL_MON_OPER3 = "REG.ID_REG, CLTE.BUC, REG.CNTA_CARG NUM_CTA_CARGO, "
    	+ "REG.CNTA_ABON NUN_CTA_ABONO, CVE_PROD_OPER, PROD.DESC_PROD, "
    	+ "ARCH.NOMBRE_ARCH, REG.REFE_BE REFERENCIA, REG.ID_ESTATUS, "
    	+ "EST.DESC_ESTATUS, REG.MONT IMPORTE, CNTR.NUM_CNTR, REG.DIVI DIVISA, "
    	+ "ARCH.FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, REG.NUM_EMAIL, EMPL.NUME_CTA TIPO, "
    	+ "EMPL.NUME_EMPL NUMERO_EMPLEADO, EMPL.NUME_TARJ_NUEV NUMERO_TARJETA, "
		+ "EMPL.NUME_BUC_EMPL BUC_EMPLEADO, EMPL.SUCU_TUTO SUCURSAL_TUTORA, CANL.NOMB_CANL ";
    
    public static final String SQL_MON_OPER4 = "REG.ID_REG, CLTE.BUC, REG.CNTA_CARG NUM_CTA_CARGO, "
    	+ "REG.CNTA_ABON NUN_CTA_ABONO, CVE_PROD_OPER, PROD.DESC_PROD, "
    	+ "ARCH.NOMBRE_ARCH, REG.REFE_BE REFERENCIA, REG.ID_ESTATUS, "
    	+ "EST.DESC_ESTATUS, REG.MONT IMPORTE, CNTR.NUM_CNTR, REG.DIVI DIVISA, "
    	+ "ARCH.FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, REG.NUM_EMAIL, "
    	+ "CANL.NOMB_CANL ";
    
    /** Inner de Consulta Monitoreo */
    public static final String INNER_CLTE = "INNER JOIN H2H_CLTE CLTE USING (ID_CLTE) "
		+ "INNER JOIN H2H_CAT_PROD PROD ON PROD.CVE_PROD_OPER=REG.CVE_PROD_OPER "
		+ "INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS "
		+ "INNER JOIN H2H_CAT_CANL CANL ON ARCH.ID_CANL = CANL.ID_CANL ";
    
    /** Parte de consulta de Monitor de Operaciones*/
    public static final String INNER_CLTE2 = "INNER JOIN H2H_CNTR CNTR USING (ID_CNTR) "
			+ "INNER JOIN H2H_CLTE CLTE USING (ID_CLTE) "
			+ "INNER JOIN H2H_CAT_PROD PROD USING(CVE_PROD_OPER) "
			+ "INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS "
			+ "INNER JOIN H2H_CAT_CANL CANL ON ARCH.ID_CANL = CANL.ID_CANL ";
    
    
    /**
     * Constructor privado.
     */
    private  MonitorOperacionesConstants() {

    }
}
