package mx.santander.h2h.monitoreo.service;

import java.util.List;

import mx.santander.h2h.monitoreo.model.response.ComboDosResponse;
import mx.santander.h2h.monitoreo.model.response.ComboResponse;

/**
 * Interface IMonitorArchivosEnCursoComplementService
 * con los metodos para obtener catalogos
 */
public interface IMonitorArchivosEnCursoComplementService {

	/**
	 * Obtiene Catalogo de Producto
	 * @return List<ComboDosResponse>
	 */
	List<ComboDosResponse> obtenerCatalogoProducto();

	/**
	 * Obtiene le catalogo de estatus
	 * @return List<ComboResponse>
	 */
	List<ComboResponse> obtenerCatalogoEstatus();

	/**
	 * Obtiene el catalogo de Productos Prod
	 * @return List<ComboResponse>
	 */
	List<ComboResponse> obtenerCatalogoProductoProd();

	/**
	 * Obtiene el catalogo de estatus Prod
	 * @return List<ComboResponse>
	 */
	List<ComboResponse> obtenerCatalogoEstatusProd();
}
