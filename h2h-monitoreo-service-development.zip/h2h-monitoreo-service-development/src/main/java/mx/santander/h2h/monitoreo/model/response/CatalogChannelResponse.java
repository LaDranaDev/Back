package mx.santander.h2h.monitoreo.model.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * Salida para el catalogo de canales..
 *
 * @author Felipe Monzon
 * @since 13/05/2022
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
public class CatalogChannelResponse implements Serializable {
	/**
	 * serial.
	 */
	private static final long serialVersionUID = -5780211849022061067L;
	/**
	 * Identificador del canal.
	 */
	private Integer idChannel;
	/**
	 * Nombre del canal.
	 */
	private String name;
	/**
	 * Descripcion del canal.
	 */
	private String description;
	/**
	 * status del canal.
	 */
	private String status;
}
