package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.constants.MonitorOperacionesRoutesConstants;
import mx.santander.h2h.monitoreo.repository.IParameterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * OperationsMonitorRedirectService.
 * Servicio que sirve para enrutar a la vista de detalle deacuerdo el producto.
 *
 * @author Jesus Soto Aguilar
 * @since 07/07/2023
 */
@Service
public class OperationsMonitorRedirectService implements IOperationsMonitorRedirectService{

    /**
     * Repositorio para obtener informacion de los parametros.
     */
    @Autowired
    private IParameterRepository parameterRepository;

    /**
     * Obtiene el identificador de la vista en la que se mostrara el detalle.
     *
     * @param idProducto identificador del producto
     * @return identificador de la vista
     */
    public String getNameRutaDetalle(String idProducto) {
        String ruta = "";

        ruta = getRutaIdProductoCondition(idProducto);
        if(!ruta.isEmpty()){
            return ruta;
        }

        ruta = getRutaParamCondition(idProducto);
        if(!ruta.isEmpty()){
            return ruta;
        }

        return MonitorOperacionesRoutesConstants.URL_DETALLE;
    }

    /**
     * Obtiene la vista en base a los valores de los parametros.
     *
     * @param idProducto Identificador del producto
     * @return identificador de la vista
     */
    private String getRutaParamCondition(String idProducto) {
        String ruta = "";
        if(idProducto.equals(getValorParametro("CVE_OPER_PROD_DOMIS")) || "29".equals(idProducto)) {
            ruta = MonitorOperacionesRoutesConstants.URL_DETALLE_DOMIS;
        }else if (idProducto.equals(getValorParametro("CVE_OPER_PROD_MT_CNF"))) {
            ruta =  MonitorOperacionesRoutesConstants.URL_DETALLE_CNF;
        }else if (idProducto.equals(getValorParametro("CVE_OPER_PROD_I_FED"))) {
            ruta =  MonitorOperacionesRoutesConstants.URL_DETALLE_IMP_FED;
        }else if (idProducto.equals(getValorParametro("CVE_OPER_PROD_P_REF"))) {
            ruta =  MonitorOperacionesRoutesConstants.URL_DETALLE_PAG_REF;
        } else if (idProducto.equals(getValorParametro("CVE_OPER_PROD_A_PATR"))) {
            ruta =  MonitorOperacionesRoutesConstants.URL_DETALLE_APOR_PATR;
        } else if (idProducto.equals(getValorParametro("CVE_OP_PROD_TRAN_INT"))) {
            ruta =  MonitorOperacionesRoutesConstants.URL_DETALLE_TRANSFERENCIAS;
        } else if (idProducto.equals(getValorParametro("CVE_OP_PROD_TRAN_MMB"))) {
            ruta =  MonitorOperacionesRoutesConstants.URL_DETALLE_TRANSFERENCIAS;
        } else if (idProducto.equals(getValorParametro("CVE_OP_PROD_SPID"))) {
            ruta =  MonitorOperacionesRoutesConstants.URL_DETALLE_SPID;
        } else if (idProducto.equals(getValorParametro("CVE_PROD_PAG_DIRE"))) {
            ruta =  MonitorOperacionesRoutesConstants.URL_DETALLE_PD;
        }

        return ruta;
    }

    /**
     * Obtiene la vista deacuerdo al id del producto.
     *
     * @param idProducto Identificador del producto.
     * @return identificador de la vista.
     */
    private String getRutaIdProductoCondition(String idProducto) {
        String ruta = "";
        if (idProducto.equals("80")) {
            ruta = MonitorOperacionesRoutesConstants.URL_DETALLE_ORDEN_PAGO;
        } else if (idProducto.equals("93")) {
            ruta = MonitorOperacionesRoutesConstants.URL_DETALLE_ALTA_MASIVA;
        }else if (idProducto.equals("54")) {
            ruta = MonitorOperacionesRoutesConstants.URL_DETALLE_TARJ_PROP;
        } else if("21".equals(idProducto) || "22".equals(idProducto) || "23".equals(idProducto)) {
            ruta = MonitorOperacionesRoutesConstants.URL_DETALLE_PIF;
        } else if ("85".equals(idProducto)) {
            ruta = MonitorOperacionesRoutesConstants.OrdPagAtm;
        } else if ("25".equals(idProducto)) {
            ruta = MonitorOperacionesRoutesConstants.PagImpAdua;
        }

        return ruta;
    }

    /**
     * Obtiene el valor del parametro por nombre.
     *
     * @param nombreParametro nombre del parametro a buscar
     * @return valor del parametro
     */
    private String getValorParametro(String nombreParametro){
        return parameterRepository.findByName(nombreParametro).getValue();
    }
}
