package mx.santander.h2h.monitoreo.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersControllerResponse;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersDtoResponse;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersTotalResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsHistoryResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;

public interface IGenerateVouchersService {

	GenerateVouchersControllerResponse findVouchersCdmx();

	GenerateVouchersControllerResponse findOperationsMonitor(
			OperationsMonitorQueryRequest operationsMonitorQueryRequest, Pageable pageable);

	GenerateVouchersTotalResponse findTotal(OperationsMonitorQueryRequest operationsMonitorQueryRequest);

	Page<OperationsMonitorQueryResponse> paginarOperaciones(OperationsMonitorQueryRequest operationsMonitorQueryRequest,
			Pageable pageable);

	GenerateVouchersControllerResponse detalleOperaciones(
			OperationsMonitorQueryResponse operationsMonitorQueryResponse);

	List<OperationsHistoryResponse> historialOperaciones(String idOperacion);

	GenerateVouchersDtoResponse conceptoValor(String lineaCaptura);

}
