package mx.santander.h2h.monitoreo.util;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.persistence.Tuple;

import org.apache.commons.lang.ObjectUtils;

import mx.santander.h2h.monitoreo.model.response.ComprobantesOperacionResponse;

/**
 * @author fespinosa
 * utileria para obtener los queryes de
 * vostro y transaferencias internacionales
 * intercambiarias
 */
public class UtilVostroComprobantes {
    /**constante parala
     * cadena de
     *   UNION ALL
     **/
    protected static final String UNION_ALL=" UNION ALL ";
    /**
     * Constante para la tabla
     * de H2H_MX_PROD_TVIB
     * de tipo String
     */
    private static final String H2H_PROD_TVIB="H2H_MX_PROD_TVIB";
    /**
     * Constante  para los datos
     * del query principal
     * en este viene el dato de estatus
     * de movimiento
     */
    protected static final String QRY_PART_ESTATUS_MOV="null CVE_FORM_PAGO,'-'||trim(ct.CVE_PROD_OPER)||'-' ESTATUS_MOV,null NUM_ORDEN,null FECHA_LIMITE_PAGO,null NUM_SUCURSAL,";
    /**
     * CAMPOS_QUERY_TRAN_INT_CAM
     * query para obtener los datos
     * del comprobante de
     * Transferencias Internacionales
     * Cambiarias
     *
     */
    private static final String CAMPOS_QUERY_TRAN_INT_CAM="SELECT tranin.ID_REG ID_REG, cntr.NUM_CNTR CONTRATO, to_char(tranin.NUM_CTA_ORD) NUM_CTA_CARGO,tranin.NUM_CTA_BENE NUN_CTA_ABONO,ct.DESC_PROD DESC_PROD," +
            "tranin.IMP_ABONO_BENE IMPORTE,to_char(tranin.TXT_REF_NUME) REFERENCIA,tranin.COD_DIV_CTA_ORD DIVISA,ce.DESC_ESTATUS DESC_ESTATUS,to_char(tranin.FECH_APLI_PROC,'dd/mm/yyyy hh24:mi:ss')  FECH_APLI," +
            "null BENEFICIARIO,null TIPO_PAGO, tranin.TXT_NOM_ORD TITULAR,tranin.TXT_REF_LEYE_ORD CONCEPTO_PAGO,to_char(tranin.NUM_TIPO_CAMBIO) CLAVE_RASTREO," +
            "tranin.TXT_NOM_BCO_PAG BANCO_RECEPTOR,r.FECH_ENVI_BACK FECHA_OPERACION,null CLAV_PROV,null NUM_DOCU,null FECH_VENCIMIENTO," +
            QRY_PART_ESTATUS_MOV +
            "tranin.TXT_RFC_BENE  RAZON_SCIA, tranin.TXT_NOM_BENE NOM_CLTE,clte.PERSONALIDAD, clte.RFC,cntr.NUM_CNTR,tranin.TXT_CIUD_BENE CLAVE_BENEF,"+
            "null ID_ESTA,clte.BUC PERS_AUT,tranin.COD_PAIS_BENE FORM_APLI, null NOMB_RAZON_SOCI_PROV, DECODE(clte.PERSONALIDAD,'F',clte.NOMBRE  || ' '  || clte.APPATERNO  || ' '  || clte.APMATERNO,clte.RAZON_SCIA) RFC_PROV, "+
            "null BANC_ABON,tranin.TXT_REF REFE_ABON,tranin.COD_DIV_CTA_BENE TIPO_DOCU";

    /**
     * CAMPOS_QUERY_VOSTRO_INT
     * query para obtener los datos
     * del comprobante de
     * Transferencias Vostro
     * Interbancarias
     *
     */
    private static final String CAMPOS_QUERY_VOSTRO_INT="SELECT tranin.ID_REG ID_REG, cntr.NUM_CNTR CONTRATO, to_char(tranin.NUM_CTA_ORD) NUM_CTA_CARGO,tranin.NUM_CTA_VOS NUN_CTA_ABONO,ct.DESC_PROD DESC_PROD,"+
            "tranin.IMP_ABONO_BENE IMPORTE,to_char(tranin.TXT_REFE_OUT) REFERENCIA,tranin.COD_DIV_CTA_BENE DIVISA,ce.DESC_ESTATUS DESC_ESTATUS,to_char(decode(tranin.FCH_ACEP_TRFR_OUT,null,tranin.FCH_APRO,tranin.FCH_ACEP_TRFR_OUT),'dd/mm/yyyy hh24:mi:ss')  FECH_APLI,"+
            "tranin.TXT_NOM_BENE BENEFICIARIO,null TIPO_PAGO, tranin.TXT_NOM_ORD TITULAR,to_char(tranin.TXT_REF_LEYE_ORD) CONCEPTO_PAGO,null CLAVE_RASTREO,"+
            "banc.NOMBRE_BANCO BANCO_RECEPTOR,r.FECH_ENVI_BACK FECHA_OPERACION,null CLAV_PROV,tranin.NUM_CTA_BENE NUM_DOCU,null FECH_VENCIMIENTO,"+
            QRY_PART_ESTATUS_MOV+
            "tranin.TXT_RFC_BENE  RAZON_SCIA, tranin.TXT_NOM_BCO_PAG NOM_CLTE,clte.PERSONALIDAD, clte.RFC,cntr.NUM_CNTR,tranin.TXT_CIUD_BENE CLAVE_BENEF,"+
            "null ID_ESTA,clte.BUC PERS_AUT,tranin.COD_PAIS_BENE FORM_APLI, null NOMB_RAZON_SOCI_PROV, DECODE(clte.PERSONALIDAD,'F',clte.NOMBRE  || ' '  || clte.APPATERNO  || ' '  || clte.APMATERNO,clte.RAZON_SCIA) RFC_PROV, "+
            "null BANC_ABON,tranin.TXT_REFE_ENVI_OUT REFE_ABON,tranin.COD_DIV_CTA_BENE TIPO_DOCU";

    /**
     * CAMPOS_QUERY_VOSTRO_INT
     * query para obtener los datos
     * del comprobante de
     * Transferencias Vostro
     * Mismo Banco
     *
     */
    private static final String CAMPOS_QUERY_VOSTRO_TMB="SELECT tranin.ID_REG ID_REG, cntr.NUM_CNTR CONTRATO, to_char(tranin.NUM_CTA_ORD) NUM_CTA_CARGO,tranin.NUM_CTA_VOS NUN_CTA_ABONO,ct.DESC_PROD DESC_PROD,"+
            "tranin.IMP_MONTO_OPER IMPORTE,to_char(tranin.REFE_SAF) REFERENCIA,tranin.COD_DIVI_ABON DIVISA,ce.DESC_ESTATUS DESC_ESTATUS,to_char(tranin.FECH_APLI_PROC,'dd/mm/yyyy hh24:mi:ss')  FECH_APLI,"+
            "tranin.TXT_NOM_BEN_FIN BENEFICIARIO,null TIPO_PAGO, tranin.TXT_NOMB_ORDE TITULAR,tranin.REFE_LEYE_ORDE CONCEPTO_PAGO,null CLAVE_RASTREO,"+
            "null BANCO_RECEPTOR,r.FECH_ENVI_BACK FECHA_OPERACION,null CLAV_PROV,tranin.NUM_CTA_BENE_FIN NUM_DOCU,null FECH_VENCIMIENTO,"+
            QRY_PART_ESTATUS_MOV+
            "tranin.RFC_BENE_FIN  RAZON_SCIA, tranin.CUENTA_ID_BANCO NOM_CLTE,clte.PERSONALIDAD, clte.RFC,cntr.NUM_CNTR,tranin.CIUD_BENEF CLAVE_BENEF,"+
            "null ID_ESTA,clte.BUC PERS_AUT,tranin.PAIS_BENEF FORM_APLI, null NOMB_RAZON_SOCI_PROV, DECODE(clte.PERSONALIDAD,'F',clte.NOMBRE  || ' '  || clte.APPATERNO  || ' '  || clte.APMATERNO,clte.RAZON_SCIA) RFC_PROV, "+
            "null BANC_ABON,null REFE_ABON,null TIPO_DOCU";
    /**
     * Mapa para contener los diferentes queryes dependiendo
     * los productos segun la tabla enviada
     */
    private static Map<String, String> campos= new HashMap<String, String>();
    /**
     * constante para el FROM
     * de los comprobantes del
     * Producto de operaciones de
     * Vostro
     */
    private static final String FROM_QUERY_PARAM_VOSTRO=" FROM %s%s tranin"+
            " INNER JOIN H2H_REG%s r ON r.id_reg = tranin.id_reg"+
            " INNER JOIN H2H_CAT_PROD ct ON r.cve_prod_oper = ct.cve_prod_oper"+
            " INNER JOIN H2H_ARCHIVO%s a ON r.id_arch = a.id_archivo"+
            " INNER JOIN H2H_CNTR cntr ON cntr.id_cntr = a.id_cntr"+
            " INNER JOIN H2H_CLTE clte ON cntr.id_clte = clte.id_clte"+
            " LEFT JOIN H2H_CAT_ESTATUS ce ON ce.id_CAT_estatus = r.id_estatus %s"
            ;
    /**
     * constante para
     * agregar al query
     * principal
     * la tabla de TRAN
     */
    protected static final String TRAN_GUION="_TRAN";

    /**constructor**/
    protected UtilVostroComprobantes() {
        throw new UnsupportedOperationException("No instanciar la clase");
    }

    /**
     * Obtiene el query de Transferencias Internacionales.
     *
     * @param listIds  List<Integer>
     * @param tabla tabla para obtener query
     * @param sqlstr sql a modificar
     * @return String query
     */
    static String obtenerQuerys(List<Integer> listIds, String tabla, String sqlstr) {
        if(validaProductos(tabla)){
            String banco=getBancoTabla(tabla);
            final StringBuilder sql = new StringBuilder();
            sql.append(campos.get(tabla));
            sql.append(String.format(sies32(FROM_QUERY_PARAM_VOSTRO,tabla),elimina32(tabla),"","","",banco));
            agregaIdRegAwhere(listIds, sql);
            sql.append(UNION_ALL);
            sql.append(campos.get(tabla));
            sql.append(String.format(sies32(FROM_QUERY_PARAM_VOSTRO,tabla),elimina32(tabla),TRAN_GUION,TRAN_GUION,TRAN_GUION,banco));
            agregaIdRegAwhere(listIds, sql);
            return sql.toString();
        }else{
            return sqlstr;
        }

    }
    /**
     * sies32
     * @param fromQueryParamVostro
     * @param tabla
     * @return query
     */
    private static String sies32(String fromQueryParamVostro,String tabla) {
        String query=fromQueryParamVostro;
        if(tabla.contains("_32")){
            query=fromQueryParamVostro.replace(" INNER JOIN H2H_REG%s r ON r.id_reg = tranin.id_reg",
                    " INNER JOIN H2H_REG%s r ON r.id_reg = tranin.id_reg and tranin.cod_Prod='32' ");
        }
        return query;
    }
    /***
     * elimina32(String)
     * @param tabla
     * @return
     */
    private static Object elimina32(String tabla) {
        String tablaIn=tabla;
        if(tablaIn.contains("_32")){
            tablaIn=tabla.replace("_32", "");
        }
        return tablaIn;
    }

    /**
     * metodo para traer
     * y agregar al query
     * la tabla de bancos
     * solo si es
     * de transfrencias
     * Vostro internacionales
     * 29/08/2025 LFER se modifica por Clave banco en vez de bic para traer el banco
     * @param tabla
     * @return
     */
    private static String getBancoTabla(String tabla) {
        if(H2H_PROD_TVIB.equals(tabla)){
            return " left join H2H_CAT_BNCO banc on tranin.COD_INT_REC=banc.CLAVE_BANCO and banc.band_activo=1 ";
        }
        return "";
    }

    /**
     * validaProductos del tipo
     * vostro o
     * internacionales
     * cambiarias
     * @param tabla
     * @return
     */
    private static boolean validaProductos(String tabla) {

        return "H2H_MX_PROD_TRAN_INTN_32".equals(tabla) ||
                H2H_PROD_TVIB.equals(tabla) ||
                "H2H_MX_PROD_TVMB".equals(tabla);

    }

    /**
     * inicializacion del mapa de productos
     * LFER 09-03-2018
     */
    static{
        campos.put("H2H_MX_PROD_TRAN_INTN_32", CAMPOS_QUERY_TRAN_INT_CAM);
        campos.put(H2H_PROD_TVIB, CAMPOS_QUERY_VOSTRO_INT);
        campos.put("H2H_MX_PROD_TVMB", CAMPOS_QUERY_VOSTRO_TMB);
    }
    /**
     * Agrega id's reg.
     *
     * @param listIdsReg
     *            List<Integer>
     * @param sql
     *            StringBuilder
     */
    protected static void agregaIdRegAwhere(List<Integer> listIdsReg, StringBuilder sql) {
        if (listIdsReg != null && !listIdsReg.isEmpty() && sql != null) {
            int l = 0;
            for (Integer idReg : listIdsReg) {
                if (l == 0) {
                    sql.append(" WHERE ( r.id_reg = ").append(idReg);
                } else {
                    sql.append(" OR r.id_reg = ").append(idReg);
                }
                l++;
            }
            sql.append(" ) ");
        }
    }

    /**
     * esVostro 32,38,39
     * @param codCveProd
     * @return
     */
    public static boolean esVostro(String codCveProd) {

        return "-32-".equals(codCveProd) || "-38-".equals(codCveProd)|| "-39-".equals(codCveProd);
    }
    
    /**
	 * Metodo para realizar el
	 * llenado de datos 
	 * para los comprobantes de
	 * los nuevos 
	 * productos.
	 * @param bean
	 * @param map
	 */
	public static void llenaProductosCBF2(ComprobantesOperacionResponse bean,
			Tuple map) {
		//Formateo de importe
		if(esVostro(ObjectUtils.toString(map.get("ESTATUS_MOV")))){
			bean.setContrato(ObjectUtils.toString(map.get("CONTRATO")));
			bean.setNoDocu(ObjectUtils.toString(map.get("PERS_AUT")));
			bean.setRfc(ObjectUtils.toString(map.get("RFC_PROV")));
			bean.setFechaAplic(ObjectUtils.toString(map.get("FECH_APLI")));
			bean.setRefInterbancaria(ObjectUtils.toString(map.get("REFERENCIA")));
			bean.setEstatusMov(ObjectUtils.toString(map.get("REFE_ABON")));
			bean.setConceptoPago(ObjectUtils.toString(map.get("CONCEPTO_PAGO")));
			bean.setCuentaCargo(ObjectUtils.toString(map.get("NUM_CTA_CARGO")));
			bean.setTitular(ObjectUtils.toString(map.get("TITULAR")));
			bean.setCuentaAbono(ObjectUtils.toString(map.get("NUN_CTA_ABONO")));
			// Enmascaramos la cuenta Abono
			bean.setCuentaAbono(UtilMapeoData.getMascara(bean.getCuentaAbono(), "abono"));
			
			bean.setCveProveedor(ObjectUtils.toString(map.get("NOM_CLTE")));
			bean.setRazonSocial(ObjectUtils.toString(map.get("RAZON_SCIA")));
			bean.setBanco(ObjectUtils.toString(map.get("BANCO_RECEPTOR")));
			bean.setFormaAplic(ObjectUtils.toString(map.get("FORM_APLI")));
			bean.setCveBenef(ObjectUtils.toString(map.get("CLAVE_BENEF")));
			bean.setDivisa(ObjectUtils.toString(map.get("DIVISA")));
			bean.setTipoDoc(ObjectUtils.toString(map.get("TIPO_DOCU")));
			final String impFormat = "$"+ new DecimalFormat().format(map.get("IMPORTE"));
			bean.setImporte(impFormat);
			bean.setNumOrden(ObjectUtils.toString(map.get("NUM_DOCU")));
			bean.setBeneficiario(ObjectUtils.toString(map.get("BENEFICIARIO")));
			bean.setTipoOper(ObjectUtils.toString(map.get("ESTATUS_MOV")));
		}
		
	}
}
