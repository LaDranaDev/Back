package mx.santander.h2h.monitoreo.model.request;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Objeto que almacena los datos para guardar la información PUT y GET
 * @author sbautish
 *
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
public class PutGetSaveRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2999661607178852786L;

	/**
	 * directorioPut
	 */
	private String directorioPut;

	/**
	 * directorioGet
	 */
	private String directorioGet;

	/**
	 * puertoPutGet
	 */
	private String puertoPutGet;

	/**
	 * servidorPutGet
	 */
	private String servidorPutGet;

	/**
	 * useriIDPutGet
	 */
	private String useriIDPutGet;

	/**
	 * patronPutGet
	 */
	private String patronPutGet;

	/**
	 * patronGetPutGet
	 */
	private String patronGetPutGet;

	/**
	 * idSelTipoProtocolo
	 */
	private String idSelTipoProtocolo;

	/**
	 * hostOSPutGet
	 */
	private String hostOSPutGet;

	/**
	 * profileIdPutGet
	 */
	private String profileIdPutGet;

	/**
	 * knowIdHostPutGet
	 */
	private String knowIdHostPutGet;

	/**
	 * userIdKeyPutGet
	 */
	private String userIdKeyPutGet;

	/**
	 * nodoRemotoPutGet
	 */
	private String nodoRemotoPutGet;

	/**
	 * usuarioRemotoPutGet
	 */
	private String usuarioRemotoPutGet;

	/**
	 * nodoLocalPutGet
	 */
	private String nodoLocalPutGet;

	/**
	 * usuarioLocalPutGet
	 */
	private String usuarioLocalPutGet;

	/**
	 * passwordRemotoPutGet
	 */
	private String passwordRemotoPutGet;

	/**
	 * oscurecerPwdPutGet
	 */
	private String oscurecerPwdPutGet;

	/**
	 * modoBinarioPutGet
	 */
	private String modoBinarioPutGet;

	/**
	 * formatoRegistroPutGet
	 */
	private String formatoRegistroPutGet;

	/**
	 * longitudRegistroPutGet
	 */
	private String longitudRegistroPutGet;

	/**
	 * modoDispPutGet
	 */
	private String modoDispPutGet;

	/**
	 * parametroSysOptsPutGet
	 */
	private String parametroSysOptsPutGet;

	/**
	 * disposicionRegistroPutGet
	 */
	private String disposicionRegistroPutGet;

	/**
	 * Variables para protocolo WebService
	 */

	/**
	 * webServiceRequest
	 */
	private PutGetSaveWebServiceRequest webServiceRequest;

}
