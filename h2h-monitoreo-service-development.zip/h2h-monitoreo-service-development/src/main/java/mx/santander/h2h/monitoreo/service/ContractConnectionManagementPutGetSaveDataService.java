package mx.santander.h2h.monitoreo.service;

import java.math.BigDecimal;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.constants.ApiConstants;
import mx.santander.h2h.monitoreo.constants.RoutesConstant;
import mx.santander.h2h.monitoreo.model.response.PutGetServiceResponse;

@Slf4j
@Service
@Transactional
public class ContractConnectionManagementPutGetSaveDataService implements IContractConnectionManagementPutGetSaveDataService {

	@Autowired
	private ContractConnectionManagementPutGetFindDataService contractConnectionManagementPutGetFindDataUtils;
	@Autowired
	@PersistenceContext
	private EntityManager entityManager;

	public void guardaEnLDAP(PutGetServiceResponse putGetServiceResponse, String numeroContrato) {

		log.info("Inicia Guardado de LDAP...");

		String ouid = putGetServiceResponse.getLdapUser();
//		String destinationIndicator = numeroContrato + "_DEST";
//		String routingKeyName = numeroContrato + "_KEY";

		log.info(Encode.forJava("Guardado de LDAP.ouid: ".concat(ouid).concat(" en el contrato: ").concat(numeroContrato)));

	}

	/**
	 * Guarda en la tabla de H2H_MX_PARA_CD o H2H_MX_PARA_SFTP
	 * @param putGetServiceResponse Con datos para el guardado
	 * @param idptclpara ID de tabla principal
	 * @param opcion Opción de actualización o guardado(N)
	 */
	public void guardarParaCD(PutGetServiceResponse putGetServiceResponse, BigDecimal idptclpara, String opcion) {

		if ("N".equals(opcion)) {

			log.debug("Guarda a H2H_MX_PARA_SFTP o H2H_MX_PARA_CD o H2H_MX_PARA_WS...");
			// Tercer insert a H2H_MX_PARA_SFTP o H2H_MX_PARA_CD si es nuevo solamente

			guardaParaSFTPParaCd(putGetServiceResponse, idptclpara);

		} else {

			// Actualizamos los cambios
			actualizaParaSFTPParaCd(putGetServiceResponse, idptclpara);

		}

	}

	/**
	 * Se agregan los datos a la tabla de PtclPath
	 * @param putGetServiceResponse Con datos para el guardado
	 * @param idptclpara ID de tabla principal
	 * @param numeroContrato
	 * @param tipo
	 */
	public void guardaPtclPath(PutGetServiceResponse putGetServiceResponse, BigDecimal idptclpara, String numeroContrato, String tipo) {

		BigDecimal idptclpathP = contractConnectionManagementPutGetFindDataUtils.findNextValue("SEQ_H2H_MX_PTCL_PATH");

		StringBuilder query = new StringBuilder("INSERT INTO H2H_MX_PTCL_PATH (ID_PTCL_PATH, ID_PTCL_PARA, ORIG_PATH, DEST_PATH, REG_EXP, TIPO_PROC, BAND_ACTI) VALUES(:idpctlpath, :idptclpara, :origPath, :destPath, :patron, :tipo, 'A')");

		String patron = ApiConstants.WHITE_SPACE;

		if ("P".equals(tipo)) {

			patron = StringUtils.isNotBlank(putGetServiceResponse.getRegistrosPG().get(0).getPatron()) ? putGetServiceResponse.getRegistrosPG().get(0).getPatron() : ApiConstants.WHITE_SPACE;

		} else {

			patron = StringUtils.isNotBlank(putGetServiceResponse.getRegistrosPG().get(0).getPatronGet()) ? putGetServiceResponse.getRegistrosPG().get(0).getPatronGet() : ApiConstants.WHITE_SPACE;

		}

		Query queryResult = entityManager.createNativeQuery(query.toString());

		String origPath = "G".equals(tipo) ? putGetServiceResponse.getRegistrosPG().get(0).getDirectorioGet() : RoutesConstant.SLASH.concat(numeroContrato).concat("/Outbound");
		String destPath = "P".equals(tipo) ? putGetServiceResponse.getRegistrosPG().get(0).getDirectorio() : RoutesConstant.SLASH.concat(numeroContrato).concat("/Inbound");

		queryResult.setParameter("idpctlpath", idptclpathP);
		queryResult.setParameter("idptclpara", idptclpara);
		queryResult.setParameter("origPath", origPath);
		queryResult.setParameter("destPath", destPath);
		queryResult.setParameter("patron", patron);
		queryResult.setParameter("tipo", tipo);

		queryResult.executeUpdate();

	}

	/**
	 * Giardado y actualización de PTCLPara
	 * @param idptclpara para agregar
	 * @param putGetServiceResponse
	 * @param opcion
	 * @param numeroContrato
	 */
	public void guardaPtclPara(BigDecimal idptclpara, PutGetServiceResponse putGetServiceResponse, String opcion, String numeroContrato) {

		if ("M".equals(opcion)) {

			StringBuilder query = new StringBuilder("UPDATE H2H_MX_PTCL_PARA SET HOST_IP_ADDR = :servidor, HOST_PORT = :puerto, HOST_USER_ID = :userId WHERE ID_PTCL_PARA = :idptclpara AND ID_CNTR = :idContrato");

			Query queryResult = entityManager.createNativeQuery(query.toString());

			queryResult.setParameter("servidor", putGetServiceResponse.getRegistrosPG().get(0).getServidor());
			queryResult.setParameter("puerto", putGetServiceResponse.getRegistrosPG().get(0).getPuerto());
			queryResult.setParameter("userId", putGetServiceResponse.getRegistrosPG().get(0).getUserId());
			queryResult.setParameter("idptclpara", idptclpara);
			queryResult.setParameter("idContrato", putGetServiceResponse.getRegistrosPG().get(0).getIdContrato());

			queryResult.executeUpdate();

		} else {

			StringBuilder query = new StringBuilder("INSERT INTO H2H_MX_PTCL_PARA (ID_PTCL_PARA, ID_CNTR, ID_PTCL, HOST_IP_ADDR, HOST_PORT, HOST_USER_ID, LDAP_USER, LDAP_PWD, KEY_STOR, HOST_OS, LDAP_ALIAS) VALUES(:idptclpara, :idContrato, :idProtocolo, :servidor, :puerto, :userId, :ldapUser, :ldapPwd, :keystore, :hostOs, :numeroContrato)");

			Query queryResult = entityManager.createNativeQuery(query.toString());

			queryResult.setParameter("idptclpara", idptclpara);
			queryResult.setParameter("idContrato", putGetServiceResponse.getRegistrosPG().get(0).getIdContrato());
			queryResult.setParameter("idProtocolo", putGetServiceResponse.getRegistrosPG().get(0).getIdProtocolo());
			queryResult.setParameter("servidor", putGetServiceResponse.getRegistrosPG().get(0).getServidor());
			queryResult.setParameter("puerto", putGetServiceResponse.getRegistrosPG().get(0).getPuerto());
			queryResult.setParameter("userId", putGetServiceResponse.getRegistrosPG().get(0).getUserId());
			queryResult.setParameter("ldapUser", putGetServiceResponse.getLdapUser());
			queryResult.setParameter("ldapPwd", putGetServiceResponse.getLdapPwd());
			queryResult.setParameter("keystore", putGetServiceResponse.getKeystore());
			queryResult.setParameter("hostOs", putGetServiceResponse.getHostOs());
			queryResult.setParameter("numeroContrato", numeroContrato + "_DEST");

			queryResult.executeUpdate();

		}

	}

	/**
	 * Método para generar el query para actualización de PARA_SFTP o PARA_CD
	 * @param putGetServiceResponse Datos para generacion de query y actualizar
	 * @param idptclpara ID de la tabla PctlPara
	 */
	private void actualizaParaSFTPParaCd(PutGetServiceResponse putGetServiceResponse, BigDecimal idptclpara) {

		StringBuilder query = new StringBuilder();

		String idProtocolo = putGetServiceResponse.getRegistrosPG().get(0).getIdProtocolo();

		switch (idProtocolo) {

		case "1":

			query.append("UPDATE H2H_MX_PARA_SFTP SET PROF_ID = :profileId, KNOW_HOST_KEY = :knowIdHost, USER_ID_KEY = :userIdKey WHERE ID_PTCL_PARA = :idptclpara");

			Query querySftpResult = entityManager.createNativeQuery(query.toString());

			querySftpResult.setParameter("profileId", putGetServiceResponse.getRegistrosPG().get(0).getProfileId());
			querySftpResult.setParameter("knowIdHost", putGetServiceResponse.getRegistrosPG().get(0).getKnowIdHost());
			querySftpResult.setParameter("userIdKey", putGetServiceResponse.getRegistrosPG().get(0).getUserIdKey());
			querySftpResult.setParameter("idptclpara", idptclpara);

			querySftpResult.executeUpdate();

			break;

		case "2":

			query.append("UPDATE H2H_MX_PARA_CD SET LCAL_NODE = :nodoLocal, REMT_NODE = :nodoRemoto, LCAL_USER = :usuarioLocal, REMT_USER = :userId, REMT_PWD = :passwordRemoto, ");
			query.append("USE_OBSC_PWD = :oscurecerPwd, BIN_MODE = :modoBinario, REC_FORM = :formatoRegistro, REC_LEN = :longitudRegistro, DISP_MODE = :modoDisp, SYS_OPT = :parametroSysOpts, ");
			query.append("REC_DISP = :disposicionRegistro WHERE ID_PTCL_PARA = :idptclpara");

			Query queryCDResult = entityManager.createNativeQuery(query.toString());

			queryCDResult.setParameter("nodoLocal", putGetServiceResponse.getRegistrosPG().get(0).getNodoLocal());
			queryCDResult.setParameter("nodoRemoto", putGetServiceResponse.getRegistrosPG().get(0).getNodoRemoto());
			queryCDResult.setParameter("usuarioLocal", putGetServiceResponse.getRegistrosPG().get(0).getUsuarioLocal());
			queryCDResult.setParameter("userId", putGetServiceResponse.getRegistrosPG().get(0).getUserId());
			queryCDResult.setParameter("passwordRemoto", putGetServiceResponse.getRegistrosPG().get(0).getPasswordRemoto());
			queryCDResult.setParameter("oscurecerPwd", putGetServiceResponse.getRegistrosPG().get(0).getOscurecerPwd());
			queryCDResult.setParameter("modoBinario", putGetServiceResponse.getRegistrosPG().get(0).getModoBinario());
			queryCDResult.setParameter("formatoRegistro", putGetServiceResponse.getRegistrosPG().get(0).getFormatoRegistro());
			queryCDResult.setParameter("longitudRegistro", putGetServiceResponse.getRegistrosPG().get(0).getLongitudRegistro());
			queryCDResult.setParameter("modoDisp", putGetServiceResponse.getRegistrosPG().get(0).getModoDisp());
			queryCDResult.setParameter("parametroSysOpts", putGetServiceResponse.getRegistrosPG().get(0).getParametroSysOpts());
			queryCDResult.setParameter("disposicionRegistro", putGetServiceResponse.getRegistrosPG().get(0).getDisposicionRegistro());
			queryCDResult.setParameter("idptclpara", idptclpara);

			queryCDResult.executeUpdate();

			break;

		case "5":

			query.append("UPDATE H2H_MX_PARA_WS SET URI_CONS_WS = :uriConsultaWS, CERT_WS = :certificadoWS, URI_PUT_WS = :uriPUTWS, URI_GET_WS = :uriGETWS WHERE ID_PTCL_PARA = :idptclpara");

			Query queryWSResult = entityManager.createNativeQuery(query.toString());

			queryWSResult.setParameter("uriConsultaWS", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getPutGetWSDto().getUriConsultaWS()));
			queryWSResult.setParameter("certificadoWS", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getPutGetWSDto().getCertificadoWS()));
			queryWSResult.setParameter("uriPUTWS", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getPutGetWSDto().getUriPUTWS()));
			queryWSResult.setParameter("uriGETWS", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getPutGetWSDto().getUriGETWS()));
			queryWSResult.setParameter("idptclpara", validateEmptyString(putGetServiceResponse.getIdPara()));

			queryWSResult.executeUpdate();

			break;

		default:

			log.info("IdProtocolo no encontrado. No se realiza inserción de datos.");

			break;

		}

	}

	/**
	 * Guarda en la tabla de H2H_MX_PARA_CD o H2H_MX_PARA_SFTP
	 * @param putGetServiceResponse Datos para guardar
	 * @param idptclpara Id del protocolo para inserción, tabla principal
	 */
	private void guardaParaSFTPParaCd(PutGetServiceResponse putGetServiceResponse, BigDecimal idptclpara) {

		StringBuilder query = new StringBuilder();

		String idProtocolo = putGetServiceResponse.getRegistrosPG().get(0).getIdProtocolo();

		switch (idProtocolo) {

		case "1":

			BigDecimal idparaSftp = contractConnectionManagementPutGetFindDataUtils.findNextValue("SEQ_H2H_MX_PARA_SFTP");

			query.append("INSERT INTO H2H_MX_PARA_SFTP (ID_PARA_SFTP, ID_PTCL_PARA, PROF_ID, KNOW_HOST_KEY, USER_ID_KEY) VALUES(:idparaSftp, :idptclpara, :profileId, :knowIdHost, :userIdKey)");

			Query querySftpResult = entityManager.createNativeQuery(query.toString());

			querySftpResult.setParameter("idparaSftp", idparaSftp);
			querySftpResult.setParameter("idptclpara", idptclpara);
			querySftpResult.setParameter("profileId", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getProfileId()));
			querySftpResult.setParameter("knowIdHost", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getKnowIdHost()));
			querySftpResult.setParameter("userIdKey", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getUserIdKey()));

			querySftpResult.executeUpdate();

			break;

		case "2":

			BigDecimal idparaCd = contractConnectionManagementPutGetFindDataUtils.findNextValue("SEQ_H2H_MX_PARA_CD");

			query.append("INSERT INTO H2H_MX_PARA_CD (ID_PARA_CD, ID_PTCL_PARA, LCAL_NODE, REMT_NODE, LCAL_USER, REMT_USER, REMT_PWD, USE_OBSC_PWD, BIN_MODE, REC_FORM, REC_LEN, DISP_MODE, SYS_OPT, REC_DISP) ");
			query.append("VALUES (:idparaCd, :idptclpara, :nodoLocal, :nodoRemoto, :usuarioLocal, :userId, :passwordRemoto, :oscurecerPwd, :modoBinario, :formatoRegistro, :longitudRegistro, ");
			query.append(":modoDisp, :parametroSysOpts, :disposicionRegistro)");

			Query queryCdResult = entityManager.createNativeQuery(query.toString());

			queryCdResult.setParameter("idparaCd", idparaCd);
			queryCdResult.setParameter("idptclpara", idptclpara);
			queryCdResult.setParameter("nodoLocal", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getNodoLocal()));
			queryCdResult.setParameter("nodoRemoto", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getNodoRemoto()));
			queryCdResult.setParameter("usuarioLocal", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getUsuarioLocal()));
			queryCdResult.setParameter("userId", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getUserId()));
			queryCdResult.setParameter("passwordRemoto", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getPasswordRemoto()));
			queryCdResult.setParameter("oscurecerPwd", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getOscurecerPwd()));
			queryCdResult.setParameter("modoBinario", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getModoBinario()));
			queryCdResult.setParameter("formatoRegistro", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getFormatoRegistro()));
			queryCdResult.setParameter("longitudRegistro", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getLongitudRegistro()));
			queryCdResult.setParameter("modoDisp", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getModoDisp()));
			queryCdResult.setParameter("parametroSysOpts", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getParametroSysOpts()));
			queryCdResult.setParameter("disposicionRegistro", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getDisposicionRegistro()));

			queryCdResult.executeUpdate();

			break;

		case "5":

			BigDecimal idparaWS = contractConnectionManagementPutGetFindDataUtils.findNextValue("SEQ_H2H_MX_PARA_WS");

			query.append("INSERT INTO H2H_MX_PARA_WS (ID_PARA_WS, ID_PTCL_PARA, URI_CONS_WS, CERT_WS, URI_GET_WS, URI_PUT_WS) VALUES(:idparaWS, :idptclpara, :uriConsultaWS, :certificadoWS, ");
			query.append(":uriGETWS, :uriPUTWS)");

			Query queryWSResult = entityManager.createNativeQuery(query.toString());

			queryWSResult.setParameter("idparaWS", idparaWS);
			queryWSResult.setParameter("idptclpara", idptclpara);
			queryWSResult.setParameter("uriConsultaWS", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getPutGetWSDto().getUriConsultaWS()));
			queryWSResult.setParameter("certificadoWS", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getPutGetWSDto().getCertificadoWS()));
			queryWSResult.setParameter("uriGETWS", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getPutGetWSDto().getUriGETWS()));
			queryWSResult.setParameter("uriPUTWS", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getPutGetWSDto().getUriPUTWS()));

			queryWSResult.executeUpdate();

			break;

		default:

			log.info("IdProtocolo no encontrado. No se realiza inserción de datos.");

			break;

		}

	}

	/**
	 * Valida datos nulos para asignarlos vacíos.
	 * 
	 * @param value valor a validar
	 * @return retorna dato o vacío
	 */
	private String validateEmptyString(String value) {

		if (StringUtils.isBlank(value)) {
			value = "";
		}

		return value;
	}

}
