package mx.santander.h2h.monitoreo.util;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UtilOperacionMonitorNew {

	/** Tabla PROD */
	protected static final String TMP_DIVI = "TMP.DIVI DIVISA,";
	/**NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD, */
	protected static final String NULL_INTERMEDIARIO_ORD_NULL_DIVISA_ORD="null INTERMEDIARIO_ORD, TMP.DIVI DIVISA_ORD, ";
	/**NULL INTERMEDIARIO_REC, NULL BENEFICIARIO, */
	protected static final String NULL_INTERMEDIARIO_REC_NULL_BENEFICIARIO="MSG.MSG_H2H INTERMEDIARIO_REC, NULL BENEFICIARIO, ";
	/**MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, */
	protected static final String MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN="MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, ";
	/**  NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, *. */
	public static final String NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA = "NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, ";
	/** NULL BUC_EMPLEADO, */
	protected static final String NULL_BUC_EMPLEADO = " NULL BUC_EMPLEADO, ";
	/**"NULL SUCURSAL_TUTORA, NULL RFC, NULL TIPO, "**/
	protected static final String NULL_SUCURSAL_TUTORA_NULL_RFC_NULL_TIPO="NULL SUCURSAL_TUTORA, NULL RFC, NULL TIPO, ";
	/**NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA,**/
	protected static final String NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA="NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, ";
	/**NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD, */
	protected static final String PIF_INTERMEDIARIO_ORD_NULL_DIVISA_ORD="DETA.OBSE_ABO INTERMEDIARIO_ORD, TMP.DIVI DIVISA_ORD, ";
	/**NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD, */
	protected static final String NULL_INTERMEDIARIO_OTROSPROD="NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD, ";

	/**
	 * Metodo Getter para cadValidacion.
	 *
	 * @param cveOperProd para cve oper prod
	 * @return cadValidacion cad validacion
	 */
	public static String getCadValidacion(final StringBuilder queryCad, String cveOperProd) {
//		final StringBuilder queryCad = new StringBuilder();
		if("31".equals(cveOperProd) || "33".equals(cveOperProd)){
			queryCad.append("DETA.NUM_CTA_BENE NUN_CTA_ABONO, PROD.CVE_PROD_OPER, PROD.DESC_PROD, ");
		}else{
			queryCad.append("TMP.CNTA_ABON NUN_CTA_ABONO, PROD.CVE_PROD_OPER, PROD.DESC_PROD, ");
		}
		queryCad.append("TMP.NOMBRE_ARCH, ");
		if("21".equals(cveOperProd) || "22".equals(cveOperProd) || "23".equals(cveOperProd)){
			queryCad.append("DETA.REFE_MOV REFERENCIA,");
		}else if("31".equals(cveOperProd)){
			queryCad.append("DETA.TXT_REF REFERENCIA,");
		}else if("33".equals(cveOperProd)){
			queryCad.append("to_char(DETA.NUM_ORDEN) REFERENCIA,");
		}else{
			queryCad.append("TMP.REFE_BE REFERENCIA,");
		}
		return queryCad.toString();
	}
	
	/**
	 * Metodo Getter para validacionCve.
	 *
	 * @return validacionCve validacion cve
	 */
	public static String getValidacionCve(final StringBuilder queryVc, String cveOperProd) {
//		final StringBuilder queryVc = new StringBuilder();
		log.info("Querie getValidacionCve: " + queryVc.toString());
		if ("01".equals(cveOperProd) || "97".equals(cveOperProd) || "02".equals(cveOperProd)) {/**SPEI - TEF - Nomina Interbancaria*/
			queryVc.append(agrega01y97y02(queryVc));
		} else if ("80".equals(cveOperProd) || "81".equals(cveOperProd)) {/**ORDEN DE PAGO*/
			queryVc.append(agrega80y81(queryVc));
		} else 	if ("95".equals(cveOperProd)  || "96".equals(cveOperProd)) {/**Alta Cuenta Beneficiarias*/
			queryVc.append(agrega95y96(queryVc));
		} else 	if ("98".equals(cveOperProd)   || "99".equals(cveOperProd)) {/**TMB  -  Nomina Mismo Banco*/
			queryVc.append(agrega9y99(queryVc));
		} else if ("91".equals(cveOperProd) || "93".equals(cveOperProd) || "30".equals(cveOperProd)|| "29".equals(cveOperProd)) {/**ALTA PAGO PROVEEDORES CONFIRMING*/
			queryVc.append(completaQueryProducto919330(cveOperProd));
		}else if("21".equals(cveOperProd) || "22".equals(cveOperProd) || "23".equals(cveOperProd)){
			queryVc.append(agregaPifconsulta(queryVc,cveOperProd));
		}else if("31".equals(cveOperProd) || "33".equals(cveOperProd)){
			queryVc.append(agregaTIconsulta(queryVc,cveOperProd));
		}else{										
			queryVc
				.append(NULL_INTERMEDIARIO_ORD_NULL_DIVISA_ORD)
				.append(NULL_INTERMEDIARIO_REC_NULL_BENEFICIARIO)
				.append("NULL COMENTARIO_1, NULL COMENTARIO_2, ")
				.append(" NULL COMENTARIO_3, NULL TITULAR, NULL BANCO_RECEPTOR, ")
				.append("NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO, ")
				.append(MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN)
				.append(" NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL,  ")
				.append(NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA)
				.append(NULL_BUC_EMPLEADO)
				.append(NULL_SUCURSAL_TUTORA_NULL_RFC_NULL_TIPO)
				.append(NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA);
		}
		log.info("Querie getValidacionCve TERMINO: " + queryVc.toString());
		return queryVc.toString();
	}
	
	/***
	 * 
	 * @param query query
	 */
	public static String agrega01y97y02(StringBuilder query) {
		StringBuilder qry172 = new StringBuilder();
		String sqlProdTran = query.toString();
		query.delete(0, sqlProdTran.length());
		sqlProdTran = sqlProdTran.replace(TMP_DIVI, "DECODE(DIVI_ABON.CLAV_CAPTA,NULL,TMP.DIVI,DIVI_ABON.CLAV_CAPTA) DIVISA,");
		qry172
			.append(sqlProdTran)
			.append("DETA.CLAV_INTE_ORDE INTERMEDIARIO_ORD, DIVI_CARG.CLAV_CAPTA DIVISA_ORD, ")
			.append("MSG.MSG_H2H INTERMEDIARIO_REC, DECODE(CNTA_ABON.NOMB_TITU,NULL,DETA.NOMB_RECE,CNTA_ABON.NOMB_TITU) BENEFICIARIO, ")
			.append("DETA.COME_1_CONC_PAGO COMENTARIO_1, DETA.COME_2 COMENTARIO_2, ")
			.append("DETA.COME_3 COMENTARIO_3, CNTA_CARG.NOMB_TITU TITULAR, BNCO.NOMBRE_BANCO BANCO_RECEPTOR, ")
			.append("NULL TIPO_PAGO, NULL MODALIDAD, DETA.IMPO_CARG IMPORTE_CARGO, ")
			.append("MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, ")
			.append(" NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, ")
			.append(" NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, ")
			.append(" NULL BUC_EMPLEADO,  ")
			.append(" NULL SUCURSAL_TUTORA, NULL RFC, NULL TIPO, ")
			.append(" NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, ");
		return qry172.toString();
	}
	
	/***
	 * 
	 * @param query query
	 */
	public static String agrega80y81(StringBuilder query) {
		StringBuilder qry88 = new StringBuilder();
		qry88
		.append("NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD, MSG.MSG_H2H INTERMEDIARIO_REC, ")
		.append("DETA.NOMB_BENE || ' ' || DETA.APE_PATE_BENE || ' ' || DETA.APE_MATE_BENE BENEFICIARIO, ")
		.append(" NULL COMENTARIO_1, NULL COMENTARIO_2, ")
		.append("NULL COMENTARIO_3, NULL TITULAR, NULL BANCO_RECEPTOR, ")
		.append("DETA.FORM_PAGO TIPO_PAGO, DETA.FORM_ALTA MODALIDAD, DETA.IMPO_GIRO IMPORTE_CARGO, ")
		.append("DETA.CONC_PAGO MSG_H2H, MSG.MSG_H2H MSG_ORDEN_PAGO, DETA.NUM_ORDEN, ")
		.append("DETA.FECH_LIMI_LIQ FECHA_LIMITE_PAGO, DETA.OFIC_PAGO NUM_SUCURSAL, ")
		.append(" NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, ")
		.append(" NULL BUC_EMPLEADO,  ")
		.append(" NULL SUCURSAL_TUTORA, NULL RFC, NULL TIPO, ")
		.append(" NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, ");
		return qry88.toString();
	}
	
	/***
	 * 
	 * @param query query
	 * 
	 */
	public static String agrega95y96(StringBuilder query) {
		StringBuilder qry99 = new StringBuilder();
		String sqlProdTran = query.toString();
		query.delete(0, sqlProdTran.length());
		sqlProdTran = sqlProdTran.replace(TMP_DIVI, "DECODE(DIVI_ABON.CLAV_CAPTA,NULL,TMP.DIVI,DIVI_ABON.CLAV_CAPTA) DIVISA,");
		qry99
			.append(sqlProdTran)
			.append("NULL INTERMEDIARIO_ORD, DIVI_CARG.CLAV_CAPTA DIVISA_ORD, ")
			.append("MSG.MSG_H2H INTERMEDIARIO_REC, DECODE(CNTA_ABON.NOMB_TITU,NULL,DETA.NOMB_RECE,CNTA_ABON.NOMB_TITU) BENEFICIARIO, ")
			.append(" NULL COMENTARIO_1, NULL COMENTARIO_2, ")
			.append("NULL COMENTARIO_3, CNTA_CARG.NOMB_TITU TITULAR, BNCO.NOMBRE_BANCO BANCO_RECEPTOR, ")
			.append(" NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO, ")
			.append(" MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, ")
			.append(" NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, ")
			.append("NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA,  ")
			.append("NULL BUC_EMPLEADO,   ")
			.append("NULL SUCURSAL_TUTORA, NULL RFC, NULL TIPO,  ")
			.append("NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA,  ");
		return qry99.toString();
	}
	
	/***
	 * 
	 * @param query query
	 * 
	 */
	public static String agrega9y99(StringBuilder query) {
		StringBuilder qry999 = new StringBuilder();
		String sqlProdTran = query.toString();
		query.delete(0, sqlProdTran.length());
		sqlProdTran = sqlProdTran.replace(TMP_DIVI, "DIVI_ABON.CLAV_CAPTA DIVISA,");
		qry999
			.append(sqlProdTran)
			.append("NULL INTERMEDIARIO_ORD,  ")
			.append("DIVI_CARG.CLAV_CAPTA DIVISA_ORD, ")
			.append("MSG.MSG_H2H INTERMEDIARIO_REC, CNTA_ABON.NOMB_TITU BENEFICIARIO, ")
			.append("NULL COMENTARIO_1, NULL COMENTARIO_2,  ")
			.append("NULL COMENTARIO_3, CNTA_CARG.NOMB_TITU TITULAR, BNCO.NOMBRE_BANCO BANCO_RECEPTOR, ")
			.append(" NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO, ")
			.append("MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN,  ")
			.append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL,  ")
			.append("NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA,  ")
			.append("NULL BUC_EMPLEADO,   ")
			.append("NULL SUCURSAL_TUTORA, NULL RFC, NULL TIPO,  ")
			.append("NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA,  ");
		return qry999.toString();
	}
	
	/**
	 * Completa el query de productos para el producto 91, 93 y 30.
	 * @param cveOperProd Clave de operacion del producto.
	 * @return SQL query
	 */
	public static String completaQueryProducto919330(String cveOperProd) {
		StringBuilder query = new StringBuilder();
		if ("91".equals(cveOperProd)) {
			String sqlConfirming = query.toString();
			query.delete(0, sqlConfirming.length());
			sqlConfirming = sqlConfirming.replace(
					"TMP.CNTA_CARG NUM_CTA_CARGO,",
					"TO_CHAR(DETA.CNTA_CARG) NUM_CTA_CARGO,");
			sqlConfirming = sqlConfirming.replace(
					"TMP.CNTA_ABON NUN_CTA_ABONO,",
					"DETA.CNTA_ABON NUN_CTA_ABONO,");
			sqlConfirming = sqlConfirming.replace("TMP.REFE_BE REFERENCIA,",
					"DETA.REFE_ABON REFERENCIA,");
			sqlConfirming = sqlConfirming.replace(TMP_DIVI,
					"DETA.DIVI_ABON DIVISA,");
			query.append(sqlConfirming)
					.append("NULL INTERMEDIARIO_ORD, DETA.DIVI_CARG DIVISA_ORD, ")
					.append("NULL INTERMEDIARIO_REC, DETA.NOMB_RAZON_SOCI_PROV BENEFICIARIO, ")
					.append("NULL COMENTARIO_1, NULL COMENTARIO_2,  ")
					.append("NULL COMENTARIO_3, ")
					.append("DECODE (CLTE.PERSONALIDAD,'F',CLTE.nombre  || ' '  || ")
					.append("CLTE.appaterno  || ' '  || CLTE.apmaterno, CLTE.RAZON_SCIA) TITULAR, ")
					.append("DETA.BANC_ABON BANCO_RECEPTOR, ")
					.append("NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO,  ")
					.append("MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN,  ")
					.append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL,  ")
					.append(NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA)
					.append(NULL_BUC_EMPLEADO)
					.append(NULL_SUCURSAL_TUTORA_NULL_RFC_NULL_TIPO)
					.append(NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA);
		} else if ("93".equals(cveOperProd)) {
			/** Alta Masiva Empleados */
			query.append(NULL_INTERMEDIARIO_OTROSPROD)
					.append(NULL_INTERMEDIARIO_REC_NULL_BENEFICIARIO)
					.append("NULL COMENTARIO_1, NULL COMENTARIO_2, ")
					.append("NULL COMENTARIO_3, NULL TITULAR, NULL BANCO_RECEPTOR, ")
					.append("NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO,  ")
					.append(MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN)
					.append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, ")
					.append("DETA.NUME_EMPL NUMERO_EMPLEADO, DETA.NUME_TARJ_NUEV NUMERO_TARJETA, ")
					.append("DETA.NUME_BUC_EMPL BUC_EMPLEADO, ")
					.append("DETA.SUCU_TUTO SUCURSAL_TUTORA, DETA.RFC_EMPL RFC, DETA.NUME_CTA TIPO, ")
					.append("DETA.NOMB_EMPL || ' ' || DETA.APEL_PATE_EMPL || ' ' || DETA.APEL_MATE_EMPL NOMBRE_EMPLEADO, DETA.NUME_CTA_NUEV NUMERO_CUENTA, ");
		} else if ("30".equals(cveOperProd)) {
			/************************* DOMICILIACIONES **************************/
			query.append(NULL_INTERMEDIARIO_OTROSPROD)
					.append(NULL_INTERMEDIARIO_REC_NULL_BENEFICIARIO)
					.append("NULL COMENTARIO_1, NULL COMENTARIO_2, ")
					.append(" NULL COMENTARIO_3, NULL TITULAR, NULL BANCO_RECEPTOR, ")
					.append("NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO, ")
					.append(MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN)
					.append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, ")
					.append(NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA)
					.append(NULL_BUC_EMPLEADO)
					.append(NULL_SUCURSAL_TUTORA_NULL_RFC_NULL_TIPO)
					.append(NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA);

		} else if ("29".equals(cveOperProd)) {
			//Esto no existe en el codigo anterior
			/************************* DOMICILIACIONES **************************/
			query.append(NULL_INTERMEDIARIO_OTROSPROD)
					.append(NULL_INTERMEDIARIO_REC_NULL_BENEFICIARIO)
					.append("NULL COMENTARIO_1, NULL COMENTARIO_2, ")
					.append(" NULL COMENTARIO_3, NULL TITULAR, NULL BANCO_RECEPTOR, ")
					.append("NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO, ")
					.append(MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN)
					.append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, ")
					.append(NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA)
					.append(NULL_BUC_EMPLEADO)
					.append(NULL_SUCURSAL_TUTORA_NULL_RFC_NULL_TIPO)
					.append(NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA);

		}
		return query.toString();
	}
	
	/**
	 * 
	 * @param query query
	 * @param cveOperProd prod oper
	 */
	public static String agregaPifconsulta(StringBuilder query, String cveOperProd) {
		StringBuilder qryPifC = new StringBuilder();
		qryPifC
		.append(PIF_INTERMEDIARIO_ORD_NULL_DIVISA_ORD)
		.append(NULL_INTERMEDIARIO_REC_NULL_BENEFICIARIO)
		.append("DETA.CLVE_CONV COMENTARIO_1,");
		if("23".equals(cveOperProd)){
			qryPifC.append(" DETA.REG_PATR COMENTARIO_2,DETA.NUME_FOLI_SUA COMENTARIO_3,");
		}else{
			qryPifC.append(" NULL COMENTARIO_2,NULL COMENTARIO_3, ");
		}
		qryPifC.append(" DETA.NOMB_CLTE TITULAR, NULL BANCO_RECEPTOR, ")
		.append("NULL TIPO_PAGO, NULL MODALIDAD, DETA.IMPO_MOVI IMPORTE_CARGO, ")
		.append(MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN)
		.append(" NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL,  ")
		.append(NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA)
		.append(NULL_BUC_EMPLEADO)
		.append(NULL_SUCURSAL_TUTORA_NULL_RFC_NULL_TIPO)
		.append(NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA);
		return qryPifC.toString();
	}
	
	/**
	 * 
	 * @param query query para Transferencias Internacionales
	 * @param cveOperProd prod oper
	 */
	public static String agregaTIconsulta(StringBuilder query, String cveOperProd) {
		StringBuilder qryTI = new StringBuilder();
		qryTI
		.append("null INTERMEDIARIO_ORD, TMP.DIVI DIVISA_ORD,")
		.append("MSG.MSG_H2H INTERMEDIARIO_REC, DETA.TXT_NOM_BENE BENEFICIARIO, ")
		.append("NULL COMENTARIO_1,")
	    .append(" NULL COMENTARIO_2,NULL COMENTARIO_3, ")
		.append(" DETA.TXT_NOM_ORD TITULAR, NULL BANCO_RECEPTOR, ")
		.append("NULL TIPO_PAGO, NULL MODALIDAD,");
		if("33".equals(cveOperProd)){
			qryTI.append(" DETA.IMP_CARGO IMPORTE_CARGO, ")
			.append(" DECODE(DETA.DSC_ERROR,null,MSG.MSG_H2H,DETA.DSC_ERROR) MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN,");
		}else{
			qryTI
			.append(" DETA.IMP_CARGO_ORD IMPORTE_CARGO, ")
			.append(MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN);
		}
		qryTI
		.append(" NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL,  ")
		.append(NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA)
		.append(NULL_BUC_EMPLEADO)
		.append(NULL_SUCURSAL_TUTORA_NULL_RFC_NULL_TIPO)
		.append(NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA);
		return qryTI.toString();
	}
}
