package mx.santander.h2h.monitoreo.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import mx.santander.h2h.monitoreo.model.request.ArchivoCancelRequest;
import mx.santander.h2h.monitoreo.model.response.ArchivoCancelResponse;
import mx.santander.h2h.monitoreo.model.response.CancelOperationUpdResponse;
import mx.santander.h2h.monitoreo.repository.ICancelOperationRepository;
import mx.santander.h2h.monitoreo.util.UtilMapeoData;

/**
 * Clase que implementa la interfaz de ICancelOperationService Creando los
 * metodos necesarios para hacer la consultas necesarias tales como los combos
 * de estatus centro, comobo de estatus cancelado buscar una operacion por buc,
 * buscar un archivo y cancelar una operacion
 * 
 * @version 1.1
 * @author NTTDATA-NRL
 */
@Service
public class CancelOperationService implements ICancelOperationService {

	/**
	 * Varaible para implementar la persistencia
	 */
	@PersistenceContext
	@Autowired
	public EntityManager entityManager;
	


	/**
	 * Varaible para implementar el repositorio de camcelar operaciones
	 */
	@Autowired
	private ICancelOperationRepository cancelOperationRepository;

    /**
     * QUery para la consylta de todos los archivos
     */
    private static final String QUERY_CONSULTA_ALL_ARCHIVOS ="SELECT reg.ID_REG REGISTRO " +
            "from H2H_ARCHIVO_TRAN arch inner join H2H_REG_TRAN reg on reg.ID_ARCH=arch.ID_ARCHIVO " +
            "inner join H2H_CAT_PROD prod on reg.CVE_PROD_OPER=prod.cve_prod_oper " +
            "inner join H2H_CNTR Cntr on Cntr.ID_CNTR=arch.ID_CNTR " +
            "inner join H2H_CLTE Clte on cntr.ID_CLTE=Clte.ID_CLTE " +
            "inner join H2H_CAT_ESTATUS est on reg.ID_ESTATUS = est.ID_CAT_ESTATUS " +
            "inner join H2H_CAT_CANL can on arch.ID_CANL=can.ID_CANL " +
            "WHERE reg.ID_ESTATUS in(10,11) and Clte.BUC = :clienteBuc ";
    
    /**
     * Query para la consulta de archivos por buc
     */
    private static final String QUERY_CONSULTA_ARCHIVOS = "SELECT reg.ID_REG REGISTRO ,Clte.BUC BUC,reg.ID_REG MOVIMIENTO," +
            "reg.CNTA_CARG CTA_CARG,reg.CNTA_ABON CTA_ABO,prod.DESC_PROD PRODUCTO, \n" +
            "arch.NOMBRE_ARCH,can.NOMB_CANL CANAL,'' REFERENCIA,arch.ID_ESTATUS,  est.DESC_ESTATUS ESTATUS ," +
            "reg.MONT IMPORTE,'' BANDERA " +
            "from H2H_ARCHIVO_TRAN arch  " +
            "inner join H2H_REG_TRAN reg on reg.ID_ARCH=arch.ID_ARCHIVO " +
            "inner join H2H_CAT_PROD prod on reg.CVE_PROD_OPER=prod.cve_prod_oper " +
            "inner join H2H_CNTR Cntr on Cntr.ID_CNTR=arch.ID_CNTR " +
            "inner join H2H_CLTE Clte on cntr.ID_CLTE=Clte.ID_CLTE " +
            "inner join H2H_CAT_ESTATUS est on reg.ID_ESTATUS = est.ID_CAT_ESTATUS " +
            "inner join H2H_CAT_CANL can on arch.ID_CANL=can.ID_CANL " +
            "WHERE reg.ID_ESTATUS in(10,11) AND Clte.BUC =:clienteBuc ";
    /**Cero*/
    private static final String VALOR_VACIO = "";
    /**0*/
    public static final String VALOR_CERO = "0";
    /**Coma*/
    public static final String VALOR_COMA = ",";
	


	/**
	 * (non-Javadoc) Método de cargador de clases estándar para cargar una clase y
	 * resolverla.
	 * 
	 * @see ICancelOperationService#searchArchive(ArchivoCancelRequest, Pageable)
	 */
	@Override
	public Page<ArchivoCancelResponse> searchArchive(ArchivoCancelRequest request, Pageable page) {

		Query querySearch = armarQuery(request,2);
//		querySearch.setFirstResult(page.getPageNumber() * page.getPageSize());
//		querySearch.setMaxResults(page.getPageSize());

		List<Object[]> detalleArchivosResult = querySearch.getResultList();

		List<ArchivoCancelResponse> lista = new ArrayList<ArchivoCancelResponse>();
		if (detalleArchivosResult != null) {
			for (Object[] map : detalleArchivosResult) {
				ArchivoCancelResponse bean = new ArchivoCancelResponse();

				bean.setIdRegistro((Long) map[0]);
				bean.setBuc((String) map[1]);
				bean.setMovimiento((Long) map[2]);
				bean.setCtaCargo((String) map[3]);
				bean.setCtaAbono((String) map[4]);
				// Enmascaramos la Cuenta
				bean.setCtaAbono(UtilMapeoData.getMascara(bean.getCtaAbono(), "abono"));
				bean.setProducto((String) map[5]);
				bean.setNomArchivo((String) map[6]);
				bean.setCanal((String) map[7]);
				bean.setReferencia((String) map[8]);
				bean.setIdEstatus((Integer) map[9]);
				bean.setEstatus((String) map[10]);
				bean.setImporte((BigDecimal) map[11]);

				lista.add(bean);
			}
		}

//		querySearch.setFirstResult(0);
//		querySearch.setMaxResults(Integer.MAX_VALUE);

		Integer totalRows = querySearch.getResultList().size();
		return new PageImpl<>(lista, page, totalRows);
	}
	
	
	/**
	 * (non-Javadoc) Método de cargador de clases estándar para cargar una clase y
	 * resolverla.
	 * 
	 * @see ICancelOperationService#cancelOperacion(String, ArchivoCancelRequest)
	 */
	@Override
	public CancelOperationUpdResponse cancelOperacion(String idOperacion, ArchivoCancelRequest request) {

		CancelOperationUpdResponse response = new CancelOperationUpdResponse();
		String[] registrosList = null;

		if (idOperacion.equals(VALOR_CERO)) {
			registrosList = getAllRegister(request).split(VALOR_COMA);
		} else {
			StringBuilder resp = new StringBuilder();
			for(int i = 0; i < request.getIdRegistros().size(); i++) {
				String idReg = request.getIdRegistros().get(i).toString();
				resp.append(idReg + ",");
			}
			resp = new StringBuilder(resp.substring(0, resp.length() - 1));
			registrosList = resp.toString().split(VALOR_COMA);
		}

		int conteoUpdate = cancelOperationRepository.updateCancelOperation(registrosList);

		if (conteoUpdate == registrosList.length) {
			response.setCodError("200");
			response.setMsgError("UPDO001");
		} else {
			response.setCodError("206");
			response.setMsgError("UPDO002");
		}

		return response;
	}

	/**
	 * Funcion para obtener la query dependiendo de los valores de filtro si
	 * contiene estatus se agrega el filtro si contiene nombre archivo se agrega el
	 * filtro en caso contrario se deja el queri que obtenga todos los registros
	 * 
	 * @param request parametros de peticion
	 * @return String
	 */
	private String getAllRegister(ArchivoCancelRequest request) {

		StringBuilder responseListAll = new StringBuilder("");

		Query query = armarQuery(request,1);


		List<Long> resultAllArchive = query.getResultList();

		if (!resultAllArchive.isEmpty()) {

			for (int i = 0; i < resultAllArchive.size(); i++) {
				String idRegistro = resultAllArchive.get(i).toString();
				responseListAll.append(idRegistro + ",");
			}
			responseListAll = new StringBuilder(responseListAll.substring(0, responseListAll.length() - 1));
		}

		return responseListAll.toString();
	}

	/**
	 * Metodo para hacer la llamada al query dependiendo de
	 * si vien ocn filtros o no
	 * @param request peticion
	 * @param tipo tipo 1 es de todos 2 es para el paginado
	 * @return Query
	 */
	public Query armarQuery(ArchivoCancelRequest request, int tipo){

		boolean nameIsEmpty = false;
		boolean statusIsEmpty = false;

		if (request.getNomArchivo().equals(VALOR_VACIO)) {
			nameIsEmpty = true;
		}

		if(request.getEstatus().equals(VALOR_VACIO)){
			statusIsEmpty = true;
		}

		StringBuilder queryBuilder = new StringBuilder();
		// 1 es de todos 2 es del paginado
		if(tipo == 1){
			queryBuilder.append(QUERY_CONSULTA_ALL_ARCHIVOS);
		}else{
			queryBuilder.append(QUERY_CONSULTA_ARCHIVOS);
		}

		if(!nameIsEmpty){
			queryBuilder.append("AND UPPER(arch.NOMBRE_ARCH) = UPPER(:nombreArchivo)");
		}

		if(!statusIsEmpty){
			queryBuilder.append("AND reg.ID_ESTATUS =:idEstatus ");
		}


		if(tipo == 2){
			queryBuilder.append(" order by MOVIMIENTO DESC");
		}

		Query query = this.entityManager.createNativeQuery(queryBuilder.toString());
		query.setParameter("clienteBuc",request.getBucCliente());

		if(!nameIsEmpty){
			query.setParameter("nombreArchivo",request.getNomArchivo());
		}

		if(!statusIsEmpty){
			query.setParameter("idEstatus",request.getEstatus());
		}

		return query;
	}

	
}
