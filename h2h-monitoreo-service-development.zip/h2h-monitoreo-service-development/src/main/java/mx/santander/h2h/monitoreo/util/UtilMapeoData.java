package mx.santander.h2h.monitoreo.util;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.comunes.utilerias.ValidaCampos;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;

/**
 * Clase generada para el mapeo de datos enviados por lo filtros del tipo de Operacion
 * 
 * @author C320868
 * @modifico C320868
 */
@Slf4j
public class UtilMapeoData {
	
	/**
	 * Mapeo de datos basados en los tipos de producto
	 * 
	 * @param consOperaciones
	 * @return
	 */
	public static OperationsMonitorQueryRequest cleanCamposByOperation(OperationsMonitorQueryRequest consOperaciones) {
		OperationsMonitorQueryRequest filtro = new OperationsMonitorQueryRequest();
		String idProducto = UtilData.toString( consOperaciones.getIdProducto() );
		String nomProd = UtilData.toString( consOperaciones.getNombreProducto() );
		
		// Validamos si es el filtro principal
		if("todos".equalsIgnoreCase(nomProd) ) {
			idProducto = "0";
		}
		filtro.setIdProducto(idProducto);
		// Campos que se repiten en los diferentes filtros validando los datos
		filtro.setFechaInicial( UtilData.toString( consOperaciones.getFechaInicial()) );
		filtro.setFechaFinal( UtilData.toString( consOperaciones.getFechaFinal() ) );
		filtro.setDivisa( UtilData.toString( consOperaciones.getDivisa()) );
		filtro.setBuc( UtilData.toString( consOperaciones.getBuc()) );
		filtro.setContrato( UtilData.toString( consOperaciones.getContrato()) );
		filtro.setNombreArchivo( UtilData.toString( consOperaciones.getNombreArchivo()) );
		filtro.setIdEstatus(UtilData.toString( consOperaciones.getIdEstatus()) );
		filtro.setIdReg( UtilData.toString( consOperaciones.getIdReg()) );
		filtro.setUser( UtilData.toString( consOperaciones.getUser()) );
		filtro.setNombreProducto(UtilData.toString( consOperaciones.getNombreProducto()) );
		filtro.setDescripcionEstatus(UtilData.toString( consOperaciones.getDescripcionEstatus()) );
		
		if( "0".equals( idProducto ) ) {
			filtro.setCuentaAbono( UtilData.toString( consOperaciones.getCuentaAbono()) );
		}
		// Validamos por tipo de Producto
		if( "11".equals( idProducto ) ) {
			filtro.setCveProveedor( UtilData.toString( consOperaciones.getCveProveedor()) );
			filtro.setTipOperacion( UtilData.toString( consOperaciones.getTipOperacion()) );
			return filtro;
		}
		if( "93".equals( idProducto ) ) {
			filtro.setNumEmpleado( UtilData.toString( consOperaciones.getNumEmpleado()) );
			filtro.setNumTarjeta( UtilData.toString( consOperaciones.getNumTarjeta()) );
			filtro.setSucTutora( UtilData.toString( consOperaciones.getSucTutora()) );
			filtro.setTipo( UtilData.toString( consOperaciones.getTipo()) );
		} 
		if( "22".equals( idProducto ) ) {
			filtro.setConvenio( UtilData.toString( consOperaciones.getConvenio()) );
		}
		if( "23".equals( idProducto ) ) {
			filtro.setRegPat( UtilData.toString( consOperaciones.getRegPat()) );
			filtro.setFolioSUA( UtilData.toString( consOperaciones.getFolioSUA()) );
		}
		if( getValLineaCaptura(idProducto) ) {
			filtro.setLineaCaptura( UtilData.toString( consOperaciones.getLineaCaptura()) );
		}
		if( getValHoraProgram(idProducto) ) {
			String horaProg = UtilData.toString( consOperaciones.getHoraProgramacion() );
			if(!"todos".equalsIgnoreCase( horaProg) ) {
				filtro.setHoraProgramacion( horaProg );
			}
		}
		if( getValNomBeneficiario(idProducto) ) {
			filtro.setNombreBeneficiario( UtilData.toString( consOperaciones.getNombreBeneficiario()) );
		}
		if( !"11".equals( idProducto ) && !"93".equals( idProducto ) ) {
			filtro.setImporte( UtilData.toString( consOperaciones.getImporte()) );
			filtro.setReferencia( UtilData.toString( consOperaciones.getReferencia()) );
			filtro.setCuentaCargo( UtilData.toString( consOperaciones.getCuentaCargo()) );
		}
		if( getValCuentaAbono(idProducto) ) {
			filtro.setCuentaAbono( UtilData.toString( consOperaciones.getCuentaAbono()) );
		}
		return filtro;
	}
	
	
	/**
	 * Operaciones que llevan Nombre de Beneficiario
	 * 
	 * @param idProducto
	 * @return
	 */
	private static boolean getValNomBeneficiario(String idProducto) {
		return ("40".equals( idProducto ) || "80".equals( idProducto ) || "85".equals( idProducto ));
	}


	/**
	 * Operaciones que llevan Hora de Programacion
	 * 
	 * @param idProducto
	 * @return
	 */
	private static boolean getValHoraProgram(String idProducto) {
		return ("29".equals( idProducto ) || "02".equals( idProducto ) || "99".equals( idProducto ));
	}


	/**
	 * Operaciones que llevan linea de Captura
	 * 
	 * @param idProducto
	 * @return
	 */
	private static boolean getValLineaCaptura(String idProducto) {
		return ("21".equals( idProducto ) || "22".equals( idProducto ) || "23".equals( idProducto ));
	}


	/**
	 * Validamos que solo se aplique para consultas con Cuenta Abono
	 * 
	 * @param idProducto
	 * @return
	 */
	private static boolean getValCuentaAbono(String idProducto) {
		return (!"11".equals( idProducto ) 
			&& !"93".equals( idProducto ) 
			&& !"85".equals( idProducto ) 
			&& !"36".equals( idProducto )
		); 
	}
	
	
	/**
	 * Metodo para enmascarar los datos
	 * @param datBean
	 * @param campo
	 * @return
	 */
	public static String getMascara(Object datBean, String campo) {
    	String datoTarjeta = "";
    	// Validamos si los datos del Bean son nulos
    	if( datBean == null ) {
    		return datoTarjeta;
    	}
    	// Seleccionamos el campo a extraer
		datoTarjeta = datBean.toString();
    	if( datoTarjeta.length() == 16 || "tarjeta".equals(campo)) {
    		datoTarjeta = ValidaCampos.aplicaFormatoEnmascarado(datoTarjeta, 4);
    	}
    	return datoTarjeta;
    }
}
