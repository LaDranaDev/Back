package mx.santander.h2h.monitoreo.model.response;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * MonitorProdOperacionesCompResponse.
 *
 * @author Jesus Soto Aguilar
 */
@Getter
@Setter
public class MonitorProdOperacionesCompResponse extends OperationsMonitorQueryResponse
        implements Serializable {

    /**
     * Declaracion de variable serialVersionUID del tipo long
     */
    private static final long serialVersionUID = 8432300729990300504L;

    /**
     * Declaracion de variable transSat del tipo String
     */
    private String transSat;

    /**
     * Declaracion de variable patente del tipo String
     */
    private String patente;

    /**
     * Declaracion de variable pedimento del tipo String
     */
    private String pedimento;

    /**
     * Declaracion de variable aduana del tipo String
     */
    private String aduana;

    /**
     * Linea de Captura (completa).
     */
    private String lineaCaptura;

    /**
     * Descripcion error
     */
    private String descError;
}
