package mx.santander.h2h.monitoreo.exception.commons;

/**
 * Clase que es usada cuando se utiliza o sucede una exception personalizada
 *
 * @author Paul Quintero
 * @since 10/05/2022
 */
public class BusinessException extends RuntimeException {
	/**
	 * SERIE UID
	 */
	private static final long serialVersionUID = -7705918775554007593L;

	/** Código de error. */
	private final String code;

	/** Constructor de la clase. */
	public BusinessException() {
		super();
		this.code = null;
	}

	/**
	 * Constructor de la clase.
	 *
	 * @param message mensaje de error
	 */
	public BusinessException(String message) {
		super(message);
		this.code = null;
	}

	/**
	 * Constructor de la clase.
	 *
	 * @param code    código de error
	 * @param message mensaje de error
	 */
	public BusinessException(String code, String message) {
		super(message);
		this.code = code;
	}

	/**
	 * Obtiene el código de error
	 *
	 * @return código de error
	 */
	public String getCode() {
		return code;
	}
}
