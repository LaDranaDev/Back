package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.MonitorArchivosEnCursoRequest;

import mx.santander.h2h.monitoreo.model.response.MonitorDeArchivosEnCursoResponse;

/**
 * Servicio para el Tracking de Archivos
 *
 * @author Daniel Ruiz
 * @since 19/04/2023
 */
public interface IMonitorArchivosEnCursoService {

    /**
     * Obtiene detalles de los archivos en curso.
     * @param fecha Date Fecha de búsqueda.
     * @param codCliente String Codio del cliente.
     * @return Bean con los totales de archivos
     */
	MonitorDeArchivosEnCursoResponse consultaNivelProducto(String idArchivo, Integer idProducto, Integer idEstatus);

	/**
	 * consultaNivelOperacion
	 * @param idArchivo String
	 * @param idProducto Integer
	 * @param idEstatus Integer
	 * @return MonitorDeArchivosEnCursoResponse
	 */
	MonitorDeArchivosEnCursoResponse consultaNivelOperacion(String idArchivo, Integer idProducto, Integer idEstatus);

	/**
	 * consultaNivelOperacionHistorica
	 * @param idReg String
	 * @return MonitorDeArchivosEnCursoResponse
	 */
	MonitorDeArchivosEnCursoResponse consultaNivelOperacionHistorica(String idReg);

	/**
	 * getReportXls
	 * @param archivosEnCurso MonitorArchivosEnCursoRequest
	 * @param user String
	 * @return ReportResponse
	 */
	ReportResponse getReportXls(MonitorArchivosEnCursoRequest archivosEnCurso, String user);

}
