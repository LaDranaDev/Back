package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.response.ArchivoDetalleResponse;

import java.util.List;

/**
 * EntityManager para el Tracking de Archivos
 *
 * @author Daniel Ruiz
 * @since 19/04/2023
 */
public interface IArchivoEntityManagerRepository {

    /**
     * Obtiene el detalle del archivo de acuerdo al estatus
     * @param fecha LocalDate
     * @param codCliente String
     * @param codEstatus String
     * @param nomArch String
     * @return Lista con los beans de resultado
     */
    List<ArchivoDetalleResponse> detalleArchivos(
            String fecha,
            String codCliente,
            String nomArch,
            Integer codEstatus
    );

}
