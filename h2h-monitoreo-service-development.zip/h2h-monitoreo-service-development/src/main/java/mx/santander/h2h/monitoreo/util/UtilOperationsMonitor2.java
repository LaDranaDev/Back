/**
* Santander SCIB - Banco Santander Negocios Globales
* Todos los derechos reservados
* UtilOperationsMonitor2.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <4 jul. 2024 12:25:03>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.util;

import mx.santander.h2h.monitoreo.constants.MonitorOperacionesConstants;

public class UtilOperationsMonitor2 {
	/**
	 * Metodo Getter para cadValidacion.
	 *
	 * @param cveOperProd para cve oper prod
	 * @return cadValidacion cad validacion
	 */
	public static void getCadValidacion(final StringBuilder query, String cveOperProd) {
		// Validan si la clave de Producto es 31 o 33
		if ("31".equals(cveOperProd) || "33".equals(cveOperProd)) {
			query.append("DETA.NUM_CTA_BENE NUN_CTA_ABONO, CVE_PROD_OPER, PROD.DESC_PROD, ");
		} else {
			query.append("TMP.CNTA_ABON NUN_CTA_ABONO, PROD.CVE_PROD_OPER, PROD.DESC_PROD, ");
		}
		query.append("TMP.NOMBRE_ARCH, ");
		if ("21".equals(cveOperProd) 
				|| "22".equals(cveOperProd) 
				|| "23".equals(cveOperProd)) {
			query.append("DETA.REFE_MOV REFERENCIA, ");
		} else if ("31".equals(cveOperProd)) {
			query.append("DETA.TXT_REF REFERENCIA, ");
		} else if ("33".equals(cveOperProd)) {
			query.append("to_char(DETA.NUM_ORDEN) REFERENCIA, ");
		} else {
			query.append("TMP.REFE_BE REFERENCIA, ");
		}
	}
	
	
	/**
	 * Metodo Getter para validacionCve.
	 *
	 * @return validacionCve validacion cve
	 */
	public static void getValidacionCve(
			final StringBuilder query, 
			String cveOperProd) {
		if ("01".equals(cveOperProd) 
				|| "97".equals(cveOperProd)
				|| "02".equals(cveOperProd)) { /** SPEI - TEF - Nomina Interbancaria */
			UtilOperationsMonitor.agrega01y97y02(query);
		} else if ("80".equals(cveOperProd) 
				|| "81".equals(cveOperProd)) { /** ORDEN DE PAGO */
			UtilOperationsMonitor.agrega80y81(query);
		} else if ("95".equals(cveOperProd) 
				|| "96".equals(cveOperProd)) { /** Alta Cuenta Beneficiarias */
			UtilOperationsMonitor.agrega95y96(query);
		} else if ("98".equals(cveOperProd) 
				|| "99".equals(cveOperProd)) { /** TMB - Nomina Mismo Banco */
			UtilOperationsMonitor.agrega9y99(query);
		} else if ("91".equals(cveOperProd) 
				|| "93".equals(cveOperProd) 
				|| "30".equals(cveOperProd)
				|| "29".equals(cveOperProd)) { /** ALTA PAGO PROVEEDORES CONFIRMING */
			UtilOperationsMonitor.completaQueryProducto919330(query, cveOperProd, false);
		} else if ("21".equals(cveOperProd) 
				|| "22".equals(cveOperProd) 
				|| "23".equals(cveOperProd)) {
			UtilOperationsMonitor.agregaPifconsulta(query, cveOperProd);
		} else if ("31".equals(cveOperProd) 
				|| "33".equals(cveOperProd)) {
			UtilOperationsMonitor.agregaTIconsulta(query, cveOperProd);
		} else if ("40".equals(cveOperProd)) { /** PGODIRECT */
			UtilOperationsMonitor.agrega40(query);
		} else  {
			query.append(MonitorOperacionesConstants.NULL_INTERMEDIARIO_ORD_NULL_DIVISA_ORD)
				.append(MonitorOperacionesConstants.NULL_INTERMEDIARIO_REC_NULL_BENEFICIARIO)
				.append("NULL COMENTARIO_1, NULL COMENTARIO_2, ")
				.append(" NULL COMENTARIO_3, NULL TITULAR, NULL BANCO_RECEPTOR, ")
				.append("NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO, ")
				.append(MonitorOperacionesConstants.MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN)
				.append(" NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL,  ")
				.append(MonitorOperacionesConstants.NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA)
				.append(MonitorOperacionesConstants.NULL_BUC_EMPLEADO)
				.append(MonitorOperacionesConstants.NULL_SUCURSAL_TUTORA_NULL_RFC_NULL_TIPO)
				.append(MonitorOperacionesConstants.NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA);
		}
	}
}
