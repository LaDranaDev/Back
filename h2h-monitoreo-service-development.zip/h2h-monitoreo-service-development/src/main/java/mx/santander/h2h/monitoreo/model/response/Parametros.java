package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.Getter;
import lombok.Setter;

/**
 * Clase auxiliar para la definicion de estructura del archivo XML de entrada
 */
@XmlRootElement
@Getter
@Setter
public class Parametros implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7528368881229142836L;
	/**
	 * Listado de parametros informados
	 */
	private List<Parametro> parametros = new ArrayList<>();

	/**
	 * Retorna la lista de parametros
	 *
	 * @return Lista con objetos de tipo Parametro
	 */
	@XmlElement(name = "parametro")
	public List<Parametro> getParametros() {
		return parametros;
	}
}
