package mx.santander.h2h.monitoreo.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import mx.santander.h2h.monitoreo.constants.RoutesConstant;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.NivelArchivoRequest;
import mx.santander.h2h.monitoreo.model.request.NivelProductoRequest;
import mx.santander.h2h.monitoreo.model.response.ArchivoGeneralResponse;
import mx.santander.h2h.monitoreo.model.response.NivelArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.NivelGeneralResponse;
import mx.santander.h2h.monitoreo.model.response.NivelProductoResponse;
import mx.santander.h2h.monitoreo.model.response.ProductoArchivoResponse;
import mx.santander.h2h.monitoreo.service.IArchivoTrackingBService;
import mx.santander.h2h.monitoreo.service.IArchivoTrackingService;
import mx.santander.h2h.monitoreo.service.IConsultaTrackingProductoService;


@Validated
@RestController
@RequestMapping(RoutesConstant.ARCHIVO_TRACKING)
public class ArchivoTrackingController {

    @Autowired
    private IArchivoTrackingService service;
    
    @Autowired
    private IArchivoTrackingBService serviceB;
    
    @Autowired
    private IConsultaTrackingProductoService consultaTrackingProductoService;

    /**
     * 
     * @param codCliente
     * @return
     */
    @Operation(summary = "Consulta traking nivel general ")
	@GetMapping(path = "/inicio", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<NivelGeneralResponse> inicio(
			@Pattern(regexp = "(^[a-zA-Z0-9_ -]+$)?", message = "Datos de Cliente no valido")
			@Size(min = 0, max = 20, message = "Datos de Cliente erroneo")
			String codCliente) {
		return ResponseEntity.ok(this.service.inicio(codCliente));
	}
    
    /**
     * 
     * @param codCliente
     * @param page
     * @return
     */
    @Operation(summary = "Consulta traking nivel general")
	@GetMapping(path = "/obtenerDetalle", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ArchivoGeneralResponse> obtenerDetalleArchivos(
			@Pattern(regexp = "(^[a-zA-Z0-9_ -]+$)?", message = "Datos de Cliente no valido")
			@Size(min = 0, max = 20, message = "Datos de Cliente erroneo")
			String codCliente, 
			
			Pageable page) {
		return ResponseEntity.ok(this.serviceB.obtenerDetalleArchivos(codCliente, page));
	}
    
    /**
     * 
     * @param codCliente
     * @param usuario
     * @return
     */
    @Operation(summary = "Genera reporte en formato xls de Consulta tracking nivel general.")
	@GetMapping(path = "/xlsGeneral", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ReportResponse> getReportXlsDetalleNivelGeneral(
			@Pattern(regexp = "(^[a-zA-Z0-9_ -]+$)?", message = "Datos de Cliente no valido")
			@Size(min = 0, max = 20, message = "Datos de Cliente erroneo")
			String codCliente, 
			
			@Pattern(regexp = "(^[a-zA-Z0-9]+$)?", message = "Datos de usuario no valido")
			@Size(min = 0, max = 15, message = "Datos de Usuario erroneo")
			String usuario) {
		return ResponseEntity.ok(this.service.getReportXls(codCliente, usuario));
	}
    
    @Operation(summary = "Consulta traking nivel archivo")
	@GetMapping(path = "/consultaTrackingNivelArchivo", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<NivelArchivoResponse> obtenerDetalleArchivos(
			@Valid
			NivelArchivoRequest nivelArchivo) {
		return ResponseEntity.ok(this.serviceB.consultaTrakingNivelArchivo(nivelArchivo));
	}
    
    @Operation(summary = "Consulta traking nivel archivo")
   	@GetMapping(path = "/obtenerDetalleNivelArchivo", produces = MediaType.APPLICATION_JSON_VALUE)
   	public ResponseEntity<Map<String, Object>> obtenerDetalleArchivoNivelArchivo(
			@Valid
			NivelArchivoRequest nivelArchivo, Pageable page) {
   		return ResponseEntity.ok(this.serviceB.obtenerDetalleArchivosNivelArchivo(nivelArchivo, page));
   	}
    
    @Operation(summary = "Genera reporte en formato xls de Consulta tracking nivel archivo.")
	@GetMapping(path = "/xlsArchivo", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ReportResponse> getReportXlsDetalleNivelArchivo(
			@Valid
			NivelArchivoRequest nivelArchivo, 
			
			@Pattern(regexp = "(^[a-zA-Z0-9]+$)?", message = "Datos de usuario no valido")
			@Size(min = 0, max = 15, message = "Datos de Usuario erroneo")
			String usuario) {
		return ResponseEntity.ok(this.serviceB.getReportXls(nivelArchivo, usuario));
	}
    
    /**
     * 
     * @param nivelProducto
     * @return
     */
    @Operation(summary = "Consulta traking nivel producto")
	@GetMapping(path = "/iniciaNivelProducto", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<NivelProductoResponse> iniciaNivelProducto(
			@Valid
			NivelProductoRequest nivelProducto) {
		return ResponseEntity.ok(this.consultaTrackingProductoService.iniciaNivelProducto(nivelProducto));
	}
    
    /**
     * 
     * @param nivelProducto
     * @param page
     * @return
     */
    @Operation(summary = "Consulta traking nivel detalle archivo nivel producto")
	@GetMapping(path = "/nivelProductoDetalle", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Page<ProductoArchivoResponse>> obtenerDetalleArchivosNivelProducto(
			@Valid
			NivelProductoRequest nivelProducto, Pageable page) {
		return ResponseEntity.ok(this.consultaTrackingProductoService.obtenerDetalleArchivo(nivelProducto, page));
    }
    
    @Operation(summary = "Genera reporte en formato xls de Consulta tracking nivel producto.")
	@GetMapping(path = "/xlsProducto", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ReportResponse> getReportXlsDetalleNivelProducto(
			@Valid
			NivelProductoRequest nivelProducto, 
			
			@Pattern(regexp = "(^[a-zA-Z0-9]+$)?", message = "Datos de usuario no valido")
			@Size(min = 0, max = 15, message = "Datos de Usuario erroneo")
			String usuario) {
		return ResponseEntity.ok(this.consultaTrackingProductoService.getReportXls(nivelProducto, usuario));
	}
}
