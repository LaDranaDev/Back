package mx.santander.h2h.monitoreo.model.request;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * clase para el request de la cancelacion de una operación
 * Implementaa la interfas de serializcion para el traspaso entre capas
 * Adicional se implementan las etiquetas lombok de
 * Geter, Seter,
 * para un desarrollo más rapido y con menos codigo.
 * @author NTTDATA-NRL
 * @version 1.0
 */
@Getter
@Setter
public class CancelOperationRequest implements Serializable {

    /**
     * Serial verion UID
     */
    private static final long serialVersionUID = -5901716007998912174L;

    /**
     * Codifo de cliente
     */
    private String codigoClienteEnc;
    /**
     * Folio del contrato
     */
    private String hdnContratoFolio;
    /**
     * Catatlogo estatus
     */
    private String catalogoEstCntr;
    /**
     * Codigo de cliente
     */
    private String codigoCliente;
    /**
     * idRegistro
     */
    private String idRegistro;
}
