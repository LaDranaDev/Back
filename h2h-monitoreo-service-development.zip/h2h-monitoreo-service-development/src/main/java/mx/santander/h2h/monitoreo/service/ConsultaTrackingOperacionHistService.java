package mx.santander.h2h.monitoreo.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.NivelOperacionHistRequest;
import mx.santander.h2h.monitoreo.model.response.NivelOperacionHistResponse;
import mx.santander.h2h.monitoreo.model.response.OperacionArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ProductoArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ResultTrackingResponse;
import mx.santander.h2h.monitoreo.repository.IConsultaTrackingOperacionHistRepository;

@Service
@Slf4j
public class ConsultaTrackingOperacionHistService implements IConsultaTrackingOperacionHistService {

	@Autowired
	private IConsultaTrackingOperacionHistRepository consultaTrackingOperacionHistRepository;
	
	/**
	 * Servicio para generacion de Reportes con JasperReport
	 */
	@Autowired
	private IJasperReportService jasperReportService;
	
	@Override
	public NivelOperacionHistResponse iniciaNivelOperacionHist(NivelOperacionHistRequest nivelOperacionHistRequest) {
		NivelOperacionHistResponse nivelOperacionResponse = new NivelOperacionHistResponse();
		
		nivelOperacionResponse.setCliente(nivelOperacionHistRequest.getNomCliente());
		nivelOperacionResponse.setFecha(new SimpleDateFormat("dd/MM/yyyy").format(new Date()));
		nivelOperacionResponse.setIdReg(nivelOperacionHistRequest.getIdReg());
		
		ProductoArchivoResponse encabezado = obtenerConteoArchivo(nivelOperacionHistRequest.getIdReg());
		
		nivelOperacionResponse.setNomArch(encabezado.getNombreArchivo());
		nivelOperacionResponse.setEstatusArch(encabezado.getEstatus());
		nivelOperacionResponse.setProducto(encabezado.getProducto());
		
		return nivelOperacionResponse;
	}
	
	@Override
	public ProductoArchivoResponse obtenerConteoArchivo(Integer idReg) {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		resultTrackingResponse = consultaTrackingOperacionHistRepository.obtenerConteoArchivo(idReg);
		return resultTrackingResponse.getArchProd();
	}
	
	@Override
	public Page<OperacionArchivoResponse> obtenerDetalleArchivo(Integer idReg, Pageable page) {
		return consultaTrackingOperacionHistRepository.obtenerDetalleArchivo(page, idReg);
	}

	@Override
	public List<OperacionArchivoResponse> obtenerListDetalleArchivo(Integer idReg) {
		return consultaTrackingOperacionHistRepository.obtenerListDetalleArchivo(idReg);
	}

	@Override
	public ReportResponse getReportXls(NivelOperacionHistRequest nivelOperacionHistRequest, String usuario) {
		ReportResponse response = new ReportResponse();
		try {
			NivelOperacionHistResponse bean = this.iniciaNivelOperacionHist(nivelOperacionHistRequest);
			List<OperacionArchivoResponse> lista = this.obtenerListDetalleArchivo(bean.getIdReg());
			Map<String, Object> reportParam = new HashMap<>();
			
			reportParam.put("LOGO_SANTANDER", "\\imgs\\Santander.jpg");
			reportParam.put("TITULO_REPORTE", "Consulta Tracking de Archivo" + " - " + "Nivel Operación Histórica");
           
			reportParam.put("USER", usuario);
			reportParam.put("FILTRO_CLIENTE", "Cliente:");
			reportParam.put("cliente", bean.getCliente());
            reportParam.put("FILTRO_ARCHIVO", "Nombre Archivo:");
            reportParam.put("nomArch", bean.getNomArch());
            reportParam.put("FILTRO_ESTATUS", "Estatus Archivo:");
            reportParam.put("estatusArch", bean.getEstatusArch());
            reportParam.put("FILTRO_PRODUCTO", "Producto:");
            reportParam.put("producto", bean.getProducto());
            reportParam.put("FILTRO_MOVIMIENTOS", "Id. Movimiento H2H:");
            reportParam.put("idReg", "" + bean.getIdReg());
 
            log.info("VALOR_MOVIMIENTOS::::::::::::" + String.valueOf(bean.getIdReg()));
            
            reportParam.put("ESTATUS_INICIAL","Estatus Inicial");
            reportParam.put("ESTATUS_FINAL","Estatus Final");
            reportParam.put("FECHACAMBIO","Fecha Cambio");
			
			response = jasperReportService.getXls("NivelHistorico.jasper", reportParam, lista);
			
			response.setType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
		}catch (BusinessException e) {
			log.error("Error en la generacion del reporte en xls operacion historica.", e);
			throw e;
		} finally {
			log.info("Fin operacion: Genera reporte en xls operacion historica");
		}
		
		return response;
	}
	
}
