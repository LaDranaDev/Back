package mx.santander.h2h.monitoreo.model.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * MonitorSaldosResponse.
 * Objeto de respuesta que contiene la informacion de los saldos reintentos.
 *
 * @author Jesus Soto Aguilar
 * @since 20/04/2023
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MonitorSaldosResponse implements Serializable {

    /**
     * Serial.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Cuenta Ordenante.
     */
    private String cuentaOrdenante;

    /**
     * Fecha envio consulta.
     */
    private String fechaEnvioConsulta;

    /**
     * Hora envio consulta.
     */
    private String horaEnvioConsulta;

    /**
     * Monto requerido.
     */
    private String montoRequerido;

    /**
     * Saldo Consulta.
     */
    private String saldoConsulta;

    /**
     * Saldo faltante.
     */
    private String saldoFaltante;

    /**
     * Linea credito.
     */
    private String lineaCredito;

    /**
     * Nombre archivo
     */
    private String nombreArchivo;

    /**
     * Clave producto.
     */
    private String cveProdOper;

    /**
     * Descripcion producto.
     */
    private String producto;
}
