package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Dto para los datos de salida del PUT/GET
 * 
 * @author Z483900
 *
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class PutGetRestResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1563154287487638980L;

	/**
	 * idcntrPutGet
	 */
	private String idcntrPutGet;

	/**
	 * CntrPutget
	 */
	private String cntrPutget;

	/**
	 * CltePutget
	 */
	private String cltePutget;

	/**
	 * tipoOperPG
	 */
	private String tipoOperPG;

	/**
	 * idPtclPara
	 */
	private String idPtclPara;

	/**
	 * protocolos
	 */
	private List<PutGetDto> protocolos;

	/**
	 * lista protocolos
	 */
	private List<ProtocolResponse> lstProtocolos;

	/**
	 * protocoloActivo
	 */
	private String protocoloActivo;

	/**
	 * idProtocolo
	 */
	private String idProtocolo;

	/**
	 * idProtocoloPath1
	 */
	private String idProtocoloPath1;

	/**
	 * idProtocoloPath2
	 */
	private String idProtocoloPath2;

	/**
	 * mensaje de error o éxito, MSG_ERR
	 */
	private String MSG_ERR;

	/**
	 * Objeto putGetResponse
	 */
	private PutGetServiceResponse putGetResponse;

}
