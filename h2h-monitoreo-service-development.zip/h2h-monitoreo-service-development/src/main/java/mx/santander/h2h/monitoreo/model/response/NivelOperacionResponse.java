package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NivelOperacionResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8981292557105288081L;
	
	/** Codigo del cliente. */
	private String codCliente;
	
	/** Cliente. */
	private String cliente;
		
	/** Id del archivo. */
	private Integer idArchivo;
	
	/** Id del archivo. */
	private String nomArch;
	
	/** Id del archivo. */
	private String estatusArch;
	
	/** Id del archivo. */
	private String producto;
	
	/** Id del producto. */
	private Integer idProducto;
	
	/** Fecha de consulta. */
	private Date fechaActual;
	
	/** Fecha de consulta. */
	private String fecha;
	
	/** Id del estatus. */
	private Integer identEstatus;
	
	/** Lista de estatus operacion. */
	private List<ComboResponse> listEstatus;
	
	/** Datos del archivo. */
	private ProductoArchivoResponse archivo;

}
