package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Clase encargada de definir los datos de entrada de notificaciones
 * 
 * @author emendoza
 * @since 12/04/2023
 */
@Getter
@Setter
@NoArgsConstructor
@ToString
public class MonitorDeArchivosEnCursoDetallesResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Identificador de idArchivo
	 */
	private String idArchivo;
	/**
	 * Identificador de numContrato
	 */
	private String numContrato;
	/**
	 * Identificador de nombreArch
	 */
	private String nombreArch;
	/***
	 * Identificador de fechaOrder
	 */
	private String fechaOrder;
	/***
	 * Identificador de fechaRegistro 
	 */
	private String fechaRegistro;
	/***
	 * Identificador de idEstatus
	 */
	private Integer idEstatus;
	/***
	 * Identificador de descEstatus
	 */
	private String descEstatus;
	/***
	 * Identificador de idProd
	 */
	private String idProd;
	/***
	 * Identificador de idClte  
	 */
	private String idClte;
	/***
	 * Identificador de cliente 
	 */
	private String cliente;
	/***
	 * Identificador de razonScia 
	 */
	private String razonScia;
	/***
	 * Identificador de buc 
	 */
	private String buc;
	/***
	 * Identificador de descProd 
	 */
	private String descProd;
	/***
	 * Identificador de nombCanl 
	 */
	private String nombCanl;
	/***
	 * Identificador de motiRech 
	 */
	private String motiRech;
	/***
	 * Identificador de totalOper 
	 */
	private Integer totalOper;
	/***
	 * Identificador de totalMont 
	 */
	private BigDecimal totalMont;
	/***
	 * Identificador de totalMont 
	 */
	private String totalMontFormat;

	@JsonIgnore
	private String cveProdOper;
}
