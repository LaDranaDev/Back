package mx.santander.h2h.monitoreo.constants;

/**
 * Constantes para los reportes
 *
 * @author Paul Quintero
 * @since 23/05/2022
 */
public final class ReportConstants {
	/**
	 * Formato pdf.
	 */
	public static final String PDF_FORMAT = "pdf";
	/**
	 * Formato excel
	 */
	public static final String EXCEL_FORMAT = "excel";
	/**
	 * Formato excel
	 */
	public static final String RTF_FORMAT = "rtf";
	/**
	 * Ruta del logotipo santander para la generación de reportes
	 */
	public static final String SANTANDER_LOGO = "imgs/Santander.jpg";
	/**
	 * Ruta raiz para la ubicación de los reportes
	 */
	public static final String REPORTS_FOLDER = "reports/";

	/**
	 * Nombre del parametro para el logo de santander
	 */
	public static final String PARAM_LOGO_SATANDER = "logoSantander";
	/**
	 * Extension de archivo tipo pdf
	 */
	public static final String PDF_EXTENTION = ".pdf";
	/**
	 * Extension de archivo tipo XLSX
	 */
	public static final String XLSX_EXTENTION = ".xlsx";
	/**
	 * Extension de archivo tipo XLSX
	 */
	public static final String RTF_EXTENTION = ".rft";
	/**
	 * Extension de archivo tipo jasper
	 */
	public static final String JASPER_EXTENTION = ".jasper";

	/**
	 * Nombre del reporte del monitor de saldos.
	 */
	public static final String MONITOR_SALDOS_REPORT_XLSX = "reporteMonitorSaldos.jasper";

	/**
	 * Nombre del subreporte del monitor de saldos.
	 */
	public static final String MONITOR_SALDOS_SUBREPORT_XLSX = "subReporteMonitorSaldos.jasper";

	/**
	 * Nombre del archivo con la informacion del reporte.
	 */
	public static  final String NOMBRE_REPORTE_MONITOR_SALDOS = "Saldos";

	public static final String REPORTE_ARCHIVO = "reporteArchivo.jasper";
	/**
	 * Nombre del reporte del monitor de operaciones.
	 */
	public static final String REPORT_MON_OPER = "rptMonOperReport.jasper";
	/**
	 * Parametro con el nombre del jasper report
	 */
	public static final String PARAM_NAME_REPORT = "name";

	/**
	 * Parametro con el tipo de archivo
	 */
	public static final String PARAM_MIME_TYPE = "mimeType";
	/**
	 * Nombre del reporte de comprobantes CDMX excel
	 */
	public static final String REPORTE_COMPROBANTES_CDMX = "ComprobantesCDMX.jasper";

	/**
	 * Nombre del reporte de comprobantes CDMX sub excel
	 */
	public static final String REPORTE_COMPROBANTES_CDMX_SUB = "ComprobantesCDMXSub.jasper";

	/**
	 * Constructor privado para una clase de solo constantes
	 */
	private ReportConstants() {
	}
}
