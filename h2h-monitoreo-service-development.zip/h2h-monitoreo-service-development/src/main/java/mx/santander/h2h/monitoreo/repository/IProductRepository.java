package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.constants.ProductosConstants;
import mx.santander.h2h.monitoreo.constants.QueryConstant;
import mx.santander.h2h.monitoreo.model.entity.ProductEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * IProductRepository.
 * Permite ejecutar consultas a la tabla de Productos.
 *
 * @author Jesus Soto Aguilar
 * @since 20/04/2023
 */
public interface IProductRepository extends JpaRepository<ProductEntity, Long> {

    /**
     * Consulta los productos activos y visibles
     * @return
     */
    @Query(ProductosConstants.QUERY_FIND_PRODUCTOS)
    List<ProductEntity> findProductos();

    ProductEntity findByCveProdOper(String claveProducto);

    /**
     * Consulta control de producto
     * @param contractNumber numero de contrato
     * @return List<Object[]>
     */
    @Query(nativeQuery = true, value = QueryConstant.GET_PRODUCT_BY_CONTRACT)
    List<Object[]> findByCntrProdcuto(@Param("contractNumber") String contractNumber);
}
