package mx.santander.h2h.monitoreo.util;

import java.util.HashMap;
import java.util.Map;

import org.owasp.encoder.Encode;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;

@Slf4j
public class UtilOrdenesPagoAtmDatosExportar {
    /**
     * Constante para la seleccion del
     * Monotor de operaciones
     * CANL_NOMB_CANL
     */
    private static final String CANL_NOMB_CANL=" CANL.NOMB_CANL ";

    /**
     * Constante para la exportacion
     *  del Monotor de operaciones
     * PART_QUERY_EXP_NULL´s
     */
    private static final String PART_QUERY_EXP_NULL="NULL BUC_EMPLEADO,NULL SUCURSAL_TUTORA,NULL RFC,NULL TIPO,NULL NOMBRE_EMPLEADO,  ";

    /**
     * Constante para la exportacion
     *  del Monotor de operaciones
     * PART_QUERY_EXP_FECH_APLI_FECHA_OPERACION
     */
    private static final String PART_QUERY_EXP_FECH_APLI_FECHA_OPERACION="NULL NUMERO_CUENTA,TMP.FECH_OPER FECHA_PRESENTACION_INICIAL, TMP.FECH_APLI FECHA_OPERACION  ";
    /**
     * Mapa para contener los diferentes queryes dependiendo
     * los productos segun la tabla enviada
     */
    private static Map<String, String> campos= new HashMap<>();

    /**
     * Tabla para los campos
     * del Query principal
     */
    private static Map<String,String> tablasSelCampos = new HashMap<>();

    /**
     * Tabla para los campos
     * del Query de la exportacion
     * de datos del monitor
     * de operaciones
     */
    private static Map<String,String> tablasSelCamposExpMonitor= new HashMap<>();
    /**
     * constante para el query de
     * consulta del monitor de
     * operaciones por producto
     * SELECT_IDREG_BUC_NUMCTA_CARG
     *
     */
    private static final String SELECT_IDREG_BUC_NUMCTA_CARG="REG.ID_REG, CLTE.BUC, REG.CNTA_CARG NUM_CTA_CARGO, ";
    /**
     * Parte del Query para el acceso a datos
     * del detalle a exportar del producto
     * de Transferencias Internacionales Cambiarias
     *
     */
    private static final StringBuilder QUERY_MONITOR_CAMPOS_ORDEN_PAGO_ATM=new StringBuilder(SELECT_IDREG_BUC_NUMCTA_CARG)
    		.append("'' NUN_CTA_ABONO, PROD.CVE_PROD_OPER, PROD.DESC_PROD,")
            .append("ARCH.NOMBRE_ARCH, DECODE( PROD.CVE_PROD_OPER,85 , DECODE(REG.REFE_BE,null,'' ,'****'|| SUBSTRB(REG.REFE_BE,-4,4)), REG.REFE_BE) REFERENCIA, REG.ID_ESTATUS,")
            .append("EST.DESC_ESTATUS, DETA.IMPO_GIRO IMPORTE, CNTR.NUM_CNTR, 'MXP' DIVISA,")
            .append("DETA.FECHA_PROC FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, REG.NUM_EMAIL, ")
            .append(CANL_NOMB_CANL)
            .append(", DETA.NOMB_BENE  BENEFICIARIO,DETA.NUM_ORDN NUM_ORDEN ");

    /**
     * Parte del Query para el acceso a datos
     * del detalle a exportar del producto
     * de Transferencias Vostro Mismo Banco
     * TVMB
     */
    private static final StringBuilder QUERY_EXP_MONITOR_OREDENES_PAGO_ATM=new StringBuilder("")
            .append("NOMB_CANL, ID_REG, CLTE.BUC, TMP.CNTA_CARG NUM_CTA_CARGO,null NUN_CTA_ABONO, ")
            .append("PROD.CVE_PROD_OPER, PROD.DESC_PROD,TMP.NOMBRE_ARCH,DETA.REFE_CTE REFERENCIA,TMP.ID_ESTATUS, EST.DESC_ESTATUS DESC_ESTATUS, ")
            .append("DETA.IMPO_GIRO IMPORTE, CNTR.NUM_CNTR, TMP.DIVI DIVISA,DETA.FECH_REG FECHA_REGISTRO, TMP.FECH_APLI FECHA_APLICACION,")
            .append("PROD.VIST_PROD,' ' INTERMEDIARIO_ORD,null DIVISA_ORD,null INTERMEDIARIO_REC, (DETA.NOMB_BENE) BENEFICIARIO,")
            .append("null COMENTARIO_1,to_char(ID_REG) COMENTARIO_2,NULL COMENTARIO_3, null TITULAR, NULL BANCO_RECEPTOR, ")
            .append("'E' TIPO_PAGO, NULL MODALIDAD,null IMPORTE_CARGO, MSG.MSG_H2H MSG_H2H, NULL MSG_ORDEN_PAGO, ")
            .append("DETA.NUM_ORDN NUM_ORDEN,FECH_LIMI_LIQ FECHA_LIMITE_PAGO,NULL NUM_SUCURSAL,NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA,  ")
            .append(PART_QUERY_EXP_NULL)
            .append(PART_QUERY_EXP_FECH_APLI_FECHA_OPERACION);
    
    
    /**
     * inicializacion del mapa de productos
     * LFER 09-03-2018
     */
     static {
        campos.put("85", "H2H_MX_PROD_ORDN_PAGO_ATM");
        tablasSelCampos.put("85", QUERY_MONITOR_CAMPOS_ORDEN_PAGO_ATM.toString());
        tablasSelCamposExpMonitor.put("85", QUERY_EXP_MONITOR_OREDENES_PAGO_ATM.toString());
    }
    
    
    /**
     *
     * @param tipoOper
     * @return
     */
    public static boolean esOrdenPago(String tipoOper) {
        if(tipoOper==null ||tipoOper.isEmpty()){
            return false;
        }
        return tipoOper.toUpperCase().contains("85");
    }

    
    /**
     *
     * @param cveOperProd
     * @param query
     */
    public static String getQuerySelectExportar(final String cveOperProd, StringBuilder queryS) {
    	StringBuilder query = new StringBuilder();
        if(esOrdenPago(cveOperProd)){
            queryS.setLength(0);
            query.append("SELECT PROD.* FROM (SELECT ");
            query.append( tablasSelCamposExpMonitor.get(cveOperProd));
        }
        return query.toString();
    }
    
    
    /**
	 * agrega select para los 
	 * productos de Vostro e
	 * internacionales cambiarias
	 * @param tresMeses
	 * @param consultaOperaciones
	 * @return
	 */
	public static String generaQueryProductosOrdenPagoatm(
			boolean tresMeses,
			OperationsMonitorQueryRequest consultaOperaciones) {
		StringBuilder query= new StringBuilder();
		log.info("*****generaQueryProductosVostro*****>"+Encode.forJava(consultaOperaciones.getIdProducto()));
		 query
		 .append("SELECT '") 
		 	.append(getTablaPorCveProdOp(tresMeses,consultaOperaciones.getIdProducto()))
		 	.append("' TABLA,")
			.append(getTablasSelCampos().get(consultaOperaciones.getIdProducto()))
			.append(" FROM ")
			.append(getTranop("H2H_REG",tresMeses))
			.append(" REG ")
			.append(" INNER JOIN ")
			.append(getTranop("H2H_ARCHIVO",tresMeses))
			.append(" ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ")
			.append("INNER JOIN H2H_CNTR CNTR USING (ID_CNTR)  INNER JOIN H2H_CLTE CLTE USING (ID_CLTE) ")
			.append(" INNER JOIN H2H_CAT_PROD PROD  ON PROD.CVE_PROD_OPER = REG.CVE_PROD_OPER ")
			.append("INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS ")
			.append("INNER JOIN H2H_CAT_CANL CANL ON ARCH.ID_CANL = CANL.ID_CANL ")
		    .append(" INNER JOIN ")
		    .append(getTablaPorCveProdOp(tresMeses, consultaOperaciones.getIdProducto()))
		    .append(" DETA ON REG.ID_REG=DETA.ID_REG ");
		 return query.toString();
	}
	
	
	/**
	 * Metodo para obtener la 
	 * tabla segun la clave prod oper
	 * que se ingresa 
	 * @param tresMeses
	 * @param idProducto
	 * @return
	 */
	public static String getTablaPorCveProdOp(boolean tresMeses, String idProducto) {
		return getTranop(campos.get(idProducto), tresMeses);
	}
	
	
	/**
	 * concatena el tran 
	 * para las tablas de
	 * tres meses
	 * @param tabla
	 * @param tresMeses
	 * @return
	 */
	public static String getTranop(String tabla, boolean tresMeses) {
		String tablain=tabla;
		if(tresMeses){
			tablain+="_TRAN";
		}
		return tablain;
	}


	public static Map<String,String> getTablasSelCampos() {
		// Validamos si los valores de las tablas son Vacios
		if( tablasSelCampos.isEmpty() ) {
			// Agregamos los datos en el Mapa
			tablasSelCampos.put("85", QUERY_MONITOR_CAMPOS_ORDEN_PAGO_ATM.toString());
		}
		return new HashMap<>(tablasSelCampos) ;
	}


	public static void setTablasSelCampos(Map<String,String> tablasSelCampos) {
		if (tablasSelCampos == null)
			throw new IllegalArgumentException("Parametros agregados es null");
		UtilOrdenesPagoAtmDatosExportar.tablasSelCampos.clear();
		UtilOrdenesPagoAtmDatosExportar.tablasSelCampos.putAll(tablasSelCampos);
	}
}
