package mx.santander.h2h.monitoreo.model.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * Clase para almacenar los totales de la consulta de MO.
 * 
 * @author sbautish
 *
 */
@Getter
@Setter
@ToString
public class GenerateVouchersTotalResponse implements Serializable {

	private static final long serialVersionUID = 7588100271253518747L;

	/** Número de correos enviados. */
	private String correosEnviados;

	/** Total de archivos. */
	private String totalArchivos;

	/** Importe Global. */
	private String importeGlobal;

}
