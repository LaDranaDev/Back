package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.response.OperationsMonitorCatalogsResponse;

public interface IOperationsMonitorComplementEntityManagerRepository {
	
	/**
     * Consulta la lista de divisas, estatus y productos
     * @return Response de catálogos
     */
    OperationsMonitorCatalogsResponse catalogs();

}
