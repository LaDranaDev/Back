/**
* Santander SCIB - Banco Santander Negocios Globales
* Todos los derechos reservados
* UtilMonitorFnc.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <5 jul. 2024 17:12:53>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.util;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.constants.MonitorOperacionesConstants;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.repository.MonitorOperacionesRepository;


/**
 * Clase generada para UtilMonitorFnc.
 *
 * @autor C320868
 * @modifico C320868
 */
@Component
@Slf4j
public class UtilMonitorFnc {
	
	/** Declaracion de Constante SQL_NUMROW. */
	private static final String SQL_NUMROW = "SELECT * FROM ( SELECT A.*, ROWNUM ROW_NUMBER FROM ( ";
	
	/** Declaracion de Constante SQL_CONDITION. */
	private static final String SQL_CONDITION = " + 1)) WHERE ROW_NUMBER >= (";
	
	/** Declaracion de Constante SQL_WHERE. */
	private static final String SQL_WHERE = ") A WHERE ROWNUM < (";
	
	
	/**
	 * Metodo para obtener un valor Llave dentro de un Mapa.
	 *
	 * @param miArreglo para mi arreglo
	 * @return array array
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, Object> getArray(Map<String, Object> miArreglo) {
		Map<String, Object> respFnc = new HashMap<String, Object>();
		// Validamos que el arreglo contenga datos
		if( miArreglo != null ) {
			// Validamos que contenga la llave
			if( miArreglo.containsKey("params") ) {
				respFnc = ((Map<String, Object>) miArreglo.get("params"));
			}
		}
		return respFnc;
	}

	
	/**
	 * Metodo para cambiar el tipo de moneda y devolver una cadena
	 * 
	 * @param moneda
	 * @param tipo
	 * @return
	 */
	public static void cadDivisa(StringBuilder cadResp, String moneda, String tipo, Map<String, Object> params, boolean someFilter) {
		if( someFilter ) {
			cadResp.append("AND ");
		}
		cadResp.append("(PROD.DIVISA = :moneda")
			.append(" OR PROD.DIVISA = :divisa) ");
		
		params.put("moneda", moneda);
		params.put("divisa", tipo);
		someFilter =  true;
	}
	
	
	/**
	 * Metodo para Armas un query en base al filtro.
	 *
	 * @param cad para cad
	 * @param filtro para filtro
	 * @return el string
	 */
	public static String armaQueryAnd(StringBuilder querySQLs, String cad, boolean filtro) {
		StringBuilder querySQL = new StringBuilder();
		if( filtro ) {
			querySQL.append("AND ");
		}
		querySQL.append( cad );
		filtro = true;
		return querySQL.toString();
	}
	
	
	/**
	 * Genera la consulta con un limite de tamanio
	 * 
	 * @param sql        consulta a paginar
	 * @param numPagina  pagina a consultar
	 * @param tamPangina tamanio de la pagina
	 * @return String de la consulta paginada
	 */
	public static void getQueryPaginado(final String querySQL, final StringBuilder queryCountSQL, Map<String, Object> params, final int numPagina, final int tamPagina) {
		log.info("Entro a query paginado");
		queryCountSQL.append(SQL_NUMROW)
			.append(querySQL)
			.append(SQL_WHERE)
			.append(numPagina + " * " + tamPagina)
			.append(SQL_CONDITION)
			.append("(" + numPagina + " - 1) * " + tamPagina)
			.append(" + 1)");
		log.info("Termino querie paginado con el querie: " + queryCountSQL.toString());
//		params.put("numPagina", numPagina);
//		params.put("tamPagina", tamPagina);
	}
	
	
	/**
	 * Metodo Getter para validacion.
	 *
	 * @param consultaOperaciones para consulta operaciones
	 * @param someFilter para some filter
	 * @return validacion validacion
	 */
	public static void getValidacion (
			OperationsMonitorQueryRequest consultaOperaciones, 
			StringBuilder query,
			Map<String, Object> params, boolean someFilter) {

		// Agregamos el BUC
		if (!UtilData.isVacio( consultaOperaciones.getBuc() ) ) {
			UtilMonitorFnc.armaQueryAnd(query, "PROD.BUC = :buc ", someFilter);
			params.put("buc", consultaOperaciones.getBuc());
		}
		if (!UtilData.isVacio(consultaOperaciones.getContrato())) {
			UtilMonitorFnc.armaQueryAnd(query, "PROD.NUM_CNTR = :contrato ", someFilter);
			params.put("contrato", consultaOperaciones.getContrato());
			someFilter =  true;
		}
		if (!UtilData.isVacio(consultaOperaciones.getNombreArchivo()) 
				&& consultaOperaciones.getNombreArchivo().length()>1 ) {
			UtilMonitorFnc.armaQueryAnd(query, "UPPER(PROD.NOMBRE_ARCH) LIKE UPPER('%' || :nombreArchivo || '%') ", someFilter);
			params.put("nombreArchivo", consultaOperaciones.getNombreArchivo().toUpperCase());
		}
		if (!UtilData.esIgual(consultaOperaciones.getIdProducto(), MonitorOperacionesConstants.CERO) 
				&& !UtilData.isVacio(consultaOperaciones.getIdProducto())) {
			UtilMonitorFnc.armaQueryAnd(query, "PROD.CVE_PROD_OPER = :idProducto ", someFilter);
			params.put("idProducto", consultaOperaciones.getIdProducto());
			someFilter =  true;
		}
		if (!UtilData.esIgual(consultaOperaciones.getIdEstatus(), MonitorOperacionesConstants.CERO)
				&& !UtilData.isVacio(consultaOperaciones.getIdEstatus())) {
			UtilMonitorFnc.armaQueryAnd(query, "PROD.ID_ESTATUS = :idEstatus ", someFilter);
			params.put("idEstatus", consultaOperaciones.getIdEstatus());
			someFilter =  true;
		}
		if (!UtilData.isVacio(consultaOperaciones.getCuentaCargo())) {
			UtilMonitorFnc.armaQueryAnd(query, "TRIM(PROD.NUM_CTA_CARGO) = :cuentaCargo ", someFilter);
			params.put("cuentaCargo", consultaOperaciones.getCuentaCargo());
		}
		if (!UtilData.isVacio(consultaOperaciones.getCuentaAbono())) {
			UtilMonitorFnc.armaQueryAnd(query, "TRIM(PROD.NUN_CTA_ABONO) = :cuentaAbono ", someFilter);
			params.put("cuentaAbono", consultaOperaciones.getCuentaAbono());
		}
		if (!UtilData.isVacio(consultaOperaciones.getImporte())) {
			UtilMonitorFnc.armaQueryAnd(query, "PROD.IMPORTE = :importe ", someFilter);
			params.put("importe", consultaOperaciones.getImporte());
		}
		if (!UtilData.isVacio(consultaOperaciones.getReferencia())) {
			final String referenciaTmp = ((consultaOperaciones.getReferencia()).trim()).replaceFirst("^0*", StringUtils.EMPTY);
			UtilMonitorFnc.armaQueryAnd(query, "REGEXP_LIKE (PROD.REFERENCIA, '^0*' || :referencia ) ", someFilter);
			params.put("referencia", referenciaTmp);
		}
		if (!UtilData.isVacio(consultaOperaciones.getNumeroOrden())) {
			UtilMonitorFnc.armaQueryAnd(query, "PROD.NUM_ORDEN = :numeroOrden ", someFilter);
			params.put("numeroOrden", consultaOperaciones.getNumeroOrden());
		}
		if (!UtilData.isVacio(consultaOperaciones.getNombreBeneficiario())) {
			UtilMonitorFnc.armaQueryAnd(query, "UPPER(PROD.BENEFICIARIO)  LIKE UPPER('%' || :nombreBeneficiario || '%') ", someFilter);
			params.put("nombreBeneficiario", "'"+ consultaOperaciones.getNombreBeneficiario() +"'");
		}
		if (!UtilData.isVacio(consultaOperaciones.getIdReg())) {
			UtilMonitorFnc.armaQueryAnd(query, "PROD.ID_REG = :idReg ", someFilter);
			params.put("idReg", consultaOperaciones.getIdReg());
		}
		if (!UtilData.isVacio(consultaOperaciones.getNumEmpleado())
				&& !MonitorOperacionesConstants.PROD_PROV_CONFIRMING.equals(consultaOperaciones.getIdProducto())) {
			UtilMonitorFnc.armaQueryAnd(query, "TRIM(PROD.NUMERO_EMPLEADO) = :numEmpleado ", someFilter);
			params.put("numEmpleado", consultaOperaciones.getNumEmpleado());
		}
		if (!UtilData.isVacio(consultaOperaciones.getNumTarjeta())
				&& !MonitorOperacionesConstants.PROD_PROV_CONFIRMING.equals(consultaOperaciones.getIdProducto())) {
			UtilMonitorFnc.armaQueryAnd(query, "TRIM(PROD.NUMERO_TARJETA) = :numTarjeta ", someFilter);
			params.put("numTarjeta", consultaOperaciones.getNumTarjeta());
		}
		if (!UtilData.isVacio(consultaOperaciones.getSucTutora())
				&& !MonitorOperacionesConstants.PROD_PROV_CONFIRMING.equals(consultaOperaciones.getIdProducto())) {
			UtilMonitorFnc.armaQueryAnd(query, "TRIM(PROD.SUCURSAL_TUTORA) = :sucTutora ", someFilter);
			params.put("sucTutora", consultaOperaciones.getSucTutora());
		}
	}
	
	
	/**
	 * Metodo Getter para obtener una cadena de un Mapa.
	 *
	 * @param miArreglo para mi arreglo
	 * @return query query
	 */
	public static String getQuery(Map<String, Object> miArreglo) {
		String cadResp = "";
		if ( miArreglo != null ) {
			if( miArreglo.containsKey("query") ) {
				cadResp = miArreglo.get("query").toString();
			}
		}
		return cadResp;
	}
	
	
	/**
	 * Metodo para obtener el contenido de un objeto.
	 *
	 * @param obj para obj
	 * @return data data
	 */
	public static String getData(Object obj) {
		String cadResp = "";
		if( obj != null) {
			cadResp = obj.toString();
		}
		return cadResp;
	}
	
	
	/**
	 * Metodo para determinar el tipo de Valor de Divisa 
	 * @param datDivisa
	 * @return
	 */
	public static String valDivisa(Object objDivisa) {
		String datDivisa = "";
		// Validamos que el objeto no sea nulo
		if( objDivisa == null ) {
			 return datDivisa;
		}
		
		datDivisa = objDivisa.toString();
		datDivisa = datDivisa.trim(); 
		if (MonitorOperacionesConstants.MN.equals(datDivisa)){
            datDivisa = MonitorOperacionesConstants.MXP;
        } else if (MonitorOperacionesConstants.MXN.equals(datDivisa)){
        	datDivisa = MonitorOperacionesConstants.MXP;
        }
		return datDivisa;
	}
}
