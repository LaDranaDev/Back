package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ComboResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -205692242925099656L;

	/** Id. */
	private Integer id;
	
	/** Valor. */
	private String valor;
	
}
