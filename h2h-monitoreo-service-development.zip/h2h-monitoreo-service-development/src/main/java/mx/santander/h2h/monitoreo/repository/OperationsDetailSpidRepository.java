package mx.santander.h2h.monitoreo.repository;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.constants.MonitorOperacionesConstants;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.util.DetalleOperacionUtils;
import mx.santander.h2h.monitoreo.util.UtilMapeoData;

/**
 * OperationsDetailSpidRepository.
 *
 * @author Jesus Soto Aguilar
 * @Since 07/07/2023
 */
@Slf4j
@Repository
public class OperationsDetailSpidRepository implements IOperationsDetailSpidRepository {

    @Autowired
    private EntityManager entityManager;
    
    /**
     * Obtiene el detalle de la operacion
     * @param idOperacion - ID de operacion
     * @return Detalle de la operacion
     */
    @Override
    public OperationsMonitorQueryResponse obtenerDetalleOperacion(String idOperacion) {
        String stringQuery = generaConsultaDetalleOperacion(idOperacion);
        Query query = entityManager.createNativeQuery(stringQuery, Tuple.class);
//        query.setParameter("idOperacion", idOperacion);

        DetalleOperacionUtils.ProductoPIFDTO respuesta = new DetalleOperacionUtils.ProductoPIFDTO();
        for (Object obj : query.getResultList()) {
            if (obj instanceof Tuple) {
                Tuple tuple = (Tuple) obj;
                Map<String, Object> row = new HashMap<>();
                tuple.getElements().forEach(t -> row.put(t.getAlias(), tuple.get(t)));
                obtenDetallePagImp(row, respuesta);
            }
        }
        return respuesta;
    }

    /**
     * Consulta el detalle de Pago de impuestos
     * @param respuestaProdDomis DTO de respuesta
     * @param row Fila
     */
    private void obtenDetallePagImp(Map<String, Object> row, DetalleOperacionUtils.ProductoPIFDTO respuestaProdDomis) {
        DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols();
        formatSymbols.setDecimalSeparator('.');
        formatSymbols.setGroupingSeparator(',');
        final DecimalFormat decimalFormat = new DecimalFormat("###,###,###,###,##0.00", formatSymbols);
        respuestaProdDomis.setProducto(Objects.toString(row.get("DESC_PROD"), ""));
        respuestaProdDomis.setCodCli(Objects.toString(row.get("BUC"), ""));
        respuestaProdDomis.setBucEmpleado(Objects.toString(row.get("BUC"), ""));
        respuestaProdDomis.setFechaAplic(Objects.toString(row.get("FCH_APLI"), ""));
        respuestaProdDomis.setReferencia(Objects.toString(row.get("TXT_REF"), ""));
        respuestaProdDomis.setEstatus(Objects.toString(row.get("DESC_ESTATUS"), ""));
        respuestaProdDomis.setIdEstatus(Objects.toString(row.get("ID_ESTATUS"), ""));
        respuestaProdDomis.setTipoPago(Objects.toString(row.get("CTA_CHEQ"), ""));
        respuestaProdDomis.setFechaCaptura(Objects.toString(row.get("FCH_PRES"), ""));
        respuestaProdDomis.setNombreBenef(Objects.toString(row.get("NOM_RECEP"), ""));
        respuestaProdDomis.setBancoOrdenante("BANCO SANTANDER (MÉXICO) S.A.");
        respuestaProdDomis.setNombreOrd(Objects.toString(row.get("TXT_NOM_ORD"), ""));
        respuestaProdDomis.setCtaCargo(Objects.toString(row.get("NUN_CTA_ABONO"), ""));
        respuestaProdDomis.setDivisa(Objects.toString(row.get("DIV_RECEP"), ""));
        respuestaProdDomis.setImporteCargo(row.get(MonitorOperacionesConstants.IMP_RECEP) == null || Objects.toString(row.get(MonitorOperacionesConstants.IMP_RECEP), "").trim().isEmpty()
                ? "$0.00" : "$" + decimalFormat.format(Double.valueOf(row.get(MonitorOperacionesConstants.IMP_RECEP).toString().trim())));
        respuestaProdDomis.setNumConvenio(Objects.toString(row.get("CLAV_RAST"), ""));
        respuestaProdDomis.setBancoReceptor(Objects.toString(row.get("BANC_RECEP"), ""));
        respuestaProdDomis.setCtaAbono(Objects.toString(row.get("NUM_CTA_ORD"), ""));
        // Obtenemos el enmascarado de datos
        respuestaProdDomis.setCtaAbono( UtilMapeoData.getMascara(respuestaProdDomis.getCtaAbono(), "abono") );
        
        respuestaProdDomis.setDivisaOrd(Objects.toString(row.get("CVE_DIVISA_ORDE"), ""));
        respuestaProdDomis.setImporte(row.get(MonitorOperacionesConstants.IMPORTE) == null || Objects.toString(row.get(MonitorOperacionesConstants.IMPORTE)).trim().isEmpty()
                ? "$0.00" : "$" + decimalFormat.format(Double.valueOf(row.get(MonitorOperacionesConstants.IMPORTE).toString().trim())));
        respuestaProdDomis.setIdProducto(Objects.toString(row.get("CVE_PROD_OPER"), ""));
        respuestaProdDomis.setNomArch(Objects.toString(row.get("NOMBRE_ARCH"), ""));
        respuestaProdDomis.setMensajeOrden(Objects.toString(row.get("MSG_H2H"), ""));
    }

    /**
     * Genera la consulta del detalle de la operacion.
     *
     * @return Consulta de detalle de operacion
     */
    private String generaConsultaDetalleOperacion(String idOperacion) {

        log.debug("Preparando consulta de operaciones");
        final StringBuilder query = new StringBuilder();
        query.append("SELECT PROD.CVE_DIVISA_ORDE,PROD.NUME_CUEN_ORDE,PROD.NUN_CTA_ABONO,PROD.NOMBRE_ARCH,PROD.ID_ESTATUS,PROD.DESC_ESTATUS,PROD.IMPORTE,PROD.FCH_APLI,")
        		.append("PROD.BUC,PROD.CLAV_RAST,PROD.FCH_PRES,PROD.TXT_NOM_ORD,PROD.ID_REG,PROD.COD_DIV_CTA_ORD,PROD.NOMB_CLTE,PROD.NUM_CTA_ORD,PROD.CVE_PROD_OPER,")
        		.append("PROD.COD_PROD,PROD.DESC_PROD,PROD.TXT_REF,PROD.TXT_NOM_BCO_PAG,PROD.BANC_RECEP,PROD.NOM_RECEP,")
        		.append("PROD.DIV_RECEP,PROD.IMP_RECEP,PROD.MSG_H2H,PROD.CTA_CHEQ FROM ( ")
                .append(getConsultaByProducto(true))
                .append(" UNION ALL ")
                .append(getConsultaByProducto(false))
                .append(") PROD WHERE PROD.ID_REG = ")
                .append(idOperacion);

        return query.toString();
    }

    /**
     * Crea el query por producto y si el del dia de hoy o el de tres meses
     * @param tresMeses boleano indicador de tres meses
     * @return SQL del producto
     */
    private String getConsultaByProducto(boolean tresMeses) {
        final StringBuilder query = new StringBuilder();
        query
                .append("SELECT ")
                .append(" DETA.CVE_DIVISA_ORDE ," +
                        "DETA.NUME_CUEN_ORDE ," +
                        " DETA.NUME_CUEN_RECE NUN_CTA_ABONO, ")
                .append(" ARCH.NOMBRE_ARCH, " +
                        "REG.ID_ESTATUS, " +
                        "EST.DESC_ESTATUS," +
                        " DETA.IMPO_CARG IMPORTE,  ")
                .append(" to_char(DETA.FECH_APLI,'dd/mm/yyyy') FCH_APLI , " +
                        "CLTE.BUC, ")
                .append(" DETA.REFE_ENVI_OUT CLAV_RAST ," +
                        " to_char(DETA.FECH_PRES,'dd/mm/yyyy') FCH_PRES ,"+
                        " DETA.NOMBRE_ORDE TXT_NOM_ORD, ")
                .append(" DETA.ID_REG," +
                        "DETA.CVE_DIVISA_ORDE COD_DIV_CTA_ORD ," +
                        "CNTA_CARG.NOMB_TITU NOMB_CLTE, ")
                .append(" DETA.NUME_CUEN_ORDE NUM_CTA_ORD," +

                        "REG.CVE_PROD_OPER," +
                        "DETA.COD_PROD,PROD.DESC_PROD, ")
                .append(" DETA.REFE_OUT TXT_REF," +
                        "'BANCO SANTANDER (MÉXICO) S.A.' TXT_NOM_BCO_PAG," +
                        " BNCO.NOMBRE_BANCO BANC_RECEP," +
                        "DETA.NOMBRE_RECE NOM_RECEP," +
                        "DETA.CVE_DIVISA_RECE DIV_RECEP ," +
                        "DETA.IMPO_ABON IMP_RECEP ")
                .append(" , MSG.MSG_H2H MSG_H2H," +
                        "REG.NUME_MOVI CTA_CHEQ ")
                .append("FROM  H2H_MX_PROD_SPID")
                .append(tresMeses ? "_TRAN DETA ": " DETA ")
                .append("INNER JOIN ").append(tresMeses ? "H2H_REG_TRAN" : "H2H_REG").append(" REG ON REG.ID_REG=DETA.ID_REG ")
                .append("INNER JOIN ").append(tresMeses ? "H2H_ARCHIVO_TRAN" : "H2H_ARCHIVO").append(" ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ")
                .append("INNER JOIN H2H_CAT_PROD PROD ON PROD.CVE_PROD_OPER=REG.CVE_PROD_OPER ")
                .append("INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS ")
                .append("INNER JOIN H2H_CNTR CNTR USING (ID_CNTR) ")
                .append("INNER JOIN H2H_CLTE CLTE USING (ID_CLTE) ")
                .append("INNER JOIN H2H_MSG MSG ON MSG.ID_MSG = REG.ID_MSG ")
                .append("LEFT JOIN H2H_CTA_INFO CNTA_CARG ON REG.CNTA_CARG = CNTA_CARG.NUME_CTA AND CNTA_CARG.TIPO_CTA = 'O' ")
                .append("LEFT JOIN H2H_CAT_BNCO BNCO ON DETA.CVE_INTER_RECE  = BNCO.CODI_TRAN ");
        return query.toString();
    }
}
