/**
* Santander Tecnologia - Banco Santander Central Hispano
* Todos los derechos reservados
* OperationsMonitorEntityManagerHelper1Util.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <3 jul. 2024 18:08:39>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.util;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.owasp.encoder.Encode;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.constants.MonitorOperacionesConstants;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.repository.OperationsMonitorEntityManagerHelper1Repository;
import mx.santander.h2h.monitoreo.repository.OperationsMonitorEntityManagerHelper2Repository;
import mx.santander.h2h.monitoreo.repository.OperationsMonitorEntityManagerHelper3Repository;


/**
 * Clase generada para OperationsMonitorEntityManagerHelper1Util.
 *
 * @autor C320868
 * @modifico C320868
 */
@Slf4j
@Component
public class OperMonEntityManHelp1Util {

	/**
	 * Validaciones.
	 *
	 * @param consultaOperaciones para consulta operaciones
	 * @return el map
	 */
	public static void validaciones(
			OperationsMonitorQueryRequest consultaOperaciones,
			StringBuilder querySQL,
			Map<String, Object> params,
			String opcion,
			boolean opcValidacion ) {		
		boolean[] ingresaVal = {false};
		switch (opcion) {
		case "subcons":
			condicionSubCons(consultaOperaciones, querySQL, opcValidacion, ingresaVal);
			break;
		case "SelectConsult":
			condSelectConsult(consultaOperaciones, querySQL, opcValidacion, ingresaVal);
			break;
		case "countArchivo":
			countArchivo(consultaOperaciones, querySQL, opcValidacion, ingresaVal);
			break;
		default:
			
		}
		// Si no ingreso a una funcion agregamos los datos
		if( !ingresaVal[0] ) {
			switch (opcion) {
			case "subcons":
				getSubConsulta(consultaOperaciones, opcValidacion, querySQL, params);
				break;
			case "SelectConsult":
				getSelectConsultaOperaciones(consultaOperaciones, opcValidacion, querySQL, params);
				break;
			default:
				getSelectConsultaOperaciones(consultaOperaciones, opcValidacion, querySQL, params);
				break;
			}
		}
	}
	
	
	private static void countArchivo(
			OperationsMonitorQueryRequest consultaOperaciones, 
			StringBuilder query,
			boolean opcValidacion, boolean[] ingresoVal) {
		
		final boolean ordenPago = OperationsMonitorEntityManagerHelper3Repository.isOrdenPago(consultaOperaciones);
		final boolean altaMasivaEmpleados = OperationsMonitorEntityManagerHelper3Repository.isAltaMasivaEmpleados(consultaOperaciones);
		final boolean pif = UtilData.isPif(consultaOperaciones.getIdProducto());
		final boolean ti = OperationsMonitorEntityManagerHelper3Repository.isTI(consultaOperaciones);
		final boolean pagoDirecto = UtilData.isPagoDirecto(consultaOperaciones.getIdProducto());
		
		// Iniciamos procedimiento
		if (pif) {
			OperMonEntityManHelp1Util.getselectImpFed(opcValidacion, query, consultaOperaciones.getIdProducto());
			ingresoVal[0] = true;
		} else if (ti) {
			OperationsMonitorEntityManagerHelper1Repository.getselectTransfInter(opcValidacion, query, consultaOperaciones.getIdProducto());
			ingresoVal[0] = true;
		} else if (UtilMonitorOperacionesSPID.esProductoActivo(consultaOperaciones.getIdProducto())) {
			UtilMonitorOperacionesSPID.getselectSPID(query, opcValidacion);
			ingresoVal[0] = true;
		} else if (pagoDirecto) {
			OperationsMonitorEntityManagerHelper1Repository.getSelectConsultaOperacionesPagoDirecto(query, opcValidacion);
			ingresoVal[0] = true;
		} else if (ordenPago) {
			OperMonEntityManHelp1Util.getSelectConsultaOperacionesOrdenPago(query, opcValidacion);
			ingresoVal[0] = true;
		} else if (altaMasivaEmpleados) {
			OperMonEntityManHelp1Util
					.getSelectConsultaOperacionesAltaMasivaEmpleados(query, opcValidacion);
			ingresoVal[0] = true;
		}
		
	}


	/**
	 * Metodo para la Consulta de los Elementos
	 *
	 * @param consultaOperaciones para consulta operaciones
	 * @param query para query
	 * @param opcValidacion para opc validacion
	 */
	private static void condSelectConsult(
			OperationsMonitorQueryRequest consultaOperaciones,
			StringBuilder query,
			boolean opcValidacion, boolean[] ingresoVal) {
		final boolean ordenPago = OperationsMonitorEntityManagerHelper3Repository.isOrdenPago(consultaOperaciones);
		final boolean altaMasivaEmpleados = OperationsMonitorEntityManagerHelper3Repository.isAltaMasivaEmpleados(consultaOperaciones);
		final boolean pif = UtilData.isPif(consultaOperaciones.getIdProducto());
		final boolean ti = OperationsMonitorEntityManagerHelper3Repository.isTI(consultaOperaciones);
		final boolean pagoDirecto = UtilData.isPagoDirecto(consultaOperaciones.getIdProducto());
		
		// Iniciamos procedimiento
		if (pif) {
			getselectImpFed(opcValidacion, query, consultaOperaciones.getIdProducto());
			ingresoVal[0] = true;
		} else if (ti) {
			OperationsMonitorEntityManagerHelper1Repository.getselectTransfInter(opcValidacion, query, consultaOperaciones.getIdProducto());
			ingresoVal[0] = true;
		} else if (pagoDirecto) {
			OperationsMonitorEntityManagerHelper1Repository.getSelectConsultaOperacionesPagoDirecto(query, opcValidacion);
			ingresoVal[0] = true;
		} else if (ordenPago) {
			OperationsMonitorEntityManagerHelper1Repository.getSelectConsultaOperacionesPagoDirecto(query, opcValidacion);
			ingresoVal[0] = true;
		} else if (altaMasivaEmpleados) {
			getSelectConsultaOperacionesAltaMasivaEmpleados(query, opcValidacion);
			ingresoVal[0] = true;
		}
	}


	public static void condicionSubCons(
			OperationsMonitorQueryRequest consultaOperaciones,
			StringBuilder query,
			boolean opcValidacion, boolean[] ingresoVal) {
		// Iniciamos procedimiento
		final boolean ordenPago = OperationsMonitorEntityManagerHelper3Repository.isOrdenPago(consultaOperaciones);
		final boolean altaMasivaEmpleados = OperationsMonitorEntityManagerHelper3Repository.isAltaMasivaEmpleados(consultaOperaciones);
		final boolean pif = UtilData.isPif(consultaOperaciones.getIdProducto());
		final boolean ti = OperationsMonitorEntityManagerHelper3Repository.isTI(consultaOperaciones);
		final boolean pagoDirecto = UtilData.isPagoDirecto(consultaOperaciones.getIdProducto()); // PGODIRECT
		final boolean centroPagoMit = OperationsMonitorEntityManagerHelper3Repository.isCentroPagoMit(consultaOperaciones.getIdProducto());
		
		// Iniciamos procedimiento
		if (pif) {
			getselectImpFed(true, query, consultaOperaciones.getIdProducto());
			ingresoVal[0] = true;
		} else if (ti) {
			UtilOperationsMonitor.getselectTransfInter(opcValidacion, query, consultaOperaciones.getIdProducto() );
			ingresoVal[0] = true;
		} else if (UtilMonitorOperacionesSPID.esProductoActivo(consultaOperaciones.getIdProducto())) {
			UtilMonitorOperacionesSPID.getselectSPID(query, opcValidacion);
			ingresoVal[0] = true;
		} else if (pagoDirecto) { // PGODIRECT
			OperationsMonitorEntityManagerHelper2Repository.getSelectConsultaOperacionesPagoDirecto(query, opcValidacion);
			ingresoVal[0] = true;
		} else if(centroPagoMit) {
			query.append( UtilMonitorOperacionesSPID.getSelectConsultaOperacionesCentroPagos(opcValidacion) );
			ingresoVal[0] = true;
		} else if (ordenPago) {
			getSelectConsultaOperacionesOrdenPago(query, opcValidacion);
			ingresoVal[0] = true;
		} else if (altaMasivaEmpleados) {
			getSelectConsultaOperacionesAltaMasivaEmpleados(query, opcValidacion);
			ingresoVal[0] = true;
		} 
	}
	
	
	/**
	 * Genera la consulta de las operaciones de orden de pago
	 * 
	 * @param delDia indica si se usan las tablas del diario
	 * @return String con la consulta
	 */
	public static void getSelectConsultaOperacionesOrdenPago(StringBuilder query, boolean delDia) {
		//final StringBuilder query = new StringBuilder();
		log.info("*****MIGAJA 2 *****");
		query.append("SELECT ")
			.append(delDia ? "'H2H_REG_TRAN' TABLA, " 
				: "'H2H_REG' TABLA, ")
			.append("REG.ID_REG, CLTE.BUC, REG.CNTA_CARG NUM_CTA_CARGO, ")
			.append("REG.CNTA_ABON NUN_CTA_ABONO, CVE_PROD_OPER, PROD.DESC_PROD, ")
			.append("ARCH.NOMBRE_ARCH, REG.REFE_BE REFERENCIA, REG.ID_ESTATUS, ")
			.append("EST.DESC_ESTATUS, REG.MONT IMPORTE, CNTR.NUM_CNTR, REG.DIVI DIVISA, ")
			.append("ARCH.FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, REG.NUM_EMAIL, ")
			.append("CANL.NOMB_CANL, ")
			.append("PAGO.NUM_ORDEN, PAGO.NOMB_BENE BENEFICIARIO, PAGO.NOMB_PERS_AUT_EXT ")
			.append(delDia ? "FROM H2H_ARCHIVO_TRAN ARCH " 
				: "FROM H2H_ARCHIVO ARCH ")
			.append(delDia ? "INNER JOIN H2H_REG_TRAN REG ON ARCH.ID_ARCHIVO = REG.ID_ARCH "
				: "INNER JOIN H2H_REG REG ON ARCH.ID_ARCHIVO = REG.ID_ARCH ")
			.append(" INNER JOIN H2H_CNTR CNTR USING (ID_CNTR) ")
			.append("INNER JOIN H2H_CLTE CLTE USING (ID_CLTE) ")
			.append("INNER JOIN H2H_CAT_PROD PROD USING(CVE_PROD_OPER) ")
			.append("INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS ")
			.append("INNER JOIN H2H_CAT_CANL CANL ON ARCH.ID_CANL = CANL.ID_CANL ")
			.append(delDia ? "INNER JOIN H2H_PROD_ORDN_PAGO_TRAN PAGO ON PAGO.ID_REG = REG.ID_REG "
					: "INNER JOIN H2H_PROD_ORDN_PAGO PAGO ON PAGO.ID_REG = REG.ID_REG ");
		//return query.toString();
	}
	
	
	/**
	 * Genera la consulta de las operaciones de alta masiva de empleados
	 * 
	 * @param delDia indica si se usan las tablas del diario
	 * @return String con la consulta
	 */
	public static void getSelectConsultaOperacionesAltaMasivaEmpleados(StringBuilder query, boolean delDia) {
		log.info("*****MIGAJA 3 *****");
		query.append(delDia ? "SELECT 'H2H_REG_TRAN' TABLA, " : "SELECT 'H2H_REG' TABLA, ")
			.append("REG.ID_REG, CLTE.BUC, REG.CNTA_CARG NUM_CTA_CARGO, ")
			.append("REG.CNTA_ABON NUN_CTA_ABONO, CVE_PROD_OPER, PROD.DESC_PROD, ")
			.append("ARCH.NOMBRE_ARCH, REG.REFE_BE REFERENCIA, REG.ID_ESTATUS, ")
			.append("EST.DESC_ESTATUS, REG.MONT IMPORTE, CNTR.NUM_CNTR, REG.DIVI DIVISA, ")
			.append("ARCH.FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, REG.NUM_EMAIL, EMPL.NUME_CTA TIPO, ")
			.append("EMPL.NUME_EMPL NUMERO_EMPLEADO, EMPL.NUME_TARJ_NUEV NUMERO_TARJETA, EMPL.NUME_BUC_EMPL BUC_EMPLEADO, EMPL.SUCU_TUTO SUCURSAL_TUTORA, ")
			.append("CANL.NOMB_CANL ")
			.append(delDia ? "FROM H2H_ARCHIVO_TRAN ARCH " : "FROM H2H_ARCHIVO ARCH ")
			.append(delDia ? "INNER JOIN H2H_REG_TRAN REG ON ARCH.ID_ARCHIVO = REG.ID_ARCH "
				: "INNER JOIN H2H_REG REG ON ARCH.ID_ARCHIVO = REG.ID_ARCH ")
			.append("INNER JOIN H2H_CNTR CNTR USING (ID_CNTR) ")
			.append("INNER JOIN H2H_CLTE CLTE USING (ID_CLTE)  ")
			.append("INNER JOIN H2H_CAT_PROD PROD USING(CVE_PROD_OPER)  ")
			.append("INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS ")
			.append(" INNER JOIN H2H_CAT_CANL CANL ON ARCH.ID_CANL = CANL.ID_CANL ")
			.append(delDia ? "INNER JOIN H2H_PROD_ALTA_EMPL_TRAN EMPL ON EMPL.ID_REG = REG.ID_REG "
				: "INNER JOIN H2H_PROD_ALTA_EMPL EMPL ON EMPL.ID_REG = REG.ID_REG ");
	}
	
	
	/**
	 * Metodo Getter para subConsulta que se usa en varios parametros
	 *
	 * @return subConsulta sub consulta
	 */
	private static void getSubConsulta(
			OperationsMonitorQueryRequest consultaOperaciones,
			boolean tresMeses,
			StringBuilder query,
			Map<String, Object> params) {
		
		final boolean ordenPago = OperationsMonitorEntityManagerHelper3Repository.isOrdenPago(consultaOperaciones);
		final boolean altaMasivaEmpleados = OperationsMonitorEntityManagerHelper3Repository.isAltaMasivaEmpleados(consultaOperaciones);
		
		if( ordenPago ) {
			getSelectConsultaOperacionesOrdenPago(query, tresMeses);
		} else if (altaMasivaEmpleados ) {
			getSelectConsultaOperacionesAltaMasivaEmpleados( query, tresMeses );
		} else {
			getSelectConsultaOperaciones( consultaOperaciones, tresMeses, query, params);
		}
	}
	
	
	/**
	 * Genera la consulta de Operaciones
	 * 
	 * @param tresMeses           valor que indica si se usa la tablas del dia o las
	 *                            de tres meses a tras
	 * @param consultaOperaciones de tipo ConsultaMonitorOperacionesDTO.
	 * @return String consulta de operaciones
	 */
	public static void getSelectConsultaOperaciones(
			OperationsMonitorQueryRequest consultaOperaciones,
			boolean tresMeses, 
			StringBuilder query,
			Map<String, Object> params) {
		if (UtilVostroDatosExportar.esVostro(consultaOperaciones.getIdProducto())) {
			log.info("*****CB_F2 Vostro*****");
			query.append(UtilVostroDatosExportar.generaQueryProductosVostro(tresMeses, consultaOperaciones));
		} else if (UtilOrdenesPagoAtmDatosExportar.esOrdenPago(consultaOperaciones.getIdProducto())) {
			log.info("*****CB_F2 OP*****");
			query.append(
					UtilOrdenesPagoAtmDatosExportar.generaQueryProductosOrdenPagoatm(tresMeses, consultaOperaciones));
		} else {
			log.info("*****MIGAJA  1*****");
			query.append(tresMeses ? MonitorOperacionesConstants.SELECT_H2H_REG_TRAN_TABLA 
					: MonitorOperacionesConstants.SELECT_H2H_REG_TABLA)
				.append(MonitorOperacionesConstants.REG_ID_REG_CLTE_BUC_REG_CNTA_CARG_NUM_CTA_CARGO)
				.append(MonitorOperacionesConstants.REG_CNTA_ABON_NUN_CTA_ABONO_CVE_PROD_OPER_PROD_DESC_PROD)
				.append(MonitorOperacionesConstants.ARCH_NOMBRE_ARCH_REG_REFE_BE_REFERENCIA_REG_ID_ESTATUS)
				.append(MonitorOperacionesConstants.EST_DESC_ESTATUS_REG_MONT_IMPORTE_CNTR_NUM_CNTR_REG_DIVI_DIVISA)
				.append(MonitorOperacionesConstants.PART_QUERY_SELECT_FECHA_REGISTRO_APLI_PROD)
				.append(" CANL.NOMB_CANL ");
			if (!"Todos".equals(consultaOperaciones.getHoraProgramacion())
					&& consultaOperaciones.getHoraProgramacion() != null) {
				query.append(", reg.HORA_APLI ");
			}
			// Valida 3 meses
			if (tresMeses) {
				query.append("FROM H2H_REG_TRAN REG ");
			} else {
				query.append("FROM H2H_REG REG ");
			}
			// Valida 3 meses
			if (tresMeses) {
				query.append("INNER JOIN H2H_ARCHIVO_TRAN ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ");
			} else {
				query.append("INNER JOIN H2H_ARCHIVO ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ");
			}
			query.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CNTR_CNTR_USING_ID_CNTR)
				.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CLTE)
				.append(MonitorOperacionesConstants.PART_QUERY_SELECT_INNER_CAT_PROD)
				.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CAT_ESTATUS_EST_ON_REG_ID_ESTATUS_EST_ID_CAT_ESTATUS)
				.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CAT_CANL);
			// inicio: si se trata de un producto confirmig y alguno de los parametros
			// incluye informacion
			log.info("*****MIGAJA  REVISA SI ES EL PRODUCTO CONFIRMING*****");
			log.info("*****consultaOperaciones.getCveProveedor()*****" + Encode.forJava(consultaOperaciones.getCveProveedor()));
			log.info("*****consultaOperaciones.getTipOperacion()*****" + Encode.forJava(consultaOperaciones.getTipOperacion()));
			if ("11".equals(consultaOperaciones.getIdProducto())
					&& (consultaOperaciones.getCveProveedor() != null || consultaOperaciones.getTipOperacion() != null)
					&& (!StringUtils.EMPTY.equals(consultaOperaciones.getCveProveedor())
							|| !StringUtils.EMPTY.equals(consultaOperaciones.getTipOperacion()))) {
				log.info("*****AGREGA EL WHERE EN CASO DE SER CONFIRMING Y QUE ALGUNO DE LOS PARAMTROS NO SEA VACIO*****");
				query.append(tresMeses ? "LEFT JOIN H2H_PROD_MTTO_PROV_TRAN " 
						: " LEFT JOIN H2H_PROD_MTTO_PROV  ")
					.append("PCONF ON REG.ID_REG = PCONF.ID_REG WHERE ");
				
				// Seccion PIF
				MonitorOperacionesComunes.agregaFiltrosConsultaOperaciones(consultaOperaciones, query, params);
			}
			// fin: si se trata de un producto confirmig y alguno de los parametros incluye
			// informacion
		}
	}
	
	
	/**
	 *
	 * @param delDia Dia
	 * @param idcntr String
	 * @return String
	 */
	public static void getselectImpFed(boolean delDia, StringBuilder query, String idcntr) {
		String tabla = "";
		// Se valida campos de Consulta
		switch (idcntr) {
			case "21": tabla = "_IMPU_FEDE"; break;
			case "22": tabla = "_PAGO_REFE"; break;
			case "23": tabla = "_APO_OBRE_PATR"; break;
			default: tabla = ""; break;
		}
		query.append(delDia ? MonitorOperacionesConstants.SELECT_H2H_REG_TRAN_TABLA 
				: MonitorOperacionesConstants.SELECT_H2H_REG_TABLA)
			.append(MonitorOperacionesConstants.REG_ID_REG_CLTE_BUC_REG_CNTA_CARG_NUM_CTA_CARGO)
			.append(MonitorOperacionesConstants.REG_CNTA_ABON_NUN_CTA_ABONO_CVE_PROD_OPER_PROD_DESC_PROD)
			.append("ARCH.NOMBRE_ARCH, PIF.REFE_MOV REFERENCIA, REG.ID_ESTATUS, ")
			.append(MonitorOperacionesConstants.EST_DESC_ESTATUS_REG_MONT_IMPORTE_CNTR_NUM_CNTR_REG_DIVI_DIVISA)
			.append("ARCH.FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, REG.NUM_EMAIL, ") //PIF.OBSE_ABO,");
			.append("'' NUMERO_EMPLEADO, '' NUMERO_TARJETA, PIF.BUC BUC_EMPLEADO, '' SUCURSAL_TUTORA, ")
			.append("CANL.NOMB_CANL ");
		
		// Cargamos la Tabla con el tipo de Archivo
		query.append(UtilQuery.fromH2hArchivo(delDia));
		// Agregamos los INNER
		query.append(UtilQuery.innerJoinH2hReg(delDia))
			.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CNTR_CNTR_USING_ID_CNTR)
			.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CLTE)
			.append("INNER JOIN H2H_CAT_PROD PROD on PROD.CVE_PROD_OPER=REG.CVE_PROD_OPER ")
			.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CAT_ESTATUS_EST_ON_REG_ID_ESTATUS_EST_ID_CAT_ESTATUS)
			.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CAT_CANL)
			.append(delDia ? "INNER JOIN H2H_PROD"+ tabla +"_TRAN PIF ON PIF.ID_REG = REG.ID_REG "
				: "INNER JOIN H2H_PROD"+ tabla +" PIF ON PIF.ID_REG = REG.ID_REG");
	}
}
