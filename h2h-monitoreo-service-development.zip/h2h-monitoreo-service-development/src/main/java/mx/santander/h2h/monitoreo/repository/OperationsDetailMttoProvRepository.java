package mx.santander.h2h.monitoreo.repository;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import mx.santander.h2h.monitoreo.constants.MonitorOperacionesConstants;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.util.UtilMapeoData;

@Repository
public class OperationsDetailMttoProvRepository implements IOperationsDetailMttoProvRepository {
	/** Mapa de las tablas de los productos de monitor de operaciones */
	protected static final Map<String, String> tablas = new HashMap<String, String>() {
		/** Constante version */
		private static final long serialVersionUID = 1L;
		{
			put("01", "H2H_PROD_TRAN"); /** SPEI */
			put("97", "H2H_PROD_TRAN"); /** TEF */
			put("02", "H2H_PROD_TRAN"); /** Nomina Interbancaria */
			put("98", "H2H_PROD_TRAN_MISM_BANC"); /** TMB */
			put("99", "H2H_PROD_NOMI_MISM_BANC"); /** Nomina Mismo Banco */
			put("91", "H2H_PROD_ALTA_PAGO"); /** ALTA PAGO PROVEEDORES CONFIRMING */
			put("80", "H2H_PROD_ORDN_PAGO"); /** ORDEN DE PAGO */
			put("95", "H2H_ACTA_BENI"); /** Alta Cuenta Beneficiarias */
			put("96", "H2H_ACTA_BENI"); /** Alta Cuenta Beneficiarias */
			put("81", "H2H_PROD_ORDN_PAGO"); /** ORDEN DE PAGO CANCELADO */
			put("93", "H2H_PROD_ALTA_EMPL"); /** ALTA MASIVA EMPLEADOS */
			put("135", "H2H_PROD_MANTTO_PROV_TRAN"); /** MTTO PROVEEDORES DE CONFIRMING **/
			put("11", "H2H_PROD_MTTO_PROV"); /** MTTO PROVEEDORES DE CONFIRMING **/
		}
	};
	/** Mapa de las operaciones */
	protected static final Map<String, String> tipoOperacion = new HashMap<String, String>() {
		/** Constante version */
		private static final long serialVersionUID = 1L;
		{
			put("1", "Alta de Proveedor, persona  Física Nacional"); /** SPEI */
			put("2", "Alta de Proveedor, persona Física Internacional"); /** TEF */
			put("3", "Alta de Proveedor, persona Moral Nacional"); /** Nomina Interbancaria */
			put("4", "Alta de Proveedor, persona Moral Internacional"); /** TMB */
			put("5", "Modificación de Proveedor, persona Física Nacional"); /** Nomina Mismo Banco */
			put("6", "Modificación de Proveedor, persona Física Internacional"); /** ALTA PAGO PROVEEDORES CONFIRMING */
			put("7", "Modificación de Proveedor, persona Moral Nacional"); /** ORDEN DE PAGO */
			put("8", "Modificación de Proveedor, persona Moral Internacional"); /** Alta Cuenta Beneficiarias */
			put("9", "Baja de Proveedor"); /** Alta Cuenta Beneficiarias */
		}
	};

	@Autowired
	private EntityManager entityManager;

	/**
	 * Consulta el detalle de la operacion
	 * 
	 * @param view        - vista del producto
	 * @param idOperacion - ID de la operacion
	 * @return Detalle de la operacion
	 */
	@Override
	public OperationsMonitorQueryResponse obtenerDetalleOperacion(String view, String idOperacion) {
		String stringQuery = generaConsultaDetalleOperacion(view, idOperacion);
		Query query = entityManager.createNativeQuery(stringQuery, Tuple.class);
//		query.setParameter("idOperacion", idOperacion);

		OperationsMonitorQueryResponse respuesta = new OperationsMonitorQueryResponse();
		respuesta.setProducto("OPERACION_EN_PROCESO");
		for (Object row : query.getResultList()) {
			if (row instanceof Tuple) {
				mapDetalleOperacion((Tuple) row, respuesta);
			}
		}

		return respuesta;
	}

	protected void mapDetalleOperacion(Tuple row, OperationsMonitorQueryResponse respuesta) {
		DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols();
		formatSymbols.setDecimalSeparator('.');
		formatSymbols.setGroupingSeparator(',');
		DecimalFormat decimalFormat = new DecimalFormat("###,###,###,###,##0.00", formatSymbols);
		respuesta.setIdOperacion(row.get("ID_REG") == null || row.get("ID_REG").toString().trim().isEmpty() ? "0"
				: row.get("ID_REG").toString().trim());
		setDatosProveedor(row, respuesta); 
		respuesta.setCodCli(getValue(row, "BUC"));
		respuesta.setCtaCargo(getValue(row, "NUM_CTA_CARGO"));
		respuesta.setCtaAbono(getValue(row, "NUN_CTA_ABONO"));
		// Obtenemos el enmascarado de datos
		respuesta.setCtaAbono( UtilMapeoData.getMascara(respuesta.getCtaAbono(), "abono") );
		respuesta.setIdProducto(row.get("CVE_PROD_OPER") == null ? "0" : row.get("CVE_PROD_OPER").toString().trim());
		respuesta.setProducto(getValue(row, "DESC_PROD"));
		respuesta.setNomArch(getValue(row, "NOMBRE_ARCH"));
		respuesta.setReferencia(row.get("REFERENCIA") == null ? "" : row.get("REFERENCIA").toString().trim());
		if ("0".equals(respuesta.getReferencia()) || "null".equals(respuesta.getReferencia())) {
			respuesta.setReferencia("");
		}
		respuesta.setEstatus(getValue(row, "DESC_ESTATUS"));
		respuesta.setImporte(row.get("IMPORTE") == null || row.get("IMPORTE").toString().trim().isEmpty() ? "$0.00"
				: "$" + decimalFormat.format(Double.valueOf(row.get("IMPORTE").toString().trim())));
		respuesta.setComentario1(getValue(row, "COMENTARIO_1"));
		respuesta.setComentario2(getValue(row, "COMENTARIO_2"));
		respuesta.setComentario3(getValue(row, "COMENTARIO_3"));
		respuesta.setDivisa(getValue(row, "DIVISA"));
		if (MonitorOperacionesConstants.MN
				.equals(respuesta.getDivisa() != null ? respuesta.getDivisa().trim() : respuesta.getDivisa())) {
			respuesta.setDivisa(MonitorOperacionesConstants.MXP);
		} else if (MonitorOperacionesConstants.MXN
				.equals(respuesta.getDivisa() != null ? respuesta.getDivisa().trim() : respuesta.getDivisa())) {
			respuesta.setDivisa(MonitorOperacionesConstants.MXP);
		}
		respuesta.setDivisaOrd(getValue(row, "DIVISA_ORD"));
		if (MonitorOperacionesConstants.MN.equals(
				respuesta.getDivisaOrd() != null ? respuesta.getDivisaOrd().trim() : respuesta.getDivisaOrd())) {
			respuesta.setDivisaOrd(MonitorOperacionesConstants.MXP);
		} else if (MonitorOperacionesConstants.MXN.equals(
				respuesta.getDivisaOrd() != null ? respuesta.getDivisaOrd().trim() : respuesta.getDivisaOrd())) {
			respuesta.setDivisaOrd(MonitorOperacionesConstants.MXP);
		}
		respuesta.setFechaAplic(getFecha(row.get("FECHA_APLICACION")));
		respuesta.setFechaCaptura(getFecha(row.get("FECHA_REGISTRO")));
		respuesta.setFechaLimitPago(getFecha(row.get("FECHA_LIMITE_PAGO")));
		respuesta.setFechaOper(getFecha(row.get("FECHA_OPERACION")));
		respuesta.setFechaPresIni(getFecha(row.get("FECHA_PRESENTACION_INICIAL")));
		respuesta.setImporteCargo(row.get("IMPORTE_CARGO") == null || row.get("IMPORTE_CARGO").toString().isEmpty()
				? respuesta.getImporte()
				: "$" + decimalFormat.format(Double.valueOf(row.get("IMPORTE_CARGO").toString().trim())));
		respuesta.setNombreOrd(Objects.toString(row.get("TITULAR"), ""));
		respuesta.setIntermOrd(getValue(row, "INTERMEDIARIO_ORD"));
		respuesta.setIntermRec(getValue(row, "INTERMEDIARIO_REC"));
		respuesta.setModalidad(getValue(row, "MODALIDAD"));
		respuesta.setNombreBenef(getValue(row, "BENEFICIARIO"));
		respuesta.setNumSucursal(getValue(row, "NUM_SUCURSAL"));
		respuesta.setFechaVenc(getFecha(row.get("FECH_VENC")));
		respuesta.setNumOrden(getValue(row, "NUM_ORDEN"));
		respuesta.setTipoPago(getValue(row, "TIPO_PAGO"));
		respuesta.setNumeMovil(getValue(row, "NUME_MOVI"));
		if (respuesta.getIdProducto().equals("98") || respuesta.getIdProducto().equals("99")) {
			respuesta.setBancoReceptor(MonitorOperacionesConstants.BANCO);
		} else {
			respuesta.setBancoReceptor(
					row.get("BANCO_RECEPTOR") == null ? "" : row.get("BANCO_RECEPTOR").toString().trim());
		}
		respuesta.setBancoOrdenante(MonitorOperacionesConstants.BANCO);
		respuesta.setMensaje(getValue(row, "MSG_H2H"));
		respuesta.setIdEstatus(row.get("ID_ESTATUS") == null ? "0" : row.get("ID_ESTATUS").toString().trim());
		respuesta
				.setMensajeOrden(row.get("MSG_ORDEN_PAGO") == null ? "0" : row.get("MSG_ORDEN_PAGO").toString().trim());
		respuesta.setReferenciaAbono(getValue(row, "REFERENCIA_ABONO"));
		respuesta.setReferenciaCargo(getValue(row, "REFERENCIA_CARGO"));
		respuesta.setNombreEmpleado(getValue(row, "NOMBRE_EMPLEADO"));
		respuesta.setNumEmpleado(getValue(row, "NUMERO_EMPLEADO"));
		respuesta.setBucEmpleado(getValue(row, "BUC_EMPLEADO"));
		respuesta.setRfc(getValue(row, "RFC"));
		respuesta.setNumTarjeta(getValue(row, "NUMERO_TARJETA"));
		// Enmascaramos las Tarjetas
		respuesta.setNumTarjeta( UtilMapeoData.getMascara(respuesta.getNumTarjeta(), "tarjeta") );

		respuesta.setNumeroCuenta(getValue(row, "NUMERO_CUENTA"));
		String sucursal = getValue(row, "SUCURSAL_TUTORA");
		if (StringUtils.isNotEmpty(sucursal) && !sucursal.equals("-1") && sucursal.length() < 4) {
			sucursal = StringUtils.leftPad(sucursal, 4, "0");
		}
		respuesta.setSucTutora(sucursal);
		respuesta.setDescripcion(getValue(row, "DESCRIPCION"));
		if (!respuesta.getModalidad().isEmpty()) {
			respuesta.setModalidad(respuesta.getModalidad().equals("T") ? "Al momento de hacer la orden"
					: "Al momento de hacer la liquidaci\u00F3n");
		}
		if (!respuesta.getTipoPago().isEmpty()) {
			respuesta.setTipoPago(respuesta.getTipoPago().equals("E") ? "E-EFECTIVO"
					: (respuesta.getTipoPago().equals("C") ? "C-CHEQUE" : "OTRO"));
		}
		if (MonitorOperacionesConstants.MN.equals(
				respuesta.getDivisaOrd() != null ? respuesta.getDivisaOrd().trim() : respuesta.getDivisaOrd())) {
			respuesta.setDivisaOrd(MonitorOperacionesConstants.MXP);
		}
	}

	/**
	 * Genera la consulta del detalle de la operacion
	 * 
	 * @return Consulta de detalle de operacion
	 */
	protected String generaConsultaDetalleOperacion(String view, String idOperacion) {
		final StringBuilder query = new StringBuilder();
		query.append("SELECT PROD.* FROM ( ")
			 .append(getConsultaByProducto(view, true))
			 .append(" UNION ALL ")
			 .append(getConsultaByProducto(view, false))
			 .append(") PROD WHERE PROD.ID_REG = ")
			 .append(idOperacion);
		return query.toString();
	}

	/**
	 * Crea el query por producto y si el dlel dia de hoy o el de tres meses
	 * 
	 * @param cveOperProd clave del producto
	 * @param tresMeses   inidca si va suar la tablasd e tres meses atras
	 * @return SQL del producto
	 */
	protected String getConsultaByProducto(String cveOperProd, boolean tresMeses) {
		final StringBuilder query = new StringBuilder();
		query.append("SELECT ")
				.append("ID_REG, ")
				.append("DETA.NOMB_RAZN_SOC NOMPROVEEDOR, DETA.CLVE_OPER TIPOOPERACION,")
				.append("DETA.CLVE_PROV CVEPROVEEDOR, DECODE(DETA.TIPO_PERS,null,'','F', 'FISICA','M','MORAL') TIPOPERJURIDICA, ")
				.append("DETA.NUM_FOL NUMFOLIO, DETA.COD_CLTE_PROV CODREGISTRO,")
				.append("CLTE.BUC, REG.CNTA_CARG NUM_CTA_CARGO, ")
				.append("REG.CNTA_ABON NUN_CTA_ABONO, CVE_PROD_OPER, PROD.DESC_PROD, ")
				.append("ARCH.NOMBRE_ARCH, 'DETA.REFE_SERV_EMIS' REFERENCIA, REG.ID_ESTATUS, ")
				.append("EST.DESC_ESTATUS, REG.MONT IMPORTE, CNTR.NUM_CNTR, REG.DIVI DIVISA, ")
				.append("ARCH.FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, ");

//		getConsultaByProducto(query, cveOperProd);
		String sqlProdTran = query.toString();
		query.delete(0, sqlProdTran.length());
		sqlProdTran = sqlProdTran.replace("REG.DIVI DIVISA,", "'MXP' DIVISA, ");
		
		query.append(sqlProdTran)
				.append("'DETA.CLAV_INTE_ORDE' INTERMEDIARIO_ORD, 'MXP' DIVISA_ORD, ")
				.append("'DETA.CLAV_INTER_RECE' INTERMEDIARIO_REC, DECODE(CNTA_ABON.NOMB_TITU,NULL,DETA.NOMB_RAZN_SOC ,CNTA_ABON.NOMB_TITU) BENEFICIARIO, ")
				.append("'DETA.COME_1_CONC_PAGO' COMENTARIO_1, 'DETA.COME_2' COMENTARIO_2, ")
				.append("'DETA.COME_3' COMENTARIO_3, DETA.NOMB_RAZN_SOC TITULAR, DETA.BNCO_EXTR BANCO_RECEPTOR, ")
				.append("NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO, ")
				.append("MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, ")
				.append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, NULL FECH_VENC,")
				.append("NULL REFERENCIA_ABONO, NULL REFERENCIA_CARGO, ")
				.append("NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, ")
				.append("NULL BUC_EMPLEADO, ")
				.append("NULL SUCURSAL_TUTORA, NULL RFC, ")
				.append("NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, ")
				.append("NULL DESCRIPCION, ");

		query.append("REG.FECH_OPER FECHA_PRESENTACION_INICIAL, REG.FECH_ENVI_BACK FECHA_OPERACION, REG.NUME_MOVI ")
				.append("FROM ")
				.append("H2H_PROD_MTTO_PROV")
				.append(tresMeses ? "_TRAN DETA " : " DETA ")
				.append("INNER JOIN ").append(tresMeses ? "H2H_REG_TRAN" : "H2H_REG").append(" REG USING(ID_REG) ")
				.append("INNER JOIN ").append(tresMeses ? "H2H_ARCHIVO_TRAN" : "H2H_ARCHIVO").append(" ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ")
				.append("INNER JOIN H2H_CNTR CNTR USING (ID_CNTR) ")
				.append("INNER JOIN H2H_CLTE CLTE USING (ID_CLTE) ")
				.append("INNER JOIN H2H_CAT_PROD PROD USING(CVE_PROD_OPER) ")
				.append("INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS ");

		// if (!("80".equals(cveOperProd) || "81".equals(cveOperProd)) || ){
		query.append("LEFT JOIN H2H_MSG MSG ON MSG.ID_MSG = REG.ID_MSG ");
		// }
		
		query
			.append("LEFT JOIN H2H_CTA_INFO CNTA_ABON ON REG.CNTA_ABON = CNTA_ABON.NUME_CTA AND CNTA_ABON.TIPO_CTA = 'B' ")
			.append("LEFT JOIN H2H_CTA_INFO CNTA_CARG ON REG.CNTA_CARG = CNTA_CARG.NUME_CTA AND CNTA_CARG.TIPO_CTA = 'O' ");

//		if ("01".equals(cveOperProd) || "97".equals(cveOperProd) || "02".equals(cveOperProd)) {
//			query.append("LEFT JOIN H2H_CAT_BNCO BNCO ON DETA.CLAV_INTER_RECE  = BNCO.CODI_TRAN ").append(
//					"LEFT JOIN H2H_CTA_INFO CNTA_ABON ON REG.CNTA_ABON = CNTA_ABON.NUME_CTA AND CNTA_ABON.TIPO_CTA = 'B' ")
//					.append("LEFT JOIN H2H_CTA_INFO CNTA_CARG ON REG.CNTA_CARG = CNTA_CARG.NUME_CTA AND CNTA_CARG.TIPO_CTA = 'O' ")
//					.append("LEFT JOIN H2H_CAT_DIVISA DIVI_ABON ON DIVI_ABON.ID_CAT_DIVISA = CNTA_ABON.ID_CAT_DIVISA ")
//					.append("LEFT JOIN H2H_CAT_DIVISA DIVI_CARG ON DIVI_CARG.ID_CAT_DIVISA = CNTA_CARG.ID_CAT_DIVISA ");
//		}
//		if ("95".equals(cveOperProd) || "96".equals(cveOperProd)) {
//			query.append("LEFT JOIN H2H_CAT_BNCO BNCO USING(ID_BANCO) ").append(
//					"LEFT JOIN H2H_CTA_INFO CNTA_ABON ON REG.CNTA_ABON = CNTA_ABON.NUME_CTA AND CNTA_ABON.TIPO_CTA = 'B' ")
//					.append("LEFT JOIN H2H_CTA_INFO CNTA_CARG ON REG.CNTA_CARG = CNTA_CARG.NUME_CTA AND CNTA_CARG.TIPO_CTA = 'O' ")
//					.append("LEFT JOIN H2H_CAT_DIVISA DIVI_ABON ON DIVI_ABON.ID_CAT_DIVISA = CNTA_ABON.ID_CAT_DIVISA ")
//					.append("LEFT JOIN H2H_CAT_DIVISA DIVI_CARG ON DIVI_CARG.ID_CAT_DIVISA = CNTA_CARG.ID_CAT_DIVISA ");
//		}
//		if ("98".equals(cveOperProd) || "99".equals(cveOperProd)) {
//			query.append("LEFT JOIN H2H_CAT_BNCO BNCO ON DETA.ID_BANC = BNCO.ID_BANCO ")
//				.append("LEFT JOIN H2H_CTA_INFO CNTA_ABON ON REG.CNTA_ABON = CNTA_ABON.NUME_CTA AND CNTA_ABON.TIPO_CTA = 'B' ")
//				.append("LEFT JOIN H2H_CTA_INFO CNTA_CARG ON REG.CNTA_CARG = CNTA_CARG.NUME_CTA AND CNTA_CARG.TIPO_CTA = 'O' ")
//				.append("LEFT JOIN H2H_CAT_DIVISA DIVI_ABON ON DIVI_ABON.ID_CAT_DIVISA = CNTA_ABON.ID_CAT_DIVISA ")
//				.append("LEFT JOIN H2H_CAT_DIVISA DIVI_CARG ON DIVI_CARG.ID_CAT_DIVISA = CNTA_CARG.ID_CAT_DIVISA ");
//		}
		

		return query.toString();
	}

	protected void getConsultaByProducto(StringBuilder query, String cveOperProd) {
		if ("01".equals(cveOperProd) || "97".equals(cveOperProd)
				|| "02".equals(cveOperProd)) { /** SPEI - TEF - Nomina Interbancaria */
			String sqlProdTran = query.toString();
			query.delete(0, sqlProdTran.length());
			sqlProdTran = sqlProdTran.replace("REG.DIVI DIVISA,",
					"DECODE(DIVI_ABON.CLAV_CAPTA,NULL,REG.DIVI,DIVI_ABON.CLAV_CAPTA) DIVISA, ");
			query.append(sqlProdTran).append("DETA.CLAV_INTE_ORDE INTERMEDIARIO_ORD, DIVI_CARG.CLAV_CAPTA DIVISA_ORD, ")
					.append("DETA.CLAV_INTER_RECE INTERMEDIARIO_REC, DECODE(CNTA_ABON.NOMB_TITU,NULL,DETA.NOMB_RECE,CNTA_ABON.NOMB_TITU) BENEFICIARIO, ")
					.append("DETA.COME_1_CONC_PAGO COMENTARIO_1, DETA.COME_2 COMENTARIO_2, ")
					.append("DETA.COME_3 COMENTARIO_3, CNTA_CARG.NOMB_TITU TITULAR, BNCO.NOMBRE_BANCO BANCO_RECEPTOR, ")
					.append("NULL TIPO_PAGO, NULL MODALIDAD, DETA.IMPO_CARG IMPORTE_CARGO, ")
					.append("MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, ")
					.append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, NULL FECH_VENC,")
					.append("NULL REFERENCIA_ABONO, NULL REFERENCIA_CARGO, ")
					.append("NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, ").append("NULL BUC_EMPLEADO, ")
					.append("NULL SUCURSAL_TUTORA, NULL RFC, ").append("NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, ")
					.append("NULL DESCRIPCION, ");
		} else if ("80".equals(cveOperProd) || "81".equals(cveOperProd)) { /** ORDEN DE PAGO */
			query.append("NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD, NULL INTERMEDIARIO_REC, ")
					.append("DETA.NOMB_BENE || ' ' || DETA.APE_PATE_BENE || ' ' || DETA.APE_MATE_BENE BENEFICIARIO, ")
					.append("NULL COMENTARIO_1, NULL COMENTARIO_2, ")
					.append("NULL COMENTARIO_3, NULL TITULAR, NULL BANCO_RECEPTOR, ")
					.append("DETA.FORM_PAGO TIPO_PAGO, DETA.FORM_ALTA MODALIDAD, DETA.IMPO_GIRO IMPORTE_CARGO, ")
					.append("DETA.CONC_PAGO MSG_H2H, MSG.MSG_H2H MSG_ORDEN_PAGO, DETA.NUM_ORDEN, ")
					.append("DETA.FECH_LIMI_LIQ FECHA_LIMITE_PAGO, DETA.OFIC_PAGO NUM_SUCURSAL, NULL FECH_VENC,")
					.append("NULL REFERENCIA_ABONO, NULL REFERENCIA_CARGO, ")
					.append("NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, ").append("NULL BUC_EMPLEADO, ")
					.append("NULL SUCURSAL_TUTORA, NULL RFC, ").append("NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, ")
					.append("NULL DESCRIPCION, ");
		} else if ("95".equals(cveOperProd) || "96".equals(cveOperProd)) { /** Alta Cuenta Beneficiarias */
			String sqlProdTran = query.toString();
			query.delete(0, sqlProdTran.length());
			sqlProdTran = sqlProdTran.replace("REG.DIVI DIVISA,",
					"DECODE(DIVI_ABON.CLAV_CAPTA,NULL,REG.DIVI,DIVI_ABON.CLAV_CAPTA) DIVISA,");
			query.append(sqlProdTran).append("NULL INTERMEDIARIO_ORD, DIVI_CARG.CLAV_CAPTA DIVISA_ORD, ").append(
					"NULL INTERMEDIARIO_REC, DECODE(CNTA_ABON.NOMB_TITU,NULL,DETA.NOMB_RECE,CNTA_ABON.NOMB_TITU) BENEFICIARIO, ")
					.append("NULL COMENTARIO_1, NULL COMENTARIO_2, ")
					.append("NULL COMENTARIO_3, CNTA_CARG.NOMB_TITU TITULAR, BNCO.NOMBRE_BANCO BANCO_RECEPTOR, ")
					.append("NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO, ")
					.append("MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, ")
					.append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, NULL FECH_VENC, ")
					.append("NULL REFERENCIA_ABONO, NULL REFERENCIA_CARGO, ")
					.append("NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, ").append("NULL BUC_EMPLEADO, ")
					.append("NULL SUCURSAL_TUTORA, NULL RFC, ").append("NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, ")
					.append("NULL DESCRIPCION, ");
		} else if ("98".equals(cveOperProd) || "99".equals(cveOperProd)) { /** TMB - Nomina Mismo Banco */
			String sqlProdTran = query.toString();
			query.delete(0, sqlProdTran.length());
			sqlProdTran = sqlProdTran.replace("REG.DIVI DIVISA,", "DIVI_ABON.CLAV_CAPTA DIVISA,");
			query.append(sqlProdTran).append("NULL INTERMEDIARIO_ORD, DIVI_CARG.CLAV_CAPTA DIVISA_ORD, ")
					.append("NULL INTERMEDIARIO_REC, CNTA_ABON.NOMB_TITU BENEFICIARIO, ")
					.append("NULL COMENTARIO_1, NULL COMENTARIO_2, ")
					.append("NULL COMENTARIO_3, CNTA_CARG.NOMB_TITU TITULAR, BNCO.NOMBRE_BANCO BANCO_RECEPTOR, ")
					.append("NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO, ")
					.append("MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, ")
					.append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, NULL FECH_VENC, ");
			if ("98".equals(cveOperProd)) {
				query.append("DETA.NUME_MOV_ABONO REFERENCIA_ABONO, DETA.NUME_MOV_CARG REFERENCIA_CARGO, ");
			} else {
				query.append("NULL REFERENCIA_ABONO, NULL REFERENCIA_CARGO, ");
			}
			query.append("NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, ").append("NULL BUC_EMPLEADO, ")
					.append("NULL SUCURSAL_TUTORA, NULL RFC, ").append("NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, ")
					.append("NULL DESCRIPCION, ");
		} else {
			getConsultaByProductoAux(query, cveOperProd);
		}
	}

	protected void getConsultaByProductoAux(StringBuilder query, String cveOperProd) {
		if ("91".equals(cveOperProd) || "135".equals(cveOperProd)
				|| "11".equals(cveOperProd)) { /** ALTA PAGO PROVEEDORES CONFIRMING */
			String sqlConfirming = query.toString();
			query.delete(0, sqlConfirming.length());
			sqlConfirming = sqlConfirming.replace("REG.CNTA_CARG NUM_CTA_CARGO,", "NULL NUM_CTA_CARGO,");
			sqlConfirming = sqlConfirming.replace("REG.CNTA_ABON NUN_CTA_ABONO,", "NULL NUN_CTA_ABONO,");
			sqlConfirming = sqlConfirming.replace("REG.REFE_BE REFERENCIA,", "NULL REFERENCIA,");
			sqlConfirming = sqlConfirming.replace("REG.DIVI DIVISA,", "NULL DIVISA,");
			query.append(sqlConfirming).append("NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD, ")
					.append("NULL INTERMEDIARIO_REC, null BENEFICIARIO, ")
					.append("NULL COMENTARIO_1, NULL COMENTARIO_2, ").append("NULL COMENTARIO_3, ")
					.append("DECODE (CLTE.PERSONALIDAD,'F',CLTE.nombre  || ' '  || ")
					.append("CLTE.appaterno  || ' '  || CLTE.apmaterno, CLTE.RAZON_SCIA) TITULAR, ")
					.append("null BANCO_RECEPTOR, ").append("NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO, ")
					.append("MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, ")
					.append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, NULL FECH_VENC, ")
					.append("NULL REFERENCIA_ABONO, NULL REFERENCIA_CARGO, ")
					.append("NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, ").append("NULL BUC_EMPLEADO, ")
					.append("NULL SUCURSAL_TUTORA, NULL RFC, ").append("NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, ")
					.append("NULL DESCRIPCION, ");
		} else if ("93".equals(cveOperProd)) { /** Alta Masiva Empleados */
			query.append("NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD, ")
					.append("NULL INTERMEDIARIO_REC, NULL BENEFICIARIO, ")
					.append("NULL COMENTARIO_1, NULL COMENTARIO_2, ")
					.append("NULL COMENTARIO_3, NULL TITULAR, NULL BANCO_RECEPTOR, ")
					.append("NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO, ")
					.append("MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, ")
					.append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, ")
					.append("NULL REFERENCIA_ABONO, NULL REFERENCIA_CARGO, ")
					.append("DETA.NUME_EMPL NUMERO_EMPLEADO, DETA.NUME_TARJ_NUEV NUMERO_TARJETA, ")
					.append("DETA.NUME_BUC_EMPL BUC_EMPLEADO, ")
					.append("DETA.SUCU_TUTO SUCURSAL_TUTORA, DETA.RFC_EMPL RFC, ")
					.append("DETA.NOMB_EMPL || ' ' || DETA.APEL_PATE_EMPL || ' ' || DETA.APEL_MATE_EMPL NOMBRE_EMPLEADO, DETA.NUME_CTA_NUEV NUMERO_CUENTA, ")
					.append("DETA.DESC_ERRO DESCRIPCION, ");
		} else {
			query.append("NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD, ")
					.append("NULL INTERMEDIARIO_REC, NULL BENEFICIARIO, ")
					.append("NULL COMENTARIO_1, NULL COMENTARIO_2, ")
					.append("NULL COMENTARIO_3, NULL TITULAR, NULL BANCO_RECEPTOR, ")
					.append("NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO, ")
					.append("MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, ")
					.append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, NULL FECH_VENC, ")
					.append("NULL REFERENCIA_ABONO, NULL REFERENCIA_CARGO, ")
					.append("NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, ").append("NULL BUC_EMPLEADO, ")
					.append("NULL SUCURSAL_TUTORA, NULL RFC, ").append("NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, ")
					.append("NULL DESCRIPCION, ");
		}
	}

	/**
	 * Retorna la fecha del objeto pasado como parametro.
	 * 
	 * @param obj Object
	 * @return String fecha
	 */
	protected String getFecha(Object obj) {
		String fecha = StringUtils.EMPTY;
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		if (obj instanceof Date || obj instanceof Timestamp) {
			fecha = dateFormat.format(obj);
		}
		if (obj instanceof String) {
			fecha = obj.toString();
		}
		return fecha;
	}

	protected String getValue(Tuple tuple, String key) {
		try {
			return Objects.toString(tuple.get(key), "").trim();
		} catch (IllegalArgumentException e) {
			return "";
		}
	}
	
	/**
	 * Metodo que define los datos del proveedor
	 * 
	 * @param row Renglo de la consulta
	 * @param respuesta Objeto de respuesta
	 */
	private void setDatosProveedor(Tuple row, OperationsMonitorQueryResponse respuesta) {
		respuesta.setNomProveedor(getValue(row, "NOMPROVEEDOR"));
		String tipOper = getValue(row, "TIPOOPERACION");
		if (tipOper.length() >= 1) {
			tipOper = tipoOperacion.get(tipOper);
			respuesta.setTipoOperacion(tipOper);
		} else {
			respuesta.setTipoOperacion("");
		}
		respuesta.setCveProveedor(getValue(row, "CVEPROVEEDOR"));
		respuesta.setTipoPerJuridica(getValue(row, "TIPOPERJURIDICA"));
		respuesta.setNumFolio(getValue(row, "NUMFOLIO"));
		respuesta.setCodRegistro(getValue(row, "CODREGISTRO"));
	}

}
