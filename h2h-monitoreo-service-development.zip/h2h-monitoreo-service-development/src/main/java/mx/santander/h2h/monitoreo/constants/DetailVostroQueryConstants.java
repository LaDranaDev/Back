package mx.santander.h2h.monitoreo.constants;

/**
 * DetailVostroQueryConstants.
 *
 * @author Jesus Soto Aguilar
 */
public final class DetailVostroQueryConstants {

    /**
     * constante de tipo
     * String para
     * UNION ALL
     */
    public static final String UNION = " UNION ALL ";

    /**
     * ID_REG_EQ
     * parte del query para
     *  agregar al where
     * del id del registro
     * del detalle de operaciones
     */
    public static final String ID_REG_EQ = ") PROD WHERE  PROD.id_reg = ";

    /**
     * Constante para la
     * cadena de _TRAN
     * para el query principal
     * del detalle
     * del producto
     */
    public static final String GUION_TRAN="_TRAN ";
    /**
     * constante para la parte de
     * la sentencia del query
     * SELECT PROD.* FROM (
     */
    public static final String SELECT = "SELECT PROD.ID_REG, PROD.BUC, PROD.NUM_CTA_CARGO, PROD.NUM_CTA_ABONO, PROD.CVE_PROD_OPER,"
    		+"PROD.DESC_PROD, PROD.NOMBRE_ARCH, PROD.REFERENCIA, PROD.ID_ESTATUS, PROD.DESC_ESTATUS," 
    		+"PROD.IMPORTE, PROD.CLAVE_DESE, PROD.TIPO_CAMBIO, PROD.NUM_CNTR, PROD.DIVISA, "
    		+"PROD.FECHA_REGISTRO, PROD.FECHA_APLICACION, PROD.VIST_PROD, PROD.INTERMEDIARIO_ORD, PROD.DIVISA_ORD,"
    		+"PROD.INTERMEDIARIO_REC, PROD.BENEFICIARIO,  PROD.COMENTARIO_1,  PROD.COMENTARIO_2, PROD.COMENTARIO_3,"
    		+"PROD.TITULAR, PROD.BANCO_RECEPTOR,  PROD.TIPO_PAGO,  PROD.MODALIDAD, PROD.IMPORTE_CARGO, "
    		+"PROD.MSG_H2H,  PROD.MSG_ORDEN_PAGO,  PROD.NUM_ORDEN,  PROD.FECHA_LIMITE_PAGO,  PROD.NUM_SUCURSAL," 
    		+"PROD.FECH_VENC, PROD.REFERENCIA_ABONO,  PROD.REFERENCIA_CARGO,  PROD.NUMERO_EMPLEADO,  PROD.NUMERO_TARJETA," 
    		+"PROD.BUC_EMPLEADO,  PROD.SUCURSAL_TUTORA,  PROD.RFC,  PROD.NOMBRE_EMPLEADO,  PROD.NUMERO_CUENTA,"
    		+"PROD.DESCRIPCION, PROD.FECHA_PRESENTACION_INICIAL, PROD.FECHA_OPERACION, PROD.NUME_MOVI, PROD.REF_CVE_RSTO FROM (";
    /**
     * Query de campos para el
     * producto de transferencias internacionales
     * Cambiarias
     *
     */
    public static final String QUERY = "SELECT id_reg, CLTE.buc, DETA.NUM_CTA_ORD NUM_CTA_CARGO, " +
    		"DETA.NUM_CTA_BENE NUM_CTA_ABONO, REG.cve_prod_oper, PROD.desc_prod, ARCH.nombre_arch, DETA.TXT_REF REFERENCIA, REG.id_estatus, " +
    		"EST.desc_estatus, DETA.IMP_ABONO_BENE IMPORTE, DETA.TXT_CVE_DESE CLAVE_DESE, DETA.NUM_TIPO_CAMBIO TIPO_CAMBIO, CNTR.num_cntr, " +
    		"REG.divi DIVISA, ARCH.fecha_registro, DETA.FCH_APLI FECHA_APLICACION, PROD.vist_prod,NULL INTERMEDIARIO_ORD, " +
    		"DETA.COD_DIV_CTA_ORD  DIVISA_ORD, NULL INTERMEDIARIO_REC, DETA.TXT_NOM_BENE BENEFICIARIO, NULL COMENTARIO_1, NULL COMENTARIO_2, " +
    		"NULL COMENTARIO_3, DETA.TXT_NOM_ORD TITULAR, DETA.TXT_NOM_BCO_PAG BANCO_RECEPTOR, NULL TIPO_PAGO, NULL MODALIDAD, " +
    		"DETA.IMP_CARGO_ORD IMPORTE_CARGO, MSG.msg_h2h, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, " +
    		"NULL FECH_VENC, DETA.TXT_REF REFERENCIA_ABONO, NULL REFERENCIA_CARGO, NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, " +
    		"NULL BUC_EMPLEADO, NULL SUCURSAL_TUTORA, NULL RFC, NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, NULL DESCRIPCION, " +
    		"DETA.FCH_REG FECHA_PRESENTACION_INICIAL, REG.fech_envi_back FECHA_OPERACION, REG.nume_movi, null REF_CVE_RSTO ";
    /**
     * Constnate para el query
     * del producto de Vostro
     * internacionales
     * Cambiarias
     */
    public static final String QUERY_VOSTRO_INT = "SELECT id_reg, CLTE.buc, DETA.NUM_CTA_ORD NUM_CTA_CARGO," +
    		"DETA.NUM_CTA_BENE NUM_CTA_ABONO, REG.cve_prod_oper, PROD.desc_prod, ARCH.nombre_arch, DETA.TXT_REFE_OUT REFERENCIA, REG.id_estatus,"+ 
    		"EST.desc_estatus, DETA.IMP_ABONO_BENE IMPORTE,null CLAVE_DESE,null TIPO_CAMBIO, CNTR.num_cntr, "+
    		"DETA.COD_DIV_CTA_BENE DIVISA, ARCH.fecha_registro, DETA.FCH_APLI FECHA_APLICACION, PROD.vist_prod,NULL INTERMEDIARIO_ORD,"+ 
    		"DETA.COD_DIV_CTA_ORD  DIVISA_ORD, NULL INTERMEDIARIO_REC, DETA.TXT_NOM_BENE BENEFICIARIO,banc.NOMBRE_BANCO COMENTARIO_1, NULL COMENTARIO_2,"+ 
    		"NULL COMENTARIO_3, DETA.TXT_NOM_ORD TITULAR, DETA.TXT_NOM_BCO_PAG BANCO_RECEPTOR, NULL TIPO_PAGO, NULL MODALIDAD, "+
    		"DETA.IMP_CARGO_ORD IMPORTE_CARGO, MSG.msg_h2h, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL,"+ 
    		"NULL FECH_VENC, null REFERENCIA_ABONO, NULL REFERENCIA_CARGO, NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, "+
    		"NULL BUC_EMPLEADO, NULL SUCURSAL_TUTORA, NULL RFC, NULL NOMBRE_EMPLEADO, DETA.NUM_CTA_VOS NUMERO_CUENTA, NULL DESCRIPCION,"+ 
    		"null FECHA_PRESENTACION_INICIAL, DETA.FCH_REG  FECHA_OPERACION, REG.nume_movi, DETA.txt_refe_envi_out REF_CVE_RSTO ";
    /**
     * query parte con datos a seleccionar
     * los datos de el producto de
     * TRANSFERENCIAS VOSTRO MISMO BANCO MXN-MXN
     */
    public static final String QUERY_VOSTRO_MB = " SELECT id_reg, CLTE.buc, DETA.NUM_CTA_ORD NUM_CTA_CARGO,"+
    		"DETA.NUM_CTA_BENE_FIN NUM_CTA_ABONO, REG.cve_prod_oper, PROD.desc_prod, ARCH.nombre_arch, DETA.REFE_SAF REFERENCIA, REG.id_estatus,"+ 
    		"EST.desc_estatus, DETA.IMP_MONTO_OPER IMPORTE,null CLAVE_DESE,null TIPO_CAMBIO, CNTR.num_cntr, "+
    		"REG.DIVI DIVISA, ARCH.fecha_registro, DETA.FCH_APLI FECHA_APLICACION, PROD.vist_prod,NULL INTERMEDIARIO_ORD,"+
    		"DETA.COD_DIVI_CARG  DIVISA_ORD, NULL INTERMEDIARIO_REC, DETA.TXT_NOM_BEN_FIN BENEFICIARIO, 'Banco Santander (MÃ©xico) S.A.' COMENTARIO_1, NULL COMENTARIO_2,"+ 
    		"NULL COMENTARIO_3, DETA.TXT_NOMB_ORDE TITULAR, DETA.CUENTA_ID_BANCO BANCO_RECEPTOR, NULL TIPO_PAGO, NULL MODALIDAD, "+
    		"DETA.IMP_MONTO_OPER IMPORTE_CARGO, MSG.msg_h2h, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL,"+
    		"NULL FECH_VENC, null REFERENCIA_ABONO, NULL REFERENCIA_CARGO, NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, "+
    		"NULL BUC_EMPLEADO, NULL SUCURSAL_TUTORA, NULL RFC, NULL NOMBRE_EMPLEADO, DETA.NUM_CTA_VOS NUMERO_CUENTA, NULL DESCRIPCION,"+
    		"null FECHA_PRESENTACION_INICIAL, DETA.FECH_REG  FECHA_OPERACION, REG.nume_movi, null REF_CVE_RSTO ";
    /**
     * constante para el
     * From del query principal de
     * transferencias vostro
     * FROM
     */
    public static final String FROM_TRAN = "%s DETA " +
    		"INNER JOIN h2h_reg%s REG using(id_reg) " +
    		"INNER JOIN h2h_archivo%s ARCH ON ARCH.id_archivo = REG.id_arch " +
    		"INNER JOIN h2h_cntr CNTR using (id_cntr) " +
    		"INNER JOIN h2h_clte CLTE using (id_clte) " +
    		"INNER JOIN h2h_cat_prod PROD ON PROD.cve_prod_oper = REG.cve_prod_oper " +
    		"INNER JOIN h2h_cat_estatus EST ON REG.id_estatus = EST.id_cat_estatus " +
    		"LEFT JOIN h2h_msg MSG ON MSG.id_msg = REG.id_msg";

    /**
     * Constructor privado.
     */
    private DetailVostroQueryConstants() {

    }
}
