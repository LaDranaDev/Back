package mx.santander.h2h.monitoreo.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.commons.utils.ConsultaTrackingUtil;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.NivelArchivoRequest;
import mx.santander.h2h.monitoreo.model.response.ArchivoGeneralResponse;
import mx.santander.h2h.monitoreo.model.response.ArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.NivelArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ProdArchResponse;
import mx.santander.h2h.monitoreo.model.response.ProductoArchivoResponse;
import mx.santander.h2h.monitoreo.repository.IConsultaTrackingNativeBRepository;
import mx.santander.h2h.monitoreo.repository.IConsultaTrackingNativeRepository;
import mx.santander.h2h.monitoreo.repository.IConsultaTrackingRepository;

@Service
@Slf4j
public class ArchivoTrackingBService implements IArchivoTrackingBService {
	
	@Autowired
    private IConsultaTrackingRepository consultaTrackingRepository;
	
    @Autowired
    private IConsultaTrackingNativeRepository consultaTrackingNativeRepository;
    
    @Autowired
    private IConsultaTrackingNativeBRepository consultaTrackingNativeBRepository;
    
    @Autowired
    private IJasperReportService reportService;
	
	@Override
	public ArchivoGeneralResponse obtenerDetalleArchivos(String codCliente, Pageable page) {
		String stringDate= new SimpleDateFormat("dd/MM/yyyy").format(new Date());
		return consultaTrackingNativeRepository.obtenerDetalleArchivosGeneral(page, stringDate, codCliente);
	}

	@Override
	public NivelArchivoResponse consultaTrakingNivelArchivo(NivelArchivoRequest nivelArchivo) {
		NivelArchivoResponse archivoResponse = new NivelArchivoResponse();
		String fecha = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
		String codCliente = nivelArchivo.getIdCliente();
		String nombreArchivo = "";
		String nombreCliente = nivelArchivo.getCliente();
		int estatus = nivelArchivo.getEstatus();
		
		archivoResponse.setNombreCliente(nombreCliente);
		archivoResponse.setCodCliente(codCliente);
		archivoResponse.setFecha(fecha);
		archivoResponse.setBeanArchivo(obtenerConteoArchivosNivelArchivo(fecha, codCliente));
		archivoResponse.getBeanArchivo().setTotMontoRecibFmt(ConsultaTrackingUtil.formateaImporteArchivo(archivoResponse.getBeanArchivo().getTotMontoRecib()));
		archivoResponse.setEstatus(estatus);
		archivoResponse.setNombreArchivo(nombreArchivo);
		
		return archivoResponse;
	}

	@Override
	public ArchivoResponse obtenerConteoArchivosNivelArchivo(String fecha, String codCliente) {
    	
    	List<Object[]> obtenerConteoArchivosResult = consultaTrackingRepository.obtenerConteoArchivosNivelArchivo(codCliente, fecha);

		ArchivoResponse archivoResponseTotal = new ArchivoResponse();
		
    	if(obtenerConteoArchivosResult != null) {
    		for(Object[] conteoArchivo : obtenerConteoArchivosResult) {		
    			archivoResponseTotal.setTotArchRecib((BigDecimal)conteoArchivo[0]);
    			archivoResponseTotal.setTotOpeRecib((BigDecimal)conteoArchivo[1]);
    			archivoResponseTotal.setTotMontoRecib((BigDecimal)conteoArchivo[2]);
    			archivoResponseTotal.setTotDupl((BigDecimal)conteoArchivo[3]);
    			archivoResponseTotal.setTotRecib((BigDecimal)conteoArchivo[4]);
    			archivoResponseTotal.setTotRecha((BigDecimal)conteoArchivo[5]);
    			archivoResponseTotal.setTotVald((BigDecimal)conteoArchivo[6]);
    			archivoResponseTotal.setTotEnroll((BigDecimal)conteoArchivo[7]);
    			archivoResponseTotal.setTotEnProc((BigDecimal)conteoArchivo[8]);
    			archivoResponseTotal.setTotEsp((BigDecimal)conteoArchivo[9]);
    			archivoResponseTotal.setTotProc((BigDecimal)conteoArchivo[10]);
    		}
    	}
    	
    	return archivoResponseTotal;
	}

	@Override
	public Map<String, Object> obtenerDetalleArchivosNivelArchivo(NivelArchivoRequest nivelArchivo, Pageable page) {
		String fecha = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
		String codCliente = nivelArchivo.getIdCliente();
		String nombreArchivo = nivelArchivo.getNombreArchivo();
		int estatus = nivelArchivo.getEstatus();
		
		return consultaTrackingNativeBRepository.obtenerDetalleArchivosNivelArchivo(page, fecha, codCliente, nombreArchivo, estatus);
	}

	@Override
	public List<ProdArchResponse> obtenerListDetalleArchivosNivelArchivo(NivelArchivoRequest nivelArchivo) {
		String fecha = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
		String codCliente = nivelArchivo.getIdCliente();
		String nombreArchivo = nivelArchivo.getNombreArchivo();
		int estatus = nivelArchivo.getEstatus();
		
		return consultaTrackingNativeBRepository.obtenerListDetalleArchivosNivelArchivo(fecha, codCliente, nombreArchivo, estatus);
	}

	@Override
	public ReportResponse getReportXls(NivelArchivoRequest nivelArchivo, String usuario) {
		ReportResponse response = new ReportResponse();
		try {
			NivelArchivoResponse responseNivArch = this.consultaTrakingNivelArchivo(nivelArchivo);
			List<ProdArchResponse> lista = obtenerListDetalleArchivosNivelArchivo(nivelArchivo);
			List<ProductoArchivoResponse> lstDatos = getLista( lista );
			
			Map<String, Object> reportParam = new HashMap<>();
			
			reportParam.put("USER", usuario);
			reportParam.put("LOGO_SANTANDER", "\\imgs\\Santander.jpg");
			reportParam.put("NOMBRE_ARCHIVO", "Nombre Archivo");
			reportParam.put("FECHA_RECEPCION", "Fecha Recepción");
			reportParam.put("CANAL", "Canal");
			reportParam.put("ESTATUS", "Estatus");
			reportParam.put("PRODUCTO", "Producto");
			reportParam.put("NUMERO_OPERACIONES", "Número Operaciones");
			reportParam.put("MONTO", "Monto");
			reportParam.put("FILTRO_NOMBRE_ARCHIVO", "Nombre Archivo");
			reportParam.put("FILTRO_CLIENTE", "Cliente");
			reportParam.put("FILTRO_TOTAL_MONTO", "Total de Montos Recibidos");
			reportParam.put("FILTRO_TOTAL_ARCHIVO", "Total de Archivos Recibidos");
			reportParam.put("FILTRO_TOTAL_OPERACIONES", "Total de Operaciones Recibidas");
			reportParam.put("FILTRO_RECHAZADO", "Rechazado");
			reportParam.put("FILTRO_DUPLICADO", "Duplicado");
			reportParam.put("FILTRO_RECIBIDO", "Recibido");
			reportParam.put("FILTRO_EN_PROCESO", "En Proceso");
			reportParam.put("FILTRO_VALIDADO", "Validado");
			reportParam.put("FILTRO_ENVIADO_CLIENTE", "Enviado Cliente");
			reportParam.put("FILTRO_EN_ESPERA", "En Espera");
			reportParam.put("FILTRO_PROCESADO", "Procesado");
			reportParam.put("TITULO_REPORTE", "Consulta Tracking de Archivo" + " - " + "Nivel Archivo");
			reportParam.put("VALOR_NOMBRE_ARCHIVO", responseNivArch.getNombreArchivo());
			reportParam.put("VALOR_CLIENTE", responseNivArch.getNombreCliente());
			reportParam.put("VALOR_TOTAL_MONTO", String.valueOf(responseNivArch.getBeanArchivo().getTotMontoRecibFmt()));
			reportParam.put("VALOR_TOTAL_ARCHIVO", String.valueOf(responseNivArch.getBeanArchivo().getTotArchRecib()));
			reportParam.put("VALOR_TOTAL_OPERACIONES", String.valueOf(responseNivArch.getBeanArchivo().getTotOpeRecib()));
			reportParam.put("VALOR_RECHAZADO", String.valueOf(responseNivArch.getBeanArchivo().getTotRecha()));
			reportParam.put("VALOR_DUPLICADO", String.valueOf(responseNivArch.getBeanArchivo().getTotDupl()));
			reportParam.put("VALOR_RECIBIDO", String.valueOf(responseNivArch.getBeanArchivo().getTotRecib()));
			reportParam.put("VALOR_EN_PROCESO", String.valueOf(responseNivArch.getBeanArchivo().getTotEnProc()));
			reportParam.put("VALOR_VALIDADO", String.valueOf(responseNivArch.getBeanArchivo().getTotVald()));
			reportParam.put("VALOR_ENVIADO_CLIENTE", String.valueOf(responseNivArch.getBeanArchivo().getTotEnroll()));
			reportParam.put("VALOR_EN_ESPERA", String.valueOf(responseNivArch.getBeanArchivo().getTotEsp()));
			reportParam.put("VALOR_PROCESADO", String.valueOf(responseNivArch.getBeanArchivo().getTotProc()));
			
			 
			response = reportService.getXls("NivelArchivo.jasper", reportParam, lstDatos);
			
			response.setType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
		}catch (BusinessException e) {
			log.error("Error en la generacion del reporte en xls Consulta Tracking Nivel General.", e);
			throw e;
		} finally {
			log.info("Fin operacion: Genera reporte en xls Consulta Tracking Nivel General");
		}
		
		return response;
	}

	/**
	 * Regresamos la lista normal al Exportador
	 * 
	 * @param lista
	 * @return
	 */
	private List<ProductoArchivoResponse> getLista(List<ProdArchResponse> lista) {
		
		List<ProductoArchivoResponse> lstDatos = new ArrayList<>();
		for(ProdArchResponse datLista : lista) {
			ProductoArchivoResponse bean = new ProductoArchivoResponse();
			bean = datLista.getArchivos();
			List<ProductoArchivoResponse> subDatos = datLista.getLstArchivos();
			lstDatos.add(bean);
			lstDatos.addAll(subDatos);
		}
		
		return lstDatos;
	}

}
