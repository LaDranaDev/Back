package mx.santander.h2h.monitoreo.repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.commons.utils.ConsultaTrackingUtil;
import mx.santander.h2h.monitoreo.model.response.ProdArchResponse;
import mx.santander.h2h.monitoreo.model.response.ProductoArchivoResponse;
import mx.santander.h2h.monitoreo.util.UtilData;


/**
 * Clase generada para ConsultaTrackingNativeBRepository.
 *
 * @autor fabrica_sw
 * @modifico C320868
 */
@Repository
@Slf4j
public class ConsultaTrackingNativeBRepository implements IConsultaTrackingNativeBRepository {
	
	/** Declaracion de EntityManager para entityManager. */
	@Autowired
	@PersistenceContext
	private EntityManager entityManager;
	
	/** Declaracion de Constante MAX_ELEM_EXCEL. */
	public static final int MAX_ELEM_EXCEL = 100000;
	
	/** Declaracion de Constante EMPTY. */
	private static final String EMPTY = "";
	
	
	/**
	 * Obtener detalle archivos nivel archivo.
	 *
	 * @param page para page
	 * @param fecha para fecha
	 * @param codCliente para cod cliente
	 * @param nomArch para nom arch
	 * @param estatus para estatus
	 * @return el page
	 */
	@Override
	public Map<String, Object> obtenerDetalleArchivosNivelArchivo(Pageable page, String fecha, String codCliente, String nomArch, Integer estatus) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder = ConsultaTrackingUtil.obtenerQueryDetalle(nomArch, estatus);
		
		Query query = entityManager.createNativeQuery(queryBuilder.toString());
		ConsultaTrackingUtil.setParamsNivelArchivo(fecha, codCliente, nomArch, estatus, query);
		
		query.setFirstResult(page.getPageNumber() * page.getPageSize());
		query.setMaxResults(page.getPageSize());
		// Obtenemos los datoss
		List<Object[]> detalleArchivosResult = query.getResultList();
		List<ProductoArchivoResponse> listBean = new ArrayList<ProductoArchivoResponse>();
		
		Integer idArchivoAnterior = -1;
		Integer numOp = 0;
		Integer estatusm =0; 
		String  motivo="";
		BigDecimal monto = new BigDecimal(0);
		
		if (detalleArchivosResult != null) {
			Object[] result = forComplement(detalleArchivosResult, idArchivoAnterior, numOp, monto, estatusm, listBean, motivo);
			estatusm = UtilData.toInt(result[2]);
			if (!listBean.isEmpty()) {
				if(estatusm==16){
					//se agrega el motivo de rechazo para los archivos rechazados
					addRechazo(listBean, motivo);
				}
				ProductoArchivoResponse subTotal = new ProductoArchivoResponse();
				subTotal.setProducto("TOTAL");
				subTotal.setTotalOperaciones( UtilData.toInt(result[0]));
				subTotal.setMonto( UtilData.toBigDecimal(result[1]) );
				listBean.add(subTotal);
			}
		}
		
		query.setFirstResult(0);
		query.setMaxResults(Integer.MAX_VALUE);
		Integer totalRows = query.getResultList().size();
		// Regresamos los datos
		List<ProdArchResponse> respuesta = verificarDetalleArchivos(listBean, estatusm);
		Map<String, Object> datMapa = new HashMap<>();
		datMapa.put("content", respuesta);
		datMapa.put("totalElementos", totalRows);
		datMapa.put("totalPages", page);
		//return new PageImpl<>(respuesta, page, totalRows);
		return datMapa;
	}
	
	
	/**
	 * Obtener detalle archivos nivel archivo complement.
	 *
	 * @param idArchivoActual para id archivo actual
	 * @param idArchivoAnterior para id archivo anterior
	 * @param numOp para num op
	 * @param bean para bean
	 * @param monto para monto
	 * @param estatusm para estatusm
	 * @param listBean para list bean
	 * @param motivo para motivo
	 */
	public void obtenerDetalleArchivosNivelArchivoComplement(Integer idArchivoActual, Integer idArchivoAnterior, Integer numOp, ProductoArchivoResponse bean, 
			BigDecimal monto, Integer estatusm, List<ProductoArchivoResponse> listBean, String  motivo) {
		if (idArchivoActual != 0 && idArchivoActual.equals(idArchivoAnterior)) {
			numOp += bean.getTotalOperaciones();
			monto = monto.add(bean.getMonto());
			bean.setNombreArchivo( EMPTY );
			bean.setFechaRecep( EMPTY );
			bean.setEstatus( EMPTY );
			bean.setCanal( EMPTY );
		} else {
			if(estatusm==16){
				//se agrega el motivo de rechazo para los archivos rechazados
				addRechazo(listBean, motivo);
			}
			ProductoArchivoResponse subTotal = new ProductoArchivoResponse();
			subTotal.setProducto("TOTAL");
			subTotal.setTotalOperaciones(numOp);
			subTotal.setMonto(monto);
			listBean.add(subTotal);
			numOp = 0;
			monto = new BigDecimal(0);
			numOp += bean.getTotalOperaciones();
			monto = monto.add(bean.getMonto());
		}
	}
	
	
	/**
	 * Verificar detalle archivos.
	 *
	 * @param detalle para detalle
	 * @param estatus para estatus
	 * @return el list
	 */
	public List<ProdArchResponse> verificarDetalleArchivos(List<ProductoArchivoResponse> detalle, Integer estatus)  {
		// Validamos que los campos no esten vacios
		if (detalle.isEmpty()){
			return null;
		}
		
		final String primerArchivoLista = detalle.get(0).getMontoFmt();
		List<Object[]> archivoIni = obtenerDetalleArchivo(primerArchivoLista);
		int con = 0;
		
		while(!"TOTAL".equals((detalle.get(con++).getProducto())));
		con--;
		log.info("[I] con < archivoIni.size() -> " + con + " < " + archivoIni.size());
		if (con < archivoIni.size()){
			detalle.get(0).setNombreArchivo( EMPTY );
			detalle.get(0).setFechaRecep( EMPTY );
			detalle.get(0).setEstatus( EMPTY );
			BigDecimal montoTotal = new BigDecimal(0);
			int totalOpers = 0;
			for (Object[] prod : archivoIni) {
				montoTotal = montoTotal.add( UtilData.toBigDecimal(prod[8]) );
				totalOpers += Integer.parseInt( UtilData.toString(prod[7]) );
			}
			detalle.get(con).setMonto(montoTotal);
			detalle.get(con).setTotalOperaciones(totalOpers);
		}
		
		String ultimoArchivoLista ="";
		if(estatus == 16 )
			ultimoArchivoLista = detalle.get(detalle.size() - 3).getMontoFmt();
		else
			ultimoArchivoLista = detalle.get(detalle.size() - 2).getMontoFmt();
		List<Object[]> archivoFin = obtenerDetalleArchivo(ultimoArchivoLista);
		int productosoDelArchivo = 0;
		for (ProductoArchivoResponse bean : detalle){
			if (ultimoArchivoLista.equals(bean.getMontoFmt())){
				productosoDelArchivo++;
			}
		}
		
		log.info("[I] productosoDelArchivo < archivoFin.size() -> " + productosoDelArchivo + " < " + archivoFin.size());
		if (productosoDelArchivo < archivoFin.size() && !ultimoArchivoLista.equals(primerArchivoLista)){
			int index =  detalle.size() - 1;
			if(detalle.get(index).getNombreArchivo() == null 
				&& detalle.get(index).getFechaRecep() == null 
				&& detalle.get(index).getEstatus() == null ){
					detalle.remove(index);
				}
		}
		
		List<ProdArchResponse> lstProductos = new ArrayList<>();
		List<ProductoArchivoResponse> lstBean = new ArrayList<>();
		ProdArchResponse productos = new ProdArchResponse();
		boolean agregar = false;
		for(ProductoArchivoResponse datGet : detalle) {
			if( !UtilData.isVacio(datGet.getNombreArchivo()) && (datGet.getFechaRecep() != null)) {
				productos = new ProdArchResponse();
				productos.setArchivos( datGet );
				agregar = true;
			} else if("TOTAL".equals(datGet.getProducto()) && agregar) {
				lstBean.add(datGet);
				productos.setLstArchivos(lstBean);
				// Agregamos los datos
				lstProductos.add(productos);
				lstBean = new ArrayList<>();
				agregar = false;
			} else {
				if( agregar ) {
					lstBean.add(datGet);
				}
			}
		}
		
		return lstProductos;
	}
	
	
	/**
	 * Obtener detalle archivo.
	 *
	 * @param idArchivo para id archivo
	 * @return el list
	 */
	private List<Object[]> obtenerDetalleArchivo(String idArchivo) {
		log.info("obtenerDetalleArchivo -> " + idArchivo);
		StringBuilder consulta = new StringBuilder();
		consulta.append("SELECT A.ID_ARCHIVO,A.NOMBRE_ARCH,A.FECHA_REGISTRO,")
		.append("A.ID_ESTATUS,B.DESC_ESTATUS,C.ID_PROD,C.DESC_PROD,")
		.append("SUM (NVL(D.TOTA_OPER,0)) AS TOTAL_OPER, SUM (NVL(D.TOTA_MONT,0)) AS TOTAL_MONT ")
		.append("FROM H2H_ARCHIVO_TRAN A ")
		.append("LEFT  JOIN H2H_ARCH_PROD_TRAN D ON D.ID_ARCHIVO = A.ID_ARCHIVO ")
		.append("INNER JOIN H2H_CAT_ESTATUS B ON B.ID_CAT_ESTATUS  =  A.ID_ESTATUS ")
		.append("LEFT JOIN H2H_CAT_PROD C ON C.CVE_PROD_OPER = D.CVE_PROD_OPER ")
		.append("WHERE A.ID_ARCHIVO = :idArchivo ")
		.append("GROUP BY A.ID_ARCHIVO,A.NOMBRE_ARCH, A.FECHA_REGISTRO, A.ID_ESTATUS, B.DESC_ESTATUS, C.ID_PROD, C.DESC_PROD ");
		
		Query query = entityManager.createNativeQuery(consulta.toString());
		this.setParamsIdArchivo(idArchivo, query);
		
		return query.getResultList();
	}
	
	
	/**
	 * Establece el params id archivo.
	 *
	 * @param idArchivo para id archivo
	 * @param query para query
	 */
	public void setParamsIdArchivo(String idArchivo, Query query) {
		query.setParameter("idArchivo", idArchivo);
	}

	
	/**
	 * Agrega el rechazo.
	 *
	 * @param listBean para list bean
	 * @param motivo para motivo
	 */
	private void addRechazo(List<ProductoArchivoResponse> listBean, String motivo ) {
		log.info("addRechazo - motivo -> " + motivo );
		ProductoArchivoResponse rechazo = new ProductoArchivoResponse();
		rechazo.setProducto(motivo);
		listBean.add(rechazo);	
	}

	
	/**
	 * Obtener list detalle archivos nivel archivo.
	 *
	 * @param fecha para fecha
	 * @param codCliente para cod cliente
	 * @param nomArch para nom arch
	 * @param estatus para estatus
	 * @return el list
	 */
	@Override
	public List<ProdArchResponse> obtenerListDetalleArchivosNivelArchivo(String fecha, String codCliente, String nomArch, Integer estatus) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder = ConsultaTrackingUtil.obtenerQueryDetalle(nomArch, estatus);
		
		StringBuilder queryBuilderExcel = new StringBuilder();
		queryBuilderExcel = ConsultaTrackingUtil.getQueryExcel(queryBuilder.toString(), MAX_ELEM_EXCEL);
		
		Query query = entityManager.createNativeQuery(queryBuilderExcel.toString());
		ConsultaTrackingUtil.setParamsNivelArchivo(fecha, codCliente, nomArch, estatus, query);
		
		List<Object[]> detalleArchivosResult = query.getResultList();
		
		List<ProductoArchivoResponse> listBean = new ArrayList<ProductoArchivoResponse>();
		
		Integer idArchivoAnterior = -1;
		Integer numOp = 0;
		Integer estatusm =0; 
		String  motivo="";
		BigDecimal monto = new BigDecimal(0);
		
		if (detalleArchivosResult != null) {
			Object[] result = forComplement(detalleArchivosResult, idArchivoAnterior, numOp, monto, estatusm, listBean, motivo);
			estatusm = UtilData.toInt(result[2]);
			if (!listBean.isEmpty()) {
				if(estatusm==16){
					//se agrega el motivo de rechazo para los archivos rechazados
					addRechazo(listBean, motivo);
				}
				ProductoArchivoResponse subTotal = new ProductoArchivoResponse();
				subTotal.setProducto("TOTAL");
				subTotal.setTotalOperaciones( UtilData.toInt(result[0]) );
				subTotal.setMonto( UtilData.toBigDecimal(result[1]) );
				listBean.add(subTotal);
			}		
		}
		List<ProdArchResponse> datRespuesta = verificarDetalleArchivos(listBean, estatusm);
		return datRespuesta;
	}
	
	
	/**
	 * For complement.
	 *
	 * @param detalleArchivosResult para detalle archivos result
	 * @param idArchivoAnterior para id archivo anterior
	 * @param numOp para num op
	 * @param monto para monto
	 * @param estatusm para estatusm
	 * @param listBean para list bean
	 * @param motivo para motivo
	 * @return el object[]
	 */
	public Object[] forComplement(List<Object[]> detalleArchivosResult, Integer idArchivoAnterior, Integer numOp, BigDecimal monto, Integer estatusm, List<ProductoArchivoResponse> listBean, String  motivo) {
		Object[] resultOperMont = new Object[4];
		Integer idArchivoActual = -1;
		for (Object[] map : detalleArchivosResult) {
			ProductoArchivoResponse bean = new ProductoArchivoResponse();
			bean.setMontoFmt( UtilData.toString(map[0]) );
			idArchivoActual = UtilData.toInt(map[0]);
			bean.setIdArchivo( idArchivoActual );
			bean.setNombreArchivo( UtilData.toString(map[1]) );
			bean.setFechaRecep( UtilData.toString(map[3]) );
			bean.setEstatus( UtilData.toString(map[5]) );
			bean.setProducto( UtilData.toString(map[7]) );
			bean.setCanal( UtilData.toString(map[8]) );
			bean.setTotalOperaciones( UtilData.toInt(map[10]) );
			bean.setMonto( UtilData.toBigDecimal(map[11]) );
			bean.setIdEstatus( UtilData.toInt(map[4]) );
			bean.setMotRechazo( UtilData.toString(map[9]) );
			if (detalleArchivosResult.indexOf(map) == 0) {
				resultOperMont[0] = numOp = bean.getTotalOperaciones();
				resultOperMont[1] = monto = bean.getMonto();
			} else {
				if (idArchivoActual != 0 && idArchivoActual.equals(idArchivoAnterior)) {
					resultOperMont[0] = numOp += bean.getTotalOperaciones();
					resultOperMont[1] = monto = monto.add(bean.getMonto());
					bean.setNombreArchivo(  EMPTY  );
					bean.setFechaRecep(  EMPTY  );
					bean.setEstatus(  EMPTY  );
					bean.setCanal(  EMPTY  );
				} else {
					refactorForComplement(estatusm, listBean, motivo);
					ProductoArchivoResponse subTotal = new ProductoArchivoResponse();
					subTotal.setProducto("TOTAL");
					subTotal.setTotalOperaciones(numOp);
					subTotal.setMonto(monto);
					listBean.add(subTotal);
					numOp = 0;
					monto = new BigDecimal(0);
					resultOperMont[0] = numOp += bean.getTotalOperaciones();
					resultOperMont[1] = monto = monto.add(bean.getMonto());
				}
			}
			listBean.add(bean);
			idArchivoAnterior = idArchivoActual;
			resultOperMont[2] = estatusm = bean.getIdEstatus();
			resultOperMont[3] = motivo = bean.getMotRechazo();
		}
		return resultOperMont;
	}
	
	
	/**
	 * Refactor for complement.
	 *
	 * @param estatusm para estatusm
	 * @param listBean para list bean
	 * @param motivo para motivo
	 */
	public void refactorForComplement(Integer estatusm, List<ProductoArchivoResponse> listBean, String  motivo) {
		if(estatusm==16){
			//se agrega el motivo de rechazo para los archivos rechazados
			addRechazo(listBean, motivo);
		}
	}
}
