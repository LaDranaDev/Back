package mx.santander.h2h.monitoreo.exception.commons;

/**
 * Clase que es usada cuando se utiliza o sucede una exception personalizada
 *
 * @author Paul Quintero
 * @since 10/05/2022
 */
public class NotDataFoundException extends RuntimeException {

	/**
	 * Serial UID
	 */
	private static final long serialVersionUID = 4853473105635998033L;

	/** Constructor de la clase. */
	public NotDataFoundException() {
		super();
	}

	/**
	 * Constructor de la clase.
	 *
	 * @param message mensaje de error
	 */
	public NotDataFoundException(String message) {
		super(message);
	}
}
