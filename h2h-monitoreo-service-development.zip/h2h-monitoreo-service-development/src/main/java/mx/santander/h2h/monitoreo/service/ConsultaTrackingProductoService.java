package mx.santander.h2h.monitoreo.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.commons.utils.ConsultaTrackingUtil;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.NivelProductoRequest;
import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import mx.santander.h2h.monitoreo.model.response.NivelProductoResponse;
import mx.santander.h2h.monitoreo.model.response.ProductoArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ResultTrackingResponse;
import mx.santander.h2h.monitoreo.repository.IConsultaTrackingProductoRepository;

@Service
@Slf4j
public class ConsultaTrackingProductoService implements IConsultaTrackingProductoService {

	@Autowired
	private IConsultaTrackingProductoRepository consultaTrackingProductoRepository;
	
	@Autowired
	private IJasperReportService reportService;
	
	@Override
	public NivelProductoResponse iniciaNivelProducto(NivelProductoRequest nivelProducto) {
		NivelProductoResponse nivelProductoResponse = new NivelProductoResponse();
		
		nivelProductoResponse.setFecha(new SimpleDateFormat("dd/MM/yyyy").format(new Date()));
		nivelProductoResponse.setCodCliente(nivelProducto.getCodCliente());
		nivelProductoResponse.setCliente(nivelProducto.getNomCliente());
		nivelProductoResponse.setIdArchivo(nivelProducto.getIdArchivo());
		
		nivelProductoResponse.setListProducto(obtenerCatalogoProducto());
		nivelProductoResponse.setListEstatus(obtenerCatalogoEstatus());
		nivelProductoResponse.setArchivo(obtenerConteoArchivo(nivelProducto.getCodCliente(), nivelProducto.getIdArchivo()));
		
		nivelProductoResponse.getArchivo().setMontoFmt(ConsultaTrackingUtil.formateaImporteProducto(nivelProductoResponse.getArchivo().getMonto()));
		
		return nivelProductoResponse;
	}
	
	@Override
	public List<ComboResponse> obtenerCatalogoProducto() {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		resultTrackingResponse = consultaTrackingProductoRepository.obtenerCatalogoProductos();
		return resultTrackingResponse.getListCombo();
	}

	@Override
	public List<ComboResponse> obtenerCatalogoEstatus() {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		resultTrackingResponse = consultaTrackingProductoRepository.obtenerCatalogoEstatus("R");
		return resultTrackingResponse.getListCombo();
	}

	@Override
	public ProductoArchivoResponse obtenerConteoArchivo(String codCliente, Integer idArchivo) {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		resultTrackingResponse = consultaTrackingProductoRepository.obtenerConteoArchivo(codCliente, idArchivo);
		return resultTrackingResponse.getArchProd();
	}

	@Override
	public Page<ProductoArchivoResponse> obtenerDetalleArchivo(NivelProductoRequest nivelProduto, Pageable page) {
		return consultaTrackingProductoRepository.obtenerDetalleArchivo(page, nivelProduto.getIdArchivo(), nivelProduto.getIdProducto(), nivelProduto.getIdEstatus());
	}

	@Override
	public List<ProductoArchivoResponse> obtenerDetalleArchivo(NivelProductoRequest nivelProduto) {
		return consultaTrackingProductoRepository.obtenerListDetalleArchivo(nivelProduto.getIdArchivo(), nivelProduto.getIdProducto(), nivelProduto.getIdEstatus());
	}

	@Override
	public ReportResponse getReportXls(NivelProductoRequest nivelProduto, String usuario) {
		ReportResponse response = new ReportResponse();
		try {
			NivelProductoResponse responseNivArch = this.iniciaNivelProducto(nivelProduto);
			List<ProductoArchivoResponse> lista = obtenerDetalleArchivo(nivelProduto);
			
			Map<String, Object> reportParam = new HashMap<>();
			
			List<ComboResponse> listEstatus = responseNivArch.getListEstatus();
			List<ComboResponse> listProducto = responseNivArch.getListProducto();
			
			String filProducto = "";
			String filEstatus = "";
			
			for(ComboResponse estatus : listEstatus) {
				if (StringUtils.equals(String.valueOf(estatus.getId()), String.valueOf(nivelProduto.getIdEstatus()))) {
					filEstatus = estatus.getValor();
					break;
				}
			}
			
			for(ComboResponse producto : listProducto) {
				if (StringUtils.equals(String.valueOf(producto.getId()), String.valueOf(nivelProduto.getIdProducto()))) {
					filProducto = producto.getValor();
					break;
				}
			}
			
			reportParam.put("USER", usuario);
			reportParam.put("LOGO_SANTANDER", "\\imgs\\Santander.jpg");
			reportParam.put("PRODUCTO", "Producto");
			reportParam.put("NO_MOVIMIENTOS", "No. Movimientos");
			reportParam.put("ESTATUS_OPERACION", "Estatus Operación");
			reportParam.put("MONTO", "Monto");
			reportParam.put("FILTRO_PRODUCTO", "Producto");
			reportParam.put("FILTRO_ESTATUS_OPERACION", "Estatus Operación");
			reportParam.put("FILTRO_NOMBRE_ARCHIVO", "Nombre Archivo");
			reportParam.put("FILTRO_FECHA_RECEPCION", "Fecha Recepción");
			reportParam.put("FILTRO_ESTATUS_ARCHIV", "Estatus Archivo");
			reportParam.put("FILTRO_NO_MOVIMIENTOS", "No. Movimientos");
			reportParam.put("FILTRO_MONTO", "Monto");
			reportParam.put("TITULO_REPORTE", "Consulta Tracking de Archivo" + " - " + "Nivel Producto");
			reportParam.put("VALOR_PRODUCTO", filProducto);
			reportParam.put("VALOR_ESTATUS_OPERACION", filEstatus);
			reportParam.put("VALOR_NOMBRE_ARCHIVO", String.valueOf(responseNivArch.getArchivo().getNombreArchivo()));
			reportParam.put("VALOR_FECHA_RECEPCION", String.valueOf(responseNivArch.getArchivo().getFechaRecep()));
			reportParam.put("VALOR_ESTATUS_ARCHIVO", String.valueOf(responseNivArch.getArchivo().getEstatus()));
			reportParam.put("VALOR_NO_MOVIMIENTOS", String.valueOf(responseNivArch.getArchivo().getTotalOperaciones()));
			reportParam.put("VALOR_MONTO", String.valueOf(responseNivArch.getArchivo().getMontoFmt()));
			
			response = reportService.getXls("NivelProducto.jasper", reportParam, lista);
			
			response.setType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
		}catch (BusinessException e) {
			log.error("Error en la generacion del reporte en xls Consulta Tracking Nivel General.", e);
			throw e;
		} finally {
			log.info("Fin operacion: Genera reporte en xls Consulta Tracking Nivel General");
		}
		
		return response;
	}

}
