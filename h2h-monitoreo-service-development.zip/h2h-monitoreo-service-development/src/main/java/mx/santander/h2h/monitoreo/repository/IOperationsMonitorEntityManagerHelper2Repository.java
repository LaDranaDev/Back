package mx.santander.h2h.monitoreo.repository;

/**
 * IOperationsMonitorEntityManagerHelper2Repository.
 */
public interface IOperationsMonitorEntityManagerHelper2Repository {
}
