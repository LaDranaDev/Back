package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.HistorialOperacionesRequest;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
/**
 * Interface IGenerateVouchersOperacionesService
 */
public interface IGenerateVouchersOperacionesService {

	/**
	 * Metodo que realiza la exportacion 
	 * del hitorial de 
	 * operaciones
	 * @param historialOperacionesRequest HistorialOperacionesRequest
	 * @return ReportResponse
	 */
	ReportResponse exportarHistorialOperacionesXlsx(HistorialOperacionesRequest historialOperacionesRequest);
	
	/**
	 * Metodo que realiza la exportacion de Operaciones XLS
	 * @param operationsMonitorQueryRequest OperationsMonitorQueryRequest
	 * @param xlsxExtention String
	 * @return ReportResponse
	 */
	ReportResponse exportarOperacionesXlsx(OperationsMonitorQueryRequest operationsMonitorQueryRequest, String xlsxExtention);
}
