package mx.santander.h2h.monitoreo.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.NivelOperacionRequest;
import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import mx.santander.h2h.monitoreo.model.response.NivelOperacionResponse;
import mx.santander.h2h.monitoreo.model.response.OperacionArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ProductoArchivoResponse;

public interface IConsultaTrackingOperacionService {
	
	NivelOperacionResponse iniciaNivelOperacion(NivelOperacionRequest nivelOperacion);

	List<ComboResponse> obtenerCatalogoEstatus();
	
	ProductoArchivoResponse obtenerConteoArchivo(String codCliente, Integer idArchivo, Integer idProducto, Integer idEstatus);
	
	Page<OperacionArchivoResponse> obtenerDetalleArchivo(NivelOperacionRequest nivelOperacion, Pageable page);
	
	List<OperacionArchivoResponse> obtenerListDetalleArchivo(Integer idArchivo, Integer idProducto, Integer idEstatus);
	
	ReportResponse getReportXls(NivelOperacionRequest nivelOperacion, String usuario);
}
