package mx.santander.h2h.monitoreo.constants;

/**
 * ProductosConstants.
 * Declaracion de las constantes para el query de productos.
 *
 * @author Jesus Soto Aguilar
 * @since 20/04/2023
 */
public final class ProductosConstants {

    /**
     * Query para obtener los productos activos y visibles.
     */
    public static final String QUERY_FIND_PRODUCTOS =
            "SELECT p FROM ProductEntity p WHERE p.bandActivo = 'A' AND p.bandVisiCons = 'A' ORDER BY p.descripcion";

    /**
     * Constructor privado.
     */
    private ProductosConstants(){}
}
