package mx.santander.h2h.monitoreo.controller;

import io.swagger.v3.oas.annotations.Operation;
import mx.santander.h2h.monitoreo.constants.RoutesConstant;
import mx.santander.h2h.monitoreo.model.response.ProductResponse;
import mx.santander.h2h.monitoreo.service.IProductService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


/**
 * MonitorSaldosController.
 * Controller para las peticiones de la pantalla Monitor de Saldos.
 *
 * @author Jesus Soto Aguilar
 * @since 20/04/2023
 */
@RestController
@RequestMapping(RoutesConstant.CATALOGO_PRODUCTOS)
public class ProductosController {

    /**
     * Servicio para obtener los productos.
     */
    private final IProductService productService;

    /**
     * Constructor en donde se realiza la inyeccion de dependencias.
     * @param productService Servicio para obtener los productos
     */
    public ProductosController(IProductService productService){
        this.productService = productService;
    }

    /**
     * Obtiene los productos activos.
     * @return Lista de productos activos.
     */
    @Operation(summary = "Constructor en donde se realiza la inyeccion de dependencias")
    @GetMapping
    public ResponseEntity<List<ProductResponse>> getProductos(){
        return ResponseEntity.ok(productService.getProductos());
    }
}
