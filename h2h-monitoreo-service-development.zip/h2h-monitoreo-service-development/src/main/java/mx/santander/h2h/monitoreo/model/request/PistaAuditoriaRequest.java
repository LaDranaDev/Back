package mx.santander.h2h.monitoreo.model.request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
* Dto PistaAuditoriaRequest
* utilizada para la consulta de asignar informacion
* a la pista de auditoria
* 
* @author Paul Quintero
* @since 8/06/22
*/

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PistaAuditoriaRequest implements Serializable {
	/**
	 * Serial ID
	 */
	private static final long serialVersionUID = -3349017938044390404L;
	/**
	 * Codigo de la operacion
	 */
	private String codigoOperacion;
	/**
	 * Resultado operación
	 */
	private String resultado;
	/**
	 * Nombre operacion
	 */
	private String nombre;
	/**
	 * Mensaje de la pista de auditoria
	 */
	private String mensaje;
	/**
	 * Mensaje de información adicionap para la pista de auditoria
	 */
	private String infoAdicional;
}
