/**
 * 
 */
package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Dto para los datos de salida de la aministracion de conexiones del contrato
 * 
 * @author sbautish
 *
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
public class ContractConnectionManagementResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3358560059649492384L;

	/**
	 * numeroContrato
	 */
	private String numeroContrato;

	/**
	 * razonSocial
	 */
	private String razonSocial;

	/**
	 * codigoCliente
	 */
	private String codigoCliente;

	/**
	 * cuentaEje
	 */
	private String cuentaEje;

	/**
	 * estatus
	 */
	private String estatus;

	/**
	 * protocolo
	 */
	private String protocolo;

	/**
	 * nombreCliente
	 */
	private String nombreCliente;

	/**
	 * personalid
	 */
	private String personalid;

	/**
	 * idContrato
	 */
	private String idContrato;

	/**
	 * envioClte
	 */
	private String envioClte;

}
