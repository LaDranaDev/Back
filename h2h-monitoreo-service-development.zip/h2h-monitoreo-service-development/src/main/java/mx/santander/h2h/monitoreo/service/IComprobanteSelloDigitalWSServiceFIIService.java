package mx.santander.h2h.monitoreo.service;

import java.net.MalformedURLException;

import mx.isban.h2h.comprobantefiscal.ComprobanteSelloDigitalWSServiceFII;

/**
 * Clase que inicia el servicio de ComprobanteSelloDigitalWSServiceFII para su
 * invocacion
 * 
 * @author Omar Rosas
 * @since 20/10/2023
 *
 */
public interface IComprobanteSelloDigitalWSServiceFIIService {

	/**
	 * Metodo que inicializa el servicio de ComprobanteSelloDigitalWSServiceFII
	 * 
	 * @param url Url de invocacion
	 * @return Intancia de servicio
	 * @throws MalformedURLException Error de url malformada
	 */
	ComprobanteSelloDigitalWSServiceFII getWSComprobanteSelloDigitalWSServiceFII(String url)
			throws MalformedURLException;
}
