package mx.santander.h2h.monitoreo.model.response;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * clase para el response de la operacion de buscar archivo
 * implementa la interfas de serializcion para el traspaso entre capas
 * Adicional se implementan las etiquetas lombok de
 * Geter, Seter, ToString, NoArgumentsConstructor
 * para un desarrollo más rapido y con menos codigo.
 * @author NTTDATA-NRL
 * @version 1.0
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
public class ArchivoCancelResponse extends  ArchivoCancelPersonResponse {

    /** Serial version UID de la clase*/
    private static final long serialVersionUID = 491621190340168830L;

    private Long idRegistro;
    /** almacena el id de la operacion */
    private String idOperacion;
    /** almacena la cuenta cargo */
    private String ctaCargo;
    /** almacena la cta Abono */
    private String ctaAbono;
    /** almacena el nombre del producto */
    private String producto;
    /** almacena el canal */
    private String canal;
    /** almacena la referencia */
    private String referencia;
    /** almacena el importe */
    private BigDecimal importe;
    /** almacena la bandera de producto o cierre */
    private String bandera;
    /** almacena el valor de Movimiento */
    private Long movimiento;

}
