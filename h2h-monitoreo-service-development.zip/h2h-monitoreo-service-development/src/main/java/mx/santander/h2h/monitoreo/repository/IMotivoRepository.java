package mx.santander.h2h.monitoreo.repository;

/**
 * IMotivoRepository.
 *
 * @author Jesus Soto Aguilar
 */
public interface IMotivoRepository {

    /**
     * Consulta el motivo de la operacion.
     *
     * @param idOperacion identificador de la operacion
     * @return Motivo de la Operacion.
     */
    String consultaMotivoOperacion(String idOperacion);
}
