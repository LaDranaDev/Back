package mx.santander.h2h.monitoreo.util;

import lombok.extern.slf4j.Slf4j;
import mx.isban.h2h.comprobantes.GeneradorComprobantes;
import mx.isban.h2h.comprobantes.model.Comprobante;
import mx.isban.h2h.comprobantes.model.ComprobanteSalida;
import mx.isban.h2h.comprobantes.model.GeneraComprobanteBean;
import mx.santander.h2h.monitoreo.model.response.ComprobantesOperacionResponse;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * Genera el reporte con el jar de GeneraComprobantes
 * para homologar la generacion de los comprobantes
 * y concentracion de componentes de genarcacion de
 * pdf en un solo componente centarl
 * Clase para la generacion de los reportes
 * en PDF con el Generador de reportes
 * se pude reducir el codigo se trabajara
 * en la version siguiente
 *
 */
@Slf4j
public final class ComprobanteGenerador {

    /**
     * Genera el reporte con el jar de GeneraComprobantes
     * para homologar la generacion de los comprobantes
     * y concentracion de componentes de genarcacion de
     * pdf en un solo componente centarl
     * para el producto de
     * generaReporteAportObrerPat
     * @param obj ComprobantesOperacionDTO
     * @return  byte[]
     */
    public static byte[] generaReporteAportObrerPat(ComprobantesOperacionResponse obj) {

        GeneradorComprobantes gen=new GeneradorComprobantes();
        GeneraComprobanteBean entrada= new GeneraComprobanteBean();
        entrada.setComprobante(Comprobante.APOR_OBR_PAT);
        List<String> datos= new ArrayList<>();
        datos.add("");
        datos.add("");
        datos.add(obj.getContrato());
        datos.add(obj.getBeneficiario());
        datos.add( obj.getTitular());
        datos.add(obj.getBeneficiario());
        datos.add(obj.getCuentaCargo());
        datos.add(obj.getNomProveedor());
        datos.add(obj.getFolioSua());
        datos.add( obj.getRegPatronal());
        if(obj.getPeriodoPago()!= null && !obj.getPeriodoPago().isEmpty() && obj.getPeriodoPago().length()>4){
            // Periodo de Pago
            String mes = obj.getPeriodoPago().substring(4,obj.getPeriodoPago().length());
            mes = "Mes "+ mes;
            String anio = obj.getPeriodoPago().substring(0,4);
            anio = " Año "+ anio;
            datos.add(mes+anio);
        }else{
            datos.add(obj.getPeriodoPago());
        }
        datos.add(obj.getLineaCaptura());
        datos.add(obj.getImporte());
        datos.add(obj.getNumOperacion());//Rellenar
        datos.add(obj.getFechaAplic()); //Formatear
        datos.add(obj.getMedioPresentacion());

        entrada.setDatosBase(datos);

        ComprobanteSalida salidaComp= gen.generaComprobante(entrada);
        log.info("Comprobante APOR_OBR_PAT generado:" +salidaComp.getMensaje());
        return salidaComp.getComprobanteBytes();
    }
    /**
     * Genera el reporte con el jar de GeneraComprobantes
     * para homologar la generacion de los comprobantes
     * y concentracion de componentes de genarcacion de
     * pdf en un solo componente centarl
     * para el producto de
     * generaImpFed
     * @param obj ComprobantesOperacionDTO
     * @return  byte[]
     */
    public static byte[] generaImpFed(ComprobantesOperacionResponse obj){

        GeneradorComprobantes gen=new GeneradorComprobantes();
        GeneraComprobanteBean entrada= new GeneraComprobanteBean();
        entrada.setComprobante(Comprobante.IMP_FED);
        List<String> datos= new ArrayList<String>();
        datos.add(obj.getPlaza());
        datos.add(obj.getSucursal());
        datos.add(obj.getContrato());
        datos.add(obj.getRazonSocial() );
        datos.add(obj.getTitular());
        datos.add(obj.getBeneficiario());
        datos.add(obj.getLineaCaptura());
        datos.add(obj.getCuentaCargo());
        datos.add(obj.getNomProveedor());
        datos.add(obj.getImporte());
        datos.add(obj.getFechaOp());
        datos.add( obj.getNumOrden());
        datos.add(obj.getTipoPago());
        datos.add(obj.getLlavePago());
        entrada.setDatosBase(datos);
        ComprobanteSalida salidaComp= gen.generaComprobante(entrada);
        log.info("Comprobante IMP_FEDgenerado:" +salidaComp.getMensaje());
        return salidaComp.getComprobanteBytes();



    }
    /**
     * Genera el reporte con el jar de GeneraComprobantes
     * para homologar la generacion de los comprobantes
     * y concentracion de componentes de genarcacion de
     * pdf en un solo componente centarl
     * para el producto de
     * generaReportePagRef
     * @param obj ComprobantesOperacionDTO
     * @return  byte[]
     */
    public static byte[] generaReportePagRef(ComprobantesOperacionResponse obj) {

        GeneradorComprobantes gen=new GeneradorComprobantes();
        GeneraComprobanteBean entrada= new GeneraComprobanteBean();
        entrada.setComprobante(Comprobante.SERV_IMP_LOC);
        List<String> datos= new ArrayList<String>();
        datos.add("");
        datos.add("");
        datos.add(obj.getCuentaCargo());
        datos.add(obj.getTitular());
        datos.add(obj.getConvenio());
        datos.add(obj.getClaveRastreo());//nomConvenio
        datos.add(obj.getImporte());//Importe
        datos.add(obj.getConceptoPago());//Concepto Pago
        datos.add(obj.getRefInterbancaria());//Clave Rastreo
        datos.add(obj.getCveProveedor());//Folio operacion
        datos.add(obj.getEstatus());
        datos.add(obj.getFechaAplic());
        datos.add(obj.getTipoPago());
        entrada.setDatosBase(datos);

        ComprobanteSalida salidaComp= gen.generaComprobante(entrada);
        log.info("Comprobante SERV_IMP_LOC :" +salidaComp.getMensaje());
        return salidaComp.getComprobanteBytes();
    }
    /**
     * Genera el reporte con el jar de GeneraComprobantes
     * para homologar la generacion de los comprobantes
     * y concentracion de componentes de genarcacion de
     * pdf en un solo componente centarl
     * para el producto de
     * generaPagoTDC
     * @param comprobantesOperacionDTO ComprobantesOperacionDTO
     * @return  byte[]
     */
    public static byte[] generaPagoTDC(ComprobantesOperacionResponse comprobantesOperacionDTO) {
        GeneradorComprobantes gen=new GeneradorComprobantes();
        GeneraComprobanteBean entrada= new GeneraComprobanteBean();
        entrada.setComprobante(Comprobante.PAGO_TDC_STNDR);
        List<String> datos= new ArrayList<String>();
        datos.add("");
        datos.add("");
        datos.add(comprobantesOperacionDTO.getCuentaCargo());
        datos.add(comprobantesOperacionDTO.getTitular());
        datos.add(comprobantesOperacionDTO.getCuentaAbono());
        datos.add(comprobantesOperacionDTO.getBeneficiario());
        datos.add(comprobantesOperacionDTO.getImporte());
        datos.add(comprobantesOperacionDTO.getConceptoPago());
        datos.add(comprobantesOperacionDTO.getClaveRastreo());
        datos.add(comprobantesOperacionDTO.getRefInterbancaria());
        datos.add(String.valueOf(comprobantesOperacionDTO.getFolioOp()));
        datos.add(comprobantesOperacionDTO.getTipoOper());
        datos.add(comprobantesOperacionDTO.getBanco());
        datos.add(comprobantesOperacionDTO.getEstatus());
        datos.add(comprobantesOperacionDTO.getFechaAplic());
        entrada.setDatosBase(datos);
        ComprobanteSalida salidaComp= gen.generaComprobante(entrada);
        log.info("Comprobante Pago TDC :" +salidaComp.getMensaje());
        return salidaComp.getComprobanteBytes();
    }
    /**
     * Genera el reporte con el jar de GeneraComprobantes
     * para homologar la generacion de los comprobantes
     * y concentracion de componentes de genarcacion de
     * pdf en un solo componente centarl
     * para el producto de
     * generaConfirming
     * @param comprobante ComprobantesOperacionDTO
     * @return  byte[]
     */
    public static byte[] generaConfirming(
            ComprobantesOperacionResponse comprobante) {
        GeneradorComprobantes gen=new GeneradorComprobantes();
        GeneraComprobanteBean entrada= new GeneraComprobanteBean();
        entrada.setComprobante(Comprobante.CONFIRMING);
        List<String> datos= new ArrayList<String>();
        datos.add("");
        datos.add("");
        datos.add(comprobante.getContrato());
        datos.add(comprobante.getRazonSocial());
        datos.add(comprobante.getRfc() );
        datos.add(comprobante.getCuentaCargo());
        datos.add(comprobante.getCveProveedor());
        datos.add(comprobante.getNomProveedor());
        datos.add(comprobante.getRfcProveedor());
        datos.add(comprobante.getTipoDoc());
        datos.add(comprobante.getNoDocu());
        datos.add(comprobante.getDivisa());
        datos.add(comprobante.getCuentaAbono());
        datos.add(comprobante.getBanco());
        datos.add(comprobante.getConceptoPago());
        datos.add(comprobante.getImporte());
        datos.add(comprobante.getFechaVenci());
        datos.add(comprobante.getFechaOp());
        datos.add(comprobante.getFormaAplic());
        datos.add(comprobante.getRefInterbancaria());
        datos.add(comprobante.getFormaPago());
        datos.add(comprobante.getClaveRastreo());
        datos.add(comprobante.getEstatusMov());
        entrada.setDatosBase(datos);
        ComprobanteSalida salidaComp= gen.generaComprobante(entrada);
        log.info("Comprobante Pago Confirming :" +salidaComp.getMensaje());
        return salidaComp.getComprobanteBytes();
    }
    /**
     * Genera el reporte con el jar de GeneraComprobantes
     * para homologar la generacion de los comprobantes
     * y concentracion de componentes de genarcacion de
     * pdf en un solo componente centarl
     * para el producto de
     * generaTEF
     * @param comprobanteTEF ComprobantesOperacionDTO
     * @return  byte[]
     */
    public static byte[] generaTEF(ComprobantesOperacionResponse comprobanteTEF) {
        GeneradorComprobantes gen=new GeneradorComprobantes();
        GeneraComprobanteBean entrada= new GeneraComprobanteBean();
        entrada.setComprobante(Comprobante.TEF);
        List<String> datos= new ArrayList<String>();
        datos.add("");
        datos.add("");
        datos.add(comprobanteTEF.getCuentaCargo());
        datos.add(comprobanteTEF.getTitular());
        datos.add(comprobanteTEF.getCuentaAbono());
        datos.add(comprobanteTEF.getBeneficiario());
        datos.add(comprobanteTEF.getImporte());
        datos.add(comprobanteTEF.getDivisa());
        datos.add(comprobanteTEF.getConceptoPago());
        datos.add(comprobanteTEF.getClaveRastreo());
        datos.add(comprobanteTEF.getRefInterbancaria());
        datos.add(String.valueOf(comprobanteTEF.getFolioOp()));
        datos.add(comprobanteTEF.getTipoOper());
        datos.add(comprobanteTEF.getBanco());
        datos.add(comprobanteTEF.getEstatus());
        datos.add(comprobanteTEF.getFechaAplic());
        entrada.setDatosBase(datos);
        ComprobanteSalida salidaComp= gen.generaComprobante(entrada);
        log.info("Comprobante Pago TEF :" +salidaComp.getMensaje());
        return salidaComp.getComprobanteBytes();
    }
    /**
     * Genera el reporte con el jar de GeneraComprobantes
     * para homologar la generacion de los comprobantes
     * y concentracion de componentes de genarcacion de
     * pdf en un solo componente centarl
     * para el producto de
     * generaNominaMismoBanco
     * @param comprobanteMB ComprobantesOperacionDTO
     * @return  byte[]
     */
    public static byte[] generaNominaMismoBanco(ComprobantesOperacionResponse comprobanteMB) {
        GeneradorComprobantes gen=new GeneradorComprobantes();
        GeneraComprobanteBean entrada= new GeneraComprobanteBean();
        entrada.setComprobante(Comprobante.NOM_MISMO_BANCO);
        List<String> datos= new ArrayList<String>();
        datos.add("");
        datos.add("");
        datos.add(comprobanteMB.getCuentaCargo());
        datos.add(comprobanteMB.getTitular());
        datos.add(comprobanteMB.getCuentaAbono());
        datos.add(comprobanteMB.getBeneficiario());
        datos.add(comprobanteMB.getImporte());
        datos.add(comprobanteMB.getDivisa());
        datos.add(comprobanteMB.getConceptoPago());
        datos.add(comprobanteMB.getClaveRastreo());
        datos.add(comprobanteMB.getRefInterbancaria());
        datos.add(String.valueOf(comprobanteMB.getFolioOp()));
        datos.add(comprobanteMB.getTipoOper());
        datos.add(comprobanteMB.getBanco());
        datos.add(comprobanteMB.getEstatus());
        datos.add(comprobanteMB.getFechaAplic());
        entrada.setDatosBase(datos);
        ComprobanteSalida salidaComp= gen.generaComprobante(entrada);
        log.info("Comprobante Pago NominaMismoBanco :" +salidaComp.getMensaje());
        return salidaComp.getComprobanteBytes();
    }
    /**
     * Genera el reporte con el jar de GeneraComprobantes
     * para homologar la generacion de los comprobantes
     * y concentracion de componentes de genarcacion de
     * pdf en un solo componente centarl
     * para el producto de
     * generaTMB
     * @param comprobanteTMB ComprobantesOperacionDTO
     * @return  byte[]
     */
    public static byte[] generaTMB(ComprobantesOperacionResponse comprobanteTMB) {
        GeneradorComprobantes gen=new GeneradorComprobantes();
        GeneraComprobanteBean entrada= new GeneraComprobanteBean();
        entrada.setComprobante(Comprobante.TMB);
        List<String> datos= new ArrayList<String>();
        datos.add("");
        datos.add("");
        datos.add(comprobanteTMB.getCuentaCargo());
        datos.add(comprobanteTMB.getTitular());
        datos.add(comprobanteTMB.getCuentaAbono());
        datos.add(comprobanteTMB.getBeneficiario());
        datos.add(comprobanteTMB.getImporte());
        datos.add(comprobanteTMB.getDivisa());
        datos.add(comprobanteTMB.getConceptoPago());
        datos.add(comprobanteTMB.getClaveRastreo());
        datos.add(comprobanteTMB.getRefInterbancaria());
        datos.add(String.valueOf(comprobanteTMB.getFolioOp()));
        datos.add(comprobanteTMB.getTipoOper());
        datos.add(comprobanteTMB.getBanco());
        datos.add(comprobanteTMB.getEstatus());
        datos.add(comprobanteTMB.getFechaAplic());
        entrada.setDatosBase(datos);
        ComprobanteSalida salidaComp= gen.generaComprobante(entrada);
        log.info("Comprobante Pago TMB :" +salidaComp.getMensaje());
        return salidaComp.getComprobanteBytes();
    }
    /**
     * Genera el reporte con el jar de GeneraComprobantes
     * para homologar la generacion de los comprobantes
     * y concentracion de componentes de genarcacion de
     * pdf en un solo componente centarl
     * para el producto de
     * generaTransferenciasMismaDiv
     * @param comprobanteTMDIV ComprobantesOperacionDTO
     * @return  byte[]
     */
    public static byte[] generaTransferenciasMismaDiv(ComprobantesOperacionResponse comprobanteTMDIV) {

        GeneradorComprobantes gen=new GeneradorComprobantes();
        GeneraComprobanteBean entrada= new GeneraComprobanteBean();

        entrada.setComprobante(Comprobante.TRANS_INT);
        List<String> datos= new ArrayList<String>();
        datos.add("");
        datos.add("");
        datos.add(comprobanteTMDIV.getFechaAplic());
        datos.add(comprobanteTMDIV.getConceptoPago() );
        datos.add(comprobanteTMDIV.getClaveRastreo());
        datos.add(comprobanteTMDIV.getFormaPago());
        datos.add(comprobanteTMDIV.getCuentaCargo());
        datos.add(comprobanteTMDIV.getCanal());
        datos.add(comprobanteTMDIV.getBeneficiario());
        datos.add(comprobanteTMDIV.getBanco());
        datos.add(comprobanteTMDIV.getRefInterbancaria());
        datos.add(comprobanteTMDIV.getTipoDoc());
        datos.add(comprobanteTMDIV.getCveProveedor());
        datos.add(comprobanteTMDIV.getNomProveedor());//CIUDAD DE MEXICO
        datos.add(comprobanteTMDIV.getDivisa());
        datos.add(comprobanteTMDIV.getImporte());//120.01
        datos.add(comprobanteTMDIV.getCveBenef());
        datos.add(comprobanteTMDIV.getEstatus());
        entrada.setDatosBase(datos);
        ComprobanteSalida salidaComp= gen.generaComprobante(entrada);
        log.info("Comprobante Pago TRANS_INT :" +salidaComp.getMensaje());
        return salidaComp.getComprobanteBytes();

    }
    /**
     *
     * Descripcion : Genera el reporte con el jar de GeneraComprobantes
     * para homologar la generacion de los comprobantes
     * y concentracion de componentes de genarcacion de
     * pdf en un solo componente centarl
     * para el producto de
     * de impuestos aduanales
     * @author 1583390
     * @since  28 abr. 2020
     * @param comprobantePagImpAdua
     * @return Devuelve la propiedad del tipo byte[]
     */
    public static byte[] generaPagImpAdua(ComprobantesOperacionResponse comprobantePagImpAdua) {
        GeneradorComprobantes gen=new GeneradorComprobantes();
        GeneraComprobanteBean entrada= new GeneraComprobanteBean();

        entrada.setComprobante(Comprobante.PAG_IMP_ADUA);
        List<String> datos= new ArrayList<String>();
        datos.add("");
        datos.add("");
        datos.add(comprobantePagImpAdua.getPatente());
        datos.add(comprobantePagImpAdua.getPedimento());
        datos.add(comprobantePagImpAdua.getAduana());
        datos.add(comprobantePagImpAdua.getLineaCaptura());
        datos.add(comprobantePagImpAdua.getImporte());
        datos.add(comprobantePagImpAdua.getFechaPago() + " " + comprobantePagImpAdua.getHoraPago());
        datos.add(comprobantePagImpAdua.getNumOpeBan());
        datos.add(comprobantePagImpAdua.getNumTrans());
        datos.add(comprobantePagImpAdua.getMedioPres());
        datos.add(comprobantePagImpAdua.getMedioCob());
        entrada.setDatosBase(datos);
        ComprobanteSalida salidaComp= gen.generaComprobante(entrada);
        log.info("Comprobante Pago de impuestos aduanales :" +salidaComp.getMensaje());
        return salidaComp.getComprobanteBytes();
    }

}
