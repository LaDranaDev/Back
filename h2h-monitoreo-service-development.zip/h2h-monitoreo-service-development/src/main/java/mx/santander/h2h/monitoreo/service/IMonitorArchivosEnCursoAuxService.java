package mx.santander.h2h.monitoreo.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.model.request.MonitorArchivosEnCursoRequest;
import mx.santander.h2h.monitoreo.model.response.MonitorDeArchivosEnCursoDetallesResponse;

/**
 * Servicio para el Tracking de Archivos
 *
 * @author Daniel Ruiz
 * @since 19/04/2023
 */
public interface IMonitorArchivosEnCursoAuxService {

    /**
     * Obtiene detalles de los archivos en curso.
     * @param fecha Date Fecha de búsqueda.
     * @param codCliente String Codio del cliente.
     * @return Bean con los totales de archivos
     */

	Page<MonitorDeArchivosEnCursoDetallesResponse> consultaArchivosEnCurso(MonitorArchivosEnCursoRequest request, Pageable pageable);
	

	

  

}
