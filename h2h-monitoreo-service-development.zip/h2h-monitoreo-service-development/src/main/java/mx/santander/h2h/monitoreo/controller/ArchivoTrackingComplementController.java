package mx.santander.h2h.monitoreo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import mx.santander.h2h.monitoreo.constants.RoutesConstant;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.NivelOperacionHistRequest;
import mx.santander.h2h.monitoreo.model.request.NivelOperacionRequest;
import mx.santander.h2h.monitoreo.model.response.NivelOperacionHistResponse;
import mx.santander.h2h.monitoreo.model.response.NivelOperacionResponse;
import mx.santander.h2h.monitoreo.model.response.OperacionArchivoResponse;
import mx.santander.h2h.monitoreo.service.IConsultaTrackingOperacionHistService;
import mx.santander.h2h.monitoreo.service.IConsultaTrackingOperacionService;

/**
 * Clase controller complemento
 * @author obautist
 *
 */
@Validated
@RestController
@RequestMapping(RoutesConstant.ARCHIVO_TRACKING)
public class ArchivoTrackingComplementController {
	
	/**
	 * Servicio de consulta tracking nivel operacion
	 */
    @Autowired
    private IConsultaTrackingOperacionService consultaTrackingOperacionService;
    
    /**
     * Servicio consulta tracking nivel historial operacion
     */
    @Autowired
    private IConsultaTrackingOperacionHistService consultaTrackingOperacionHistService;
    
    /**
     * Controller para mostrar el nivel operacion
     * @param nivelOperacion NivelOperacionRequest
     * @return ResponseEntity<NivelOperacionResponse>
     */
    @Operation(summary = "Consulta traking nivel operacion")
	@GetMapping(path = "/iniciaNivelOperacion", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<NivelOperacionResponse> iniciaNivelOperacion(
			@Valid
			NivelOperacionRequest nivelOperacion) {
		return ResponseEntity.ok(this.consultaTrackingOperacionService.iniciaNivelOperacion(nivelOperacion));
	}
    
    /**
     * 
     * Metodo controller para mostrar el detalle del archivo
     * @param nivelOperacion NivelOperacionRequest
     * @param page Pageable
     * @return ResponseEntity<Page<OperacionArchivoResponse>>
     */
    @Operation(summary = "Consulta traking nivel detalle archivo nivel operacion")
	@GetMapping(path = "/nivelOperacionDetalle", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Page<OperacionArchivoResponse>> obtenerDetalleArchivosNivelOperacion(
			@Valid
			NivelOperacionRequest nivelOperacion, Pageable page) {
		return ResponseEntity.ok(this.consultaTrackingOperacionService.obtenerDetalleArchivo(nivelOperacion, page));
	}
    
    /**
     * Metodo controller que obtiene el formato xls del detalle del archivo
     * @param nivelOperacion NivelOperacionRequest
     * @param usuario String
     * @return ResponseEntity<ReportResponse>
     */
    @Operation(summary = "Genera reporte en formato xls de detalle nivel operacion.")
   	@GetMapping(path = "/xlsDetalleOperacion", produces = MediaType.APPLICATION_JSON_VALUE)
   	public ResponseEntity<ReportResponse> getReportXlsNivelOperacion(
			@Valid
			NivelOperacionRequest nivelOperacion, String usuario) {
   		return ResponseEntity.ok(this.consultaTrackingOperacionService.getReportXls(nivelOperacion, usuario));
   	}
    
    /**
     * Metodo controller que inciia operacion historica
     * @param nivelOperacion NivelOperacionHistRequest
     * @return ResponseEntity<NivelOperacionHistResponse>
     */
    @Operation(summary = "Consulta traking nivel operacion historica")
	@GetMapping(path = "/iniciaNivelOperacionHist", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<NivelOperacionHistResponse> iniciaNivelOperacionHistorica(
			@Valid
			NivelOperacionHistRequest nivelOperacion) {
		return ResponseEntity.ok(this.consultaTrackingOperacionHistService.iniciaNivelOperacionHist(nivelOperacion));
	}
    
    /**
     * Metodo controller que contiene el detalle archivo nivel operacion historica
     * @param idReg Integer
     * @param page Pageable
     * @return ResponseEntity<Page<OperacionArchivoResponse>> 
     */
    @Operation(summary = "Consulta traking nivel detalle archivo nivel operacion historica")
	@GetMapping(path = "/nivelOperacionDetalleHist", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Page<OperacionArchivoResponse>> obtenerDetalleArchivosNivelOperacionHist(
			Integer idReg, 
			Pageable page) {
		return ResponseEntity.ok(this.consultaTrackingOperacionHistService.obtenerDetalleArchivo(idReg, page));
	}
    
    /**
     * Metodo controller que obtiene el archivo con el detalle de opercion historica
     * @param nivelOperacionHistRequest NivelOperacionHistRequest
     * @param usuario String
     * @return ResponseEntity<ReportResponse>
     */
    @Operation(summary = "Genera reporte en formato xls de detalle nivel operacion historica.")
	@GetMapping(path = "/xlsDetalleOperacionHist", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ReportResponse> getReportXlsDetalleNivelOperacionHist(
			@Valid
			NivelOperacionHistRequest nivelOperacionHistRequest, String usuario) {
		return ResponseEntity.ok(this.consultaTrackingOperacionHistService.getReportXls(nivelOperacionHistRequest, usuario));
	}

}
