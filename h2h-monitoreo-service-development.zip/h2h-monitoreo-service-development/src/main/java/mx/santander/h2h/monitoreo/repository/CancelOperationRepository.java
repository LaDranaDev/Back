package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.constants.QueryConstant;
import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import mx.santander.h2h.monitoreo.util.UtilData;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementacion de la clase repository la cual
 * nos va  a permitir implementar los metodos para
 * la conexión a base de datos ara obtener los
 * catalogos y hace la actualizacion de los
 * registros de las operaciones
 * @author NTTDATA-NRL
 * @version 1.0
 */
@Repository
public class CancelOperationRepository implements ICancelOperationRepository {

    /** Interfaz para impelmentar las conexion a base de datos */
	
    @Autowired
    private EntityManager entityManager;
    
    /**
     * (non-Javadoc)
     * Método de cargador de clases estándar para cargar una clase y resolverla.
     * @see ICancelOperationRepository#obtenerCatalogoEstatus(String)
     */
    @Override
    public List<ComboResponse> obtenerCatalogoEstatus(String tipoStatus) {

        StringBuilder queryBuilder = new StringBuilder();
        queryBuilder.append(QueryConstant.QUERY_COMBO);
        Query query = entityManager.createNativeQuery(queryBuilder.toString());

        @SuppressWarnings("unchecked")
		List<Object[]> resultQueryCatalogos = query.getResultList();

        List<ComboResponse> listCombo = new ArrayList<ComboResponse>();

        if (resultQueryCatalogos != null) {
            for (Object[] map : resultQueryCatalogos) {
                ComboResponse bean = new ComboResponse();
                bean.setId( UtilData.toInt(map[0]) );
                bean.setValor( UtilData.toString(map[1]) );
                listCombo.add(bean);
            }
        }
        return listCombo;
    }

    /**
     * (non-Javadoc)
     * Método de cargador de clases estándar para cargar una clase y resolverla.
     * @see ICancelOperationRepository#updateCancelOperation(String[])
     */
    @Override
    @Transactional
    public int updateCancelOperation(String[] registrosList) {
        int conteoUpdate = 0;

        for(int i=0; i<registrosList.length; i++){
            StringBuilder queryUpd = new StringBuilder();
            queryUpd.append("update H2H_REG_TRAN set ID_MSG = 1954, ID_ESTATUS = 71 where ID_REG = :idRegistro ");
            Query updateRegistrationResponse = entityManager.createNativeQuery(queryUpd.toString());
            updateRegistrationResponse.setParameter("idRegistro", registrosList[i]);

            Integer executeUpdate = updateRegistrationResponse.executeUpdate();
            if(executeUpdate == 1){
                conteoUpdate++;
            }
        }
        return conteoUpdate;
    }

}
