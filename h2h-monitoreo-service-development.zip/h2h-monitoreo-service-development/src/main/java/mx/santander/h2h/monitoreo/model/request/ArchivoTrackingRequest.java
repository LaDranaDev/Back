package mx.santander.h2h.monitoreo.model.request;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * Petition para la information del Archivo y sus productos asociados.
 *
 * @author Daniel Ruiz
 * @since 19/04/2023
 */
@Getter
@Setter
public class ArchivoTrackingRequest implements Serializable {

    /** Serial id */
    private static final long serialVersionUID = 7324417559159313067L;

    /** Fecha de búsqueda (opcional) */
    private LocalDate fecha;

    /** Código del cliente */
    private String codCliente;

    /** Nombre del archivo (opcional) */
    private String nomArch;

    /** Código de estatus (opcional) */
    private Integer codEstatus;

}
