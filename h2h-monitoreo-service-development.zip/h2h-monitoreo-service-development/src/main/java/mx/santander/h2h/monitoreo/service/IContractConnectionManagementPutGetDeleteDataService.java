package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.model.response.PutGetServiceResponse;

public interface IContractConnectionManagementPutGetDeleteDataService {

	void eliminaInformacion(PutGetServiceResponse putGetServiceResponse);

	void eliminaValoresnuevoReg(PutGetServiceResponse putGetServiceResponse);

	void eliminaDatosSiEsAlta(PutGetServiceResponse putGetServiceResponse, String tipoOperPG);

}
