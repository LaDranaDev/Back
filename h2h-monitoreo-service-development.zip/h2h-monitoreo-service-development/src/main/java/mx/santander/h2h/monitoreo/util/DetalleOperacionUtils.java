package mx.santander.h2h.monitoreo.util;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang.StringUtils;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class DetalleOperacionUtils {

    /** Constante DIVISA MXN*/
    public static final String MXN = "MXN";
    /** Constante DIVISA COD_DIVS_SAL*/
    public static final String MN = "MN";
    /** Constante DIVISA MXP*/
    public static final String MXP = "MXP";
    /** Constante Banco. */
    public static final String BANCO = "BANCO SANTANDER (MÉXICO) S.A.";
    /**String ID_MSG*/
    private static final String ID_MSG = "2623";
    /**constante para nombre de empleado*/
    private static final String NOMBRE_EMPLEADO="NOMBRE_EMPLEADO";

    /**
     * Descripcion : Metodo que realiza la recuperacion de la cuenta Cargo
     * @author  [z448853: Orlando Michael Mujica Garcia]
     * @since  18/06/2020
     * @param idproducto atributo que contiene el id del producto
     * @param registro objeto que contiene el registros para recuperar al respuesta
     * @return retorna String con la respuesta de Cuenta Cargo
     */
    public static String cuentaCartgo(String idproducto, Map<String, Object> registro){
        /**Se realiza la genracion de la variable de salida*/
        String cuentaCargo= Objects.toString(registro.get("NUM_CTA_CARGO"), "").trim();
        if("54".equals(idproducto)){
            cuentaCargo= Objects.toString(registro.get("NUM_CTA_CARGO_TARJ"), "").trim();
        }
        /**Se retorna la cuenta cargo*/
        return cuentaCargo;
    }

    /**
     * Descripcion : Metodo que recupera el numero de referencia.
     * @author  [z448853: Orlando Michael Mujica Garcia]
     * @since  18/06/2020
     * @param referencia atributo que almacena la referencia
     * @return retorna String con la respuesta de Referencia
     */
    public static String referencia(String referencia){
        /**Se define variable para almacenar al respuesta*/
        String ref = referencia;
        if ("0".equals(referencia)) {
            ref="";
        }
        /**Se retorna la respuesta*/
        return ref;
    }

    /**
     * Descripcion : Metodo que realiza la definicion del tipo de divisa
     * @author  [z448853: Orlando Michael Mujica Garcia]
     * @since  18/06/2020
     * @param divisa atributo que contiene el tipo de divisa
     * @return retorna String con la divisa.
     */
    public static String tipoDivisa(String divisa){
        /**Se define la variable que almacenara el tipo de divisa*/
        String result=null;
        /**Se realiza la validacion de divisa diferente de null y igual MN o MXN*/
        if(divisa != null && ( MN.equals(divisa.trim()) || MXN.equals(divisa.trim()))){
            result=MXP;
        }else{
            result=divisa;
        }
        /**Se retorna la respuesta con la divisa*/
        return result;
    }

    /**
     * Descripcion : Metodo que define el banco receptor
     * @author  [z448853: Orlando Michael Mujica Garcia]
     * @since  18/06/2020
     * @param idproducto atributo que contiene el id del producto
     * @param registro objeto que contiene el registros para recuperar al respuesta
     * @return
     */
    public static String bancoReceptor(String idproducto, Map<String, Object> registro){
        /**Se define la variable que almacenara el tipo de divisa*/
        String result=defaultObjectString(registro.get("BANCO_RECEPTOR"), "");
        if ("98".equals(idproducto) || "99".equals(idproducto) || "36".equals(idproducto)) {
            result=BANCO;
        }
        /**Se retorna la respuesta de la validacion*/
        return result;
    }

    /**
     * Descripcion : Metodo que recupera el mensaje
     * @author  [z448853: Orlando Michael Mujica Garcia]
     * @since  18/06/2020
     * @param mensaje atributo que contieien el identificador del mensaje
     * @param row objeto que contiene el registros para recuperar al respuesta
     * @return retorna String con el mensaje recuperado de la validacion
     */
    public static String mensaje(String mensaje, Map<String, Object> row){
        /**Se define la variable que almacenara el tipo de divisa*/
        String result=null;
        if(ID_MSG.equals(mensaje)) {
            result= defaultObjectString(row.get("MSG_H2H"), "0") +" - " + defaultObjectString(row.get("MSG_ONL"), "0");
        }else{
            result= defaultObjectString(row.get("MSG_H2H"), "0");
        }
        /**Se retorna la respuesta de la validacion*/
        return result;
    }

    /**
     * Descripcion : Metodo que realiza la asignacion del nombre del empleado
     * @author  [z448853: Orlando Michael Mujica Garcia]
     * @since  18/06/2020
     * @param idProducto atributo que almacena el identificador del producto
     * @param row objeto que contiene la respeusta de la consulta
     * @return retorna String con el nombre del Empleado
     */
    public static String nombreEmpleado(String idProducto, Map<String, Object> row){
        /**Se define la variable que almacenara el tipo de divisa*/
        String result="";
        DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols();
        formatSymbols.setDecimalSeparator('.');
        formatSymbols.setGroupingSeparator(',');
        final DecimalFormat decimalFormat = new DecimalFormat("###,###,###,###,##0.00", formatSymbols);
        if ("91".equals(idProducto)){
            /**Se realiza validacion del nombre de empleado igual a null o vacio*/
            if(row.get(NOMBRE_EMPLEADO) == null || row.get(NOMBRE_EMPLEADO).toString().trim().isEmpty()){
                result="";
            }else{
                result = "$" + decimalFormat.format(Double.valueOf(row.get(NOMBRE_EMPLEADO).toString().trim()));
            }
        }else{
            result= Objects.toString(row.get(NOMBRE_EMPLEADO), "").trim();
        }
        /**Se retorna la respuesta de la validacion*/
        return result;
    }

    /**
     * Descripcion : Metodo que realiza la recuperacion del sucursal tutora
     * @author  [z448853: Orlando Michael Mujica Garcia]
     * @since  18/06/2020
     * @param sucursal atributo que almacena el valor de la sucursal
     * @return retorna String con la sucursal.
     */
    public static String sucursalTutore(String sucursal){
        /**Se define la variable que almacenara el tipo de divisa*/
        String result=sucursal;
        if(StringUtils.isNotEmpty(sucursal) && !"-1".equals(sucursal) && sucursal.length() < 4){
            result = StringUtils.leftPad(sucursal, 4, "0");
        }
        /**Se retorna la respuesta de la validacion*/
        return result;
    }

    /**
     * Descripcion : Metodo que realiza la recuperacion de la descripcion
     * @author  [z448853: Orlando Michael Mujica Garcia]
     * @since  18/06/2020
     * @param idProducto atributo que almacena el identificador del producto
     * @param row objeto que contiene la respeusta de la consulta
     * @return
     */
    public static String descripcion(String idProducto, Map<String, Object> row){
        /**Se define la variable que almacenara el tipo de divisa*/
        String result=null;
        if ("91".equals(idProducto)){
            result= Objects.toString(row.get("DESCRIPCION"), null);
        }else{
            result= defaultObjectString(row.get("DESCRIPCION"), "0");
        }
        /**Se retorna la respuesta de la validacion*/
        return result;
    }

    /**
     * Descripcion : Metodo que recupera la modalidad
     * @author  [z448853: Orlando Michael Mujica Garcia]
     * @since  18/06/2020
     * @param modalidad atributo que almcena el tipo de modalidad en base a la consulta
     * @return retorna String con la modalidad recuperada
     */
    public static String modalidad(String modalidad){
        /**Se define la variable que almacenara el tipo de divisa*/
        String result=modalidad;
        if (!modalidad.isEmpty()) {
            /**Se realiza validacion de la modalidad igual a T*/
            if("T".equals(modalidad)){
                result="Al momento de hacer la orden";
            }else{
                result="Al momento de hacer la liquidaci\u00F3n";
            }
        }
        /**Se retorna la respuesta de la validacion*/
        return result;
    }
    /**
     * Asigna el valor por default indicado al Object
     * en caso de ser null, cadena vacia o la cadena "null".
     * <br>En caso de tener otro valor respeta el valor original, quitando los espacios.
     * @param objeto Object
     * @param valorDefault String
     * @return String
     */
    public static String defaultObjectString(Object objeto, String valorDefault) {
        String temporal = StringUtils.EMPTY;
        if (objeto != null) {
            temporal = objeto.toString();
        }
        if ("null".equals(StringUtils.trimToEmpty(temporal))) {
            temporal = StringUtils.EMPTY;
        }
        return StringUtils.defaultIfEmpty(StringUtils.trimToEmpty(temporal), valorDefault);
    }

    @Getter
    @Setter
    public static class ProductoPIFDTO extends OperationsMonitorQueryResponse implements Serializable {
        /** SID */
        private static final long serialVersionUID = -2985356932102685194L;
        /**Linea de Captura (completa).*/
        private String lineaCaptura;
        /**Folio SUA - Folio de Operacion:*/
        private String folioSua;
        /**Registro Patronal*/
        private String registroPat;
        /**Periodo de Pago*/
        private String periodoPago;
        /**hora*/
        private String hora;
        /**codigo de errore en tablas*/
        private String codError;
        /**Decripcion de errore en tablas*/
        private String descError;
        /**No de Convenio*/
        private String numConvenio;
        /**Nombre Convenio:*/
        private String nombreConvenio;
        /**Llave de Pago */
        private String llavePago;
        /**Plaza (El cual siempre tendra un valor fijo de 180)*/
        private String plaza;
        /**Sucursal (Valor fijo 7701)*/
        private String sucursal;
    }

}
