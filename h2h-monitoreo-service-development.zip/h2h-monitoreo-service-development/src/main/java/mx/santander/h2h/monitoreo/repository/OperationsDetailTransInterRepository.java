package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.util.DetalleOperacionUtils;
import mx.santander.h2h.monitoreo.util.UtilMapeoData;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.HashMap;
import java.util.Map;

@Repository
public class OperationsDetailTransInterRepository implements IOperationsDetailTransInterRepository {

    @Autowired
    private EntityManager entityManager;

    @Override
    public OperationsMonitorQueryResponse obtenerDetalleOperacion(String idOperacion) {
        String stringQuery = generaConsultaDetalleOperacion(idOperacion);
        Query query = entityManager.createNativeQuery(stringQuery, Tuple.class);
//        query.setParameter("idOperacion", idOperacion);

        DetalleOperacionUtils.ProductoPIFDTO respuesta = new DetalleOperacionUtils.ProductoPIFDTO();
        respuesta.setProducto("OPERACION_EN_PROCESO");
        for (Object row : query.getResultList()) {
            if (row instanceof Tuple) {
                obtenDetalleTransInter((Tuple) row, respuesta);
            }
        }

        return respuesta;
    }

    /**
     * Consulta el detalle de Transferencias Internacionales
     * @param respuestaProdDomis DTO de respuesta
     * @param row Fila
     */
    private void obtenDetalleTransInter(Tuple tuple, DetalleOperacionUtils.ProductoPIFDTO respuestaProdDomis) {
        DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols();
        formatSymbols.setDecimalSeparator('.');
        formatSymbols.setGroupingSeparator(',');
        final DecimalFormat decimalFormat = new DecimalFormat("###,###,###,###,##0.00", formatSymbols);

        Map<String, Object> row = new HashMap<>();
        tuple.getElements().forEach(t -> row.put(t.getAlias(), tuple.get(t)));

        respuestaProdDomis.setProducto(DetalleOperacionUtils.defaultObjectString(row.get("DESC_PROD"), ""));
        respuestaProdDomis.setCodCli(DetalleOperacionUtils.defaultObjectString(row.get("BUC"), ""));
        respuestaProdDomis.setFechaAplic(DetalleOperacionUtils.defaultObjectString(row.get("FCH_APLI"), ""));
        respuestaProdDomis.setReferencia(DetalleOperacionUtils.defaultObjectString(row.get("TXT_REF"), ""));
        respuestaProdDomis.setEstatus(DetalleOperacionUtils.defaultObjectString(row.get("DESC_ESTATUS"), ""));
        respuestaProdDomis.setIdEstatus(DetalleOperacionUtils.defaultObjectString(row.get("ID_ESTATUS"), ""));
        respuestaProdDomis.setFechaCaptura(DetalleOperacionUtils.defaultObjectString(row.get("FCH_REG"), ""));

        respuestaProdDomis.setBancoOrdenante("BANCO SANTANDER (MÉXICO) S.A.");
        respuestaProdDomis.setNombreOrd(DetalleOperacionUtils.defaultObjectString(row.get("TXT_NOM_ORD"), ""));
        respuestaProdDomis.setCtaCargo(DetalleOperacionUtils.defaultObjectString(row.get("NUM_CTA_ORD"), ""));
        respuestaProdDomis.setDivisaOrd(DetalleOperacionUtils.defaultObjectString(row.get("COD_DIV_CTA_ORD"), ""));
        respuestaProdDomis.setImporteCargo(row.get("IMP_CARGO_ORD") == null || row.get("IMP_CARGO_ORD").toString().trim().isEmpty()
                ? "$0.00" : "$" + decimalFormat.format(Double.valueOf(row.get("IMP_CARGO_ORD").toString().trim())));


        respuestaProdDomis.setBancoReceptor(DetalleOperacionUtils.defaultObjectString(row.get("TXT_NOM_BCO_PAG"), ""));
        respuestaProdDomis.setNombreBenef(DetalleOperacionUtils.defaultObjectString(row.get("TXT_NOM_BENE"), ""));
        respuestaProdDomis.setCtaAbono(DetalleOperacionUtils.defaultObjectString(row.get("NUM_CTA_BENE"), ""));
        
        // Obtenemos el enmascarado de datos
        respuestaProdDomis.setCtaAbono(UtilMapeoData.getMascara(respuestaProdDomis.getCtaAbono(), "abono"));
        
        respuestaProdDomis.setDivisa(DetalleOperacionUtils.defaultObjectString(row.get("COD_DIV_CTA_BENE"), ""));
        respuestaProdDomis.setImporte(row.get("IMP_ABONO_BENE") == null || row.get("IMP_ABONO_BENE").toString().trim().isEmpty()
                ? "$0.00" : "$" + decimalFormat.format(Double.valueOf(row.get("IMP_ABONO_BENE").toString().trim())));

        respuestaProdDomis.setIdProducto(DetalleOperacionUtils.defaultObjectString(row.get("CVE_PROD_OPER"), ""));
        respuestaProdDomis.setNomArch(DetalleOperacionUtils.defaultObjectString(row.get("NOMBRE_ARCH"), ""));
        respuestaProdDomis.setMensajeOrden(DetalleOperacionUtils.defaultObjectString(row.get("MSG_H2H"), ""));
    }

    /**
     * Genera la consulta del detalle de la operacion
     *
     * @return Consulta de detalle de operacion
     */
    private String generaConsultaDetalleOperacion(String idOperacion) {
    	final StringBuilder query = new StringBuilder();
    	query.append("SELECT PROD.* FROM ( ")
    			.append(getConsultaByProducto(true))
    			.append(" UNION ALL ")
    			.append(getConsultaByProducto(false))
    			.append(") PROD WHERE PROD.ID_REG = ")
    			.append(idOperacion);
        return  query.toString();
    }

    /**
     * Crea el query por producto y si el del dia de hoy o el de tres meses
     * @param tresMeses boleano indicador de tres meses
     * @return SQL del producto
     */
    private String getConsultaByProducto(boolean tresMeses) {
    	final StringBuilder query = new StringBuilder();
    	query
    		.append("SELECT ")
    		.append(" REG.DIVI DIVISA,REG.CNTA_CARG NUM_CTA_CARGO, REG.CNTA_ABON NUN_CTA_ABONO, ")
    		.append("ARCH.NOMBRE_ARCH, REG.ID_ESTATUS, EST.DESC_ESTATUS, REG.MONT IMPORTE, ")
    		.append(" to_char(DETA.FCH_APLI,'dd/mm/yyyy') FCH_APLI , CLTE.BUC,")
    		.append(" to_char(DETA.FCH_REG,'dd/mm/yyyy') FCH_REG, DETA.TXT_NOM_ORD, ")
    		.append("DETA.ID_REG,DETA.COD_DIV_CTA_ORD ,CNTA_CARG.NOMB_TITU NOMB_CLTE, ")
    		.append("DETA.NUM_CTA_ORD,DETA.IMP_CARGO_ORD ,REG.CVE_PROD_OPER,DETA.COD_PROD,PROD.DESC_PROD, ")
    		.append("DETA.TXT_REF,DETA.TXT_NOM_BCO_PAG, DETA.TXT_NOM_BENE,DETA.NUM_CTA_BENE,DETA.COD_DIV_CTA_BENE,DETA.IMP_ABONO_BENE  ")
    		.append(", MSG.MSG_H2H ")
    		.append("FROM  H2H_MX_PROD_TRAN_INTN")
    		.append(tresMeses ? "_TRAN DETA " : " DETA ")
    		.append("INNER JOIN " + (tresMeses ? "H2H_REG_TRAN" : "H2H_REG") + " REG ON REG.ID_REG=DETA.ID_REG ")
    		.append("INNER JOIN " + (tresMeses ? "H2H_ARCHIVO_TRAN" : "H2H_ARCHIVO") + " ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ")
    		.append("INNER JOIN H2H_CAT_PROD PROD ON PROD.CVE_PROD_OPER=REG.CVE_PROD_OPER ")
    		.append("INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS ")
    		.append("INNER JOIN H2H_CNTR CNTR USING (ID_CNTR) ")
    		.append("INNER JOIN H2H_CLTE CLTE USING (ID_CLTE) ")
    		.append("INNER JOIN H2H_MSG MSG ON MSG.ID_MSG = REG.ID_MSG ")
    		.append("LEFT JOIN H2H_CTA_INFO CNTA_CARG ON REG.CNTA_CARG = CNTA_CARG.NUME_CTA AND CNTA_CARG.TIPO_CTA = 'O' ");
    	
        return query.toString();
    }

}
