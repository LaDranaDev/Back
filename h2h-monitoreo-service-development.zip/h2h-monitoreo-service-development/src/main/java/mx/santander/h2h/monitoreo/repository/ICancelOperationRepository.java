package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import java.util.List;

/**
 * Interfas que contiene los metodos
 * necesarios para el repositorio de
 * cancelacion de operacion
 * @author NTTDATA-NRL
 * @version 1.0
 */
public interface ICancelOperationRepository {
    /**
     * Metodo para ibtener los catalagos con estatus
     * @param tipoStatus tipo ed estatus
     * @return List<ComboResponse>
     */
    List<ComboResponse> obtenerCatalogoEstatus(String tipoStatus);

    /**
     * Metodo para actualizar el estatus
     * de las operaciones y hacer una baja logica
     * @param registros registro a actualizar
     * @return int 0 o 1
     */
    int updateCancelOperation(String[]  registros);
}
