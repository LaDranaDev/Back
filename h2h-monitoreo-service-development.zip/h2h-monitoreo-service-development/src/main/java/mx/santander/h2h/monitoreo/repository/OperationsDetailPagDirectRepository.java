package mx.santander.h2h.monitoreo.repository;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.constants.MonitorOperacionesConstants;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.util.DetalleOperacionUtils;
import mx.santander.h2h.monitoreo.util.UtilsTramaAdicionales;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * OperationsPagDirectRepository.
 *
 * @author Jesus Soto Aguilar
 */
@Slf4j
@Repository
public class OperationsDetailPagDirectRepository implements IOperationsDetailPagDirectRepository {

    @Autowired
    private EntityManager entityManager;
    
    protected static final Map<String, String> tablas = new HashMap<>();

    /*
     * TCS (sonar)
     * Cambio de clase anonima por inicializacion en bloque estatico
     */
    static {
        tablas.put("01",MonitorOperacionesConstants.H2H_PROD_TRAN); /**SPEI*/
        tablas.put("97",MonitorOperacionesConstants.H2H_PROD_TRAN); /**TEF*/
        tablas.put("02",MonitorOperacionesConstants.H2H_PROD_TRAN); /**Nomina Interbancaria*/
        tablas.put("98","H2H_PROD_TRAN_MISM_BANC"); /**TMB*/
        tablas.put("99","H2H_PROD_NOMI_MISM_BANC"); /**Nomina Mismo Banco*/
        tablas.put("91","H2H_PROD_ALTA_PAGO"); /**ALTA PAGO PROVEEDORES CONFIRMING*/
        tablas.put("80","H2H_PROD_ORDN_PAGO"); /**ORDEN DE PAGO	*/
        tablas.put("95","H2H_ACTA_BENI"); /**Alta Cuenta Beneficiarias*/
        tablas.put("96","H2H_ACTA_BENI"); /**Alta Cuenta Beneficiarias*/
        tablas.put("81","H2H_PROD_ORDN_PAGO"); /**ORDEN DE PAGO CANCELADO*/
        tablas.put("93","H2H_PROD_ALTA_EMPL"); /**ALTA MASIVA EMPLEADOS*/
        tablas.put("135","H2H_PROD_MANTTO_PROV_TRAN"); /**MTTO PROVEEDORES DE CONFIRMING**/
        tablas.put("23","H2H_PROD_APO_OBRE_PATR");
        tablas.put("21","H2H_PROD_IMPU_FEDE");
        tablas.put("22","H2H_PROD_PAGO_REFE");
        tablas.put("36","H2H_MX_PROD_PAGO_TDC"); /**Pago a TDC Santander*/
        tablas.put("54","H2H_MX_PROD_CARD_CHECK");
        tablas.put("40","H2H_MX_PROD_PAGO_DIR"); //PGODIRECT
        tablas.put("32", "H2H_MX_PROD_TRAN_INTN");//Transferencias internacionales Cambiarias
        tablas.put("38", "H2H_MX_PROD_TVIB");//Transferencias Vostro Interbancarias
        tablas.put("39", "H2H_MX_PROD_TVMB");//Transferencias Vostro Mismo Banco
        tablas.put("85", "H2H_MX_PROD_ORDN_PAGO_ATM");//Ordenes de pago ATM
        tablas.put("41",MonitorOperacionesConstants.H2H_PROD_TRAN); /**SPEI ONLINE*/
        tablas.put("47",MonitorOperacionesConstants.H2H_PROD_TRAN); /**TEF ONLINE*/
        tablas.put("42",MonitorOperacionesConstants.H2H_PROD_TRAN); /**Nomina Interbancaria ONLINE*/
        tablas.put("48","H2H_PROD_TRAN_MISM_BANC"); /**TMB ONLINE*/
        tablas.put("49","H2H_PROD_NOMI_MISM_BANC"); /**Nomina Mismo Banco ONLINE*/
    }

    @Override
    public OperationsMonitorQueryResponse obtenerDetalleOperacion(String view, String idOperacion) {
        String stringQuery = generaConsultaDetalleOperacion(view, idOperacion);
        Query query = entityManager.createNativeQuery(stringQuery, Tuple.class);
//        query.setParameter("idOperacion", idOperacion);

        OperationsMonitorQueryResponse respuesta = new OperationsMonitorQueryResponse();

        if (!tablas.containsKey(view)){
            respuesta.setMensaje(getH2HMensaje(idOperacion));
            return respuesta;
        }

        for (Object obj : query.getResultList()) {
            if (obj instanceof Tuple) {
                Tuple tuple = (Tuple) obj;
                Map<String, Object> row = new HashMap<>();
                tuple.getElements().forEach(t -> row.put(t.getAlias(), tuple.get(t)));
                rellenaRespuestaMonitorOperacionesDTO(row, respuesta);
            }
        }

        return respuesta;
    }
    private void rellenaRespuestaMonitorOperacionesDTO(Map<String, Object> row, OperationsMonitorQueryResponse respuesta) {
        DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols();
        final DecimalFormat decimalFormat = new DecimalFormat("###,###,###,###,##0.00", formatSymbols);
        respuesta.setIdOperacion(DetalleOperacionUtils.defaultObjectString(row.get("ID_REG"), "0"));
        respuesta.setCodCli(Objects.toString(row.get("BUC"), "").trim());
        respuesta.setCtaCargo(Objects.toString(row.get("NUM_CTA_CARGO"), "").trim());
        respuesta.setIdProducto(DetalleOperacionUtils.defaultObjectString(row.get("CVE_PROD_OPER"), "0"));
        respuesta.setProducto(Objects.toString(row.get("DESC_PROD"), "").trim());
        respuesta.setReferencia(DetalleOperacionUtils.defaultObjectString(row.get("REFERENCIA"), ""));
        if ("0".equals(respuesta.getReferencia())) {
            respuesta.setReferencia("");
        }
        respuesta.setEstatus(Objects.toString(row.get("DESC_ESTATUS"), "").trim());
        respuesta.setImporte(row.get(MonitorOperacionesConstants.IMPORTE) == null || Objects.toString(row.get(MonitorOperacionesConstants.IMPORTE), "").trim().isEmpty()
                ? "$0.00" : "$" + decimalFormat.format(Double.valueOf(row.get(MonitorOperacionesConstants.IMPORTE).toString().trim())));
        respuesta.setFechaAplic(UtilsTramaAdicionales.getFecha(row.get("FECHA_APLICACION")));
        respuesta.setFechaCaptura(UtilsTramaAdicionales.getFecha(row.get("FECHA_PRESENTACION")));
        respuesta.setFechaLimitPago(UtilsTramaAdicionales.getFecha(row.get("FECHA_LIMITE_PAGO")));
        respuesta.setFechaOper(UtilsTramaAdicionales.getFecha(row.get("FECHA_OPERACION")) );
        respuesta.setNombreBenef(Objects.toString(row.get("BENEFICIARIO"), "").trim());
        respuesta.setNumSucursal(Objects.toString(row.get("NUM_SUCURSAL"), "").trim());
        respuesta.setNumOrden(Objects.toString(row.get("NO_ORDEN"), "").trim());
        respuesta.setBancoReceptor(DetalleOperacionUtils.defaultObjectString(row.get("BANCO_RECEPTOR"), ""));
        respuesta.setMensaje(Objects.toString(row.get("MSG_H2H"), "").trim());
        respuesta.setIdEstatus(DetalleOperacionUtils.defaultObjectString(row.get("ID_ESTATUS"), "0"));
        respuesta.setMensajeOrden(DetalleOperacionUtils.defaultObjectString(row.get("COMENTARIOS"), "0"));
        respuesta.setReferenciaAbono(Objects.toString(row.get("REFERENCIA_ABONO"), "").trim());
        respuesta.setTipoPago(traduceTipoPago(Objects.toString(row.get("TIPO_PAGO"), "").trim()));
    }
    
    /**
	 * Traduce tipo pago.
	 * <br> E: efectivo <br> C: cheque
	 * @param objeto Object
	 * @return String
	 */
    private String traduceTipoPago(Object objeto) {
		String temporal = defaultObjectString(objeto, "");
		if ("E".equals(temporal)) {
			return "E-EFECTIVO";
		}
		if ("C".equals(temporal)) {
			return "C-CHEQUE";
		}
		return "OTRO";
	}
    
    /**
	 * Asigna el valor por default indicado al Object
	 * en caso de ser null, cadena vacia o la cadena "null".
	 * <br>En caso de tener otro valor respeta el valor original, quitando los espacios.
	 * @param objeto Object
	 * @param valorDefault String
	 * @return String
	 */
    private String defaultObjectString(Object objeto, String valorDefault) {
		String temporal = StringUtils.EMPTY;
		if (objeto != null) {
			temporal = objeto.toString();
		}
		if ("null".equals(StringUtils.trimToEmpty(temporal))) {
			temporal = StringUtils.EMPTY;
		}
		return StringUtils.defaultIfEmpty(StringUtils.trimToEmpty(temporal), valorDefault);
	}

    private String generaConsultaDetalleOperacion(String view, String idOperacion) {
        log.debug("Preparando consulta de operaciones");
        final StringBuilder query = new StringBuilder();
        query
                .append("SELECT PROD.* FROM ( ")
                .append(getConsultaByProducto(view, true))
                .append(" UNION ALL ")
                .append(getConsultaByProducto(view, false))
                .append(") PROD WHERE PROD.ID_REG = ")
                .append(idOperacion);

        return query.toString();
    }

    /**
     * Crea el query por producto y si el dlel dia de hoy o el de tres meses.
     * <br> Producto Pago Directo
     *
     * @param cveOperProd
     *            - clave del producto
     * @param tresMeses
     *            - inidca si va suar la tablasd e tres meses atras
     * @return String
     *            SQL del producto
     */
    private  String getConsultaByProducto(String cveOperProd, boolean  tresMeses) {
        final StringBuilder query = new StringBuilder();
        query.append("SELECT ")
		        .append("ID_REG, CLTE.BUC, REG.CNTA_CARG NUM_CTA_CARGO, ")
				.append("DETA.NUM_CTA NUN_CTA_ABONO, REG.CVE_PROD_OPER, PROD.DESC_PROD, ")
				.append("ARCH.NOMBRE_ARCH, REG.REFE_BE REFERENCIA, REG.ID_ESTATUS, EST.DESC_ESTATUS,coalesce(DETA.DESC_ESTA, MSG.MSG_H2H) COMENTARIOS,DETA.FECH_LIBE FECHA_APLICACION,REG.FECH_REG FECHA_PRESENTACION,")
				.append("REG.MONT IMPORTE, CNTR.NUM_CNTR, REG.DIVI DIVISA, ")
				.append("DETA.FECH_OPER FECHA_REGISTRO, PROD.VIST_PROD, ")
				.append("NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD, NULL INTERMEDIARIO_REC, ")
				.append("DETA.NOM_BENE BENEFICIARIO, ")
				.append("NULL COMENTARIO_1, NULL COMENTARIO_2, ")
				.append("NULL COMENTARIO_3, NULL TITULAR, NULL BANCO_RECEPTOR, ")
				.append("DETA.FORM_PAG TIPO_PAGO, NULL MODALIDAD, DETA.IMP_PAGO IMPORTE_CARGO, ")
				.append("DETA.CONS_PAGO MSG_H2H, NULL MSG_ORDEN_PAGO, DETA.NO_ORDEN, ")
				.append("DETA.FECHA_LIM FECHA_LIMITE_PAGO, DETA.CLV_SUC NUM_SUCURSAL, NULL FECH_VENC,")
				.append("DETA.REF_CAPT REFERENCIA_ABONO, NULL REFERENCIA_CARGO, ")
                .append("NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, ")
                .append("NULL BUC_EMPLEADO, ")
                .append("NULL SUCURSAL_TUTORA, NULL RFC, ")
                .append("NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, ")
                .append("NULL DESCRIPCION, ")
                .append("REG.FECH_OPER FECHA_PRESENTACION_INICIAL, REG.FECH_ENVI_BACK FECHA_OPERACION, REG.NUME_MOVI ")
                .append("FROM ")
                .append(tablas.get(cveOperProd));
        if (tresMeses) {
            query.append("_TRAN DETA INNER JOIN H2H_REG_TRAN REG USING(ID_REG) ")
                    .append("INNER JOIN H2H_ARCHIVO_TRAN ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ");
        } else {
            query.append(" DETA INNER JOIN H2H_REG REG USING(ID_REG) ")
                    .append("INNER JOIN H2H_ARCHIVO ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ");
        }
	        query.append("INNER JOIN H2H_CNTR CNTR USING (ID_CNTR) ")
				.append("INNER JOIN H2H_CLTE CLTE USING (ID_CLTE) ")
				.append("INNER JOIN H2H_CAT_PROD PROD ON PROD.CVE_PROD_OPER=REG.CVE_PROD_OPER ")
				.append("INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS ")
				.append("LEFT JOIN H2H_MSG MSG ON MSG.ID_MSG = REG.ID_MSG ");
        return query.toString();
    }

    private String getH2HMensaje(String idOperacion) {
    	final StringBuilder query = new StringBuilder();
    	query.append("SELECT MSG_H2H FROM H2H_MSG INNER JOIN H2H_REG USING(ID_MSG) WHERE ID_REG = ")
    			.append(idOperacion)
    			.append(" UNION ALL ")
    			.append("SELECT MSG_H2H FROM H2H_MSG INNER JOIN H2H_REG_TRAN USING(ID_MSG) WHERE ID_REG = ")
    			.append(idOperacion);

        Query nativeQuery = entityManager.createNativeQuery(query.toString(), Tuple.class);
//        nativeQuery.setParameter("idOperacion", idOperacion);

        for (Object obj : nativeQuery.getResultList()) {
            if (obj instanceof Tuple) {
                Tuple tuple = (Tuple) obj;
                return Objects.toString(tuple.get("MSG_H2H"), "");
            }
        }

        return null;
    }

}
