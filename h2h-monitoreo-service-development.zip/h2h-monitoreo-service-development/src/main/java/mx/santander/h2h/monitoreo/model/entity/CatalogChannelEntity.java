package mx.santander.h2h.monitoreo.model.entity;

import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;

/**
 * Entidad para el catalogo de canales.
 *
 * @author Felipe Monzon
 * @since 11/05/2022
 */
@Entity
@Getter
@Setter
@Table(name = "H2H_CAT_CANL")
public class CatalogChannelEntity implements Serializable {
	/**
	 * serial.
	 */
	private static final long serialVersionUID = -3167785274885816146L;
	/**
	 * Identificador del canal.
	 */
	@Id
	@Column(name = "ID_CANL")
	private Integer idChannel;
	/**
	 * Nombre del canal.
	 */
	@Column(name = "NOMB_CANL")
	private String name;
	/**
	 * Descripcion del canal.
	 */
	@Column(name = "DESC_CANL")
	private String description;
	/**
	 * status del canal.
	 */
	@Column(name = "BAND_ACTI")
	private String status;
	/**
	 * identificador del centro.
	 */
	@Column(name = "id_cntr")
	private transient Integer idCenter;
	/**
	 * estado de la seleccion.
	 */
	@Column(name = "ESTADO_SELECCION")
	private transient String statusSelected;
}
