package mx.santander.h2h.monitoreo.util;

import java.util.List;

import jakarta.persistence.Tuple;

import org.apache.commons.lang.ObjectUtils;

import mx.santander.h2h.monitoreo.model.response.ComprobantesOperacionResponse;

/**
 * @author  FSW TCS
 * Utileria para datos de comprobante Pago Directo.
 */
public final class UtilComprobantePD {

    /** Constructor privado de la clase utileria **/
    private UtilComprobantePD() {
    }

    /**
     * Obtiene el query del comprobante Pago Directo.
     *
     * @param listIds
     *            List<Integer>
     * @return String
     *            Query Producido
     */
    protected static String obtenerQuery(List<Integer> listIds) {
        final StringBuilder sql = new StringBuilder(queryBaseProd(listIds, false));
        sql.append(" UNION ALL ").append(queryBaseProd(listIds, true));
        return sql.toString();
    }

    /**
     * Agrega la restriccion de los Id Reg indicados.
     *
     * @param listaIdRg
     *            List<Integer>
     * @return String
     *            Query producido
     */
    private static String addIdReg(List<Integer> listaIdRg) {
        StringBuilder sqlIdRegs = new StringBuilder();
        boolean primero = true;
        if (listaIdRg != null && !listaIdRg.isEmpty()) {
            // Itera en la lista y agrega los operandos
            for (Integer idReg : listaIdRg) {
                if (primero) {
                    sqlIdRegs.append(" AND ( pdtrn.id_reg = ").append(idReg);
                } else {
                    sqlIdRegs.append(" OR pdtrn.id_reg = ").append(idReg);
                }
                primero = false;
            }
            sqlIdRegs.append(" ) ");
        }
        return sqlIdRegs.toString();
    }

    /**
     * Arma el query base del producto para el comprobante.
     *
     * @param listIds
     *            List<Integer>
     * @param esTran
     *            Indicador para tomar la tabla del diario o la de tres meses.
     * @return String
     *            Query producido.
     */
    private static String queryBaseProd(List<Integer> listIds, boolean esTran) {
        String tran = "";
        if (esTran) {
            tran = "_TRAN";
        }
        // arma el query
        StringBuilder sql = new StringBuilder()
                .append("SELECT pdtrn.ID_REG, null CONTRATO, to_char(pdtrn.NUM_CTA) NUM_CTA_CARGO,null NUN_CTA_ABONO,")
                .append("ct.DESC_PROD, TO_NUMBER(pdtrn.IMP_PAGO) IMPORTE,pdtrn.REF_CAPT REFERENCIA,null DIVISA, est.DESC_ESTATUS,")
                .append("null FECH_APLI, pdtrn.NOM_BENE BENEFICIARIO,pdtrn.FORM_PAG TIPO_PAGO,DECODE(info.NOMB_TITU,null,' ',info.NOMB_TITU) TITULAR,")
                .append("pdtrn.CONS_PAGO CONCEPTO_PAGO,null CLAVE_RASTREO,null BANCO_RECEPTOR,pdtrn.FECH_LIBE FECHA_OPERACION,")
                .append("null CLAV_PROV, null NUM_DOCU,to_char(abt.FECH_RESP_BE,'dd/mm/yyyy hh24:mi:ss') FECH_VENCIMIENTO,null CVE_FORM_PAGO,trim(ct.CVE_PROD_OPER) ESTATUS_MOV, ")
                .append("pdtrn.NO_ORDEN NUM_ORDEN,to_char(pdtrn.FECHA_LIM,'dd/mm/yyyy') FECHA_LIMITE_PAGO,rpdt.SUCURSAL NUM_SUCURSAL, NULL  RAZON_SCIA,")
                .append("null NOM_CLTE, null PERSONALIDAD, null RFC, null NUM_CNTR,")
                .append("pdtrn.CLV_BENE CLAVE_BENEF,null ID_ESTA,null PERS_AUT,'' FORM_APLI, '' NOMB_RAZON_SOCI_PROV,'' RFC_PROV,")
                .append("null BANC_ABON,null REFE_ABON,null TIPO_DOCU")
                .append(" FROM H2H_MX_PROD_PAGO_DIR")
                .append(tran)
                .append(" pdtrn ")
                .append(esTran ? " INNER JOIN H2H_REG_TRAN r ON r.id_reg = pdtrn.id_reg " : " INNER JOIN H2H_REG r ON r.id_reg = pdtrn.id_reg ")
                .append(" INNER JOIN H2H_CAT_PROD ct ON r.cve_prod_oper = ct.cve_prod_oper")
                .append(" LEFT JOIN H2H_MX_REP_PAGO_DIR")
                .append(tran)
                .append(" rpdt ON pdtrn.ID_REG = rpdt.ID_REG")
                .append(" LEFT JOIN H2H_CTA_INFO info ON pdtrn.NUM_CTA = info.NUME_CTA")
                .append(" LEFT JOIN H2H_ARCH_BACK")
                .append(tran)
                .append(" abt ON r.id_arch_be = abt.id_arch_back")
                .append(" LEFT JOIN H2H_CAT_ESTATUS est ON  r.ID_ESTATUS = est.ID_CAT_ESTATUS")
                .append(" WHERE rpdt.COD_ESTATUS = 'L' AND info.tipo_cta = 'O' ")
                .append(addIdReg(listIds));
        return sql.toString();
    }
    
    /***
	 * metodo para obtener los datos para el comprobante
	 * 
	 * @param bean
	 *            bean a llenar
	 * @param map
	 *            mapa con datos
	 */
	public static void llenaBeanPagoDirecto(ComprobantesOperacionResponse bean, Tuple map) {
		// setea los atributos del bean
		bean.setCuentaCargo(ObjectUtils.toString(map.get("NUM_CTA_CARGO")));
		bean.setTitular(ObjectUtils.toString(map.get("TITULAR")));
		bean.setCveBenef(ObjectUtils.toString(map.get("CLAVE_BENEF")));
		bean.setBeneficiario(ObjectUtils.toString(map.get("BENEFICIARIO")));
		bean.setImporte("$" + UtilFormatDatos.traduceImporte(map.get("IMPORTE")));
		bean.setConceptoPago(ObjectUtils.toString(map.get("CONCEPTO_PAGO")));
		bean.setNumOrden(ObjectUtils.toString(map.get("NUM_ORDEN")));
		bean.setFolioOp(UtilFormatDatos.convierteLong(map.get("ID_REG")));
		bean.setTipoOper(ObjectUtils.toString(map.get("DESC_PROD")));
		bean.setFormaPago(UtilFormatDatos.traduceTipoPagoPD(map.get("TIPO_PAGO")));
		bean.setSucursal(ObjectUtils.toString(map.get("NUM_SUCURSAL")));
		bean.setEstatus(ObjectUtils.toString(map.get("DESC_ESTATUS")));
		bean.setFechaOp(ObjectUtils.toString(map.get("FECH_VENCIMIENTO")));
		bean.setFechaLimPago(ObjectUtils.toString(map.get("FECHA_LIMITE_PAGO")));
		bean.setClaveRastreo(ObjectUtils.toString(map.get("REFERENCIA")));
		bean.setEstatusMov(ObjectUtils.toString(map.get("ESTATUS_MOV")));	
	}

}
