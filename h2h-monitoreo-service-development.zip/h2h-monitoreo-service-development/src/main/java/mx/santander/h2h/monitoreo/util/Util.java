package mx.santander.h2h.monitoreo.util;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.commons.utils.ConsultaTrackingUtil;
import mx.santander.h2h.monitoreo.model.entity.CatalogChannelEntity;
import mx.santander.h2h.monitoreo.model.response.CatalogChannelResponse;
import mx.santander.h2h.monitoreo.model.response.MonitorDeArchivosEnCursoDetallesResponse;

import org.apache.commons.lang.StringUtils;
import org.modelmapper.ModelMapper;
import org.owasp.encoder.Encode;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import jakarta.persistence.Tuple;

/**
 * Clase de utilerias..
 *
 * @author Felipe Monzon
 * @since 25/05/2022
 */
@Slf4j
public final class Util {
	
	/**
	 * Constructor privado.
	 */
	private Util() {
	}

	/**
	 * Filtra la lista de catalogos.
	 * 
	 * @param parameter lista en formato cadena separada por pipes
	 * @param list      lista a filtrar
	 * @return lista filtrada con los nuevos datos
	 */
	public static List<CatalogChannelResponse> filterList(String parameter, List<CatalogChannelEntity> list) {
		log.info("Empezo filterList -> Util");
		log.info("Filtra la lista de parametros optimus por canales {}", Encode.forJava(parameter));
		List<CatalogChannelEntity> channel = new ArrayList<>();
		if (!StringUtils.isEmpty(parameter)) {
			List<String> values = Arrays.asList(parameter.split("\\|"));
			channel = list.stream().filter(ca -> !values.contains(String.valueOf(ca.getIdChannel())))
					.collect(Collectors.toList());
		}
		log.info("Termino filterList -> Util");
		return channel.stream().map(Util::mapping).collect(Collectors.toList());
	}

	/**
	 * Convierte un entity de tipo {@link CatalogChannelEntity} a un objeto
	 * {@link CatalogChannelResponse}
	 *
	 * @param entity entidad de catalogo de canales
	 * @return {@link CatalogChannelResponse} respuesta de canales
	 */
	private static CatalogChannelResponse mapping(CatalogChannelEntity entity) {
		return new ModelMapper().map(entity, CatalogChannelResponse.class);
	}

	/**
	 * Metodo para obtener la fecha actual
	 * 
	 * @return Date la fecha actual
	 */
	public static Date getCurrentDate() {
		return new Date();
	}

	/**
	 * Valida si el check esta vacio o nulo.
	 * 
	 * @param value valor del check
	 * @return valor a guardar del check
	 */
	public static String validateCheck(String value) {
		if (StringUtils.isEmpty(value)) {
			value = "I";
		}

		return value;
	}
	
	/**
	 * Descripcion: Metodo que realiza la validacion de los nombres de los archivos validados,
	 * para agrupar los productos por nombre de archivo.
	 * @param datos recuperados de la base de datos
	 * @param mapa que contiene los datos con el formato para presentarlos en pantalla
	 * @param bean con los datos de respuesta de la peticion
	 * @param idArchivoActual valor del archivo en validacion dentro del for
	 * @param idArchivoAnterior valor del archivo validado anteriormente dentro del for
	 * @param listBean lista de los archivos
	 * @param numOp numero de operaciones por archivo
	 * @param monto monto total de operaciones por archivo
	 * @return BeanArchivosEnCurso valores actualizados del 
	 * numero de operaciones y el monto por archivo.
	 */
	public static MonitorDeArchivosEnCursoDetallesResponse validaDuplicidadNombreArchivo(List<?> datos, Tuple mapa, 
			MonitorDeArchivosEnCursoDetallesResponse bean, Integer idArchivoActual, Integer idArchivoAnterior, 
			List<MonitorDeArchivosEnCursoDetallesResponse> listBean, Integer numOp, BigDecimal monto) {
		MonitorDeArchivosEnCursoDetallesResponse beanMontoOpe = new MonitorDeArchivosEnCursoDetallesResponse();
		if(datos.indexOf(mapa)==0) {
        	numOp = bean.getTotalOper();
			monto = bean.getTotalMont();
        }else {
        /**Se valida si el nombre del archivo ya 
		fue escrito en la tabla para enviar en 
		vacio los parametros de nombre, fecha, 
		estatus, canal y cliente*/
			if(idArchivoActual!= 0 && idArchivoActual.equals(idArchivoAnterior)){
				monto = monto.add(bean.getTotalMont());
				numOp += bean.getTotalOper();
				bean.setCliente(StringUtils.EMPTY);
				bean.setNombreArch(StringUtils.EMPTY);
				bean.setFechaRegistro(StringUtils.EMPTY);
				bean.setDescEstatus(StringUtils.EMPTY);
				bean.setNombCanl(StringUtils.EMPTY);
				
			}else {
				
				MonitorDeArchivosEnCursoDetallesResponse subTotal = new MonitorDeArchivosEnCursoDetallesResponse();
				subTotal.setDescProd("TOTAL");
				subTotal.setTotalOper(numOp);
				subTotal.setTotalMont(monto);
				subTotal.setTotalMontFormat(ConsultaTrackingUtil.formateaImporteArchivo(monto));
				
				listBean.add(subTotal);
				numOp = bean.getTotalOper();
				monto = bean.getTotalMont();
			}
        }
		/**Se actualiza el valor
		 * del numero de operaciones y el monto*/
		beanMontoOpe.setTotalMont(monto);
		beanMontoOpe.setTotalMontFormat(ConsultaTrackingUtil.formateaImporteArchivo(monto));
		beanMontoOpe.setTotalOper(numOp);
		return beanMontoOpe;
	}
}
