package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;

/**
 * IOperationsDetailVostroRepository.
 *
 * @author Jesus Soto Aguilar
 */
public interface IOperationsDetailVostroRepository {

    OperationsMonitorQueryResponse obtenerDetalleOperacion(String view, String idOperacion);

}
