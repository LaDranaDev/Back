package mx.santander.h2h.monitoreo.model.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

/**
 * Response para mostrar los catálogos del monitor de operaciones
 */
@Getter
@Setter
public class OperationsMonitorCatalogsResponse implements Serializable {
    /** Serial id */
    private static final long serialVersionUID = -1293128199083531126L;
    /** Lista de divisas */
    private List<Pair> divisas;
    /** Lista de estatus */
    private List<Pair> estatus;
    /** Lista de productos */
    private List<Pair> productos;

    @Getter
    @AllArgsConstructor
    public static class Pair {
        /** key */
        private String key;
        /** value */
        private String value;
    }

}
