package mx.santander.h2h.monitoreo.commons.utils;



import jakarta.servlet.ServletRequest;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import mx.santander.pid.logadapter.core.model.MetadataTracker;
import mx.santander.pid.logadapter.core.worker.LogAdapterAbstractExtractor;



/**
 * The Class LogAdapterExtractorAPI
 * la clase es usada como default para la
 * extraccion de informacion, el default se considera que es usado cuando se
 * utiliza un esquema de servicio, los valores que se obtienen son de forma
 * principalmente de API Connect.
 * 
 * @author pquintra
 * @since 28/06/2022
 */
@Slf4j
public class LogAdapterExtractorAPI extends LogAdapterAbstractExtractor {

	/**
	 * Metodo que se encarga de obtener la informacion
	 * del metadata y del servlet request
	 * 
	 * @param metadata propiedad a la que se le asignara la informaicon
	 * que se requiere mandar
	 * 
	 * @param request contiene la informacion de la peticion
	 */
	@Override
	public void obtenerInformacion(MetadataTracker metadata, ServletRequest request) {
		log.info("---Worker--");
		HttpServletRequest servletRequest = (HttpServletRequest) request;
		metadata.setIdGlobalTracker(obtenValorCabecera(servletRequest, ID_GLOBAL));

		if (metadata.getIdGlobalTracker() != null) {
			metadata.setClasificacionPeticion("API");
		}

		metadata.setIdConsumidor(obtenValorCabecera(servletRequest, ID_CLIENT_ID));
		metadata.setIdDispsitivo(obtenValorCabecera(servletRequest, ID_DISPOSITIVO));
		metadata.setIdUsuarioFinal(servletRequest.getHeader("residente"));
	}


}
