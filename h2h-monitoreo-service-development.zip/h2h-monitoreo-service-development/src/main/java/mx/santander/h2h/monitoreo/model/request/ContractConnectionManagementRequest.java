package mx.santander.h2h.monitoreo.model.request;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * DTO para consultas de conexión de contratos
 * Dto de los datos de entrada de la administracion de conexion de contrato
 * 
 * @author sbautish
 * @since 03/05/2023
 *
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ContractConnectionManagementRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 134516811774427333L;

	/**
	 * numeroContrato
	 */
	private String numeroContrato;

	/**
	 * codigoCliente
	 */
	private String codigoCliente;

	/**
	 * Usuario
	 */
	private String usuario;

}
