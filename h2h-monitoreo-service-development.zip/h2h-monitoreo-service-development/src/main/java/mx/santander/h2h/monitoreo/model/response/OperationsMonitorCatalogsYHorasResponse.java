package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OperationsMonitorCatalogsYHorasResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3854956362884395439L;
	
	private OperationsMonitorCatalogsResponse operationsMonitorCatalogsResponse;
	
	private List<HorasCatalogo> listaHorario29;
	
	private List<HorasCatalogo> listaHorario99;
	
	private List<HorasCatalogo> listaHorario02;

	@Getter
    @AllArgsConstructor
    public static class HorasCatalogo {
        private String descr;
    }
}
