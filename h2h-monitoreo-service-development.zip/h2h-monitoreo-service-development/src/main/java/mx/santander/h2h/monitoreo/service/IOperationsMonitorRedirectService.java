package mx.santander.h2h.monitoreo.service;

/**
 * IOperationsMonitorRedirectService.
 * Define el metodo de enrutamiento del detalle del producto.
 *
 * @author Jesus Soto Aguilar
 * @since 07/07/2023
 */
public interface IOperationsMonitorRedirectService {

    /**
     * Obtiene el identificador de la vista en la que se mostrara el detalle.
     *
     * @param idProducto identificador del producto
     * @return identificador de la vista
     */
    String getNameRutaDetalle(String idProducto);
}
