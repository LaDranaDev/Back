package mx.santander.h2h.monitoreo.model.entity;

import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Entidad para la tabla H2H_ARCHIVO_HIST.
 *
 * @author Jesus Soto Aguilar
 * @since 13/04/2023
 */
@Entity
@Getter
@Setter
@Table(name = "H2H_ARCHIVO_HIST")
public class ArchivoHistEntity implements Serializable {

    /**
     * Serial.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Identificador del archivo.
     */
    @Id
    @Column(name = "ID_ARCHIVO")
    private Long idArchivo;

    /**
     * Nombre del archivo.
     */
    @Column(name = "NOMBRE_ARCH")
    private String nombreArchivo;

    /**
     * Id de la relación con la tabla H2H_LAY.
     */
    @Column(name = "ID_LAY")
    private Long idLayout;

    /**
     * Id de la relacion con la tabla CAT_STATUS.
     */
    @Column(name = "ID_ESTATUS")
    private Long idStatus;

    /**
     * Id de la relacion con la tabla H2H_CNTR.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_CNTR")
    private ContractEntity contractEntity;

    /**
     * Tamaño del archivo
     */
    @Column(name = "TAMANO")
    private Long tamano;

    /**
     * Bandera Activa o Inactiva según el estatus del contrato si esta en Enrollment.
     * Valores posibles I=Inactiva, A=Activa.
     */
    @Column(name = "BAND_ENRO")
    private Character bandEnrollment;

    /**
     * Fecha de lata del archivo.
     */
    @Column(name = "FECHA_REGISTRO")
    private LocalDate fechaRegistro;

    /**
     * Total de productos
     */
    @Column(name = "TOTA_PROD")
    private Integer totoalProductos;

    /**
     * Bandera que indica si el archivo es de fondeo.
     * A: Archivo de fondeo y el archivo ya fue procesado.
     * I: archivo de fondeo pero aun no se ha procesado.
     * null no es archivo de fondeo.
     */
    @Column(name = "BAND_ARCH_FOND")
    private Character bandFondeo;

    /**
     * Identificador del Canal por el que se recibe el archivo.
     */
    @Column(name = "ID_CANL")
    private Integer idCanal;

    /**
     * Identificador del Tipo de Procesamiento
     */
    @Column(name = "ID_CAT_PROC")
    private Long idCatProcesamiento;

    /**
     * Proceso que realizo el alta del registro.
     */
    @Column(name = "ID_PROC_REG")
    private Long idProcesoRegistro;

    /**
     * Bandera Archivo cierre.
     * A: Activo I: Inactivo.
     */
    @Column(name = "BAND_CIER")
    private Character bandCierre;

    /**
     * Bandera archivo cifrado o descifrado.
     * A:activo  I:Inactivo.
     */
    @Column(name = "BAND_CIFR")
    private Character bandCifrado;

    /**
     * Numero Total de Operaciones.
     */
    @Column(name = "TOTA_OPER")
    private Integer totalOperaciones;

    /**
     * Importe Total de las operaciones.
     */
    @Column(name = "TOTA_MONT")
    private BigDecimal totalMonto;

    /**
     * Identificador del message id dado por el integrador.
     */
    @Column(name = "MBX_MSG_ID")
    private Integer mbxMsgId;

    /**
     * Identificador del archivo not asociado al archivo del cliente.
     */
    @Column(name = "NOT_MSG_ID")
    private Integer notMsgId;

    /**
     * Bandera para marcar la disponiblidad de un archivo cuando sea solicitado por el front para su descarga.
     * I=Inactiva , A=Activa
     */
    @Column(name = "BAND_DISP_WEB")
    private Character bandDispWeb;

    /**
     * ID del mensaje cuando el archivo es rechazado por un error de encabezado, sumario o cifras de control.
     */
    @Column(name = "ID_MSG")
    private Integer idMensaje;

    /**
     * Bandera indicativa de la disponibilidad de un archivo para descargarse por parte del cliente
     */
    @Column(name = "BAND_DISP_WEB_CLTE")
    private Character bandDispWebClte;

    /**
     * Divisa de la operacion.
     * MXP o USD.
     */
    @Column(name = "DIVI")
    private Character divisa;

    /**
     * Numero de serie de certificado de descifrado
     */
    @Column(name = "SN_CERT")
    private String numSerieCert;

    /**
     * Hash de archivo cifrado
     */
    @Column(name = "HASH_CIFR")
    private String hashCifrado;

    /**
     * Hash de archivo en claro
     */
    @Column(name = "HASH_CLR")
    private String hashArchivo;

    /**
     * Identificador del message id dado por el integrador para la versión cifrada del archivo
     */
    @Column(name = "MBX_MSG_ID_CIFR")
    private Integer mbxMsgIdCifr;

    /**
     * Descripcion del el error de rechazo por usuario.
     */
    @Column(name = "MOTIVO_RECH_DUPLI")
    private String motivoRechDupl;

    /**
     * Identificador de archivo con el que se ha detectado que es posible duplicado
     */
    @Column(name = "ID_ARCH_DUPL")
    private Integer idArchDupl;

    /**
     * Charset encoding del archivo
     */
    @Column(name = "TXT_CHAR_SET_ENC")
    private String encodingArchivo;
}
