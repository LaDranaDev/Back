package mx.santander.h2h.monitoreo.repository;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Objects;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import mx.santander.h2h.monitoreo.constants.MonitorOperacionesConstants;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.util.DetalleOperacionUtils;
import mx.santander.h2h.monitoreo.util.UtilMapeoData;

@Repository
public class OperationsDetailPagRefRepository implements IOperationsDetailPagRefRepository {
    @Autowired
    private EntityManager entityManager;

    /**
     * Consulta el detalle de la operacion
     * @param idOperacion - ID de la operacion
     * @return Detalle de la operacion
     */
    @Override
    public OperationsMonitorQueryResponse obtenerDetalleOperacion(String idOperacion) {
        String stringQuery = generaConsultaDetalleOperacion(idOperacion);
        Query query = entityManager.createNativeQuery(stringQuery, Tuple.class);
//        query.setParameter("idOperacion", idOperacion);

        DetalleOperacionUtils.ProductoPIFDTO respuesta = new DetalleOperacionUtils.ProductoPIFDTO();
        respuesta.setProducto("OPERACION_EN_PROCESO");
        for (Object row : query.getResultList()) {
            if (row instanceof Tuple) {
                obtenDetallePagImp((Tuple) row, respuesta);
            }
        }

        return respuesta;
    }

    /**
     * Consulta el detalle de Pago de impuestos
     * @param respuestaProdDomis DTO de respuesta
     * @param row Fila
     */
    private void obtenDetallePagImp(Tuple row, DetalleOperacionUtils.ProductoPIFDTO respuestaProdDomis) {
        DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols();
        formatSymbols.setDecimalSeparator('.');
        formatSymbols.setGroupingSeparator(',');
        final DecimalFormat decimalFormat = new DecimalFormat("###,###,###,###,##0.00", formatSymbols);
        respuestaProdDomis.setFechaVenc(getValue(row, "FECH_REG"));
        String impoMovi = getValue(row, "IMPO_MOVI");
        respuestaProdDomis.setImporte(impoMovi.isEmpty() ? "$0.00" : "$" + decimalFormat.format(Double.valueOf(impoMovi)));
        respuestaProdDomis.setBucEmpleado(getValue(row, "BUC"));
        respuestaProdDomis.setNombreOrd(getValue(row, "NOMB_CLTE"));
        respuestaProdDomis.setCtaCargo(getValue(row, "NUM_CTA_CARGO"));
        respuestaProdDomis.setNumConvenio(getValue(row, MonitorOperacionesConstants.CLVE_CONV));
        respuestaProdDomis.setNombreConvenio(getValue(row, "DESR"));
        respuestaProdDomis.setReferencia(getValue(row, "NUME_MOVI_CARG"));
        respuestaProdDomis.setHora(getValue(row, "HORA_OPER"));
        respuestaProdDomis.setFolioSua(getValue(row, "REFE_MOV"));
        respuestaProdDomis.setCodError(getValue(row, "COD_ERR"));
        respuestaProdDomis.setDescError(getValue(row, MonitorOperacionesConstants.DESC_ERROR));
        respuestaProdDomis.setProducto(getValue(row, "DESC_PROD"));
        respuestaProdDomis.setNumTarjeta(getValue(row, "CTA_CNV"));
        // Enmascaramos las Tarjetas
        respuestaProdDomis.setNumTarjeta( UtilMapeoData.getMascara(respuestaProdDomis.getNumTarjeta(), "tarjeta") );
        respuestaProdDomis.setNomArch(getValue(row, "NOMBRE_ARCH"));
        respuestaProdDomis.setDivisa(getValue(row, "DIVISA"));
        respuestaProdDomis.setEstatus(getValue(row, "DESC_ESTATUS"));
        respuestaProdDomis.setMensaje(getValue(row, MonitorOperacionesConstants.DESC_ERROR));
        respuestaProdDomis.setIdProducto(getValue(row, "CVE_PROD_OPER"));
        respuestaProdDomis.setIdEstatus(getValue(row, "ID_ESTATUS"));
        respuestaProdDomis.setLineaCaptura(getValue(row, "OBSE_ABO"));
    }

    /**
     * Genera la consulta del detalle de la operacion
     *
     * @return Consulta de detalle de operacion
     */
    private String generaConsultaDetalleOperacion(String idOperacion) {
    	final StringBuilder query = new StringBuilder();
    	query.append("SELECT PROD.* FROM ( ")
    		.append(getConsultaByProducto(true))
    		.append(" UNION ALL ")
    		.append(getConsultaByProducto(false))
    		.append(") PROD WHERE PROD.ID_REG = ")
    		.append(idOperacion);
        return query.toString();
    }

    /**
     * Crea el query por producto y si el del dia de hoy o el de tres meses
     * @param tresMeses boleano indicador de tres meses
     * @return SQL del producto
     */
    private String getConsultaByProducto(boolean tresMeses) {
    	final StringBuilder query = new StringBuilder();
    	query.append("SELECT ")
    			.append(" REG.DIVI DIVISA,REG.CNTA_CARG NUM_CTA_CARGO, REG.CNTA_ABON NUN_CTA_ABONO, ")
    			.append(" ARCH.NOMBRE_ARCH, REG.ID_ESTATUS, EST.DESC_ESTATUS, REG.MONT IMPORTE,  ")
    			.append(" ARCH.FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, ")
    			.append(" REG.FECH_OPER FECHA_PRESENTACION_INICIAL,to_char(DETA.FECH_REG,'dd/mm/yyyy') FECH_REG, REG.NUME_MOVI, ") 
    			.append(" DETA.ID_REG, DETA.FECH_OPER,DETA.HORA_OPER,DETA.BUC,DETA.NUME_MOVI_CARG,DETA.OBSE_ABO,CNTA_CARG.NOMB_TITU NOMB_CLTE, ")
    			.append(" DETA.NUM_CTA_ABO,DETA.IMPO_MOVI,DETA.CVE_PROD_OPER,PROD.DESC_PROD,DETA.CLVE_CONV , CNV.DESR, CNV.NUM_CTA CTA_CNV ")
    			.append(",DECODE(DETA.DESC_ERR,null,MSG.MSG_H2H ,DETA.DESC_ERR) as  DESC_ERR, DETA.REFE_MOV  ")
    			.append("FROM  H2H_PROD_PAGO_REFE")
    			.append(tresMeses ? "_TRAN DETA " : " DETA ")
    			.append("INNER JOIN " + (tresMeses ? "H2H_REG_TRAN" : "H2H_REG") + " REG ON REG.ID_REG=DETA.ID_REG ")
    			.append("INNER JOIN " + (tresMeses ? "H2H_ARCHIVO_TRAN" : "H2H_ARCHIVO") + " ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ")
    			.append("INNER JOIN H2H_CAT_PROD PROD ON PROD.CVE_PROD_OPER=REG.CVE_PROD_OPER ")
    			.append("INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS ")
    			.append("LEFT JOIN H2H_CAT_CONV CNV ON trim(CNV.clve_serv)=DETA.CLVE_CONV ")
    			.append("LEFT JOIN H2H_MSG MSG ON MSG.ID_MSG = REG.ID_MSG ")
    			.append("LEFT JOIN H2H_CTA_INFO CNTA_CARG ON REG.CNTA_CARG = CNTA_CARG.NUME_CTA AND CNTA_CARG.TIPO_CTA = 'O' ")
    			.append("");
        return query.toString();
    }

    protected String getValue(Tuple tuple, String key) {
        try {
            return Objects.toString(tuple.get(key), "").trim();
        } catch (IllegalArgumentException e) {
            return "";
        }
    }

}
