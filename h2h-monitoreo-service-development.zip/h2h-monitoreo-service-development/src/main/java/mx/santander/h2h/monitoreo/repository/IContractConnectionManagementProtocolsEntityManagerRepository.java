package mx.santander.h2h.monitoreo.repository;

import java.util.List;

import mx.santander.h2h.monitoreo.model.response.ContractResponse;
import mx.santander.h2h.monitoreo.model.response.ParametersGetPutResponse;

public interface IContractConnectionManagementProtocolsEntityManagerRepository {

	List<ContractResponse> findContractConnectionByContractNumber(String numeroContrato);

	Integer findContractIdProtocol(Integer idContrato);

	List<ParametersGetPutResponse> findContractParametersGetPut(Integer idContrato, Integer idProtocol, String tipoActividad);

	List<String> findParametersNameInProtocol(Integer idProtocol);

	void updateRegistrationStatus(Integer idRegistro, String tipoProcesamiento, String estado);

}
