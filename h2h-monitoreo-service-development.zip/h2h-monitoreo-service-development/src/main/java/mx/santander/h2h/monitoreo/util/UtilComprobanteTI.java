package mx.santander.h2h.monitoreo.util;

import java.util.List;

import static mx.santander.h2h.monitoreo.util.UtilComprobante.agregaIdReg;

/**
 * @author fespinosa
 *
 */
public final class UtilComprobanteTI {

    /**" UNION ALL "*/
    private static final String UNION_ALL=" UNION ALL ";
    /**parte 1 de query***/
    private static final String SELECT_PART_1="SELECT r.ID_REG, cntr.NUM_CNTR CONTRATO, to_char(tranin.NUM_CTA_ORD) NUM_CTA_CARGO,r.CNTA_ABON NUN_CTA_ABONO, ";
    /**parte de query de PERSONALIDAD y NUM_CNTR*/
    private static final String SELECT_PART_PERSONALIDAD_NUM_CNTR="clte.PERSONALIDAD, clte.RFC,cntr.NUM_CNTR, ";
    /**parte de select para Banc_abon**/
    private static final String SELECT_PART_BANC_ABON ="tranin.TXT_NOM_BENE BANC_ABON, ";
    /**parte de qur inner con H2H_CAT_PROD*/
    private static final String SELECT_PART_INNER_H2H_CAT_PROD="INNER JOIN H2H_CAT_PROD ct ON r.cve_prod_oper = ct.cve_prod_oper ";
    /**parte de qur inner con H2H_CNTR*/
    private static final String SELECT_PART_INNER_H2H_CNTR="INNER JOIN H2H_CNTR cntr ON cntr.id_cntr = a.id_cntr ";
    /**parte de qur inner con H2H_CLTE*/
    private static final String SELECT_PART_INNER_H2H_CLTE="INNER JOIN H2H_CLTE clte ON cntr.id_clte = clte.id_clte ";
    /**parte de qur inner con H2H_CAT_ESTATUS*/
    private static final String SELECT_PART_INNER_H2H_CAT_ESTATUS="LEFT JOIN H2H_CAT_ESTATUS ce ON ce.id_CAT_estatus = r.id_estatus ";
    /** LEFT JOIN H2H_CTA_INFO ca ON r.CNTA_ABON = ca.NUME_CTA AND ca.TIPO_CTA = 'B' */
    private static final String LEFT_JOIN_H2H_CTA_INFO_BENE=" LEFT JOIN H2H_CTA_INFO ca ON tranin.NUM_CTA_BENE = ca.NUME_CTA AND ca.TIPO_CTA = 'B' ";
    /** LEFT JOIN H2H_CTA_INFO ca ON r.CNTA_ABON = ca.NUME_CTA AND ca.TIPO_CTA = 'B' */
    private static final String LEFT_JOIN_H2H_CTA_INFO_ORDE=" LEFT JOIN H2H_CTA_INFO co ON tranin.NUM_CTA_ORD = ca.NUME_CTA AND ca.TIPO_CTA = 'O' ";
    /** AND (tranin.cod_prod = '31' OR tranin.cod_prod = '32') */
    private static final String AND_COD_PROD_31_OR_32 = "AND (tranin.cod_prod = '31' OR tranin.cod_prod = '32') ";

    /**constructor**/
    private UtilComprobanteTI() {
    }
    /**
     * Obtiene el query de Transferencias Internacionales.
     *
     * @param listIds
     *            List<Integer>
     * @return String query
     */
    protected static String obtenerQueryTranasferenciasInernacionales(List<Integer> listIds) {
        final StringBuilder sql = new StringBuilder()
                .append(SELECT_PART_1)
                .append("ct.DESC_PROD, tranin.IMP_ABONO_BENE IMPORTE,'0' REFERENCIA,tranin.COD_DIV_CTA_BENE  DIVISA, ce.DESC_ESTATUS, ")
                .append("to_char(r.FECH_APLI,'dd/mm/yyyy')  FECH_APLI,tranin.NUM_CTA_BENE BENEFICIARIO,null TIPO_PAGO,  ")
                .append("clte.BUC TITULAR,to_char(tranin.TXT_REF_NUME) CONCEPTO_PAGO,tranin.TXT_REF CLAVE_RASTREO,tranin.TXT_NOM_ORD BANCO_RECEPTOR,r.FECH_ENVI_BACK FECHA_OPERACION, ")
                .append("tranin.COD_PAIS_BENE CLAV_PROV,to_char(tranin.IMP_ABONO_BENE) NUM_DOCU,null FECH_VENCIMIENTO,null CVE_FORM_PAGO,'-'||trim(ct.CVE_PROD_OPER)||'-' ESTATUS_MOV, ")
                .append("null NUM_ORDEN,null FECHA_LIMITE_PAGO,tranin.TXT_REF_LEYE_ORD NUM_SUCURSAL, ")
                .append("DECODE(clte.PERSONALIDAD,'F',clte.NOMBRE  || ' '  || clte.APPATERNO  || ' '  || clte.APMATERNO,clte.RAZON_SCIA) RAZON_SCIA,tranin.TXT_CIUD_BENE NOM_CLTE, ")
                .append(SELECT_PART_PERSONALIDAD_NUM_CNTR)
                .append("'0' CLAVE_BENEF,tranin.COD_CVE_ESTAT ID_ESTA,'H2H' PERS_AUT,'' FORM_APLI, '' NOMB_RAZON_SOCI_PROV,'' RFC_PROV, ")
                .append(SELECT_PART_BANC_ABON)
                .append("tranin.TXT_RFC_BENE REFE_ABON,tranin.TXT_NOM_BCO_PAG TIPO_DOCU ")
                .append(" FROM H2H_MX_PROD_TRAN_INTN tranin ")
                .append("INNER JOIN H2H_REG r ON r.id_reg = tranin.id_reg ")
                .append(SELECT_PART_INNER_H2H_CAT_PROD)
                .append("INNER JOIN H2H_ARCHIVO a ON r.id_arch = a.id_archivo ")
                .append(SELECT_PART_INNER_H2H_CNTR)
                .append(SELECT_PART_INNER_H2H_CLTE)
                .append(SELECT_PART_INNER_H2H_CAT_ESTATUS);


        agregaIdReg(listIds, sql);
        sql.append(AND_COD_PROD_31_OR_32);
        sql.append(UNION_ALL)
                .append(SELECT_PART_1)
                .append("ct.DESC_PROD, tranin.IMP_ABONO_BENE IMPORTE,'0' REFERENCIA,tranin.COD_DIV_CTA_BENE  DIVISA, ce.DESC_ESTATUS, ")
                .append("to_char(r.FECH_APLI,'dd/mm/yyyy')  FECH_APLI,tranin.NUM_CTA_BENE BENEFICIARIO,null TIPO_PAGO,  ")
                .append("clte.BUC TITULAR,to_char(tranin.TXT_REF_NUME) CONCEPTO_PAGO,tranin.TXT_REF CLAVE_RASTREO,tranin.TXT_NOM_ORD BANCO_RECEPTOR,r.FECH_ENVI_BACK FECHA_OPERACION, ")
                .append("tranin.COD_PAIS_BENE CLAV_PROV,to_char(tranin.IMP_ABONO_BENE) NUM_DOCU,null FECH_VENCIMIENTO,null CVE_FORM_PAGO,'-'||trim(ct.CVE_PROD_OPER)||'-' ESTATUS_MOV, ")
                .append("null NUM_ORDEN,null FECHA_LIMITE_PAGO,tranin.TXT_REF_LEYE_ORD NUM_SUCURSAL, ")
                .append("DECODE(clte.PERSONALIDAD,'F',clte.NOMBRE  || ' '  || clte.APPATERNO  || ' '  || clte.APMATERNO,clte.RAZON_SCIA) RAZON_SCIA,tranin.TXT_CIUD_BENE NOM_CLTE, ")
                .append(SELECT_PART_PERSONALIDAD_NUM_CNTR)
                .append("'0' CLAVE_BENEF,tranin.COD_CVE_ESTAT ID_ESTA,'H2H' PERS_AUT,'' FORM_APLI, '' NOMB_RAZON_SOCI_PROV,'' RFC_PROV, ")
                .append(SELECT_PART_BANC_ABON)
                .append("tranin.TXT_RFC_BENE REFE_ABON,tranin.TXT_NOM_BCO_PAG TIPO_DOCU ")
                .append(" FROM H2H_MX_PROD_TRAN_INTN_TRAN tranin ")
                .append("INNER JOIN H2H_REG_TRAN r ON r.id_reg = tranin.id_reg ")
                .append(SELECT_PART_INNER_H2H_CAT_PROD)
                .append("INNER JOIN H2H_ARCHIVO_TRAN a ON r.id_arch = a.id_archivo ")
                .append(SELECT_PART_INNER_H2H_CNTR)
                .append(SELECT_PART_INNER_H2H_CLTE)
                .append(SELECT_PART_INNER_H2H_CAT_ESTATUS);

        agregaIdReg(listIds, sql);
        sql.append(AND_COD_PROD_31_OR_32);
        return sql.toString();
    }
    /**
     * Obtiene el query de Transferencias Internacionales.
     *
     * @param listIds
     *            List<Integer>
     * @return String query
     */
    protected static String obtenerQueryTranasferenciasIntMBC(List<Integer> listIds) {
        final StringBuilder sql = new StringBuilder()
                .append(SELECT_PART_1)
                .append("ct.DESC_PROD, decode(tranin.COD_DIV_CTA_ORD,'MXP',tranin.IMP_CARGO,tranin.IMP_ABONO) IMPORTE,to_char(tranin.TXT_REF_NUME) REFERENCIA,tranin.COD_DIV_CTA_ORD  DIVISA, ce.DESC_ESTATUS,")
                .append("to_char(r.FECH_APLI,'dd/mm/yyyy')  FECH_APLI,tranin.TXT_RFC_BENE BENEFICIARIO,tranin.NUM_ORDEN TIPO_PAGO,  ")
                .append("clte.BUC TITULAR,tranin.TXT_REF_LEYE_ORD CONCEPTO_PAGO,tranin.TXT_REF_CTE CLAVE_RASTREO,tranin.TXT_NOM_ORD BANCO_RECEPTOR,r.FECH_ENVI_BACK FECHA_OPERACION,")
                .append("tranin.NUM_CTA_BENE CLAV_PROV,null NUM_DOCU,null FECH_VENCIMIENTO,null CVE_FORM_PAGO,'-'||trim(ct.CVE_PROD_OPER)||'-' ESTATUS_MOV, ")
                .append("TO_CHAR(decode(tranin.COD_DIV_CTA_ORD,'USD',tranin.IMP_CARGO,tranin.IMP_ABONO)) NUM_ORDEN,null FECHA_LIMITE_PAGO,tranin.COD_DIV_CTA_BENE NUM_SUCURSAL, ")
                .append("DECODE(clte.PERSONALIDAD,'F',clte.NOMBRE  || ' '  || clte.APPATERNO  || ' '  || clte.APMATERNO,clte.RAZON_SCIA) RAZON_SCIA,DECODE(co.NOMB_TITU,null,tranin.TXT_NOM_ORD,co.NOMB_TITU) NOM_CLTE,")
                .append(SELECT_PART_PERSONALIDAD_NUM_CNTR)
                .append("'0' CLAVE_BENEF,null ID_ESTA,DECODE(ca.NOMB_TITU,null,tranin.TXT_NOM_BENE,ca.NOMB_TITU) PERS_AUT,'' FORM_APLI, '' NOMB_RAZON_SOCI_PROV,'' RFC_PROV,")
                .append(SELECT_PART_BANC_ABON)
                .append("tranin.TXT_RFC_BENE REFE_ABON,to_char(tranin.IMP_TIPO_CAMB) TIPO_DOCU ")
                .append(" FROM H2H_MX_PROD_BANC_CAMB tranin ")
                .append("INNER JOIN H2H_REG r ON r.id_reg = tranin.id_reg ")
                .append(SELECT_PART_INNER_H2H_CAT_PROD)
                .append("INNER JOIN H2H_ARCHIVO a ON r.id_arch = a.id_archivo ")
                .append(SELECT_PART_INNER_H2H_CNTR)
                .append(SELECT_PART_INNER_H2H_CLTE)
                .append(SELECT_PART_INNER_H2H_CAT_ESTATUS)
                .append(LEFT_JOIN_H2H_CTA_INFO_BENE)
                .append(LEFT_JOIN_H2H_CTA_INFO_ORDE);
        agregaIdReg(listIds, sql);
        sql.append(UNION_ALL)
                .append(SELECT_PART_1)
                .append("ct.DESC_PROD, decode(tranin.COD_DIV_CTA_ORD,'MXP',tranin.IMP_CARGO,tranin.IMP_ABONO) IMPORTE,to_char(tranin.TXT_REF_NUME) REFERENCIA,tranin.COD_DIV_CTA_ORD  DIVISA, ce.DESC_ESTATUS,")
                .append("to_char(r.FECH_APLI,'dd/mm/yyyy')  FECH_APLI,tranin.TXT_RFC_BENE BENEFICIARIO,tranin.NUM_ORDEN TIPO_PAGO,  ")
                .append("clte.BUC TITULAR,tranin.TXT_REF_LEYE_ORD CONCEPTO_PAGO,tranin.TXT_REF_CTE CLAVE_RASTREO,tranin.TXT_NOM_ORD BANCO_RECEPTOR,r.FECH_ENVI_BACK FECHA_OPERACION,")
                .append("tranin.NUM_CTA_BENE CLAV_PROV,null NUM_DOCU,null FECH_VENCIMIENTO,null CVE_FORM_PAGO,'-'||trim(ct.CVE_PROD_OPER)||'-' ESTATUS_MOV, ")
                .append("TO_CHAR(decode(tranin.COD_DIV_CTA_ORD,'USD',tranin.IMP_CARGO,tranin.IMP_ABONO)) NUM_ORDEN,null FECHA_LIMITE_PAGO,tranin.COD_DIV_CTA_BENE NUM_SUCURSAL, ")
                .append("DECODE(clte.PERSONALIDAD,'F',clte.NOMBRE  || ' '  || clte.APPATERNO  || ' '  || clte.APMATERNO,clte.RAZON_SCIA) RAZON_SCIA,DECODE(co.NOMB_TITU,null,tranin.TXT_NOM_ORD,co.NOMB_TITU) NOM_CLTE,")
                .append(SELECT_PART_PERSONALIDAD_NUM_CNTR)
                .append("'0' CLAVE_BENEF,null ID_ESTA,DECODE(ca.NOMB_TITU,null,tranin.TXT_NOM_BENE,ca.NOMB_TITU) PERS_AUT,'' FORM_APLI, '' NOMB_RAZON_SOCI_PROV,'' RFC_PROV,")
                .append(SELECT_PART_BANC_ABON)
                .append("tranin.TXT_RFC_BENE REFE_ABON,to_char(tranin.IMP_TIPO_CAMB) TIPO_DOCU ")
                .append(" FROM H2H_MX_PROD_BANC_CAMB_TRAN tranin ")
                .append("INNER JOIN H2H_REG_TRAN r ON r.id_reg = tranin.id_reg ")
                .append(SELECT_PART_INNER_H2H_CAT_PROD)
                .append("INNER JOIN H2H_ARCHIVO_TRAN a ON r.id_arch = a.id_archivo ")
                .append(SELECT_PART_INNER_H2H_CNTR)
                .append(SELECT_PART_INNER_H2H_CLTE)
                .append(SELECT_PART_INNER_H2H_CAT_ESTATUS)
                .append(LEFT_JOIN_H2H_CTA_INFO_BENE)
                .append(LEFT_JOIN_H2H_CTA_INFO_ORDE);
        agregaIdReg(listIds, sql);
        return sql.toString();
    }

}
