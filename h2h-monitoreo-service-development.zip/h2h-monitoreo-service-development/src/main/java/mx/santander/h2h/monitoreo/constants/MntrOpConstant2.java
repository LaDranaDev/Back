/**
* Santander SCIB - Banco Santander Negocios Globales
* Todos los derechos reservados
* MntrOpConstant2.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <4 jul. 2024 12:14:51>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.constants;


/**
 * Clase generada para MntrOpConstant2.
 *
 * @autor C320868
 * @modifico C320868
 */
public class MntrOpConstant2 {
	
	/** Declaracion de Constante CAD_INNER. */
	public static final String CAD_INNER = "INNER JOIN H2H_CLTE CLTE USING (ID_CLTE) "
		+ "INNER JOIN H2H_CAT_PROD PROD USING(CVE_PROD_OPER) "
		+ "INNER JOIN H2H_CAT_ESTATUS EST ON TMP.ID_ESTATUS = EST.ID_CAT_ESTATUS "
		+ "LEFT JOIN H2H_MSG MSG ON MSG.ID_MSG = TMP.ID_MSG ";
	
	/** Declaracion de Constante CAD_INNER_CVEOP. */
	public static final String CAD_INNER_CVEOP = "LEFT JOIN H2H_MX_CNTR_ENL ctre ON DETA.ID_CNTR_ENLA = TO_CHAR(ctre.ID_CNTR_ENLA) "
		+ "LEFT JOIN H2H_CNTR_CTA ccta ON ctre.ID_CNTR = ccta.ID_CNTR "
		+ "LEFT JOIN H2H_CTA_INFO info ON ccta.NUM_CTA = info.NUME_CTA "
		+ "LEFT JOIN H2H_ARCH_BACK_TRAN abt ON  TMP.id_arch_be = abt.id_arch_back ";
}
