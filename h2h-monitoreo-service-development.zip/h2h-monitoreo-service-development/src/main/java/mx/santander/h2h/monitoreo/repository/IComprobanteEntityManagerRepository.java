package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.response.ComprobantesOperacionResponse;

import java.util.List;

/**
 * @author Daniel Ruiz
 * Interfaz del repositrio para Comprobantes.
 */
public interface IComprobanteEntityManagerRepository {

    /**
     * Obtener los comprobantes de las operaciones.
     * @param listIds List<Integer>
     * @param vistaProd List<String>
     * @return Lista de comprobantes
     */
    List<ComprobantesOperacionResponse> obtenerComprobantes(List<Integer> listIds, List<String> vistaProd);

}
