package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.GeneralResponse;

/**
 * Servicio para el Monitor de Operaciones
 *
 * @author Omar Rosas
 * @since 07/07/2023
 */
public interface IOperationsMonitorAuxService {    
    /**
     * Genera el xml de la consulta de operaciones y lo envia a Sterling
     * 
     * @param request Datos de la consulta de operaciones
     * @return Respuesta de la operacion
     * */
    GeneralResponse generaXmlOperaciones(OperationsMonitorQueryRequest request);
    
    /**
     * Genera el xml de la consulta de operaciones y lo envia a Sterling para exportaciones
     * 
     * @param request Datos de la consulta de operaciones
     * @return Respuesta de la operacion
     * */
    GeneralResponse generaXmlOperacionesExp(OperationsMonitorQueryRequest request);

}
