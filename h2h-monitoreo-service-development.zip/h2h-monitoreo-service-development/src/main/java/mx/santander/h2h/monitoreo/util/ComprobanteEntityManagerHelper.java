package mx.santander.h2h.monitoreo.util;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

import jakarta.persistence.Tuple;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;

import mx.santander.h2h.monitoreo.model.response.ComprobantesOperacionResponse;

/**
 * Clase de apoyo de la clase ComprobanteEntityManagerRepository
 * 
 * @author Z483900
 * @since 27/09/2023
 */
public final class ComprobanteEntityManagerHelper {
	/**
	 * constante para la variable de tipo String REFE_ABON
	 */
	private static final String REFE_ABON = "REFE_ABON";
	/**
	 * constante de tipo String para la variable de TIPO_PAGO
	 */
	private static final String TIPO_PAGO = "TIPO_PAGO";
	/***
	 * constante de tipo String para la variable de CLAVE_RASTREO
	 */
	private static final String CLAVE_RASTREO = "CLAVE_RASTREO";
	/**
	 * Constantes CONCEPTO_PAGO TCS (sonar)
	 */
	private static final String CONCEPTO_PAGO = "CONCEPTO_PAGO";
	/** Constante DIVISA MXP. */
	private static final transient String MXP = "MXP";

	/** Constante DIVISA MXN. */
	private static final transient String MXN = "MXN";

	/** Constante DIVISA MXN. */
	private static final transient String MN = "MN";
	/** Constante CONTRATO. */
	private static final String CONTRATO = "CONTRATO";
	/***
	 * Constante para NOM_CLTE de tipo String
	 */
	private static final String NOM_CLTE = "NOM_CLTE";
	/***
	 * cnstante de tipo string para NOMB_RAZON_SOCI_PROV
	 */
	private static final String NOMB_RAZON_SOCI_PROV = "NOMB_RAZON_SOCI_PROV";
	/** Constante TITULAR. */
	private static final String TITULAR = "TITULAR";
	/** Constante BANC_ABON. */
	private static final String BANC_ABON = "BANC_ABON";
	/** Constante FECH_APLI. */
	private static final String FECH_APLI = "FECH_APLI";
	/** Constante NUM_CTA_CARGO. */
	private static final String NUM_CTA_CARGO = "NUM_CTA_CARGO";

	/**
	 * Constructor default
	 */
	private ComprobanteEntityManagerHelper() {
	}

	/**
	 * Aplica formatos especiales al bean.
	 * 
	 * @param bean ComprobantesOperacionDTO
	 */
	public static void aplicaFormatoEspecial(ComprobantesOperacionResponse bean) {
		if (bean != null && StringUtils.isNotBlank(bean.getCuentaCargo())) {
			// Mostrar visibles solo los 4 ultimos digitos
			String tmp = bean.getCuentaCargo();
			tmp = tmp.trim();
			final int lngtd = tmp.length();
			if (lngtd >= 4) {
				final String ult = tmp.substring(lngtd - 4, lngtd);
				final String inicio = StringUtils.leftPad(StringUtils.EMPTY, lngtd - 4, "*");
				bean.setCuentaCargo(inicio + ult);
			}
			// Cambio de divisa MXN a MXP
			tmp = bean.getDivisa();
			if (StringUtils.isNotBlank(tmp) && (tmp.equals(MN) || tmp.equals(MXN))) {
				bean.setDivisa(MXP);
			}

			// Mostrar visibles solo los 4 ultimos digitos
			if (bean.isEsPagoTDC()) {
				String tmp2 = bean.getCuentaAbono();
				tmp2 = tmp2.trim();
				final int lngtd2 = tmp2.length();
				if (lngtd2 >= 4) {
					final String ult2 = tmp2.substring(lngtd2 - 4, lngtd2);
					final String inicio2 = StringUtils.leftPad(StringUtils.EMPTY, lngtd2 - 4, "*");
					bean.setCuentaAbono(inicio2 + ult2);
					// Enmascaramos la cuenta Abono
					bean.setCuentaAbono(UtilMapeoData.getMascara(bean.getCuentaAbono(), "abono"));
				}
			}
		}
	}

	/***
	 * @param aSession session bean
	 * @param bean     bean a llenar
	 * @param map      con datos
	 */
	public static void llenaBeanImpuFed(ComprobantesOperacionResponse bean, Tuple map, String longitud) {
		bean.setContrato(ObjectUtils.toString(map.get(CONTRATO)));
		bean.setTitular(ObjectUtils.toString(map.get(TITULAR)));
		bean.setLineaCaptura(ObjectUtils.toString(map.get(CONCEPTO_PAGO)));
		bean.setCuentaCargo(ObjectUtils.toString(map.get(NUM_CTA_CARGO)));
		bean.setFechaOp(ObjectUtils.toString(map.get("FECH_APLI")));
		bean.setNumOrden(ObjectUtils.toString(map.get("NUM_ORDEN")));
		bean.setTipoPago(ObjectUtils.toString(map.get(TIPO_PAGO)));
		bean.setPlaza(ObjectUtils.toString(map.get(REFE_ABON)));
		bean.setSucursal(ObjectUtils.toString(map.get(BANC_ABON)));
		bean.setLlavePago(ObjectUtils.toString(map.get("NUM_DOCU")));
		bean.setBeneficiario(ObjectUtils.toString(map.get(NOM_CLTE)));
		bean.setRazonSocial(ObjectUtils.toString(map.get("RAZON_SCIA")));
		if (!bean.getRazonSocial().isEmpty()) {
			if (longitud != null) {
				int longitudint = Integer.parseInt(longitud);
				if (bean.getRazonSocial().length() > longitudint) {
					bean.setRazonSocial(bean.getRazonSocial().substring(0, longitudint));
				}
				if (bean.getBeneficiario().length() > longitudint) {
					bean.setBeneficiario(bean.getBeneficiario().substring(0, longitudint));
				}
			}
		}
		bean.setNomProveedor(ObjectUtils.toString(map.get(NOMB_RAZON_SOCI_PROV)));
		if (bean.getLlavePago() != null && !bean.getLlavePago().isEmpty()) {
			bean.setEsVer2(true);
		}
	}

	/***
	 * 
	 * @param bean bean allenar
	 * @param map  mapa con datos
	 */
	public static void llenaPagoRefBean(ComprobantesOperacionResponse bean, Tuple map) {
		bean.setContrato(ObjectUtils.toString(map.get(CONTRATO)));
		bean.setTitular(ObjectUtils.toString(map.get(TITULAR)));
		bean.setCuentaCargo(ObjectUtils.toString(map.get(NUM_CTA_CARGO)));
		bean.setFechaAplic(ObjectUtils.toString(map.get(FECH_APLI)));
		// llenado especial campo 25 y 29
		String campos = ObjectUtils.toString(map.get(BANC_ABON));
		if (campos != null && campos.length() > 0) {
			String[] cadSeparada = campos.split(">"); // TCS (sonar)
			// clave de rastreo Campo25 en posicion 19
			bean.setRefInterbancaria(cadSeparada.length >= 19 ? cadSeparada[18] : "");
			// Folio operacion campo 29 en posicion 25, esto se reviso con Tere y Pedro y se obtiene el valor del token 25 en el proceso de sterling
			bean.setCveProveedor(cadSeparada.length >= 26 ? cadSeparada[24] : "");
		} else {
			bean.setCveProveedor("");
			bean.setRefInterbancaria("");
		}
		bean.setConceptoPago(ObjectUtils.toString(map.get(REFE_ABON)));
		bean.setConvenio(ObjectUtils.toString(map.get("CLAVE_BENEF")));
		bean.setClaveRastreo(ObjectUtils.toString(map.get(CLAVE_RASTREO)));
		bean.setTipoPago(ObjectUtils.toString(map.get(TIPO_PAGO)));
		aplicaFormatoEspecial(bean);
	}

	/***
	 * 
	 * @param bean bean allenar
	 * @param map  mapa con datos
	 */
	public static void llenatransInterBean(ComprobantesOperacionResponse bean, Tuple map) {
		bean.setContrato(ObjectUtils.toString(map.get(CONTRATO)));
		bean.setRazonSocial(ObjectUtils.toString(map.get("RAZON_SCIA")));
		bean.setFechaAplic(ObjectUtils.toString(map.get("FECH_APLI")));
		bean.setConceptoPago(ObjectUtils.toString(map.get("CONCEPTO_PAGO")));
		bean.setClaveRastreo(ObjectUtils.toString(map.get("CLAVE_RASTREO")));
		bean.setFormaPago(ObjectUtils.toString(map.get("NUM_SUCURSAL")));
		bean.setCuentaCargo(ObjectUtils.toString(map.get(NUM_CTA_CARGO)));
		aplicaFormatoEspecial(bean);
		ComprobantesOperacionResponse dtoformato = new ComprobantesOperacionResponse();
		dtoformato.setCuentaCargo(ObjectUtils.toString(map.get("BENEFICIARIO")));
		aplicaFormatoEspecial(dtoformato);
		bean.setBeneficiario(dtoformato.getCuentaCargo());
		// Formateo de importe
		final DecimalFormat decimalFormat = new DecimalFormat("###,###,###,###,##0.00", new DecimalFormatSymbols());
		bean.setRefInterbancaria(ObjectUtils.toString(map.get("REFE_ABON")));
		bean.setTipoDoc(ObjectUtils.toString(map.get("TIPO_DOCU")));
		bean.setCveProveedor(ObjectUtils.toString(map.get("CLAV_PROV")));
		bean.setDivisa(ObjectUtils.toString(map.get("DIVISA")));

		final String impFormat = "$" + decimalFormat.format(Double.valueOf(ObjectUtils.toString(map.get("IMPORTE"))));
		bean.setImporte(impFormat);
		final String impFormat2 = "$" + decimalFormat.format(Double.valueOf(ObjectUtils.toString(map.get("NUM_DOCU"))));
		bean.setNoDocu(impFormat2);
		final String impFormat3 = "$" + decimalFormat.format(Double.valueOf(ObjectUtils.toString(map.get("CLAVE_BENEF"))));
		bean.setCveBenef(impFormat3);

		bean.setEstatus(ObjectUtils.toString(map.get("DESC_ESTATUS")));
		bean.setBanco(ObjectUtils.toString(map.get("REFERENCIA")));
		bean.setTitular(ObjectUtils.toString(map.get("TITULAR")));
		bean.setEstatusMov("-31-");
		// bean.setBanco(ObjectUtils.toString(map.get("BANCO_RECEPTOR")));
		// bean.setCanal(ObjectUtils.toString(map.get("BANC_ABON")));
		bean.setBanco(ObjectUtils.toString(map.get("BANC_ABON")));
		bean.setCanal(ObjectUtils.toString(map.get("BANCO_RECEPTOR")));
		bean.setEstatusMov(ObjectUtils.toString(map.get("ESTATUS_MOV")));
		// Aqui se registra la ciudad del beneficiario
		bean.setNomProveedor(ObjectUtils.toString(map.get("NOM_CLTE")));
	}

	/***
	 * metodo para obtener los datos para el comprobante
	 * 
	 * @param bean bean allenar
	 * @param map  mapa con datos
	 */
	public static void llenatransInterMBCBean(ComprobantesOperacionResponse bean, Tuple map) {
		// Formateo de importe
		final DecimalFormat decimalFormat = new DecimalFormat("###,###,###,###,##0.00", new DecimalFormatSymbols());
		bean.setContrato(ObjectUtils.toString(map.get(CONTRATO)));
		bean.setRazonSocial(ObjectUtils.toString(map.get("RAZON_SCIA")));
		bean.setTitular(ObjectUtils.toString(map.get("TITULAR")));
		bean.setFechaAplic(ObjectUtils.toString(map.get("FECH_APLI")));
		bean.setTipoPago(ObjectUtils.toString(map.get("TIPO_PAGO")));
		bean.setRefInterbancaria(ObjectUtils.toString(map.get("REFERENCIA")));
		bean.setConceptoPago(ObjectUtils.toString(map.get("CONCEPTO_PAGO")));
		bean.setClaveRastreo(ObjectUtils.toString(map.get("CLAVE_RASTREO")));
		bean.setCuentaCargo(ObjectUtils.toString(map.get(NUM_CTA_CARGO)));
		bean.setCuentaAbono(ObjectUtils.toString(map.get("CLAV_PROV")));
		// Enmascaramos la cuenta Abono
		bean.setCuentaAbono(UtilMapeoData.getMascara(bean.getCuentaAbono(), "abono"));
		
		bean.setBeneficiario(ObjectUtils.toString(map.get("BENEFICIARIO")));
		final String impTipoCambio = "$" + decimalFormat.format(Double.valueOf(ObjectUtils.toString(map.get("TIPO_DOCU"))));
		bean.setTipoDoc(impTipoCambio);

		final String impFormat = "$" + decimalFormat.format(Double.valueOf(ObjectUtils.toString(map.get("IMPORTE"))));
		bean.setImporte(impFormat);
		final String impFormat2 = "$" + decimalFormat.format(Double.valueOf(ObjectUtils.toString(map.get("NUM_ORDEN"))));
		bean.setNumOrden(impFormat2);
		final String impIva = "$" + decimalFormat.format(Double.valueOf(ObjectUtils.toString(map.get("CLAVE_BENEF"))));

		bean.setFormaPago(impIva);// Divisa(impIva);
		bean.setDivisa(ObjectUtils.toString(map.get("DESC_ESTATUS")));
		bean.setEstatus(ObjectUtils.toString(map.get("DESC_ESTATUS")));
		bean.setEstatusMov(ObjectUtils.toString(map.get("ESTATUS_MOV")));

		bean.setNoDocu(ObjectUtils.toString(map.get("NOM_CLTE")));
		bean.setPersAut(ObjectUtils.toString(map.get("PERS_AUT")));
	}

}
