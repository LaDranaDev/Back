package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;

/**
 * IOperationsDetailPagImpAduan.
 *
 * @author Jesus Soto Aguilar
 */
public interface IOperationsDetailPagImpAduanRepository {
    OperationsMonitorQueryResponse obtenerDetalleOperacion(String view, String idOperacion);
}
