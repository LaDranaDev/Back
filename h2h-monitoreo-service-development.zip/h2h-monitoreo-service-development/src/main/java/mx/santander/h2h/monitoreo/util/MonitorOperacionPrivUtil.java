package mx.santander.h2h.monitoreo.util;

import java.util.Map;

import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.constants.MonitorOperacionesConstants;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.repository.OperationsMonitorEntityManagerHelper1Repository;

@Slf4j
@Component
public class MonitorOperacionPrivUtil {
	
	/** Declaracion de Variable Vacia */
	public static final String EMPTY = "";
	
	
	/**
	 * Metodo para agregar los INNER y Seleccion de las Tablas
	 * 
	 * @param delDia Dia
	 * @param idcntr String
	 * @return String
	 */
	public static String getselectImpFed(boolean delDia, String idcntr) {
		final StringBuilder queryImp = new StringBuilder();
		String tabla = EMPTY;
		if("21".equals(idcntr)){//imp Fed
			tabla="_IMPU_FEDE";
		}else if("22".equals(idcntr)){
			tabla="_PAGO_REFE";
		}else if("23".equals(idcntr)){
			tabla="_APO_OBRE_PATR";
		}
//		String cadSql = MonitorOperacionesConstants.REG_CNTA_ABON_NUN_CTA_ABONO_CVE_PROD_OPER_PROD_DESC_PROD;
//		if( "23".equals(idcntr) || "21".equals(idcntr) || "22".equals(idcntr)) {
//			cadSql = cadSql.replace("CVE_PROD_OPER", "PROD.CVE_PROD_OPER");
//		}
		//NO EXISTE EN FRONT ACTUAL

		queryImp
			.append(delDia ?  MonitorOperacionesConstants.SELECT_H2H_REG_TRAN_TABLA : MonitorOperacionesConstants.SELECT_H2H_REG_TABLA)
			.append(MonitorOperacionesConstants.REG_ID_REG_CLTE_BUC_REG_CNTA_CARG_NUM_CTA_CARGO)
			.append(MonitorOperacionesConstants.REG_CNTA_ABON_NUN_CTA_ABONO_CVE_PROD_OPER_PROD_DESC_PROD)
			.append("ARCH.NOMBRE_ARCH, PIF.REFE_MOV REFERENCIA, REG.ID_ESTATUS, ")
			.append(MonitorOperacionesConstants.EST_DESC_ESTATUS_REG_MONT_IMPORTE_CNTR_NUM_CNTR_REG_DIVI_DIVISA)
			.append("ARCH.FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, REG.NUM_EMAIL, PIF.OBSE_ABO, ");
			if( "23".equals(idcntr) ) {
				queryImp.append("PIF.REG_PATR REG_PATR, PIF.NUME_FOLI_SUA NUME_FOLI_SUA, ");	
			}
			queryImp.append("PIF.BUC BUC_EMPLEADO,PIF.CLVE_CONV CLVE_CONV, CANL.NOMB_CANL ");
			
			queryImp.append( UtilQuery.fromH2hArchivo(delDia) )
			.append( UtilQuery.innerJoinH2hReg(delDia) )
			.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CNTR_CNTR_USING_ID_CNTR)
			.append(MonitorOperacionesConstants.INNER_CLTE)
			.append(UtilQuery.selectImpFedDU(delDia, tabla) );
					
		 return queryImp.toString();
	}
	
	
	/**
	 * Genera la consulta de las operaciones de orden de pago
	 * @param delDia indica si se usan las tablas del diario
	 * @return String con la consulta
	 */
	public static String getSelectConsultaOperacionesOrdenPago(boolean delDia, String idProducto){
		final StringBuilder query = new StringBuilder();
		log.info("*****MIGAJA 2 *****");
//		String cadSQL = MonitorOperacionesConstants.SQL_MON_OPER2;
//		if( "80".equals(idProducto) ) {
//			cadSQL = cadSQL.replace("PROD.CVE_PROD_OPER", "CVE_PROD_OPER");
//		}
		
		query
			.append(delDia ?  "SELECT 'H2H_REG_TRAN' TABLA, " : "SELECT 'H2H_REG' TABLA, ")
			.append(MonitorOperacionesConstants.REG_ID_REG_CLTE_BUC_REG_CNTA_CARG_NUM_CTA_CARGO)
			.append(MonitorOperacionesConstants.REG_CNTA_ABON_NUN_CTA_ABONO_CVE_PROD_OPER_PROD_DESC_PROD)
			.append(MonitorOperacionesConstants.ARCH_NOMBRE_ARCH_REG_REFE_BE_REFERENCIA_REG_ID_ESTATUS)
			.append(MonitorOperacionesConstants.EST_DESC_ESTATUS_REG_MONT_IMPORTE_CNTR_NUM_CNTR_REG_DIVI_DIVISA)
			.append(MonitorOperacionesConstants.PART_QUERY_SELECT_FECHA_REGISTRO_APLI_PROD)
			.append("CANL.NOMB_CANL, ")
			.append("PAGO.NUM_ORDEN, PAGO.NOMB_BENE BENEFICIARIO ")
			.append(UtilQuery.fromH2hArchivo(delDia) )
			.append(UtilQuery.innerJoinH2hReg(delDia) )
			.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CNTR_CNTR_USING_ID_CNTR)
			.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CLTE)
			.append(MonitorOperacionesConstants.PART_QUERY_SELECT_INNER_CAT_PROD)
			.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CAT_ESTATUS_EST_ON_REG_ID_ESTATUS_EST_ID_CAT_ESTATUS)
			.append( MonitorOperacionesConstants.INNER_JOIN_H2H_CAT_CANL)
			.append( UtilQuery.innerJoinPagoDirc(delDia) );
		 return query.toString();
	}

	
	/**
	 * Genera la consulta de las operaciones de alta masiva de empleados
	 * @param delDia indica si se usan las tablas del diario
	 * @return String con la consulta
	 */
	public static String getQueryConsOpAltaMasiva(boolean delDia){
		final StringBuilder queryAl = new StringBuilder();
		log.info("*****MIGAJA 3 *****");
		queryAl
			.append(delDia ? "SELECT 'H2H_REG_TRAN' TABLA, " : "SELECT 'H2H_REG' TABLA, ")
			.append(MonitorOperacionesConstants.REG_ID_REG_CLTE_BUC_REG_CNTA_CARG_NUM_CTA_CARGO)
			.append(MonitorOperacionesConstants.REG_CNTA_ABON_NUN_CTA_ABONO_CVE_PROD_OPER_PROD_DESC_PROD)
			.append(MonitorOperacionesConstants.ARCH_NOMBRE_ARCH_REG_REFE_BE_REFERENCIA_REG_ID_ESTATUS)
			.append(MonitorOperacionesConstants.EST_DESC_ESTATUS_REG_MONT_IMPORTE_CNTR_NUM_CNTR_REG_DIVI_DIVISA)
			.append("ARCH.FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, REG.NUM_EMAIL, EMPL.NUME_CTA TIPO, ")
			.append("EMPL.NUME_EMPL NUMERO_EMPLEADO, EMPL.NUME_TARJ_NUEV NUMERO_TARJETA, EMPL.NUME_BUC_EMPL BUC_EMPLEADO, EMPL.SUCU_TUTO SUCURSAL_TUTORA, ")
			.append("CANL.NOMB_CANL ")
			.append(UtilQuery.fromH2hArchivo(delDia) )
			.append(UtilQuery.innerJoinH2hReg(delDia) )
			.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CNTR_CNTR_USING_ID_CNTR)
			.append("INNER JOIN H2H_CLTE CLTE USING (ID_CLTE)  ")
			.append("INNER JOIN H2H_CAT_PROD PROD  ON PROD.CVE_PROD_OPER = REG.CVE_PROD_OPER  ")
			.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CAT_ESTATUS_EST_ON_REG_ID_ESTATUS_EST_ID_CAT_ESTATUS)
			.append(" INNER JOIN H2H_CAT_CANL CANL ON ARCH.ID_CANL = CANL.ID_CANL ")
			.append(UtilQuery.innerJoinAltaEmp(delDia) );
		 return queryAl.toString();
	}


	/**
	 * Genera la consulta de  Operaciones
	 * @param tresMeses valor que indica si se usa la tablas del dia o las de tres meses a tras
	 * @param consultaOperaciones ConsultaOperaciones
	 * @return String consulta de operaciones 
	 */
	public static String getQueryConsOperaciones(boolean tresMeses, 
			OperationsMonitorQueryRequest consultaOperaciones, 
			Map<String, Object> params){
		final StringBuilder query = new StringBuilder();
		if( UtilVostroDatosExportar.esVostro(consultaOperaciones.getIdProducto()) ) {
			log.info("*****CB_F2 Vostro*****");
			query.append(UtilVostroDatosExportar.generaQueryProductosVostro(tresMeses,consultaOperaciones));
		} else if( UtilOrdenesPagoAtmDatosExportar.esOrdenPago(consultaOperaciones.getIdProducto()) ){
			log.info("*****CB_F2 OP*****");
			query.append(
				OperationsMonitorEntityManagerHelper1Repository.generaQueryProductosOrdenPagoatm(tresMeses, consultaOperaciones.getIdProducto())
			);
		} else {
			log.info("*****MIGAJA  1*****");
//			query.append( UtilQuery.selectRegTabla(tresMeses) )
			query
				.append(tresMeses ? MonitorOperacionesConstants.SELECT_H2H_REG_TRAN_TABLA : MonitorOperacionesConstants.SELECT_H2H_REG_TABLA)
				.append(MonitorOperacionesConstants.REG_ID_REG_CLTE_BUC_REG_CNTA_CARG_NUM_CTA_CARGO)
				.append(MonitorOperacionesConstants.REG_CNTA_ABON_NUN_CTA_ABONO_CVE_PROD_OPER_PROD_DESC_PROD)
				.append(MonitorOperacionesConstants.ARCH_NOMBRE_ARCH_REG_REFE_BE_REFERENCIA_REG_ID_ESTATUS)
				.append(MonitorOperacionesConstants.EST_DESC_ESTATUS_REG_MONT_IMPORTE_CNTR_NUM_CNTR_REG_DIVI_DIVISA)
				.append(MonitorOperacionesConstants.PART_QUERY_SELECT_FECHA_REGISTRO_APLI_PROD)
				.append(" CANL.NOMB_CANL ");
//				.append( MonitorOperacionesConstants.SQL_MON_OPER4 );
			// Realizamos una validacion para la hora de aplicacion
			if( !"Todos".equals( UtilData.toString(consultaOperaciones.getHoraProgramacion())) && consultaOperaciones.getHoraProgramacion() != null) {
		 		query.append(", reg.HORA_APLI ");
		 	}
			query.append(UtilQuery.selTabla(tresMeses) )
				 .append(UtilQuery.innerJoinArchivo(tresMeses) )
				 .append(MonitorOperacionesConstants.INNER_JOIN_H2H_CNTR_CNTR_USING_ID_CNTR)
				 .append(MonitorOperacionesConstants.INNER_JOIN_H2H_CLTE)
				 .append(MonitorOperacionesConstants.PART_QUERY_SELECT_INNER_CAT_PROD)
				 .append(MonitorOperacionesConstants.INNER_JOIN_H2H_CAT_ESTATUS_EST_ON_REG_ID_ESTATUS_EST_ID_CAT_ESTATUS)
				 .append(MonitorOperacionesConstants.INNER_JOIN_H2H_CAT_CANL);
			
			//inicio: si se trata de un producto confirmig y alguno de los parametros incluye informacion
			log.info("*****MIGAJA  REVISA SI ES EL PRODUCTO CONFIRMING*****");
			log.info("*****consultaOperaciones.getCveProveedor()*****"+consultaOperaciones.getCveProveedor());
			log.info("*****consultaOperaciones.getTipOperacion()*****"+consultaOperaciones.getTipOperacion());
			if("11".equals(consultaOperaciones.getIdProducto()) && (consultaOperaciones.getCveProveedor() != null || consultaOperaciones.getTipOperacion() != null) &&
				(!EMPTY.equals(UtilData.toString(consultaOperaciones.getCveProveedor())) && !EMPTY.equals(UtilData.toString( consultaOperaciones.getTipOperacion())) )) {
				log.info("*****AGREGA EL WHERE EN CASO DE SER CONFIRMING Y QUE ALGUNO DE LOS PARAMTROS NO SEA VACIO*****");
				query.append(getcveProveedor(query, consultaOperaciones, params, tresMeses));
			}
		}
		//fin: si se trata de un producto confirmig y alguno de los parametros incluye informacion
		return query.toString();
	}

	/**
	 * Separamos el metodo
	 * 
	 * @param query String SQL
	 * @param consultaOperaciones datos filtro
	 * @param params marametros
	 * @param tresMeses booleano
	 * @return
	 */
	private static String getcveProveedor(StringBuilder querys, OperationsMonitorQueryRequest consultaOperaciones, Map<String, Object> params, boolean tresMeses) {
		final StringBuilder query = new StringBuilder();
		query.append("LEFT JOIN H2H_PROD_MTTO_PROV")
		.append(tresMeses ? "_TRAN " : " ") 
		.append("PCONF ON REG.ID_REG = PCONF.ID_REG  WHERE ");
		 if (!EMPTY.equals(consultaOperaciones.getTipOperacion()) && consultaOperaciones.getTipOperacion() != null) {
			log.info("*****SI NO ES VACIO AGREGA TIPO OPERACION*****");
			query.append("PCONF.CLVE_OPER = ")
				 .append(consultaOperaciones.getTipOperacion())
				 .append(" ");
//			params.put("TipOperacion", consultaOperaciones.getTipOperacion());
		}
		if (!EMPTY.equals(consultaOperaciones.getCveProveedor()) && consultaOperaciones.getCveProveedor() != null) {
			log.info("*****SI NO ES VACIO AGREGA CLAVE DE PROVEEDOR*****");
			if(!EMPTY.equals(consultaOperaciones.getTipOperacion()) && consultaOperaciones.getTipOperacion() != null){
				query.append(" AND ");
			}
			query.append("PCONF.CLVE_PROV LIKE ('%")
			     .append(consultaOperaciones.getCveProveedor())
			     .append("%') ");
//			params.put("clvProveedor", consultaOperaciones.getCveProveedor());
		}
		return query.toString();
	}


	/**
	 * Agrega el where de parametros de consulta.
	 * @param consultaOperaciones DTO de restricciones
	 * @param exportar true para flujo de exportacion
	 * @return String gener el where de la cosnulta
	 */
	public  static String getWhereConsultaOperaciones(
		OperationsMonitorQueryRequest consultaOperaciones, 
		boolean exportar, Map<String, Object> params
	){
		final StringBuilder query = new StringBuilder();
		boolean someFilter =  false;
		if (exportar){
//			someFilter = true;
			query.append("WHERE ");
		}else {
			someFilter = true;
			query.append("WHERE ((PROD.FECHA_REGISTRO >= TO_DATE('")
			.append(consultaOperaciones.getFechaInicial())
			.append(MonitorOperacionesConstants.HORARIOINICIAL)
			.append("', 'DD/MM/YYYY HH24:MI:SS') ")
			.append("AND PROD.FECHA_REGISTRO <= TO_DATE('")
			.append(consultaOperaciones.getFechaFinal())
			.append(MonitorOperacionesConstants.HORARIOFINAL)
			.append("', 'DD/MM/YYYY HH24:MI:SS')) OR (PROD.FECHA_APLICACION >= TO_DATE('")
			.append(consultaOperaciones.getFechaInicial())
			.append(MonitorOperacionesConstants.HORARIOINICIAL)
			.append("', 'DD/MM/YYYY HH24:MI:SS') ")
			.append("AND PROD.FECHA_APLICACION <= TO_DATE('")
			.append(consultaOperaciones.getFechaFinal())
			.append(MonitorOperacionesConstants.HORARIOFINAL).append("'")
			.append(MonitorOperacionesConstants.FORMATO_FECHA);
		}
		
		String qCont = UtilOrdenesPagoAtmDatosExportarNew.getWhereConsultaOperacionesCont(consultaOperaciones, params, someFilter);
		if(qCont != null && !qCont.isEmpty()) {
			query.append(qCont);
			someFilter = true;
		}
		
		//-----------------------------------------------
		query.append(getDivisa(query, params, consultaOperaciones.getDivisa(), someFilter));
//		query.append(getWhereConsOpercion2(consultaOperaciones, query, params, someFilter));
		
//		if (!EMPTY.equals( UtilData.toString(consultaOperaciones.getNumeroOrden())) ) {
		if(!"".equals(consultaOperaciones.getNumeroOrden()) && consultaOperaciones.getNumeroOrden() != null) {
			query.append(UtilMonitorFnc.armaQueryAnd(query, "PROD.NUM_ORDEN = '"+ consultaOperaciones.getNumeroOrden() +"' ", someFilter));
//			params.put("numOrden", consultaOperaciones.getNumeroOrden());
		}
//		if (!EMPTY.equals( UtilData.toString(consultaOperaciones.getNombreBeneficiario())) ) {
		if(!"".equals(consultaOperaciones.getNombreBeneficiario()) && consultaOperaciones.getNombreBeneficiario() != null) {
			query.append(UtilMonitorFnc.armaQueryAnd(query, "UPPER(PROD.BENEFICIARIO)  LIKE ('% UPPER("+ consultaOperaciones.getNombreBeneficiario() +") %' )", someFilter));
//			params.put("beneficiario", consultaOperaciones.getNombreBeneficiario());
		}
//		if (!EMPTY.equals( UtilData.toString(consultaOperaciones.getIdReg())) ) {
		if(!"".equals(consultaOperaciones.getIdReg()) && consultaOperaciones.getIdReg() != null) {
			log.info("Id reg: " + consultaOperaciones.getIdReg());
			query.append(UtilMonitorFnc.armaQueryAnd(query, "PROD.ID_REG = "+ consultaOperaciones.getIdReg() +" ", someFilter));
//			params.put("idReg", consultaOperaciones.getIdReg());
		}
//		if (!EMPTY.equals(UtilData.toString(consultaOperaciones.getNumEmpleado()) ) 
		if((!"".equals(consultaOperaciones.getNumEmpleado()) && consultaOperaciones.getNumEmpleado() != null)
			&& !MonitorOperacionesConstants.PROD_PROV_CONFIRMING.equals(consultaOperaciones.getIdProducto()) ) {
			query.append(UtilMonitorFnc.armaQueryAnd(query, "PROD.NUMERO_EMPLEADO = '"+ consultaOperaciones.getNumEmpleado() +"' ", someFilter));
//			params.put("numEmpleado", consultaOperaciones.getNumEmpleado());
		}
//		if (!EMPTY.equals( UtilData.toString(consultaOperaciones.getNumTarjeta()) )
		if((!"".equals(consultaOperaciones.getNumTarjeta()) && consultaOperaciones.getNumTarjeta() != null)
				&& !MonitorOperacionesConstants.PROD_PROV_CONFIRMING.equals( UtilData.toString(consultaOperaciones.getIdProducto())) ) {
			query.append(UtilMonitorFnc.armaQueryAnd(query, "PROD.NUMERO_TARJETA = '"+ consultaOperaciones.getNumTarjeta() +"' ", someFilter));
//			params.put("numTarjeta", consultaOperaciones.getNumTarjeta());
		}
//		if (!EMPTY.equals( UtilData.toString(consultaOperaciones.getSucTutora()) ) 
		if((!"".equals(consultaOperaciones.getSucTutora()) && consultaOperaciones.getSucTutora() != null)
				&& !MonitorOperacionesConstants.PROD_PROV_CONFIRMING.equals( UtilData.toString(consultaOperaciones.getIdProducto())) ) {
			query.append(UtilMonitorFnc.armaQueryAnd(query, "PROD.SUCURSAL_TUTORA = "+ consultaOperaciones.getSucTutora() +" ", someFilter));
//			params.put("sucursalTutora", consultaOperaciones.getSucTutora());
		}
		
		
		
		if (!EMPTY.equals( UtilData.toString(consultaOperaciones.getTipo())) 
			&& !MonitorOperacionesConstants.CERO.equals( UtilData.toString(consultaOperaciones.getTipo())) ) {
			if ("PREEXISTENTE".equals( UtilData.toString(consultaOperaciones.getTipo())) ){
				query.append(UtilMonitorFnc.armaQueryAnd(query, "PROD.TIPO IS NOT NULL ", someFilter));
			} else {
				query.append(UtilMonitorFnc.armaQueryAnd(query, "PROD.TIPO IS NULL ", someFilter));
			}
			someFilter = true;
		}
		
		query.append(getPif(consultaOperaciones, query, params, exportar));
		
		if(consultaOperaciones.isEsLiquidaciones()) {
			query.append(" AND PROD.CVE_PROD_OPER in(21,23) ");
		}
		
		if(!"Todos".equals(consultaOperaciones.getHoraProgramacion()) && consultaOperaciones.getHoraProgramacion() != null && !consultaOperaciones.getHoraProgramacion().equals("")) {
			query
			.append("AND to_char(prod.HORA_APLI,'HH24:MI') = '")
			.append(consultaOperaciones.getHoraProgramacion())
			.append("' ");
		}
		
		if (exportar && !someFilter){
			return EMPTY;
		}
		return query.toString();
	}
	
	
	/**
	 * Metodo para obtener los datos del PIF
	 * 
	 * @param consultaOperaciones
	 * @param query
	 * @param params
	 */
	public static String getPif(OperationsMonitorQueryRequest consultaOperaciones, 
			final StringBuilder query, Map<String, Object> params, boolean exportar) {
		StringBuilder qryPif = new StringBuilder();
		//Esta parte es de PIF
		if(UtilData.isPif( consultaOperaciones.getIdProducto() )){
			if(UtilData.getLen(consultaOperaciones.getLineaCaptura()) >0  && consultaOperaciones.getLineaCaptura() != null){
				qryPif.append(" AND PROD.OBSE_ABO like ('").append(consultaOperaciones.getLineaCaptura()).append("%') ");
//				params.put("observacionABO", consultaOperaciones.getLineaCaptura());
			}
			if(UtilData.getLen(consultaOperaciones.getConvenio())>0 && consultaOperaciones.getConvenio() != null){
				if(exportar) {
					qryPif.append(" AND PROD.COMENTARIO_1 = '").append(consultaOperaciones.getConvenio()).append("' ");
				}else {
					qryPif.append(" AND PROD.CLVE_CONV = '").append(consultaOperaciones.getConvenio()).append("' ");
				}
//				params.put("clveConv", consultaOperaciones.getConvenio());
			}
			if("23".equals(consultaOperaciones.getIdProducto())) {
				if(UtilData.getLen(consultaOperaciones.getFolioSUA()) > 0 && consultaOperaciones.getFolioSUA() != null){
					String qrys = exportar ? " AND PROD.COMENTARIO_3 like '" + consultaOperaciones.getFolioSUA() + "%'" :
							" AND PROD.NUME_FOLI_SUA like '" + consultaOperaciones.getFolioSUA() + "%'";
					qryPif.append(qrys);
//					if(exportar) {
//						query.append(" AND PROD.COMENTARIO_3 like '").append(consultaOperaciones.getFolioSUA()).append("%'");
//					}else {
//						query.append(" AND PROD.NUME_FOLI_SUA like '").append(consultaOperaciones.getFolioSUA()).append("%'");
//					}
//					params.put("folioUSA", consultaOperaciones.getFolioSUA());
				}
				if(UtilData.getLen(consultaOperaciones.getRegPat()) > 0 && consultaOperaciones.getRegPat() != null){
					String qry = exportar ? " AND UPPER(PROD.COMENTARIO_2) like UPPER('" + consultaOperaciones.getRegPat() + "%') " : 
						" AND UPPER(PROD.REG_PATR) like UPPER('" + consultaOperaciones.getRegPat() + "%') ";
					qryPif.append(qry);
//					if(exportar) {
//						query.append(" AND UPPER(PROD.COMENTARIO_2) like UPPER('").append(consultaOperaciones.getRegPat()).append("%') ");
//					}else {
//						query.append(" AND UPPER(PROD.REG_PATR) like UPPER('").append(consultaOperaciones.getRegPat()).append("%') ");
//					}
//					params.put("regPat", consultaOperaciones.getRegPat());
				}
			}
		}
		return qryPif.toString();
	}
	
	
	/**
	 * Metodo para determinar la Divisa
	 * 
	 * @param query QuerySql
	 * @param params Parametros
	 * @param divisa Tipo Divisa
	 * @param filtro Bandera de Filtro
	 */
	public static String getDivisa(StringBuilder querys, Map<String, Object> params, String divisa, boolean filtro) {
		StringBuilder queryD = new StringBuilder();
//		if (!EMPTY.equals( UtilData.toString(divisa))
		if(divisa != null && !MonitorOperacionesConstants.CERO.equals( UtilData.toString(divisa)) ) {
			if (MonitorOperacionesConstants.MXP.equals( UtilData.toString(divisa)) ) {
				queryD.append(filtro ? "AND (PROD.DIVISA = '" : "(PROD.DIVISA = '").append(MonitorOperacionesConstants.MXP).append("' OR PROD.DIVISA = '").append(MonitorOperacionesConstants.MN).append("') ");
//				UtilMonitorFnc.armaQueryAnd(query, "(PROD.DIVISA = :divisa1 ", filtro);
//				query.append("OR PROD.DIVISA = :divisa2) ");
//				params.put("divisa1", MonitorOperacionesConstants.MXP);
//				params.put("divisa2", MonitorOperacionesConstants.MN );
			} else {
				if (MonitorOperacionesConstants.USD.equals( UtilData.toString(divisa)) ) {
					queryD.append(filtro ? "AND (PROD.DIVISA = '" : "(PROD.DIVISA = '").append(MonitorOperacionesConstants.USD).append("' OR PROD.DIVISA = '").append(MonitorOperacionesConstants.DL).append("') ");
//					UtilMonitorFnc.armaQueryAnd(queryD, "(PROD.DIVISA = :divisa1 ", filtro);
//					queryD.append("OR PROD.DIVISA = :divisa2) ");
//					params.put("divisa1", MonitorOperacionesConstants.USD);
//					params.put("divisa2", MonitorOperacionesConstants.DL );
				} else {
					queryD.append(filtro ? "AND PROD.DIVISA = '" : "PROD.DIVISA = '").append(divisa).append("' ");
//					UtilMonitorFnc.armaQueryAnd(queryD, "PROD.DIVISA = :divisa ", filtro);
//					params.put("divisa", divisa);
				}
			}
			filtro = true;
		}
		return queryD.toString();
	}
	
	
	/**
	 * Metodo de Consulta de datos Parte2
	 * 
	 * @param consultaOperaciones Bean
	 * @param query QuerySql
	 * @param params Parametros
	 * @param divisa Divisa
	 * @param filtro Filtros
	 */
	public static String getWhereConsOpercion2(OperationsMonitorQueryRequest consultaOperaciones, StringBuilder query, Map<String, Object> params, boolean filtro) {
		log.info("Entro getWhereConsOpercion2");
		StringBuilder queryCn = new StringBuilder();
//		if (!EMPTY.equals( UtilData.toString(consultaOperaciones.getNumeroOrden())) ) {
		if(!"".equals(consultaOperaciones.getNumeroOrden()) && consultaOperaciones.getNumeroOrden() != null) {
			UtilMonitorFnc.armaQueryAnd(queryCn, "PROD.NUM_ORDEN = :numOrden ", filtro);
			params.put("numOrden", consultaOperaciones.getNumeroOrden());
		}
//		if (!EMPTY.equals( UtilData.toString(consultaOperaciones.getNombreBeneficiario())) ) {
		if(!"".equals(consultaOperaciones.getNombreBeneficiario()) && consultaOperaciones.getNombreBeneficiario() != null) {
			UtilMonitorFnc.armaQueryAnd(queryCn, "UPPER(PROD.BENEFICIARIO)  LIKE ('%'|| upper(:beneficiario) || '%' )", filtro);
			params.put("beneficiario", consultaOperaciones.getNombreBeneficiario());
		}
//		if (!EMPTY.equals( UtilData.toString(consultaOperaciones.getIdReg())) ) {
		log.info("Id registro: " + consultaOperaciones.getIdReg());
		if(!"".equals(consultaOperaciones.getIdReg()) && consultaOperaciones.getIdReg() != null) {
			log.info("Entro al filtro de ID_REG");
			UtilMonitorFnc.armaQueryAnd(queryCn, "PROD.ID_REG = :idReg ", filtro);
			params.put("idReg", consultaOperaciones.getIdReg());
		}
//		if (!EMPTY.equals(UtilData.toString(consultaOperaciones.getNumEmpleado()) ) 
		if((!"".equals(consultaOperaciones.getNumEmpleado()) && consultaOperaciones.getNumEmpleado() != null)
			&& !MonitorOperacionesConstants.PROD_PROV_CONFIRMING.equals(consultaOperaciones.getIdProducto()) ) {
			UtilMonitorFnc.armaQueryAnd(queryCn, "PROD.NUMERO_EMPLEADO = :numEmpleado ", filtro);
			params.put("numEmpleado", consultaOperaciones.getNumEmpleado());
		}
//		if (!EMPTY.equals( UtilData.toString(consultaOperaciones.getNumTarjeta()) )
		if((!"".equals(consultaOperaciones.getNumTarjeta()) && consultaOperaciones.getNumTarjeta() != null)
				&& !MonitorOperacionesConstants.PROD_PROV_CONFIRMING.equals( UtilData.toString(consultaOperaciones.getIdProducto())) ) {
			UtilMonitorFnc.armaQueryAnd(queryCn, "PROD.NUMERO_TARJETA = :numTarjeta ", filtro);
			params.put("numTarjeta", consultaOperaciones.getNumTarjeta());
		}
//		if (!EMPTY.equals( UtilData.toString(consultaOperaciones.getSucTutora()) ) 
		if((!"".equals(consultaOperaciones.getSucTutora()) && consultaOperaciones.getSucTutora() != null)
				&& !MonitorOperacionesConstants.PROD_PROV_CONFIRMING.equals( UtilData.toString(consultaOperaciones.getIdProducto())) ) {
			UtilMonitorFnc.armaQueryAnd(queryCn, "PROD.SUCURSAL_TUTORA = :sucursalTutora ", filtro);
			params.put("sucursalTutora", consultaOperaciones.getSucTutora());
		}
		log.info("Termino getWhereConsOpercion2" + params.get(0));
		return queryCn.toString();
	}
	
}
