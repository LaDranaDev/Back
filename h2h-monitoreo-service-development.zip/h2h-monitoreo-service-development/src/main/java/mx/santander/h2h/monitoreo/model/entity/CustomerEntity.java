package mx.santander.h2h.monitoreo.model.entity;

import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * Entidad para la tabla H2H_CLTE.
 *
 * @author Jesus Soto Aguilar
 * @since 13/04/2023
 */
@Entity
@Getter
@Setter
@Table(name = "H2H_CLTE")
public class CustomerEntity implements Serializable {
	/**
	 * Serial.
	 */
	private static final long serialVersionUID = -3136508607927858865L;
	/**
	 * Identificador del cliente
	 */
	@Id
	@Column(name = "ID_CLTE")
	private Long idCliente;
	/**
	 * Razon social del cliente
	 */
	@Column(name = "RAZON_SCIA")
	private String razonSocial;
	/**
	 * Nombre del cliente
	 */
	private String nombre;
	/**
	 * Apellido Materno del cliente
	 */
	@Column(name = "APMATERNO")
	private String apMaterno;
	/**
	 * Apellido Paterno del cliente
	 */
	@Column(name = "APPATERNO")
	private String apPaterno;
	/**
	 * Codigo del cliente
	 */
	private String buc;
	/**
	 * Condicion del cliente: cliente, ex-cliente o anticliente
	 */
	@Column(name = "COND_CLTE")
	private String condicion;
	/**
	 * Nombre del ejecutivo
	 */
	private String ejecutivo;
	/**
	 * Se refiere a la fecha de nacimiento o de la constitucion de la empresa
	 */
	@Column(name = "fecha")
	private LocalDate fecha;
	/**
	 * Segmento al que pertenece el cliente
	 */
	@Column(name = "ID_SGMTO")
	private Integer idSegmento;
	/**
	 * Personalidad del cliente: M persona moral - F persona fisica
	 */
	private String personalidad;
	/**
	 * RFC del cliente
	 */
	private String rfc;
	/**
	 * Nemonico
	 */
	private String nemonico;
}
