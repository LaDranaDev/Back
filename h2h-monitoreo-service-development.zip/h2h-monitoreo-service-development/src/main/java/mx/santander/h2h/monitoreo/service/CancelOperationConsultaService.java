package mx.santander.h2h.monitoreo.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.response.CancelOperationResponse;
import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import mx.santander.h2h.monitoreo.repository.ICatalogoEstatusRepository;
import mx.santander.h2h.monitoreo.repository.IContractRepository;
import mx.santander.h2h.monitoreo.repository.IParameterRepository;
/**
 * CancelOperationConsultaService 27/06/2024
 * Clase que implementa la interfaz de ICancelOperationService Creando los
 * metodos necesarios para hacer la consultas necesarias tales como los combos
 * de estatus centro, comobo de estatus cancelado buscar una operacion por buc,
 * buscar un archivo y cancelar una operacion
 * 
 * @version 1.1
 * @author NTTDATA-NRL
 */
@Service
public class CancelOperationConsultaService implements ICancelOperationConsultaService{
	/**
	 * Varaible para implementar el repositorio de parametros
	 */
	@Autowired
	public IParameterRepository parameterRepository;
	/**
	 * Varaible para implementar el repositorio de Catalogos
	 */
	@Autowired
	private ICatalogoEstatusRepository catalogoEstatusRepository;
	/**
	 * Varaible para implementar el repositorio de contratos
	 */
	@Autowired
	private IContractRepository contractRepository;
	
    /**Cero*/
    private static final String VALOR_VACIO = "";
    /**0*/
    public static final String VALOR_CERO = "0";
	/**
	 * (non-Javadoc) Método de cargador de clases estándar para cargar una clase y
	 * resolverla.
	 * 
	 * @see ICancelOperationService#consultaCancel(String)
	 */
	@Override
	public CancelOperationResponse consultaCancel(String bucCliente) {

		if (bucCliente.equals(VALOR_VACIO) || bucCliente.equals(VALOR_CERO)) {
			throw new BusinessException("403", "Buc no informado o nulo");
		}

		String tipoEstatus = this.parameterRepository.findByName("TIPO_ESTATUS_CNTR").getValue();
		String descripcionEstatus = this.parameterRepository.findByName("ESTATUS_CANCEL_CNTR").getValue();
		List<ComboResponse> listaComboEstatus = obtenerCatalogoEstatus(tipoEstatus, descripcionEstatus);

		int idEstatus = listaComboEstatus.get(0).getId();
		List<Object[]> resultQueryCntr = contractRepository.findCntrByBUCAndEstatus(bucCliente, idEstatus);
		String contractNumber = "";

		if (resultQueryCntr != null) {
			for (Object[] map : resultQueryCntr) {
				contractNumber = (String) map[9];
			}
		}

		// respuesta general del servicio
		CancelOperationResponse resp = new CancelOperationResponse();

		resp.setReadOnly("disabled='disabled'");
		resp.setMuestraBusqueda(VALOR_CERO);
		resp.setHdnContratoFolio(contractNumber);

		return resp;
	}

	/**
	 * Metodo para obtener los catalogos por estatis y descripcion
	 * 
	 * @param tipoEstat
	 * @param descEstat
	 * @return List<ComboResponse>
	 */
	private List<ComboResponse> obtenerCatalogoEstatus(String tipoEstat, String descEstat) {

		List<ComboResponse> listaCombo = new ArrayList<ComboResponse>();
		List<Object[]> resultQueryCatalogos = catalogoEstatusRepository.obtenerCatalogoEstatusCancelado(tipoEstat,
				descEstat);

		if (resultQueryCatalogos != null) {
			for (Object[] map : resultQueryCatalogos) {
				ComboResponse bean = new ComboResponse();
				bean.setId(((BigDecimal) map[0]).intValue());
				bean.setValor((String) map[1]);
				listaCombo.add(bean);
			}
		}

		return listaCombo;
	}
}