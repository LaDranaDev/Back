package mx.santander.h2h.monitoreo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import mx.isban.h2h.comprobantefiscal.BeanDatosOperMasiva;
import mx.isban.h2h.comprobantefiscal.ConsultaInfoConcepto;
import mx.isban.h2h.comprobantefiscal.ConsultaInfoConceptoResponse;
import mx.isban.h2h.comprobantefiscal.GeneraComprobante;
import mx.isban.h2h.comprobantefiscal.GeneraComprobanteResponse;
import mx.isban.h2h.comprobantefiscal.RegistraMovimiento;
import mx.isban.h2h.comprobantefiscal.RegistraMovimientoResponse;
import mx.isban.h2h.comprobantefiscal.ValidaComprobante;
import mx.isban.h2h.comprobantefiscal.ValidaComprobanteResponse;
import mx.santander.h2h.monitoreo.constants.ApiConstants;
import mx.santander.h2h.monitoreo.constants.ReportConstants;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.response.CampoAdicionalBean;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersDtoResponse;
import mx.santander.h2h.monitoreo.model.response.VoucherRequestDto;
import mx.santander.h2h.monitoreo.repository.IComprobanteSelloDigitalRepository;
import mx.santander.h2h.monitoreo.repository.IDatosAdicionalesEntityManagerRepository;
import mx.santander.h2h.monitoreo.repository.IGenerateVouchersEntityManagerRepository;
import mx.santander.h2h.monitoreo.util.DatosAdicionalesUtils;
import mx.santander.h2h.monitoreo.util.GenerateVouchersImplUtils;
import mx.santander.h2h.monitoreo.util.UtilsTramaAdicionalesAux;

/**
 * Clase que define la logica de las operaciones de exportacion de comprobante
 * formato CDMX
 * 
 * @author Omar Rosas
 * @since 19/10/2023
 */
@Service
@Slf4j
public class GenerateVouchersExportImplService implements IGenerateVouchersExportService {
	@Autowired
	private IGenerateVouchersEntityManagerRepository iGenerateVouchersEntityManagerRepository;
	@Autowired
	private IDatosAdicionalesEntityManagerRepository iDatosAdicionalesEntityManagerRepository;
	@Autowired
	private IComprobanteSelloDigitalRepository comprobante;

	@Override
	public ReportResponse exportarOperacionesPdf(VoucherRequestDto voucherRequestDto) {
		ReportResponse reponse = new ReportResponse();
		GenerateVouchersDtoResponse vouchersDtoResponse = new GenerateVouchersDtoResponse();

		/** Se genera la peticion inicial */
		try {
			/** Se inicializa el comprobante fiscal */
			ValidaComprobanteResponse responseComprobante = initComprobanteFiscal(voucherRequestDto);

			if (Integer.parseInt(responseComprobante.getReturn().getCodRespuesta()) == 1) {
				/** Se ejecuta el metodo para armado de comprobantes */
				vouchersDtoResponse = armaComprobantes(voucherRequestDto, responseComprobante);
			} else {
				/** Se estbalece el base64 */
				vouchersDtoResponse.getCdmxBean().setBase64(responseComprobante.getReturn().getCompSelloDigital());
			}
			reponse.setData(vouchersDtoResponse.getCdmxBean().getBase64());
			reponse.setLength(vouchersDtoResponse.getCdmxBean().getBase64().length());
			reponse.setName("Comprobante CDMX " + GenerateVouchersImplUtils.generarFecha() + ".pdf");
			reponse.setType(ReportConstants.PDF_EXTENTION);

			return reponse;

		} catch (BusinessException ex) {
			log.error("Error de negocio al general el comprobante: " + ex.getMessage() + " - " + ex.getCause());
			throw new BusinessException(ex.getCode(), ex.getMessage());
		}
	}

	/**
	 * Metodo que inicia la invocacion al servicio soap que obtiene el comprobante
	 * de formatos cdmx
	 * 
	 * @param voucherRequestDto Datos para generar el comprobante
	 * @return Datos de respuesta de la validacion del comprobante
	 */
	private ValidaComprobanteResponse initComprobanteFiscal(final VoucherRequestDto voucherRequestDto) {
		/** Se recuperan los datos requeridos del comprobante formato cdmx */
		GenerateVouchersDtoResponse responseDAO = iGenerateVouchersEntityManagerRepository
				.recuperarParamsGenComprobante();

		Integer idCanal = Integer.parseInt(responseDAO.getParametrosAdicionalesComprobante().get(1));
		String numCta = responseDAO.getParametrosAdicionalesComprobante().get(0);
		String url = responseDAO.getParametrosAdicionalesComprobante().get(2);

		// Se invoca la operacion de Consulta Info Concepto
		ConsultaInfoConcepto consultaReq = new ConsultaInfoConcepto();
		consultaReq.setIdCanal(idCanal);
		consultaReq.setLinCap(voucherRequestDto.getLineaCaptura());
		consultaReq.setNumCta(numCta);

		ConsultaInfoConceptoResponse consultaRes = comprobante.consultaInfoConcepto(consultaReq, url);

		if (!consultaRes.getReturn().getCodError().equals(ApiConstants.CODE_RES_WS_COMPROBANTE)) {
			throw new BusinessException(consultaRes.getReturn().getCodError(), consultaRes.getReturn().getMsgError());
		}

		// Se invoca la operacion de Registro de Movimientos
		RegistraMovimiento registroReq = new RegistraMovimiento();

		BeanDatosOperMasiva bean = new BeanDatosOperMasiva();
		bean.setFecha(voucherRequestDto.getFecha());
		bean.setIdCanal(idCanal);
		bean.setImporte(voucherRequestDto.getImporte());
		bean.setLineaCaptura(voucherRequestDto.getLineaCaptura());
		bean.setNumCuenta(numCta);
		bean.setReferencia(voucherRequestDto.getReferencia());
		registroReq.getMovimientos().add(bean);

		RegistraMovimientoResponse registroRes = comprobante.registraMovimiento(registroReq, url);

		if (!consultaRes.getReturn().getCodError().equals(ApiConstants.CODE_RES_WS_COMPROBANTE)) {
			throw new BusinessException(registroRes.getReturn().getCodError(), registroRes.getReturn().getMsgError());
		}

		// Se invoca la operacion de Validacion del comprobante
		ValidaComprobante validacionReq = new ValidaComprobante();
		validacionReq.setFec(voucherRequestDto.getFecha());
		validacionReq.setIdCanal(idCanal);
		validacionReq.setImp(voucherRequestDto.getImporte());
		validacionReq.setLinCap(voucherRequestDto.getLineaCaptura());
		validacionReq.setNumCuenta(numCta);
		validacionReq.setRef(voucherRequestDto.getReferencia());

		ValidaComprobanteResponse validacionRes = comprobante.validaComprobante(validacionReq, url);

		if (!validacionRes.getReturn().getCodError().equals(ApiConstants.CODE_RES_WS_COMPROBANTE)) {
			throw new BusinessException(validacionRes.getReturn().getCodError(),
					validacionRes.getReturn().getMsgError());
		}

		return validacionRes;
	}

	/**
	 * Metodo que arma el comprobante de formatos cdmx
	 * 
	 * @param voucherRequestDto   Datos para generar el comprobante
	 * @param responseComprobante Datos de respuesta de la validacion del
	 *                            comprobante
	 * @return Datos de respuesta del comprobante de formato cdmx
	 */
	private GenerateVouchersDtoResponse armaComprobantes(VoucherRequestDto voucherRequestDto,
			ValidaComprobanteResponse comprobanteResponse) {
		GenerateVouchersDtoResponse vouchersDtoResponse = new GenerateVouchersDtoResponse();
		vouchersDtoResponse.setCdmxBean(voucherRequestDto);
		String datosRefe;
		String datosRefeTran;
		boolean refeValido;
		boolean refeTranValido;

		/** Se validan datos adicionales en refe */
		if (DatosAdicionalesUtils.adicionalesRequeridos(voucherRequestDto.getTramaAdicionalesEntrada(),
				comprobanteResponse.getReturn().getNumCampAdicionales())) {
			List<CampoAdicionalBean> cpAdicionales = new ArrayList<>();
			String[] primeraDivision = comprobanteResponse.getReturn().getCampAdicionales().split(Pattern.quote("||"));
			for (int i = 1; i <= comprobanteResponse.getReturn().getNumCampAdicionales(); i++) {
				String[] segundaDivision = primeraDivision[i].split(Pattern.quote("|"));
				String[] values = voucherRequestDto.getTramaAdicionalesEntrada().split(Pattern.quote("|"));
				CampoAdicionalBean bean = new CampoAdicionalBean();
				bean.setCampo(segundaDivision[0]);
				bean.setValue(values[i - 1]);
				cpAdicionales.add(bean);
			}

			/** Se genera el comprobante */
			procesoGeneracionComprobante(voucherRequestDto, vouchersDtoResponse, cpAdicionales, comprobanteResponse);

			/** se actualizan los datos adicionales */
			if (DatosAdicionalesUtils.actualizacionBDRequerida(vouchersDtoResponse.getCdmxBean().getBase64(),
					comprobanteResponse.getReturn().getNumCampAdicionales())) {
				iDatosAdicionalesEntityManagerRepository.actualizaPagoRefe(voucherRequestDto);
				iDatosAdicionalesEntityManagerRepository.actualizaPagoRefeTran(voucherRequestDto);
			}
		} else {
			GenerateVouchersDtoResponse pagoRefe = new GenerateVouchersDtoResponse();

			/** Se consultan datos adicionales */
			pagoRefe = iDatosAdicionalesEntityManagerRepository.existeEnPagoRefe(voucherRequestDto);
			datosRefe = pagoRefe.getCdmxBean().getTramaAdicionalesEntrada();
			refeValido = DatosAdicionalesUtils.validaTramaAdicionales(pagoRefe);

			/** Se consultan datos adicionales */
			pagoRefe = iDatosAdicionalesEntityManagerRepository.existeEnPagoRefeTran(voucherRequestDto);
			datosRefeTran = pagoRefe.getCdmxBean().getTramaAdicionalesEntrada();
			refeTranValido = DatosAdicionalesUtils.validaTramaAdicionales(pagoRefe);

			if (refeValido) {
				/** Se genera el comprobante */
				procesoGeneracionComprobante(voucherRequestDto, vouchersDtoResponse,
						UtilsTramaAdicionalesAux.generarListaCPA(datosRefe), comprobanteResponse);
				/** Se validan datos adicionales en refetran */
			} else if (refeTranValido) {
				/** Se genera el comprobante */
				procesoGeneracionComprobante(voucherRequestDto, vouchersDtoResponse,
						UtilsTramaAdicionalesAux.generarListaCPA(datosRefeTran), comprobanteResponse);
			}
		}
		return vouchersDtoResponse;
	}

	/**
	 * Metodo que ejecuta la operacion de generacion del comprobante
	 * 
	 * @param voucherRequestDto   Datos para generar el comprobante
	 * @param vouchersDtoResponse Datos de respuesta de la generacion del
	 *                            comprobante
	 * @param cpAdicionales       Lista de datos adicionales
	 * @param comprobanteResponse Datos de la validacion del comprobante
	 */
	private void procesoGeneracionComprobante(VoucherRequestDto voucherRequestDto,
			GenerateVouchersDtoResponse vouchersDtoResponse, List<CampoAdicionalBean> cpAdicionales,
			ValidaComprobanteResponse comprobanteResponse) {
		GeneraComprobante request = new GeneraComprobante();

		/** Se recuperan los datos requeridos del comprobante formato cdmx */
		GenerateVouchersDtoResponse responseDAO = iGenerateVouchersEntityManagerRepository
				.recuperarParamsGenComprobante();

		Integer idCanal = Integer.parseInt(responseDAO.getParametrosAdicionalesComprobante().get(1));
		String numCta = responseDAO.getParametrosAdicionalesComprobante().get(0);
		String url = responseDAO.getParametrosAdicionalesComprobante().get(2);

		request.setLinCap(voucherRequestDto.getLineaCaptura());
		request.setImp(voucherRequestDto.getImporte());
		request.setRef(voucherRequestDto.getReferencia());
		request.setFec(voucherRequestDto.getFecha());
		request.setIdCanal(idCanal);
		request.setNumCta(numCta);
		request.setNombre(ApiConstants.EMPTY_STRING);
		request.setDomicilio(ApiConstants.EMPTY_STRING);
		request.setColonia(ApiConstants.EMPTY_STRING);
		request.setCp(ApiConstants.EMPTY_STRING);
		request.setDelegacion(ApiConstants.EMPTY_STRING);
		request.setEstado(ApiConstants.EMPTY_STRING);
		request.setCamposAdicionales(UtilsTramaAdicionalesAux.getTramaCamposAdicionales(cpAdicionales));

		/** Se ejecuta el paso 4 */
		GeneraComprobanteResponse response = comprobante.generaComprobante(request, url);
		/** Se valida la respuesta del WS */
		if (ApiConstants.CODE_RES_WS_COMPROBANTE.equals(response.getReturn().getCodError())) {
			vouchersDtoResponse.getCdmxBean().setBase64(response.getReturn().getCompSelloDigital());
		} else {
			throw new BusinessException(response.getReturn().getCodError(), response.getReturn().getMsgError());
		}
	}
}
