/**
 * DTO para consulta comprobantes formato CDMX
 * DTO respuesta para el front
 */
package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author sbautish
 *
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class GenerateVouchersControllerResponse implements Serializable {

	/**
	 * ID de version de serie
	 */
	private static final long serialVersionUID = 5104092915003191247L;

	Map<String, Object> parametros;

	/**
	 * Atributo que representa la variable listaOperaciones del tipo
	 * ArrayList<RespuestaMonitorOperacionesDTO>
	 */
	private List<OperationsMonitorQueryResponse> listaOperaciones;

	/** Atributo que representa la variable totalOperaciones del tipo String */
	private String totalOperaciones;

	/** Atributo que representa el tamaño de total de operaciones */
	private String listaSize;

	/** Atributo que representa el límite de registros para exportar */
	private Integer limiteRegistrosExportar;

	/** Atributo que representa el total de páginas */
	private Integer totalPaginas;

	/** Bandera que representa validación de cálculo operaciones */
	private Boolean realizaCalculo;

	/** Inicio de paginación */
	private Integer inicio;

	/** Fin de paginación */
	private Integer fin;

}
