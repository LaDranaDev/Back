/**
* Santander SCIB - Banco Santander Negocios Globales
* Todos los derechos reservados
* NivelOperacionRequest.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <20 nov 2024 09:14:21>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.model.request;

import java.io.Serializable;

import jakarta.validation.constraints.Pattern;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NivelOperacionRequest implements Serializable {
	
	/** Declaracion de Constante serialVersionUID. */
	private static final long serialVersionUID = -8452732325434361311L;
	
	/** Declaracion de Integer para idArchivo. */
	private Integer idArchivo;
	
	/** Declaracion de Integer para idProducto. */
	private Integer idProducto;
	
	/** Declaracion de String para codCliente. */
	@Pattern(regexp = "(^[a-zA-Z0-9 _-]+$)?", message = "Datos de Cliente no valido")
	private String codCliente;
	
	/** Declaracion de String para nomCliente. */
	@Pattern(regexp = "(^[0-9A-Za-zñÑáéíóúÁÉÍÓÚ_. - ]+$)?", message = "Datos no validos")
	private String nomCliente;
	
	/** Declaracion de Integer para idEstatus. */
	private Integer idEstatus;

}
