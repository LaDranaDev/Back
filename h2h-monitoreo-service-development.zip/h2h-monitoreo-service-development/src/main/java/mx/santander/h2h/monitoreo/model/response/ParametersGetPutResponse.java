package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Dto para los datos de salida de los parametro de PUT/GET
 * 
 * @author Z483900
 *
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ParametersGetPutResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2470160511473404029L;

	/**
	 * Variable que almacena identificador del parametro
	 */
	private String idParametro;

	/**
	 * Variable que almacena nombre del parametro
	 */
	private String nombreParametro;

	/**
	 * Variable que almacena valor del parametro
	 */
	private String valorParametro;

	/**
	 * Variable que almacena identificador del parametro
	 */
	private String id;

	/**
	 * Identificador del Protocolo al que se encuentra asociado el Parametro
	 */
	private String idProtocolo;

	/**
	 * Nombre del protocolo
	 */
	private String nombreProtocolo;

	/**
	 * Identificador del valor almacenado para el parametro
	 */
	private String idValorParametro;

	/**
	 * Variable que almacena identificador del parametro configurado
	 */
	private String idContrato;

	/**
	 * Variable que almacena si el campo es obligatorio
	 * para el parametro configurado
	 */
	private String obliParametro;

	/**
	 * Variable que almacena si el campo es editable
	 * para el parametro configurado
	 */
	private String editParametro;

	/**
	 * Variable que almacena el tipo de dato para 
	 * el parametro configurado
	 */
	private String tipoDatoParametro;

	/**
	 * Variable que almacena el longitud del dato para 
	 * el parametro configurado
	 */
	private String longParametro;

	/**
	 * Tipo de procesamiento
	 */
	private String tipoProcesamiento;

	/**
	 * Identificador del canal al cual esta asignado
	 */
	private Integer idCanal;

	/**
	 * Numeroo de registro al que pertenece el valor del parametro
	 */
	private Integer numeroRegistro;

	/**
	 * Estado del valor del parametro, Activo o Inactivo
	 */
	private String estadoValor;

}
