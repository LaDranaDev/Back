package mx.santander.h2h.monitoreo.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.model.request.ArchivoCancelRequest;
import mx.santander.h2h.monitoreo.model.response.ArchivoCancelResponse;
import mx.santander.h2h.monitoreo.model.response.CancelOperationUpdResponse;

/**
 * Interfas con las servcios disponibles
 * @author NTTDATA-NRL
 * @version 1.0
 */
public interface ICancelOperationService {


    /**
     * Función para hacer la busqueda de archivos por buc, nombre archivo o estatus
     * @param request Request
     * @param page pagina
     * @return Page<ArchivoCancelResponse>
     */
    Page<ArchivoCancelResponse> searchArchive(ArchivoCancelRequest request, Pageable page);

    /**
     * Función apra cancelar la operacion, recibe un reistro o varios
     * @param idRegistros id registro
     * @param requestBody requestbody
     * @return CancelOperationUpdResponse
     */
    CancelOperationUpdResponse cancelOperacion(String idRegistros, ArchivoCancelRequest requestBody);


}
