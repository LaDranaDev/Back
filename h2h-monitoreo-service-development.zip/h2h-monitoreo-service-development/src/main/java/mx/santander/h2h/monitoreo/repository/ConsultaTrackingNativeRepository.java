/**
* Santander SCIB - Banco Santander Negocios Globales
* Todos los derechos reservados
* ConsultaTrackingNativeRepository.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <16 jul. 2024 13:45:09>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import mx.santander.h2h.monitoreo.model.response.ArchivoGeneralResponse;
import mx.santander.h2h.monitoreo.model.response.ArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ResultTrackingResponse;
import mx.santander.h2h.monitoreo.model.response.SubtotalResponse;
import mx.santander.h2h.monitoreo.util.UtilData;

@Repository
public class ConsultaTrackingNativeRepository implements IConsultaTrackingNativeRepository {
	@Autowired
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public ArchivoGeneralResponse obtenerDetalleArchivosGeneral(Pageable page, String fecha, String codCliente) {
		ArchivoGeneralResponse archivoGeneral = new ArchivoGeneralResponse();
		List<ArchivoResponse> lista = new ArrayList<ArchivoResponse>();
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder = queryObtenerDetalleArchivos(codCliente);
		
		Query query = entityManager.createNativeQuery(queryBuilder.toString());
		setParamsObtenerDetalleArchivos(codCliente, fecha, query);
		
		query.setFirstResult(page.getPageNumber() * page.getPageSize());
		query.setMaxResults(page.getPageSize());
		
		List<Object[]> detalleArchivosResult = query.getResultList();
		
		if(detalleArchivosResult != null) {
			for(Object[] detalleArchivo : detalleArchivosResult) {
				ArchivoResponse archivo = new ArchivoResponse();
				
				archivo.setCodCliente( UtilData.toString(detalleArchivo[0]) );
				archivo.setTotArchRecib( UtilData.toBigDecimal(detalleArchivo[1]) );
				archivo.setCliente( UtilData.toString(detalleArchivo[2]) );
				archivo.setTotDupl( UtilData.toBigDecimal(detalleArchivo[3]) );
				archivo.setTotRecib( UtilData.toBigDecimal(detalleArchivo[4]) );
				archivo.setTotRecha( UtilData.toBigDecimal(detalleArchivo[5]) );
				archivo.setTotVald( UtilData.toBigDecimal(detalleArchivo[6]) );
				archivo.setTotEnroll( UtilData.toBigDecimal(detalleArchivo[7]) );
				archivo.setTotEnProc( UtilData.toBigDecimal(detalleArchivo[8]) );
				archivo.setTotEsp( UtilData.toBigDecimal(detalleArchivo[9]) );
				archivo.setTotProc( UtilData.toBigDecimal(detalleArchivo[10]) );
				
				lista.add(archivo);
			}
		}
		
		SubtotalResponse subtotal = calculoSubtotales(lista, 0, lista.size() - 1);
		
		query.setFirstResult(0);
		query.setMaxResults(Integer.MAX_VALUE);
		
		Integer totalRows = query.getResultList().size();
		
		archivoGeneral.setDetalleArchivo(new PageImpl<>(lista, page, totalRows));
		archivoGeneral.setSubtotal(subtotal);
		
		return archivoGeneral;
	}
	
	private SubtotalResponse calculoSubtotales(List<ArchivoResponse> listaBeanArchivo, int valInicio, int valFinal){
		ArchivoResponse aux = new ArchivoResponse();
		final SubtotalResponse beanSubtotal= new SubtotalResponse();
		int rango =0;	
		final int tam=listaBeanArchivo.size();		
		for( rango=valInicio ; rango<=valFinal ;rango++){
			if(rango<tam){				
				aux=listaBeanArchivo.get(rango);			
				beanSubtotal.setSubTotalArchivos(beanSubtotal.getSubTotalArchivos()+aux.getTotArchRecib().intValue());
				beanSubtotal.setSubDuplicado(beanSubtotal.getSubDuplicado()+ aux.getTotDupl().intValue());
				beanSubtotal.setSubRecibido(beanSubtotal.getSubRecibido()+ aux.getTotRecib().intValue());
				beanSubtotal.setSubRechazados(beanSubtotal.getSubRechazados()+ aux.getTotRecha().intValue());
				beanSubtotal.setSubValidado(beanSubtotal.getSubValidado()+ aux.getTotVald().intValue());
				beanSubtotal.setSubEnrollment(beanSubtotal.getSubEnrollment()+ aux.getTotEnroll().intValue());
				beanSubtotal.setSubproceso(beanSubtotal.getSubproceso()+ aux.getTotEnProc().intValue());
				beanSubtotal.setSubEspera(beanSubtotal.getSubEspera()+ aux.getTotEsp().intValue());
				beanSubtotal.setSubProcesado(beanSubtotal.getSubProcesado()+ aux.getTotProc().intValue());
			}
		}
		return beanSubtotal;
	}
	
	@Override
	public ResultTrackingResponse obtenerConteoArchivo(String codCliente, String fecha) {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder = queryObtenerDetalleArchivos(codCliente);
		
		Query query = entityManager.createNativeQuery(queryBuilder.toString());
		setParamsObtenerDetalleArchivos(codCliente, fecha, query);
		
		List<Object[]> detalleArchivosResult = query.getResultList();
		
		ArchivoResponse result = new ArchivoResponse();
		
		result.setTotAlerta(new BigDecimal(0));
		result.setTotDupl(new BigDecimal(0));
		result.setTotEsp(new BigDecimal(0));
		result.setTotEnProc(new BigDecimal(0));
		result.setTotEnroll(new BigDecimal(0));
		result.setTotProc(new BigDecimal(0));
		result.setTotProg(new BigDecimal(0));
		result.setTotRecha(new BigDecimal(0));
		result.setTotRecib(new BigDecimal(0));
		result.setTotVald(new BigDecimal(0));
		
		if(detalleArchivosResult != null) {
			for(Object[] detalleArchivo : detalleArchivosResult) {
				ArchivoResponse archivo = new ArchivoResponse();
				
				archivo.setCodCliente( UtilData.toString(detalleArchivo[0]) );
				archivo.setTotArchRecib( UtilData.toBigDecimal(detalleArchivo[1]) );
				archivo.setCliente( UtilData.toString(detalleArchivo[2]) );
				
				archivo.setTotDupl( UtilData.toBigDecimal(detalleArchivo[3]) );
				result.setTotDupl(result.getTotDupl().add(archivo.getTotDupl()));
				archivo.setTotRecib( UtilData.toBigDecimal(detalleArchivo[4]) );
				result.setTotRecib(result.getTotRecib().add(archivo.getTotRecib()));
				archivo.setTotRecha( UtilData.toBigDecimal(detalleArchivo[5]) );
				result.setTotRecha(result.getTotRecha().add(archivo.getTotRecha()));
				archivo.setTotVald( UtilData.toBigDecimal(detalleArchivo[6]) );
				result.setTotVald(result.getTotVald().add(archivo.getTotVald()));
				archivo.setTotEnroll( UtilData.toBigDecimal(detalleArchivo[7]) );
				result.setTotEnroll(result.getTotEnroll().add(archivo.getTotEnroll()));
				archivo.setTotEnProc( UtilData.toBigDecimal(detalleArchivo[8]) );
				result.setTotEnProc(result.getTotEnProc().add(archivo.getTotEnProc()));
				archivo.setTotEsp( UtilData.toBigDecimal(detalleArchivo[9]) );
				result.setTotEsp(result.getTotEsp().add(archivo.getTotEsp()));
				archivo.setTotProc( UtilData.toBigDecimal(detalleArchivo[10]) );
				result.setTotProc(result.getTotProc().add(archivo.getTotProc()));
				
			}
		}
		
		resultTrackingResponse.setArchivo(result);
		
		return resultTrackingResponse;
	}
	
	
	public StringBuilder queryObtenerDetalleArchivos(String codCliente) {
		StringBuilder querySql = new StringBuilder()
				
		.append("SELECT BUC, ")
		.append(" SUM(NUM_ARCH) NUM_ARCH, ")
		.append(" CLIENTE,")
		.append(" SUM(DUPLICADO) DUPLICADO,")
		.append(" SUM(RECIBIDO) RECIBIDO, ")
		.append(" SUM(RECHAZADO) RECHAZADO , ")
		.append(" SUM(VALIDADO) VALIDADO, ")
		.append(" SUM(ENVIADO) ENVIADO, ")
		.append(" SUM(PROCESO) PROCESO, ")
		.append(" SUM(ESPERA) ESPERA, ")
		.append(" SUM (PROCESADO) PROCESADO ")
		.append("FROM ")
		
		.append("( SELECT H2H_CLTE.BUC, ")
		.append(" COUNT(*) AS NUM_ARCH, ")
		.append(" DECODE(H2H_CLTE.PERSONALIDAD, 'F',  H2H_CLTE.NOMBRE ||'  ' || H2H_CLTE.APPATERNO ||'  '|| H2H_CLTE.APMATERNO,  H2H_CLTE.RAZON_SCIA )  AS CLIENTE, ")
		.append("SUM(DECODE (P.DESRIPCION, 'DUPLICADO', 1, 0)) AS DUPLICADO,")  
		.append("SUM(DECODE (P.DESRIPCION, 'RECIBIDO', 1, 0))  AS RECIBIDO,")   
		.append("SUM(DECODE (P.DESRIPCION, 'RECHAZADO', 1, 0) ) AS RECHAZADO,")   
		.append("SUM(DECODE (P.DESRIPCION, 'VALIDADO', 1, 0)) AS VALIDADO,")   
		.append("SUM(DECODE (P.DESRIPCION, 'ENVIADO', 1, 0)) AS ENVIADO,")
		.append("SUM(DECODE (P.DESRIPCION, 'PROCESO', 1, 0)) AS PROCESO,")   
		.append("SUM(DECODE (P.DESRIPCION, 'ESPERA',1,0 )) AS ESPERA,") 
		.append("SUM(DECODE (P.DESRIPCION, 'PROCESADO', 1, 0)) AS PROCESADO ")
		.append(" FROM H2H_ARCHIVO_TRAN ")  
		.append("INNER JOIN H2H_PARAM P ")  
        .append("ON P.VALOR = H2H_ARCHIVO_TRAN.ID_ESTATUS ")  
        .append("AND P.NMBR_PARAM LIKE 'TRCKNG_ESTATUS_%' ") 
		.append(" INNER JOIN H2H_CNTR  ON  H2H_CNTR.ID_CNTR = H2H_ARCHIVO_TRAN.ID_CNTR ")
		.append(" INNER JOIN H2H_CLTE ON H2H_CLTE.ID_CLTE = H2H_CNTR.ID_CLTE ");
				
		if (StringUtils.isNotBlank(codCliente)) {
			querySql.append("WHERE H2H_CLTE.BUC = :codCliente");
		}
		querySql.append(" GROUP BY  ") 
		.append(" H2H_CLTE.BUC,  ")
		.append(" DECODE(H2H_CLTE.PERSONALIDAD, 'F',  H2H_CLTE.NOMBRE ||'  ' || H2H_CLTE.APPATERNO ||'  '|| H2H_CLTE.APMATERNO,  H2H_CLTE.RAZON_SCIA ) ") 
		
		.append(" UNION ALL ")
		.append(" SELECT H2H_CLTE.BUC, ")
		.append(" COUNT(DISTINCT NOMB_ARCH) AS NUM_ARCH, ")
		.append(" DECODE(H2H_CLTE.PERSONALIDAD, 'F', H2H_CLTE.NOMBRE ")
		.append(" ||'  ' ")
		.append(" || H2H_CLTE.APPATERNO ")
		.append(" ||'  ' ")
		.append(" || H2H_CLTE.APMATERNO, H2H_CLTE.RAZON_SCIA ) AS CLIENTE, ")
		.append(" 0 DUPLICADO, ")
		.append(" 0 RECIBIDO, ")
		.append(" COUNT(DISTINCT NOMB_ARCH) RECHAZADO, ")
		.append(" 0 VALIDADO, ")
		.append(" 0 ENVIADO, ")
		.append(" 0 PROCESO, ")
		.append(" 0 ESPERA, ")
		.append(" 0 PROCESADO ")
		.append(" FROM H2H_ARCH_RECH ar  ")
		.append(" INNER JOIN H2H_CNTR  ")
		.append(" ON ar.ID_CNTR = H2H_CNTR.ID_CNTR ")
		.append(" INNER JOIN H2H_CLTE  ")
		.append(" ON H2H_CLTE.ID_CLTE      = H2H_CNTR.ID_CLTE ")
		.append(" WHERE TRUNC(ar.FECH_REG) = to_date (:fecha ,'dd/mm/yyyy') ")
		.append(" AND ar.MOTI_RECH        != 'Archivo Duplicado'");
		if (StringUtils.isNotBlank(codCliente)) {
			querySql.append("AND H2H_CLTE.BUC = :codCliente");
		}
		querySql.append(" GROUP BY H2H_CLTE.BUC, ")
		.append("  DECODE(H2H_CLTE.PERSONALIDAD, 'F', H2H_CLTE.NOMBRE")
		.append("  ||'  '")
		.append("  || H2H_CLTE.APPATERNO")
		.append("  ||'  '")
		.append("  || H2H_CLTE.APMATERNO, H2H_CLTE.RAZON_SCIA )")
		.append(" ) ");
		querySql.append(" GROUP BY BUC,CLIENTE ")
		.append(" ORDER  BY CLIENTE ");
		
		return querySql;
	}
	
	public void setParamsObtenerDetalleArchivos(String codCliente, String fecha, Query query) {
		if (StringUtils.isNotBlank(codCliente)) {
			query.setParameter("codCliente", codCliente);
		}
		query.setParameter("fecha", fecha);
	}

	@Override
	public List<ArchivoResponse> obtenerListDetalleArchivosGeneral(String fecha, String codCliente) {
		List<ArchivoResponse> lista = new ArrayList<ArchivoResponse>();
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder = queryObtenerDetalleArchivos(codCliente);
		
		Query query = entityManager.createNativeQuery(queryBuilder.toString());
		setParamsObtenerDetalleArchivos(codCliente, fecha, query);
		
		List<Object[]> detalleArchivosResult = query.getResultList();
		
		if(detalleArchivosResult != null) {
			for(Object[] detalleArchivo : detalleArchivosResult) {
				ArchivoResponse archivo = new ArchivoResponse();
				
				archivo.setCodCliente( UtilData.toString(detalleArchivo[0]) );
				
				archivo.setTotArchRecib( UtilData.toBigDecimal(detalleArchivo[1]) );
				archivo.setCliente( UtilData.toString(detalleArchivo[2]) );
				
				archivo.setTotDupl( UtilData.toBigDecimal(detalleArchivo[3]) );
				archivo.setTotRecib( UtilData.toBigDecimal(detalleArchivo[4]) );
				archivo.setTotRecha( UtilData.toBigDecimal(detalleArchivo[5]) );
				archivo.setTotVald( UtilData.toBigDecimal(detalleArchivo[6]) );
				archivo.setTotEnroll( UtilData.toBigDecimal(detalleArchivo[7]) );
				archivo.setTotEnProc( UtilData.toBigDecimal(detalleArchivo[8]) );
				archivo.setTotEsp( UtilData.toBigDecimal(detalleArchivo[9]) );
				archivo.setTotProc( UtilData.toBigDecimal(detalleArchivo[10]) );
				
				lista.add(archivo);
			}
		}
		
		return lista;
	}
	
}
