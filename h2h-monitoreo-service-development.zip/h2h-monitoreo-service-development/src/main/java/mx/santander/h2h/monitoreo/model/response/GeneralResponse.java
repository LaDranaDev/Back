package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Respuesta base para las apis 
 *
 * DTO para indicar una respuesta de exito o error
 * @author Paul Quintero
 * @since 22/03/22
 */
@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class GeneralResponse implements Serializable {
	/**
	 * Serial ID
	 */
	private static final long serialVersionUID = 1025077792796601926L;
	/**
     * Mensaje de exito
     */
	private String message;
    /**
     * Mensaje de error
     */
	private String error;
}
