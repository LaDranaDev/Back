package mx.santander.h2h.monitoreo.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Tuple;
import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.constants.QueryConstant;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorCatalogsResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorCatalogsResponse.Pair;


@Slf4j
@Repository
public class OperationsMonitorComplementEntityManagerRepository implements IOperationsMonitorComplementEntityManagerRepository {

	/** Declaracion de EntityManager para entityManager. */
	@Autowired
    @PersistenceContext
    private EntityManager entityManager;

	
	@Override
	public OperationsMonitorCatalogsResponse catalogs() {
		log.info("Iniciamos con la obtención de catalogos............");
        OperationsMonitorCatalogsResponse response = new OperationsMonitorCatalogsResponse();
        response.setDivisas(new ArrayList<>());
        response.setEstatus(new ArrayList<>());
        response.setProductos(new ArrayList<>());

        List<?> divisas = entityManager.createNativeQuery(QueryConstant.LISTA_DIVISAS, Tuple.class).getResultList();
        divisas.forEach(object -> {
            if (!(object instanceof Tuple)) return;
            Tuple tuple = (Tuple) object;
            String value = String.valueOf(tuple.get("value"));
            response.getDivisas().add(new Pair(value, value));
        });

        List<?> estatus = entityManager.createNativeQuery(QueryConstant.LISTA_ESTATUS, Tuple.class).getResultList();
        estatus.forEach(object -> {
            if (!(object instanceof Tuple)) return;
            Tuple tuple = (Tuple) object;
            String key = String.valueOf(tuple.get("key"));
            String value = String.valueOf(tuple.get("value"));
            response.getEstatus().add(new Pair(key, value));
        });

        List<?> productos = entityManager.createNativeQuery(QueryConstant.QUERY_OBTENER_CATALOGO_PRODUCTOS, Tuple.class).getResultList();
        productos.forEach(object -> {
            if (!(object instanceof Tuple)) return;
            Tuple tuple = (Tuple) object;
            String key = String.valueOf(tuple.get("ID_PROD"));
            String value = String.valueOf(tuple.get("DESC_PROD"));
            response.getProductos().add(new Pair(key, value));
        });

        return response;

	}

}
