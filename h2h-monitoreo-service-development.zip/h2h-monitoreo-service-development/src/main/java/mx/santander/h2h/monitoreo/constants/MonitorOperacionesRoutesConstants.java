package mx.santander.h2h.monitoreo.constants;

/**
 * MonitorOperacionesRoutesConstants.
 *
 * Define las rutas de las distintas pantallas de detalle.
 *
 * @author Jesus Soto Aguilar
 * @since 07/07/2023
 */
public final class MonitorOperacionesRoutesConstants {

    /**
     * URL_DETALLE_DOMIS.
     */
    public static final String URL_DETALLE_DOMIS = "URL_DETALLE_DOMIS";

    /**
     * URL_DETALLE_CNF.
     */
    public static final String URL_DETALLE_CNF = "URL_DETALLE_CNF";

    /**
     * URL_DETALLE_IMP_FED.
     */
    public static final String URL_DETALLE_IMP_FED = "URL_DETALLE_IMP_FED";

    /**
     * URL_DETALLE_PAG_REF.
     */
    public static final String URL_DETALLE_PAG_REF = "URL_DETALLE_PAG_REF";

    /**
     * URL_DETALLE_APOR_PATR.
     */
    public static final String URL_DETALLE_APOR_PATR = "URL_DETALLE_APOR_PATR";

    /**
     * URL_DETALLE_ORDEN_PAGO.
     */
    public static final String URL_DETALLE_ORDEN_PAGO = "URL_DETALLE_ORDEN_PAGO";

    /**
     * URL_DETALLE_ALTA_MASIVA.
     */
    public static final String URL_DETALLE_ALTA_MASIVA = "URL_DETALLE_ALTA_MASIVA";

    /**
     * URL_DETALLE_TARJ_PROP.
     */
    public static final String URL_DETALLE_TARJ_PROP = "URL_DETALLE_TARJ_PROP";

    /**
     * URL_DETALLE_PIF.
     */
    public static final String URL_DETALLE_PIF = "URL_DETALLE_PIF";

    /**
     * URL_DETALLE_TRANSFERENCIAS.
     */
    public static final String URL_DETALLE_TRANSFERENCIAS = "URL_DETALLE_TRANSFERENCIAS";

    /**
     * URL_DETALLE_SPID.
     */
    public static final String URL_DETALLE_SPID = "URL_DETALLE_SPID";

    /**
     * URL_DETALLE_PD.
     */
    public static final String URL_DETALLE_PD = "URL_DETALLE_PD";

    /**
     * OrdPagAtm
     */
    public static final String OrdPagAtm = "OrdPagAtm";

    /**
     * PagImpAdua
     */
    public static final String PagImpAdua = "PagImpAdua";

    /**
     * URL_DETALLE
     */
    public static final String URL_DETALLE = "URL_DETALLE";

    /**
     * Constructor privado.
     */
    private  MonitorOperacionesRoutesConstants() {

    }
}
