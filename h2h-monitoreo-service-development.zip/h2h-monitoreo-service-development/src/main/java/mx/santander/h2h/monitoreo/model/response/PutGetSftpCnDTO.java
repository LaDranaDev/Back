package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Dto para los datos de salida del SFTP PUT/GET
 * 
 * @author Z483900
 *
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class PutGetSftpCnDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7361555441516613592L;

	/**Variable par alamacenar el campo de Profile ID*/
	private String profileId;

	/**Variable par alamacenar el campo de KnowId Host*/
	private String knowIdHost;

	/**Variable par alamacenar el campo de User Id Key*/
	private String userIdKey;

	/**Variable par alamacenar el campo de Nodo Local*/
	private String nodoLocal;

	/**Variable par alamacenar el campo de nodo remoto*/
	private String nodoRemoto;

	/**Variable par alamacenar el campo de Usuario Local*/
	private String usuarioLocal;

	/**Variable par alamacenar el campo de Usuario Remoto*/
	private String usuarioRemoto;

	/**Variable par alamacenar el campo de Password Remoto*/
	private String passwordRemoto;

	/**Variable par alamacenar el campo de oscurecer Password*/
	private String oscurecerPwd;

	/**Variable par alamacenar el campo de Modo Binario*/
	private String modoBinario;

	/**Variable par alamacenar el campo de Formato de Registro*/
	private String formatoRegistro;

	/**Variable par alamacenar el campo de Longitud de Registro*/
	private String longitudRegistro;

	/**Variable par alamacenar el campo de Modo DISP*/
	private String modoDisp;

	/**Variable par alamacenar el campo de Parametro SYS OPTS*/
	private String parametroSysOpts;

	/**Variable par alamacenar el campo de Desposicion de registro*/
	private String disposicionRegistro;

}
