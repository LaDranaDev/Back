package mx.santander.h2h.monitoreo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * Clase principal para iniciar el proyecto en SpringBoot Si se necesitan
 * scanear paquetes debem ser agregados en la clase principal
 *
 * @author Jesus Soto Aguilar
 * @since 12/04/2023
 */
@SpringBootApplication
@ComponentScan({ "mx.santandertec.*", "mx.santander.h2h.monitoreo", "mx.santander" })
public class MonitoreoApplication {

	/**
	 * Metodo main para inicializar la aplicacion Spring Boot
	 * @param args Argumentos opcionales de envio al programa
	 */
	public static void main(String[] args) {
		SpringApplication.run(MonitoreoApplication.class, args);
	}

}
