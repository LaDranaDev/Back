package mx.santander.h2h.monitoreo.model.request;

import java.io.Serializable;
import java.util.ArrayList;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import mx.santander.h2h.monitoreo.model.response.ParametersGetPutResponse;

/**
 * Dto para los datos de entrada de los parametros de conexion de contrato
 * 
 * @author sbautish
 * @since 03/05/2023
 *
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ContractConnectionParametersManagementRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9101897600096558608L;

	/**
	 * Variable que almacena el número de contrato
	 */
	private String numeroContrato;

	/**
	 * Variable que almacena el código del cliente
	 */
	private String codigoCliente;

	/**
	 * Variable que almacena el identificador del protocolo
	 */
	private String idProtocolo;

	/**
	 * Variable que almacena el identificador de registro
	 */
	private String idRegistro;

	/**
	 * Variable que almacena el tipo de procesamiento GET o PUT
	 */
	private String tipoProcesamiento;

	/**
	 * Variable que almacena el estado de valor activo (A) o inactivo (I)
	 */
	private String estadoValor;

	/**
	 * Lista para almacenar objetos de parámetros GET o PUT
	 */
	private ArrayList<ParametersGetPutResponse> parametrosGetPut;

}
