package mx.santander.h2h.monitoreo.util;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

import jakarta.persistence.Tuple;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.MutablePair;
import org.apache.commons.lang3.tuple.Pair;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class UtilsTramaAdicionales {
    /**
     * String UNION_ALL
     */
    private static final String UNION_ALL = " UNION ALL ";

    /**
     * Descripcion   : Metodo que realiza la generacion de unalista de beanes de campos adicionales
     * Creado por    : 1396920|Moises Navarro
     * Fecha Creacion: 11 nov. 2019
     * @param datosRefe string con los datos adicionales
     * @return List<CampoAdicionalBean> lista de beanes de campos adicionales
     */
    public static List<Pair<String, String>> generarListaCPA(String datosRefe) {
        List<Pair<String, String>> cpAdicionales= new ArrayList<>();
        String[] arrayCampos=datosRefe.split(Pattern.quote("|"));
        for (int i = 0; i < arrayCampos.length; i += 2) {
            cpAdicionales.add(ImmutablePair.of(arrayCampos[i], (arrayCampos[i+1])));
        }
        return cpAdicionales;
    }

    /**
	 * Descripcion   : Metodo que realiza la generacion de una lista de beanes de campos adicionales
	 * 
	 * @param datosRefe string con los datos adicionales
	 * @return List<CampoAdicionalBean> lista de beanes de campos adicionales
	 */
//	public static List<CampoAdicionalBean> generarListaCPABean(String datosRefe) {
//		List<CampoAdicionalBean> cpAdicionales= new ArrayList<CampoAdicionalBean>();
//		String[] arrayCampos=datosRefe.split(Pattern.quote("|"));
//		for(int i=0;i<arrayCampos.length;i+=2) {
//			CampoAdicionalBean bean= new CampoAdicionalBean();
//			bean.setCampo(arrayCampos[i]);
//			bean.setValue(arrayCampos[i+1]);
//			cpAdicionales.add(bean);
//		}
//		return cpAdicionales;
//	}

    /**
     * Genera la consulta del historial de la operacion
     * @param tabla1 nombre de la tabla a consultar
     * @param tabla2 - ID de la operacion
     * @return Consulta del historial de la operacion
     */
    public static String generaConsultaHistorialOperacion (String tabla1, String tabla2) {
        /**Se genera instacia de stringbuilder*/
        StringBuilder query = new StringBuilder();
        query
                .append("SELECT HBR.ID_REG, ")
                .append("DESC_ESTATUS as estatus, ")
                .append("TO_CHAR (HBR.FECHA_ESTATUS, 'dd-MM-yyyy') AS fecha, ")
                .append("TO_CHAR (HBR.FECHA_ESTATUS, 'HH24:mi:ss') AS hora, ")
                .append(" HBR.FECHA_ESTATUS ")
                .append("FROM ")
                .append(tabla1)
                .append(" HBR INNER JOIN H2H_CAT_ESTATUS HCE ")
                .append("ON HBR.ID_ESTATUS = HCE.ID_CAT_ESTATUS ")
                .append("WHERE HBR.ID_REG = ")
                .append(" :idOperacion ")
                .append(UNION_ALL)
                .append("SELECT HBR.ID_REG, ")
                .append("DESC_ESTATUS as estatus, ")
                .append("TO_CHAR (HBR.FECHA_ESTATUS, 'dd-MM-yyyy') AS fecha, ")
                .append("TO_CHAR (HBR.FECHA_ESTATUS, 'HH24:mi:ss') AS hora, ")
                .append(" HBR.FECHA_ESTATUS ")
                .append("FROM ")
                .append(tabla2)
                .append(" HBR INNER JOIN H2H_CAT_ESTATUS HCE ")
                .append("ON HBR.ID_ESTATUS = HCE.ID_CAT_ESTATUS ")
                .append("WHERE HBR.ID_REG = ")
                .append(" :idOperacion ")
                .append(" ORDER BY FECHA_ESTATUS");
        /**Se retorne query armado con las diferentes tablas para consultar la operacion*/
        return query.toString();
    }

    /**
     * Retorna la fecha del objeto pasado como parametro.
     * @param obj Object
     * @return String fecha
     */
    public static String getFecha(Object obj) {
        String fecha = StringUtils.EMPTY;
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        if (obj instanceof Date || obj instanceof Timestamp) {
            fecha = dateFormat.format(obj);
        }
        if (obj instanceof String) {
            fecha = obj.toString();
        }
        return fecha;
    }

    /**
     * Descripcion : Metodo que realiza validacion de los productos 01, 41, 97, 47, 02, 42
     * @author  [z448853: Orlando Michael Mujica Garcia]
     * @since  25/05/2020
     * @param cveOperProd contiene la clave del producto
     * @return devuelve String con la cadena armada.
     */
    public static String getConsultaProdructoUtils(int cveOperProd){
        /**Se genera instacia del query de tipo StringBuilder*/
        final StringBuilder query = new StringBuilder();
        /**Se inicia con las validaciones con switch*/
        switch (cveOperProd) {
            case 1:
            case 41:
            case 97:
            case 47:
            case 2:
            case 42:
                String sqlProdTra = query.toString();
                query.delete(0, sqlProdTra.length());
                sqlProdTra = sqlProdTra.replace(ConstantesUtils.REG_DIVI_DIVISA, "DECODE(DIVI_ABON.CLAV_CAPTA,NULL,REG.DIVI,DIVI_ABON.CLAV_CAPTA) DIVISA, ");
                query.append(sqlProdTra);
                /**Se relaiza la invocacion del metodo para armar el query*/
                query.append(ConstantesUtils.consultaProductos(cveOperProd));
                break;
            default:
                /**Se realiza la inovacion del metodo getConsultaProdructo80819596Utils*/
                query.append(getConsultaProdructo80819596Utils(cveOperProd));
                break;
        }
        /**Se retorna el query armado*/
        return query.toString();
    }

    /**
     * Descripcion : Metodo que realiza validacion de los productos 80,81,95,96
     * @author  [z448853: Orlando Michael Mujica Garcia]
     * @since  25/05/2020
     * @param cveOperProd contiene la clave del producto
     * @return devuelve String con la cadena armada.
     */
    public static String getConsultaProdructo80819596Utils(int cveOperProd){
        /**Se genera instacia del query de tipo StringBuilder*/
        final StringBuilder query = new StringBuilder();
        /**Se inicia con las validaciones con switch*/
        switch (cveOperProd) {
            case 80:
            case 81:
            	query.append("NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD, NULL INTERMEDIARIO_REC, DETA.NOMB_BENE || ' ' || DETA.APE_PATE_BENE || ' ' || DETA.APE_MATE_BENE BENEFICIARIO, ")
                        .append(ConstantesUtils.NULL_COMENTARIO_1_NULL_COMENTARIO_2+ConstantesUtils.NULL_COMENTARIO)
                        .append("DETA.FORM_PAGO TIPO_PAGO, DETA.FORM_ALTA MODALIDAD, DETA.IMPO_GIRO IMPORTE_CARGO, ")
            			.append("DETA.CONC_PAGO MSG_H2H, MSG.MSG_H2H MSG_ORDEN_PAGO, DETA.NUM_ORDEN, ")
            			.append("DETA.FECH_LIMI_LIQ FECHA_LIMITE_PAGO, DETA.OFIC_PAGO NUM_SUCURSAL, NULL FECH_VENC,")
            			.append("DETA.REFE_CLTE REFERENCIA_ABONO, DETA.REFE_NUM_CLTE REFERENCIA_CARGO, DETA.NOMB_PERS_AUT_EXT, DETA.MENSAJE, ")
                        .append(ConstantesUtils.NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA+ConstantesUtils.NULL_BUC_EMPLEADO+ConstantesUtils.NULL_SUCURSAL_TUTORA_NULL_RFC+ConstantesUtils.NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA+ConstantesUtils.NULL_DESCRIPCION);
                break;
            case 95:
            case 96:
                String sqlProdTran = query.toString();
                query.delete(0, sqlProdTran.length());
                sqlProdTran = sqlProdTran.replace(ConstantesUtils.REG_DIVI_DIVISA, "DECODE(DIVI_ABON.CLAV_CAPTA,NULL,REG.DIVI,DIVI_ABON.CLAV_CAPTA) DIVISA,");
                query.append(sqlProdTran)
                        .append("NULL INTERMEDIARIO_ORD, DIVI_CARG.CLAV_CAPTA DIVISA_ORD, NULL INTERMEDIARIO_REC, DECODE(CNTA_ABON.NOMB_TITU,NULL,DETA.NOMB_RECE,CNTA_ABON.NOMB_TITU) BENEFICIARIO, ")
                        .append(ConstantesUtils.NULL_COMENTARIO_1_NULL_COMENTARIO_2+"NULL COMENTARIO_3, CNTA_CARG.NOMB_TITU TITULAR, BNCO.NOMBRE_BANCO BANCO_RECEPTOR, ")
                        .append(ConstantesUtils.NULL_TIPO_PAGO_NULL_MODALIDAD_NULL_IMPORTE_CARGO+ConstantesUtils.MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN+ConstantesUtils.FECHA_LIMITE)
                        .append(ConstantesUtils.NULL_REFERENCIA_ABONO_NULL_REFERENCIA_CARGO+ConstantesUtils.NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA+ConstantesUtils.NULL_BUC_EMPLEADO+ConstantesUtils.NULL_SUCURSAL_TUTORA_NULL_RFC+ConstantesUtils.NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA+ConstantesUtils.NULL_DESCRIPCION);
                break;
            default:
                /**Se realiza la invocacion del metodo getConsultaProdructo489899493691135Utils*/
                query.append(getConsultaProdructo489899493691135Utils(cveOperProd));
                break;
        }
        /**Se retorna el el query armado*/
        return query.toString();
    }

    /**
     * Descripcion : Metodo que realiza validacion de los productos 48,98,99,49,36,91,135
     * @author  [z448853: Orlando Michael Mujica Garcia]
     * @since  25/05/2020
     * @param cveOperProd contiene la clave del producto
     * @return devuelve String con la cadena armada.
     */
    public static String getConsultaProdructo489899493691135Utils(int cveOperProd){
        /**Se genera instacia del query de tipo StringBuilder*/
        final StringBuilder query = new StringBuilder();
        /**Se inicia con las validaciones con switch*/
        switch (cveOperProd) {
            case 48:
            case 98:
            case 99:
            case 49:
            case 36:
                String sqlProdTr = query.toString();
                query.delete(0, sqlProdTr.length());
                sqlProdTr = sqlProdTr.replace(ConstantesUtils.REG_DIVI_DIVISA, "DIVI_ABON.CLAV_CAPTA DIVISA,");
                query.append(sqlProdTr);
                /**Se relaiza la invocacion del metodo para armar el query*/
                query.append(ConstantesUtils.consultaProductos9848(cveOperProd));
                break;
            case 91:
            case 135:
                String sqlConfirming = query.toString();
                query.delete(0, sqlConfirming.length());
                sqlConfirming = sqlConfirming.replace("REG.CNTA_CARG NUM_CTA_CARGO,", "DETA.CNTA_CARG NUM_CTA_CARGO,");
    			sqlConfirming = sqlConfirming.replace("REG.CNTA_ABON NUN_CTA_ABONO,", "DETA.CNTA_ABON NUN_CTA_ABONO,");
    			sqlConfirming = sqlConfirming.replace("REG.REFE_BE REFERENCIA,", "DETA.REFE_ABON REFERENCIA,");
                sqlConfirming = sqlConfirming.replace(ConstantesUtils.REG_DIVI_DIVISA, "DETA.DIVI_ABON DIVISA,");
                query.append(sqlConfirming);
                /**Se relaiza la invocacion del metodo para armar el query*/
                query.append(ConstantesUtils.consultaProductos9949(cveOperProd));
                break;
            default:
                /**Se realiza la invocacion del metodo getConsultaProdructo9354Utils*/
                query.append(getConsultaProdructo9354Utils(cveOperProd));
                break;
        }
        /**Se retorna l cadena armada*/
        return query.toString();
    }

    /**
     * Descripcion : Metodo que realiza validacion de los productos 93 y 54
     * @author  [z448853: Orlando Michael Mujica Garcia]
     * @since  25/05/2020
     * @param cveOperProd contiene la clave del producto
     * @return devuelve String con la cadena armada.
     */
    public static String getConsultaProdructo9354Utils(int cveOperProd){
        /**Se genera instacia del query de tipo StringBuilder*/
        final StringBuilder query = new StringBuilder();
        /**Se inicia con las validaciones con switch*/
        switch (cveOperProd) {
            case 93:
                query
                        .append("NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD, NULL INTERMEDIARIO_REC, NULL BENEFICIARIO, "+ConstantesUtils.NULL_COMENTARIO_1_NULL_COMENTARIO_2)
                        .append(ConstantesUtils.NULL_COMENTARIO+ConstantesUtils.NULL_TIPO_PAGO_NULL_MODALIDAD_NULL_IMPORTE_CARGO+ConstantesUtils.MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN)
                        .append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, "+ConstantesUtils.NULL_REFERENCIA_ABONO_NULL_REFERENCIA_CARGO)
                        .append("DETA.NUME_EMPL NUMERO_EMPLEADO, DETA.NUME_TARJ_NUEV NUMERO_TARJETA, DETA.NUME_BUC_EMPL BUC_EMPLEADO, ")
            			.append("DETA.SUCU_TUTO SUCURSAL_TUTORA, DETA.RFC_EMPL RFC, DETA.NOMB_EMPL || ' ' || DETA.APEL_PATE_EMPL || ' ' || DETA.APEL_MATE_EMPL NOMBRE_EMPLEADO, DETA.NUME_CTA_NUEV NUMERO_CUENTA, ")
            			.append("DETA.DESC_ERRO DESCRIPCION, ");
                break;
            case 54:
                query
	                .append("DETA.NUM_TARJ NUMERO_TARJETA_ACT, DETA.NUM_TARJ_ARCH NUMERO_TARJETA, DETA.NUM_CTA NUM_CTA_CARGO_TARJ, ")
	    			.append("MSG.MSG_H2H, ");
                break;
            default:
                query
                        .append("NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD, NULL INTERMEDIARIO_REC, NULL BENEFICIARIO, ")
                        .append(ConstantesUtils.NULL_COMENTARIO_1_NULL_COMENTARIO_2+ConstantesUtils.NULL_COMENTARIO)
                        .append(ConstantesUtils.NULL_TIPO_PAGO_NULL_MODALIDAD_NULL_IMPORTE_CARGO+ConstantesUtils.MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN)
                        .append(ConstantesUtils.FECHA_LIMITE+ConstantesUtils.NULL_REFERENCIA_ABONO_NULL_REFERENCIA_CARGO+ConstantesUtils.NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA)
                        .append(ConstantesUtils.NULL_BUC_EMPLEADO+ConstantesUtils.NULL_SUCURSAL_TUTORA_NULL_RFC+ConstantesUtils.NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA+ConstantesUtils.NULL_DESCRIPCION);
                break;
        }
        /**Se retorna la cadena realizada*/
        return query.toString();
    }
    /**
     * Descripcion : Metodo que realiza validacion de los productos a 3 meses
     * @author  [z448853: Orlando Michael Mujica Garcia]
     * @since  25/05/2020
     * @param cveOperProd contiene la clave del producto
     * @return devuelve String con la cadena armada.
     */
    public static String armadoTramaSegundaParte(int cveOperProd){
        /**Se genera instacia del query de tipo StringBuilder*/
        final StringBuilder query = new StringBuilder();
        switch (cveOperProd) {
            case 95:
            case 96:
                query
                        .append("LEFT JOIN H2H_CAT_BNCO BNCO USING(ID_BANCO) ")
                        .append(ConstantesUtils.LEFT_JOIN_CONS+ConstantesUtils.LEFT_JOIN_CONS_DOS)
                        .append(ConstantesUtils.LEFT_JOIN_CONS_TRES+ConstantesUtils.LEFT_JOIN_CONS_CUATRO);
                break;
            case 98:
            case 48:
            case 99:
            case 49:
                query
                    .append("LEFT JOIN H2H_CAT_BNCO BNCO ON DETA.ID_BANC = BNCO.ID_BANCO ")
                    .append(ConstantesUtils.LEFT_JOIN_CONS+ConstantesUtils.LEFT_JOIN_CONS_DOS)
                    .append(ConstantesUtils.LEFT_JOIN_CONS_TRES+ConstantesUtils.LEFT_JOIN_CONS_CUATRO);
                break;
            case 36:
                query
                        .append("LEFT JOIN H2H_CAT_BNCO BNCO ON BNCO.CLAVE_BANCO = '014'")
                        .append(ConstantesUtils.LEFT_JOIN_CONS+ConstantesUtils.LEFT_JOIN_CONS_DOS)
                        .append(ConstantesUtils.LEFT_JOIN_CONS_TRES+ConstantesUtils.LEFT_JOIN_CONS_CUATRO);
                break;
            default:
                break;
        }
        /**Se retorna el query armado.*/
        return query.toString();
    }

    /**
     * Descripcion : Metodo que realiza la validacion de la operacion online o h2h actual
     * @author  [z448853: Orlando Michael Mujica Garcia]
     * @since  25/05/2020
     * @param resultList lista que contiene los objetos de la respuesta
     * @return retorna objeto de tipo Pair con los atributros de las tablas a consultar
     */
    public static Pair<String, String> recuperaRespuesta(List<?> resultList){
        MutablePair<String, String> tablas = new MutablePair<>();
        /**Se recorre la respuesta*/
        for (Object obj : resultList) {
            if (!(obj instanceof Tuple)) continue;
            Tuple tuple = (Tuple) obj;
            /**Se realiza la invocacion al metodo para recuperar las tablss*/
            if(tuple.get("ID_OPER_ONL")!= null && !tuple.get("ID_OPER_ONL").toString().isEmpty() ){
                tablas.setLeft("h2h_bita_reg_online_tran");
                tablas.setRight("h2h_bita_reg_online");
            }else{
                /**Se realiza la generacion de la variable para almacenar la primer tabla*/
                tablas.setLeft("H2H_BITA_REG_TRAN");
                /**Se realiza la generacion de la variable para almacenar la Segunda tabla*/
                tablas.setRight("H2H_BITA_REG");
            }
        }
        return tablas;
    }
}
