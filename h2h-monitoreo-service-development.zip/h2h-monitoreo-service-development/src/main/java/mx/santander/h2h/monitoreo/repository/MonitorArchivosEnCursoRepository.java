package mx.santander.h2h.monitoreo.repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import mx.santander.h2h.monitoreo.commons.utils.ConsultaTrackingUtil;
import mx.santander.h2h.monitoreo.model.request.MonitorArchivosEnCursoRequest;
import mx.santander.h2h.monitoreo.model.response.MonitorDeArchivosEnCursoDetallesResponse;
import mx.santander.h2h.monitoreo.util.Util;
import mx.santander.h2h.monitoreo.util.UtilMonitorFnc;


/**
 * EntityManager para el Tracking de Archivos
 *
 * @author emendoza
 * @since 19/04/2023
 */
@Repository
public class MonitorArchivosEnCursoRepository implements IMonitorArchivosEnCursoRepository {
	@Autowired
    @PersistenceContext
    private EntityManager entityManager;

    /**
     * Obtiene el detalle del archivo de acuerdo al estatus
     * @param fecha LocalDate
     * @param codCliente String
     * @param codEstatus String
     * @param nomArch String
     * @return Lista con los beans de resultado
     */
    @Override
    public List<MonitorDeArchivosEnCursoDetallesResponse> ejecutaBusquedaArchivosEnCurso(
    		MonitorArchivosEnCursoRequest request) {
        Map<String, Object> params = new HashMap<>();
        StringBuilder querySQL = new StringBuilder();
        String querys = ejecutaBusquedaArchivosEnCurso(request, querySQL, params);

        int pagina = Integer.parseInt(request.getPagina());
        int tamPagina = Integer.parseInt(request.getTamanioPagina());
        
        StringBuilder queryCountSQL = new StringBuilder();
        UtilMonitorFnc.getQueryPaginado(querys, queryCountSQL, params, pagina, tamPagina);
        		
        Query query = entityManager.createNativeQuery(queryCountSQL.toString(), Tuple.class);
        params.forEach(query::setParameter);
        List<?> resultList = query.getResultList();
        List<MonitorDeArchivosEnCursoDetallesResponse> respuestaOperaciones =  mapResultToResponseList(resultList, 1);

        return respuestaOperaciones;
    }   
    
    /**
     * Obtiene el detalle del archivo de acuerdo al estatus
     * @param fecha LocalDate
     * @param codCliente String
     * @param codEstatus String
     * @param nomArch String
     * @return Lista con los beans de resultado
     */
    @Override
    public List<MonitorDeArchivosEnCursoDetallesResponse> ejecutaBusquedaArchivosEnCursoReporte(MonitorArchivosEnCursoRequest
            request
    ) {
        Map<String, Object> params = new HashMap<>();
        StringBuilder querySQL = new StringBuilder();
        String queryS = ejecutaBusquedaArchivosEnCurso(request, querySQL, params);
        Query query = entityManager.createNativeQuery(queryS, Tuple.class);
        params.forEach(query::setParameter);
        List<?> result = query.getResultList();
        return mapResultToResponseList(result, 1);
    }

    
    /**
     * Obtiene el detalle del archivo de acuerdo al estatus
     * @param fecha LocalDate
     * @param codCliente String
     * @param codEstatus String
     * @param nomArch String
     * @return Lista con los beans de resultado
     */
    @Override
    public List<MonitorDeArchivosEnCursoDetallesResponse> ejecutaBusquedaNivelProducto( String idArchivo, Integer idProducto, Integer idEstatus
    ) {
        Map<String, Object> params = new HashMap<>();
        String queryDetalle = ejecutaBusquedaNivelProducto(idArchivo, idProducto, idEstatus, params);
        Query query = entityManager.createNativeQuery(queryDetalle, Tuple.class);
        params.forEach(query::setParameter);
        List<?> result = query.getResultList();
        return mapResultToResponseList(result, 2);
    }

    /**
     * Obtiene el query Detalle.
     * @param fecha LocalDate
     * @param codCliente String
     * @param nomArch String
     * @param codEstatus Integer
     * @param params Map<String, Object>
     * @return String
     */
    private String ejecutaBusquedaArchivosEnCurso(
    		MonitorArchivosEnCursoRequest request, StringBuilder querySQLs, 
            Map<String, Object> params
    ) {
    	final StringBuilder querySQL = new StringBuilder();
    	querySQL.append(" ")
        .append(" SELECT A.ID_ARCHIVO, A.NOMBRE_ARCH,A.FECHA_REGISTRO FECHA_ORDER,")
        .append(" TO_CHAR(A.FECHA_REGISTRO,'dd/mm/yyyy') FECHA_REGISTRO,")
        .append(" A.ID_ESTATUS, B.DESC_ESTATUS,C.ID_PROD,F.ID_CLTE,")
        .append(" DECODE(F.PERSONALIDAD, 'F', F.NOMBRE || '  ' || F.APPATERNO || '  ' || F.APMATERNO, F.RAZON_SCIA ) AS CLIENTE,")
        .append(" F.RAZON_SCIA,  F.BUC,").append(" C.DESC_PROD,  H2H_CAT_CANL.NOMB_CANL,  MSG_H2H MOTI_RECH, ")
        .append(" SUM (NVL(D.TOTA_OPER,0)) AS TOTAL_OPER, ").append(" SUM (NVL(D.TOTA_MONT,0)) AS TOTAL_MONT ")
        .append(" FROM H2H_ARCHIVO_TRAN A ")
        .append(" LEFT  JOIN H2H_ARCH_PROD_TRAN D ON D.ID_ARCHIVO = A.ID_ARCHIVO ")
        .append(" INNER JOIN  H2H_CAT_ESTATUS B ON B.ID_CAT_ESTATUS  =  A.ID_ESTATUS")
        .append(" INNER JOIN H2H_PARAM P ON P.VALOR = A.ID_ESTATUS")
        .append(" AND P.NMBR_PARAM LIKE 'TRCKNG_ESTATUS_%' ")
        .append(" INNER JOIN H2H_CNTR E  ON  E.ID_CNTR = A.ID_CNTR")
        .append(" INNER JOIN H2H_CLTE F ON  F.ID_CLTE =  E.ID_CLTE")
        .append(" LEFT JOIN H2H_CAT_PROD C ON C.CVE_PROD_OPER = D.CVE_PROD_OPER")
        .append(" INNER JOIN H2H_CAT_CANL ON H2H_CAT_CANL.ID_CANL = A.ID_CANL ")
        .append(" LEFT JOIN H2H_MSG MSG ON MSG.ID_MSG = A.ID_MSG ").append(" WHERE A.ID_ESTATUS not in (18, 16, 69) ");
        completaWhere(querySQL, request, params);
        querySQL.append(" GROUP BY A.ID_ARCHIVO, A.NOMBRE_ARCH, A.FECHA_REGISTRO, A.ID_ESTATUS,")
        .append(" B.DESC_ESTATUS, C.ID_PROD, C.DESC_PROD, F.ID_CLTE, DECODE(F.PERSONALIDAD, 'F', F.NOMBRE || '  ' || F.APPATERNO || '  ' || F.APMATERNO, F.RAZON_SCIA ), ")
        .append(" F.RAZON_SCIA, F.buc, ")
        .append(" H2H_CAT_CANL.NOMB_CANL,MSG_H2H ORDER BY FECHA_ORDER ASC, ID_ARCHIVO");
        return querySQL.toString();
    }
    
    /**
     * Consulta el total de registros
     * @param consultaOperaciones - Parámetros de consulta
     * @return Numero de total de registros
     */
    public long countConsultaOperaciones(MonitorArchivosEnCursoRequest consultaOperaciones) {

        final Map<String, Object> params = new HashMap<>();
        StringBuilder querySQL = new StringBuilder();
        String querys = ejecutaBusquedaArchivosEnCurso(consultaOperaciones, querySQL, params);
        
        String queryCount = OperationsMonitorEntityManagerHelper2Repository
                .getQueryCount( querys );
        
        Query query = entityManager.createNativeQuery(queryCount);
        params.forEach(query::setParameter);
        return ((BigDecimal) query.getSingleResult()).longValue();
    }
    
    /**
     * Obtiene el query Detalle.
     * @param fecha LocalDate
     * @param codCliente String
     * @param nomArch String
     * @param codEstatus Integer
     * @param params Map<String, Object>
     * @return String
     */
    private String ejecutaBusquedaNivelProducto(
             String idArchivo,
             Integer idProducto,
             Integer idEstatus,
             Map<String, Object> params
    ) {
        StringBuilder sql = new StringBuilder();
        sql.append(" ")
        .append("SELECT C.id_prod as ID_PROD, A.id_estatus, ")
		.append("C.DESC_PROD as DESC_PROD, B.DESC_ESTATUS as DESC_ESTATUS, ")
		.append("count(*) as NUM_OP, sum(mont) as IMP_OP ")
		.append("FROM h2h_reg_tran A, ")
			.append(" h2h_cat_estatus B, ")
			.append(" h2h_cat_prod C ")
		.append("WHERE A.id_estatus = B.id_cat_estatus ")
		.append("  AND A.cve_prod_oper = C.cve_prod_oper ")
		.append(" AND A.id_arch = :idArchivo ");
	if (idProducto != null && idProducto > 0) {
		sql.append(" AND C.id_prod = :idProducto ");
		params.put("idProducto", idProducto);
		
	}
	if (idEstatus != null && idEstatus > 0) {
		sql.append(" AND B.id_cat_estatus = :idEstatus ");
		params.put("idEstatus", idEstatus);
	}
	params.put("idArchivo", idArchivo);
	sql.append(" group by C.id_prod, C.DESC_PROD,A.id_estatus, B.DESC_ESTATUS ");
	sql.append(" order by B.DESC_ESTATUS ");
        return sql.toString();
    }

    /**
     * Map a Lista de detalle
     * @param datos List<?>
     * @return List<BeanProductoArchivo>
     */
    public List<MonitorDeArchivosEnCursoDetallesResponse> mapResultToResponseList(List<?> datos, Integer numb) {
        List<MonitorDeArchivosEnCursoDetallesResponse> listBean = new ArrayList<>();
        Integer idArchivoActual = -1;
		Integer idArchivoAnterior = -1;
		Integer numOp = 0;
		BigDecimal monto = new BigDecimal(0);
		
        for (Object object : datos) {
            if (!(object instanceof Tuple)) {
                continue;
            }
            Tuple row = (Tuple) object;
            MonitorDeArchivosEnCursoDetallesResponse bean = new MonitorDeArchivosEnCursoDetallesResponse();
            if(numb == 1) {
		        	bean.setCliente(String.valueOf(row.get("CLIENTE")));
		            bean.setIdArchivo(String.valueOf(row.get("ID_ARCHIVO")));
		            idArchivoActual= Integer.parseInt(bean.getIdArchivo());
		            bean.setNombreArch(String.valueOf(row.get("NOMBRE_ARCH")));
		            bean.setFechaRegistro(String.valueOf(row.get("FECHA_REGISTRO")));
		            bean.setNombCanl(String.valueOf(row.get("NOMB_CANL")));           
		            bean.setDescEstatus(String.valueOf(row.get("DESC_ESTATUS")));
		            bean.setDescProd(String.valueOf(row.get("DESC_PROD")));
		            bean.setIdProd(String.valueOf(row.get("ID_PROD")));
		            bean.setBuc(String.valueOf(row.get("BUC")));
		            bean.setTotalOper(row.get("TOTAL_OPER", BigDecimal.class).intValue());
		            bean.setTotalMont(row.get("TOTAL_MONT", BigDecimal.class));
		            bean.setIdEstatus((Integer) row.get("ID_ESTATUS"));
		            bean.setMotiRech(String.valueOf(row.get("MOTI_RECH")));
		            bean.setTotalMontFormat(ConsultaTrackingUtil.formateaImporteArchivo((row.get("TOTAL_MONT", BigDecimal.class))));
		            
		            MonitorDeArchivosEnCursoDetallesResponse subTotales  = Util.validaDuplicidadNombreArchivo(datos, row, bean, idArchivoActual, idArchivoAnterior, listBean, numOp, monto);
		            /**Se actualizan los valores de los subtotales*/
		            numOp = subTotales.getTotalOper();
		            monto = subTotales.getTotalMont(); 
		            /**Se agrega el registro de la tabla*/
		            listBean.add(bean);
		            /**Se actualiza el valor de archivo a validar*/
					idArchivoAnterior = idArchivoActual;
					/**Se valida si hay registros pendientes para agregar el subtotal*/
		            
	            }           
            if(numb == 2) {
	        	
            	if(row.get("ID_ESTATUS")!=null && row.get("ID_ESTATUS").toString().matches("^[1-9][0-9]*$")) {
            		bean.setIdEstatus((Integer)row.get("ID_ESTATUS"));       
            	}else {
                	bean.setIdEstatus(0);
                }
            	
            	bean.setIdProd(String.valueOf(row.get("ID_PROD")));
	        	bean.setDescProd(String.valueOf(row.get("DESC_PROD")));
            	bean.setDescEstatus(String.valueOf(row.get("DESC_ESTATUS")));
                bean.setTotalOper(row.get("NUM_OP", BigDecimal.class) != null ? row.get("NUM_OP", BigDecimal.class).intValue() : 0);
                bean.setTotalMont(row.get("IMP_OP", BigDecimal.class));
                listBean.add(bean);
            }
            
        }
        if(!listBean.isEmpty() && numb == 1) {
        	MonitorDeArchivosEnCursoDetallesResponse subTotal = new MonitorDeArchivosEnCursoDetallesResponse();
        	subTotal.setDescProd("TOTAL");
			subTotal.setTotalOper(numOp);
			subTotal.setTotalMont(monto);
			subTotal.setTotalMontFormat(ConsultaTrackingUtil.formateaImporteArchivo(monto));
			listBean.add(subTotal);
        }
        return listBean;
    }
    
    
    /**
     * Metodo para agregar las condiciones pertinentes
     * 
     * @param where
     * @param beanRequest
     * @param params
     */
    public static void completaWhere(StringBuilder where, 
    		MonitorArchivosEnCursoRequest beanRequest, 
    		Map<String, Object> params) {
    	
    	agregaCondicion(where, beanRequest.getBuc(), "AND F.BUC = :buc ", "buc", params);
    	agregaCondicion(where, beanRequest.getNumContrato(), "AND E.NUM_CNTR = :numContrato ", "numContrato", params);
    	agregaCondicion(where, beanRequest.getNombreArch(), "AND UPPER(A.NOMBRE_ARCH) LIKE UPPER(:nomArch) ", "nomArch", params);
    	agregaCondicion(where, beanRequest.getIdProducto(), "AND C.CVE_PROD_OPER = :idProd ", "idProd", params);
    	agregaCondicion(where, beanRequest.getIdEstatus(), "AND A.ID_ESTATUS = :idEstatus ", "idEstatus", params);
    	
        /**Validacion de fechas se amra como parte del where*/
        if (!esVacioNulo(beanRequest.getFechaIni()) && !esVacioNulo(beanRequest.getFechaFin())) {
            where.append(" AND TRUNC(A.FECHA_REGISTRO) BETWEEN ")    
            .append(" TO_DATE(:fechaIni, 'DD/MM/YYYY') ").append("AND TO_DATE(:fechaFin, 'DD/MM/YYYY') ");
            params.put("fechaIni", beanRequest.getFechaIni());
            params.put("fechaFin", beanRequest.getFechaFin());
        }
    }
    
    /**
     * Metodo que agrega parametros a sentencia 
     * @param where String builder con la query
     * @param value valor a evaluar, atributo
     * @param campo como va agregar el campo
     * @param param parametro que agregará 
     * @param params mapa con parametros
     */
    public static void agregaCondicion(StringBuilder where, String value, String campo, String param, Map<String, Object> params) {
        /** Se arma dinamicamente la condicion*/
        if (!esVacioNulo(value)) {
        	where.append(campo);
        	if("nomArch".equals(param)) {
        		params.put(param, "%"+ value +"%");
        	}else {
        		params.put(param, value);
        	}
        }else {
        	where.append("");
        }
    }

    
    private static boolean  esVacioNulo(String value) {
        return !(value != null && !value.isEmpty());
    }
}
