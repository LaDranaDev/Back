package mx.santander.h2h.monitoreo.repository;

public interface IMonitorOperacionesRepository {

}
