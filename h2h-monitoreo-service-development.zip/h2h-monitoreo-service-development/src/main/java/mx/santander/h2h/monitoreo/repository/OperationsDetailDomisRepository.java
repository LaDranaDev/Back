package mx.santander.h2h.monitoreo.repository;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.constants.MonitorOperacionesConstants;
import mx.santander.h2h.monitoreo.model.request.MessageDataBaseRequest;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.util.DetalleOperacionUtils;
import mx.santander.h2h.monitoreo.util.UtilMapeoData;
import mx.santander.h2h.monitoreo.util.UtilsTramaAdicionalesAux;

@Slf4j
@Repository
public class OperationsDetailDomisRepository implements IOperationsDetailDomisRepository {
    @Autowired
    private EntityManager entityManager;

    /**
     * Consulta el detalle de la operacion
     * @param idOperacion - ID de la operacion
     * @return Detalle de la operacion
     */
    @Override
    public OperationsMonitorQueryResponse obtenerDetalleOperacion(String idOperacion, String tabla) {
        String stringQuery = generaConsultaDetalleOperacion(UtilsTramaAdicionalesAux.cleanTable(tabla), idOperacion);
        Query query = entityManager.createNativeQuery(stringQuery, Tuple.class);
//        query.setParameter("idOperacion", idOperacion);

        OperationsMonitorQueryResponse respuesta = new OperationsMonitorQueryResponse();
        respuesta.setProducto("OPERACION_EN_PROCESO");
        for (Object row : query.getResultList()) {
            if (row instanceof Tuple) {
                rellenaRespuestaMonitorOperacionesDTO((Tuple) row, respuesta, idOperacion);
            }
        }

        return respuesta;
    }

    /**
     * Rellena el objeto de tipo RespuestaMonitorOperacionesDTO
     * @param row Map<String, Object>
     * @param respuesta de tipo RespuestaMonitorOperacionesDTO
     */
    protected void rellenaRespuestaMonitorOperacionesDTO(Tuple row, OperationsMonitorQueryResponse respuesta, String idOperacion) {
        respuesta.setIdOperacion(DetalleOperacionUtils.defaultObjectString(row.get("ID_REG"), "0"));
        respuesta.setCodCli(getValue(row, "BUC"));
        respuesta.setCtaCargo(getValue(row, "NUM_CTA_CARGO"));
        respuesta.setCtaAbono(getValue(row, "NUN_CTA_ABONO"));
        // Obtenemos el enmascarado de datos
     	respuesta.setCtaAbono( UtilMapeoData.getMascara(respuesta.getCtaAbono(), "abono") );
        respuesta.setIdProducto(DetalleOperacionUtils.defaultObjectString(row.get("CVE_PROD_OPER"), "0"));
        respuesta.setProducto(getValue(row, "DESC_PROD"));
        respuesta.setNomArch(getValue(row, "NOMBRE_ARCH"));

        respuesta.setReferencia(DetalleOperacionUtils.defaultObjectString(row.get("REFERENCIA"), ""));
        if ("0".equals(respuesta.getReferencia())) {
            respuesta.setReferencia("");
        }

        rellenaDivisas(row, respuesta);

        respuesta.setComentario1(getValue(row, "COMENTARIO_1"));
        respuesta.setComentario2(getValue(row, "COMENTARIO_2"));
        respuesta.setComentario3(getValue(row, "COMENTARIO_3"));
        respuesta.setNombreOrd(Objects.toString(row.get("TITULAR"), null));
        respuesta.setIntermOrd(getValue(row, "INTERMEDIARIO_ORD"));
        respuesta.setIntermRec(getValue(row, "INTERMEDIARIO_REC"));
        respuesta.setModalidad(getValue(row, "MODALIDAD"));
        respuesta.setNombreBenef(getValue(row, "BENEFICIARIO"));
        respuesta.setNumSucursal(getValue(row, "NUM_SUCURSAL"));
        respuesta.setFechaVenc(getFecha(row.get("FECH_VENC")));
        respuesta.setNumOrden(getValue(row, "NUM_ORDEN"));
        respuesta.setTipoPago(getValue(row, "TIPO_PAGO"));
        respuesta.setNumeMovil(getValue(row, "NUME_MOVI"));
        respuesta.setBancoReceptor(MonitorOperacionesConstants.BANCO);
        respuesta.setBancoOrdenante(DetalleOperacionUtils.defaultObjectString(row.get("BANCO_RECEPTOR"), ""));

        respuesta.setMensaje(getValue(row, "MSG_H2H"));
        respuesta.setIdEstatus(DetalleOperacionUtils.defaultObjectString(row.get("ID_ESTATUS"), "0"));

        respuesta.setMensajeOrden(DetalleOperacionUtils.defaultObjectString(row.get("MSG_ORDEN_PAGO"), "0"));
        respuesta.setReferenciaAbono(getValue(row, "REFERENCIA_ABONO"));
        respuesta.setReferenciaCargo(getValue(row, "REFERENCIA_CARGO"));

        respuesta.setNombreEmpleado(getValue(row, "NOMBRE_EMPLEADO"));
        respuesta.setNumEmpleado(getValue(row, "NUMERO_EMPLEADO"));
        respuesta.setBucEmpleado(getValue(row, "BUC_EMPLEADO"));
        respuesta.setRfc(getValue(row, "RFC"));
        respuesta.setNumTarjeta(getValue(row, "NUMERO_TARJETA"));
     // Enmascaramos las Tarjetas
        respuesta.setNumTarjeta( UtilMapeoData.getMascara(respuesta.getNumTarjeta(), "tarjeta") );
        respuesta.setNumeroCuenta(getValue(row, "NUMERO_CUENTA"));
        String sucursal = getValue(row, "SUCURSAL_TUTORA");
        if(StringUtils.isNotEmpty(sucursal) && !"-1".equals(sucursal) && sucursal.length() < 4){
            sucursal = StringUtils.leftPad(sucursal, 4, "0");
        }
        respuesta.setSucTutora(sucursal);
        respuesta.setDescripcion(getValue(row, "DESCRIPCION"));

        if (!respuesta.getModalidad().isEmpty()) {
            respuesta.setModalidad("T".equals(respuesta.getModalidad()) ? "Al momento de hacer la orden" :
                    "Al momento de hacer la liquidaci\u00F3n");
        }
        if (!respuesta.getTipoPago().isEmpty()) {
            respuesta.setTipoPago("E".equals(respuesta.getTipoPago()) ? "E-EFECTIVO" : ("C".equals(respuesta.getTipoPago()) ?
                    "C-CHEQUE" : "OTRO" ));
        }

        if (MonitorOperacionesConstants.MN.equals(respuesta.getDivisaOrd() != null ? respuesta.getDivisaOrd().trim() : respuesta.getDivisaOrd())){
            respuesta.setDivisaOrd(MonitorOperacionesConstants.MXP);
        }
        if("29".equals(respuesta.getIdProducto())) {
            respuesta.setHorarioProg(getValue(row, "HORA_APLI"));
        }
        if ("OPERACION_EN_PROCESO".equals(respuesta.getProducto())){
			respuesta.setMensaje(getH2HMensaje(idOperacion));
		}
    }

    /**
     * Rellena el objeto de tipo RespuestaMonitorOperacionesDTO
     * @param row Map<String, Object>
     * @param respuesta de tipo RespuestaMonitorOperacionesDTO
     */
    protected void rellenaDivisas(Tuple row, OperationsMonitorQueryResponse respuesta){
        DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols();
        formatSymbols.setDecimalSeparator('.');
        formatSymbols.setGroupingSeparator(',');
        final DecimalFormat decimalFormat = new DecimalFormat("###,###,###,###,##0.00", formatSymbols);
        respuesta.setDivisa(getValue(row, "DIVISA"));
        if (MonitorOperacionesConstants.MN.equals(respuesta.getDivisa() != null ? respuesta.getDivisa().trim() : respuesta.getDivisa())){
            respuesta.setDivisa(MonitorOperacionesConstants.MXP);
        } else if (MonitorOperacionesConstants.MXN.equals(respuesta.getDivisa() != null ? respuesta.getDivisa().trim() : respuesta.getDivisa())){
            respuesta.setDivisa(MonitorOperacionesConstants.MXP);
        }

        respuesta.setDivisaOrd(getValue(row, "DIVISA_ORD"));
        if (MonitorOperacionesConstants.MN.equals(respuesta.getDivisaOrd() != null ? respuesta.getDivisaOrd().trim() : respuesta.getDivisaOrd())){
            respuesta.setDivisaOrd(MonitorOperacionesConstants.MXP);
        } else if (MonitorOperacionesConstants.MXN.equals(respuesta.getDivisaOrd() != null ? respuesta.getDivisaOrd().trim() : respuesta.getDivisaOrd())){
            respuesta.setDivisaOrd(MonitorOperacionesConstants.MXP);
        }

        respuesta.setFechaAplic(getFecha(row.get("FECHA_APLICACION")));
        respuesta.setFechaCaptura(getFecha(row.get("FECHA_REGISTRO")));
        respuesta.setFechaLimitPago(getFecha(row.get("FECHA_LIMITE_PAGO")));
        respuesta.setFechaOper(getFecha(row.get("FECHA_OPERACION")) );
        respuesta.setFechaPresIni(getFecha(row.get("FECHA_PRESENTACION_INICIAL")) );

        respuesta.setImporteCargo(row.get(MonitorOperacionesConstants.IMPORTE_CARGO) == null || row.get(MonitorOperacionesConstants.IMPORTE_CARGO).toString().isEmpty() ?
                respuesta.getImporte() : "$" + decimalFormat.format(Double.valueOf(row.get(MonitorOperacionesConstants.IMPORTE_CARGO).toString().trim())));

        respuesta.setEstatus(getValue(row, "DESC_ESTATUS"));
        respuesta.setImporte(row.get(MonitorOperacionesConstants.IMPORTE) == null || row.get(MonitorOperacionesConstants.IMPORTE).toString().trim().isEmpty()
                ? "$0.00" : "$" + decimalFormat.format(Double.valueOf(row.get(MonitorOperacionesConstants.IMPORTE).toString().trim())));
    }

    /**
     * Genera la consulta del detalle de la operacion
     * @return Consulta de detalle de operacion
     */
    protected String generaConsultaDetalleOperacion(String tabla, String idOperacion) {
        log.debug("Preparando consulta de operaciones");
        final StringBuilder query = new StringBuilder();
        query.append("SELECT PROD.* FROM ( ")
        		.append(getConsultaByProducto(true, tabla))
        		.append(" UNION ALL ")
        		.append(getConsultaByProducto(false, tabla))
        		.append(") PROD WHERE PROD.ID_REG = ")
        		.append(idOperacion);
        return query.toString();
    }

    /**
     * Crea el query por producto y si el dlel dia de hoy o el de tres meses
     * @param tresMeses inidca si va suar la tablasd e tres meses  atras
     * @param tabla
     * @return SQL del producto
     */
    protected String getConsultaByProducto(boolean  tresMeses, String tabla){
        final StringBuilder query = new StringBuilder();
        query
                .append("SELECT ")
                .append("ID_REG, CLTE.BUC, REG.CNTA_CARG NUM_CTA_CARGO, ")
                .append("REG.CNTA_ABON NUN_CTA_ABONO, CVE_PROD_OPER, PROD.DESC_PROD, ")
                .append("ARCH.NOMBRE_ARCH, DETA.REFE_SERV_EMIS REFERENCIA, REG.ID_ESTATUS, ")
                .append("EST.DESC_ESTATUS, REG.MONT IMPORTE, CNTR.NUM_CNTR, REG.DIVI DIVISA, ")
                .append("ARCH.FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, ");


        String sqlProdTran = query.toString();
        query.delete(0, sqlProdTran.length());
        sqlProdTran = sqlProdTran.replace("REG.DIVI DIVISA,", "DECODE(DIVI_ABON.CLAV_CAPTA,NULL,REG.DIVI,DIVI_ABON.CLAV_CAPTA) DIVISA, ");
        query
                .append(sqlProdTran)
                .append("'DETA.CLAV_INTE_ORDE' INTERMEDIARIO_ORD, DECODE(DIVI_CARG.CLAV_CAPTA,NULL,REG.DIVI,DIVI_CARG.CLAV_CAPTA) DIVISA_ORD, ")
                .append("'DETA.CLAV_INTER_RECE' INTERMEDIARIO_REC, DECODE(CNTA_ABON.NOMB_TITU,NULL,DETA.RAZN_SOCI_EMSR,CNTA_ABON.NOMB_TITU) BENEFICIARIO, ")
                .append("'DETA.COME_1_CONC_PAGO' COMENTARIO_1, 'DETA.COME_2' COMENTARIO_2, ")
                .append("'DETA.COME_3' COMENTARIO_3, DETA.NOMB_CLTE TITULAR, BNCO.NOMBRE_BANCO BANCO_RECEPTOR, ")
                .append("NULL TIPO_PAGO, NULL MODALIDAD, DETA.IMPO_OPER IMPORTE_CARGO, ")
                .append("MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, ")
                .append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, NULL FECH_VENC,")
                .append("NULL REFERENCIA_ABONO, NULL REFERENCIA_CARGO, ")
                .append("NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, ")
                .append("NULL BUC_EMPLEADO, ")
                .append("NULL SUCURSAL_TUTORA, NULL RFC, ")
                .append("NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, ")
                .append("NULL DESCRIPCION, ");

        query
                .append("REG.FECH_OPER FECHA_PRESENTACION_INICIAL, REG.FECH_ENVI_BACK FECHA_OPERACION, REG.NUME_MOVI, DETA.IMPO_COBR, DETA.IMPO_PEND_COBR ");
        if("H2H_PROD_DOMI_CXH".equals(tabla)) {
            query.append(", TO_CHAR(REG.HORA_APLI,'HH24:MI') HORA_APLI ");
        }
        query.append("FROM ")
                .append(tabla)
                .append(tresMeses ? "_TRAN DETA ": " DETA ")
                .append(" LEFT JOIN H2H_CAT_BNCO BNCO")
                .append(" ON DETA.BNCO_RECE_CLTE = BNCO.CLAVE_BANCO ")
                .append("INNER JOIN ").append(tresMeses ? "H2H_REG_TRAN" : "H2H_REG").append(" REG USING(ID_REG) ")
                .append("INNER JOIN ").append(tresMeses ? "H2H_ARCHIVO_TRAN" : "H2H_ARCHIVO").append(" ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ")
                .append("INNER JOIN H2H_CNTR CNTR USING (ID_CNTR) ")
                .append("INNER JOIN H2H_CLTE CLTE USING (ID_CLTE) ")
                .append("INNER JOIN H2H_CAT_PROD PROD USING(CVE_PROD_OPER) ")
                .append("INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS ");

        query.append("LEFT JOIN H2H_MSG MSG ON MSG.ID_MSG = REG.ID_MSG ");

        query
                .append("LEFT JOIN H2H_CTA_INFO CNTA_ABON ON REG.CNTA_ABON = CNTA_ABON.NUME_CTA AND CNTA_ABON.TIPO_CTA = 'B' ")
                .append("LEFT JOIN H2H_CTA_INFO CNTA_CARG ON REG.CNTA_CARG = CNTA_CARG.NUME_CTA AND CNTA_CARG.TIPO_CTA = 'O' ")
                .append("LEFT JOIN H2H_CAT_DIVISA DIVI_ABON ON DIVI_ABON.CLAV_NUME = DETA.COD_DIVI ")
                .append("LEFT JOIN H2H_CAT_DIVISA DIVI_CARG ON DIVI_CARG.CLAV_NUME = DETA.COD_DIVI ");

        return query.toString();
    }

    /**
     * Retorna la fecha del objeto pasado como parametro.
     * @param obj Object
     * @return String fecha
     */
    protected String getFecha(Object obj) {
        String fecha = StringUtils.EMPTY;
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", new Locale("es", "MX"));
        if (obj instanceof Date || obj instanceof Timestamp) {
            fecha = dateFormat.format(obj);
        }
        if (obj instanceof String) {
            fecha = obj.toString();
        }
        return fecha;
    }

    protected String getValue(Tuple tuple, String key) {
        try {
            return Objects.toString(tuple.get(key), "");
        } catch (IllegalArgumentException e) {
            return "";
        }
    }
    
    /**
	 * Obtiene el mensaje de la operacion
	 * 
	 * @param idOperacion id del mensaje
	 * @return  String - Mensaje de la operacion
	 * @throws ExceptionDataAccess Exception manejada
	 */
	protected String getH2HMensaje(String idOperacion) throws DataAccessException {
		final MessageDataBaseRequest requestMessage = new MessageDataBaseRequest();
		final StringBuilder queryBuild = new StringBuilder();
		queryBuild
			.append("SELECT MSG_H2H FROM H2H_MSG INNER JOIN H2H_REG USING(ID_MSG) WHERE ID_REG = :idOperacion")
			.append(" UNION ALL ")
			.append("SELECT MSG_H2H FROM H2H_MSG INNER JOIN H2H_REG_TRAN USING(ID_MSG) WHERE ID_REG = :idOperacion");
		requestMessage.setCodeOperation("DetalleOperaciones");
		requestMessage.setTypeOperation("QUERY_TYPE");
		requestMessage.setQuery(queryBuild.toString());
		
		
	        Query query = entityManager.createNativeQuery(queryBuild.toString(), Tuple.class);
	        query.setParameter("idOperacion", idOperacion);

	     
	        @SuppressWarnings("unchecked")
			List<Object[]> lstQuery = query.getResultList();
			
			if(!lstQuery.isEmpty()) {
				for (Object row : query.getResultList()) {
		            if (row instanceof Tuple) {
		            	return String.valueOf(getValue((Tuple) row, "MSG_H2H"));
		            }
		        }
			}

			
		return null;
	}

}
