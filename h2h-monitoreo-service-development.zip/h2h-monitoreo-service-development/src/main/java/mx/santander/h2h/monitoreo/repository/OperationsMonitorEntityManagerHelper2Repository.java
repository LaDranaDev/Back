/**
* Santander SCIB - Banco Santander Negocios Globales
* Todos los derechos reservados
* OperationsMonitorEntityManagerHelper2Repository.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <5 jul. 2024 17:44:45>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.repository;

import static mx.santander.h2h.monitoreo.repository.OperationsMonitorEntityManagerRepository.TABLAS;

import java.util.List;
import java.util.Map;

import org.owasp.encoder.Encode;
import org.springframework.stereotype.Repository;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.constants.MonitorOperacionesConstants;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.util.OperMonEntityManHelp1Util;
import mx.santander.h2h.monitoreo.util.UtilData;
import mx.santander.h2h.monitoreo.util.UtilMonitorOperacionesSPID;
import mx.santander.h2h.monitoreo.util.UtilOperationsMonitor;
import mx.santander.h2h.monitoreo.util.UtilOperationsMonitor2;
import mx.santander.h2h.monitoreo.util.UtilOrdenesPagoAtmDatosExportar;
import mx.santander.h2h.monitoreo.util.UtilQuery;
import mx.santander.h2h.monitoreo.util.UtilVostroDatosExportar;

/**
 * OperationsMonitorEntityManagerHelper2Repository.
 *
 * @author Daniel Ruiz
 */
@Slf4j
@Repository
public class OperationsMonitorEntityManagerHelper2Repository
		implements IOperationsMonitorEntityManagerHelper2Repository {
	
	/** Declaracion de Constante SQL_COUNT. */
	private static final String SQL_COUNT = "SELECT COUNT(*) TOTAL FROM (";
	
	
	/**
	 * Genera la consuslta general para contar el numero de registros
	 * 
	 * @param query consulta
	 * @return String de la consulta de conteo del total de registros
	 */
	protected static String getQueryCount(String query) {
		return new StringBuilder().append( SQL_COUNT)
			.append( query )
			.append(")").toString();
	}

	/**
	 * Obtiene los productos a exportar.
	 *
	 * @param consultaOperaciones parametros de la consulta operaciones 
	 * @return String consulta para identicar los productos
	 */
	protected static String getViews(OperationsMonitorQueryRequest consultaOperaciones, 
			final StringBuilder query,
			Map<String, Object> params) {
		final boolean ordenPago = OperationsMonitorEntityManagerHelper3Repository.isOrdenPago(consultaOperaciones);
		final boolean altaMasivaEmpleados = OperationsMonitorEntityManagerHelper3Repository
				.isAltaMasivaEmpleados(consultaOperaciones);
		final boolean pif = UtilData.isPif(consultaOperaciones.getIdProducto());
		final boolean ti = OperationsMonitorEntityManagerHelper3Repository.isTI(consultaOperaciones);
		final boolean pagoDirecto = UtilData.isPagoDirecto(consultaOperaciones.getIdProducto()); // PGODIRECT
		
		// Iniciamos el QUERY de Consulta para Productos
		query.append( MonitorOperacionesConstants.SQLPROD1 )
			.append( MonitorOperacionesConstants.SEL_PROD );
		
		if (OperationsMonitorEntityManagerHelper3Repository.isDateToday(consultaOperaciones.getFechaInicial())) {
			log.info("*****MIGAJA  I*****");
			if (pif) {
				OperMonEntityManHelp1Util.getselectImpFed(true, query, consultaOperaciones.getIdProducto());
			} else if (ti) {
				UtilOperationsMonitor.getselectTransfInter(true, query, consultaOperaciones.getIdProducto());
			} else if (UtilMonitorOperacionesSPID.esProductoActivo(consultaOperaciones.getIdProducto())) {
				UtilMonitorOperacionesSPID.getselectSPID(query, true);
			} else if (pagoDirecto) {
				getSelectConsultaOperacionesPagoDirecto(query, true); // PGODIRECT
			} else if (ordenPago) {
				OperMonEntityManHelp1Util.getSelectConsultaOperacionesOrdenPago(query, true);
			} else if (altaMasivaEmpleados) {
				OperMonEntityManHelp1Util.getSelectConsultaOperacionesAltaMasivaEmpleados(query, true);
			} else {
				OperMonEntityManHelp1Util.getSelectConsultaOperaciones(consultaOperaciones, true, query, params);
			}
			query.append(MonitorOperacionesConstants.TABLA_PROD);
			OperationsMonitorEntityManagerHelper1Repository.getWhereConsultaOperaciones(consultaOperaciones, query, params, false);
			
			query.append(MonitorOperacionesConstants.TABLA_PROD);
			
		} else {
			log.info("*****MIGAJA  J ii *****");
			if (pif) {
				OperMonEntityManHelp1Util.getselectImpFed(false, query, consultaOperaciones.getIdProducto());
			} else if (ti) {
				UtilOperationsMonitor.getselectTransfInter(false, query, consultaOperaciones.getIdProducto());
			} else if (UtilMonitorOperacionesSPID.esProductoActivo(consultaOperaciones.getIdProducto())) {
				UtilMonitorOperacionesSPID.getselectSPID(query, true);
			} else if (pagoDirecto) {
				getSelectConsultaOperacionesPagoDirecto(query, false); // PGODIRECT
			} else if (ordenPago) {
				OperMonEntityManHelp1Util.getSelectConsultaOperacionesOrdenPago(query, false);
			} else if (altaMasivaEmpleados) {
				OperMonEntityManHelp1Util.getSelectConsultaOperacionesAltaMasivaEmpleados(query, false);
			} else {
				OperMonEntityManHelp1Util.getSelectConsultaOperaciones(consultaOperaciones, false, query, params);
			}
			query.append(MonitorOperacionesConstants.TABLA_PROD);
			OperationsMonitorEntityManagerHelper1Repository.getWhereConsultaOperaciones(consultaOperaciones, query, params, false);
			query.append( MonitorOperacionesConstants.UNION_ALL)
			.append(MonitorOperacionesConstants.SEL_PROD);
			if (pif) {
				OperMonEntityManHelp1Util.getselectImpFed(true, query, consultaOperaciones.getIdProducto());
			} else if (ti) {
				UtilOperationsMonitor.getselectTransfInter(true, query, consultaOperaciones.getIdProducto());
			} else if (UtilMonitorOperacionesSPID.esProductoActivo(consultaOperaciones.getIdProducto())) {
				UtilMonitorOperacionesSPID.getselectSPID(query, true);
			} else if (pagoDirecto) {
				getSelectConsultaOperacionesPagoDirecto(query, true); // PGODIRECT
			} else if (ordenPago) {
				OperMonEntityManHelp1Util.getSelectConsultaOperacionesOrdenPago(query, true);
			} else if (altaMasivaEmpleados) {
				OperMonEntityManHelp1Util.getSelectConsultaOperacionesAltaMasivaEmpleados(query, true);
			} else {
				OperMonEntityManHelp1Util.getSelectConsultaOperaciones(consultaOperaciones, true, query, params);
			}
			query.append(MonitorOperacionesConstants.TABLA_PROD);
			OperationsMonitorEntityManagerHelper1Repository.getWhereConsultaOperaciones(consultaOperaciones, query, params, false);
			query.append(MonitorOperacionesConstants.TABLA_PROD);
		}
		return query.toString();
	}

	
	/**
	 * Obtiene operaciones por producto.
	 *
	 * @param views               nombres de las vistas de productos
	 * @param consultaOperaciones el parametro consulta operaciones
	 * @return String de la cosnulta de las poeraciones por producto
	 */
	protected static String getConsultaExportar(List<String> views, 
			OperationsMonitorQueryRequest consultaOperaciones, 
			final StringBuilder query,
			Map<String, Object> params
			) {
		boolean union = false;

		// Iniciamos proceso de la Vista getArchTemp --------------
		getArchTemp(consultaOperaciones, query, params);
		
		// Validamos que contenga datos
		query.append( MonitorOperacionesConstants.SQLPRODVIEW1 );
		for (String view : views) {
			if (union) {
				query.append(MonitorOperacionesConstants.SQLUNIONALL);
			}
			getConsultaByProducto(view, consultaOperaciones, query, params);
			union = true;
		}
		// Fin del QUERY
		query.append(MonitorOperacionesConstants.TABLA_PROD2);
		query.append(MonitorOperacionesConstants.TABLA_PRODFIN);
		return query.toString();
	}

	/**
	 * Metodo par crear un tabla temporal de las operaciones que se van a consultar
	 * 
	 * @param consultaOperaciones opciones de la consulta
	 * @return String de la tabla temporal
	 */
	protected static void getArchTemp(
			OperationsMonitorQueryRequest consultaOperaciones, 
			final StringBuilder query, 
			Map<String, Object> params) {
		query.append("WITH TEMP_ARCH AS (");
		if (OperationsMonitorEntityManagerHelper3Repository.isDateToday(consultaOperaciones.getFechaInicial())) {
			query.append(
				MonitorOperacionesConstants.SERCH_ARCH_TMP)
				.append(", id_arch_be ") // PGODIRECT
				.append("FROM H2H_REG_TRAN REG ")
				.append("INNER JOIN H2H_ARCHIVO_TRAN ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ")
				.append("INNER JOIN H2H_CAT_CANL CANL ON ARCH.ID_CANL = CANL.ID_CANL ");
		} else {
			query.append(MonitorOperacionesConstants.SERCH_ARCH_TMP )
				.append(", id_arch_be ") // PGODIRECT
				.append(MonitorOperacionesConstants.H2H_REG_TABLE)
				.append("INNER JOIN H2H_ARCHIVO ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ")
				.append("INNER JOIN H2H_CAT_CANL CANL ON ARCH.ID_CANL = CANL.ID_CANL ")
				// Agregamos las Restricciones del Rango de Fechas
				.append(MonitorOperacionesConstants.CONS_RANGO_FECHA);
				// unimos la cadena
			query.append( MonitorOperacionesConstants.UNION_ALL);
			query.append(MonitorOperacionesConstants.SERCH_ARCH_TMP )
				.append(", id_arch_be ") // PGODIRECT
				.append(MonitorOperacionesConstants.H2H_REG_TRAN_TABLE)
				.append("INNER JOIN H2H_ARCHIVO_TRAN ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ")
				.append("INNER JOIN H2H_CAT_CANL CANL ON ARCH.ID_CANL = CANL.ID_CANL ");
		}
		// Agregamos las Restricciones del Rango de Fechas
		query.append(MonitorOperacionesConstants.CONS_RANGO_FECHA);
		query.append(") ");

		params.put("fechaInicial", consultaOperaciones.getFechaInicial() + MonitorOperacionesConstants.HORARIOINICIAL);
		params.put("fechaFinal", consultaOperaciones.getFechaFinal() + MonitorOperacionesConstants.HORARIOFINAL);
	}

	/**
	 * Crea el query por producto y si el dlel dia de hoy o el de tres meses
	 * 
	 * @param cveOperProd         clave del producto
	 * @param consultaOperaciones DTO de restricciones
	 * @return SQL del producto
	 */
	protected static void getConsultaByProducto(String cveOperProd, 
			OperationsMonitorQueryRequest consultaOperaciones, 
			final StringBuilder query,
			Map<String, Object> params) {
		final String tablaProd = cveOperProd;
		
		// Iniciamos proceso de construccion de Query -----------
		cveOperProd = TABLAS.get(tablaProd);
		query.append("SELECT PROD.* FROM (SELECT NOMB_CANL, ")
			.append("ID_REG, CLTE.BUC, TMP.CNTA_CARG NUM_CTA_CARGO, ");
		// Llamamos al metodo de Validacion
		UtilOperationsMonitor2.getCadValidacion(query, cveOperProd);
		query.append("TMP.ID_ESTATUS, ")
			.append("EST.DESC_ESTATUS, TMP.MONT IMPORTE, CNTR.NUM_CNTR, TMP.DIVI DIVISA, ")
			.append("TMP.FECHA_REGISTRO, TMP.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, ");
		// Agregamos otras validaciones
		UtilOperationsMonitor2.getValidacionCve(query, cveOperProd);
		query.append("TMP.FECH_OPER FECHA_PRESENTACION_INICIAL, TMP.FECH_ENVI_BACK FECHA_OPERACION ");
		//}
		query.append( UtilVostroDatosExportar.getQuerySelectExportar(cveOperProd, query) );
		query.append( UtilOrdenesPagoAtmDatosExportar.getQuerySelectExportar(cveOperProd, query) );
			 
		if (!TABLAS.containsKey(tablaProd)) {
			query.append("FROM (SELECT TMP.* FROM TEMP_ARCH TMP WHERE TMP.CVE_PROD_OPER NOT IN(")
				.append(":lstTablas)) TMP ");
			params.put("lstTablas", TABLAS.toString());
		} else {
			query.append("FROM TEMP_ARCH TMP INNER JOIN (SELECT * FROM ");
			if (OperationsMonitorEntityManagerHelper3Repository.isDateToday(consultaOperaciones.getFechaInicial())) {
				query.append(tablaProd)
					.append("_TRAN ) DETA USING (ID_REG) ");
			} else {
				query.append(tablaProd)
					.append("_TRAN UNION ALL SELECT * FROM ")
					.append(tablaProd)
					.append(") DETA USING (ID_REG) ");
			}
		}
		
		log.info("*****MIGAJA 4 *****");
		query.append( addINNERS() )
			.append(UtilVostroDatosExportar.addInnerVostro(cveOperProd));
		
		log.info("*****consultaOperaciones.getCveProveedor()*****"
			+ Encode.forJava(consultaOperaciones.getCveProveedor())
			+ "\n*****consultaOperaciones.getTipOperacion()*****"
			+ Encode.forJava(consultaOperaciones.getTipOperacion()));

		UtilOperationsMonitor.completaConsultaByProducto(cveOperProd, consultaOperaciones, query, params);
		
		query.append(MonitorOperacionesConstants.TABLA_PROD);
		OperationsMonitorEntityManagerHelper1Repository.getWhereConsultaOperaciones(consultaOperaciones, query, params, true);
	}
	
	
	/***
	 * metodo de ayuda para concatenar los inners faltantes
	 * @return string de inner joins
	 */
	private static String addINNERS() {
		return new StringBuffer()
			.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CNTR_CNTR_USING_ID_CNTR)
			.append("INNER JOIN H2H_CLTE CLTE USING (ID_CLTE)  ")
			.append("INNER JOIN H2H_CAT_PROD PROD ON TMP.CVE_PROD_OPER=PROD.CVE_PROD_OPER  ")
			.append("INNER JOIN H2H_CAT_ESTATUS EST ON TMP.ID_ESTATUS = EST.ID_CAT_ESTATUS ")
			.append("LEFT JOIN H2H_MSG MSG ON MSG.ID_MSG = TMP.ID_MSG ").toString();
	}
	

	/**
	 * Consulta para obtener el numero de correos enviados
	 * 
	 * @param consultaOperaciones parametros de la consulta
	 * @return String consulta de los correos enviados
	 */
	protected static void getCorreosEnvQuery(OperationsMonitorQueryRequest consultaOperaciones, StringBuilder query, 
			Map<String, Object> params) {
		boolean ordenPago = OperationsMonitorEntityManagerHelper3Repository.isOrdenPago(consultaOperaciones);
		boolean altaMasivaEmpleados = OperationsMonitorEntityManagerHelper3Repository.isAltaMasivaEmpleados(consultaOperaciones);
		boolean pif = UtilData.isPif(consultaOperaciones.getIdProducto());
		boolean ti = OperationsMonitorEntityManagerHelper3Repository.isTI(consultaOperaciones);
		boolean pagoDirecto = UtilData.isPagoDirecto(consultaOperaciones.getIdProducto());
		
		if (OperationsMonitorEntityManagerHelper3Repository.isDateToday(consultaOperaciones.getFechaInicial())) {
			log.info("*****MIGAJA  E*****");
			query.append("SELECT NVL(SUM(PROD.NUM_EMAIL),0) TOTAL FROM (").append(MonitorOperacionesConstants.SEL_PROD);
			if (pif) {
				OperMonEntityManHelp1Util.getselectImpFed(true, query, consultaOperaciones.getIdProducto());
			} else if (ti) {
				OperationsMonitorEntityManagerHelper1Repository.getselectTransfInter(true, query, consultaOperaciones.getIdProducto());
			} else if (pagoDirecto) {
				OperationsMonitorEntityManagerHelper1Repository.getSelectConsultaOperacionesPagoDirecto(query, true);
			} else if (ordenPago) {
				OperationsMonitorEntityManagerHelper1Repository.getSelectConsultaOperacionesPagoDirecto(query, true);
			} else if (altaMasivaEmpleados) {
				OperMonEntityManHelp1Util.getSelectConsultaOperacionesAltaMasivaEmpleados(query, true);
			} else {
				OperMonEntityManHelp1Util.getSelectConsultaOperaciones(consultaOperaciones, true, query, params);
			}
			query.append(MonitorOperacionesConstants.TABLA_PROD);
			OperationsMonitorEntityManagerHelper1Repository.getWhereConsultaOperaciones(consultaOperaciones, query, params, false);
			query.append(MonitorOperacionesConstants.TABLA_PROD);
		} else {
			log.info("*****MIGAJA  F ii*****");
			query.append("SELECT NVL(SUM(PROD.NUM_EMAIL),0) TOTAL FROM (").append(MonitorOperacionesConstants.SEL_PROD);
			if (pif) {
				OperMonEntityManHelp1Util.getselectImpFed(false, query, consultaOperaciones.getIdProducto());
			} else if (ti) {
				OperationsMonitorEntityManagerHelper1Repository.getselectTransfInter(false, query, consultaOperaciones.getIdProducto());
			} else if (pagoDirecto) {
				OperationsMonitorEntityManagerHelper1Repository.getSelectConsultaOperacionesPagoDirecto(query, false);
			} else if (ordenPago) {
				OperationsMonitorEntityManagerHelper1Repository.getSelectConsultaOperacionesPagoDirecto(query, false);
			} else if (altaMasivaEmpleados) {
				OperMonEntityManHelp1Util.getSelectConsultaOperacionesAltaMasivaEmpleados(query, false);
			} else {
				OperMonEntityManHelp1Util.getSelectConsultaOperaciones(consultaOperaciones, false, query, params);
			}
			query.append(MonitorOperacionesConstants.TABLA_PROD);
			OperationsMonitorEntityManagerHelper1Repository.getWhereConsultaOperaciones(consultaOperaciones, query, params, false);
			query.append( MonitorOperacionesConstants.UNION_ALL)
				.append(MonitorOperacionesConstants.SEL_PROD);
			if (pif) {
				OperMonEntityManHelp1Util.getselectImpFed(true, query, consultaOperaciones.getIdProducto());
			} else if (ti) {
				OperationsMonitorEntityManagerHelper1Repository.getselectTransfInter(true, query, consultaOperaciones.getIdProducto());
			} else if (pagoDirecto) {
				OperationsMonitorEntityManagerHelper1Repository.getSelectConsultaOperacionesPagoDirecto(query, true);
			} else if (ordenPago) {
				OperationsMonitorEntityManagerHelper1Repository.getSelectConsultaOperacionesPagoDirecto(query, true);
			} else if (altaMasivaEmpleados) {
				OperMonEntityManHelp1Util.getSelectConsultaOperacionesAltaMasivaEmpleados(query, true);
			} else {
				OperMonEntityManHelp1Util.getSelectConsultaOperaciones(consultaOperaciones, true, query, params);
			}
			query.append(MonitorOperacionesConstants.TABLA_PROD);
			
			OperationsMonitorEntityManagerHelper1Repository.getWhereConsultaOperaciones(consultaOperaciones, query, params, false);
			query.append(MonitorOperacionesConstants.TABLA_PROD);
		}
	}

	/**
	 * Genera laconsulta para la conteo de archivos
	 * 
	 * @param consultaOperaciones opciones para la consulta.
	 * @return String de la cosnulta de coenteo de archivos
	 */
	protected static void getCountArchivos(OperationsMonitorQueryRequest consultaOperaciones, 
			StringBuilder query, Map<String, Object> params) {
		log.info("Preparando consulta de operaciones - numero de archivos");
		
		if (OperationsMonitorEntityManagerHelper3Repository.isDateToday(consultaOperaciones.getFechaInicial())) {
			log.info("*****MIGAJA  G*****");
			query.append("SELECT DISTINCT PROD.NOMBRE_ARCH FROM (").append(MonitorOperacionesConstants.SEL_PROD);
			// Agregamos los datos de la consulta
			OperMonEntityManHelp1Util.validaciones(consultaOperaciones, query, params, "countArchivo", true);
			// -----------------------
			query.append(MonitorOperacionesConstants.TABLA_PROD);
			OperationsMonitorEntityManagerHelper1Repository.getWhereConsultaOperaciones(consultaOperaciones, query, params, false);
			query.append(MonitorOperacionesConstants.TABLA_PROD);
		} else {
			query.append("SELECT DISTINCT PROD.NOMBRE_ARCH FROM (")
				.append(MonitorOperacionesConstants.SEL_PROD);
			
			// Agregamos los datos de la consulta
			OperMonEntityManHelp1Util.validaciones(consultaOperaciones, query, params, "countArchivo", false);
			// ------------------------------
			query.append(MonitorOperacionesConstants.TABLA_PROD);
			OperationsMonitorEntityManagerHelper1Repository.getWhereConsultaOperaciones(consultaOperaciones, query, params, false);
			query.append( MonitorOperacionesConstants.UNION_ALL ).append(MonitorOperacionesConstants.SEL_PROD);
			
			// Agregamos los datos de la consulta
			OperMonEntityManHelp1Util.validaciones(consultaOperaciones, query, params, "countArchivo", true);
			// ------------------------------
			query.append(MonitorOperacionesConstants.TABLA_PROD);
			OperationsMonitorEntityManagerHelper1Repository.getWhereConsultaOperaciones(consultaOperaciones, query, params, false);
			query.append(MonitorOperacionesConstants.TABLA_PROD);
		}
	}

	/**
	 * Obtiene importe global query.
	 *
	 * @param consultaOperaciones el parametro consulta operaciones
	 * @return importe global query
	 */
	protected static void getImporteGlobalQuery(OperationsMonitorQueryRequest consultaOperaciones,
			StringBuilder query, Map<String, Object> params) {
		// Iniciamos las validaciones del proceso ----------
		if (OperationsMonitorEntityManagerHelper3Repository.isDateToday(consultaOperaciones.getFechaInicial())) {
			log.info("*****MIGAJA  C*****");
			query.append("SELECT NVL(SUM(CASE WHEN PROD.IMPORTE >= 0 THEN PROD.IMPORTE ELSE 0 END),0) AS IMPORTE_GLOBAL FROM (")
				.append(MonitorOperacionesConstants.SEL_PROD);
			
			OperMonEntityManHelp1Util.validaciones(consultaOperaciones, query, params, "SelectConsult", true);
			
			query.append(MonitorOperacionesConstants.TABLA_PROD);
			OperationsMonitorEntityManagerHelper1Repository.getWhereConsultaOperaciones(consultaOperaciones, query, params, false);
			
			query.append(MonitorOperacionesConstants.TABLA_PROD);
		} else {
			query.append(
					"SELECT NVL(SUM(CASE WHEN PROD.IMPORTE >= 0 THEN PROD.IMPORTE ELSE 0 END),0) AS IMPORTE_GLOBAL FROM (")
					.append(MonitorOperacionesConstants.SEL_PROD);
			
			OperMonEntityManHelp1Util.validaciones(consultaOperaciones, query, params, "SelectConsult", false);
			
			query.append(MonitorOperacionesConstants.TABLA_PROD);
			OperationsMonitorEntityManagerHelper1Repository.getWhereConsultaOperaciones(consultaOperaciones, query, params, false);
			query.append(MonitorOperacionesConstants.UNION_ALL).append(MonitorOperacionesConstants.SEL_PROD);
			
			OperMonEntityManHelp1Util.validaciones(consultaOperaciones, query, params, "SelectConsult", true);
			
			query.append(MonitorOperacionesConstants.TABLA_PROD);
			OperationsMonitorEntityManagerHelper1Repository.getWhereConsultaOperaciones(consultaOperaciones, query, params, false); 
			query.append(MonitorOperacionesConstants.TABLA_PROD);
		}
	}

	/**
	 * Genera la consulta de las operaciones de pago directo
	 * 
	 * @param delDia indica si se usan las tablas del diario
	 * @return String con la consulta
	 */
	public static String getSelectConsultaOperacionesPagoDirecto(StringBuilder query, boolean delDia) { // Inicia PGODIRECT
		StringBuilder qryPagD = new StringBuilder();
		log.info("*****MIGAJA PD *****");
		qryPagD.append(UtilQuery.selectRegTabla(delDia))
		.append(MonitorOperacionesConstants.REG_ID_REG_CLTE_BUC_REG_CNTA_CARG_NUM_CTA_CARGO)
		.append(MonitorOperacionesConstants.REG_CNTA_ABON_NUN_CTA_ABONO_CVE_PROD_OPER_PROD_DESC_PROD)
		.append(MonitorOperacionesConstants.ARCH_NOMBRE_ARCH_REG_REFE_BE_REFERENCIA_REG_ID_ESTATUS)
		.append(MonitorOperacionesConstants.EST_DESC_ESTATUS_REG_MONT_IMPORTE_CNTR_NUM_CNTR_REG_DIVI_DIVISA)
		.append(" ARCH.FECHA_REGISTRO, PAGO.FECH_LIBE FECHA_APLICACION, PROD.VIST_PROD, REG.NUM_EMAIL, ")
		.append("CANL.NOMB_CANL, ")
		.append("PAGO.NO_ORDEN NUM_ORDEN, PAGO.NOM_BENE BENEFICIARIO ")
		.append(UtilQuery.fromH2hArchivo(delDia))
		.append(UtilQuery.innerJoinH2hReg(delDia))
		.append(" INNER JOIN H2H_CNTR CNTR USING (ID_CNTR) ")
		.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CLTE)
		.append(MonitorOperacionesConstants.PART_QUERY_SELECT_INNER_CAT_PROD)
		.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CAT_ESTATUS_EST_ON_REG_ID_ESTATUS_EST_ID_CAT_ESTATUS)
		.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CAT_CANL)
		.append(UtilQuery.innerJoinPagoDirecto(delDia));
		return qryPagD.toString();
	} // Fin PGODIRECT
}
