package mx.santander.h2h.monitoreo.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.response.CampoAdicionalBean;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class UtilsTramaAdicionalesAux {
	/**
	 * Metodo que realiza la generacion de unalista de beanes de campos adicionales
	 * 
	 * @param datosRefe string con los datos adicionales
	 * @return List<CampoAdicionalBean> lista de beanes de campos adicionales
	 */
	public static List<CampoAdicionalBean> generarListaCPA(String datosRefe) {
		List<CampoAdicionalBean> cpAdicionales = new ArrayList<CampoAdicionalBean>();
		String[] arrayCampos = datosRefe.split(Pattern.quote("|"));
		for (int i = 0; i < arrayCampos.length; i += 2) {
			CampoAdicionalBean bean = new CampoAdicionalBean();
			bean.setCampo(arrayCampos[i]);
			bean.setValue(arrayCampos[i + 1]);
			cpAdicionales.add(bean);
		}
		return cpAdicionales;
	}

	/**
	 * Metodo que realiza la generacion de la trama de campos adicionales
	 * 
	 * @param cpAdicionales Lista de campos adicionales
	 * @return String con los campos adicionales
	 */
	public static String getTramaCamposAdicionales(List<CampoAdicionalBean> cpAdicionales) {
		StringBuilder builder = new StringBuilder();
		builder.append("");
		if (cpAdicionales.size() > 0) {
			for (CampoAdicionalBean field : cpAdicionales) {
				if (!"".equals(builder.toString())) {
					builder.append("|");
				}
				builder.append(field.getCampo()).append("|").append(field.getValue());
			}
		}
		return builder.toString();
	}

	/**
	 * Metodo para limpiar la tabla
	 * 
	 * @param table Tabla
	 * @return Nombre de la tabla
	 */
	public static String cleanTable(String table) {
		String uppercase = table.toUpperCase();
		if ("H2H_REG_TRAN".equals(uppercase)) {
			return "H2H_REG_TRAN";
		} else if ("H2H_REG".equals(uppercase)) {
			return "H2H_REG";
		} else if ("H2H_MX_PROD_SPID_TRAN".equals(uppercase)) {
			return "H2H_MX_PROD_SPID_TRAN";
		} else if ("H2H_MX_PROD_SPID".equals(uppercase)) {
			return "H2H_MX_PROD_SPID";
		} else if ("H2H_PROD_DOMI_TRAN".equals(uppercase)) {
			return "H2H_PROD_DOMI_TRAN";
		} else if ("H2H_PROD_DOMI".equals(uppercase)) {
			return "H2H_PROD_DOMI";
		} else if ("H2H_PROD_DOMI_CXH_TRAN".equals(uppercase)) {
			return "H2H_PROD_DOMI_CXH_TRAN";
		} else if ("H2H_PROD_DOMI_CXH".equals(uppercase)) {
			return "H2H_PROD_DOMI_CXH";
		} else {
			throw new BusinessException("Tabla desconocida: " + table);
		}
	}
	
	/**
	 * Metodo que agrega a la consulta principal los campos de CFDI.
	 * 
	 * @param tresMeses boolean 
	 * @return String con los campos de la tabla principal si tresMeses es true
	 * o con los campos de un join a otra tabla.
	 */
	public static String addCfdiFieldsToQuery(boolean tresMeses) {
		StringBuilder stringBuilder = new StringBuilder();
		return tresMeses ?
				stringBuilder
				.append("DETA.ID_REG ID_REG_CONFIRMING,")
				.append("DETA.FECH_EMIS,")
				.append("DETA.NUM_DOC_NET,")
				.append("DETA.CLAV_PROV,")
				.append("DETA.NUM_CONT_CONF,")
				.append("DETA.TIPO_DOCU,")
				.append("DETA.NUM_DOCU,")
				.append("DETA.CONC_PAGO,")
				.append("DETA.COD_TIPO_PAGO,")
				.append("DETA.REFE_H2H,")
				.append("DETA.BASE_RET_ISR,")
				.append("DETA.TASA_RET_ISR,")
				.append("DETA.RET_ISR,")
				.append("DETA.BASE_RET_IEPS_TASA,")
				.append("DETA.TASA_RET_IEPS,")
				.append("DETA.RET_IEPS_TASA,")
				.append("DETA.BASE_RET_IVA,")
				.append("DETA.TASA_RET_IVA,")
				.append("DETA.RET_IVA,")
				.append("DETA.BASE_RET_IEPS_CUOT,")
				.append("DETA.CUOT_RET_IEPS,")
				.append("DETA.RET_IEPS_CUOT,")
				.append("DETA.BASE_RET_ISR_CUOT,")
				.append("DETA.CUOT_RET_ISR,")
				.append("DETA.RET_ISR_CUOT,")
				.append("DETA.BASE_IEPS_COUT,")
				.append("DETA.COUT_IEPS,")
				.append("DETA.MONT_IEPS_CUOT,")
				.append("DETA.TRSL_IEPS,")
				.append("DETA.BASE_IEPS_TASA,")
				.append("DETA.TASA_IEPS,")
				.append("DETA.MONT_IEPS_TASA,")
				.append("DETA.BASE_IVA_16,")
				.append("DETA.IVA_16,")
				.append("DETA.BASE_IVA_8,")
				.append("DETA.IVA_8,")
				.append("DETA.BASE_IVA_0,")
				.append("DETA.IVA_0,")
				.append("DETA.BASE_IVA_EX,")
				.append("DETA.IVA_EX,").toString()
				: 
					stringBuilder
					.append("ALTA_PAGO.ID_REG ID_REG_CONFIRMING,")
					.append("ALTA_PAGO.FECH_EMIS,")
					.append("ALTA_PAGO.NUM_DOC_NET,")
					.append("ALTA_PAGO.CLAV_PROV,")
					.append("ALTA_PAGO.NUM_CONT_CONF,")
					.append("ALTA_PAGO.TIPO_DOCU,")
					.append("ALTA_PAGO.NUM_DOCU,")
					.append("ALTA_PAGO.CONC_PAGO,")
					.append("ALTA_PAGO.COD_TIPO_PAGO,")
					.append("ALTA_PAGO.REFE_H2H,")
					.append("ALTA_PAGO.BASE_RET_ISR,")
					.append("ALTA_PAGO.TASA_RET_ISR,")
					.append("ALTA_PAGO.RET_ISR,")
					.append("ALTA_PAGO.BASE_RET_IEPS_TASA,")
					.append("ALTA_PAGO.TASA_RET_IEPS,")
					.append("ALTA_PAGO.RET_IEPS_TASA,")
					.append("ALTA_PAGO.BASE_RET_IVA,")
					.append("ALTA_PAGO.TASA_RET_IVA,")
					.append("ALTA_PAGO.RET_IVA,")
					.append("ALTA_PAGO.BASE_RET_IEPS_CUOT,")
					.append("ALTA_PAGO.CUOT_RET_IEPS,")
					.append("ALTA_PAGO.RET_IEPS_CUOT,")
					.append("ALTA_PAGO.BASE_RET_ISR_CUOT,")
					.append("ALTA_PAGO.CUOT_RET_ISR,")
					.append("ALTA_PAGO.RET_ISR_CUOT,")
					.append("ALTA_PAGO.BASE_IEPS_COUT,")
					.append("ALTA_PAGO.COUT_IEPS,")
					.append("ALTA_PAGO.MONT_IEPS_CUOT,")
					.append("ALTA_PAGO.TRSL_IEPS,")
					.append("ALTA_PAGO.BASE_IEPS_TASA,")
					.append("ALTA_PAGO.TASA_IEPS,")
					.append("ALTA_PAGO.MONT_IEPS_TASA,")
					.append("ALTA_PAGO.BASE_IVA_16,")
					.append("ALTA_PAGO.IVA_16,")
					.append("ALTA_PAGO.BASE_IVA_8,")
					.append("ALTA_PAGO.IVA_8,")
					.append("ALTA_PAGO.BASE_IVA_0,")
					.append("ALTA_PAGO.IVA_0,")
					.append("ALTA_PAGO.BASE_IVA_EX,")
					.append("ALTA_PAGO.IVA_EX,").toString();
	}

}
