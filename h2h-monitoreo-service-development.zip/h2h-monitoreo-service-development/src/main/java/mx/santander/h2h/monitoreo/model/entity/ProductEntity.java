package mx.santander.h2h.monitoreo.model.entity;

import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;

/**
 * Entidad para la tabla H2H_CAT_PROD.
 *
 * @author Jesus Soto Aguilar
 * @since 13/04/2023
 */
@Entity
@Getter
@Setter
@Table(name = "H2H_CAT_PROD")
public class ProductEntity implements Serializable {

	/**
	 * Id generado automaticamente para la serializacion del objeto
	 */
	private static final long serialVersionUID = -3038625406615101522L;

	/**
	 * Id del producto
	 */
	@Id
	@Column(name = "ID_PROD")
	private Long id;

	/**
	 * Descripcion del producto
	 */
	@Column(name = "DESC_PROD")
	private String descripcion;

	/**
	 * Define si el producto va a manejar algun tipo de cargo
	 */
	@Column(name = "BAND_TIPO_CARGO")
	private String bandTipoCargo;
	/**
	 * Define si en el producto aplica alguna vigencia
	 */
	@Column(name = "BAND_VIGENCIA")
	private String bandVigencia;

	/**
	 * Define si en el producto se va a manejar el envio de email
	 */
	@Column(name = "BAND_EMAIL")
	private String bandEmail;

	/**
	 * Define si el producto va a manejar reintentos
	 */
	@Column(name = "BAND_REINTENTOS")
	private String bandReintentos;

	/**
	 * Aplica contratos confirming
	 */
	@Column(name = "BAND_CONFIRMING")
	private String bandConfirming;

	/**
	 * Id del catalogo de backEnd
	 */
	@Column(name = "ID_BACK")
	private Long idBack;

	/**
	 * Clave del producto de usuario
	 */
	@Column(name = "CVE_PROD")
	private String cveProd;

	/**
	 * Tiempo maximo en minutos para un archivo enviado a backend de este producto.
	 */
	@Column(name = "UMBRAL")
	private Long umbral;

	/**
	 * Visibilidad del producto.
	 */
	@Column(name = "VISIBILIDAD")
	private Character visibilidad;

	/**
	 * Indicador de si el producto se encuentra activo.
	 */
	@Column(name = "BAND_ACTIVO")
	private String bandActivo;

	/**
	 * Clave del producto de operacion
	 */
	@Column(name = "CVE_PROD_OPER")
	private String cveProdOper;

	/**
	 * Codigo de la operación de cargos del producto.
	 */
	@Column(name = "CODI_OPER_CARG")
	private String codiOperCarg;

	/**
	 * Codigo de la operación de abonos del producto.
	 */
	@Column(name = "CODI_OPER_ABON")
	private String codiOperAbon;

	/**
	 * Numero de Dias a sumar a la fecha operación respecto a la fecha del sistema.
	 */
	@Column(name = "DIAS_FEC_OPER")
	private Integer diasFecOper;

	/**
	 * Numero de Dias a sumar a la fecha transferencia respecto a la fecha del sistema.
	 */
	@Column(name = "DIAS_FEC_TRAN")
	private Integer diasFecTran;

	/**
	 * Numero de Dias a sumar a la fecha aplicacion respecto a la fecha del sistema.
	 */
	@Column(name = "DIAS_FEC_APLI")
	private Integer diasFecApli;

	/**
	 * CLACON para el cobro de comisión a nivel de producto.
	 */
	@Column(name = "CODI_OPER_COMI")
	private String codiOperComi;

	/**
	 * Bandera que indica que si el producto se debe mostrar en consulta.
	 * A-Activo mostrar, I-Inactivo mostrar.
	 */
	@Column(name = "BAND_VISI_CONS")
	private Character bandVisiCons;

	/**
	 * Nombre de la vista del producto correspondiente.
	 */
	@Column(name = "VIST_PROD")
	private String visitProd;

	/**
	 * Indica como se considera el producto para la comision.
	 * N - No se consiedera.
	 * P - Por Producto.
	 * A - Ambas (libres y por producto).
	 * C - Es el producto Comision H2H.
	 */
	@Column(name = "BAND_COMISION")
	private Character bandComision;

	/**
	 * Hora maxima para operar con el producto.
	 */
	@Column(name = "HORA_MAX_OPERA")
	private Long horaMaxOpera;

}
