/**
* Santander SCIB - Banco Santander Negocios Globales
* Todos los derechos reservados
* ProdArchResponse.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <4 dic 2024 11:22:29>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * Clase generada para ProdArchResponse para los datos y la lista de productos rechazos
 *
 * @autor C320868
 * @modifico C320868
 */
@Getter
@Setter
public class ProdArchResponse implements Serializable {

	/** Declaracion de Constante serialVersionUID. */
	private static final long serialVersionUID = -5965416158245734733L;

	/** Id del archivo. */
	private ProductoArchivoResponse archivos;
	
	/** Declaracion de List<ProductoArchivoResponse> para lstArchivos. */
	private List<ProductoArchivoResponse> lstArchivos;
}
