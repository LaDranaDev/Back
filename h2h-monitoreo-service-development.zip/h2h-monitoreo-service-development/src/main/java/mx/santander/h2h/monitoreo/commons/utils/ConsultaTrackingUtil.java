package mx.santander.h2h.monitoreo.commons.utils;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

import jakarta.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

/**
 * Clase utils para Consulta 
 * de tracking
 * @author obautist
 *
 */
@Component
public final class ConsultaTrackingUtil {
	/**
	 * FORMAT_DECIMAL
	 * ###,###,###,###,##0.00
	 */
	private static final String FORMAT_DECIMAL = "###,###,###,###,##0.00";

	/**
	 * Constructor 
	 * de la clase
	 */
	private ConsultaTrackingUtil(){
		
	}
	
	/**
	 * Metodo que formatea el 
	 * importe del archivo
	 * @param num big decmal
	 * @return string
	 */
	public static String formateaImporteArchivo(BigDecimal num) {
		String formato = "0.00";
		final DecimalFormatSymbols simbolos = DecimalFormatSymbols.getInstance(Locale.ENGLISH);
		final DecimalFormat format = new DecimalFormat(FORMAT_DECIMAL,simbolos);

		if (num != null) {
			formato = format.format(num);
			return "$" + formato;
		} else {
			return "";
		}
	}
	
	/**
	 * MEtodo que formatea el 
	 * iomporte del producto
	 * @param num big decimal
	 * @return String
	 */
	public static String formateaImporteProducto(BigDecimal num) {
        String formato = "0.00";
        final DecimalFormatSymbols simbolos = DecimalFormatSymbols.getInstance(Locale.ENGLISH);
        final DecimalFormat format = new DecimalFormat(FORMAT_DECIMAL, simbolos);

        if (num != null) {
            formato = format.format(num);
        }

        return "$" + formato;
    }
	
	/**
	 * Metodo que formatea el 
	 * importe de la operacion
	 * @param num Big decimal
	 * @return String
	 */
	public static String formateaImporteOperacion(BigDecimal num) {
        return formateaImporteProducto(num);
    }
	
	/**
	 * Metodo que tiene el queri 
	 * de obtener productos
	 * @return query
	 */
	public static StringBuilder queryObtenerProductos() {
		StringBuilder querySql = new StringBuilder();
				
		return querySql.append("SELECT ID_PROD, DESC_PROD ")
				.append("FROM H2H_CAT_PROD ")
				.append("WHERE BAND_ACTIVO = 'A'  AND BAND_VISI_CONS = 'A' ")
				.append("ORDER BY DESC_PROD ");	
	}
	
	/**
	 * metodo que contiene el query para obtener catalogos
	 * @return query
	 */
	public static StringBuilder queryObtenerCatalogos() {
		StringBuilder querySql = new StringBuilder();
				
		return querySql.append("SELECT ID_CAT_ESTATUS, DESC_ESTATUS ")
				.append("FROM H2H_CAT_ESTATUS ")
				.append("WHERE BAND_ACTIVO = 'A' ")
				.append("AND TIPO_ESTATUS = :tipoEstatus ")
				.append("ORDER BY DESC_ESTATUS ");
	}
	
	/**
	 * Metodo que contiene el query para obtener los archivos en excel
	 * @param sql de tipo string
	 * @param tamExcel tamaño de detalle
	 * @return query a ejecutar
	 */
	public static StringBuilder getQueryExcel(final String sql, final int tamExcel) {
		final StringBuilder query = new StringBuilder();
		
		query.append("SELECT A.*, ROWNUM ROW_NUMBER FROM ( ")
		.append(sql)
		.append(") A WHERE ROWNUM < ")
		.append(tamExcel);
		
		return query;
	}
	
	/**
	 * MEtodo que contiene la query 
	 * para obtener los detalles de los
	 * archivos
	 * @param nomArch nombre de archivo
	 * @param estatus estatus
	 * @return query a ejecutar
	 */
	public static StringBuilder obtenerQueryDetalle(String nomArch, Integer estatus) {
		StringBuilder querySql = new StringBuilder();
		
		querySql.append("SELECT ")
		.append("A.ID_ARCHIVO,")
		.append("A.NOMBRE_ARCH,A.FECHA_REGISTRO FECHA_ORDER,")
		.append("TO_CHAR(A.FECHA_REGISTRO,'dd/mm/yyyy hh24:mi:ss') FECHA_REGISTRO,")
		.append("A.ID_ESTATUS,")
		.append("B.DESC_ESTATUS,")
		.append("C.ID_PROD,")
		.append("C.DESC_PROD,")
		.append(" H2H_CAT_CANL.NOMB_CANL, ")
		.append(" MSG_H2H MOTI_RECH, ")
		.append("SUM (NVL(D.TOTA_OPER,0)) AS TOTAL_OPER,")
		.append("SUM (NVL(D.TOTA_MONT,0)) AS TOTAL_MONT ")
		.append("FROM H2H_ARCHIVO_TRAN A ")
		.append("LEFT  JOIN H2H_ARCH_PROD_TRAN D ON D.ID_ARCHIVO = A.ID_ARCHIVO ")
		.append("INNER JOIN  H2H_CAT_ESTATUS B ON B.ID_CAT_ESTATUS  =  A.ID_ESTATUS ")
		.append("INNER JOIN H2H_PARAM P ")  
		.append("ON P.VALOR = A.ID_ESTATUS ")  
		.append("AND P.NMBR_PARAM LIKE 'TRCKNG_ESTATUS_%' ") 
		.append("INNER JOIN H2H_CNTR E  ON  E.ID_CNTR = A.ID_CNTR ")
		.append("INNER JOIN H2H_CLTE F ON  F.ID_CLTE =  E.ID_CLTE ")
		.append("LEFT JOIN H2H_CAT_PROD C ON C.CVE_PROD_OPER = D.CVE_PROD_OPER ")
		.append("INNER JOIN H2H_CAT_CANL ")
		.append("ON H2H_CAT_CANL.ID_CANL = A.ID_CANL ")
		.append("LEFT JOIN H2H_MSG MSG ")
		.append("ON MSG.ID_MSG = A.ID_MSG ")
		.append("WHERE ") 
		.append("F.BUC = :codCliente");		
		if (StringUtils.isNotBlank(nomArch)) {			
			querySql.append(" AND A.NOMBRE_ARCH LIKE ( '%' || :nomArch || '%') ");
		}
		agregarRestriccionEstatus(querySql, estatus);
		querySql.append(" GROUP BY ")
		.append("A.ID_ARCHIVO,")
		.append("A.NOMBRE_ARCH, ")
		.append("A.FECHA_REGISTRO, ")
		.append("A.ID_ESTATUS, ")
		.append("B.DESC_ESTATUS, ")
		.append("C.ID_PROD, ")
		.append("C.DESC_PROD, ")
		.append("H2H_CAT_CANL.NOMB_CANL,  ")
		.append(" MSG_H2H ");
		//IF-THEN Equivalente a metodo agregarRestriccionEstatus 
		if (estatus == null || estatus == 3   || estatus <= 0) {
			querySql.append(" UNION ALL ")
				.append(" SELECT ID_ARCHIVO, NOMBRE_ARCH, MAX(FECHA_REGISTRO) FECHA_ORDER,")
				.append("  TO_CHAR(MAX(FECHA_REGISTRO),'dd/mm/yyyy hh24:mi:ss') FECHA_REGISTRO, ")
				.append("  ID_ESTATUS, DESC_ESTATUS, ID_PROD,  DESC_PROD,   NOMB_CANL,  MOTI_RECH,  ")
				.append("  TOTAL_OPER, TOTAL_MONT FROM ( ")
				.append("  SELECT 0 ID_ARCHIVO,   ar.NOMB_ARCH NOMBRE_ARCH,  ")
				.append("   FECH_REG FECHA_REGISTRO,  16 ID_ESTATUS,  'RECHAZADO' DESC_ESTATUS, ")
				.append(" 0 ID_PROD,  '' DESC_PROD,  d.NOMB_CANL NOMB_CANL, AR.MOTI_RECH, 0 TOTAL_OPER,  0 TOTAL_MONT  ")
				.append("  FROM H2H_ARCH_RECH ar   ")
				.append(" INNER JOIN H2H_CNTR  ON ar.ID_CNTR = H2H_CNTR.ID_CNTR  ")
				.append(" INNER JOIN H2H_CLTE  ON H2H_CLTE.ID_CLTE = H2H_CNTR.ID_CLTE ")
				.append(" INNER JOIN H2H_CAT_CANL d ")               
				.append(" ON d.ID_CANL = ar.ID_CANAL ")
				.append("  WHERE TRUNC(ar.FECH_REG) = to_date (:fecha,'dd/mm/yyyy')")
				.append("  AND H2H_CLTE.BUC = :codCliente")
				.append(" AND ar.MOTI_RECH != 'Archivo Duplicado'");
				if (StringUtils.isNotBlank(nomArch)) {			
					querySql.append(" AND ar.NOMB_ARCH LIKE :nomArch ");
				}
				querySql.append(" ) TMP  ")
				.append("  GROUP BY ID_ARCHIVO, NOMBRE_ARCH, ID_ESTATUS, ")
				.append(" DESC_ESTATUS, ID_PROD, DESC_PROD, TOTAL_OPER,TOTAL_MONT, NOMB_CANL, MOTI_RECH  ");
		}  
		querySql.append(" ORDER BY FECHA_ORDER DESC, ID_ARCHIVO ");
		
		return querySql;
	}
	
	/**
	 * Metodo que realiza el seteo de los parametros a buscar en query
	 * @param fecha fecha string
	 * @param codCliente string
	 * @param nomArch string
	 * @param estatus integer
	 * @param query query
	 */
	public static void setParamsNivelArchivo(String fecha, String codCliente, String nomArch, Integer estatus, Query query) {
		query.setParameter("codCliente", codCliente);
		if (estatus == null || estatus == 3   || estatus <= 0) {
			query.setParameter("fecha", fecha);
		}
		if (StringUtils.isNotBlank(nomArch)) {
			query.setParameter("nomArch", nomArch);
		}
	}
	
	/**
	 * Metodo que realiza evaluacion de estatus para formar query
	 * @param sql String builder
	 * @param idEstatus integer
	 */
	private static void agregarRestriccionEstatus(final StringBuilder sql, Integer idEstatus) {
		if (sql != null && idEstatus != null && idEstatus > 0) {
			switch (idEstatus) {
			case 1: //DUPLICADO
				sql.append(" AND P.DESRIPCION = 'DUPLICADO' ");
				break;
			case 2: //RECIBIDO
				sql.append(" AND P.DESRIPCION = 'RECIBIDO' ");
				break;
			case 3: //RECHAZADO
				sql.append(" AND P.DESRIPCION = 'RECHAZADO' ");
				break;	
			case 4: //VALIDADO
				sql.append(" AND P.DESRIPCION = 'VALIDADO' ");
				break;
			case 5: //ENVIADO CLIENTE
				sql.append(" AND P.DESRIPCION = 'ENVIADO' ");
				break;
			case 6: //EN PROCESO
				sql.append(" AND P.DESRIPCION = 'PROCESO' ");
				break;	
			case 7: //EN ESPERA
				sql.append(" AND P.DESRIPCION = 'ESPERA' ");
				break;
			case 8: //PROCESADO
				sql.append(" AND P.DESRIPCION = 'PROCESADO' ");
				break;
			default:
				break;
			}
		}
	}
}
