package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductoArchivoResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5965416158245734733L;

	/** Id del archivo. */
	private Integer idArchivo;
	
	/** Nombre del archivo. */
	private String nombreArchivo;
	
	/** Codigo del cliente. */
	private String cliente;
	
	/** Codigo del cliente. */
	private Integer codigoCliente;
	
	/** Fecha recepcion del archivo. */
	private String fechaRecep;
	
	/** Estatus. */
	private String estatus;
	
	/** Id del estatus. */
	private Integer idEstatus;
	
	/** Producto. */
	private String producto;
	
	/** Id del Producto. */
	private Integer idProducto;
	
	/** Total de operaciones. */
	private Integer totalOperaciones;
	
	/** Total del monto. */
	private BigDecimal monto;
	
	/** Umbral de BE en minutos. */
	private Integer umbral;
	
	/** Envio a Backend. */
	private String envioBackend;

	/** Regreso a Backend. */
	private String regresoBackend;
	
	/** Total del monto formateado. */
	private String montoFmt;
	
	/** Canal del archivo. */
	private String canal;
	
	/** Motivo de Rechazo del archivo. */
	private String motRechazo;
	
	/** Nombre del archivo Procesado. */
	private String nombreArchivoProcesado;
	
	/** Estatus Final. */
	private String estatusFinal;

	/** Buc Cliente - Archivo . */
	private String buc;

	/** Buc Cliente. */
	private String bucDuplicado;
	
}
