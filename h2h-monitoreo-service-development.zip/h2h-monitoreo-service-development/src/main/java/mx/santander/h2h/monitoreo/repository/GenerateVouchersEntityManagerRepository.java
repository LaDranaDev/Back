/**
 * 
 */
package mx.santander.h2h.monitoreo.repository;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersDtoResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.model.response.SelectComboDTO;
import mx.santander.h2h.monitoreo.util.IGenerateVouchersRepositoryUtil;
import mx.santander.h2h.monitoreo.util.UtilData;
import mx.santander.h2h.monitoreo.util.UtilMapeoData;

/**
 * @author sbautish
 *
 */
@Repository
@Transactional
@Slf4j
public class GenerateVouchersEntityManagerRepository implements IGenerateVouchersEntityManagerRepository {
	@Autowired
	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private IGenerateVouchersRepositoryUtil iGenerateVouchersRepositoryUtil;

	@Override
	public GenerateVouchersDtoResponse getListPaymentType() {

		log.info("Realizando consulta de estatus.");

		StringBuilder query = new StringBuilder("SELECT VALO AS KEY, DESCR AS VALUE FROM H2H_REGI_CATA WHERE ID_CATA = (");
		query.append("SELECT ID_CATA FROM H2H_CATA WHERE DESCRIPCION = 'CATALOGO DE CONCEPTOS CDMX'");
		query.append(")");

		Query queryResult = entityManager.createNativeQuery(query.toString());

		List<Object[]> resultList = queryResult.getResultList();

		List<SelectComboDTO> listaTipoPago = new ArrayList<SelectComboDTO>();

		for (Object[] paymentType : resultList) {

			SelectComboDTO selectComboDTO = new SelectComboDTO();

			selectComboDTO.setKey(Objects.toString(paymentType[0], ""));
			selectComboDTO.setValue(Objects.toString(paymentType[1], ""));

			listaTipoPago.add(selectComboDTO);

		}

		GenerateVouchersDtoResponse generateVouchersDtoResponse = new GenerateVouchersDtoResponse();

		generateVouchersDtoResponse.setListaTipoPago(listaTipoPago);

		return generateVouchersDtoResponse;

	}

	@Override
	public GenerateVouchersDtoResponse findOperationsCount(OperationsMonitorQueryRequest operationsMonitorQueryRequest) throws BusinessException {

		List<String> listParams = new ArrayList<>();

		StringBuilder query = new StringBuilder("SELECT COUNT(1) TOTAL FROM (");

		query = iGenerateVouchersRepositoryUtil.getQueryTable(operationsMonitorQueryRequest, listParams, query);

		query.append(")");

		log.info("findOperationsCount Repository: ".concat(Encode.forJava(query.toString())));

		Query operationsCountQuery = entityManager.createNativeQuery(query.toString(), Tuple.class);

		iGenerateVouchersRepositoryUtil.setStringParamsInToQuery(listParams, operationsCountQuery);

		List<Tuple> totalOperationsResult = operationsCountQuery.getResultList();

		GenerateVouchersDtoResponse generateVouchersDtoResponse = new GenerateVouchersDtoResponse();

		generateVouchersDtoResponse.setTotalOperaciones("0");

		if (!totalOperationsResult.isEmpty()) {

			totalOperationsResult.forEach(tuple -> generateVouchersDtoResponse.setTotalOperaciones(tuple.get("TOTAL").toString()));

		}

		return generateVouchersDtoResponse;

	}

	@Override
	public List<OperationsMonitorQueryResponse> findOperations(OperationsMonitorQueryRequest operationsMonitorQueryRequest) {

		List<OperationsMonitorQueryResponse> listaOperaciones = new ArrayList<>();

		List<String> listParams = new ArrayList<>();

		StringBuilder queryTable = iGenerateVouchersRepositoryUtil.getQueryTable(operationsMonitorQueryRequest, listParams, new StringBuilder());

		StringBuilder query = iGenerateVouchersRepositoryUtil.getPaginatedQuery(new StringBuilder(), queryTable);

		Query paginatedQueryResult = entityManager.createNativeQuery(query.toString(), Tuple.class);

		iGenerateVouchersRepositoryUtil.setStringParamsInToQuery(listParams, paginatedQueryResult);

		List<Tuple> operationsResult = paginatedQueryResult.getResultList();

		final DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols();

		formatSymbols.setDecimalSeparator('.');
		formatSymbols.setGroupingSeparator(',');

		final DecimalFormat decimalFormat = new DecimalFormat("###, ###, ###, ###, ##0.00", formatSymbols);

		for (Tuple item : operationsResult) {

			OperationsMonitorQueryResponse operationsMonitorQueryResponse = new OperationsMonitorQueryResponse();

			if (item.get(0) == null || StringUtils.isBlank(item.get(0).toString())) {
				operationsMonitorQueryResponse.setIdOperacion("0");
			} else {
				operationsMonitorQueryResponse.setIdOperacion(item.get(0).toString());
			}

			operationsMonitorQueryResponse.setCodCli(ObjectUtils.toString(item.get(1)));
			operationsMonitorQueryResponse.setCtaCargo(ObjectUtils.toString(item.get(2)));
			operationsMonitorQueryResponse.setCtaAbono( ObjectUtils.toString(item.get(3)) );
			// Obtenemos el enmascarado de datos
			operationsMonitorQueryResponse.setCtaAbono( UtilMapeoData.getMascara(operationsMonitorQueryResponse.getCtaAbono(), "abono") );
			
			operationsMonitorQueryResponse.setIdProducto(ObjectUtils.toString(item.get(4)));
			operationsMonitorQueryResponse.setProducto(ObjectUtils.toString(item.get(5)));
			operationsMonitorQueryResponse.setNomArch(ObjectUtils.toString(item.get(6)));
			operationsMonitorQueryResponse.setEstatus(ObjectUtils.toString(item.get(7)));
			operationsMonitorQueryResponse.setIdEstatus(ObjectUtils.toString(item.get(8)));
			operationsMonitorQueryResponse.setCanal(ObjectUtils.toString(item.get(9)));
			operationsMonitorQueryResponse.setReferencia(ObjectUtils.toString(item.get(10)));
			operationsMonitorQueryResponse.setReferenciaAbono(ObjectUtils.toString(item.get(11)));
			operationsMonitorQueryResponse.setFechaAplic(ObjectUtils.toString(item.get(12)));

			if (item.get(13) == null || StringUtils.isBlank(item.get(13).toString())) {
				operationsMonitorQueryResponse.setImporte("$0.00");
			} else {
				operationsMonitorQueryResponse.setImporte("$".concat(decimalFormat.format(Double.valueOf(item.get(13).toString()))));
			}

			listaOperaciones.add(operationsMonitorQueryResponse);

		}

		return listaOperaciones;

	}

	/**
	 * Descripción : Método que realiza la carga inicial de componentes con la obtención del importe total.
	 *
	 */
	@Override
	public String getLumpSum(OperationsMonitorQueryRequest operationsMonitorQueryRequest) {

		StringBuilder query = new StringBuilder("SELECT NVL(SUM(IMPO_MOVI), 0) IMP_TOTAL FROM (");

		List<String> listParams = new ArrayList<>();

		query = iGenerateVouchersRepositoryUtil.getQueryTable(operationsMonitorQueryRequest, listParams, query);

		query.append(")");

		Query createdQuery = entityManager.createNativeQuery(query.toString(), Tuple.class);

		iGenerateVouchersRepositoryUtil.setStringParamsInToQuery(listParams, createdQuery);

		List<Tuple> importeTotalResult = createdQuery.getResultList();

		String importeTotal = "0";

		if (!importeTotalResult.isEmpty()) {

			for (Tuple importeTotalTuple : importeTotalResult) {

				importeTotal = importeTotalTuple.get("IMP_TOTAL").toString();

			}

		}

		return importeTotal;

	}

	/**
	 * Descripción : Método que realiza la carga inicial de componentes con la obtención del total de archivos.
	 *
	 */
	@Override
	public String getTotalFiles(OperationsMonitorQueryRequest operationsMonitorQueryRequest) {

		StringBuilder query = new StringBuilder("SELECT COUNT(DISTINCT(NOMB_CLTE)) DIST_ARCHIVO FROM (");

		List<String> listParams = new ArrayList<>();

		query = iGenerateVouchersRepositoryUtil.getQueryTable(operationsMonitorQueryRequest, listParams, query);

		query.append(")");

		Query createdQuery = entityManager.createNativeQuery(query.toString(), Tuple.class);

		iGenerateVouchersRepositoryUtil.setStringParamsInToQuery(listParams, createdQuery);

		List<Tuple> totalFilesResult = createdQuery.getResultList();

		String totalFiles = "0";

		if (!totalFilesResult.isEmpty()) {

			for (Tuple totalFilesTuple : totalFilesResult) {

				totalFiles = totalFilesTuple.get("DIST_ARCHIVO").toString();

			}

		}

		return totalFiles;

	}

	@Override
	public GenerateVouchersDtoResponse conceptoValor(String lineaCaptura) {

		GenerateVouchersDtoResponse generateVouchersDtoResponse = new GenerateVouchersDtoResponse();

		try {

			StringBuilder query = new StringBuilder("SELECT DESCR ");
			query.append("FROM H2H_REGI_CATA ");
			query.append("WHERE ID_CATA = ");
			query.append("(SELECT ID_CATA FROM H2H_CATA WHERE DESCRIPCION = 'CATALOGO DE CONCEPTOS CDMX') ");
			query.append("AND VALO = :concepto ");

			List<String> listaConceptos = entityManager.createNativeQuery(query.toString()).setParameter("concepto", lineaCaptura).getResultList();

			for (String conceptoArray : listaConceptos) {
				generateVouchersDtoResponse.setConceptoValor(Objects.toString(conceptoArray, ""));
			}

		} catch (BusinessException be) {

			generateVouchersDtoResponse.setCodError(be.getCode());
			generateVouchersDtoResponse.setMsgError(be.getMessage());

			throw new BusinessException(be.getCode(), be.getMessage());

		}

		return generateVouchersDtoResponse;

	}

	@Override
	public List<OperationsMonitorQueryResponse> consultaOperacionesExportar(
			OperationsMonitorQueryRequest operationsMonitorQueryRequest) throws DataAccessException {

		List<OperationsMonitorQueryResponse> listOperationsMonitorQueryResponse = new ArrayList<OperationsMonitorQueryResponse>();

		List<String> listParams = new ArrayList<>();

		StringBuilder query = new StringBuilder("SELECT ");
		query.append("ID_REG, BUC, NUM_CTA_CARG, NUM_CTA_ABO, DESC_PROD, NOMBRE_ARCH, DESC_CANL, NUME_MOVI_CARG, OBSE_ABO, DIVI, NOMB_CLTE, DESC_ESTATUS, CLVE_CONV, FECHA_PRESENTACION_INICIAL, ");
		query.append("FECHA_APLICACION, FECHA_OPERACION, DESC_ERR, IMPO_MOVI FROM ( SELECT A.ID_REG, A.BUC, A.NUM_CTA_CARG, A.NUM_CTA_ABO, A.DESC_PROD, A.NOMBRE_ARCH, A.DESC_ESTATUS, ");
		query.append("A.DESC_CANL, A.NUME_MOVI_CARG, A.OBSE_ABO, A.DIVI, A.NOMB_CLTE, A.CLVE_CONV, A.FECHA_PRESENTACION_INICIAL, A.FECHA_APLICACION, A.FECHA_OPERACION, A.DESC_ERR, A.IMPO_MOVI, ");
		query.append("ROWNUM ROW_NUMBER FROM ( ");

		query = iGenerateVouchersRepositoryUtil.getQueryTableExport(operationsMonitorQueryRequest, listParams, query);

		query.append(") A)");

		Query createdQuery = entityManager.createNativeQuery(query.toString(), Tuple.class);

		iGenerateVouchersRepositoryUtil.setStringParamsInToQuery(listParams, createdQuery);

		List<Tuple> listaOperaciones = createdQuery.getResultList();

		if (!listaOperaciones.isEmpty()) {

			for (Tuple operacionesTuple : listaOperaciones) {

				OperationsMonitorQueryResponse operationsMonitorQueryResponse = new OperationsMonitorQueryResponse();

				DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols();

				formatSymbols.setDecimalSeparator('.');
				formatSymbols.setGroupingSeparator(',');

				DecimalFormat decimalFormat = new DecimalFormat("###,###,###,###,##0.00", formatSymbols);

				/** Se valida el campo de indicador de registro y se valida si es null o vacío para asignar valor */
				if (operacionesTuple.get("ID_REG") == null || operacionesTuple.get("ID_REG").toString().isEmpty()) {
					operationsMonitorQueryResponse.setIdOperacion("0");
				} else {
					operationsMonitorQueryResponse.setIdOperacion(operacionesTuple.get("ID_REG").toString());
				}

				/** Se recuperan los valores y se llena el bean que guadara los datos para el front */
				operationsMonitorQueryResponse.setCodCli(ObjectUtils.toString(operacionesTuple.get("BUC")));
				operationsMonitorQueryResponse.setCtaCargo(ObjectUtils.toString(operacionesTuple.get("NUM_CTA_CARG")));
				operationsMonitorQueryResponse.setCtaAbono( ObjectUtils.toString(operacionesTuple.get("NUM_CTA_ABO")) );
				// Enmascaramos la Cuenta
				operationsMonitorQueryResponse.setCtaAbono(UtilMapeoData.getMascara(operationsMonitorQueryResponse.getCtaAbono(), "abono"));
				
				operationsMonitorQueryResponse.setProducto(ObjectUtils.toString(operacionesTuple.get("DESC_PROD")));
				operationsMonitorQueryResponse.setNomArch(ObjectUtils.toString(operacionesTuple.get("NOMBRE_ARCH")));
				operationsMonitorQueryResponse.setEstatus(ObjectUtils.toString(operacionesTuple.get("DESC_ESTATUS")));
				operationsMonitorQueryResponse.setCanal(ObjectUtils.toString(operacionesTuple.get("DESC_CANL")));
				operationsMonitorQueryResponse.setReferencia(ObjectUtils.toString(operacionesTuple.get("NUME_MOVI_CARG")));
				operationsMonitorQueryResponse.setIntermOrd(ObjectUtils.toString(operacionesTuple.get("OBSE_ABO")));
				operationsMonitorQueryResponse.setDivisaOrd(ObjectUtils.toString(operacionesTuple.get("DIVI")));
				operationsMonitorQueryResponse.setNombreOrd(ObjectUtils.toString(operacionesTuple.get("NOMB_CLTE")));
				operationsMonitorQueryResponse.setIntermRec(ObjectUtils.toString(operacionesTuple.get("DESC_ERR")));
				operationsMonitorQueryResponse.setEstatus(ObjectUtils.toString(operacionesTuple.get("DESC_ESTATUS")));
				operationsMonitorQueryResponse.setComentario1(ObjectUtils.toString(operacionesTuple.get("CLVE_CONV")));
				operationsMonitorQueryResponse.setFechaPresIni(ObjectUtils.toString(operacionesTuple.get("FECHA_PRESENTACION_INICIAL")));
				operationsMonitorQueryResponse.setFechaAplic(ObjectUtils.toString(operacionesTuple.get("FECHA_APLICACION")));
				operationsMonitorQueryResponse.setFechaOper(ObjectUtils.toString(operacionesTuple.get("FECHA_OPERACION")));
				operationsMonitorQueryResponse.setMensaje(ObjectUtils.toString(operacionesTuple.get("DESC_ERR")));

				/** Se valida si el campo de importe es null o vacío y se asigna su valor */
				if (operacionesTuple.get("IMPO_MOVI") == null || operacionesTuple.get("IMPO_MOVI").toString().isEmpty()) {
					operationsMonitorQueryResponse.setImporte("$0.00");
				} else {
					operationsMonitorQueryResponse.setImporte("$" + decimalFormat.format(Double.valueOf(operacionesTuple.get("IMPO_MOVI").toString())));
				}

				listOperationsMonitorQueryResponse.add(operationsMonitorQueryResponse);

			}

		}

		return listOperationsMonitorQueryResponse;

	}
	
	@Override
	public GenerateVouchersDtoResponse recuperarParamsGenComprobante() throws DataAccessException {
		GenerateVouchersDtoResponse generateVouchersDtoResponse = new GenerateVouchersDtoResponse();
		StringBuilder query = new StringBuilder("SELECT NMBR_PARAM, VALOR FROM H2H_PARAM WHERE NMBR_PARAM IN ('CTA_RECAUDADORA_CDMX', 'ID_CANAL_WS_CDMX', 'RUTA_WSDL_COMP_CDMX') ORDER BY NMBR_PARAM ASC");
		Query createdQuery = entityManager.createNativeQuery(query.toString(), Tuple.class);
		List<Tuple> listaParamsComprobante = createdQuery.getResultList();
		if (!listaParamsComprobante.isEmpty()) {
			List<String> params = new ArrayList<String>();
			for (Tuple paramTuple : listaParamsComprobante) {
				params.add(ObjectUtils.toString(paramTuple.get("VALOR")));
			}
			generateVouchersDtoResponse.setParametrosAdicionalesComprobante(params);
		}

		return generateVouchersDtoResponse;
	}

}
