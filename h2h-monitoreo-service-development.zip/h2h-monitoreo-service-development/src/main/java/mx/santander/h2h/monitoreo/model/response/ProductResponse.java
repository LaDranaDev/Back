package mx.santander.h2h.monitoreo.model.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * ProductResponse.
 * Objeto de respuesta que contiene la informacion de los productos.
 *
 * @author Jesus Soto Aguilar
 * @since 20/04/2023
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductResponse implements Serializable {

    /**
     * Serial.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Identificador del producto.
     */
    private Long idProducto;

    /**
     * Clave del producto.
     */
    private String claveProducto;

    /**
     * Descripcion del producto.
     */
    private String descProducto;
}
