package mx.santander.h2h.monitoreo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import mx.santander.h2h.monitoreo.constants.ReportConstants;
import mx.santander.h2h.monitoreo.constants.RoutesConstant;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.OperationsHistoryResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorCatalogsYHorasResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorTotalResponse;
import mx.santander.h2h.monitoreo.service.IComprobanteService;
import mx.santander.h2h.monitoreo.service.IOperationsMonitorService;

/**
 * OperationsMonitorController.
 * API pare el Monitor de Operaciones
 *
 * @author Daniel Ruiz
 * @since 13/04/2023
 */
@Validated
@RestController
@RequestMapping(RoutesConstant.PATH_MONITOR_OPERACIONES)
public class OperationsMonitorController {

    @Autowired
    private IOperationsMonitorService service;

    @Autowired
    private IComprobanteService comprobanteService;

    /**
     * consulta
     * API POST - Realiza la consulta de las operaciones.
     *
     * @param request Request para realizar la consulta.
     * @param pageable parámetros de la paginación.
     * @return Página contiene los resultados.
     */
    @Operation(summary = "Realiza la consulta de las operaciones.")
    @PostMapping(path = "/consulta", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Page<OperationsMonitorQueryResponse>> consulta(
            @RequestBody @Valid OperationsMonitorQueryRequest request,
            @PageableDefault Pageable pageable
    ) {
        return ResponseEntity.ok(service.consulta(request, pageable));
    }

    /**
     * total
     * API POST - Obtiene los totales de la consulta de operaciones.
     *
     * @param request Request de la consulta.
     * @return Response con los totales
     */
    @Operation(summary = "Obtiene los totales de la consulta de operaciones.")
    @PostMapping(path = "/total", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<OperationsMonitorTotalResponse> total(
            @RequestBody @Valid OperationsMonitorQueryRequest request
    ) {
        return ResponseEntity.ok(service.total(request));
    }

    /**
     * consultaExcel
     * API POST - Endpoint para poder exportar los datos de la consulta a excel.
     *
     * @param request Request para realizar la consulta.
     * @return DTO con los datos del reporte.
     */
    @Operation(summary = "Endpoint para poder exportar los datos de la consulta a excel.")
    @PostMapping(path = RoutesConstant.SLASH + RoutesConstant.EXPORTEDOCTATOEXCEL)
    public ResponseEntity<ReportResponse> consultaExcel(
            @RequestBody OperationsMonitorQueryRequest request
    ) {
        return ResponseEntity.ok(service.reporte(request, ReportConstants.EXCEL_FORMAT));
    }


    /**
     * consultaExcel
     * API POST - Generacion de comprobantes.
     *
     * @param queries Datos de las operaciones a consultar.
     * @return DTO con los datos de los comprobantes.
     */
    @Operation(summary = "Generacion de comprobantes.")
    @PostMapping(path = RoutesConstant.SLASH + "comprobantes/{format}")
    public ResponseEntity<ReportResponse> comprobantes(
            @RequestBody List<OperationsMonitorQueryResponse> queries,
            
            @Pattern(regexp = "((xls)|(xlsx)|(csv)|(pdf)|(zip))?", message = "Formato no valido")
            @PathVariable String format
    ) {
        return ResponseEntity.ok(comprobanteService.comprobantes(queries, format));
    }

    /**
     * Consulta la lista de divisas, estatus y productos
     * @return Response de catálogos
     */
    @Operation(summary = "Consulta la lista de divisas, estatus y productos")
    @GetMapping(path = RoutesConstant.SLASH + "catalogos")
    public ResponseEntity<OperationsMonitorCatalogsYHorasResponse> catalogs() {
        return ResponseEntity.ok(service.catalogsConsultaTrackingArchivo());
    }

    /**
     * Obtiene el detalle de la operacion
     * @param query Datos para realizar la consulta.
     * @return Detalle de la operacion
     */
    @Operation(summary = "Obtiene el detalle de la operacion")
    @PostMapping(path = "/detalle")
    public ResponseEntity<OperationsMonitorQueryResponse> detalleOperacion(
    		@Valid
            @RequestBody 
            OperationsMonitorQueryResponse query
    ) {
        return ResponseEntity.ok(service.obtenerDetalleOperacion(query.getIdProducto(), query.getIdOperacion()));
    }

    /**
     * Obtiene el historial de la operacion
     * @param idOperacion - ID de operacion
     * @return Historial de la operacion
     */
    @Operation(summary = "Obtiene el historial de la operacion")
    @GetMapping(path = "/historial/{idOperacion}")
    public ResponseEntity<List<OperationsHistoryResponse>> historialOperacion(
    		@PathVariable(required = true, name = "idOperacion") 
    		@Size(min = 1, max = 15, message = "El id operacion debe tener máximo 15 dígitos") 
    		@Pattern(regexp = "([0-9]+$)?",  message = "Solo se permiten caracteres númericos") String idOperacion
    ) {
        return ResponseEntity.ok(service.obtenerHistorialOperacion(idOperacion));
    }

    /**
     * Obtiene el reporte del historial de la operacion
     * @param idOperacion - ID de operacion
     * @param usuario Nombre del usuario en el reporte
     * @return Reporte Historial de la operacion
     */
    @Operation(summary = "Obtiene el historial de la operacion")
    @GetMapping(path = "/historial/{idOperacion}/reporte")
    public ResponseEntity<ReportResponse> reporteHistorialOperacion(
    		@PathVariable(required = true, name = "idOperacion") 
    		@Size(min = 0, max = 15, message = "El id operacion debe tener máximo 15 dígitos") 
    		@Pattern(regexp = "([0-9]+$)?",  message = "Solo se permiten caracteres númericos") 
    		String idOperacion,
    		
    		@RequestParam(required = true, name="usuario") 
    		@Size(min = 0, max = 15, message = "El id operacion debe tener máximo 15 dígitos") 
    		@Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Solo se permiten caracteres númericos") 
    		String usuario
    ) {
        return ResponseEntity.ok(service.reporteHistorialOperacion(idOperacion, usuario));
    }

    /**
     * Cambia el estatus de la operacion
     * @param query Datos para realizar la consulta.
     * @return true o false, indica si la actualizacion se realizo con exito o no
     */
    @Operation(summary = "Cambia el estatus de la operacion")
    @PostMapping(path = "/cambiarEstatus")
    public ResponseEntity<Boolean> cambiarEstatus(
    		@Valid
            @RequestBody OperationsMonitorQueryResponse query
    ) {
        return ResponseEntity.ok(
                service.cambiarEstatusOperacion(query.getIdOperacion(), query.getEstatus(), query.getTabla())
        );
    }

    /**
     * Consulta el horario para realizar el cambio de estatus.
     * @param producto String
     * @return boolean
     */
    @Operation(summary = "Consulta el horario para realizar el cambio de estatus.")
    @GetMapping(path = "/consultarHorario/{producto}")
    public ResponseEntity<Boolean> consultarHorario(
    		@Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
            @PathVariable String producto
    ) {
        return ResponseEntity.ok(service.consultarHorario(producto));
    }

}
