package mx.santander.h2h.monitoreo.model.entity;

import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Entidad para la tabla H2H_CONS_SALD_REIN.
 * Mapea la tabla principal de Saldos reintentos.
 *
 * @author Jesus Soto Aguilar
 * @since 13/04/2023
 */
@Entity
@Getter
@Setter
@Table(name = "H2H_CONS_SALD_REIN")
public class SaldosReintentosEntity implements Serializable {

    /**
     * Serial.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Identificador de la entidad
     */
    @Id
    @Column(name = "ID_CONS_SALDO_REIN")
    private Long idSaldosReintentos;

    /**
     * Numero de la cuenta ordenante.
     */
    @Column(name = "NUM_CTA_ORD")
    private String numCtaOrdenante;

    /**
     * Saldo obtenido de la cuenta.
     */
    @Column(name = "SALDO")
    private BigDecimal saldo;

    /**
     * Fecha en que se hace la consulta del saldo.
     */
    @Column(name = "FECHA_CONSULTA")
    private LocalDate fechaConsulta;

    /**
     * ID del archivo en que se encuentra la cuenta que se consulta.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_ARCHIVO")
    private ArchivoEntity archivoEntity;

    /**
     * Monto requerido.
     */
    @Column(name = "MONTO_REQUERIDO")
    private BigDecimal montoRequerido;

    /**
     * Linea de credito.
     */
    @Column(name = "LINEA_CREDITO")
    private Character lineaCredito;

    /**
     * Clave de producto.
     */
    @Column(name = "CVE_PROD_OPER")
    private String claveProducto;
}
