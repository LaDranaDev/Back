package mx.santander.h2h.monitoreo.constants;


/**
 * Constantes para rutas del servicio.
 *
 * @author Jesus Soto Aguilar
 * @since 13/04/23
 */
public final class RoutesConstant {

	/**
	 * Contiene el simbolo slash /
	 */
	public static final String SLASH = "/";

	/**
	 * Ruta base endpoint monitoreo.
	 */
	public static final String MONITOREO_BASE_PATH = SLASH + "monitor";

	/**
	 * Ruta base para reporte
	 */
	public static final String REPORT_PATH = SLASH + "reporte";
	
	/**
	 * Ruta base para reporte tipo pdf
	 */
	public static final String PDF_PATH =  REPORT_PATH + SLASH + "pdf";

	/**
	 * Ruta base para reporte tipo XLSX
	 */
	public static final String XLSX_PATH = REPORT_PATH + SLASH + "xlsx";

	/**
	 * Ruta del servicio de monitoreo saldos
	 */
	public static final String MONITOREO_SALDOS = "saldos";

	/**
	 * Ruta del servicio de productos
	 */
	public static final String CATALOGO_PRODUCTOS = "monsaldos" +  SLASH + "catalogo" + SLASH + "productos";

	/**
	 * Ruta de Tracking de Archivo
	 */
	public static final String ARCHIVO_TRACKING = "tracking";
	
	/**
	 * Ruta del servicio de monitoreo de archivos en curso
	 */
	public static final String MONITOREO_ARCHIVOS_EN_CURSO = "monitoreo" + SLASH + "archivosEnCurso";
	/**
	 * Path monitor operaciones
	 */
	public static final String PATH_MONITOR_OPERACIONES = "monitorOperaciones";
	/**
	 * Path redireccionamiento detalle operacionesgit 
	 */
	public static final String PATH_MONITOR_OPERACIONES_REDIRECT = "monitor-operaciones-detalle";
	/**
	 * Contiene la opcion para poder exportar a pdf el estado de cuenta
	 */
	public static final String EXPORTEDOCTATOEXCEL = "reporte/excel";
	/** PATH PRINCIPAL */
	public static final String PATH_CANCEL_OPERACION = "cancelarOperaciones";
	/** PATH BUSCAR BUC */
	public static final String PATH_SEARCH_CANCEL_BUC = "buscarCancelaOperacion/{bucCliente}";
	/** PATH BUSCAR ARCHIVO */
	public static final String PATH_SEARCH_CANCEL_ARCHIVO = "buscarArchivo";
	/** PATH CMB ESTATUS CENTRO */
	public static final String PATH_CANCEL_OPERACION_DO = "cancelaOperaciones/{idRegistros}";
	/** PATH CMB ESTATUS CENTRO */
	public static final String PATH_CANCEL_CMB_ESTAT_CENTRO = "listaEstatusCentro";
	/** PATH CMB ESTATUS CMB */
	public static final String PATH_CANCEL_CMB_ESTAT = "listaEstatusCmb";
	
	/**
	 * Path de monitoreo
	 */
	public static final String PATH_MONITOREO = "monitoreo";
	
	/**
	 * Path comprobantes CDMX
	 */
	public static final String PATH_VOUCHERS_CDMX = RoutesConstant.PATH_MONITOREO + "/vouchers-cdmx";
	/**
	 * Ruta base para reporte tipo XLSX
	 */
	public static final String XLS_PATH = SLASH + "xls";
    /**
     * Constructor.
     */
    private RoutesConstant() {
    }
}
