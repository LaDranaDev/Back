package mx.santander.h2h.monitoreo.repository;

/**
 * IOperationsMonitorEntityManagerHelper1Repository.
 */
public interface IOperationsMonitorEntityManagerHelper1Repository {

}
