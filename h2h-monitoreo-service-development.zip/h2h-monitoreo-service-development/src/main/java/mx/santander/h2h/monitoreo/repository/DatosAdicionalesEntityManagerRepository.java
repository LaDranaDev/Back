package mx.santander.h2h.monitoreo.repository;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

import org.apache.commons.lang.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import mx.santander.h2h.monitoreo.model.response.GenerateVouchersDtoResponse;
import mx.santander.h2h.monitoreo.model.response.VoucherRequestDto;

/**
 * Repositorio para definir la logica de las operaciones para optener los datos
 * adicionales del comprobantes
 * 
 * @author Omar Rosas
 * @since 19/10/2023
 *
 */
@Repository
public class DatosAdicionalesEntityManagerRepository implements IDatosAdicionalesEntityManagerRepository {
	@Autowired
	@PersistenceContext
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public GenerateVouchersDtoResponse existeEnPagoRefe(VoucherRequestDto datosAdicionales) {
		GenerateVouchersDtoResponse generateVouchersDtoResponse = new GenerateVouchersDtoResponse();
		StringBuilder query = new StringBuilder(
				"SELECT ID_REG, DATOS_ADICIONALES FROM H2H_PROD_PAGO_REFE WHERE ID_REG = :idReg");
		Query createdQuery = entityManager.createNativeQuery(query.toString(), Tuple.class);
		createdQuery.setParameter("idReg", datosAdicionales.getIdReg());
		List<Tuple> listaDatosAdicionales = createdQuery.getResultList();
		if (!listaDatosAdicionales.isEmpty()) {
			List<String> params = new ArrayList<String>();
			for (Tuple paramTuple : listaDatosAdicionales) {
				params.add(ObjectUtils.toString(paramTuple.get("DATOS_ADICIONALES")));
			}

			VoucherRequestDto cdmxBean = new VoucherRequestDto();
			generateVouchersDtoResponse.setCdmxBean(cdmxBean);
			generateVouchersDtoResponse.getCdmxBean().setTramaAdicionalesEntrada(params.get(0));
		}
		return generateVouchersDtoResponse;
	}

	@SuppressWarnings("unchecked")
	@Override
	public GenerateVouchersDtoResponse existeEnPagoRefeTran(VoucherRequestDto datosAdicionales) {
		GenerateVouchersDtoResponse generateVouchersDtoResponse = new GenerateVouchersDtoResponse();
		StringBuilder query = new StringBuilder(
				"SELECT ID_REG, DATOS_ADICIONALES FROM H2H_PROD_PAGO_REFE_TRAN WHERE ID_REG = :idReg");
		Query createdQuery = entityManager.createNativeQuery(query.toString(), Tuple.class);
		createdQuery.setParameter("idReg", datosAdicionales.getIdReg());
		List<Tuple> listaDatosAdicionales = createdQuery.getResultList();
		if (!listaDatosAdicionales.isEmpty()) {
			List<String> params = new ArrayList<String>();
			for (Tuple paramTuple : listaDatosAdicionales) {
				params.add(ObjectUtils.toString(paramTuple.get("DATOS_ADICIONALES")));
			}

			VoucherRequestDto cdmxBean = new VoucherRequestDto();
			generateVouchersDtoResponse.setCdmxBean(cdmxBean);
			generateVouchersDtoResponse.getCdmxBean().setTramaAdicionalesEntrada(params.get(0));
		}
		return generateVouchersDtoResponse;
	}

	@Override
	public void actualizaPagoRefe(VoucherRequestDto datosAdicionales) {
		Query query = entityManager.createNativeQuery(
				"UPDATE H2H_PROD_PAGO_REFE SET DATOS_ADICIONALES = :datAdicionales WHERE ID_REG = :idReg");

		query.setParameter("datAdicionales", datosAdicionales.getTramaAdicionalesEntrada());
		query.setParameter("idReg", datosAdicionales.getIdReg());
		query.executeUpdate();
	}

	@Override
	public void actualizaPagoRefeTran(VoucherRequestDto datosAdicionales) {
		Query query = entityManager.createNativeQuery(
				"UPDATE H2H_PROD_PAGO_REFE_TRAN SET DATOS_ADICIONALES = :datAdicionales WHERE ID_REG = :idReg");

		query.setParameter("datAdicionales", datosAdicionales.getTramaAdicionalesEntrada());
		query.setParameter("idReg", datosAdicionales.getIdReg());
		query.executeUpdate();
	}

}
