package mx.santander.h2h.monitoreo.service;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.config.SftpConnectProperties;
import mx.santander.h2h.monitoreo.constants.ErrorConstant;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.GeneralResponse;
import mx.santander.h2h.monitoreo.repository.IGeneralJPARepository;
import mx.santander.h2h.monitoreo.repository.IOperationsMonitorEntityManagerHelper4Repository;
import mx.santander.h2h.monitoreo.repository.IOperationsMonitorEntityManagerRepository;
import mx.santander.h2h.monitoreo.util.GenerateXML;

/**
 * Servicio para el Monitor de Operaciones
 *
 * @author Omar Rosas
 * @since 07/07/2023
 */
@Slf4j
@Service
public class OperationsMonitorAuxService implements IOperationsMonitorAuxService {
	@Autowired
	private IOperationsMonitorEntityManagerRepository repository;
	
	@Autowired
	private IOperationsMonitorEntityManagerHelper4Repository repo;
	
	@Autowired
	private IGeneralJPARepository generalRepo;
	@Autowired
	private SftpConnectProperties sftpConnectProperties;
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public GeneralResponse generaXmlOperaciones(OperationsMonitorQueryRequest request) {
		GeneralResponse response = new GeneralResponse();
		Map<String, String> params = new HashMap<>();
		params.put("plantilla", "rptComprobante.jasper");
		params.put("idCntr", request.getIdContrato());
		params.put("tipo", "pdf");
		params.put("correo", request.getCorreo());
		params.put("subsentencia", "");
        String comprobantesSel=repo.obtenerIdsComprobantes(request);
		
		//validamos query y vemos si es requerido cortar los registros:
		
		List<String> selpaginados= generalRepo.conteoResgistros(comprobantesSel);
		for(String qrComp:selpaginados) {
			log.info("Query: "+qrComp);
			try {
				params.put("sentencia", qrComp);
				log.info("Inicio Creacion del XML de Consulta de Operaciones");
				HttpHeaders header = new HttpHeaders();
				header.add("Content-Type", "application/json");
				ByteArrayInputStream xml = new ByteArrayInputStream(GenerateXML.creaXML(params));
				int n = xml.available();
				byte[] bytes = new byte[n];
				xml.read(bytes, 0, n);
				String xmls = new String(bytes, StandardCharsets.UTF_8);
				log.info("Xml: " + xmls);
				HttpEntity<String> entry = new HttpEntity<>(xmls, header);
				String url = sftpConnectProperties.getUrl();
				String path = sftpConnectProperties.getPathcrearxml();
				StringBuilder pathCompleto = new StringBuilder(path).append("?operacion=e").append("&contrato=");
				String[] arrUrl = url.split("\\://");
				UriComponents uriComponents = UriComponentsBuilder.newInstance().scheme(arrUrl[0]).host(arrUrl[1])
						.path(pathCompleto.toString()).build();
				log.info("Url de envio: " + uriComponents.toUriString());
				ResponseEntity<GeneralResponse> result = restTemplate.postForEntity(uriComponents.toUriString(), entry,
						GeneralResponse.class);
				response = Optional.ofNullable(result).map(HttpEntity::getBody).orElse(new GeneralResponse());
				log.info("Fin Creacion del XML de Consulta de Operaciones");
				
			} catch (RestClientResponseException e) {
				log.error("Error de en la respuesta: " , e);
				response.setError(ErrorConstant.FAILURE_CODE);
				response.setMessage("No se pudo crear el archivo por error en la respuesta de servidor sftp");
			} catch (RestClientException e) {
				log.error("Error de comunicacion: " , e);
				response.setError(ErrorConstant.FAILURE_CODE);
				response.setMessage("No se pudo crear el archivo por error de comunicacion con el servidor sftp");
			}
			}
		return response;
	}
	
	@Override
	public GeneralResponse generaXmlOperacionesExp(OperationsMonitorQueryRequest request) {
		GeneralResponse response = new GeneralResponse();
		Map<String, String> params = new HashMap<>();
		params.put("plantilla", "MonOperReportIntegrado.jasper");
		params.put("idCntr", request.getIdContrato());
		params.put("tipo", "csv");
		params.put("correo", request.getCorreo());
		params.put("subsentencia", "");
		params.put("sentencia", repository.consultaOperacionesExportar(request));
		
		try {
			log.info("Inicio creacion del XML para Exportacion de operaciones");
			HttpHeaders header = new HttpHeaders();
			header.add("Content-Type", "application/json");
			ByteArrayInputStream xml = new ByteArrayInputStream(GenerateXML.creaXML(params));
			int n = xml.available();
			byte[] bytes = new byte[n];
			xml.read(bytes, 0, n);
			String xmls = new String(bytes, StandardCharsets.UTF_8);
			log.info("Xml Exportaciones: " + xmls);
			HttpEntity<String> entry = new HttpEntity<>(xmls, header);
			String url = sftpConnectProperties.getUrl();
			String path = sftpConnectProperties.getPathcrearxml();
			StringBuilder pathCompleto = new StringBuilder(path).append("?operacion=e").append("&contrato=");
			String[] arrUrl = url.split("\\://");
			UriComponents uriComponents = UriComponentsBuilder.newInstance().scheme(arrUrl[0]).host(arrUrl[1])
					.path(pathCompleto.toString()).build();
			log.info("Url de envio: " + uriComponents.toUriString());
			ResponseEntity<GeneralResponse> result = restTemplate.postForEntity(uriComponents.toUriString(), entry,
					GeneralResponse.class);
			response = Optional.ofNullable(result).map(HttpEntity::getBody).orElse(new GeneralResponse());
			log.info("Fin Creacion del XML de Consulta de Operaciones para Exportacion");
		} catch (RestClientResponseException e) {
			log.error("Error de en la respuesta de exportacion: " , e);
			response.setError(ErrorConstant.FAILURE_CODE);
			response.setMessage("No se pudo crear el archivo por error en la respuesta de servidor sftp");
		} catch (RestClientException e) {
			log.error("Error de comunicacion: " , e);
			response.setError(ErrorConstant.FAILURE_CODE);
			response.setMessage("No se pudo crear el archivo por error de comunicacion con el servidor sftp");
		}
		
		return response;
	}

}
