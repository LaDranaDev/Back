package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.model.request.PutGetRequest;
import mx.santander.h2h.monitoreo.model.response.PutGetDto;
import mx.santander.h2h.monitoreo.model.response.PutGetRestResponse;

public interface IContractConnectionManagementPutGetService {

	PutGetRestResponse findPutGetFiles(PutGetRequest putGetRequest);

	PutGetRestResponse verAgregaPutGet(PutGetRequest putGetRequest, Boolean isSavePutGet);

	PutGetRestResponse enableDisablePutGet(PutGetDto putGetRequest);

}
