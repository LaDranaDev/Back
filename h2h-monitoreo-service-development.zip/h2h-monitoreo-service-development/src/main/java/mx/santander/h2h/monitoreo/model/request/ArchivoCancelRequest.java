package mx.santander.h2h.monitoreo.model.request;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/**
 * clase para el reuqest de los archivos de un cliente
 * implementaa la interfas de serializcion para el traspaso entre capas
 * Adicional se implementan las etiquetas lombok de
 * Geter, Seter,
 * para un desarrollo más rapido y con menos codigo.
 * @author NTTDATA-NRL
 * @version 1.0
 */
@Getter
@Setter
public class ArchivoCancelRequest implements Serializable {

    /** Serial version UID */
    private static final long serialVersionUID = 2177041640442496071L;

    /** Buc del cliente */
    @Pattern(regexp = "(^[a-zA-Z0-9]+$)?", message = "Datos de usuario no valido")
    @Size(min = 0, max = 15, message = "Datos de Usuario erroneo")
    private String bucCliente;

    /** Nombre del archivo a buscar */
    @Pattern(regexp = "(^[A-Za-z0-9 -_. ]+$)?", message = "Datos no validos")
    private String nomArchivo;

    /** Estatus del archivo a buscar */
    @Pattern(regexp = "(^[a-zA-Z0-9]+$)?", message = "Datos no validos")
    private String estatus;
    
    private List<String> idRegistros;
}
