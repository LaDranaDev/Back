package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.response.ArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.NivelGeneralResponse;

import java.util.List;

/**
 * Servicio para el Tracking de Archivos
 *
 * @author Daniel Ruiz
 * @since 19/04/2023
 */
public interface IArchivoTrackingService {
    
    NivelGeneralResponse inicio(String codCliente);

    ArchivoResponse obtenerConteoArchivos();
    
    ArchivoResponse obtenerDetalleArchivos(String codCliente);
    
    List<ArchivoResponse> filtradoOperacionesInicio(List<ArchivoResponse> listaArchivo);
    
    List<ArchivoResponse> obtenerListDetalleArchivos(String codCliente);
    
    ReportResponse getReportXls(String codCliente, String usuario);
}