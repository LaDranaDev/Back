package mx.santander.h2h.monitoreo.model.mapper;

import mx.santander.h2h.monitoreo.constants.MonitorSaldosConstants;
import mx.santander.h2h.monitoreo.model.response.MonitorSaldosResponse;

import jakarta.persistence.Tuple;
import java.io.Serializable;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

/**
 * MonitorSaldosModelMapping.
 * Mapea Objetos MonitorSaldosResponse y Entidades segun corresponda.
 *
 * @author Jesus Soto Aguilar
 * @since 20/04/2023
 */
public final class MonitorSaldosModelMapping implements Serializable {

    /**
     * Serial.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Constructor por defecto.
     */
    private MonitorSaldosModelMapping() {}

    /**
     * Convierte una lista de objetos de tipo Tuple a una lista de objetos de tipo MonitorSaldosResponse.
     * @param saldosReintentosList Lista de objetos Tuple
     * @return Lista de objetos MonitorSaldosResponse
     */
    public static List<MonitorSaldosResponse> mappingTupleListToDtoList(List<Tuple> saldosReintentosList) {
        return saldosReintentosList.stream()
                .map(MonitorSaldosModelMapping::mappingTupleToDto)
                .collect(Collectors.toList());
    }

    /**
     * Convierte un objeto de tipo Tuple a un objeto de tipo MonitorSaldosResponse.
     * @param saldosReintentosData Objeto de tipo Tuple
     * @return Objeto de tipo MonitorSaldosResponse
     */
    public static MonitorSaldosResponse mappingTupleToDto(Tuple saldosReintentosData) {
        MonitorSaldosResponse monitorSaldosResponse = null;
        if(saldosReintentosData != null) {
            monitorSaldosResponse = MonitorSaldosResponse.builder()
                    .cuentaOrdenante(saldosReintentosData.get("numeroCuenta", String.class))
                    .fechaEnvioConsulta(saldosReintentosData.get("fechaConsulta", String.class))
                    .horaEnvioConsulta(saldosReintentosData.get("horaConsulta", String.class))
                    .montoRequerido(saldosReintentosData.get("montoRequerido", String.class))
                    .saldoConsulta(saldosReintentosData.get("saldo", String.class))
                    .saldoFaltante(getMontoFaltante(saldosReintentosData.get("saldoFaltante", BigDecimal.class)))
                    .lineaCredito(saldosReintentosData.get("lineaCredito", Character.class).toString())
                    .nombreArchivo(saldosReintentosData.get("nombreArchivo", String.class))
                    .cveProdOper(saldosReintentosData.get("claveProducto", String.class))
                    .producto(saldosReintentosData.get("descProducto", String.class))
                    .build();
        }
        return monitorSaldosResponse;
    }

    /**
     * Obtiene el monto faltante.
     * @param montoFaltante valor del monto
     * @return monto faltante en tipo String
     */
    private static String  getMontoFaltante(BigDecimal montoFaltante) {
        if(montoFaltante.signum()== -1) {
            montoFaltante = montoFaltante.multiply(new BigDecimal("-1.0"));
            return "$"+formateaImporteGeneral(montoFaltante);
        } else {
            montoFaltante = new BigDecimal(MonitorSaldosConstants.CERO_CERO);
            return "$"+formateaImporteGeneral(montoFaltante);
        }
    }

    /**
     * Da formato al dato de monto faltante.
     * @param num valor del monto
     * @return dato formateado
     */
    private static String formateaImporteGeneral(BigDecimal num) {
        String formato;
        final DecimalFormatSymbols simbolos = DecimalFormatSymbols.getInstance(Locale.ENGLISH);
        final DecimalFormat format  = new DecimalFormat("###,###,###,###,##0.00", simbolos);

        formato = format.format(num);

        return formato;
    }
}
