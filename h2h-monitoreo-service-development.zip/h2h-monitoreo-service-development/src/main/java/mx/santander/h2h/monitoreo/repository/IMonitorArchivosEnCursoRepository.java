package mx.santander.h2h.monitoreo.repository;

import java.util.List;

import mx.santander.h2h.monitoreo.model.request.MonitorArchivosEnCursoRequest;
import mx.santander.h2h.monitoreo.model.response.MonitorDeArchivosEnCursoDetallesResponse;

/**
 * EntityManager para el Tracking de Archivos
 *
 * @author Daniel Ruiz
 * @since 19/04/2023
 */
public interface IMonitorArchivosEnCursoRepository {

    /**
     * Obtiene el detalle del archivo de acuerdo al estatus
     * @param fecha LocalDate
     * @param codCliente String
     * @param codEstatus String
     * @param nomArch String
     * @return Lista con los beans de resultado
     */
    List<MonitorDeArchivosEnCursoDetallesResponse> ejecutaBusquedaArchivosEnCurso(
    		MonitorArchivosEnCursoRequest request
    );

	/**
	 * Obtiene el detalle del archivo de acuerdo al estatus
	 * @param fecha LocalDate
	 * @param codCliente String
	 * @param codEstatus String
	 * @param nomArch String
	 * @return Lista con los beans de resultado
	 */
	List<MonitorDeArchivosEnCursoDetallesResponse> ejecutaBusquedaNivelProducto(String idArchivo, Integer idProducto, Integer idEstatus);


	/**
	 * Consulta el total de registros
	 * @param consultaOperaciones - Parámetros de consulta
	 * @return Numero de total de registros
	 */
	long countConsultaOperaciones(MonitorArchivosEnCursoRequest consultaOperaciones);

	/**
	 * Obtiene el detalle del archivo de acuerdo al estatus
	 * @param fecha LocalDate
	 * @param codCliente String
	 * @param codEstatus String
	 * @param nomArch String
	 * @return Lista con los beans de resultado
	 */
	List<MonitorDeArchivosEnCursoDetallesResponse> ejecutaBusquedaArchivosEnCursoReporte(
			MonitorArchivosEnCursoRequest request);

}
