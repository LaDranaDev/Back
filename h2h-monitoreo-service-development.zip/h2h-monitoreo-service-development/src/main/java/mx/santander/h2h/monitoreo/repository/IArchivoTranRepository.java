package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.constants.ArchivosConstants;
import mx.santander.h2h.monitoreo.model.entity.ArchivoTranEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jakarta.persistence.Tuple;

/**
 * Repositorio para la tabla H2H_ARCHIVO_TRAN.
 *
 * @author Daniel Ruiz
 * @since 19/04/2023
 */
@Repository
public interface IArchivoTranRepository extends JpaRepository<ArchivoTranEntity, Long> {

    /**
     * Consulta el total de archivos de acuerdo a la fecha y cliente.
     * @param fecha String con la fecha en formato 'dd/MM/yyyy'
     * @param codCliente String con el código del cliente
     * @return Tupla de los resultados
     */
    @Query(nativeQuery = true, value = ArchivosConstants.QUERY_CONTEO_ARCHIVOS)
    Tuple conteoArchivos(
            @Param("fecha") String fecha,
            @Param("codCliente") String codCliente
    );

}
