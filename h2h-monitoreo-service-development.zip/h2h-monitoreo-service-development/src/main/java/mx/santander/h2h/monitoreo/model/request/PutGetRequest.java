package mx.santander.h2h.monitoreo.model.request;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Dto para los datos de entrada del protocolo PUT/GET
 * 
 * @author Z483900
 * @since 03/05/2023
 *
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class PutGetRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 586564582381120645L;

	/**
	 * numeroContrato
	 */
	private String numeroContrato;

	/**
	 * codigoCliente
	 */
	private String codigoCliente;

	/**
	 * idContrato
	 */
	private String idContrato;

	/**
	 * idProtocolo
	 */
	private String idProtocolo;

	/**
	 * idProtocoloPara
	 */
	private String idProtocoloPara;

	/**
	 * idProtocoloPath1
	 */
	private String idProtocoloPath1;

	/**
	 * idProtocoloPath2
	 */
	private String idProtocoloPath2;

	/**
	 * tipoOperPG
	 */
	private String tipoOperPG;

	/**
	 * putGetSaveRequest
	 */
	private PutGetSaveRequest putGetSaveRequest;

}
