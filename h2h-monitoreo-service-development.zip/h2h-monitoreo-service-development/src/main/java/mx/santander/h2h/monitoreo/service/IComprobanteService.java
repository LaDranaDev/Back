package mx.santander.h2h.monitoreo.service;

import java.util.List;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;

/**
 * @author Daniel Ruis Servicio para los comprobantes del monitor de
 *         operaciones.
 */
public interface IComprobanteService {

	/**
	 * Generacion de comprobantes.
	 * 
	 * @param operaciones lista de operaciones
	 * @param formato     Formato para la respuesta
	 * @return ReportResponse con el archivo de respuesta
	 */
	ReportResponse comprobantes(List<OperationsMonitorQueryResponse> operaciones, String formato);

}
