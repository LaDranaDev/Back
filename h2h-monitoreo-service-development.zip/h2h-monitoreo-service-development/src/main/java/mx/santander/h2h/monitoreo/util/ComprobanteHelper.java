package mx.santander.h2h.monitoreo.util;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.ExceptionConverter;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.response.ComprobantesOperacionResponse;

import org.apache.commons.lang.StringUtils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**
 * Clase ComprobanteHelper
 * con metodos de ayuda para la generacion
 * de comprobantes
 *
 */
@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class ComprobanteHelper {

    /**
     * 	PAgo de inpuestos federales y SPID
     * @param registros a validar
     * @return respuesta
     */
    public static boolean isPIF(ComprobantesOperacionResponse registros) {
        boolean isPif=false;
        if(registros!=null && validaIsPifHelper(registros)){
            isPif= true;
        }
        if(registros!= null && "-33-".equals(registros.getEstatusMov())){
            isPif= true;
        }
        if(registros!= null && "-09-".equals(registros.getEstatusMov())){
            isPif= true;
        }
        return isPif;
    }

    /**
     * Metodo de ayuda para evitar
     * complejidad ciclomatica
     * @param registros ComprobantesOperacionDTO
     * @return boolean
     */
    private static boolean validaIsPifHelper(ComprobantesOperacionResponse registros) {
        return registros.isEsImpuFed()|| registros.isEsApoObr()|| registros.isEsPagRef()|| "-31-".equals(registros.getEstatusMov());
    }

    /**
     * esMigrado
     * metoso creado para evitar complejidad
     * @param registros
     * @return
     */
    public static boolean esMigrado(List<ComprobantesOperacionResponse> registros) {
        List<String> tipoOpers = Arrays.asList(
                "TEF", "NOMINA MISMO BANCO", "NOMINA BANCARIA", "TMB", "TRANSFERENCIAS BANCARIAS"
        );
        return registros.get(0).isEsPagoTDC()
                || registros.get(0).isEsConfirming()
                || tipoOpers.stream().anyMatch(
                        tipoOper -> registros.get(0).getTipoOper().toUpperCase().contains(tipoOper)
        );
    }

    /**
     * Metodo para validar
     * si las operaciones
     * son de tipo:
     * TRANSFERENCIAS INTERNACIONALES CAMBIARIAS
     * TRANSFERENCIAS VOSTRO INTERBANCARIAS
     * o
     * TRANSFERENCIAS VOSTRO MISMO BANCO
     * @param tipoOper
     * @return
     */
    public static boolean esVostro(String tipoOper) {

        return tipoOper.toUpperCase().contains("-32-") //esporCveProd
                || tipoOper.toUpperCase().contains("-38-")
                || tipoOper.toUpperCase().contains("-39-")
                || tipoOper.toUpperCase().contains("TRANSFERENCIAS INTERNACIONALES CAMBIARIAS") //es por descripcion
                || tipoOper.toUpperCase().contains("TRANSFERENCIAS VOSTRO INTERBANCARIAS")
                || tipoOper.toUpperCase().contains("TRANSFERENCIAS VOSTRO MISMO BANCO");
    }

    /**
     * esOrdPagAtm
     * @param tipoOper
     * @return
     */
    public static boolean esOrdPagAtm(String tipoOper) {
        return tipoOper.toUpperCase().contains("ORDEN DE PAGO ATM")
                || tipoOper.toUpperCase().contains("85");
    }

    /**
     * generarComprobante
     * @param registros
     * @return
     */
    public static byte[] generarComprobante(List<ComprobantesOperacionResponse> registros) {
        byte[] comprobante=null;
        if(registros.get(0).isEsPagoTDC()){
            comprobante= ComprobanteGenerador.generaPagoTDC(registros.get(0));
        }else if(registros.get(0).isEsConfirming()){
            comprobante= ComprobanteGenerador.generaConfirming(registros.get(0));
        }else if(registros.get(0).getTipoOper().toUpperCase().contains("TEF")){
            comprobante=ComprobanteGenerador.generaTEF(registros.get(0));
        }else if(registros.get(0).getTipoOper().toUpperCase().contains("NOMINA MISMO BANCO") ||
                registros.get(0).getTipoOper().toUpperCase().contains("NOMINA BANCARIA")){
            comprobante=ComprobanteGenerador.generaNominaMismoBanco(registros.get(0));
        }else if(registros.get(0).getTipoOper().toUpperCase().contains("TMB") ||
                registros.get(0).getTipoOper().toUpperCase().contains("TRANSFERENCIAS BANCARIAS")){
            comprobante=ComprobanteGenerador.generaTMB(registros.get(0));
        }else if(registros.get(0).getTipoOper().toUpperCase().contains("ADUANALES")) {
            comprobante=ComprobanteGenerador.generaPagImpAdua(registros.get(0));
        }
        return comprobante;
    }

    /**
     * Metodo para validar si es Spei y es el parametro de Homologar SPEI en su contrato
     * @param dto con datos para la validacion
     * @return String
     */
    public static String validaEsSpei(ComprobantesOperacionResponse dto) {
        if(dto.getTipoOper().toUpperCase().trim().contains("SPEI")  && "A".equals(dto.getRfcProveedor())){
            return StringUtils.defaultString(dto.getCuentaAbono()) + "_" + StringUtils.defaultString(dto
                    .getRefInterbancaria()) + ".pdf";
        }else{
            return StringUtils.defaultString(dto.getCuentaAbono()) + "_" + StringUtils.defaultString(dto
                    .getFolioOp().toString()) + ".pdf";
        }
    }

    /**
     * Metodo para la concatenacion de
     * los PDF's este se agregara en un arreglo
     * de bytes par enviar al explorador y se
     * pueda descargar el archivo
     * -
     * @param pdfFiles archivos
     * Retorna  un array de bytes de los pdfs unidos
     * @return byte con todos loes reportes generados
     * @throws BusinessException mensaje de erro
     */
    public static byte[] concatenarPDFs(List<byte[]> pdfFiles) throws BusinessException {

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        boolean paginate = true;

        try ( Document document = new Document() ) {
            List<PdfReader> readers = new ArrayList<>();
            for(int i=0; i<pdfFiles.size(); i++){
                PdfReader pdfReader = new PdfReader(pdfFiles.get(i));
                readers.add(pdfReader);
            }

            PdfWriter writer = PdfWriter.getInstance(document, outputStream);

            document.open();
            PdfContentByte cb = writer.getDirectContent();

            Iterator<PdfReader> iteratorPDFReader = readers.iterator();

            enwhilepdf(cb,iteratorPDFReader,document,writer,paginate);
            outputStream.flush();
        } catch (DocumentException e) {
            throw new BusinessException("Problemas al generar el documento DE" + e.getMessage());
        } catch (IOException e) {
            throw new BusinessException("Problemas al generar el documento IO" + e.getMessage());
        } catch (ExceptionConverter e) {
            return new byte[] {};
        } finally {
            try {
                if (outputStream != null){
                    outputStream.close();
                }
            } catch (IOException ioe) {
                log.error(ioe.getMessage());
            }
        }

        return outputStream.toByteArray();
    }

    /**
     * Metodo para agregar los pedf en el documento
     * final a mostrar como
     * comprobantes de operaciones
     * de los diferentes productos
     * -
     * @param cb PdfContentByte
     * @param iteratorPDFReader Iterator
     * @param document document
     * @param writer writer
     * @param paginate boolean
     */
    private static void enwhilepdf(PdfContentByte cb, Iterator<PdfReader> iteratorPDFReader,
                              Document document, PdfWriter writer, boolean paginate) {
        int pageOfCurrentReaderPDF=0;
        PdfImportedPage page;
        while (iteratorPDFReader.hasNext()) {
            PdfReader pdfReader = iteratorPDFReader.next();
            log.debug("paginas::::pdfReader-> " +pdfReader.getNumberOfPages());
            while (pageOfCurrentReaderPDF < pdfReader.getNumberOfPages()) {
                Rectangle rectangle = pdfReader.getPageSizeWithRotation(1);
                document.setPageSize(rectangle);
                document.newPage();
                pageOfCurrentReaderPDF++;
                page = writer.getImportedPage(pdfReader,pageOfCurrentReaderPDF);
                switch (rectangle.getRotation()) {
                    case 0:
                        cb.addTemplate(page, 1f, 0, 0, 1f, 0, 0);
                        break;
                    case 90:
                        cb.addTemplate(page, 0, -1f, 1f, 0, 0, pdfReader.getPageSizeWithRotation(1).getHeight());
                        break;
                    case 180:
                        cb.addTemplate(page, -1f, 0, 0, -1f, 0, 0);
                        break;
                    case 270:
                        cb.addTemplate(page, 0, 1.0F, -1.0F, 0, pdfReader.getPageSizeWithRotation(1).getWidth(), 0);
                        break;
                    default:
                        break;
                }
                if (paginate) {
                    cb.beginText();
                    cb.getPdfDocument().getPageSize();
                    cb.endText();
                }
            }
            pageOfCurrentReaderPDF = 0;
        }

    }

}
