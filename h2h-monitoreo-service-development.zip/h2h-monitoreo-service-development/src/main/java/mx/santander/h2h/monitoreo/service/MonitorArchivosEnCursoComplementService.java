package mx.santander.h2h.monitoreo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.santander.h2h.monitoreo.model.response.ComboDosResponse;
import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import mx.santander.h2h.monitoreo.model.response.ResultTrackingResponse;
import mx.santander.h2h.monitoreo.repository.IConsultaTrackingProductoRepository;
import mx.santander.h2h.monitoreo.repository.IMonitorArchivosEnCursoNivelOperacionRepository;

/**
 * Clase implemntacion con los metodos declarados
 * en su interface IMonitorArchivosEnCursoComplementService
 */
@Service
public class MonitorArchivosEnCursoComplementService implements IMonitorArchivosEnCursoComplementService {

	/**
	 * consultaTrackingProductoRepository
	 */
	@Autowired
	private IConsultaTrackingProductoRepository consultaTrackingProductoRepository;
	
	/**
	 * entityManagerOperacion
	 */
	@Autowired
	private IMonitorArchivosEnCursoNivelOperacionRepository entityManagerOperacion;

	/**
	 * Obtiene Catalogo de Producto
	 * @return List<ComboDosResponse>
	 */
	@Override
	public List<ComboResponse> obtenerCatalogoProductoProd() {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		resultTrackingResponse = consultaTrackingProductoRepository.obtenerCatalogoProductos();
		return resultTrackingResponse.getListCombo();
	}

	/**
	 * Obtiene le catalogo de estatus
	 * @return List<ComboResponse>
	 */
	@Override
	public List<ComboResponse> obtenerCatalogoEstatusProd() {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		resultTrackingResponse = consultaTrackingProductoRepository.obtenerCatalogoEstatus("R");
		return resultTrackingResponse.getListCombo();
	}

	/**
	 * Obtiene el catalogo de Productos Prod
	 * @return List<ComboResponse>
	 */
	@Override
	public List<ComboDosResponse> obtenerCatalogoProducto() {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		resultTrackingResponse = entityManagerOperacion.obtenerCatalogoProductos();
		return resultTrackingResponse.getListComboDos();
	}

	/**
	 * Obtiene el catalogo de estatus Prod
	 * @return List<ComboResponse>
	 */
	@Override
	public List<ComboResponse> obtenerCatalogoEstatus() {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		resultTrackingResponse = entityManagerOperacion.obtenerCatalogoEstatus();
		return resultTrackingResponse.getListCombo();
	}
	
}
