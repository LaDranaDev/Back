package mx.santander.h2h.monitoreo.constants;

/**
 * Constantes para la aplicación.
 *
 * @author Paul Quintero
 * @since 19/04/2022
 */
public final class ApiConstants {
	/**
	 * Prefijo para las propiedades de la aplicación.
	 */
	public static final String PROPERTY_PREFIX = "api.monitoreo.properties";
	/**
	 * Propiedades para swagger.
	 */
	public static final String SWAGGER_PROPERTIES = "swagger-config";
	/**
	 * Llave req.time.
	 */
	public static final String TIME_REQ_ATTRIBUTE = "req.time";
	/**
	 * Llave para el atributo uuid header.
	 */
	public static final String UUID_MDC_LABEL = "mdc.uuid";
	/**
	 * UUID header.
	 */
	public static final String HEADER_UUID = "UUID";
	/**
	 * Muestra el inicio de la petición.
	 */
	public static final String START_REQUEST = "Inicia Llamado [{}]";
	/**
	 * Muestra el tiempo de petición y respuesta.
	 */
	public static final String TIME_ELAPSED_MESSAGE = "Time elapsed for request round trip [{}]: {} ms";
	/**
	 * Formato para fecha completa.
	 */
	public static final String DATE_TIME_FULL_PATTERN = "yyyy-MM-dd hh:mm:ss";
	/**
	 * Espacio en blanco.
	 */
	public static final String WHITE_SPACE = " ";
	/**
	 * Descripcion de producto.
	 */
	public static final String PRODUCT_PROGRAMMING = "PRODUTOS CON PROGRAMACION POR HORARIO";
	/**
	 * Caracter coma
	 */
	public static final String COMMA = ",";
	/**
	 * Valor para los select no seleccionados
	 */
	public static final String VALUE_NOT_SELECTED = "-1";

	public static final String VALOR_VACIO = "";

	public static final String VALOR_CERO = "0";

	public static final String VALOR_COMA = ",";

	public static final String CODE_RES_WS_COMPROBANTE = "OKSD0000";

	public static final String EMPTY_STRING = "";

	public static final String LINEA_CAPUTRA = "Linea captura: ";

	public static final String FECHA = "Fecha: ";

	public static final String IMPORTE = "Importe: ";

	public static final String REFERENCIA = "Referencia: ";

	public static final String NUMERO_CUENTA = "Numero cuenta: ";

	public static final String CANAL = "Canal: ";

	/**
	 * Constructor privado.
	 */
	private ApiConstants() {
	}
}
