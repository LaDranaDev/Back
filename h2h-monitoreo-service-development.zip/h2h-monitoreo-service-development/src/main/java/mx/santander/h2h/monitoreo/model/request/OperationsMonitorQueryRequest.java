/**
* Santander SCIB - Banco Santander Negocios Globales
* Todos los derechos reservados
* OperationsMonitorQueryRequest.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <20 nov 2024 09:33:15>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.model.request;

import java.io.Serializable;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Request para realizar la consulta al monitor de operaciones
 *
 * @author Daniel Ruiz
 * @since 13/04/2023
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
public class OperationsMonitorQueryRequest implements Serializable {

	/** Serial id */
    private static final long serialVersionUID = -8174432469247427367L;

    /** BUC del cliente */
    @Size(min = 0, max = 8, message = "El buc debe tener 8 dígitos")
    @Pattern(regexp = "(^[0-9 ]+$)?",  message = "Solo se permiten caracteres numéricos")
    private String buc;

    /** Cuenta cargo */
    @Size(min = 0, max = 12, message = "La cuenta cargo debe tener máximo 12 dígitos")
    @Pattern(regexp = "(^[0-9 ]+$)?",  message = "Solo se permiten caracteres numéricos")
    private String cuentaCargo;

    /** Cuenta abono */
    @Size(min = 0, max = 18, message = "La cuenta abono debe tener máximo 18 dígitos")
    @Pattern(regexp = "(^[0-9 ]+$)?",  message = "Solo se permiten caracteres numéricos")
    private String cuentaAbono;

    /** ID de producto */
    @Size(min = 0, max = 15, message = "El producto debe tener máximo 15 dígitos")
    @Pattern(regexp = "(^[0-9 ]+$)?",  message = "Solo se permiten caracteres numéricos")
    private String idProducto;

    /** Archivo */
    @Size(min = 0, max = 100, message = "El nombre de archivo debe tener máximo 100 dígitos")
    @Pattern(regexp = "(^((([a-z_-])?/.*)|(([a-zA-Z_]:)?(\\\\([a-zA-Z0-9_.-]+\\\\?)?))?)+(([a-zA-Z0-9._-]+)(.([.a-zA-Z0-9_-]))?)+$)?", message = "Archivo No valido")
    private String nombreArchivo;

    /** Importe **/
    @Size(min = 0, max = 15, message = "El importe debe tener máximo 15 dígitos")
    @Pattern(regexp = "(^\\d{1,15}(\\.\\d{1,2})?$)?",  message = "Solo se permiten caracteres numéricos")
    private String importe;

    /** Referencia */
    @Size(min = 0, max = 20, message = "La referencia debe tener máximo 20 dígitos")
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?",  message = "No se permiten caracteres especiales")
    private String referencia;

    /** Divisa **/
    @Size(min = 0, max = 3, message = "La divisa debe tener máximo 3 dígitos")
    @Pattern(regexp = "(^[a-zA-Z0]+$)?",  message = "No se permiten caracteres especiales")
    private String divisa;

    /** ID de estatus */
    @Size(min = 0, max = 3, message = "Código de estatus inválido")
    @Pattern(regexp = "(^[0-9 ]+$)?",  message = "No se permiten caracteres especiales")
    private String idEstatus;

    /** Numero de contrato */
    @Size(min = 0, max = 12, message = "El contrato debe tener entre 8 y 12 dígitos")
    @Pattern(regexp = "(^[0-9]+$)?",  message = "Solo se permiten caracteres numéricos")
    private String contrato;

    /** Fecha inicial */
    @Size(min = 0, max = 10, message = "La fecha de inicio debe tener máximo 10 dígitos")
    @Pattern(regexp = "(((\\d{2})|(\\d{4}))([-/])\\d{2}([-/])((\\d{2})|(\\d{4})))( (\\d{2}:\\d{2}:\\d{2})?)?",  message = "Formato de fecha Inválido")
    @NotNull
    private String fechaInicial;

    /** Fecha final */
    @Size(min = 0, max = 10, message = "La fecha fin debe tener máximo 10 dígitos")
    @Pattern(regexp = "(((\\d{2})|(\\d{4}))([-/])\\d{2}([-/])((\\d{2})|(\\d{4})))( (\\d{2}:\\d{2}:\\d{2})?)?",  message = "Formato de fecha Inválido")
    @NotNull
    private String fechaFinal;

    /** Numero de orden */
    @Size(min = 0, max = 30, message = "El número de orden debe tener máximo 30 dígitos")
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?",  message = "No se permiten caracteres especiales")
    private String numeroOrden;

    /** Nombre Beneficiario */
    @Size(min = 0, max = 100, message = "El nombre de beneficiario debe tener máximo 100 dígitos")
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?",  message = "No se permiten caracteres especiales")
    private String nombreBeneficiario;

    /** Pagina  */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Pagina Erronea")
    private String pagina;

    /** tamanio pagina */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Tamaño de Pagina")
    private String tamanioPagina;

    /** order by */
    @Pattern(regexp = "(^[a-zA-Z0-9 _-]+$)?", message = "Orden no valido")
    private String orderBy;

    /** Id Reg - Referencia H2H */
    @Size(min = 0, max = 18, message = "El id movimiento debe tener máximo 12 dígitos")
    @Pattern(regexp = "(^[0-9 ]+$)?",  message = "Solo se permiten caracteres numéricos")
    private String idReg;

    /** Importe con signo de pesos y seprado por comas */
    @Pattern(regexp = "(^\\d{1,10}(\\.\\d{1,2})?$)?", message = "Importe no valido")
    private String importeFormateado;

    /** tipo */
    @Size(min = 0, max = 100, message = "El tipo debe tener máximo 100 dígitos")
    @Pattern(regexp = "(^[a-zA-Z0-9_ -]+$)?",  message = "No se permiten caracteres especiales")
    private String tipo;
    
    /** Estatus */
    @Pattern(regexp = "(^[0-9A-Za-zñÑáéíóúÁÉÍÓÚ_. -]+$)?", message = "Datos no validos")
    @Size(min = 0, max = 120, message = "Datos erroneos")
    private String descripcionEstatus;
    
    /** Producto */
    @Pattern(regexp = "(^[0-9A-Za-zñÑáéíóúÁÉÍÓÚ_. -]+$)?", message = "Datos no validos")
    @Size(min = 0, max = 120, message = "Datos erroneos")
    private String nombreProducto;

    /** Numero empleado */
    @Size(min = 0, max = 20, message = "El número de empleado debe tener máximo 20 dígitos")
    @Pattern(regexp = "(^[0-9 ]+$)?",  message = "No se permiten caracteres especiales")
    private String numEmpleado;

    /** Numero tarjeta */
    @Size(min = 0, max = 16, message = "El número de tarjeta debe tener máximo 16 dígitos")
    @Pattern(regexp = "(^[0-9 ]+$)?",  message = "No se permiten caracteres especiales")
    private String numTarjeta;

    /** Sucursal tutora */
    @Size(min = 0, max = 50, message = "La suc tutora debe tener máximo 50 dígitos")
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?",  message = "No se permiten caracteres especiales")
    private String sucTutora;

    /** Parametro clave proveedor */
    @Size(min = 0, max = 50, message = "La clave de proveedor debe tener máximo 50 dígitos")
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?",  message = "No se permiten caracteres especiales")
    private String cveProveedor;

    /** parametro tipo operacion */
    private String tipOperacion;
    
    /** Folio SUA */
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
    private String folioSUA;
    
    /** Linea Captura */
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
    private String lineaCaptura;
    
    /** Convenio */
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
    private String convenio;
    
    /** registro Patronal */
    private String regPat;
    
    /** esLiquidaciones */
    private boolean esLiquidaciones;
    
    /** filtrarBUCS */
    private boolean filtrarBUCS;
    
    /** bucsSensibles */
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
    private String bucsSensibles;
    
    /** Hora Programacion */
    @Pattern(regexp = "(^\\d{2}:\\d{2}((:\\d{2})?)+$)?|^Todos$", message = "Hora No Valida")
    private String horaProgramacion;

    /**Usuario de la sesion*/
    @Size(min = 0, max = 12, message = "El user debe tener máximo 12 dígitos")
    @Pattern(regexp = "(^[a-zA-Z0-9]+$)?",  message = "Solo se permiten caracteres numéricos")
    private String user;

    /**Correo del usuario*/
    @Email
    private String correo;
    
    /**Id Contrato*/
    private String idContrato;
    
    /** Declaracion de String para personaAutorizada. */
    @Pattern(regexp = "(^[0-9A-Za-zñÑáéíóúÁÉÍÓÚ ]+$)?", message = "Datos no validos")
    @Size(min = 0, max = 120, message = "Datos erroneos")
    private String personaAutorizada;
}
