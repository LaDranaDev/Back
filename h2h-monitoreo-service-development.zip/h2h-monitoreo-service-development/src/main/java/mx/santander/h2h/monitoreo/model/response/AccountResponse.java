package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * AccountResponse Dtop para la respuesta del catalogo de cuentas de contratos
 * 
 * @author Felipe Cazarez
 * @since 30/06/2022
 */
@Getter
@Setter
@NoArgsConstructor
public class AccountResponse implements Serializable {

	/**
	 * id serial
	 */
	private static final long serialVersionUID = 5637596671030927432L;

	/**
	 * id del contrato de la cuenta
	 */
	private Integer idContratoCuenta;

	/**
	 * id del contrato
	 */
	private int idContrato;

	/**
	 * numero de cuenta
	 */
	private String numCuenta;

	/**
	 * tipo de cuenta
	 */
	private String tipoCuenta;

	/**
	 * Bandera que indica si una cuenta es interbancaria o bancaria
	 */
	private String bandIntercambiaria;

	/**
	 * Bandera que indica si una persona es fisica o moral
	 */
	private String bandPersonalidad;

	/**
	 * titular de la cuenta
	 */
	private String titular;

	/**
	 * fecha de alta de la cuenta
	 */
	private String fechaAlta;

	/**
	 * indica si es cuenta de terceros
	 */
	private Boolean terceros;

	/**
	 * estatus de la cuenta
	 */
	private String statusCuenta;

	/**
	 * codigo de la cuenta
	 */
	private String codigo;

	/**
	 * descripcion de validar si la cuenta es de terceros o propios
	 */
	private String terceroPropio;

	/**
	 * Identificador del estatus de la cuenta
	 */
	private String bandActivo;

	/**
	 * Identificador del id de la divisa
	 */
	private String idDivisa;

	/**
	 * idcontrato String
	 */
	private String idContratoStr;

	/**
	 * Identificador para saber el numero de comisiones
	 */
	private String noComisiones;

	/**
	 * Bic
	 */
	private String bic;

	/**
	 * Bic
	 */
	private String bicAnterior;

	/**
	 * bandera para actualizar solo bic
	 */
	private Boolean actualizaBic;

}
