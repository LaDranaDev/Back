package mx.santander.h2h.monitoreo.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import mx.santander.h2h.monitoreo.model.response.ProtocolResponse;
import mx.santander.h2h.monitoreo.model.response.PutGetDto;
import mx.santander.h2h.monitoreo.model.response.PutGetServiceResponse;
import mx.santander.h2h.monitoreo.service.IContractConnectionManagementPutGetFindDataService;

@Component
public class ContractConnectionManagementPutGetMapping {

	@Autowired
	private IContractConnectionManagementPutGetFindDataService iContractConnectionManagementPutGetFindDataService;

	public PutGetServiceResponse mapFromPutGetResponseToPutGetServiceResponse(List<Object[]> putGetResponse, PutGetServiceResponse putGetServiceResponse) {

		List<PutGetDto> listPutGetDtoResponse = new ArrayList<>();

		for (Object[] putGet : putGetResponse) {

			PutGetDto putGetDtoResponse = new PutGetDto();

			putGetDtoResponse.setDirectorio(Objects.toString(putGet[5], ""));
			putGetDtoResponse.setPuerto(Objects.toString(putGet[10], ""));
			putGetDtoResponse.setServidor(Objects.toString(putGet[9], ""));
			putGetDtoResponse.setUserId(Objects.toString(putGet[11], ""));
			putGetDtoResponse.setPatron(Objects.toString(putGet[6], "").trim());
			putGetDtoResponse.setPatronGet(Objects.toString(putGet[6], "").trim());
			putGetDtoResponse.setTipoProceso(Objects.toString(putGet[7], ""));
			putGetDtoResponse.setIdPtclPara(Objects.toString(putGet[0], ""));
			putGetDtoResponse.setIdPtclPath(Objects.toString(putGet[4], ""));
			putGetDtoResponse.setEstatus(Objects.toString(putGet[8], ""));

			if ("1".equals(Objects.toString(putGet[2], ""))) {
				iContractConnectionManagementPutGetFindDataService.buscarDatosdeSFTP(putGetDtoResponse);
			} else if ("2".equals(Objects.toString(putGet[2], ""))) {
				iContractConnectionManagementPutGetFindDataService.buscarDatosdeCD(putGetDtoResponse);
			} else if ("5".equals(Objects.toString(putGet[2], ""))) {
				iContractConnectionManagementPutGetFindDataService.buscarDatosdeWS(putGetDtoResponse);
			}

			putGetServiceResponse.setNombreProtocolo(Objects.toString(putGet[1], ""));
			putGetServiceResponse.setIdProtocolo(Objects.toString(putGet[2], ""));
			putGetServiceResponse.setIdPara(Objects.toString(putGet[0], ""));
			putGetServiceResponse.setIdContrato(Objects.toString(putGet[3], ""));
			putGetServiceResponse.setHostOs(Objects.toString(putGet[12], ""));

			listPutGetDtoResponse.add(putGetDtoResponse);

		}

		putGetServiceResponse.setRegistrosPG(listPutGetDtoResponse);

		return putGetServiceResponse;
	}

	public List<ProtocolResponse> mapFromListProtocolsToListProtocolsResponse(List<Object[]> listProtocols) {

		List<ProtocolResponse> listProtocolResponse = new ArrayList<>();

		for (Object[] protocol : listProtocols) {

			ProtocolResponse protocolResponse = new ProtocolResponse();

			protocolResponse.setIdProtocolo(Integer.valueOf(protocol[0].toString()));
			protocolResponse.setNombre(Objects.toString(protocol[1], ""));

			listProtocolResponse.add(protocolResponse);

		}

		return listProtocolResponse;
	}

	public PutGetServiceResponse mapFromPutGetFilesResponseToPutGetServiceResponse(
			List<Object[]> listPutGetFilesResponse) {

		PutGetServiceResponse putGetServiceResponse = new PutGetServiceResponse();

		List<PutGetDto> listPutGetDtoResponse = new ArrayList<>();

		for (Object[] putGetFile : listPutGetFilesResponse) {

			PutGetDto putGetDtoResponse = new PutGetDto();

			putGetDtoResponse.setDirectorio(null);

			putGetDtoResponse.setIdPtclPara(Objects.toString(putGetFile[0], ""));
			putGetDtoResponse.setIdPtclPath(Objects.toString(putGetFile[4], ""));
			putGetDtoResponse.setDirectorio(Objects.toString(putGetFile[5], ""));
			putGetDtoResponse.setPatron(Objects.toString(putGetFile[6], "").trim());
			putGetDtoResponse.setPatronGet(Objects.toString(putGetFile[6], "").trim());
			putGetDtoResponse.setTipoProceso(Objects.toString(putGetFile[7], ""));
			putGetDtoResponse.setEstatus(Objects.toString(putGetFile[8], ""));
			putGetDtoResponse.setServidor(Objects.toString(putGetFile[9], ""));
			putGetDtoResponse.setPuerto(Objects.toString(putGetFile[10], ""));
			putGetDtoResponse.setUserId(Objects.toString(putGetFile[11], ""));

			putGetServiceResponse.setIdPara(Objects.toString(putGetFile[0], ""));
			putGetServiceResponse.setNombreProtocolo(Objects.toString(putGetFile[1], ""));
			putGetServiceResponse.setIdProtocolo(Objects.toString(putGetFile[2], ""));
			putGetServiceResponse.setIdContrato(Objects.toString(putGetFile[3], ""));
			putGetServiceResponse.setHostOs(Objects.toString(putGetFile[12], ""));

			listPutGetDtoResponse.add(putGetDtoResponse);

		}

		putGetServiceResponse.setRegistrosPG(listPutGetDtoResponse);

		return putGetServiceResponse;
	}

}
