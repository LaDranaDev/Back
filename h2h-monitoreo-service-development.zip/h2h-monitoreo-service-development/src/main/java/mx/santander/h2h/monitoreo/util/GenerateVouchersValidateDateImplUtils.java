package mx.santander.h2h.monitoreo.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;

@Component
@Slf4j
public class GenerateVouchersValidateDateImplUtils implements IGenerateVouchersValidateDateUtils {

	/**
	 * Descripción: Método que realiza la validación y el cálculo de los 3 meses
	 *
	 * @author sbautish
	 * @param operationsMonitorQueryRequest lista de operaciones
	 * @throws BusinessException, ParseException excepciones controladas
	 *
	 */
	@Override
	public void validateDate(OperationsMonitorQueryRequest operationsMonitorQueryRequest) throws BusinessException {

		String mensageVal = "La Fecha de Inicio Solo Puede Tener Una Antig\u00FCedad M\u00E1xima de Noventa D\u00EDas ";

		try {

			/** The date format */
			SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");

			Date fechaIni = formatoFecha.parse(operationsMonitorQueryRequest.getFechaInicial());

			Date fechaFin = formatoFecha.parse(operationsMonitorQueryRequest.getFechaFinal());

			Calendar calc = Calendar.getInstance();
			calc.set(Calendar.HOUR_OF_DAY, 0);
			calc.set(Calendar.MINUTE, 0);
			calc.set(Calendar.SECOND, 0);
			calc.set(Calendar.MILLISECOND, 0);

			Long timeIni = calc.getTime().getTime();

			/**Se valida fecha Ini*/
			if (fechaIni.getTime() > timeIni || fechaFin.getTime() > timeIni) {

				throw new BusinessException("VALFEC04", "La Fecha de Inicio y Fin Deben de Ser Menor o Igual a D\u00EDa de Hoy ".concat(formatoFecha.format(new Date(timeIni))));

			}

			Long timeFin = fechaFin.getTime();

			/**Se valida fecha Ini*/
			if (fechaIni.getTime() > timeFin) {

				throw new BusinessException("VALFEC01", "La Fecha de Inicio No Puede Ser Mayor a la fecha de fin ".concat(formatoFecha.format(new Date(timeFin))));

			}

			calc.add(Calendar.DAY_OF_YEAR, -91);

			Long maxFechaInicial = calc.getTime().getTime();

			/**Se validan 90 dias*/
			if (fechaIni.getTime() < maxFechaInicial) {

				throw new BusinessException("VALFEC03", mensageVal.concat(formatoFecha.format(new Date(maxFechaInicial))));

			}

			calc.setTime(new Date());
			calc.add(Calendar.DAY_OF_MONTH, -6);
			calc.set(Calendar.HOUR_OF_DAY, 0);
			calc.set(Calendar.MINUTE, 0);
			calc.set(Calendar.SECOND, 0);
			calc.set(Calendar.MILLISECOND, 0);

		} catch (ParseException e) {

			e.printStackTrace();

			log.error(e.getMessage(), e);

			throw new BusinessException("VALFEC00", mensageVal.concat(Locale.getDefault().toString().concat(" DD/MM/YYYY")));

		}

	}
	
	/**
	 * Descripción : Método que realiza la generación de la fecha
	 * 
	 * @return Dato de la fecha en texto
	 */
	public static String generarFecha() {

		/** Se genera un dateformat */
		final SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault());

		/** Se retorna la fecha:hora */
		return dateFormat.format(new Date()).toString();

	}
	
	/**
	 * Descripción : Método que realiza el set de inicio y fin de paginación
	 * 
	 * @param totalPaginas total de páginas
	 * @return retorna fin páginas
	 */
	public static Integer calculaInicioFin(Integer totalPaginas) {

		Integer fin = 0;

		if (totalPaginas < 17) {
			fin = totalPaginas;
		} else {
			fin = 17;
		}

		return fin;
	}

}
