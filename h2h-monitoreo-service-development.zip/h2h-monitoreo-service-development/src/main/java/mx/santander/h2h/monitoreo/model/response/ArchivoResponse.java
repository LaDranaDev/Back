package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class ArchivoResponse implements Serializable {

	/** Serial de la clase. */
	private static final long serialVersionUID = 293305367636950536L;

	/** Total de archivos recibidos.*/
	private BigDecimal totArchRecib;
	
	/** Total de operaciones recibidas.*/
	private BigDecimal totOpeRecib;
	
	/** Total del monto recibido. */
	private BigDecimal totMontoRecib;
	
	/** Nombre del cliente. */
	private String cliente;
	
	/** Codigo del cliente. */
	private String codCliente;
	
	/** Archivos con alerta. */
	private BigDecimal totAlerta;
	
	/** Archivos en duplicado. */
	private BigDecimal totDupl;
	
	/** Archivos en espera. */
	private BigDecimal totEsp;
	
	/** Archivos en proceso. */
	private BigDecimal totEnProc;
	
	/** Archivos en enrollment. */
	private BigDecimal totEnroll;
	
	/** Archivos procesados. */
	private BigDecimal totProc;
	
	/** Archivos programados. */
	private BigDecimal totProg;
	
	/** Archivos rechazados. */
	private BigDecimal totRecha;
	
	/** Archivos recibidos. */
	private BigDecimal totRecib;
	
	/** Archivos validados. */
	private BigDecimal totVald;
	
	/** Total del monto recibido formateado. */
	private String totMontoRecibFmt;
}
