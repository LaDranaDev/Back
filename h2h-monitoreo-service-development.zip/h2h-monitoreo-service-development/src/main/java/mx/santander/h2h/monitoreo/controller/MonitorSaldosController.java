package mx.santander.h2h.monitoreo.controller;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import mx.santander.h2h.monitoreo.constants.RoutesConstant;
import mx.santander.h2h.monitoreo.model.report.request.MonitorSaldosReportRequest;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.MonitorSaldosRequest;
import mx.santander.h2h.monitoreo.model.response.MonitorSaldosResponse;
import mx.santander.h2h.monitoreo.service.IMonitorSaldosReportService;
import mx.santander.h2h.monitoreo.service.IMonitorSaldosService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * MonitorSaldosController.
 * Controller para atender las peticiones de la vista Monitor Saldos.
 *
 * @author Jesus Soto Aguilar
 * @since 20/04/2023
 */
@Validated
@RestController
@RequestMapping(RoutesConstant.MONITOREO_SALDOS)
public class MonitorSaldosController {

    /**
     * Servicio de servicio para obtener los saldos reintentos.
     */
    private final IMonitorSaldosService monitorSaldosService;

    /**
     * Servicio de servicio para generar el reporte de saldos reintentos.
     */
    private final IMonitorSaldosReportService monitorSaldosReportService;


    /**
     * Constructor en donde se realiza la inyeccion de dependencias.
     *
     * @param monitorSaldosService Servicio de servicio para obtener los saldos reintentos
     * @param monitorSaldosReportService Servicio de servicio para generar el reporte de saldos reintentos
     */
    public MonitorSaldosController(IMonitorSaldosService monitorSaldosService,
                                   IMonitorSaldosReportService monitorSaldosReportService) {
        this.monitorSaldosService = monitorSaldosService;
        this.monitorSaldosReportService = monitorSaldosReportService;
    }

    /**
     * Obtiene los saldos reintentos paginados.
     *
     * @param request Objeto con los filtros de consulta
     * @param pagination Objeto con los datos de paginacion
     * @return Objeto con los datos paginados
     */
    @PostMapping
    @Operation(summary = "Obtiene los saldos reintentos paginados")
    public ResponseEntity<Page<MonitorSaldosResponse>> getSaldosReintentosCliente(
    		@Valid
            @RequestBody MonitorSaldosRequest request, Pageable pagination) {
        Page<MonitorSaldosResponse> response = monitorSaldosService.getSaldosReintentosCliente(request, pagination);
        return ResponseEntity.ok(response);
    }

    /**
     * Genera el reporte de los saldos reintentos.
     *
     * @param request Objeto con los datos para generar el reporte
     * @return Objeto con los datos del reporte en base 64
     */
    @Operation(summary = "Genera el reporte de los saldos reintentos")
    @PostMapping(path = RoutesConstant.XLSX_PATH)
    public ResponseEntity<ReportResponse>  getReportSaldosReintentos(
    		@Valid
            @RequestBody MonitorSaldosReportRequest request){
        ReportResponse response = monitorSaldosReportService.getReportSaldosReintentos(request);
        return ResponseEntity.ok(response);
    }

}
