package mx.santander.h2h.monitoreo.repository;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.constants.MonitorOperacionesConstants;
import mx.santander.h2h.monitoreo.model.response.OperationsHistoryResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorCatalogsYHorasResponse.HorasCatalogo;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.util.ConstantesUtils;
import mx.santander.h2h.monitoreo.util.DetalleOperacionUtils;
import mx.santander.h2h.monitoreo.util.UtilMapeoData;
import mx.santander.h2h.monitoreo.util.UtilsTramaAdicionales;
import mx.santander.h2h.monitoreo.util.UtilsTramaAdicionalesAux;

@Slf4j
@Repository
public class OperationsDetailRepository implements IOperationsDetailRepository {

	/** Mapa de las tablas de los productos de monitor de operaciones */
	protected static final transient Map<String, String> tablas = new HashMap<String, String>();

	/*
	 * TCS (sonar) Cambio de clase anonima por inicializacion en bloque estatico
	 */
	static {
		tablas.put("01", MonitorOperacionesConstants.H2H_PROD_TRAN); /** SPEI */
		tablas.put("97", MonitorOperacionesConstants.H2H_PROD_TRAN); /** TEF */
		tablas.put("02", MonitorOperacionesConstants.H2H_PROD_TRAN); /** Nomina Interbancaria */
		tablas.put("98", "H2H_PROD_TRAN_MISM_BANC"); /** TMB */
		tablas.put("99", "H2H_PROD_NOMI_MISM_BANC"); /** Nomina Mismo Banco */
		tablas.put("91", "H2H_PROD_ALTA_PAGO"); /** ALTA PAGO PROVEEDORES CONFIRMING */
		tablas.put("80", "H2H_PROD_ORDN_PAGO"); /** ORDEN DE PAGO */
		tablas.put("95", "H2H_ACTA_BENI"); /** Alta Cuenta Beneficiarias */
		tablas.put("96", "H2H_ACTA_BENI"); /** Alta Cuenta Beneficiarias */
		tablas.put("81", "H2H_PROD_ORDN_PAGO"); /** ORDEN DE PAGO CANCELADO */
		tablas.put("93", "H2H_PROD_ALTA_EMPL"); /** ALTA MASIVA EMPLEADOS */
		tablas.put("135", "H2H_PROD_MANTTO_PROV_TRAN"); /** MTTO PROVEEDORES DE CONFIRMING **/
		tablas.put("23", "H2H_PROD_APO_OBRE_PATR");
		tablas.put("21", "H2H_PROD_IMPU_FEDE");
		tablas.put("22", "H2H_PROD_PAGO_REFE");
		tablas.put("36", "H2H_MX_PROD_PAGO_TDC"); /** Pago a TDC Santander */
		tablas.put("54", "H2H_MX_PROD_CARD_CHECK");
		tablas.put("40", "H2H_MX_PROD_PAGO_DIR"); // PGODIRECT
		tablas.put("32", "H2H_MX_PROD_TRAN_INTN");// Transferencias internacionales Cambiarias
		tablas.put("38", "H2H_MX_PROD_TVIB");// Transferencias Vostro Interbancarias
		tablas.put("39", "H2H_MX_PROD_TVMB");// Transferencias Vostro Mismo Banco
		tablas.put("85", "H2H_MX_PROD_ORDN_PAGO_ATM");// Ordenes de pago ATM
		tablas.put("41", MonitorOperacionesConstants.H2H_PROD_TRAN); /** SPEI ONLINE */
		tablas.put("47", MonitorOperacionesConstants.H2H_PROD_TRAN); /** TEF ONLINE */
		tablas.put("42", MonitorOperacionesConstants.H2H_PROD_TRAN); /** Nomina Interbancaria ONLINE */
		tablas.put("48", "H2H_PROD_TRAN_MISM_BANC"); /** TMB ONLINE */
		tablas.put("49", "H2H_PROD_NOMI_MISM_BANC"); /** Nomina Mismo Banco ONLINE */
	}

	@Autowired
	private EntityManager entityManager;

	@Override
	public OperationsMonitorQueryResponse obtenerDetalleOperacion(String view, String idOperacion) {
		DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols();
		formatSymbols.setDecimalSeparator('.');
		formatSymbols.setGroupingSeparator(',');
		DecimalFormat decimalFormat = new DecimalFormat("###,###,###,###,##0.00", formatSymbols);

		OperationsMonitorQueryResponse respuesta = new OperationsMonitorQueryResponse();

		respuesta.setProducto("OPERACION_EN_PROCESO");

		if (!tablas.containsKey(view)) {
			respuesta.setMensaje(getH2HMensaje(idOperacion));
			return respuesta;
		}

		String stringQuery = generaConsultaDetalleOperacion(view, idOperacion);
		Query query = entityManager.createNativeQuery(stringQuery, Tuple.class);

		try {

			for (Object obj : query.getResultList()) {
				if (!(obj instanceof Tuple))
					continue;
				Tuple tuple = (Tuple) obj;
				Map<String, Object> row = new HashMap<>();
				tuple.getElements().forEach(t -> row.put(t.getAlias(), tuple.get(t)));

				validarProductoConHorario(view, respuesta, row);
				respuesta.setIdOperacion(DetalleOperacionUtils.defaultObjectString(row.get("ID_REG"), "0"));
				respuesta.setCodCli(DetalleOperacionUtils.defaultObjectString(row.get("BUC"), ""));
				respuesta.setCtaAbono(DetalleOperacionUtils.defaultObjectString(row.get("NUN_CTA_ABONO"), ""));
				// Obtenemos el enmascarado de datos
				respuesta.setCtaAbono(UtilMapeoData.getMascara(respuesta.getCtaAbono(), "abono"));
				respuesta.setIdProducto(DetalleOperacionUtils.defaultObjectString(row.get("CVE_PROD_OPER"), "0"));
				/** Se invoca el metodo que recupera la cuenta Cargo */
				respuesta.setCtaCargo(DetalleOperacionUtils.cuentaCartgo(respuesta.getIdProducto(), row));
				respuesta.setProducto(DetalleOperacionUtils.defaultObjectString(row.get("DESC_PROD"), ""));
				respuesta.setNomArch(DetalleOperacionUtils.defaultObjectString(row.get("NOMBRE_ARCH"), ""));
				respuesta.setReferencia(DetalleOperacionUtils.defaultObjectString(row.get("REFERENCIA"), ""));
				/** Se realiza implementacion del metodo para validar la referencia */
				respuesta.setReferencia(DetalleOperacionUtils.referencia(respuesta.getReferencia()));
				respuesta.setEstatus(DetalleOperacionUtils.defaultObjectString(row.get("DESC_ESTATUS"), ""));
				respuesta.setImporte("$" + decimalFormat
						.format(Double.valueOf(DetalleOperacionUtils.defaultObjectString(row.get("IMPORTE"), "0.00"))));
				respuesta.setComentario1(DetalleOperacionUtils.defaultObjectString(row.get("COMENTARIO_1"), ""));
				respuesta.setComentario2(DetalleOperacionUtils.defaultObjectString(row.get("COMENTARIO_2"), ""));
				respuesta.setComentario3(DetalleOperacionUtils.defaultObjectString(row.get("COMENTARIO_3"), ""));
				respuesta.setDivisa(DetalleOperacionUtils.defaultObjectString(row.get("DIVISA"), ""));
				/** Se realiza la inovacion del metodo para validar el tipo de divisa */
				respuesta.setDivisa(DetalleOperacionUtils.tipoDivisa(respuesta.getDivisa()));
				respuesta.setDivisaOrd(DetalleOperacionUtils.defaultObjectString(row.get("DIVISA_ORD"), ""));
				/**
				 * Se realiza la invocacion del metos para definir el tipo de divisa de
				 * ordenante
				 */
				respuesta.setDivisaOrd(DetalleOperacionUtils.tipoDivisa(respuesta.getDivisaOrd()));
				respuesta.setFechaAplic(UtilsTramaAdicionales.getFecha(row.get("FECHA_APLICACION")));
				respuesta.setFechaCaptura(UtilsTramaAdicionales.getFecha(row.get("FECHA_REGISTRO")));
				respuesta.setFechaLimitPago(UtilsTramaAdicionales.getFecha(row.get("FECHA_LIMITE_PAGO")));
				respuesta.setFechaOper(UtilsTramaAdicionales.getFecha(row.get("FECHA_OPERACION")));
				respuesta.setFechaPresIni(UtilsTramaAdicionales.getFecha(row.get("FECHA_PRESENTACION_INICIAL")));
				respuesta.setImporteCargo(row.get(MonitorOperacionesConstants.IMPORTE_CARGO) == null
						|| row.get(MonitorOperacionesConstants.IMPORTE_CARGO).toString().isEmpty()
								? respuesta.getImporte()
								: "$" + decimalFormat.format(Double.valueOf(
										row.get(MonitorOperacionesConstants.IMPORTE_CARGO).toString().trim())));
				respuesta.setNombreOrd(Objects.toString(row.get("TITULAR"), ""));
				respuesta.setIntermOrd(DetalleOperacionUtils.defaultObjectString(row.get("INTERMEDIARIO_ORD"), ""));
				respuesta.setIntermRec(DetalleOperacionUtils.defaultObjectString(row.get("INTERMEDIARIO_REC"), ""));
				respuesta.setModalidad(DetalleOperacionUtils.defaultObjectString(row.get("MODALIDAD"), ""));
				respuesta.setNombreBenef(DetalleOperacionUtils.defaultObjectString(row.get("BENEFICIARIO"), ""));
				respuesta.setNumSucursal(DetalleOperacionUtils.defaultObjectString(row.get("NUM_SUCURSAL"), ""));
				respuesta.setFechaVenc(UtilsTramaAdicionales.getFecha(row.get("FECH_VENC")));
				respuesta.setNumOrden(DetalleOperacionUtils.defaultObjectString(row.get("NUM_ORDEN"), ""));
				respuesta.setTipoPago(DetalleOperacionUtils.defaultObjectString(row.get("TIPO_PAGO"), ""));
				respuesta.setNumeMovil(DetalleOperacionUtils.defaultObjectString(row.get("NUME_MOVI"), ""));
				/** Se invoca metdo para definir el banco receptor */
				respuesta.setBancoReceptor(DetalleOperacionUtils.bancoReceptor(respuesta.getIdProducto(), row));
				respuesta.setBancoOrdenante(MonitorOperacionesConstants.BANCO);
				respuesta.setIdMensaje(DetalleOperacionUtils.defaultObjectString(row.get("ID_MSG"), ""));
				/** Se invoca metodo que realiza la recuperacion del mensaje */
				respuesta.setMensaje(DetalleOperacionUtils.mensaje(respuesta.getIdMensaje(), row));
				if ("OPERACION_EN_PROCESO".equals(respuesta.getProducto())) {
					respuesta.setMensaje(getH2HMensaje(idOperacion));
				}
				respuesta.setIdEstatus(DetalleOperacionUtils.defaultObjectString(row.get("ID_ESTATUS"), "0"));
				respuesta.setMensajeOrden(DetalleOperacionUtils.defaultObjectString(row.get("MSG_ORDEN_PAGO"), "0"));
				respuesta
						.setReferenciaAbono(DetalleOperacionUtils.defaultObjectString(row.get("REFERENCIA_ABONO"), ""));
				respuesta
						.setReferenciaCargo(DetalleOperacionUtils.defaultObjectString(row.get("REFERENCIA_CARGO"), ""));
				/** Se realiza la invocacion del metodo para recuperar el nombre */
				respuesta.setNombreEmpleado(DetalleOperacionUtils.nombreEmpleado(respuesta.getIdProducto(), row));
				respuesta.setNumEmpleado(DetalleOperacionUtils.defaultObjectString(row.get("NUMERO_EMPLEADO"), ""));
				respuesta.setBucEmpleado(DetalleOperacionUtils.defaultObjectString(row.get("BUC_EMPLEADO"), ""));
				respuesta.setRfc(DetalleOperacionUtils.defaultObjectString(row.get("RFC"), ""));
				respuesta.setNumTarjeta(DetalleOperacionUtils.defaultObjectString(row.get("NUMERO_TARJETA"), ""));
				respuesta
						.setNumTarjetaAct(DetalleOperacionUtils.defaultObjectString(row.get("NUMERO_TARJETA_ACT"), ""));
				// Enmascaramos las Tarjetas
				respuesta.setNumTarjeta(UtilMapeoData.getMascara(respuesta.getNumTarjeta(), "tarjeta"));
				// Enmascaramos las Tarjetas
				respuesta.setNumTarjetaAct(UtilMapeoData.getMascara(respuesta.getNumTarjetaAct(), "tarjeta"));

				respuesta.setNumeroCuenta(DetalleOperacionUtils.defaultObjectString(row.get("NUMERO_CUENTA"), ""));
				String sucursal = DetalleOperacionUtils.defaultObjectString(row.get("SUCURSAL_TUTORA"), "");
				/** Se invoca metodo para recuperar la sucursal tutora */
				respuesta.setSucTutora(DetalleOperacionUtils.sucursalTutore(sucursal));
				/** Se invoca metoso para recuperar la descripcion */
				respuesta.setDescripcion(DetalleOperacionUtils.descripcion(respuesta.getIdProducto(), row));
				/** Se invoca metodo para recuperar la modalidad */
				respuesta.setModalidad(DetalleOperacionUtils.modalidad(respuesta.getModalidad()));
				/**
				 * Se invoca metodo que realiza la validacion del tipo pago para recuperar la
				 * descripcion
				 */
				respuesta.setTipoPago(ConstantesUtils.tipoPago(respuesta.getTipoPago()));
				respuesta.setDivisaOrd(ConstantesUtils.divisaOrdenante(respuesta.getDivisaOrd()));
				respuesta.setNumConvenio(row.containsKey("REF_CVE_RSTO")
						? DetalleOperacionUtils.defaultObjectString(row.get("REF_CVE_RSTO"), "")
						: "");
			}
		} catch (RuntimeException e) {
			log.error("Error de operacion en proceso:", e.getMessage());
		}
		return respuesta;
	}

	/**
	 * Validar producto con horario.
	 *
	 * @param view     the view
	 * @param response the respuesta
	 * @param row      the row
	 */
	protected void validarProductoConHorario(String view, OperationsMonitorQueryResponse response,
			Map<String, Object> row) {
		// Si el producto tiene horario
		if ("99".equals(view) || "02".equals(view)) {
			response.setHorarioProg(DetalleOperacionUtils.defaultObjectString(row.get("HORA_APLI"), ""));
		}
	}

	@Override
	public List<OperationsHistoryResponse> obtenerHistorialOperacion(String idOperacion) {
		Pair<String, String> tablasConsulta = recuperarTablasConsulta(idOperacion);
		String stringQuery = UtilsTramaAdicionales.generaConsultaHistorialOperacion(tablasConsulta.getLeft(),
				tablasConsulta.getRight());
		Query query = entityManager.createNativeQuery(stringQuery, Tuple.class);
		query.setParameter("idOperacion", idOperacion);
		List<?> resultList = query.getResultList();
		return resultList.stream().map(obj -> {
			if (!(obj instanceof Tuple))
				return null;
			Tuple tuple = (Tuple) obj;
			OperationsHistoryResponse response = new OperationsHistoryResponse();
			response.setEstatus(Objects.toString(tuple.get("ESTATUS"), ""));
			response.setFecha(Objects.toString(tuple.get("FECHA"), ""));
			response.setHora(Objects.toString(tuple.get("HORA"), ""));
			response.setRefOper(idOperacion);
			return response;
		}).filter(Objects::nonNull).collect(Collectors.toList());
	}

	/**
	 * Metodo que realiza la consulta para indicar a que tablas se realiza la
	 * consulta
	 * 
	 * @param idOperacion atributo que contiene el numero de operacion
	 * @return retorna objeto de tipo Pair con las tablas a consultar
	 */
	protected Pair<String, String> recuperarTablasConsulta(String idOperacion) {
		String stringQuery = "select id_oper_onl from h2h_reg_tran where ID_REG= :idOperacion "
				+ MonitorOperacionesConstants.UNION_ALL + "select id_oper_onl from h2h_reg where ID_REG= :idOperacion ";
		Query query = entityManager.createNativeQuery(stringQuery, Tuple.class);
		query.setParameter("idOperacion", idOperacion);
		List<?> resultList = query.getResultList();
		if (!resultList.isEmpty()) {
			return UtilsTramaAdicionales.recuperaRespuesta(resultList);
		}
		return ImmutablePair.of("H2H_BITA_REG_TRAN", "H2H_BITA_REG");
	}

	/**
	 * Cambia el estatus de la operacion
	 * 
	 * @param idOperacion - ID de la operacion
	 * @param estatus     - ID del estatus de la operacion
	 * @param tabla       - nombre de la tabla donde se va a modificar el estatus
	 * @return resultado de la operacion
	 */
	@Override
	@Transactional
	public boolean cambiarEstatusOperacion(String idOperacion, String estatus, String tabla) {
		StringBuilder stringBuilder = new StringBuilder();
		if (MonitorOperacionesConstants.REPROCESAR.equals(estatus)) {
			stringBuilder.append(MonitorOperacionesConstants.UPDATE).append(UtilsTramaAdicionalesAux.cleanTable(tabla))
					.append(MonitorOperacionesConstants.SET_ESTATUS_REPROCESAR).append(" :idOperacion ").append(") ")
					// .append(WHERE_DESC).append(REPROCESAR)
					// .append("' AND TIPO_ESTATUS = 'R' )
					.append("WHERE nvl(ID_ARCH_BE,-1) = ").append("(SELECT nvl(ID_ARCH_BE,-1) FROM ")
					.append(UtilsTramaAdicionalesAux.cleanTable(tabla)).append(MonitorOperacionesConstants.WHERE_ID_REG)
					.append(" :idOperacion ").append(") AND ID_ARCH = (SELECT ID_ARCH FROM ")
					.append(UtilsTramaAdicionalesAux.cleanTable(tabla)).append(MonitorOperacionesConstants.WHERE_ID_REG)
					.append(" :idOperacion ").append(")").append(" AND ID_ESTATUS = (SELECT ID_ESTATUS FROM ")
					.append(UtilsTramaAdicionalesAux.cleanTable(tabla)).append(MonitorOperacionesConstants.WHERE_ID_REG)
					.append(" :idOperacion ").append(")");
		} else if (MonitorOperacionesConstants.PROCESADO.equals(estatus)) {
			stringBuilder.append(MonitorOperacionesConstants.UPDATE).append(UtilsTramaAdicionalesAux.cleanTable(tabla))
					.append(MonitorOperacionesConstants.SET_ESTATUS).append(MonitorOperacionesConstants.WHERE_DESC)
					.append(" :estatus ").append(" AND TIPO_ESTATUS = 'R' ) ").append(", BAND_EDO_MODI = 'I' ")
					.append(", ID_MSG = 119 ").append(" WHERE ID_REG=").append(" :idOperacion ");
		} else {
			stringBuilder.append(MonitorOperacionesConstants.UPDATE).append(UtilsTramaAdicionalesAux.cleanTable(tabla))
					.append(MonitorOperacionesConstants.SET_ESTATUS).append(MonitorOperacionesConstants.WHERE_DESC)
					.append(" :estatus ").append(" AND TIPO_ESTATUS = 'R' ) WHERE ID_REG=").append(" :idOperacion ");
		}
		String stringQuery = stringBuilder.toString();
		Query query = entityManager.createNativeQuery(stringQuery);
		if (stringQuery.contains(":idOperacion")) {
			query.setParameter("idOperacion", idOperacion);
		}
		if (stringQuery.contains(":estatus")) {
			query.setParameter("estatus", estatus);
		}
		return query.executeUpdate() > 0;
	}

	/**
	 * Consulta el horario de un producto
	 * 
	 * @param producto nombre del producto a consultar
	 * @return Boolean que indica si el producto esta en su horario
	 */
	@Override
	public boolean consultarHorario(String producto) {
		String stringQuery = " select ID_PROD from h2h_cat_prod producto, h2h_cat_dia_prod dia "
				+ " where producto.id_prod = dia.id_producto " + " and dia = to_char(sysdate, 'D') "
				+ " and id_prod = :producto " + " and to_char(sysdate, 'HH24:mi') between hora_ini and hora_fin ";

		Query query = entityManager.createNativeQuery(stringQuery, Tuple.class);
		query.setParameter("producto", producto);

		boolean ret = false;
		for (Object obj : query.getResultList()) {
			if (obj instanceof Tuple) {
				Tuple tuple = (Tuple) obj;
				ret = tuple.get("ID_PROD") != null;
			}
		}

		return ret;
	}

	/**
	 * Genera la consulta del detalle de la operacion
	 *
	 * @param view vista
	 * @return Consulta de detalle de operacion
	 */
	protected String generaConsultaDetalleOperacion(String view, String idOperacion) {
		log.debug("Preparando consulta de operaciones");
		StringBuilder query = new StringBuilder();
		query.append("SELECT PROD.* FROM ( ").append(getConsultaByProducto(view, true))
				.append(MonitorOperacionesConstants.UNION_ALL).append(getConsultaByProducto(view, false))
				.append(") PROD WHERE PROD.ID_REG = ").append(idOperacion);
		return query.toString();
	}

	/**
	 * Crea el query por producto y si el dlel dia de hoy o el de tres meses
	 * 
	 * @param cveOperProd clave del producto
	 * @param tresMeses   inidca si va suar la tablasd e tres meses atras
	 * @return SQL del producto
	 */
	protected String getConsultaByProducto(String cveOperProd, boolean tresMeses) {
		final StringBuilder query = new StringBuilder();
		/** Se realiza la conversion de string a entero */
		int claveProducto = Integer.parseInt(cveOperProd);
		log.debug("El  valor de la clave de producto:::: " + claveProducto);
		query.append("SELECT ").append("REG.ID_REG, CLTE.BUC, REG.CNTA_CARG NUM_CTA_CARGO, ")
				.append("REG.CNTA_ABON NUN_CTA_ABONO, REG.CVE_PROD_OPER, PROD.DESC_PROD, ")
				.append("ARCH.NOMBRE_ARCH, DECODE( PROD.CVE_PROD_OPER,85 ,'****'|| SUBSTRB(REG.REFE_BE,-4,4) , REG.REFE_BE)  REFERENCIA, REG.ID_ESTATUS, ")
				.append("EST.DESC_ESTATUS, REG.MONT IMPORTE, CNTR.NUM_CNTR, REG.DIVI DIVISA, ")
				.append("ARCH.FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, ")
				.append("REG.ID_MSG, REG.MSG_ONL, ");
		if ("03".equals(cveOperProd)) {
			query.append(" DETA.EMAIL EMAIL_MIT,").append(
					"DECODE(PROD.CVE_PROD_OPER,85, '****' || SUBSTRB(DETA.REFE,-4,4), DETA.REFE) REFERENCIA_MIT, ");
		}
		if ("01".equals(cveOperProd) || "97".equals(cveOperProd)) {
			query.append("DETA.REFE_ENVI_OUT REF_CVE_RSTO, ");
		}
		/** Se realiza la inovacion del metodo */
		query.append(UtilsTramaAdicionales.getConsultaProdructoUtils(claveProducto));
		if ("91".equals(cveOperProd)) {
			query.append(UtilsTramaAdicionalesAux.addCfdiFieldsToQuery(tresMeses));
		}
		query.append("REG.FECH_OPER FECHA_PRESENTACION_INICIAL, REG.FECH_ENVI_BACK FECHA_OPERACION, REG.NUME_MOVI ")
				.append("FROM ").append(tablas.get(cveOperProd)).append(tresMeses ? "_TRAN DETA " : " DETA ");
		query.append("INNER JOIN ").append(tresMeses ? "H2H_REG_TRAN" : "H2H_REG")
				.append(" REG ON REG.ID_REG = DETA.ID_REG ").append("INNER JOIN ")
				.append(tresMeses ? "H2H_ARCHIVO_TRAN" : "H2H_ARCHIVO")
				.append(" ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ").append("INNER JOIN H2H_CNTR CNTR USING (ID_CNTR) ")
				.append("INNER JOIN H2H_CLTE CLTE USING (ID_CLTE) ")
				.append("INNER JOIN H2H_CAT_PROD PROD ON PROD.CVE_PROD_OPER=REG.CVE_PROD_OPER ")
				.append("INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS ");

		if (("91".equals(cveOperProd)) && tresMeses) {
			query.append(" LEFT JOIN H2H_PROD_ALTA_PAGO_TRAN ALTA_PAGO ON DETA.ID_REG = ALTA_PAGO.ID_REG ");
		} else if (("91".equals(cveOperProd)) && !tresMeses) {
			query.append(" LEFT JOIN H2H_PROD_ALTA_PAGO ALTA_PAGO ON DETA.ID_REG = ALTA_PAGO.ID_REG ");
		}

		query.append("LEFT JOIN H2H_MSG MSG ON MSG.ID_MSG = REG.ID_MSG ");
		switch (claveProducto) {
		case 1:
		case 41:
		case 97:
		case 47:
		case 2:
		case 42:
			query.append("LEFT JOIN H2H_CAT_BNCO BNCO ON DETA.CLAV_INTER_RECE  = BNCO.CODI_TRAN ")
					.append(MonitorOperacionesConstants.LEFT_JOIN_CONS)
					.append(MonitorOperacionesConstants.LEFT_JOIN_CONS_DOS)
					.append(MonitorOperacionesConstants.LEFT_JOIN_CONS_TRES)
					.append(MonitorOperacionesConstants.LEFT_JOIN_CONS_CUATRO);
			break;
		default:
			/**
			 * Se realiza la inmovacion del metodo que realiza la segunda parte de las
			 * validaciones
			 */
			query.append(UtilsTramaAdicionales.armadoTramaSegundaParte(claveProducto));
			break;
		}
		return query.toString();
	}

	/**
	 * Obtiene el mensaje de la operacion
	 *
	 * @param idOperacion id del mensaje
	 * @return String - Mensaje de la operacion
	 */
	protected String getH2HMensaje(String idOperacion) {
		final StringBuilder query = new StringBuilder();
		query.append("SELECT MSG_H2H FROM H2H_MSG INNER JOIN H2H_REG USING(ID_MSG) WHERE ID_REG = ").append(idOperacion)
				.append(MonitorOperacionesConstants.UNION_ALL)
				.append("SELECT MSG_H2H FROM H2H_MSG INNER JOIN H2H_REG_TRAN USING(ID_MSG) WHERE ID_REG = ")
				.append(idOperacion);

		Query nativeQuery = entityManager.createNativeQuery(query.toString(), Tuple.class);
//        nativeQuery.setParameter("idOperacion", idOperacion);

		for (Object obj : nativeQuery.getResultList()) {
			if (obj instanceof Tuple) {
				Tuple tuple = (Tuple) obj;
				return Objects.toString(tuple.get("MSG_H2H"), "");
			}
		}

		return null;
	}

	/**
	 * Metodo que obtiene los horarios
	 * 
	 * @param producto id de producto a obtener
	 * @return lista de horas
	 */
	@Override
	public List<HorasCatalogo> listaHorarios(String producto) {

		List<HorasCatalogo> listaHorarios = new ArrayList<HorasCatalogo>();

		final String queryHorarios = "SELECT DESCR FROM H2H_REGI_CATA T1 "
				+ "INNER JOIN H2H_CATA T2 ON T1.ID_CATA=T2.ID_CATA "
				+ "WHERE T2.DESCRIPCION= 'CATALOGO DE HORARIOS INTRADIA POR PRODUCTO' and VALO = :producto";

		Query nativeQuery = entityManager.createNativeQuery(queryHorarios, Tuple.class);
		nativeQuery.setParameter("producto", producto);

		for (Object obj : nativeQuery.getResultList()) {
			if (obj instanceof Tuple) {
				Tuple tuple = (Tuple) obj;
				HorasCatalogo hora = new HorasCatalogo(Objects.toString(tuple.get("DESCR"), ""));
				listaHorarios.add(hora);
			}

		}

		return listaHorarios;
	}

}
