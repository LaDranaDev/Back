package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;

/**
 * IOperationsPagDirectRepository.
 *
 * @author Jesus Soto Aguilar
 */
public interface IOperationsDetailPagDirectRepository {

    /**
     * Obtiene el detalle de la operacion
     * @param view - nombre de la vista del producto
     * @param idOperacion - ID de operacion
     * @return Detalle de la operacion
     */
    OperationsMonitorQueryResponse obtenerDetalleOperacion(String view, String idOperacion);
}
