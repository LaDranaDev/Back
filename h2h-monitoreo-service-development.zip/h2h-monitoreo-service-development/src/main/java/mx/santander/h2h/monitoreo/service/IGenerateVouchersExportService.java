package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.response.VoucherRequestDto;

/**
 * Clase que define las operaciones de exportacion de comprobante formato CDMX
 * 
 * @author Omar Rosas
 * @since 19/10/2023
 *
 */
public interface IGenerateVouchersExportService {

	/**
	 * Metodo que genera el comprobante en pdf
	 * 
	 * @param voucherRequestDto Datos de entrada para generar el comprobante
	 * @return Reporte del comprobante
	 */
	ReportResponse exportarOperacionesPdf(VoucherRequestDto voucherRequestDto);

}
