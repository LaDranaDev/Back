package mx.santander.h2h.monitoreo.constants;

/**
 * QueryConstant Constantes para las consultas nativas. Utilizada para agregar
 * las queries, de pereferencia aquellas que puedan ser reutilizadas
 *
 * @author Felipe Monzon
 * @since 26/04/2022
 */
public final class QueryConstant {

	/** Propiedad constante para el where de id contrato y id frecuencia */
	private static final String WHERE_IDCNTR_IDFREC = " WHERE ID_CNTR = :idContrato AND ID_FREC = :idFrec";
	/** Propiedad constante para el select de horario */
	private static final String SELECT_SCHEDULE_CATALOG = "SELECT CH.ID_CAT_HORARIO AS ID_CAT, to_char(CH.HORA_EJEC,'hh24:mi') AS DESCRIPCION";
	/** Propiedad constante para el left join con contr_frec_ecta */
	private static final String LEFTJOIN_CNTRFREC_ECTA = "LEFT JOIN H2H_CNTR_FREC_ECTA B ON (A.ID_ECTA = B.ID_ECTA) ";
	
	/** Propiedad constante para el left join con contr_frec_ecta */
	private static final String DATE_RANGE = "AND (cntr.FECHA_ALTA >= to_date(:#{#request.dateInit}, 'dd/MM/yyyy') AND cntr.FECHA_ALTA <= to_date(:#{#request.dateEnd}, 'dd/MM/yyyy')) ORDER BY 1";
	
	private static final String NUM_CONTRATO = "AND cntr.NUM_CNTR = :#{#request.numContrato} ORDER BY 1";
	
	private static final String COD_CLIENTE = "AND clte.BUC = :#{#request.codigoCliente} ORDER BY 1";

	private static final String CUENTA_EJE = "AND cta.NUM_CTA = :#{#request.cuentaEje} ORDER BY 1";
	
	private static final String RAZON_SOCIAL = "AND (UPPER(clte.RAZON_SCIA) LIKE CONCAT('%', CONCAT(:#{#request.razonSocial}, '%')) OR (NVL(clte.nombre, ' ') || ' ' || NVL(clte.APPATERNO, ' ') || ' ' || NVL(clte.apmaterno, ' ')) LIKE CONCAT('%', CONCAT(:#{#request.razonSocial}, '%'))) ORDER BY 1";
	
	/**
	 * Consulta el catalogo de horarios por identificador de centro.
	 */
	public static final String SCHEDULE_CATALOG_BY_ID_CENTER = SELECT_SCHEDULE_CATALOG
			+ ",CH.ID_FREC AS ESTATUS_ACTIVO FROM H2H_CAT_HORARIO CH WHERE CH.TIPO = :type"
			+ " AND CH.ID_FREC = :frec AND CH.ID_CAT_HORARIO NOT IN (SELECT ID_HORARIO"
			+ " FROM H2H_CNTR_REP_INTRADIA_OP WHERE ID_CNTR = :idCenter) ORDER BY CH.HORA_EJEC";
	/**
	 * Consulta los datos del contrato.
	 */
	public static final String CONTRACT_BY_NUM = "SELECT clte.BUC, clte.RAZON_SCIA AS RAZON_SOCIAL, clte.PERSONALIDAD, clte.NOMBRE, clte.APPATERNO, clte.APMATERNO,"
			+ " cta.NUM_CTA CUENTA_EJE, cntr.ID_CNTR, cntr.ID_ESTADO, cntr.NUM_CNTR, cntr.HABILITA_BENE, cntr.CVE_CANL_HSM,"
			+ " cntr.BAND_BENEF, cntr.BAND_CLABE_ECTA, cntr.BAND_CAMB_PROD, est.Desc_Estatus, clte.nemonico, cntr.BAND_ACT_CONT,"
			+ " cntr.BIC, cntr.MSG_PTNR, cntr.TIPO_TRAN, cntr.BAND_CIF_CTRL, DIAS_PROG_ARCH , NVL(cntr.ALIAS,'') AS ALIAS, cntr.CTR_BACK_CONF"
			+ " FROM H2H_CNTR cntr INNER JOIN H2H_CNTR_CTA cta ON cta.ID_CNTR = cntr.ID_CNTR"
			+ " INNER JOIN  H2H_CLTE clte ON cntr.ID_CLTE = clte.ID_CLTE"
			+ " INNER JOIN H2H_CAT_ESTATUS est ON cntr.id_estado = est.ID_CAT_ESTATUS"
			+ " WHERE cntr.NUM_CNTR = :centerNumber AND cta.TIPO_CTA = :accountType";
	/**
	 * Consulta contrato no cancelado por buc
	 */
	public static final String CNTR_NO_CANCELADO_POR_BUC = "SELECT\n" +
			"\tclte.BUC, clte.RAZON_SCIA RAZON_SOCIAL, clte.PERSONALIDAD, \n" +
			"\tclte.NOMBRE, clte.APPATERNO, clte.APMATERNO,\n" +
			"\tcta.NUM_CTA CUENTA_EJE, cntr.ID_CNTR, cntr.ID_ESTADO,\n" +
			"\tcntr.NUM_CNTR, cntr.HABILITA_BENE,\n" +
			"\tcntr.BAND_BENEF, cntr.BAND_CLABE_ECTA, cntr.BAND_CAMB_PROD,\n" +
			"\tEst.Desc_Estatus, clte.nemonico, cntr.BAND_ACT_CONT,\n" +
			"\tcntr.BIC, cntr.MSG_PTNR, cntr.TIPO_TRAN, cntr.BAND_CIF_CTRL, DIAS_PROG_ARCH ,nvl(cntr.ALIAS,'') as ALIAS \n" +
			"\tFROM\n" +
			"\tH2H_CNTR cntr,\n" +
			"\tH2H_CNTR_CTA cta, H2H_CLTE clte,H2H_CAT_ESTATUS est\n" +
			"\tWHERE clte.BUC =:bucCliente  AND cta.TIPO_CTA = 'E' \n" +
			"\tAND cta.ID_CNTR = cntr.ID_CNTR  AND cntr.ID_CLTE = clte.ID_CLTE\n" +
			"\tAND cntr.id_estado = est.ID_CAT_ESTATUS\n" +
			"\tAND est.ID_CAT_ESTATUS != :idEstatus";
	/**
	 * Consulta los productos asociados a un numero de contrato.
	 */
	public static final String GET_PRODUCT_BY_CONTRACT = "SELECT NVL(pa.ID_CNTR_PROD, 0) AS ID_CNTR_PROD, p.Id_Prod, p.desc_prod, p.Cve_Prod, "
			+ " CASE WHEN NVL(pa.Id_Prod, 0) > 0 AND pa.Band_Activo = 'A' THEN 'S' Else 'N' END prod_asignado, "
			+ " p.band_Email, DECODE(NVL(pa.Envio_Email, 'I'), 'A', 'checked', '') AS envio_email, "
			+ " p.band_Tipo_Cargo, pa.Tipo_Cargo, p.band_Vigencia, pa.Vigencia, p.band_Confirming, "
			+ " p.band_Reintentos, pa.num_rein, pa.interv_rein, pa.Band_Activo, pa.Num_Cntr "
			+ "From H2h_Cat_Prod p, (Select pc.ID_CNTR_PROD, cntr.NUM_CNTR, pc.ID_PROD, pc.ENVIO_EMAIL, "
			+ "pc.TIPO_CARGO, pc.NUM_REIN, pc.INTERV_REIN, pc.VIGENCIA, pc.Band_Activo "
			+ "From H2H_CNTR cntr, H2H_CNTR_PROD pc Where cntr.Num_Cntr = :contractNumber AND cntr.Id_Cntr = pc.Id_Cntr) pa "
			+ "Where p.Id_Prod = pa.id_prod(+) AND (p.VISIBILIDAD = 'A' OR p.VISIBILIDAD = 'P') "
			+ "AND p.Band_Activo = 'A' Order By p.Id_Prod";

	/**
	 * Consulta para obtener parametros adicionales.
	 */
	public static final String GET_ADDITIONAL_ENVIROMENT_BY_CONTRACT = "SELECT ATM.BAND_CON_OP_ATM , ATM.BAND_HST_OP_ATM, ATM.BAND_INTR_OP_ATM, cntr.ID_CANL_REP_OPTIMUS,"
			+ " cntr.BAND_DUPLICADO, cntr.CNL_REP_DEV_ONL, cntr.IP_CLIENTE, cntr.COD_BICE, ATM.BAND_REF_ODP_ATM, CNTR.NUM_CNTR"
			+ " FROM H2H_CNTR CNTR LEFT JOIN H2H_MX_CNTR_ATM ATM ON CNTR.ID_CNTR = ATM.ID_CNTR"
			+ " WHERE CNTR.NUM_CNTR = :centerNumber";
	/**
	 * Consulta los horarios de intadia.
	 */
	public static final String GET_SCHEDULE_INTRADIA = "SELECT ATM.ID_HORARIO, to_char(HOR.HORA_EJEC,'hh24:mi') AS HORA"
			+ " FROM H2H_CNTR_REP_INTR_ODP_ATM ATM"
			+ " LEFT JOIN H2H_CAT_HORARIO HOR ON ATM.ID_HORARIO = HOR.ID_CAT_HORARIO"
			+ " INNER JOIN H2H_CNTR CNTR ON CNTR.ID_CNTR = ATM.ID_CNTR WHERE CNTR.NUM_CNTR = :centerNumber ORDER BY hora";
	/**
	 * cuenta los productos asignados a un centro con status A.
	 */
	public static final String COUNT_PRODUCT_CENTER = "SELECT COUNT(1)"
			+ " FROM H2H_CNTR_PROD CNTRPROD INNER JOIN H2H_CAT_PROD prod ON prod.ID_PROD = CNTRPROD.ID_PROD WHERE"
			+ " CNTRPROD.ID_CNTR = :idCenter AND CNTRPROD.ID_PROD = :idProduct AND CNTRPROD.BAND_ACTIVO = 'A' ";

	/**
	 * Query para contar los archivos asociados a un contrato
	 * SELECT_EXISTEN_PRODUCTOS_DE_CONTRATO
	 */
	public static final String COUNT_EXISTEN_PRODUCTOS_DE_CONTRATO = "SELECT COUNT(1) FROM H2H_CNTR_PROD "
			+ "WHERE ID_CNTR = :idContrato AND BAND_ACTIVO = :bandActive";

	/**
	 * Consulta los datos del catalogo de canales por centro.
	 */
	public static final String GET_CATALOG_CHANNEL = "SELECT CAN.* FROM H2H_CAT_CANL CAN "
			+ "INNER JOIN H2H_CNTR_CANL CNTRCANL ON can.id_canl = cntrcanl.id_canl "
			+ "WHERE cntrcanl.id_cntr = :idCenter";
	/**
	 * Consulta canales asignados.
	 */
	public static final String GET_CHANNEL_ASSIGN = "SELECT C.ID_CANL AS ID_CANL, C.NOMB_CANL AS NOMB_CANL, C.DESC_CANL AS DESC_CANL, C.BAND_ACTI AS BAND_ACTI,"
			+ " NVL(CC.ID_CNTR, 0) AS ID_CNTR, NVL(CC.BAND_ACTI, 'I') AS ESTADO_SELECCION"
			+ " FROM H2H_CAT_CANL C INNER JOIN H2H_CNTR_CANL CC ON C.ID_CANL = CC.ID_CANL"
			+ " WHERE C.BAND_ACTI = :statusChannel AND CC.ID_CNTR = :idCenter AND CC.BAND_ACTI = :statusChannel"
			+ " ORDER BY C.ID_CANL";
	/**
	 * Consulta el total de productos activos por centro.
	 */
	public static final String COUNT_ID_PRODUCT_ACTIVE = "SELECT COUNT(ID_CNTR_PROD) from h2h_cntr_prod where id_cntr = :idCenter and band_activo = :productStatus and ID_PROD = (SELECT ID_PROD FROM h2h_cat_prod WHERE CVE_PROD_OPER = '92' AND BAND_ACTIVO = :productStatus)";
	
	/**
	 * Consulta producto por su estado, numero de contrato y descripcion.
	 */
	public static final String GET_PRODUCT_BY_STATUS_AND_DESCRIPTION = "SELECT prod.ID_PROD, prod.DESC_PROD , cprod.BAND_PROG_HR, cprod.ID_CNTR_PROD "
			+ "FROM h2h_regi_cata rcata INNER JOIN h2h_cata cata ON rcata.id_cata = cata.id_cata "
			+ "INNER JOIN h2h_cat_prod prod ON trim(rcata.valo) = prod.cve_prod_oper "
			+ "INNER JOIN h2h_cntr_prod cprod ON prod.id_prod = cprod.id_prod "
			+ "INNER JOIN h2h_cntr cntr ON cprod.id_cntr = cntr.id_cntr WHERE cntr.num_cntr = :contractNumber "
			+ "AND cata.DESCRIPCION = :description AND cprod.band_activo = :statusProduct";
	/**
	 * Actualiza los datos del contrato por numero de contrato.
	 */
	public static final String UPDATE_PARAMETERS_BY_CONTRACT = "UPDATE H2H_CNTR "
			+ "SET COD_BICE = :codBice, BAND_DUPLICADO = :duplicateFlag, CNL_REP_DEV_ONL = :channel, IP_CLIENTE = :ipCustomer "
			+ "where NUM_CNTR = :contractNumber";
	/**
	 * Verifica si hay registrato.
	 */
	public static final String COUNT_BY_ID_CONTRCT = "SELECT count(id_cntr) FROM H2H_MX_CNTR_ATM "
			+ "WHERE id_cntr = :contractNumber";

	/**
	 * Se obtienen los valores de los check mediante el id del contrato
	 */
	public static final String GET_VALUESCHECK_BYIDCONTR = "SELECT ID_CNTR,BAND_CON_OP_ATM,BAND_HST_OP_ATM,BAND_INTR_OP_ATM,BAND_REF_ODP_ATM "
			+ "FROM H2H_MX_CNTR_ATM WHERE ID_CNTR = :idContract";

	/**
	 * Actualiza los valores de parametros atm.
	 */
	public static final String UPDATE_ADDITIONAL_PARAMETERS = "UPDATE H2H_MX_CNTR_ATM "
			+ "SET BAND_CON_OP_ATM = :atmFlag, BAND_HST_OP_ATM = :atmFlagHist, BAND_INTR_OP_ATM = :atmFlagIntr, BAND_REF_ODP_ATM = :atmFlagRef "
			+ "WHERE ID_CNTR = :idContract";
	/**
	 * Se insertan valores de parametros atms.
	 */
	public static final String INSERT_ADDITIONAL_PARAMETERS = "INSERT INTO H2H_MX_CNTR_ATM (ID_CNTR,BAND_CON_OP_ATM ,BAND_HST_OP_ATM,BAND_INTR_OP_ATM, BAND_REF_ODP_ATM) "
			+ "values(:contractNumber, :atmFlag, :atmFlagHist, :atmFlagIntr, :atmFlagRef)";
	/**
	 * Elimina los horarios de intradia.
	 */
	public static final String DELETE_SCHEDULE_INTRADIA = "SELECT atm.ID_REP_INTR_OP_ATM FROM H2H_CNTR_REP_INTR_ODP_ATM atm WHERE EXISTS ("
			+ "SELECT 1 FROM H2H_CNTR cntr WHERE cntr.ID_CNTR = atm.ID_CNTR AND cntr.NUM_CNTR = :contractNumber)";

	/**
	 * Obtener el id del contrato al buscar por el numero de contrato
	 */
	public static final String GET_IDCONTRATO_BY_NUMCONTRATO = "SELECT ID_CNTR FROM H2H_CNTR WHERE NUM_CNTR = :numContrato";

	/**
	 * Obtener el id mas reciente de la tabla H2H_CNTR_REP_INTR_ODP_ATM
	 */
	public static final String GETLAST_IDFROMTABLE_H2H_CNTR_REP_INTR_ODP_ATM = "SELECT ID_REP_INTR_OP_ATM FROM ("
			+ "SELECT ID_REP_INTR_OP_ATM FROM H2H_CNTR_REP_INTR_ODP_ATM ORDER BY ID_REP_INTR_OP_ATM DESC) WHERE ROWNUM <= 1";

	/**
	 * Inserta los horarios.
	 */
	public static final String INSERT_SCHEDULE = "INSERT INTO H2H_CNTR_REP_INTR_ODP_ATM (ID_REP_INTR_OP_ATM,ID_CNTR,ID_HORARIO) \r\n"
			+ "VALUES((SELECT DECODE(MAX(ID_REP_INTR_OP_ATM),null,0, MAX(ID_REP_INTR_OP_ATM)) ID_REP_INTR_OP_ATM \r\n"
			+ "FROM H2H_CNTR_REP_INTR_ODP_ATM) +1,(SELECT ID_CNTR FROM H2H_CNTR WHERE NUM_CNTR = :contractNumber), :schedule)";
	/**
	 * Actualiza la parametria adicional por identificador.
	 */
	public static final String UPDATE_REPO_CHANNEL = "UPDATE H2H_MX_CNTR_REPO_CANL SET CANL_REPO_ATM = :channelRepoAtm \r\n"
			+ "WHERE ID_REPO_CANL = :idRepoChannel";
	/**
	 * Inserta los datos la parametria adicional por identificador.
	 */
	public static final String INSERT_REPO_CHANNEL = "INSERT INTO H2H_MX_CNTR_REPO_CANL(ID_REPO_CANL,ID_CNTR, CANL_REPO_ATM )\r\n"
			+ "VALUES((SELECT DECODE(MAX(ID_REPO_CANL), null, 1, MAX(ID_REPO_CANL)+1) FROM H2H_MX_CNTR_REPO_CANL), :contractNumber, :channelRepoAtm)";

	/**
	 * Obtener el ultimo id registrado en la tabla H2H_MX_CNTR_REPO_CANL
	 */
	public static final String GETLASTID_FROMTABLE_H2H_MX_CNTR_REPO_CANL = "SELECT DECODE(MAX(ID_REPO_CANL), null, 1, MAX(ID_REPO_CANL)+1) FROM H2H_MX_CNTR_REPO_CANL";

	/**
	 * Actualiza parametro optimus.
	 */
	public static final String UPDATE_PARAMETER_OPTIMUS = "UPDATE H2H_CNTR SET ID_CANL_REP_OPTIMUS = :channelRepOptimus WHERE NUM_CNTR = :contractNumber";
	/**
	 * Actualiza los productos.
	 */
	public static final String UPDATE_PRODUCT = "UPDATE H2H_CNTR_PROD SET BAND_PROG_HR = :flagProgramming WHERE ID_PROD = :idProduct"
			+ " AND ID_CNTR_PROD = :contractNumber";

	/**
	 * Proceso estado de cuenta intradia QUERY QUE INDICA SI EL CONTRATO PERMITE O
	 * NO CONFIGURACION DE ESTADOS DE CUENTA CADA 15 MIN.
	 */
	public static final String COUNT_EDOCTA_CONFIG = "SELECT COUNT(1) FROM H2H_CNTR cntr WHERE cntr.NUM_CNTR = :num_contrato AND "
			+ "cntr.BAND_EDOCTA_15 = :band_edocta";

	/**
	 * Select para el catalogo de horarios disponibles para los estados de cuenta y
	 * para llenar combos de horas
	 */
	public static final String SELECT_HORARIOS_DISPONIBLES_EDOCTA_FLAGSI = SELECT_SCHEDULE_CATALOG
			+ ",CH.ID_FREC AS ESTATUS_ACTIVO FROM H2H_CAT_HORARIO CH WHERE CH.ID_FREC = :idFrecuency AND (CH.TIPO='A' OR TIPO='E') "
			+ "AND CH.ID_CAT_HORARIO NOT IN (SELECT D.ID_CAT_HORARIO FROM H2H_CNTR_ECTA A " + LEFTJOIN_CNTRFREC_ECTA
			+ "LEFT JOIN H2H_ECTA_FREC_INTRADIA C ON (B.ID_CNTR_FREC_ECTA = C.ID_FREC_ECTA) "
			+ "LEFT JOIN H2H_CAT_HORARIO D ON (C.ID_HORARIO = D.ID_CAT_HORARIO) "
			+ "WHERE A.ID_CNTR = :numCtr AND D.ID_FREC = :idFrecuency AND (D.TIPO='A' OR TIPO='E')) ORDER BY CH.HORA_EJEC ASC";

	/**
	 * Select para el catalogo de horarios disponibles para los estados de cuenta y
	 * para llenar combos de horas
	 */
	public static final String SELECT_HORARIOS_DISPONIBLES_EDOCTA_FLAGNO = SELECT_SCHEDULE_CATALOG
			+ ",CH.ID_FREC AS ESTATUS_ACTIVO FROM H2H_CAT_HORARIO CH WHERE CH.ID_FREC = :idFrecuency AND CH.TIPO='A' "
			+ "AND CH.ID_CAT_HORARIO NOT IN (SELECT D.ID_CAT_HORARIO FROM H2H_CNTR_ECTA A " + LEFTJOIN_CNTRFREC_ECTA
			+ "LEFT JOIN H2H_ECTA_FREC_INTRADIA C ON (B.ID_CNTR_FREC_ECTA = C.ID_FREC_ECTA) "
			+ "LEFT JOIN H2H_CAT_HORARIO D ON (C.ID_HORARIO = D.ID_CAT_HORARIO) "
			+ "WHERE A.ID_CNTR = :numCtr AND D.ID_FREC = :idFrecuency AND D.TIPO='A') ORDER BY CH.HORA_EJEC ASC";

	/**
	 * Select para el catalogo de dias
	 */
	public static final String SELECT_DIAS_DISPO = "SELECT A.ID_CAT_DIA AS ID_CAT,A.DESC_DIA AS DESCRIPCION,A.ID_FREC AS ESTATUS_ACTIVO"
			+ " FROM H2H_CAT_DIA A WHERE ID_FREC = :idFrec ORDER BY A.ID_CAT_DIA";

	/**
	 * Select para el catalogo de formatos de archivo
	 */
	public static final String SELECT_FORMAT_FILE = "SELECT ID_LAY AS ID_CAT,NOMBRE AS DESCRIPCION FROM H2H_CAT_LAYT"
			+ " WHERE ORIGEN = :origen AND BAND_ACTIVO = :bandActive ORDER BY NOMBRE";

	/**
	 * Query para buscar los registros asignados en la tabla temporal para la
	 * paginacion en Edo cta
	 */
	public static final String SELECT_TMPCONTRATOS_ASIG = "SELECT ID_CARGA,ID_NUM_MOV,MOVIMIENTO,TIPO_CTA,DIVISA,NUM_CTA,RAZON_SOCIAL,DETALLE"
			+ " FROM h2h_cta_ord_carga_masiva WHERE ID_CARGA = :idCarga AND MOVIMIENTO = :movimiento ORDER BY NUM_CTA";
	/**
	 * Query para buscar los registros asignados en la tabla temporal para la
	 * paginacion en Edo cta
	 ***/

	/**
	 * Query para poder obtener los contratos asignados
	 */
	public static final String SELECT_CNTR_EDO_CTA_ASIGNADOS = "SELECT ID_CNTR_CTA,NUM_CTA,ID_CAT_DIVISA FROM H2H_CNTR_CTA A WHERE "
			+ "A.ID_CNTR = :idContrato AND (A.TIPO_CTA = 'O' OR A.TIPO_CTA = 'E') AND A.BAND_ACTIVO='A' AND A.ID_CNTR_CTA IN ("
			+ "SELECT ID_CNTR_CTA FROM H2H_ECTA_CTA B " + "LEFT JOIN H2H_CNTR_ECTA C ON (B.ID_ECTA = C.ID_ECTA) "
			+ "WHERE A.ID_CNTR = C.ID_CNTR AND C.ID_CNTR= :idContrato AND ID_FREC= :idFrec) ORDER BY NUM_CTA";

	/**
	 * Query para obtener los contratos no asignados
	 */
	public static final String SELECT_CNTR_CTA_NOASIGNADOS = "SELECT C.ID_CNTR_CTA,C.NUM_CTA FROM H2H_CNTR_CTA C WHERE "
			+ "C.ID_CNTR = :idContrato AND (C.TIPO_CTA = 'O' OR C.TIPO_CTA = 'E') AND C.BAND_ACTIVO='A' AND C.ID_CNTR_CTA NOT IN ("
			+ "SELECT A.ID_CNTR_CTA FROM H2H_ECTA_CTA A " + "LEFT JOIN H2H_CNTR_ECTA B ON (A.ID_ECTA=B.ID_ECTA) "
			+ "WHERE B.ID_CNTR=C.ID_CNTR AND B.ID_FREC = :idFrec) " + "ORDER BY C.NUM_CTA";

	/**
	 * Query para obtener los estados de cuenta por tipo de frecuencia
	 */
	public static final String SELECT_CONF_EDO_CTA_TIPOFRECUENCIA = "SELECT A.ID_ECTA,C.ID_FREC,C.DESCR as DESCRIPCION FROM H2H_CNTR_ECTA A "
			+ LEFTJOIN_CNTRFREC_ECTA + "LEFT JOIN H2H_CAT_FREC C ON (B.ID_FREC = C.ID_FREC) "
			+ "WHERE A.ID_CNTR = :idContrato AND A.ID_FREC = :idFrec AND C.BAND_ACTIVO = 'A' AND (C.TIPO='E' OR C.TIPO='O') "
			+ "ORDER BY C.ID_FREC";

	/**
	 * Query para obtener los estados de cuenta intradia con sus horas almacenadas
	 */
	public static final String SELECT_CONF_EDO_CTA_INTRADIAHORAS = "SELECT D.ID_CAT_HORARIO AS ID_CAT,to_char(D.HORA_EJEC,'hh24:mi') AS DESCRIPCION"
			+ " FROM H2H_CNTR_ECTA A " + LEFTJOIN_CNTRFREC_ECTA
			+ "LEFT JOIN H2H_ECTA_FREC_INTRADIA C ON (B.ID_CNTR_FREC_ECTA = C.ID_FREC_ECTA)"
			+ " LEFT JOIN H2H_CAT_HORARIO D ON (C.ID_HORARIO = D.ID_CAT_HORARIO)"
			+ " WHERE A.ID_CNTR = :idContrato AND A.ID_FREC = :idFrec AND D.ID_FREC = :idFrec AND (D.TIPO='E' OR D.TIPO='A')"
			+ " ORDER BY D.HORA_EJEC";

	/**
	 * Query para obtener los estados de cuenta por semanalDia
	 */
	public static final String SELECT_CONF_EDO_CTA_SEMANALDIA = "SELECT D.ID_CAT_DIA as ID_CAT,D.DESC_DIA as DESCRIPCION FROM H2H_CNTR_ECTA A "
			+ LEFTJOIN_CNTRFREC_ECTA + "LEFT JOIN H2H_ECTA_FREC_SEMANAL C ON (B.ID_CNTR_FREC_ECTA = C.ID_FREC_ECTA) "
			+ "LEFT JOIN H2H_CAT_DIA D ON (C.ID_DIA = D.ID_CAT_DIA) "
			+ "WHERE A.ID_CNTR = :idContrato and A.ID_FREC = :idFrec AND D.ID_FREC=4";

	/**
	 * Query para el select que obtiene los estados de cuenta con el tipo de
	 * recepcion del archivo
	 */
	public static final String SELECT_CONF_EDO_CTA_TIPO_RECIBIR_ARCH = "SELECT ID_ECTA,CONT_EDO_CTA FROM H2H_CNTR_ECTA"
			+ WHERE_IDCNTR_IDFREC;

	/**
	 * Query para obtener el estado de cuenta que contiene el formato del archivo
	 * almacenado
	 */
	public static final String SELECT_CONF_EDOCTA_FORMATOARCHIVO = "SELECT B.ID_LAY AS ID_LAY, B.NOMBRE AS DESCRIPCION FROM H2H_CNTR_ECTA A "
			+ "LEFT JOIN H2H_CAT_LAYT B ON (A.ID_LAY = B.ID_LAY) "
			+ "WHERE A.ID_CNTR = :idContrato AND A.ID_FREC = :idFrec AND B.ORIGEN = 'ECT' AND B.BAND_ACTIVO = 'A'";

	/**
	 * Query para obtener el id del estado de cuenta con el canal asignado
	 */
	public static final String SELECT_ID_EDOCTA_WITHCANAL = "SELECT NVL(ECTA.ID_CANL, 0) AS ID_CANL FROM H2H_CNTR_ECTA ECTA "
			+ "LEFT JOIN H2H_CAT_CANL CAN ON (ECTA.ID_CANL = CAN.ID_CANL) "
			+ "WHERE ECTA.ID_CNTR = :idContrato AND ECTA.ID_FREC = :idFrec";

	/**
	 * La instruccion del select obtiene si existe el producto Edo. de Cuenta dado
	 * de alta a la cuenta
	 */
	public static final String SELECT_EXISTE_PRODUCTO_EDO_CTA = "SELECT CASE WHEN NVL(A.ID_PROD, 0) > 0 THEN 'S' ELSE 'N' END AS PROD_EDO_CTA FROM "
			+ "(SELECT COUNT(*) AS ID_PROD FROM H2H_CNTR_PROD WHERE ID_CNTR = :idContrato AND ID_PROD = :idProducto AND "
			+ "BAND_ACTIVO = :bandActive) A";

	/**
	 * Instruccion para determinar si el producto esta en estado activo o no
	 */
	public static final String SELECT_EXIST_PRODUCTO_EDOCTA_ACTIVO = "SELECT CASE WHEN NVL(A.ID_PROD, 0) > 0 THEN 'S' ELSE 'N' END PROD_EDO_CTA FROM "
			+ "(SELECT COUNT(*) AS ID_PROD FROM h2h_cat_prod WHERE ID_PROD = :idProducto AND BAND_ACTIVO = :bandActive) A";

	/**
	 * Query para obtener el estado de cuenta con las banderas siguiente y cvrt
	 */
	public static final String CONS_BAND_EDO_CTA_SHOW = "SELECT BAND_EDO_CTA_SIG, BAND_EDO_CTA_CVRT FROM H2H_CNTR_ECTA"
			+ WHERE_IDCNTR_IDFREC;

	/**
	 * Query para obtener la banda anual del estado de cuenta
	 */
	public static final String SELECT_BANDANUL_EDOCTA = "SELECT BAND_ANUL_EDOCTA FROM H2H_CNTR_ECTA"
			+ WHERE_IDCNTR_IDFREC;

	/**
	 * Query para obtener la banda anual de repcob en la tabla H2H_MX_CNTR_REP_COB
	 */
	public static final String SELECT_BADANUL_REPCOB = "SELECT BAND_ANUL_REPCOB FROM H2H_MX_CNTR_REP_COB"
			+ WHERE_IDCNTR_IDFREC;

	/**
	 * Query para obtener el ultimo registro de la tabla de H2H_CTA_ORD_CARGA_MASIVA
	 */
	public static final String SELECT_LASTROW_INH2HCARGAMASIVA = "SELECT ID_CARGA FROM (SELECT ID_CARGA FROM H2H_CTA_ORD_CARGA_MASIVA ORDER BY ID_CARGA DESC) WHERE ROWNUM <= 1";

	/**
	 * Query para obtener la informacion que se registrada en la tabla usando el IN
	 * h2h_cta_ord_carga_masiva
	 */
	public static final String SELECTINFO_INSERTINTO_CARGAMASIVAIN = "SELECT ID_CNTR_CTA AS ID_NUM_MOV,NUM_CTA,"
			+ "'I' AS TIPO_CTA,DECODE(ID_CAT_DIVISA,null,'NA',ID_CAT_DIVISA) AS DIVISA "
			+ "FROM H2H_CNTR_CTA WHERE ID_CNTR = :idContrato AND (TIPO_CTA = 'O' OR TIPO_CTA = 'E') AND BAND_ACTIVO = 'A' AND ID_CNTR_CTA IN ("
			+ "SELECT ID_CNTR_CTA FROM H2H_ECTA_CTA "
			+ "WHERE ID_ECTA IN (SELECT ID_ECTA FROM H2H_CNTR_ECTA WHERE ID_FREC = :idFrec AND ID_CNTR = :idContrato)) ORDER BY NUM_CTA";

	/**
	 * Query para obtener la informacion que se registrada en la tabla usando el NOT
	 * IN h2h_cta_ord_carga_masiva
	 */
	public static final String SELECTINFO_INSERTINTO_CARGAMASIVANOTIN = "SELECT ID_CNTR_CTA AS ID_NUM_MOV,NUM_CTA,"
			+ "'I' AS TIPO_CTA,DECODE(ID_CAT_DIVISA,null,'NA',ID_CAT_DIVISA) AS DIVISA "
			+ "FROM H2H_CNTR_CTA WHERE ID_CNTR = :idContrato AND (TIPO_CTA = 'O' OR TIPO_CTA = 'E') AND BAND_ACTIVO = 'A' AND ID_CNTR_CTA NOT IN ("
			+ "SELECT ID_CNTR_CTA FROM H2H_ECTA_CTA "
			+ "WHERE ID_ECTA IN (SELECT ID_ECTA FROM H2H_CNTR_ECTA WHERE ID_FREC = :idFrec AND ID_CNTR = :idContrato)) ORDER BY NUM_CTA";

	/**
	 * Query para actualizar el movimiento de la tabla de cuentas ordenantes carga
	 * masiva
	 */
	public static final String SELECT_CTAORDENANTE_BYIDCARGA_NUMCTA = "SELECT ID_CARGA,ID_NUM_MOV,MOVIMIENTO,TIPO_CTA,DIVISA,"
			+ "NUM_CTA,RAZON_SOCIAL,DETALLE FROM h2h_cta_ord_carga_masiva WHERE ID_CARGA = :idCarga AND NUM_CTA = :numCta";

	/**
	 * Query para poder obtener las cuentas con configuracion o las cuentas
	 * ordenantes en archivo se ejecuta en el metodo
	 * getAllCuentasOrdenantesEnArchivo
	 */
	public static final String SELECT_CUENTA_CON_CONFIG_ESTADO = "SELECT A.ID_CNTR_CTA,A.ID_CNTR,A.NUM_CTA,A.TIPO_CTA,A.BAND_INTERBANCARIA,"
			+ "A.BAND_PERSONALIDAD,A.TITULAR,A.FECHA_ALTA,A.TERCEROS,A.ID_CAT_TIP_CTA,A.BAND_ACTIVO,A.ID_CAT_DIVISA,A.BIC "
			+ "FROM H2H_CNTR_CTA A WHERE A.ID_CNTR = :idCntr AND "
			+ "(A.TIPO_CTA = 'O' OR A.TIPO_CTA = 'E') AND A.BAND_ACTIVO = 'A' AND EXISTS (SELECT B.* FROM H2H_ECTA_CTA B WHERE "
			+ "A.ID_CNTR_CTA = B.ID_CNTR_CTA AND B.ID_ECTA = (SELECT C.ID_ECTA FROM H2H_CNTR_ECTA C WHERE C.ID_FREC = :idFrec AND "
			+ "C.ID_CNTR = :idCntr)) ORDER BY A.NUM_CTA";

	/**
	 * Query para eliminar la asociacion del estado de cuenta H2H_ECTA_CTA
	 */
	public static final String DELETE_ECTA_CTA_BY_ID_CNTR_ID_FREC = "DELETE FROM H2H_ECTA_CTA A "
			+ "WHERE Exists (select 1 from h2h_cntr_ecta b where b.id_ecta = A.ID_ECTA AND B.ID_CNTR = :idContrato AND B.ID_FREC = :idFrec )";

	/**
	 * Query para eliminar la asociacion del estado de cuenta H2H_ECTA_FREC_INTRADIA
	 */
	public static final String DELETE_H2H_ECTA_FREC_INTRADIA = "DELETE FROM H2H_ECTA_FREC_INTRADIA A WHERE exists "
			+ "(select 1 from h2h_cntr_frec_ecta b, h2h_cntr_ecta c where b.id_cntr_frec_ecta = a.id_frec_ecta AND B.ID_ECTA = C.ID_ECTA AND C.ID_CNTR = :idContrato) ";

	/**
	 * Query para eliminar de la tabla H2H_ECTA_FREC_SEMANAL
	 */
	public static final String DELETE_H2H_ECTA_FREC_SEMANAL = "DELETE FROM H2H_ECTA_FREC_SEMANAL A  WHERE exists "
			+ " (select 1 from h2h_cntr_frec_ecta b , H2H_CNTR_ECTA C where b.id_cntr_frec_ecta = a.id_frec_ecta and b.id_ecta = c.id_ecta AND C.ID_CNTR= :idContrato) ";
	/**
	 * Query para eliminar de la tabla H2H_CNTR_FREC_ECTA Para Intradia
	 */
	public static final String DELETE_H2H_CNTR_FREC_ECTA_INTRADIA = "DELETE FROM H2H_CNTR_FREC_ECTA A WHERE exists "
			+ " (select 1 from h2h_cntr_ecta b where b.id_ecta = A.ID_ECTA AND B.ID_CNTR =:idContrato  AND B.ID_FREC= :idFrec ) AND A.ID_FREC IN(1,2) ";

	/**
	 * Query para eliminar de la tabla H2H_CNTR_FREC_ECTA Para Consolidado
	 */
	public static final String DELETE_H2H_CNTR_FREC_ECTA_CONSOLIDADO = "DELETE FROM H2H_CNTR_FREC_ECTA A WHERE exists "
			+ " (select 1 from h2h_cntr_ecta b where b.id_ecta = A.ID_ECTA AND B.ID_CNTR =:idContrato  AND B.ID_FREC= :idFrec ) AND A.ID_FREC IN(3,4,5,6) ";
	/**
	 * Query para eliminar de la tabla H2H_CNTR_ECTA
	 */
	public static final String DELETE_H2H_CNTR_ECTA = "DELETE FROM H2H_CNTR_ECTA A WHERE A.ID_CNTR=:idContrato AND A.ID_FREC=:idFrec ";
	/**
	 * Sentencia que cambia el estatus de un estad de cuenta para un contrato dado.
	 */
	public static final String CANCELAR_SOLICITUDES_ANTERIORES = "UPDATE H2H_CTRL_ECTA SET ID_CAT_ESTATUS = :idStatus "
			+ " WHERE NUM_CTR = :numCtr AND ID_CAT_ESTATUS IN (:idsStatus) ";

	public static final String SELECT_H2H_CAT_HORARIO_BY_TYPE = SELECT_SCHEDULE_CATALOG
			+ ",CH.ID_FREC as ESTATUS_ACTIVO FROM H2H_CAT_HORARIO CH WHERE CH.ID_FREC = 2  AND CH.ID_CAT_HORARIO IN (:hoursIds) AND (CH.TIPO='A' OR CH.TIPO='E') ORDER BY CH.HORA_EJEC ASC ";

	public static final String SELECT_H2H_CAT_HORARIO_NO_TYPE = SELECT_SCHEDULE_CATALOG
			+ ",CH.ID_FREC as ESTATUS_ACTIVO FROM H2H_CAT_HORARIO CH WHERE CH.ID_FREC = 2  AND CH.ID_CAT_HORARIO IN (:hoursIds) AND (CH.TIPO='A') ORDER BY CH.HORA_EJEC ASC ";

	/**
	 * Query para la actualizacion de configuración de comprobantes por contrato
	 */
	public static final String UPDATE_PRODUCTS_BY_CNTR = "UPDATE H2H_CNTR_PROD SET BAND_ENV_BUZ = :bandEnvBuz, BAND_24X7 = :band24x7 WHERE ID_CNTR_PROD = :idCntrProd";
	/**
	 * Query para la consulta del valor del parametro solicitado.
	 */
	public static final String SELECT_PARAM_BY_NUMBR_PARAM = "SELECT VALOR FROM H2H_PARAM WHERE NMBR_PARAM = :nmbrParam";
	/**
	 * Query para la consulta de productos y su configuración de comprobantes por
	 * contrato
	 */
	public static final String SELECT_PRODUCTS_BY_CNTR = "SELECT PROD.ID_CNTR_PROD, CATP.DESC_PROD, PROD.BAND_ENV_BUZ, PROD.BAND_24X7, CATP.CVE_PROD_OPER "
			+ "FROM H2H_CNTR CNTR " + "INNER JOIN H2H_CNTR_PROD PROD ON PROD.ID_CNTR = CNTR.ID_CNTR "
			+ "INNER JOIN H2H_CAT_PROD CATP ON PROD.ID_PROD = CATP.ID_PROD "
			+ "WHERE  CATP.CVE_PROD_OPER NOT IN(:ids) AND " + "PROD.BAND_ACTIVO = 'A' AND CNTR.ID_CNTR =:idCntr "
			+ "ORDER BY CATP.DESC_PROD ASC";
	/**
	 * Nombre del parametro 'H2H_PROD_EXC_COMP'
	 */
	public static final String PARAM_H2H_PROD_EXC_COMP = "H2H_PROD_EXC_COMP";
	/**
	 * Nombre del parametro 'PROD_GC_ACT_24X7'
	 */
	public static final String PARAM_PROD_GC_ACT_24X7 = "PROD_GC_ACT_24X7";
	/**
	 * Query para la consulta de contrato por identificador de cliente.
	 */
	public static final String SELECT_CONTRACT_BY_NUM_CONTRACT = "SELECT CLTE.BUC buc, CLTE.RAZON_SCIA razonSocial, CTA.NUM_CTA numeroCuenta, "
			+ "EST.DESC_ESTATUS descEstatus, EST.TIPO_ESTATUS tipoEstatus, CNTR.ID_CNTR idCntr "
			+ "FROM H2H_CNTR CNTR, H2H_CNTR_CTA CTA, H2H_CLTE CLTE, H2H_CAT_ESTATUS EST "
			+ "WHERE CNTR.NUM_CNTR = :numContrato AND CTA.TIPO_CTA = 'E' "
			+ "AND CTA.ID_CNTR = CNTR.ID_CNTR AND CNTR.ID_CLTE = CLTE.ID_CLTE "
			+ "AND CNTR.ID_ESTADO = EST.ID_CAT_ESTATUS ";

	/**
	 * Query para la consulta de cuenta beneficiaria del contrato por número de
	 * contrato y cuenta.
	 */
	public static final String SELECT_CTA_BENEFICIARIA_CTO = "SELECT CTA.TIPO_CTA AS tipoCuenta, CNTR.ID_CLTE AS buc, "
			+ "CASE WHEN  CTA.BAND_INTERBANCARIA ='I' THEN 'INTERBANCARIA' "
			+ "WHEN CTA.BAND_INTERBANCARIA  ='B' THEN 'BANCARIA' ELSE '' "
			+ "END AS bandInterbancaria, CTA.BAND_PERSONALIDAD AS bandPersonalidad, "
			+ "CTA.NUM_CTA AS numCuenta, CTA.TITULAR AS titular, "
			+ "TO_CHAR(CTA.FECHA_ALTA,'DD/MM/YYYY') AS fechaAlta FROM H2H_CNTR  CNTR, H2H_CNTR_CTA  CTA "
			+ "WHERE CNTR.ID_CNTR  = CTA.ID_CNTR  AND CTA.TIPO_CTA = 'B' AND CTA.BAND_ACTIVO = 'A' "
			+ "AND CNTR.NUM_CNTR = :numeroContrato AND SUBSTR(CTA.NUM_CTA, LENGTH(CTA.NUM_CTA)-LENGTH(:numeroCuenta)+1 )  = :numeroCuenta";
	/**
	 * Query para la consulta de cuenta beneficiaria del contrato por número de
	 * contrato y cuenta.
	 */
	public static final String SELECT_ALL_CTAS_BENEFICIARIAS_CTO = "SELECT CTA.TIPO_CTA AS tipoCuenta, CNTR.ID_CLTE AS buc, CASE "
			+ "WHEN CTA.BAND_INTERBANCARIA ='I' THEN 'INTERBANCARIA' "
			+ "WHEN CTA.BAND_INTERBANCARIA  ='B' THEN 'BANCARIA' ELSE '' "
			+ "END AS bandInterbancaria, CTA.BAND_PERSONALIDAD AS bandPersonalidad, "
			+ "CTA.NUM_CTA AS numCuenta, CTA.TITULAR AS titular, "
			+ "TO_CHAR(CTA.FECHA_ALTA,'DD/MM/YYYY') AS fechaAlta FROM H2H_CNTR  CNTR, H2H_CNTR_CTA  CTA "
			+ "WHERE CNTR.ID_CNTR  = CTA.ID_CNTR  AND CTA.TIPO_CTA = 'B' AND CTA.BAND_ACTIVO = 'A' "
			+ "AND CNTR.NUM_CNTR = :numeroContrato";

	/**
	 * Query para la consulta detallada de la información del contrato.
	 */
	public static final String SELECT_DETALLE_CONTRACT_BY_NUM_CONTRATO = "SELECT CLTE.BUC AS buc, CLTE.RAZON_SCIA AS razonSocial, CLTE.PERSONALIDAD AS personalidad, "
			+ "CLTE.NOMBRE AS nombre, CLTE.APPATERNO AS paterno, CLTE.APMATERNO AS materno, "
			+ "CTA.NUM_CTA AS cuentaEje, CNTR.ID_CNTR AS idCNTR, CNTR.ID_ESTADO AS idESTado, "
			+ "CNTR.NUM_CNTR AS numeroContrato, CNTR.HABILITA_BENE AS habilitaBene, CNTR.CVE_CANL_HSM AS cveCanlHms, "
			+ "CNTR.BAND_BENEF AS bandBenef, CNTR.BAND_CLABE_ECTA AS bandClabeECTA, CNTR.BAND_CAMB_PROD AS bandCambProd, "
			+ "EST.Desc_ESTatus AS descEsTatus, CLTE.nemonico AS nemonico, CNTR.BAND_ACT_CONT AS bandActCont, "
			+ "CNTR.BIC AS bic, CNTR.MSG_PTNR AS msgPtnr, CNTR.TIPO_TRAN AS tipoTran, CNTR.BAND_CIF_CTRL AS bandCifCtrl, "
			+ "DIAS_PROG_ARCH AS diasProgArch, nvl(CNTR.ALIAS,'') AS alias , CNTR.CTR_BACK_CONF AS ctrBackConf "
			+ "FROM H2H_CNTR CNTR, H2H_CNTR_CTA CTA, H2H_CLTE CLTE,  H2H_CAT_ESTATUS EST "
			+ "WHERE CNTR.NUM_CNTR = :numeroContrato AND CTA.TIPO_CTA = 'E' AND CTA.ID_CNTR = CNTR.ID_CNTR   "
			+ "    AND CNTR.ID_CLTE = CLTE.ID_CLTE AND CNTR.id_ESTado = EST.ID_CAT_ESTATUS";
	
	/**
	 * Query para la consulta notificaciones por numero de contrato.
	 */
	public static final String SELECT_NOTIFICATIONS_BY_NUM_CONTRATO = "SELECT n.ID_NOTI, NVL(nc.ID_CNTR, 0) ID_CNTR, NVL(nc.ID_NOTI_CNTR, 0) ID_NOTI_CNTR, "
			+ " n.TIPO_DEST, TRIM(NVL(n.NOMBRE_NOTI, 'Notif ' || n.ID_NOTI)) NOMBRE_NOTI, "
			+ " NVL(BAND_ENV_AREA_CENT, 'I') BAND_OP_CAPTACION, NVL(BAND_ENVIO_CTE, 'I') BAND_CLIENTE, "
			+ " decode(count(nt.dir_email),0,'I','A') MAILS "
			+ " FROM H2H_NOTI n, H2H_NOTI_CNTR nc ,H2H_DEST_NOTIF nt "
			+ " WHERE n.id_noti = nc.id_noti(+) and nc.id_noti_cntr = nt.id_noti_cntr(+)  "
			+ " AND n.TIPO_NOTI = 'N' AND n.BAND_ACTIVO = 1  AND nc.ID_CNTR(+) = :idContract "
			+ " GROUP BY n.ID_NOTI, NVL(nc.ID_CNTR, 0), NVL(nc.ID_NOTI_CNTR, 0), n.TIPO_DEST, TRIM(NVL(n.NOMBRE_NOTI, 'Notif ' || n.ID_NOTI)), NVL(BAND_ENV_AREA_CENT, 'I'), NVL(BAND_ENVIO_CTE, 'I')  "
			+ " ORDER BY NLSSORT(UPPER(TRIM(NOMBRE_NOTI)), 'NLS_SORT=SPANISH') ASC, id_noti";

	/**
	 * Query para la insertar notificaciones.
	 */
	public static final String INSERT_NOTIFICATIONS = "INSERT INTO H2H_NOTI_CNTR(ID_NOTI_CNTR, ID_CNTR, ID_NOTI, BAND_ENVIO_CTE, BAND_ENV_AREA_CENT) "
			+ "  VALUES((SELECT DECODE(MAX(ID_NOTI_CNTR), null, 1, MAX(ID_NOTI_CNTR)+1) FROM H2H_NOTI_CNTR), :idContract, :idNoti, :bandEnvioCte, :bandEnvioAreaCent)";
				
	/**
	 * Query para la actualizacion de la bandera de Area Central.
	 */
	public static final String UPDATE_BAND_AREA_CENT_NOTIFICACION = "UPDATE H2H_NOTI_CNTR SET BAND_ENV_AREA_CENT = :bandEnvioAreaCent WHERE ID_NOTI_CNTR = :idNotiCntr";
	
	/**
	 * Query para la actualizacion de la bandera de Cliente.
	 */
	public static final String UPDATE_BAND_CLIENTE_NOTIFICACION = "UPDATE H2H_NOTI_CNTR SET BAND_ENVIO_CTE = :bandEnvioCte WHERE ID_NOTI_CNTR = :idNotiCntr";
	
	/**
	 * Query para actualizar notificaciones.
	 */
	public static final String UPDATE_NOTIFICACIONES = "UPDATE H2H_NOTI_CNTR SET BAND_ENVIO_CTE = :bandEnvioCte, BAND_ENV_AREA_CENT = :bandEnvioAreaCent "
			+ "    WHERE ID_NOTI_CNTR= :idNotiCntr AND ID_CNTR= :idContract AND ID_NOTI = :idNoti ";
	
	/**
	 * Query para actualizar notificaciones cent operaciones.
	 */
	public static final String UPDATE_NOTIFICACIONES_OC = "UPDATE H2H_NOTI_CNTR SET BAND_ENV_AREA_CENT = :bandEnvioAreaCent "
			+ "    WHERE ID_NOTI_CNTR= :idNotiCntr AND ID_CNTR= :idContract AND ID_NOTI = :idNoti";
	
	/**
	 * Query para actualizar notificaciones envio cliente.
	 */
	public static final String UPDATE_NOTIFICACIONES_CL = "UPDATE H2H_NOTI_CNTR SET BAND_ENVIO_CTE = :bandEnvioCte"
			+ "   WHERE ID_NOTI_CNTR= :idNotiCntr AND ID_CNTR= :idContract AND ID_NOTI = :idNoti ";
		
	/**
	 * Query para actualizar el estatus de catalogo.
	 */
	public static final String UPDATE_STATUS_CAT = "UPDATE H2H_NOTI_CNTR  "
			+ "    SET BAND_ENVIO_CTE = :bandEnvioCte WHERE ID_NOTI_CNTR= :idNotiCntr AND ID_CNTR= :idContract AND ID_NOTI = :idNoti ";
	
	/**
	 * Query para select de los destinatarios.
	 */
	public static final String SELECT_DEST = "SELECT ID_NOTI_CNTR, TRIM(DIR_EMAIL) DIR_EMAIL, TIPO_DESTINATARIO FROM H2H_DEST_NOTIF "
			+ "    WHERE ID_NOTI_CNTR = :idNotiCntr AND TIPO_DESTINATARIO = :kindDest order by NLSSORT(TRIM(DIR_EMAIL), 'NLS_SORT=SPANISH') ASC";
		
	/**
	 * Query para insertar correos.
	 */
	public static final String INSERT_EMAIL = "INSERT INTO H2H_DEST_NOTIF(ID_DEST_NOTIF,ID_NOTI_CNTR, DIR_EMAIL, TIPO_DESTINATARIO) "
			+ "    VALUES((SELECT DECODE(MAX(ID_DEST_NOTIF), null, 1, MAX(ID_DEST_NOTIF)+1) FROM H2H_DEST_NOTIF), :idNotiCntr, :email, :kindDest) ";
			
	/**
	 * Query select para id de notificacion.
	 */
	public static final String SELECT_ID_NOTIFICATIONS = "SELECT ID_NOTI FROM H2H_NOTI_CNTR WHERE ID_NOTI_CNTR= :idNotiCntr ";
			
	/**
	 * Query select para id de notificacion contrato.
	 */
	public static final String SELECT_ID_NOTIFICATIONS_CONTRACT = "SELECT ID_NOTI_CNTR FROM H2H_NOTI_CNTR WHERE ID_NOTI = :idNoti AND ID_CNTR = :idContract";
			
	/**
	 * Query update para modificar correo.
	 */
	public static final String UPDATE_EMAIL = "UPDATE H2H_DEST_NOTIF SET DIR_EMAIL = :email WHERE ID_NOTI_CNTR = :idNotiCntr AND DIR_EMAIL = :emailant AND TIPO_DESTINATARIO = :kindDest";
			
	/**
	 * Query delete para correos.
	 */
	public static final String DELETE_EMAIL = "DELETE FROM H2H_DEST_NOTIF WHERE ID_NOTI_CNTR = :idNotiCntr AND DIR_EMAIL = :email";
			
	/**
	 * Query select para total de correos.
	 */
	public static final String SELECT_EMAIL_LIST = "SELECT COUNT(1) FROM H2H_DEST_NOTIF WHERE ID_NOTI_CNTR = :idNotiCntr AND DIR_EMAIL = :email AND TIPO_DESTINATARIO = :kindDest";
			
	/**
	 * Query para select del estatus del tipo de notificacion por idcontrato.
	 */
	public static final String SELECT_STATUS_KIND_NOTI = "SELECT ID_NOTI_CNTR, ID_CNTR, ID_NOTI, BAND_ENVIO_CTE, BAND_ENV_AREA_CENT "
			+ "   FROM H2H_NOTI_CNTR WHERE ID_CNTR = :idContract ";
	
	/**
	 * Query select para el estatus del tipo de notificacion por idnoti y idnoticntr.
	 */
	public static final String SELECT_STATUS_KIND_NOTI_BY_IDNOTICNTR = "SELECT  ID_NOTI_CNTR ,ID_CNTR ,ID_NOTI, BAND_ENVIO_CTE, BAND_ENV_AREA_CENT FROM H2H_NOTI_CNTR WHERE ID_NOTI = :idNoti AND ID_NOTI_CNTR = :idNotiCntr";
	
	/**Constante para el Query que obtiene los CONTRATOS POR FECHA*/
	public static final String QUERY_CONSULTA_CONTRATO = "SELECT distinct cntr.NUM_CNTR CONTRATO, DECODE (clte.personalidad,'F',trim(nombre) || ' '||trim(appaterno)||' ' ||trim(apmaterno) , DECODE (Clte.RAZON_SCIA, 'null', ' ', NVL (Clte.RAZON_SCIA, ' ')) )   RAZON_SOCIAL,"+
			"NVL(clte.BUC, ' ') CODIGO_CLIENTE, NVL(Est.Desc_Estatus, ' ') DESC_ESTATUS,(NVL(clte.nombre, ' ') || ' ' || NVL(clte.APPATERNO, ' ') || ' ' || NVL(clte.apmaterno, ' ')) as NOMBRE, "+ 
			"NVL(clte.personalidad, ' ') personalidad, cntr.ID_CNTR ID_CONTRATO, cntr.ID_ESTADO, cta.NUM_CTA  FROM H2H_CNTR cntr, H2H_CLTE clte, H2H_CNTR_CTA cta, H2H_CAT_ESTATUS est WHERE "+
			"Cntr.ID_CLTE = Clte.Id_Clte AND Cntr.Id_Cntr = Cta.Id_Cntr AND Cntr.Id_Estado = Est.Id_cat_Estatus AND Est.Tipo_Estatus = 'C' AND cta.TIPO_CTA = 'E' ORDER BY 1";
	
	
	/**Constante para el Query que obtiene los CONTRATOS POR FECHA*/
	public static final String QUERY_CONSULTA_CONTRATO_FECHAS = "SELECT distinct cntr.NUM_CNTR CONTRATO, DECODE (clte.personalidad,'F',trim(nombre) || ' '||trim(appaterno)||' ' ||trim(apmaterno) , DECODE (Clte.RAZON_SCIA, 'null', ' ', NVL (Clte.RAZON_SCIA, ' ')) )   RAZON_SOCIAL,"+
			"NVL(clte.BUC, ' ') CODIGO_CLIENTE, NVL(Est.Desc_Estatus, ' ') DESC_ESTATUS,(NVL(clte.nombre, ' ') || ' ' || NVL(clte.APPATERNO, ' ') || ' ' || NVL(clte.apmaterno, ' ')) as NOMBRE, "+ 
			"NVL(clte.personalidad, ' ') personalidad, cntr.ID_CNTR ID_CONTRATO, cntr.ID_ESTADO, cta.NUM_CTA FROM H2H_CNTR cntr, H2H_CLTE clte, H2H_CNTR_CTA cta, H2H_CAT_ESTATUS est WHERE "+
			"Cntr.ID_CLTE = Clte.Id_Clte AND Cntr.Id_Cntr = Cta.Id_Cntr AND Cntr.Id_Estado = Est.Id_cat_Estatus AND Est.Tipo_Estatus = 'C' AND cta.TIPO_CTA = 'E' " + DATE_RANGE;
	
	/**Constante para el Query que obtiene los CONTRATOS POR FECHA*/
	public static final String QUERY_CONSULTA_CONTRATO_NUM_CONTRATO = "SELECT distinct cntr.NUM_CNTR CONTRATO, DECODE (clte.personalidad,'F',trim(nombre) || ' '||trim(appaterno)||' ' ||trim(apmaterno) , DECODE (Clte.RAZON_SCIA, 'null', ' ', NVL (Clte.RAZON_SCIA, ' ')) )   RAZON_SOCIAL,"+
			"NVL(clte.BUC, ' ') CODIGO_CLIENTE, NVL(Est.Desc_Estatus, ' ') DESC_ESTATUS,(NVL(clte.nombre, ' ') || ' ' || NVL(clte.APPATERNO, ' ') || ' ' || NVL(clte.apmaterno, ' ')) as NOMBRE, "+ 
			"NVL(clte.personalidad, ' ') personalidad, cntr.ID_CNTR ID_CONTRATO, cntr.ID_ESTADO, cta.NUM_CTA FROM H2H_CNTR cntr, H2H_CLTE clte, H2H_CNTR_CTA cta, H2H_CAT_ESTATUS est WHERE "+
			"Cntr.ID_CLTE = Clte.Id_Clte AND Cntr.Id_Cntr = Cta.Id_Cntr AND Cntr.Id_Estado = Est.Id_cat_Estatus AND Est.Tipo_Estatus = 'C' AND cta.TIPO_CTA = 'E' " + NUM_CONTRATO;
	
	/**Constante para el Query que obtiene los CONTRATOS POR FECHA*/
	public static final String QUERY_CONSULTA_CONTRATO_COD_CLIENTE = "SELECT distinct cntr.NUM_CNTR CONTRATO, DECODE (clte.personalidad,'F',trim(nombre) || ' '||trim(appaterno)||' ' ||trim(apmaterno) , DECODE (Clte.RAZON_SCIA, 'null', ' ', NVL (Clte.RAZON_SCIA, ' ')) )   RAZON_SOCIAL,"+
			"NVL(clte.BUC, ' ') CODIGO_CLIENTE, NVL(Est.Desc_Estatus, ' ') DESC_ESTATUS,(NVL(clte.nombre, ' ') || ' ' || NVL(clte.APPATERNO, ' ') || ' ' || NVL(clte.apmaterno, ' ')) as NOMBRE, "+ 
			"NVL(clte.personalidad, ' ') personalidad, cntr.ID_CNTR ID_CONTRATO, cntr.ID_ESTADO, cta.NUM_CTA FROM H2H_CNTR cntr, H2H_CLTE clte, H2H_CNTR_CTA cta, H2H_CAT_ESTATUS est WHERE "+
			"Cntr.ID_CLTE = Clte.Id_Clte AND Cntr.Id_Cntr = Cta.Id_Cntr AND Cntr.Id_Estado = Est.Id_cat_Estatus AND Est.Tipo_Estatus = 'C' AND cta.TIPO_CTA = 'E' " + COD_CLIENTE;
	
	/**Constante para el Query que obtiene los CONTRATOS POR FECHA*/
	public static final String QUERY_CONSULTA_CONTRATO_CUENTA_EJE = "SELECT distinct cntr.NUM_CNTR CONTRATO, DECODE (clte.personalidad,'F',trim(nombre) || ' '||trim(appaterno)||' ' ||trim(apmaterno) , DECODE (Clte.RAZON_SCIA, 'null', ' ', NVL (Clte.RAZON_SCIA, ' ')) )   RAZON_SOCIAL,"+
			"NVL(clte.BUC, ' ') CODIGO_CLIENTE, NVL(Est.Desc_Estatus, ' ') DESC_ESTATUS,(NVL(clte.nombre, ' ') || ' ' || NVL(clte.APPATERNO, ' ') || ' ' || NVL(clte.apmaterno, ' ')) as NOMBRE, "+ 
			"NVL(clte.personalidad, ' ') personalidad, cntr.ID_CNTR ID_CONTRATO, cntr.ID_ESTADO , cta.NUM_CTA FROM H2H_CNTR cntr, H2H_CLTE clte, H2H_CNTR_CTA cta, H2H_CAT_ESTATUS est WHERE "+
			"Cntr.ID_CLTE = Clte.Id_Clte AND Cntr.Id_Cntr = Cta.Id_Cntr AND Cntr.Id_Estado = Est.Id_cat_Estatus AND Est.Tipo_Estatus = 'C' AND cta.TIPO_CTA = 'E' " + CUENTA_EJE;
	
	/**Constante para el Query que obtiene los CONTRATOS POR FECHA*/
	public static final String QUERY_CONSULTA_CONTRATO_RAZON_SOCIAL = "SELECT distinct cntr.NUM_CNTR CONTRATO, DECODE (clte.personalidad,'F',trim(nombre) || ' '||trim(appaterno)||' ' ||trim(apmaterno) , DECODE (Clte.RAZON_SCIA, 'null', ' ', NVL (Clte.RAZON_SCIA, ' ')) )   RAZON_SOCIAL,"+
			"NVL(clte.BUC, ' ') CODIGO_CLIENTE, NVL(Est.Desc_Estatus, ' ') DESC_ESTATUS,(NVL(clte.nombre, ' ') || ' ' || NVL(clte.APPATERNO, ' ') || ' ' || NVL(clte.apmaterno, ' ')) as NOMBRE, "+ 
			"NVL(clte.personalidad, ' ') personalidad, cntr.ID_CNTR ID_CONTRATO, cntr.ID_ESTADO, cta.NUM_CTA FROM H2H_CNTR cntr, H2H_CLTE clte, H2H_CNTR_CTA cta, H2H_CAT_ESTATUS est WHERE "+
			"Cntr.ID_CLTE = Clte.Id_Clte AND Cntr.Id_Cntr = Cta.Id_Cntr AND Cntr.Id_Estado = Est.Id_cat_Estatus AND Est.Tipo_Estatus = 'C' AND cta.TIPO_CTA = 'E' " + RAZON_SOCIAL;
	
			
	
	/**Constante para el Query que obtiene los CONVENIOS POR ID CONTRATO*/
	public static final String QUERY_CONSULTA_CONVENIO_CONTRATO = "SELECT CO.ID_CNTR_CONV,CO.ID_CNTR,CO.clve_serv,CO.BAND_ACTI,CO.FECH_UMOD,CN.desr,CN.num_cta " +
																  "FROM H2H_CNTR_CONV CO, H2H_CAT_CONV CN WHERE co.clve_serv = cn.clve_serv AND " +
																  "CO.id_cntr = :idCntr AND CO.band_acti='A'";
	/**Constante para el Query que consulta convenios por nombre*/
	public static final String CONSULTA_CONVENIOS_BY_NOMBRE = "SELECT clve_serv,desr,num_cta from H2H_CAT_CONV WHERE band_acti='A' AND clve_serv= :clveServ OR upper(desr) LIKE upper(concat(:desr, '%'))";
	
	/**Constante para el Query que agrega convenios de contrato*/
	public static final String QUERY_AGREGA_CONVENIO = "INSERT INTO H2H_CNTR_CONV h (h.ID_CNTR_CONV, h.ID_CNTR, h.BAND_ACTI, h.FECH_UMOD, h.CLVE_SERV) VALUES((SELECT DECODE(MAX(t.ID_CNTR_CONV), null, 1, MAX(t.ID_CNTR_CONV)+1) FROM H2H_CNTR_CONV t), :idCntr,'A',null, :clveServ)";
	
	/**Constante para el Query que elimina convenios de contrato*/
	public static final String QUERY_ELIMINA_CONVENIOS_DE_CONTRATO = "DELETE FROM H2H_CNTR_CONV h WHERE h.id_cntr= :idCntr AND h.clve_serv= :clveServ";
			
	/**
	 * Query para la consulta id del protocolo asignado al canal.
	 */
	public static final String ID_PROTOCOL_BY_CHANNEL = "SELECT DISTINCT NVL(pp.ID_PTCL, 0) "
			+ " FROM H2H_PATT_PTCL param, H2H_PARA_PTCL pp "
			+ " WHERE param.ID_CANL = :idChannel "
			+ " AND pp.ID_PARA_PTCL = param.ID_PARA_PTCL";
	/**
	 * Obtiene los nombres de los parametros activos de un protocolo.
	 */
	public static final String PARAM_NAMES_BY_PROTOCOL = "SELECT  NMBR_PARA "
			+ " FROM H2H_PARA_PTCL WHERE ID_PTCL = :idProtocol AND BAND_ACTIVO = 1 "
			+ " ORDER BY NLSSORT(UPPER(NMBR_PARA), 'NLS_SORT=SPANISH') ";
	/**
	 * Consulta los patrones de protocolo asignados a un canal.
	 */
	public static final String PROTOCOL_PATTERNS_BY_CHANNEL = "SELECT "
				+ "   para.ID_PARA_PTCL ID_PARAM_PROTOCOL, ptcl.ID_PTCL ID_PROTOCOL, ptcl.NOMBRE PROTOCOL_NAME, "
			+ "   para.NMBR_PARA PARAM_NAME, patt.VALOR PATTERN_VALUE, "
			+ "   para.PARA_ES_EDIT PARAM_IS_EDITABLE, para.PARA_ES_OBLI PARAM_IS_MANDATORY, "
			+ "   para.PARA_LONG PARAM_LENGTH, para.PARA_TIPO_DATO PARAM_DATA_TYPE, "
			+ "   NVL(patt.ID_SEQU_PATT, 0) ID_PATTERN, patt.PATT_ACTI PATTERN_TYPE, "
			+ "   NVL(patt.ID_DATO_TRAN, 0) ID_REG, NVL(patt.BAND_ACTI, 'I') PATTERN_STATUS "
			+ "FROM H2H_PTCL ptcl, H2H_PARA_PTCL para, H2H_PATT_PTCL patt "
			+ "WHERE ptcl.ID_PTCL = :idProtocol "
			+ "   AND ptcl.ID_PTCL = para.ID_PTCL "
			+ "   AND para.ID_PARA_PTCL = patt.ID_PARA_PTCL(+) "
			+ "   AND patt.ID_CANL(+) = :idChannel "
			+ "   AND patt.PATT_ACTI(+) = :type "
			+ "   AND para.BAND_ACTIVO = 1 "
			+ "ORDER BY patt.ID_DATO_TRAN, patt.PATT_ACTI, "
			+ "   NLSSORT(UPPER(para.nmbr_para), 'NLS_SORT=SPANISH')";
	/**
	 * Consulta para Eliminar Parametros de Canal
	 */
	public static final String DELETE_CHANNEL_PATTERN = "DELETE FROM H2H_PATT_PTCL WHERE ID_CANL = :idChannel";
	/**
	 * Obtiene el siguiente valor de la secuencia H2H_PATT_PTCL_DATO_TRAN_SEQ
	 */
	public static final String NEXT_VAL_DATO_TRAN_SEQ = "SELECT H2H_PATT_PTCL_DATO_TRAN_SEQ.NEXTVAL as seq from DUAL";
	/**
	 * Obtiene el siguiente valor de la secuencia H2H_PATT_PTCL_SEQ
	 */
	public static final String NEXT_VAL_PTCL_SEQ = "SELECT H2H_PATT_PTCL_SEQ.NEXTVAL as seq from DUAL";
	/**
	 * Actualiza valor de Parametros de Canal
	 */
	public static final String UPDATE_PROTOCOL_PATTERN =
			"UPDATE H2H_PATT_PTCL SET VALOR = :patternValue WHERE ID_SEQU_PATT = :idPattern ";
	/**
	 * Inserta valor de Parametros de Canal
	 */
	public static final String INSERT_CHANNEL_PROTOCOL_PATTERN = "INSERT INTO H2H_PATT_PTCL " +
			"   (ID_SEQU_PATT, ID_CANL, ID_PARA_PTCL, VALOR, PATT_ACTI, FECH_REG, ID_DATO_TRAN, BAND_ACTI) " +
			"VALUES (:idPattern , :idChannel , :idParamProtocol , :patternValue , :patternType , sysdate, :idReg , 'A')";
	/**
	 * Activa/Inactiva los parametros de un protocolo con base al numero de registro y tipo
	 */
	public static final String UPDATE_PATTERN_STATUS =
			"UPDATE H2H_PATT_PTCL SET BAND_ACTI = :patternStatus " +
			"WHERE ID_DATO_TRAN =:idReg AND PATT_ACTI = :patternType ";
	/**
	 * Consulta la lista de divisas
	 */
	public static final String LISTA_DIVISAS = "select id_cat_divisa as key, clav_capta as value "
			+ "from h2h_cat_divisa order by id_cat_divisa";
	/**
	 * Consulta la lista de estatus
	 */
	public static final String LISTA_ESTATUS = "select id_cat_estatus as key, "
			+ "desc_estatus as value from h2h_cat_estatus where tipo_estatus = 'R' "
			+ "and band_activo = 'A' order by desc_estatus";
	/**
	 * Consulta la lista de productos
	 */
	public static final String LISTA_PRODUCTOS = "select cve_prod_oper as key, desc_prod as value "
			+ "from h2h_cat_prod where band_activo = 'A' and band_visi_cons = 'A' order by desc_prod";
	
	/**Consulta la lista de convenios disponibles*/
	public static final String QUERY_CONSULTA_CONVENIO_DISP = "SELECT clve_serv,desr,num_cta from H2H_CAT_CONV where band_acti='A' order by clve_serv"; 
	
	/**Consulta si ya existe el convenio a registrar en base al id de contrato*/
	public static final String CONSULTA_CONVENIOS_BY_NOMBRE_ID_CNTR="SELECT clve_serv from h2h_cntr_conv where band_acti='A'  AND clve_serv=:cveSer AND id_cntr=:idCntr ";
	
	public static final String QUERY_COMBO = "SELECT id_cat_estatus as KEY, desc_estatus as VALUE from H2H_CAT_ESTATUS WHERE TIPO_ESTATUS = 'R' AND CLASIFICACION = 'I' AND (DESC_ESTATUS = 'EN ESPERA' OR DESC_ESTATUS = 'PROGRAMADO')";
	
	public static final String QUERY_OBTENER_CATALOGO_PRODUCTOS = "SELECT cve_prod_oper as ID_PROD, DESC_PROD FROM H2H_CAT_PROD WHERE BAND_ACTIVO = 'A'  AND BAND_VISI_CONS = 'A' ORDER BY DESC_PROD";
	
	/**
	 * Constructor privado.
	 */
	private QueryConstant() {
	}
}
