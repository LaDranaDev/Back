/**
* Santander SCIB - Banco Santander Negocios Globales
* Todos los derechos reservados
* IArchivoTrackingBService.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <3 dic 2024 18:14:38>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.service;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.NivelArchivoRequest;
import mx.santander.h2h.monitoreo.model.response.ArchivoGeneralResponse;
import mx.santander.h2h.monitoreo.model.response.ArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.NivelArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ProdArchResponse;

/**
 * Clase generada para IArchivoTrackingBService.
 *
 * @autor FSW
 * @modifico C320868
 */
public interface IArchivoTrackingBService {
	
	/**
	 * Obtener detalle archivos.
	 *
	 * @param codCliente para cod cliente
	 * @param page para page
	 * @return el archivo general response
	 */
	ArchivoGeneralResponse obtenerDetalleArchivos(String codCliente, Pageable page);
    
    /**
     * Consulta traking nivel archivo.
     *
     * @param nivelArchivo para nivel archivo
     * @return el nivel archivo response
     */
    NivelArchivoResponse consultaTrakingNivelArchivo(NivelArchivoRequest nivelArchivo);
    
    /**
     * Obtener conteo archivos nivel archivo.
     *
     * @param fecha para fecha
     * @param codigoCliente para codigo cliente
     * @return el archivo response
     */
    ArchivoResponse obtenerConteoArchivosNivelArchivo(String fecha, String codigoCliente);
    
    /**
     * Obtener detalle archivos nivel archivo.
     *
     * @param nivelArchivo para nivel archivo
     * @param page para page
     * @return el map
     */
    Map<String, Object> obtenerDetalleArchivosNivelArchivo(NivelArchivoRequest nivelArchivo, Pageable page);
    
    /**
     * Obtener list detalle archivos nivel archivo.
     *
     * @param nivelArchivo para nivel archivo
     * @return el list
     */
    List<ProdArchResponse> obtenerListDetalleArchivosNivelArchivo(NivelArchivoRequest nivelArchivo);
    
    /**
     * Metodo Getter para reportXls.
     *
     * @param nivelArchivo para nivel archivo
     * @param usuario para usuario
     * @return reportXls report xls
     */
    ReportResponse getReportXls(NivelArchivoRequest nivelArchivo, String usuario);

}
