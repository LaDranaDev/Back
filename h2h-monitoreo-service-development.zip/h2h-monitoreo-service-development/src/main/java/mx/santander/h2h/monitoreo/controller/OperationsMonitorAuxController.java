package mx.santander.h2h.monitoreo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import mx.santander.h2h.monitoreo.constants.RoutesConstant;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.GeneralResponse;
import mx.santander.h2h.monitoreo.service.IOperationsMonitorAuxService;

/**
 * API para el Monitor de Operaciones
 *
 * @author Omar Rosas
 * @since 07/07/2023
 */
@Validated
@RestController
@RequestMapping(RoutesConstant.PATH_MONITOR_OPERACIONES)
public class OperationsMonitorAuxController {

	@Autowired
	private IOperationsMonitorAuxService service;

	/**
	 * API POST - Endpoint para generar el Xml de la consulta de operaciones y
	 * enviarlo a Sterling
	 *
	 * @param request Datos de la consulta de operaciones.
	 * @return DTO con los datos del reporte.
	 */
	@Operation(summary = "Endpoint para generar el Xml de la consulta de operaciones y enviarlo a Sterling.")
	@PostMapping(path = "/generaxml")
	public ResponseEntity<GeneralResponse> generaXmlOperaciones(
			@Valid
			@RequestBody OperationsMonitorQueryRequest request) {
		return ResponseEntity.ok(service.generaXmlOperaciones(request));
	}
	
	/**
	 * API POST - Endpoint para generar el Xml de la consulta de operaciones y
	 * enviarlo a Sterling para la exportacion
	 *
	 * @param request Datos de la consulta de operaciones.
	 * @return DTO con los datos del reporte.
	 */
	@Operation(summary = "Endpoint para generar el Xml de la consulta de operaciones y enviarlos a Sterling")
	@PostMapping(path = "/generaxmlExp")
	public ResponseEntity<GeneralResponse> generaXmlOperacionesExport(
			@Valid
			@RequestBody OperationsMonitorQueryRequest request){
		return ResponseEntity.ok(service.generaXmlOperacionesExp(request));
	}

}
