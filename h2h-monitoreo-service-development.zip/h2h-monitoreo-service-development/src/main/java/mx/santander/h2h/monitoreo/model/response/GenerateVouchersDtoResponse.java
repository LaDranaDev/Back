/**
 * 
 */
package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Descripción: DTO utilizado para almacenar las respuestas de los DAO de la
 * funcionalidad: Generación de comprobantes formato CDMX
 * GenerateVouchersDtoResponse.java
 * 
 * @author sbautish
 * @version 1.0 TCS Creación de GenerateVouchersDtoResponse.java
 *
 */
@Getter
@Setter
@ToString
public class GenerateVouchersDtoResponse implements Serializable {

	/**
	 * Atributo que representa la variable serialVersionUID del tipo long
	 * 
	 */
	private static final long serialVersionUID = -8108475212113889739L;

	/** Atributo que representa la variable importeTotal del tipo String */
	private String importeTotal;

	/** Atributo que representa la variable conceptoValor del tipo String */
	private String conceptoValor;

	/**
	 * Atributo que representa la variable listaOperaciones del tipo
	 * ArrayList<RespuestaMonitorOperacionesDTO>
	 */
	private List<OperationsMonitorQueryResponse> listaOperaciones;

	/**
	 * Atributo que representa la variable parametrosAdicionalesComprobante del tipo
	 * ArrayList<String>
	 */
	private List<String> parametrosAdicionalesComprobante;

	/**
	 * Atributo que representa la variable listaTipoPago del tipo
	 * ArrayList<SelectComboDTO>
	 */
	private List<SelectComboDTO> listaTipoPago;

	/** Atributo que representa la variable totalOperaciones del tipo String */
	private String totalOperaciones;

	/** Atributo que representa la variable totalArchivos del tipo String */
	private String totalArchivos;

	/**
	 * Atributo que representa la variable cdmxBean del tipo
	 * BeanSolicitudComprobante
	 */
	private VoucherRequestDto cdmxBean;

	/** Atributo que representa la variable msgError del tipo String */
	private String msgError;

	/** Atributo que representa la variable codError del tipo String */
	private String codError;

	public GenerateVouchersDtoResponse() {
		this.cdmxBean = new VoucherRequestDto();
	}

}
