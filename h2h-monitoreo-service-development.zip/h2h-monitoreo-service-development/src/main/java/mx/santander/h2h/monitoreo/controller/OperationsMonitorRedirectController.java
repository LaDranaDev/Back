package mx.santander.h2h.monitoreo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.constraints.Pattern;
import mx.santander.h2h.monitoreo.constants.RoutesConstant;
import mx.santander.h2h.monitoreo.model.request.OperationsDetailRoutesResponse;
import mx.santander.h2h.monitoreo.service.IOperationsMonitorRedirectService;


/**
 * OperationsMonitorRedirect.
 * Define las operaciones de enrutamiento para mostrar el detalle de las operaciones.
 *
 * @author Jesus Soto Aguilar
 * @since 07/07/2023
 */
@RestController
@RequestMapping(RoutesConstant.PATH_MONITOR_OPERACIONES)
public class OperationsMonitorRedirectController {

    /**
     * Servicio que realiza el enrutamiento a la vista de detalle.
     */
    @Autowired
    private IOperationsMonitorRedirectService operationsMonitorRedirectService;

    /**
     * Obtiene el nombre de la vista en donde se mostrara el detalle de las operaciones.
     * @param idProducto identificador del producto
     * @return identificador de la vista
     */
    @GetMapping(path = "/detalle/{idProducto}")
    @Operation(description = "Obtiene el nombre de la vista en donde se mostrara el detalle de las operaciones")
    public ResponseEntity<OperationsDetailRoutesResponse> getRutaDetalleOperacionesProducto(
    		@Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
    		@PathVariable String idProducto) {
        OperationsDetailRoutesResponse response = new OperationsDetailRoutesResponse();
        response.setRuta(operationsMonitorRedirectService.getNameRutaDetalle(idProducto));
        return ResponseEntity.ok(response);
    }
}
