package mx.santander.h2h.monitoreo.service;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.constants.ReportConstants;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.report.request.MonitorSaldosReportRequest;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.MonitorSaldosRequest;
import mx.santander.h2h.monitoreo.model.response.MonitorSaldosResponse;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * MonitorSaldosReportService.
 * Define los metodos de negocio para generar el reporte de saldos reintentos.
 *
 * @author Jesus Soto Aguilar
 * @since 20/04/2023
 */
@Slf4j
@Service
public class MonitorSaldosReportService implements IMonitorSaldosReportService{

    /**
     * Servicio de servicio para obtener los saldos reintentos.
     */
    @Autowired
    private IMonitorSaldosService monitorSaldosService;

    @Autowired
    private IProductService productService;

    /**
     * Servicio para generar el reporte de acuerdo al formato especificado.
     */
    @Autowired
    private IJasperReportService jasperReportService;

    /**
     * Genera el reporte de los saldos reintentos en formato xlsx.
     *
     * @param request Objeto con los datos para generar el reporte
     * @return Objeto con los datos del reporte en base 64
     */
    @Override
    public ReportResponse getReportSaldosReintentos(MonitorSaldosReportRequest request) {
        Map<String, Object> reportParams = new HashMap<>();
        setParametrosTitulo(reportParams, request);
        setParametrosConsulta(reportParams, request);

        List<MonitorSaldosResponse> data = getData(request);
        setSubReport(reportParams, data);

        ReportResponse response = jasperReportService.getXls(ReportConstants.MONITOR_SALDOS_REPORT_XLSX, reportParams, Collections.emptyList());
        response.setName(new StringBuilder(ReportConstants.NOMBRE_REPORTE_MONITOR_SALDOS)
                .append(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy_HH_mm_ss"))).append(ReportConstants.XLSX_EXTENTION)
                .toString());
        return response;
    }


    /**
     * Agrega al modelo del reporte los datos del encabezado.
     *
     * @param reportParams Modelo con los parametros necesarios para la generacion del reporte
     * @param request Objeto con datos necesarios para la genracion del reporte
     */
    private void setParametrosTitulo(
            Map<String, Object> reportParams, MonitorSaldosReportRequest request){
        reportParams.put("lblHeaderTitulo", "MONITOR DE SALDOS");
        reportParams.put("usuario", request.getUsuario());

    }

    /**
     * Agrega al modelo del reporte la informacion la informacion referente a la consulta.
     *
     * @param reportParams Modelo con los parametros necesarios para la generacion del reporte
     * @param request Objeto con datos necesarios para la genracion del reporte
     */
    private void setParametrosConsulta(
            Map<String, Object> reportParams, MonitorSaldosReportRequest request){
        MonitorSaldosRequest monitorSaldosRequest = request.getMonitorSaldosRequest();
        reportParams.put("codigoCliente", monitorSaldosRequest.getCodigoCliente());
        reportParams.put("fechaInicio", monitorSaldosRequest.getFechaInicio());
        reportParams.put("fechaFin", monitorSaldosRequest.getFechaFin());
        reportParams.put("archivoProcesado", monitorSaldosRequest.getNombreArchivo());
        reportParams.put("producto", monitorSaldosRequest.getClaveProducto().isEmpty()?
                null:productService.getProductoByClave(monitorSaldosRequest.getClaveProducto()).getDescProducto());
    }

    /**
     * Obteiene los datos de los saldos reintentos que se mostraran en el reporte.
     *
     * @param request Objeto con datos necesarios para la generacion del reporte
     * @return Lista con los saldos reintentos
     */
    private List<MonitorSaldosResponse> getData(MonitorSaldosReportRequest request){
        return monitorSaldosService.getSaldosReintentosCliente(request.getMonitorSaldosRequest());
    }

    /**
     * Agrega al modelo del reporte el subreporte en el que se mostraran los saldos reintentos.
     *
     * @param reportParams Modelo con los parametros necesarios para la generacion del reporte
     * @param data Lista con los saldos reintentos
     */
    private void setSubReport(Map<String, Object> reportParams, List<MonitorSaldosResponse> data) {
        StringBuilder subReportPath = new StringBuilder(ReportConstants.REPORTS_FOLDER)
                .append(ReportConstants.MONITOR_SALDOS_SUBREPORT_XLSX);
        ClassPathResource dirSubRepor = new ClassPathResource(subReportPath.toString());
        InputStream jasperStream;
        try {
            jasperStream = dirSubRepor.getInputStream();
            JasperReport jasperReport = (JasperReport) JRLoader.loadObject(jasperStream);
            reportParams.put("rutaSubReporte", jasperReport);
            reportParams.put("listaSaldos", data);
        } catch (IOException | JRException e) {
            log.debug(e.getMessage());
            throw new BusinessException(e.getMessage());
        }
    }
}
