/**
 * 
 */
package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Descripción: Bean utilizado para almacenar los atributos requeridos por la
 * funcionalidad de generacion de comprobantes en formato CDMX
 * VoucherRequestDto.java
 * 
 * @author sbautish
 *
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
public class VoucherRequestDto implements Serializable {

	/**
	 * Atributo que representa la variable serialVersionUID del tipo long
	 */
	private static final long serialVersionUID = -7481340936331348916L;

	/** Atributo que representa la variable lineaCaptura del tipo String */
	@Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Linea de Captura no valida")
	private String lineaCaptura;

	/** Atributo que representa la variable canalOperacion del tipo int */
	private Integer canalOperacion;

	/** Atributo que representa la variable fecha del tipo String */
	@Pattern(regexp = "(((\\d{2})|(\\d{4}))([-/])\\d{2}([-/])((\\d{2})|(\\d{4})))( (\\d{2}:\\d{2}:\\d{2})?)?", message = "Fecha No Valida")
	@Size(min = 0, max = 20, message = "Fecha erronea")
	private String fecha;

	/** Atributo que representa la variable importe del tipo double */
	private Double importe;

	/** Atributo que representa la variable referencia del tipo String */
	@Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
	private String referencia;

	/** Atributo que representa la variable base64 del tipo String */
	private String base64;

	/** Atributo que representa la variable idReg del tipo String */
	@Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
	private String idReg;

	/** Atributo que representa la variable tramaAdicionalesEntrada del tipo String */
	private String tramaAdicionalesEntrada;

}
