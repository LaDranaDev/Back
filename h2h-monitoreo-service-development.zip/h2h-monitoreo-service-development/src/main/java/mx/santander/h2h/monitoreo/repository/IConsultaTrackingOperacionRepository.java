package mx.santander.h2h.monitoreo.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.model.response.OperacionArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ResultTrackingResponse;

public interface IConsultaTrackingOperacionRepository {
	
	ResultTrackingResponse obtenerCatalogoEstatus(String tipoStatus);
	
	ResultTrackingResponse obtenerConteoArchivo(String codCliente, Integer idArchivo, Integer idProducto, Integer idEstatus);
	
	Page<OperacionArchivoResponse> obtenerDetalleArchivo(Pageable page, Integer idArchivo, Integer idProducto, Integer idEstatus);
	
	List<OperacionArchivoResponse> obtenerListDetalleArchivo(Integer idArchivo, Integer idProducto, Integer idEstatus);
}
