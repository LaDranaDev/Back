package mx.santander.h2h.monitoreo.repository;

import java.util.Map;

import org.springframework.stereotype.Repository;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.constants.MonitorOperacionesConstants;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.util.MonitorOperacionPrivUtil;
import mx.santander.h2h.monitoreo.util.UtilData;
import mx.santander.h2h.monitoreo.util.UtilMapeoData;
import mx.santander.h2h.monitoreo.util.UtilMonitorOperacionesSPID;


@Slf4j
@Repository
public class MonitorOperacionesRepository implements IMonitorOperacionesRepository  {

	public static final String EMPTY = "";
	
	
	/**
	 * Prepara la consulta de operaciones
	 * 
	 * @param consultaOperaciones - Parametros de la consulta
	 * @return String Consulta a realizar
	 */
	protected static String preparaConsultaOperaciones (
			OperationsMonitorQueryRequest consultaOperaciones, 
			final StringBuilder querys, Map<String, Object> params
	) {
		log.debug("Preparando consulta de operaciones");
		final StringBuilder query = new StringBuilder();
		// llamamos al metodo para limpiar los campos
		consultaOperaciones = UtilMapeoData.cleanCamposByOperation(consultaOperaciones);
		
		final boolean ordenPago = OperationsMonitorEntityManagerHelper3Repository.isOrdenPago(consultaOperaciones);
		final boolean altaMasivaEmpleados = OperationsMonitorEntityManagerHelper3Repository.isAltaMasivaEmpleados(consultaOperaciones);
		final boolean pif = UtilData.isPif(consultaOperaciones.getIdProducto());
		final boolean ti = OperationsMonitorEntityManagerHelper3Repository.isTI(consultaOperaciones);
		final boolean pagoDirecto = UtilData.isPagoDirecto(consultaOperaciones.getIdProducto()); //PGODIRECT
		final boolean centroPagoMit = OperationsMonitorEntityManagerHelper3Repository.isCentroPagoMit(consultaOperaciones.getIdProducto());
		
		if (OperationsMonitorEntityManagerHelper3Repository.isDateToday(consultaOperaciones.getFechaInicial())) {
			log.info("*****MIGAJA  A*****");
			query.append(MonitorOperacionesConstants.SEL_PROD);
			if(pif){
				query.append(MonitorOperacionPrivUtil.getselectImpFed(true, consultaOperaciones.getIdProducto()));
			}else if(ti){
				query.append(OperationsMonitorEntityManagerHelper1Repository.getselectTransfInter(true, query, consultaOperaciones.getIdProducto()));
			}else if(UtilMonitorOperacionesSPID.esProductoActivo(consultaOperaciones.getIdProducto())){
				query.append(UtilMonitorOperacionesSPID.getselectSPID( query, true));
			} else if (pagoDirecto) {
				query.append(OperationsMonitorEntityManagerHelper2Repository.getSelectConsultaOperacionesPagoDirecto(query, true)); //PGODIRECT
			} else if (centroPagoMit) {
				query.append(OperationsMonitorEntityManagerHelper1Repository.getSelectCentroPagoMit(query, true)); 
			} else{
				query.append(ordenPago ? MonitorOperacionPrivUtil.getSelectConsultaOperacionesOrdenPago(true, consultaOperaciones.getIdProducto()) : 
				(altaMasivaEmpleados ? MonitorOperacionPrivUtil.getQueryConsOpAltaMasiva(true) 
						: MonitorOperacionPrivUtil.getQueryConsOperaciones(true,consultaOperaciones, params)));
			}
			query.append(MonitorOperacionesConstants.TABLA_PROD)
			.append(MonitorOperacionPrivUtil.getWhereConsultaOperaciones(consultaOperaciones, false, params))
			.append(" ORDER BY PROD.ID_REG DESC ");
		} else {	
			log.info("*****MIGAJA  B ii*****");
			query
				.append(MonitorOperacionesConstants.SEL_PROD)
				.append(MonitorOperacionesConstants.SEL_PROD);
			if(pif){
				query.append(MonitorOperacionPrivUtil.getselectImpFed(false, consultaOperaciones.getIdProducto()));
			}else if(ti){
				query.append(OperationsMonitorEntityManagerHelper1Repository.getselectTransfInter(false, query, consultaOperaciones.getIdProducto()));
			}else if(UtilMonitorOperacionesSPID.esProductoActivo(consultaOperaciones.getIdProducto())){
				query.append(UtilMonitorOperacionesSPID.getselectSPID( query, false));
			} else if (pagoDirecto) {
				query.append(OperationsMonitorEntityManagerHelper2Repository.getSelectConsultaOperacionesPagoDirecto(query, false)); //PGODIRECT
			} else if (centroPagoMit) {
				query.append(OperationsMonitorEntityManagerHelper1Repository.getSelectCentroPagoMit(query, false)); 
			} else{
				query.append(ordenPago ? MonitorOperacionPrivUtil.getSelectConsultaOperacionesOrdenPago(false, consultaOperaciones.getIdProducto()) : 
				(altaMasivaEmpleados ? MonitorOperacionPrivUtil.getQueryConsOpAltaMasiva(false) 
						: MonitorOperacionPrivUtil.getQueryConsOperaciones(false,consultaOperaciones, params)));
			}
			query.append(MonitorOperacionesConstants.TABLA_PROD)
				.append(MonitorOperacionPrivUtil.getWhereConsultaOperaciones(consultaOperaciones, false, params))
				.append(" UNION ALL ")
				.append(MonitorOperacionesConstants.SEL_PROD);
		
			if(pif){
				query.append(MonitorOperacionPrivUtil.getselectImpFed(true, consultaOperaciones.getIdProducto()));
			}else if(ti){
				query.append(OperationsMonitorEntityManagerHelper1Repository.getselectTransfInter(true, query, consultaOperaciones.getIdProducto()));
			}else if(UtilMonitorOperacionesSPID.esProductoActivo(consultaOperaciones.getIdProducto())){
				query.append(UtilMonitorOperacionesSPID.getselectSPID( query, true));
			} else if (pagoDirecto) {
				query.append(OperationsMonitorEntityManagerHelper2Repository.getSelectConsultaOperacionesPagoDirecto(query, true)); //PGODIRECT
			} else if (centroPagoMit) {
				query.append(OperationsMonitorEntityManagerHelper1Repository.getSelectCentroPagoMit(query, true)); 
			} else{
				query.append(ordenPago ? MonitorOperacionPrivUtil.getSelectConsultaOperacionesOrdenPago(true, consultaOperaciones.getIdProducto()) : 
				(altaMasivaEmpleados ? MonitorOperacionPrivUtil.getQueryConsOpAltaMasiva(true) 
						: MonitorOperacionPrivUtil.getQueryConsOperaciones(true,consultaOperaciones, params)));
			}	
			query.append(MonitorOperacionesConstants.TABLA_PROD)
			.append(MonitorOperacionPrivUtil.getWhereConsultaOperaciones(consultaOperaciones, false, params))
			.append(MonitorOperacionesConstants.TABLA_PROD)	
			.append(" ORDER BY PROD.ID_REG DESC ");
		}
		
		log.info("Consulta a realizar: " + query.toString());
		return query.toString();
	}
	
	
	/**
	 * Obtiene los productos a exportar.
	 *
	 * @param consultaOperaciones parametros de la consulta operaciones
	 * @return String consulta para identicar los productos
	 */
	protected static String getViews(
		OperationsMonitorQueryRequest consultaOperaciones, 
		final StringBuilder query, 
		Map<String, Object> params
	) {
		// llamamos al metodo para limpiar los campos
		consultaOperaciones = UtilMapeoData.cleanCamposByOperation(consultaOperaciones);
		
		final boolean ordenPago =  OperationsMonitorEntityManagerHelper3Repository.isOrdenPago(consultaOperaciones);
		final boolean altaMasivaEmpleados =  OperationsMonitorEntityManagerHelper3Repository.isAltaMasivaEmpleados(consultaOperaciones);
		final boolean pif = UtilData.isPif(consultaOperaciones.getIdProducto());
		final boolean ti = OperationsMonitorEntityManagerHelper3Repository.isTI(consultaOperaciones);
		final boolean pagoDirecto =  UtilData.isPagoDirecto(consultaOperaciones.getIdProducto()); //PGODIRECT
		final boolean centroPagoMit =  OperationsMonitorEntityManagerHelper3Repository.isCentroPagoMit(consultaOperaciones.getIdProducto());
		
		if (OperationsMonitorEntityManagerHelper3Repository.isDateToday(consultaOperaciones.getFechaInicial())){
			log.info("*****MIGAJA  I*****");
			query.append("SELECT  DISTINCT PROD.VIST_PROD  FROM (")
				.append(MonitorOperacionesConstants.SEL_PROD);
			if(pif){
				query.append(MonitorOperacionPrivUtil.getselectImpFed(true, consultaOperaciones.getIdProducto()));
			}else if(ti){
				query.append(OperationsMonitorEntityManagerHelper1Repository.getselectTransfInter(true, query, consultaOperaciones.getIdProducto()));
			}else if(UtilMonitorOperacionesSPID.esProductoActivo(consultaOperaciones.getIdProducto())){
				query.append(UtilMonitorOperacionesSPID.getselectSPID( query, true));
			} else if (pagoDirecto) {
				query.append(OperationsMonitorEntityManagerHelper2Repository.getSelectConsultaOperacionesPagoDirecto(query, true)); //PGODIRECT
			} else if (centroPagoMit) {
				query.append(OperationsMonitorEntityManagerHelper1Repository.getSelectCentroPagoMit(query, true)); 
			} else{
				query.append(ordenPago ? MonitorOperacionPrivUtil.getSelectConsultaOperacionesOrdenPago(true, consultaOperaciones.getIdProducto()) : 
				(altaMasivaEmpleados ? MonitorOperacionPrivUtil.getQueryConsOpAltaMasiva(true) 
						: MonitorOperacionPrivUtil.getQueryConsOperaciones(true,consultaOperaciones, params)));
			}
			query.append(MonitorOperacionesConstants.TABLA_PROD)
				.append(MonitorOperacionPrivUtil.getWhereConsultaOperaciones(consultaOperaciones, false, params))
				.append(MonitorOperacionesConstants.TABLA_PROD);
		} else {
			log.info("*****MIGAJA  J ii *****");
			query
				.append("SELECT  DISTINCT PROD.VIST_PROD  FROM (")
				.append(MonitorOperacionesConstants.SEL_PROD);
				if(pif){
					query.append(MonitorOperacionPrivUtil.getselectImpFed(false,consultaOperaciones.getIdProducto()));
				}else if(ti){
					query.append(OperationsMonitorEntityManagerHelper1Repository.getselectTransfInter(false, query, consultaOperaciones.getIdProducto()));
				}else if(UtilMonitorOperacionesSPID.esProductoActivo(consultaOperaciones.getIdProducto())){
					query.append(UtilMonitorOperacionesSPID.getselectSPID(query, false));
				}else if (pagoDirecto) {
					query.append(OperationsMonitorEntityManagerHelper2Repository.getSelectConsultaOperacionesPagoDirecto(query, false)); //PGODIRECT
				}else if (centroPagoMit) {
					query.append(OperationsMonitorEntityManagerHelper1Repository.getSelectCentroPagoMit(query, false));
				}else{
					query.append(ordenPago ? MonitorOperacionPrivUtil.getSelectConsultaOperacionesOrdenPago(false, consultaOperaciones.getIdProducto()) :
					(altaMasivaEmpleados ? MonitorOperacionPrivUtil.getQueryConsOpAltaMasiva(false) : MonitorOperacionPrivUtil.getQueryConsOperaciones(false, consultaOperaciones, params)));
				}
				log.info("1er WHERE");
				query.append(MonitorOperacionesConstants.TABLA_PROD)
					.append(MonitorOperacionPrivUtil.getWhereConsultaOperaciones(consultaOperaciones, false, params));
				log.info("UNION");
				query.append(" UNION ALL  ");
				query.append(MonitorOperacionesConstants.SEL_PROD);
				if(pif){
					query.append(MonitorOperacionPrivUtil.getselectImpFed(true,consultaOperaciones.getIdProducto()));
				}else if(ti){
					query.append(OperationsMonitorEntityManagerHelper1Repository.getselectTransfInter(true, query, consultaOperaciones.getIdProducto()));
				}else if(UtilMonitorOperacionesSPID.esProductoActivo(consultaOperaciones.getIdProducto())){
					query.append(UtilMonitorOperacionesSPID.getselectSPID(query, true));
				}else if (pagoDirecto) {
					query.append(OperationsMonitorEntityManagerHelper2Repository.getSelectConsultaOperacionesPagoDirecto(query, true)); //PGODIRECT
				}else if (centroPagoMit) {
					query.append(OperationsMonitorEntityManagerHelper1Repository.getSelectCentroPagoMit(query, true));
				}else{
					query.append(ordenPago ? MonitorOperacionPrivUtil.getSelectConsultaOperacionesOrdenPago(true, consultaOperaciones.getIdProducto()) :
					(altaMasivaEmpleados ? MonitorOperacionPrivUtil.getQueryConsOpAltaMasiva(true) : MonitorOperacionPrivUtil.getQueryConsOperaciones(true, consultaOperaciones, params)));
				}
				
				log.info("2DO WHERE");
				query.append(MonitorOperacionesConstants.TABLA_PROD)
					.append(MonitorOperacionPrivUtil.getWhereConsultaOperaciones(consultaOperaciones, false, params))
					.append(MonitorOperacionesConstants.TABLA_PROD);
		}
		return query.toString();
	}
	
	
	/**
	 * Genera la consulta de las operaciones de orden de pago
	 * 
	 * @param delDia indica si se usan las tablas del diario
	 * @return String con la consulta
	 */
	protected static void getCorreosEnvQuery(
		OperationsMonitorQueryRequest consultaOperaciones,
		final StringBuilder query, Map<String, Object> params
	) {
		// llamamos al metodo para limpiar los campos
		consultaOperaciones = UtilMapeoData.cleanCamposByOperation(consultaOperaciones);
		
		final boolean ordenPago =  OperationsMonitorEntityManagerHelper3Repository.isOrdenPago(consultaOperaciones);
		final boolean altaMasivaEmpleados =  OperationsMonitorEntityManagerHelper3Repository.isAltaMasivaEmpleados(consultaOperaciones);
		if (OperationsMonitorEntityManagerHelper3Repository.isDateToday(consultaOperaciones.getFechaInicial())){
			log.info("*****MIGAJA  E*****");
			query
				.append("SELECT NVL(SUM(PROD.NUM_EMAIL),0) TOTAL FROM (")
				.append(MonitorOperacionesConstants.SEL_PROD)
				.append(ordenPago ? MonitorOperacionPrivUtil.getSelectConsultaOperacionesOrdenPago(true, consultaOperaciones.getIdProducto()) : 
					(altaMasivaEmpleados ? MonitorOperacionPrivUtil.getQueryConsOpAltaMasiva(true) : MonitorOperacionPrivUtil.getQueryConsOperaciones(true, consultaOperaciones, params)))
				.append(MonitorOperacionesConstants.TABLA_PROD)
				.append(MonitorOperacionPrivUtil.getWhereConsultaOperaciones(consultaOperaciones, false, params))
				.append(MonitorOperacionesConstants.TABLA_PROD); 
		} else {
			log.info("*****MIGAJA  F ii*****");
			query
				.append("SELECT NVL(SUM(PROD.NUM_EMAIL),0) TOTAL FROM (")
				.append(MonitorOperacionesConstants.SEL_PROD)
				.append(ordenPago ? MonitorOperacionPrivUtil.getSelectConsultaOperacionesOrdenPago(false, consultaOperaciones.getIdProducto()) : 
					(altaMasivaEmpleados ? MonitorOperacionPrivUtil.getQueryConsOpAltaMasiva(false) : MonitorOperacionPrivUtil.getQueryConsOperaciones(false, consultaOperaciones, params)))
				.append(MonitorOperacionesConstants.TABLA_PROD)
				.append(MonitorOperacionPrivUtil.getWhereConsultaOperaciones(consultaOperaciones, false, params))
				.append("UNION ALL  ")
				.append(MonitorOperacionesConstants.SEL_PROD)
				.append(ordenPago ? MonitorOperacionPrivUtil.getSelectConsultaOperacionesOrdenPago(true, consultaOperaciones.getIdProducto()) : 
					(altaMasivaEmpleados ? MonitorOperacionPrivUtil.getQueryConsOpAltaMasiva(true) : MonitorOperacionPrivUtil.getQueryConsOperaciones(true, consultaOperaciones, params)))
				.append(MonitorOperacionesConstants.TABLA_PROD)
				.append(MonitorOperacionPrivUtil.getWhereConsultaOperaciones(consultaOperaciones, false, params))
				.append(MonitorOperacionesConstants.TABLA_PROD); 
		}
	}
	
	
	/**
	 *  Genera laconsulta para la conteo de archivos
	 *  
	 * @param consultaOperaciones opciones para la consulta.
	 * @return String de la cosnulta de coenteo de archivos
	 */
	protected static String getCountArchivos(
		OperationsMonitorQueryRequest consultaOperaciones,
		final StringBuilder querys, Map<String, Object> params
	) {
		final StringBuilder query = new StringBuilder();
		log.debug("Preparando consulta de operaciones - numero de archivos");
		// llamamos al metodo para limpiar los campos
		consultaOperaciones = UtilMapeoData.cleanCamposByOperation(consultaOperaciones);
		
		final boolean ordenPago =  OperationsMonitorEntityManagerHelper3Repository.isOrdenPago(consultaOperaciones);
		final boolean altaMasivaEmpleados =  OperationsMonitorEntityManagerHelper3Repository.isAltaMasivaEmpleados(consultaOperaciones);
		
		if (OperationsMonitorEntityManagerHelper3Repository.isDateToday(consultaOperaciones.getFechaInicial())){
			log.info("*****MIGAJA  G*****");
			query
				.append("SELECT DISTINCT PROD.NOMBRE_ARCH FROM (")
				.append(MonitorOperacionesConstants.SEL_PROD)
				.append(ordenPago ? MonitorOperacionPrivUtil.getSelectConsultaOperacionesOrdenPago(true, consultaOperaciones.getIdProducto()) :
					(altaMasivaEmpleados ? MonitorOperacionPrivUtil.getQueryConsOpAltaMasiva(true) : MonitorOperacionPrivUtil.getQueryConsOperaciones(true,consultaOperaciones, params)))
				.append(MonitorOperacionesConstants.TABLA_PROD)
				.append(MonitorOperacionPrivUtil.getWhereConsultaOperaciones(consultaOperaciones, false, params))
				.append(MonitorOperacionesConstants.TABLA_PROD); 
		} else {
			log.info("*****MIGAJA  H ii*****");
			query
				.append("SELECT DISTINCT PROD.NOMBRE_ARCH FROM (")
				.append(MonitorOperacionesConstants.SEL_PROD)
				.append(ordenPago ? MonitorOperacionPrivUtil.getSelectConsultaOperacionesOrdenPago(false, consultaOperaciones.getIdProducto()) :
					(altaMasivaEmpleados ? MonitorOperacionPrivUtil.getQueryConsOpAltaMasiva(false) : MonitorOperacionPrivUtil.getQueryConsOperaciones(false,consultaOperaciones, params)))
				.append(MonitorOperacionesConstants.TABLA_PROD)
				.append(MonitorOperacionPrivUtil.getWhereConsultaOperaciones(consultaOperaciones, false, params))
				.append("UNION ALL  ")
				.append(MonitorOperacionesConstants.SEL_PROD)
				.append(ordenPago ? MonitorOperacionPrivUtil.getSelectConsultaOperacionesOrdenPago(true, consultaOperaciones.getIdProducto()) : 
					(altaMasivaEmpleados ? MonitorOperacionPrivUtil.getQueryConsOpAltaMasiva(true) : MonitorOperacionPrivUtil.getQueryConsOperaciones(true,consultaOperaciones, params)))
				.append(MonitorOperacionesConstants.TABLA_PROD)
				.append(MonitorOperacionPrivUtil.getWhereConsultaOperaciones(consultaOperaciones, false, params))
				.append(MonitorOperacionesConstants.TABLA_PROD); 
		}
		return query.toString();
	}
	
	
	/**
	 * Obtiene importe global query.
	 *
	 * @param consultaOperaciones el parametro consulta operaciones
	 * @return  importe global query
	 */
	protected static void getImporteGlobalQuery(
			OperationsMonitorQueryRequest consultaOperaciones,
			final StringBuilder query, Map<String, Object> params
		) {
		// llamamos al metodo para limpiar los campos
		consultaOperaciones = UtilMapeoData.cleanCamposByOperation(consultaOperaciones);
		
		final boolean ordenPago =  OperationsMonitorEntityManagerHelper3Repository.isOrdenPago(consultaOperaciones);
		final boolean altaMasivaEmpleados =  OperationsMonitorEntityManagerHelper3Repository.isAltaMasivaEmpleados(consultaOperaciones);
		if (OperationsMonitorEntityManagerHelper3Repository.isDateToday(consultaOperaciones.getFechaInicial())){
			log.info("*****MIGAJA  C*****");
			query
				.append("SELECT NVL(SUM(CASE WHEN PROD.IMPORTE >= 0 THEN PROD.IMPORTE ELSE 0 END),0) AS IMPORTE_GLOBAL FROM (")
				.append(MonitorOperacionesConstants.SEL_PROD)
				.append(ordenPago ? MonitorOperacionPrivUtil.getSelectConsultaOperacionesOrdenPago(true, consultaOperaciones.getIdProducto()) : 
					(altaMasivaEmpleados ? MonitorOperacionPrivUtil.getQueryConsOpAltaMasiva(true) : MonitorOperacionPrivUtil.getQueryConsOperaciones(true, consultaOperaciones, params)))
				.append(MonitorOperacionesConstants.TABLA_PROD)
				.append(MonitorOperacionPrivUtil.getWhereConsultaOperaciones(consultaOperaciones, false, params))
				.append(MonitorOperacionesConstants.TABLA_PROD); 
		} else {
			log.info("*****MIGAJA  D ii****");
			query
				.append("SELECT NVL(SUM(CASE WHEN PROD.IMPORTE >= 0 THEN PROD.IMPORTE ELSE 0 END),0) AS IMPORTE_GLOBAL FROM (")
				.append(MonitorOperacionesConstants.SEL_PROD)
				.append(ordenPago ? MonitorOperacionPrivUtil.getSelectConsultaOperacionesOrdenPago(false, consultaOperaciones.getIdProducto()) :
					(altaMasivaEmpleados ? MonitorOperacionPrivUtil.getQueryConsOpAltaMasiva(false) : MonitorOperacionPrivUtil.getQueryConsOperaciones(false, consultaOperaciones, params)))
				.append(MonitorOperacionesConstants.TABLA_PROD)
				.append(MonitorOperacionPrivUtil.getWhereConsultaOperaciones(consultaOperaciones, false, params))
				.append(" UNION ALL ")
				.append(MonitorOperacionesConstants.SEL_PROD)
				.append(ordenPago ? MonitorOperacionPrivUtil.getSelectConsultaOperacionesOrdenPago(true, consultaOperaciones.getIdProducto()) : 
					(altaMasivaEmpleados ? MonitorOperacionPrivUtil.getQueryConsOpAltaMasiva(true) : MonitorOperacionPrivUtil.getQueryConsOperaciones(true, consultaOperaciones, params)))
				.append(MonitorOperacionesConstants.TABLA_PROD)
				.append(MonitorOperacionPrivUtil.getWhereConsultaOperaciones(consultaOperaciones, false, params))
				.append(MonitorOperacionesConstants.TABLA_PROD); 
		}
	}
	
}
