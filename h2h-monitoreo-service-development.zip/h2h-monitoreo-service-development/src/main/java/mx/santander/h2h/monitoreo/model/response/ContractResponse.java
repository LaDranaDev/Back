package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * DTO para la respuesta de obtener contrato
 * 
 * @author Felipe Cazarez
 * @since 12/07/2022
 */
@Getter
@Setter
@NoArgsConstructor
public class ContractResponse implements Serializable{
	/**
	 * id serial 
	 */
	private static final long serialVersionUID = 3227869057450317672L;
	/**
	 * Numero de contrato asignado al cliente
	 */
	private String numeroContrato;
	/**
	 * Identificador del contrato
	 */
	private Integer idContrato;
	/**
	 * Certificado HSM.
	 */
	private String cveCertHSM;
	/**
	 * Periodo de Habilitacion de cuentas
	 */
	private Float periodoHabilitacion;
	/**
	 * Numero de dias de anticipacion para programar archivos
	 */
	private Integer diasProgramarArchivos;
	/**
	 * Bandera para indicar si se va a verificar la cuenta beneficiaria
	 */
	private String verificarCuentaBeneficiaria;
	/**
	 * Bandera para indicar si se va a utilizar la cuenta CLABE para Estado de
	 * Cuenta
	 */
	private String usarClabeParaEdoCta;
	/**
	 * Bandera para indicar si se va a utilizar cifras de control en SFG.
	 */
	private String usarCifrasControl;
	/**
	 * Bandera para indicar si esta permitido el cambio de producto (SPEI, TEF)
	 */
	private String bandCambioProd;
	/**
	 * Contiene los valores del cliente al que se esta dando de alta el contrato
	 */
	private CustomerResponse cliente;
	/**
	 * Cuenta Eje utilizada para el contrato
	 */
	private AccountResponse cuentaEje;
	/**
	 * Estado del contrato
	 */
	private CatalogStatusResponse estatus;

	/**
	 * Nombre o razon social
	 */
	private String nombreRazon;

	/**
	 * Lista de producto que se van a asignar al contrato
	 */
	private List<ProductEdoCtaResponse> productos;

	/**
	 * Lista de producto asignados actualmente al contrato
	 */
	private List<ProductEdoCtaResponse> productosOriginales;

	/**
	 * La propiedad bandActCont.
	 */
	private String bandActCont;
	/**
	 * bic.
	 */
	private String bic;
	/**
	 * messagePartner.
	 */
	private String messagePartner;
	/**
	 * tipoTransferencia.
	 */
	private String tipoTransferencia;
	/**
	 * Alias del contrato
	 */
	private String alias;
	/**
	 * back Confriming
	 */
	private String backConfirming;
}
