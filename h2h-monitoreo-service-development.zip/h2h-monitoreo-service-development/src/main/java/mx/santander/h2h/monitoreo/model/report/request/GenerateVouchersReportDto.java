package mx.santander.h2h.monitoreo.model.report.request;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;

@Getter
@Setter
@ToString
public class GenerateVouchersReportDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Atributo que representa la variable listaOperaciones del tipo
	 * ArrayList<RespuestaMonitorOperacionesDTO>
	 */
	private List<OperationsMonitorQueryResponse> listaOperaciones;

	/**
	 * Objeto de entrada de consulta de operaciones
	 */
	private OperationsMonitorQueryRequest consultaOperaciones;

}
