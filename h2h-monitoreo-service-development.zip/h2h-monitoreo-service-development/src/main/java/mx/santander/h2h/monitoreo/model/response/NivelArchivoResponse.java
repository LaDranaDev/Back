package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;

import org.springframework.data.domain.Page;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NivelArchivoResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 973258205740926581L;

	private String nombreCliente;
	
	private String codCliente;
	
	private String fecha;
	
	private ArchivoResponse beanArchivo;
	
	private ArchivoResponse beanArchivoDetalle;
	
	private Page<ProductoArchivoResponse> listBeanArchivo;
	
	private int estatus;
	
	private String nombreArchivo;
}
