package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Dto para los datos de salida de protocolo
 * 
 * @author Z483900
 *
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ProtocolResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4881323733545480191L;

	/**
	 * idProtocolo - 
	 */
	private int idProtocolo;

	/**
	 * nombre - 
	 */
	private String nombre;

	/**
	 * activo - estatus
	 */
	private String activo;

	/**
	 * parametrosGet - Lista de ParametersGetPutResponse
	 */
	private List<ParametersGetPutResponse> parametrosGet;

	/**
	 * parametrosPut - Lista de ParametersGetPutResponse
	 */
	private List<ParametersGetPutResponse> parametrosPut;

	/**
	 * nombreParametros - Lista de String
	 */
	private List<String> nombreParametros;

	/**
	 * idRegistro - 
	 */
	private int idRegistro;

	/**
	 * Agrega parametro GET
	 * 
	 * @param parametro almacena y valida el parametro
	 */
	public void agregarParametroGet(ParametersGetPutResponse parametro){

		if(this.parametrosGet == null){

			this.parametrosGet = new ArrayList<ParametersGetPutResponse>();
		}

		this.parametrosGet.add(parametro);
	}

	/**
	 * Agrega parametro PUT
	 * 
	 * @param parametro almacena y valida el parametro
	 */
	public void agregarParametroPut(ParametersGetPutResponse parametro){

		if(this.parametrosPut == null){

			this.parametrosPut = new ArrayList<ParametersGetPutResponse>();
		}

		this.parametrosPut.add(parametro);
	}

}
