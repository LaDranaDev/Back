package mx.santander.h2h.monitoreo.model.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.apache.commons.lang.StringUtils;

import java.io.Serializable;

/**
 * @author Daniel Ruiz
 * Bean para los datos de los comprobantes.
 */
@Getter
@Setter
@ToString
public class ComprobantesOperacionResponse implements Serializable {
    /** Serial id */
    private static final long serialVersionUID = 6580889376315141667L;

    /** Contrato.*/
    private String contrato;

    /** Canal.*/
    private String canal = StringUtils.EMPTY;

    /** RFC.*/
    private String rfc = StringUtils.EMPTY;

    /** Cuenta cargo.*/
    private String cuentaCargo = StringUtils.EMPTY;

    /** Titular.*/
    private String titular = StringUtils.EMPTY;

    /** Nombre o razon social.*/
    private String razonSocial = StringUtils.EMPTY;

    /** Cuenta abono.*/
    private String cuentaAbono = StringUtils.EMPTY;

    /** Beneficiario.*/
    private String beneficiario = StringUtils.EMPTY;

    /** Nombre de la persona autorizada.*/
    private String persAut = StringUtils.EMPTY;

    /** Clave del beneficiario.*/
    private String cveBenef = StringUtils.EMPTY;

    /** Importe.*/
    private String importe;

    /** Cocenpto pago.*/
    private String conceptoPago = StringUtils.EMPTY;

    /** Clave de rastreo.*/
    private String claveRastreo = StringUtils.EMPTY;

    /** Referencia interbancaria.*/
    private String refInterbancaria = StringUtils.EMPTY;

    /** Folio de la operacion.*/
    private Long folioOp;

    /** Tipo de operacion.*/
    private String tipoOper = StringUtils.EMPTY;

    /** Banco receptor o destino.*/
    private String banco = StringUtils.EMPTY;

    /** Estatus.*/
    private String estatus = StringUtils.EMPTY;

    /** Estatus Movimiento.*/
    private String estatusMov = StringUtils.EMPTY;

    /** Fecha vencimiento. */
    private String fechaVenci = StringUtils.EMPTY;

    /** Fecha operacion. */
    private String fechaOp = StringUtils.EMPTY;

    /** Fecha aplicacion. */
    private String fechaAplic = StringUtils.EMPTY;

    /** Clave del proveedor.*/
    private String cveProveedor = StringUtils.EMPTY;

    /** RFC del proveedor.*/
    private String rfcProveedor = StringUtils.EMPTY;

    /** Nombre del proveedor.*/
    private String nomProveedor = StringUtils.EMPTY;

    /** Tipo de documento.*/
    private String tipoDoc = StringUtils.EMPTY;

    /** Numero de documento.*/
    private String noDocu = StringUtils.EMPTY;

    /** Divisa.*/
    private String divisa = StringUtils.EMPTY;

    /** Forma Pago.*/
    private String formaAplic = StringUtils.EMPTY;

    /** Forma Pago.*/
    private String formaPago = StringUtils.EMPTY;

    /** Identifica si es Confirming.*/
    private boolean esConfirming;

    /** Identifica si es Orden Pago.*/
    private boolean esOrdenPago;

    /** Numero de Orden de Pago.*/
    private String numOrden = StringUtils.EMPTY;

    /** Tipo de pago.*/
    private String tipoPago = StringUtils.EMPTY;

    /** Numero de Sucursal.*/
    private String numSucursal = StringUtils.EMPTY;

    /** Fecha limite de pago.*/
    private String fechaLimPago = StringUtils.EMPTY;

    /** Estatus de orden de pago.*/
    private String estatusOp = StringUtils.EMPTY;

    /**Identifica si es Pago TDC Santander*/
    private boolean esPagoTDC;

    /**Identifica si es Impuestos Federales**/
    private boolean esImpuFed;
    /**Identifica si es Pago Referenciados(Pagos de Servicios e Impuestos Locales)*/
    private boolean esPagRef;
    /**Identifica si es Aportaciones Obrero Patronales*/
    private boolean esApoObr;
    /**Identifica si es Impuestos federales version 2*/
    private boolean esVer2;
    /**linea de Captura*/
    private String lineaCaptura;
    /**plaza*/
    private String plaza;
    /**numero de sucursal*/
    private String sucursal;
    /**llave de pago refrenciado*/
    private String llavePago;
    /**convenio*/
    private String convenio;
    /**folio sua*/
    private String folioSua;
    /**resgistro patronal*/
    private String regPatronal;
    /**periodoPago*/
    private String periodoPago;
    /**numero de operacion*/
    private String numOperacion;
    /**Medio de presentacion*/
    private String medioPresentacion;
    private String patente;
    private String pedimento;
    private String aduana;
    private String cveProdOper;
    private String fechaPago;
    private String horaPago;
    private String numOpeBan;
    private String numTrans;
    private String medioPres;
    private String medioCob;
}
