/**
 * 
 * Clase: GenerateVouchersController.java
 * Descripcion: Comprobantes Formato CDMX
 *
 * Control de Cambios:
 * 26/09/2019 Bhalla Ram - Creacion de la clase
 */
package mx.santander.h2h.monitoreo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import mx.santander.h2h.monitoreo.constants.ReportConstants;
import mx.santander.h2h.monitoreo.constants.RoutesConstant;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.HistorialOperacionesRequest;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersControllerResponse;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersDtoResponse;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersTotalResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsHistoryResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.model.response.VoucherRequestDto;
import mx.santander.h2h.monitoreo.service.IGenerateVouchersExportService;
import mx.santander.h2h.monitoreo.service.IGenerateVouchersOperacionesService;
import mx.santander.h2h.monitoreo.service.IGenerateVouchersService;

/**
 * Descripcion:Controller utilizado para la pantalla de comprobantes fiscales
 * GenerateVouchersController.java
 * 
 * @author sbautish
 * @Version 1.0 TCS Creacion de GenerateVouchersController.java
 */
@Validated
@RestController
@RequestMapping(RoutesConstant.PATH_VOUCHERS_CDMX)
public class GenerateVouchersController {

	@Autowired
	private IGenerateVouchersService iGenerateVouchersService;
	
	@Autowired
	private IGenerateVouchersExportService  iGenerateVouchersExportService;
	
	@Autowired
	private IGenerateVouchersOperacionesService generateVouchersOperacionesService;

	/**
	 * 
	 * Descripción : Metodo que realiza el arranque de la pantalla
	 * 
	 * @param contractConnectionParametersManagementRequest
	 * @return Datos del registro actualizado
	 */
	@Operation(summary = "Endpoint para consultar los comprobantes formato cdmx.")
	@GetMapping(path = "/find-vouchers-cdmx", produces = MediaType.APPLICATION_JSON_VALUE)
	public GenerateVouchersControllerResponse findVouchersCdmx() {

		return iGenerateVouchersService.findVouchersCdmx();

	}

	/**
	 * Descripción : Método que realiza la consulta de las operaciones
	 * 
	 * @param operationsMonitorQueryRequest objeto de entrada
	 * @param pageable                      objeto paginador
	 * @return retorna objeto con datos de las operaciones
	 */
	@Operation(summary = "Endpoint para consultar las operaciones.")
	@PostMapping(path = "/find-operations-monitor", produces = MediaType.APPLICATION_JSON_VALUE)
	public GenerateVouchersControllerResponse findOperationsMonitor(
			@Valid
			@RequestBody OperationsMonitorQueryRequest operationsMonitorQueryRequest,
			@PageableDefault Pageable pageable) {

		return iGenerateVouchersService.findOperationsMonitor(operationsMonitorQueryRequest, pageable);
	}

	/**
	 * Descripción : Método que realiza la consulta de totales
	 * 
	 * @return objeto con totales de importe y archivos
	 */
	@Operation(summary = "Endpoint para consultar totales.")
	@PostMapping(path = "/find-total", produces = MediaType.APPLICATION_JSON_VALUE)
	public GenerateVouchersTotalResponse findTotal(
			@Valid
			@RequestBody OperationsMonitorQueryRequest operationsMonitorQueryRequest) {

		return iGenerateVouchersService.findTotal(operationsMonitorQueryRequest);

	}

	/**
	 * Descripción : Método que realiza la paginación
	 * 
	 * @param operationsMonitorQueryResponse Objeto con datos de entrada
	 * @param pageable                       Objeto para paginación
	 * @return Objeto con datos de respuesta
	 */
	@Operation(summary = "Endpoint para consultar de operaciones paginadas.")
	@PostMapping(path = "/paginar-operaciones", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Page<OperationsMonitorQueryResponse>> paginarOperaciones(
			@Valid
			@RequestBody OperationsMonitorQueryRequest operationsMonitorQueryRequest,
			@PageableDefault Pageable pageable) {

		return ResponseEntity.ok(iGenerateVouchersService.paginarOperaciones(operationsMonitorQueryRequest, pageable));

	}

	/**
	 * Descripción : Método que realiza la consulta del detalle de la operación
	 * 
	 * @param operationsMonitorQueryResponse Objeto con datos de entrada
	 * @return Objeto con datos de respuesta
	 */
	@Operation(summary = "Endpoint para consultar detalle de operaciones.")
	@PostMapping(path = "/detalle-operaciones", produces = MediaType.APPLICATION_JSON_VALUE)
	public GenerateVouchersControllerResponse detalleOperaciones(
			@Valid
			@RequestBody OperationsMonitorQueryResponse operationsMonitorQueryResponse) {

		return iGenerateVouchersService.detalleOperaciones(operationsMonitorQueryResponse);

	}

	/**
	 * Descripción : Método que realiza la consulta del concepto valor
	 * 
	 * @param lineaCaptura dato de entrada para consulta de datos por linea de
	 *                     captura
	 * @return Objeto con datos de respuesta
	 */
	@Operation(summary = "Endpoint para consultar el concepto valor.")
	@GetMapping(path = "/concepto-valor/{lineaCaptura}", produces = MediaType.APPLICATION_JSON_VALUE)
	public GenerateVouchersDtoResponse conceptoValor(
			@Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Linea de Captura no valida")
			@PathVariable("lineaCaptura") 
			String lineaCaptura) {

		return iGenerateVouchersService.conceptoValor(lineaCaptura);

	}

	/**
	 * Descripción : Método que realiza la exportación de la consulta de operaciones
	 * 
	 * @param countryManagementRequest Objeto con datos de monitor de operación para
	 *                                 consultar en Base de datos.
	 * @return Obtiene documento excel con listado de operaciones.
	 */
	@Operation(summary = "Servicio para generar reporte en Excel de la consulta de operaciones.")
	@PostMapping(path = "/exportar-operaciones", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ReportResponse> exportarOperacionesXlsx(
			@Valid
			@RequestBody OperationsMonitorQueryRequest operationsMonitorQueryRequest) {

		return ResponseEntity.ok(generateVouchersOperacionesService.exportarOperacionesXlsx(operationsMonitorQueryRequest,
				ReportConstants.XLSX_EXTENTION));

	}

	/**
	 * Descripción : Método que realiza la exportación de la consulta de operaciones en pdf
	 * 
	 * @param voucherRequestDto Objeto con datos de comprobante para filtrar en la consulta.
	 * @param response Objeto para respuesta de archivo obtenido de WebService.
	 * @return Archivo generado desde WebService.
	 */
	@Operation(summary = "Servicio para generar reporte en Excel de la consulta de operaciones.")
	@PostMapping(path = "/exportar-operaciones" + RoutesConstant.PDF_PATH, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ReportResponse> exportarOperacionesPdf(
			@Valid
			@RequestBody VoucherRequestDto voucherRequestDto) {

		return ResponseEntity.ok(iGenerateVouchersExportService.exportarOperacionesPdf(voucherRequestDto));

	}
	
	/**
	 * Descripción : Método que realiza la consulta del historial de la operación
	 * 
	 * @param idOperacion dato de entrada para consulta de datos por id de operación
	 * @return Objeto con datos de respuesta
	 */
	@Operation(summary = "Endpoint para consultar el historial de la operación.")
	@GetMapping(path = "/historial-operacion/{idOperacion}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<OperationsHistoryResponse>> historialOperaciones(
			@PathVariable(required = true, name = "idOperacion") 
			@NotBlank(message = "El id operacion no debe venir vacío") 
			@Size(min = 0, max = 15, message = "El id operacion debe tener máximo 15 dígitos") 
			@Pattern(regexp = "(^[0-9]+$)?", message = "Solo se permiten caracteres númericos") 
			String idOperacion) {

		return ResponseEntity.ok(iGenerateVouchersService.historialOperaciones(idOperacion));

	}

	/**
	 * Controller que obtiene el reporte historial operaciones
	 * @param historialOperacionesRequest atributos de solicitud
	 * @return reporte
	 */
	@Operation(summary = "Servicio para generar reporte en Excel de la Historial consulta de operaciones.")
	@PostMapping(path = "/historial-operacion-export", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ReportResponse> exportarHistorialOperacionesXlsx(
			@Valid
			@RequestBody HistorialOperacionesRequest historialOperacionesRequest ) {
		return ResponseEntity.ok(generateVouchersOperacionesService.exportarHistorialOperacionesXlsx(historialOperacionesRequest));
	}
}
