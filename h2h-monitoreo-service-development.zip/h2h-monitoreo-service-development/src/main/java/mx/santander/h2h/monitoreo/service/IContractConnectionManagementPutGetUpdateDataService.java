package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.model.request.PutGetRequest;
import mx.santander.h2h.monitoreo.model.response.PutGetServiceResponse;

public interface IContractConnectionManagementPutGetUpdateDataService {

	void actualizarPtclPath(PutGetServiceResponse putGetServiceResponse, PutGetRequest putGetRequest, String tipo);

	void actualizarPtclPara(PutGetServiceResponse putGetServiceResponse);

	void actualizaParaSFTPCD(PutGetServiceResponse putGetServiceResponse);

}
