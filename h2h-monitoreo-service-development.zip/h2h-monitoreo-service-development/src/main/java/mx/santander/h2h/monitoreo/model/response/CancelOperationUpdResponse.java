package mx.santander.h2h.monitoreo.model.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class CancelOperationUpdResponse implements Serializable {

    private static final long serialVersionUID = -1075075074986674375L;

    /** Codigo de error. */
    private String codError;

    /** Mensaje de error. */
    private String msgError;
}
