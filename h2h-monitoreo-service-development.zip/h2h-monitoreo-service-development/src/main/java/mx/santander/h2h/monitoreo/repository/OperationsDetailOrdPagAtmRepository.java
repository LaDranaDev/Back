package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.constants.DetailOrdPagoAtmQueryConstants;
import mx.santander.h2h.monitoreo.constants.MonitorOperacionesConstants;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.util.DetalleOperacionUtils;
import mx.santander.h2h.monitoreo.util.UtilMapeoData;
import mx.santander.h2h.monitoreo.util.UtilsTramaAdicionales;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * OperationsDetailOrdenPagoAtmRepository.
 *
 * @author Jesus Soto Aguilar
 */
@Repository
public class OperationsDetailOrdPagAtmRepository implements IOperationsDetailOrdPagAtmRepository {

    @Autowired
    private EntityManager entityManager;
    
    protected static final Map<String, String> tablas = new HashMap<>();

    /*
     * TCS (sonar)
     * Cambio de clase anonima por inicializacion en bloque estatico
     */
    static {
        tablas.put("01",MonitorOperacionesConstants.H2H_PROD_TRAN); /**SPEI*/
        tablas.put("97",MonitorOperacionesConstants.H2H_PROD_TRAN); /**TEF*/
        tablas.put("02",MonitorOperacionesConstants.H2H_PROD_TRAN); /**Nomina Interbancaria*/
        tablas.put("98","H2H_PROD_TRAN_MISM_BANC"); /**TMB*/
        tablas.put("99","H2H_PROD_NOMI_MISM_BANC"); /**Nomina Mismo Banco*/
        tablas.put("91","H2H_PROD_ALTA_PAGO"); /**ALTA PAGO PROVEEDORES CONFIRMING*/
        tablas.put("80","H2H_PROD_ORDN_PAGO"); /**ORDEN DE PAGO	*/
        tablas.put("95","H2H_ACTA_BENI"); /**Alta Cuenta Beneficiarias*/
        tablas.put("96","H2H_ACTA_BENI"); /**Alta Cuenta Beneficiarias*/
        tablas.put("81","H2H_PROD_ORDN_PAGO"); /**ORDEN DE PAGO CANCELADO*/
        tablas.put("93","H2H_PROD_ALTA_EMPL"); /**ALTA MASIVA EMPLEADOS*/
        tablas.put("135","H2H_PROD_MANTTO_PROV_TRAN"); /**MTTO PROVEEDORES DE CONFIRMING**/
        tablas.put("23","H2H_PROD_APO_OBRE_PATR");
        tablas.put("21","H2H_PROD_IMPU_FEDE");
        tablas.put("22","H2H_PROD_PAGO_REFE");
        tablas.put("36","H2H_MX_PROD_PAGO_TDC"); /**Pago a TDC Santander*/
        tablas.put("54","H2H_MX_PROD_CARD_CHECK");
        tablas.put("40","H2H_MX_PROD_PAGO_DIR"); //PGODIRECT
        tablas.put("32", "H2H_MX_PROD_TRAN_INTN");//Transferencias internacionales Cambiarias
        tablas.put("38", "H2H_MX_PROD_TVIB");//Transferencias Vostro Interbancarias
        tablas.put("39", "H2H_MX_PROD_TVMB");//Transferencias Vostro Mismo Banco
        tablas.put("85", "H2H_MX_PROD_ORDN_PAGO_ATM");//Ordenes de pago ATM
        tablas.put("41",MonitorOperacionesConstants.H2H_PROD_TRAN); /**SPEI ONLINE*/
        tablas.put("47",MonitorOperacionesConstants.H2H_PROD_TRAN); /**TEF ONLINE*/
        tablas.put("42",MonitorOperacionesConstants.H2H_PROD_TRAN); /**Nomina Interbancaria ONLINE*/
        tablas.put("48","H2H_PROD_TRAN_MISM_BANC"); /**TMB ONLINE*/
        tablas.put("49","H2H_PROD_NOMI_MISM_BANC"); /**Nomina Mismo Banco ONLINE*/
    }


    @Override
    public OperationsMonitorQueryResponse obtenerDetalleOperacion(String view, String idOperacion) {
        String stringQuery = generaConsultaDetalleOperacion(view, idOperacion);
        Query query = entityManager.createNativeQuery(stringQuery, Tuple.class);
//        query.setParameter("idOperacion", idOperacion);

        OperationsMonitorQueryResponse respuesta = new OperationsMonitorQueryResponse();
        respuesta.setProducto("OPERACION_EN_PROCESO");
        for (Object obj : query.getResultList()) {
            if (obj instanceof Tuple) {
                Tuple tuple = (Tuple) obj;
                Map<String, Object> row = new HashMap<>();
                tuple.getElements().forEach(t -> row.put(t.getAlias(), tuple.get(t)));
                rellenaRespuestaMonitorOperacionesDTO(row, respuesta);
            }
        }

        if ("OPERACION_EN_PROCESO".equals(respuesta.getProducto())){
            respuesta.setMensaje(getH2HMensaje(idOperacion));
        }

        return respuesta;
    }

    private String generaConsultaDetalleOperacion(String view, String idOperacion) {
        StringBuilder query = new StringBuilder();
        query.append(DetailOrdPagoAtmQueryConstants.SELECT);
        query.append(DetailOrdPagoAtmQueryConstants.QUERY);
        query.append(getFromTran(false,view));
        query.append(DetailOrdPagoAtmQueryConstants.UNION);
        query.append(DetailOrdPagoAtmQueryConstants.QUERY);
        query.append(getFromTran(true,view));
        query.append(DetailOrdPagoAtmQueryConstants.ID_REG_EQ);
        query.append(idOperacion);

        return query.toString();
    }

    /**
     * get From si es tran o no
     * @param tran
     * @param view
     * @return
     */
    private String getFromTran(boolean tran,String view) {
        StringBuilder from = new StringBuilder(" FROM ");
        from.append(tablas.get(view));
        if(tran){
            from.append(String.format(DetailOrdPagoAtmQueryConstants.FROM_TRAN, DetailOrdPagoAtmQueryConstants.GUION_TRAN,
                    DetailOrdPagoAtmQueryConstants.GUION_TRAN, DetailOrdPagoAtmQueryConstants.GUION_TRAN));
        }else{
            from.append(String.format(DetailOrdPagoAtmQueryConstants.FROM_TRAN," "," "," "));
        }

        return from.toString();
    }

    private void rellenaRespuestaMonitorOperacionesDTO(Map<String, Object> row, OperationsMonitorQueryResponse respuestaopa) {

        DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols();
        formatSymbols.setDecimalSeparator('.');
        formatSymbols.setGroupingSeparator(',');
        final DecimalFormat decimalFormat = new DecimalFormat("###,###,###,###,##0.00", formatSymbols);

        respuestaopa.setIdOperacion(DetalleOperacionUtils.defaultObjectString(row.get("ID_REG"), "0"));
        respuestaopa.setCodCli(Objects.toString(row.get("BUC"),"").trim());
        respuestaopa.setCtaCargo(Objects.toString(row.get("NUM_CTA_CARGO"), "").trim());
        respuestaopa.setCtaAbono(Objects.toString(row.get("NUM_CTA_ABONO"), "").trim());
        // Obtenemos el enmascarado de datos
        respuestaopa.setCtaAbono( UtilMapeoData.getMascara(respuestaopa.getCtaAbono(), "abono") );
        respuestaopa.setIdProducto(DetalleOperacionUtils.defaultObjectString(row.get("CVE_PROD_OPER"), "0"));
        respuestaopa.setProducto(Objects.toString(row.get("DESC_PROD"), "").trim());
        respuestaopa.setNomArch(Objects.toString(row.get("NOMBRE_ARCH"), "").trim());

        respuestaopa.setReferencia(DetalleOperacionUtils.defaultObjectString(row.get("REFERENCIA"), ""));
        respuestaopa.setEstatus(Objects.toString(row.get("DESC_ESTATUS"), "").trim());
        respuestaopa.setImporte("$" + decimalFormat.format(Double.valueOf(DetalleOperacionUtils.defaultObjectString(row.get("IMPORTE"), "0.00"))));
        respuestaopa.setImporteCargo("$" + decimalFormat.format(Double.valueOf(DetalleOperacionUtils.defaultObjectString(row.get("IMPORTE_CARGO"), "0.00"))));
        respuestaopa.setComentario1(Objects.toString(row.get("CLAVE_DESE"), "").trim());
        respuestaopa.setComentario2(Objects.toString(row.get("TIPO_CAMBIO"), "").trim());
        respuestaopa.setComentario3(Objects.toString(row.get("COMENTARIO_1"), "").trim());

        respuestaopa.setDivisa(Objects.toString(row.get("DIVISA"), "").trim());
        if (MonitorOperacionesConstants.MN.equals(respuestaopa.getDivisa().trim()) || MonitorOperacionesConstants.MXN.equals(respuestaopa.getDivisa().trim())){
            respuestaopa.setDivisa(MonitorOperacionesConstants.MXP);
        }
        respuestaopa.setDivisaOrd(Objects.toString(row.get("DIVISA_ORD"), "").trim());
        if (MonitorOperacionesConstants.MN.equals(respuestaopa.getDivisaOrd().trim()) || MonitorOperacionesConstants.MXN.equals( respuestaopa.getDivisaOrd().trim())){
            respuestaopa.setDivisaOrd(MonitorOperacionesConstants.MXP);
        }

        respuestaopa.setFechaAplic(UtilsTramaAdicionales.getFecha(row.get("FECHA_APLICACION")));
        respuestaopa.setFechaCaptura(UtilsTramaAdicionales.getFecha(row.get("FECHA_REGISTRO")));
        respuestaopa.setFechaLimitPago(UtilsTramaAdicionales.getFecha(row.get("FECHA_LIMITE_PAGO")));
        respuestaopa.setFechaOper(UtilsTramaAdicionales.getFecha(row.get("FECHA_OPERACION")) );
        respuestaopa.setFechaPresIni(UtilsTramaAdicionales.getFecha(row.get("FECHA_OPERACION")) );
        respuestaopa.setNombreOrd(Objects.toString(row.get("NUM_ORDEN"), ""));
        respuestaopa.setIntermOrd(Objects.toString(row.get("INTERMEDIARIO_ORD"), "").trim());
        respuestaopa.setIntermRec(Objects.toString(row.get("INTERMEDIARIO_REC"), "").trim());
        respuestaopa.setNombreBenef(Objects.toString(row.get("BENEFICIARIO"), "").trim());
        respuestaopa.setNumSucursal(Objects.toString(row.get("NUM_SUCURSAL"), "").trim());
        respuestaopa.setFechaVenc(UtilsTramaAdicionales.getFecha(row.get("FECH_VENC")));
        respuestaopa.setNumOrden(Objects.toString(row.get("NUM_ORDEN"), "").trim());
        respuestaopa.setTipoPago(Objects.toString(row.get("TIPO_PAGO"), "").trim());
        respuestaopa.setNumeMovil(null);
        respuestaopa.setBancoReceptor(DetalleOperacionUtils.defaultObjectString(row.get("BANCO_RECEPTOR"), ""));
        respuestaopa.setBancoOrdenante("BANCO SANTANDER (MÉXICO) S.A.");
        respuestaopa.setMensaje(Objects.toString(row.get("MSG_H2H"), "").trim());
        respuestaopa.setIdEstatus(DetalleOperacionUtils.defaultObjectString(row.get("ID_ESTATUS"), "0"));
        respuestaopa.setMensajeOrden(DetalleOperacionUtils.defaultObjectString(row.get("MSG_ORDEN_PAGO"), "0"));
        respuestaopa.setReferenciaAbono(Objects.toString(row.get("REFERENCIA_ABONO"), "").trim());
        respuestaopa.setReferenciaCargo(Objects.toString(row.get("REFERENCIA_CARGO"), "").trim());
        respuestaopa.setNumEmpleado(Objects.toString(row.get("NUMERO_EMPLEADO"), "").trim());
        respuestaopa.setBucEmpleado(Objects.toString(row.get("BUC_EMPLEADO"), "").trim());
        respuestaopa.setRfc(Objects.toString(row.get("RFC"), "").trim());
        respuestaopa.setNumTarjeta(Objects.toString(row.get("NUMERO_TARJETA"), "").trim());
        respuestaopa.setNumTarjetaAct(Objects.toString(row.get("NUMERO_TARJETA_ACT"), "").trim());
        respuestaopa.setNumeroCuenta(Objects.toString(row.get("NUMERO_CUENTA"), "").trim());
        respuestaopa.setDescripcion(Objects.toString(row.get("DESCRIPCION"), "").trim());
        // Enmascaramos las Tarjetas
        respuestaopa.setNumTarjeta( UtilMapeoData.getMascara(respuestaopa.getNumTarjeta(), "tarjeta") );
        // Enmascaramos las Tarjetas
        respuestaopa.setNumTarjetaAct( UtilMapeoData.getMascara(respuestaopa.getNumTarjetaAct(), "tarjeta") );

    }

    private String getH2HMensaje(String idOperacion) {
    	final StringBuilder query = new StringBuilder();
    	query.append("SELECT MSG_H2H FROM H2H_MSG INNER JOIN H2H_REG USING(ID_MSG) WHERE ID_REG = ")
    			.append(idOperacion)
    			.append(" UNION ALL ")
    			.append("SELECT MSG_H2H FROM H2H_MSG INNER JOIN H2H_REG_TRAN USING(ID_MSG) WHERE ID_REG = ")
    			.append(idOperacion);

        Query nativeQuery = entityManager.createNativeQuery(query.toString(), Tuple.class);
//        nativeQuery.setParameter("idOperacion", idOperacion);

        for (Object obj : nativeQuery.getResultList()) {
            if (obj instanceof Tuple) {
                Tuple tuple = (Tuple) obj;
                return Objects.toString(tuple.get("MSG_H2H"), "");
            }
        }

        return null;
    }
}
