/**
* Santander SCIB - Banco Santander Negocios Globales
* Todos los derechos reservados
* MonitorSaldosReportRequest.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <20 nov 2024 10:10:55>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.model.report.request;

import lombok.AllArgsConstructor;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import mx.santander.h2h.monitoreo.model.request.MonitorSaldosRequest;

import java.io.Serializable;

/**
 * MonitorSaldosReportRequest.
 * Objeto de respuesta de la peticion para generar el reporte de saldos reintentos.
 *
 * @author Jesus Soto Aguilar
 * @since 20/04/2023
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MonitorSaldosReportRequest implements Serializable {

    /** Declaracion de Constante serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** Objeto con los datos de consulta. */
    private MonitorSaldosRequest monitorSaldosRequest;

    /** Usuario que realiza la operacion. */
    @Pattern(regexp = "(^[a-zA-Z0-9]+$)?", message = "Datos de usuario no valido")
    @Size(min = 0, max = 15, message = "Datos de Usuario erroneo")
    private String usuario;
}
