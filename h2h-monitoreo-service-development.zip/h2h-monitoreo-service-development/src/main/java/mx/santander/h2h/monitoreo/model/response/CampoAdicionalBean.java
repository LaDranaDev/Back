package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Dto para obtener los datos adicionales del comprobante
 * 
 * @author Z483900
 *
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
public class CampoAdicionalBean implements Serializable {
	/** Serial de la clase. */
	private static final long serialVersionUID = 293305367636950536L;

	/** Atributo que representa el nombre del campo adicional */
	private String campo;

	/** Atributo que representa el tipo de dato del campo adicional */
	private String tipoDato;

	/** Atributo que representa la logitud del campo adicional */
	private int longitud;

	/** Atributo que representa el valor del campo adicional */
	private String value;
}
