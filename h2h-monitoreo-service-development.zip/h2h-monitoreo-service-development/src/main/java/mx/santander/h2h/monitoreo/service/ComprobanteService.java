package mx.santander.h2h.monitoreo.service;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import mx.isban.h2h.comprobantes.model.Comprobante;
import mx.santander.h2h.monitoreo.constants.ReportConstants;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.response.ComprobantesOperacionResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.repository.IComprobanteEntityManagerRepository;
import mx.santander.h2h.monitoreo.util.ComprobanteGenerador;
import mx.santander.h2h.monitoreo.util.ComprobanteGenerador2;
import mx.santander.h2h.monitoreo.util.ComprobanteHelper;

@Service
@Slf4j
public class ComprobanteService implements IComprobanteService {

	/** Constante para Impuesto de Pagos Aduanales */
	private static final String IMP_PAG_ADU = "25";

	/** imagen 1 para reportes ***/

	protected static final String IMG_1 = "imgs/Santander.jpg";
	/** imagen 2 para reportes ***/

	protected static final String IMG_2 = "imgs/logo_Reportes.jpg";

	@Autowired
	private IJasperReportService reportService;

	@Autowired
	private IComprobanteEntityManagerRepository entityManager;

	@Override
	public ReportResponse comprobantes(List<OperationsMonitorQueryResponse> operaciones, String formato) {
		List<Integer> seleccion = new ArrayList<>(operaciones.size());
		List<String> vistaProd = new ArrayList<>(operaciones.size());
		operaciones.forEach(operacion -> {
			seleccion.add(Integer.parseInt(operacion.getIdOperacion()));
			vistaProd.add(operacion.getVistProd());
		});
		log.info("------------ Vamos por la informacion de comprobantes...");
		List<ComprobantesOperacionResponse> comprobantes = entityManager.obtenerComprobantes(seleccion, vistaProd);
		log.info( "Validamos si la lista de Comprobantes esta vacia");
		if (comprobantes.isEmpty()) {
			log.info( "----> Operacion cuando Comprobantes esta vacia.");
			ReportResponse response = new ReportResponse();
			response.setData("");
			return response;
		}
		log.info("comprobantes.size(): " + comprobantes.size());
		try {
			if (ReportConstants.PDF_FORMAT.equals(formato)) {
				return generaReporteGlobal(comprobantes);
			} else {
				return generaReportesPorComprobante(comprobantes);
			}
		} catch (IOException e) {
			throw new BusinessException(e.getMessage());
		}
	}

	/**
	 * Genera el reporte global de comprobantes.
	 *
	 * @param comprobantes el parametro comprobantes
	 */
	protected ReportResponse generaReporteGlobal(
			List<ComprobantesOperacionResponse> comprobantes
		) throws IOException {
		// response.setHeader("Content-Disposition", "attachment;
		// filename=\"comprobantes.pdf\"");
		// obetenemos los de PIF
		List<ComprobantesOperacionResponse> piflst = new ArrayList<ComprobantesOperacionResponse>();
		for (ComprobantesOperacionResponse comp : comprobantes) {
			if (ComprobanteHelper.isPIF(comp) || comp.getTipoOper().toUpperCase().contains("SPEI")) {
				piflst.add(comp);
			}
		}
		comprobantes.removeAll(piflst);
		List<byte[]> pdfFiles = new ArrayList<>();
		if (!comprobantes.isEmpty()) {
			for (ComprobantesOperacionResponse comp : comprobantes) {
				List<ComprobantesOperacionResponse> tmp = new ArrayList<ComprobantesOperacionResponse>();
				tmp.add(comp);
				final byte[] pdf = generarFormatoPdf(obtenerModelo(comprobantes), tmp, false);
				pdfFiles.add(pdf);
			}
		}

		for (ComprobantesOperacionResponse comp : piflst) {
			final byte[] pdf2 = generarFormatoPdf(obtenerModelo(comprobantes), Arrays.asList(comp), true);
			pdfFiles.add(pdf2);
		}

		byte[] data = ComprobanteHelper.concatenarPDFs(pdfFiles);
		return new ReportResponse(

				Base64.getEncoder().encodeToString(data),
				data.length, 
				"comprobantes.pdf",
				MediaType.APPLICATION_PDF_VALUE);
	}

	/**
	 * Genera reportes por comprobante.
	 *
	 * @param comprobantes el parametro comprobantes
	 */
	protected ReportResponse generaReportesPorComprobante(List<ComprobantesOperacionResponse> comprobantes)
			throws IOException {
		log.debug("Inicia generaReportesPorComprobante");
		// Variables de metodo
		final HashMap<String, String> listaNom = new HashMap<String, String>();
		final SimpleDateFormat formatter = new SimpleDateFormat("_yyyyMMdd_HHmm", Locale.forLanguageTag("es_MX"));
		final String nomCarpeta = "cmprbnt" + formatter.format(new Date());
		// Crear carpeta
		final File fichero = new File(nomCarpeta);
		fichero.mkdir();
		// Crear documentos
		int num = 1;
		String nomComprobante = null;
		for (ComprobantesOperacionResponse dto : comprobantes) {
			if (dto.isEsPagoTDC()) {
				String tdc = dto.getCuentaAbono();
				tdc = tdc.trim();
				final int lngtdc = tdc.length();
				if (lngtdc == 16) {
					nomComprobante = "------------" 
						+ dto.getCuentaAbono().substring(12) 
						+ "_"
						+ StringUtils.defaultString(dto.getFolioOp().toString()) 
						+ ".pdf";
				} else {
					nomComprobante = "-----------" 
						+ dto.getCuentaAbono().substring(11) 
						+ "_"
						+ StringUtils.defaultString(dto.getFolioOp().toString()) 
						+ ".pdf";
				}
			} else {
				nomComprobante = ComprobanteHelper.validaEsSpei(dto);
			}
			List<ComprobantesOperacionResponse> tmp = new ArrayList<>();
			tmp.add(dto);
			final byte[] pdf = generarFormatoPdf(obtenerModelo(tmp), tmp, true);
			FileOutputStream salida;
			try {
				salida = new FileOutputStream(nomCarpeta + File.separatorChar + nomComprobante);
				salida.write(pdf);
				salida.close();
			} catch (IOException | RuntimeException e) {
				throw new BusinessException("MONOP0006", "Error al crear comprobante numero: " + num);
			}
			listaNom.put(nomComprobante, nomComprobante);
			num++;
		}
		// Generar el archivo zip
		final String nomZip = nomCarpeta + ".zip";
		try {
			final FileOutputStream destino = new FileOutputStream(nomZip);
			final ZipOutputStream zipArchivo = new ZipOutputStream(new BufferedOutputStream(destino));
			for (String nom : listaNom.keySet()) {
				final File fileTmp = new File(nomCarpeta + File.separatorChar + nom);
				final FileInputStream streamTmp = new FileInputStream(fileTmp);
				final ZipEntry arch = new ZipEntry(nom);
				zipArchivo.putNextEntry(arch);
				int byteCount;
				final byte[] buffer = new byte[4096];
				while (-1 != (byteCount = streamTmp.read(buffer))) {
					zipArchivo.write(buffer, 0, byteCount);
				}
				zipArchivo.closeEntry();
				streamTmp.close();
				Files.delete(fileTmp.toPath());
			}
			zipArchivo.close();
			destino.close();
		} catch (IOException e) {
			throw new BusinessException("Error al generar el zip ");
		}
		log.debug("Fin generaReportesPorComprobante");
		return ultimosPasosZip(nomZip, nomCarpeta);
	}

	/***
	 *
	 * @param nomZip     nombrezip
	 * @param nomCarpeta nombre carpeta
	 * @throws BusinessException con error
	 */
	protected ReportResponse ultimosPasosZip(String nomZip, String nomCarpeta) throws BusinessException {
		// Agrega el request la respuesta del zip
		ReportResponse response = new ReportResponse();
		try {
			final FileInputStream zip = new FileInputStream(nomZip);
			byte[] bytes = IOUtils.toByteArray(zip);
			zip.close();
			response.setData( Base64.getEncoder().encodeToString(bytes) );
			
			response.setLength(bytes.length);
		} catch (IOException e) {
			throw new BusinessException("Error al descargar el zip ");
		}
		// Borrado de archivos temporales
		try {
			File tmpFile = new File(nomZip);
			Files.delete(tmpFile.toPath());
			tmpFile = new File(nomCarpeta);
			Files.delete(tmpFile.toPath());
		} catch (IOException e) {
			log.debug("Error al borrar archivos temporales");
		}
		response.setName(nomZip);
		response.setType("application/zip");
		return response;
	}

	/**
	 * Obtiene el modelo para los reportes.
	 * 
	 * @param comprobantes List<ComprobantesOperacionDTO>
	 * @return Map
	 */
	protected Map<String, Object> obtenerModelo(List<ComprobantesOperacionResponse> comprobantes) throws IOException {
		ClassPathResource pathImagen1 = new ClassPathResource(IMG_1);
		ClassPathResource pathImagen2 = new ClassPathResource(IMG_2);
		Map<String, Object> modelo = new HashMap<>();
		modelo.put("RUTA_IMAGEN", pathImagen1.getURL().toString());
		modelo.put("RUTA_IMAGEN2", pathImagen2.getURL().toString());
		modelo.put("NUM_ELEM", comprobantes.size());
		return modelo;
	}

	/**
	 * Generar reporte en formato PDF
	 *
	 * @param modelo    el parametro modelo
	 * @param registros el parametro registros
	 * @return byte[] bytes
	 * @param generaMasivo para generacion anterior
	 */
	protected byte[] generarFormatoPdf(
			Map<String, Object> modelo, 
			List<ComprobantesOperacionResponse> registros,
			boolean generaMasivo
		) {
		byte[] reporte = null;
		if (registros == null || registros.isEmpty()) {
			return reporte;
		}
		if (ComprobanteHelper.isPIF(registros.get(0)) 
				&& generaMasivo) {
			ComprobantesOperacionResponse obj = registros.get(0);
			if (obj.isEsImpuFed()) {
				reporte = ComprobanteGenerador.generaImpFed(obj);
			} else if (obj.isEsApoObr() || obj.isEsPagRef()) {
				if (obj.isEsApoObr()) {
					reporte = ComprobanteGenerador.generaReporteAportObrerPat(obj);
				} else {
					reporte = ComprobanteGenerador.generaReportePagRef(obj);
				}
			} else if ("-31-".equals(obj.getEstatusMov())) {
				reporte = ComprobanteGenerador.generaTransferenciasMismaDiv(obj);
			} else if ("-33-".equals(obj.getEstatusMov())) {
				reporte = ComprobanteGenerador2.generaTransferenciasCambiarias(obj);
			} else if ("-09-".equals(obj.getEstatusMov())) {
				reporte = ComprobanteGenerador2.generaReportes(obj, Comprobante.SPID);
			}
		} else if (IMP_PAG_ADU.equals(registros.get(0).getCveProdOper())) {
			reporte = ComprobanteGenerador.generaPagImpAdua(registros.get(0));
		} else {
			reporte = generaComprobanteporJasper(registros, modelo);
		}
		return reporte;
	}

	/**
	 * genera el Comprobante por Jasper Reports
	 * 
	 * @param registros lista de registros
	 * @param modelo    modelo para obtener y guardar los datos
	 * @return arreglo de bytes de los comprobantes
	 */
	protected byte[] generaComprobanteporJasper(List<ComprobantesOperacionResponse> registros,
			Map<String, Object> modelo) {
		byte[] comprobante = null;
		if (registros.get(0).getTipoOper().toUpperCase().contains("SPEI")) {
			comprobante = ComprobanteGenerador2.generaReportes(registros.get(0), Comprobante.SPEI);
		} else if (ComprobanteHelper.esMigrado(registros)) {
			comprobante = ComprobanteHelper.generarComprobante(registros);
		} else if (registros.get(0).getTipoOper().toUpperCase().contains("NOMINA INTERBANCARIA")) {
			comprobante = ComprobanteGenerador2.generaReportes(registros.get(0), Comprobante.NOM_INT);
		} else if (registros.get(0).getTipoOper().toUpperCase().contains("ORDEN DE PAGO")
				&& !ComprobanteHelper.esOrdPagAtm(registros.get(0).getTipoOper())) {
			comprobante = ComprobanteGenerador2.generaOrdenPago(registros.get(0));
		} else if ("40".equals(registros.get(0).getEstatusMov())) { // PGODIRECT Inicia
			return ComprobanteGenerador2.generaReportesPD(registros.get(0), Comprobante.PGO_DIRCT);
			// PGODIRECT Fin
		} else if (ComprobanteHelper.esVostro(registros.get(0).getTipoOper())) {
			log.debug("Operaciones de Vostro..." + registros.get(0).getTipoOper());
			comprobante = ComprobanteGenerador2.generaVostro(registros.get(0));
		} else if (ComprobanteHelper.esOrdPagAtm(registros.get(0).getTipoOper())) {
			log.debug("Operaciones de ORdens Pago ATM..." + registros.get(0).getTipoOper());
			return ComprobanteGenerador2.generaOrdenPagoAtm(registros.get(0));
		} else {
			ReportResponse response = reportService.getPdf("rptComprobante.jasper", modelo, registros);
			return Base64.getDecoder().decode(response.getData());
		}
		return comprobante;
	}

}
