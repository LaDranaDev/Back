package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.entity.CatalogStatusEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Interfas que implementa JPA para los catalogos
 * para acceder a la informacion de la base de datos
 * mapeando un Bean con una tabla
 * extiende de la libreria JPARepository
 */
public interface ICatalogoEstatusRepository extends JpaRepository<CatalogStatusEntity, Integer> {

    /**
     * Query para buscar los catalogos con estatus cancelado
     */
    String QUERY_ESTATUS_CANCELADO = "SELECT id_cat_estatus as KEY, desc_estatus as VALUE from H2H_CAT_ESTATUS WHERE TIPO_ESTATUS = 'R' AND CLASIFICACION = 'I' AND (DESC_ESTATUS = 'EN ESPERA' OR DESC_ESTATUS = 'PROGRAMADO')";

    /**
     * Query para buscar los catalogos por tipo y descripccion
     */
    String QUERY_ESTATUS_BY_TIPO_DESC = "SELECT ID_CAT_ESTATUS as ID_CAT, DESC_ESTATUS as DESCRIPCION, BAND_ACTIVO as ESTATUS_ACTIVO FROM H2H_CAT_ESTATUS WHERE TIPO_ESTATUS = :tipo_estat AND DESC_ESTATUS = :desc_estat ORDER BY DESC_ESTATUS";

    /**
     * QUery para buscar los catalogos del centro
     */
    String QUERY_COMBO_ESTATUS_CENTRO = "SELECT ID_CAT_ESTATUS as ID_CAT,DESC_ESTATUS as DESCRIPCION,BAND_ACTIVO as ESTATUS_ACTIVO FROM H2H_CAT_ESTATUS WHERE TIPO_ESTATUS = 'C' ORDER BY DESC_ESTATUS";

    /**
     * Metodo apra obtener los catalogos con estatus Cancelado
     * @return
     */
    @Query(nativeQuery = true, value = QUERY_ESTATUS_CANCELADO)
    List<Object[]> obtenerCatalogoEstatusCancelado();

    /**
     * Metodo apra obtener los estatus cancelados
     * @param tipoStat tipo de estatus
     * @param descEstat descripcion
     * @return
     */
    @Query(nativeQuery = true, value = QUERY_ESTATUS_BY_TIPO_DESC)
    List<Object[]> obtenerCatalogoEstatusCancelado(@Param("tipo_estat")String tipoStat, @Param("desc_estat") String descEstat);

    /**
     * Metodo para obtener los catalods de Esttaus centro
     * @return List<Object[]>
     */
    @Query(nativeQuery = true, value = QUERY_COMBO_ESTATUS_CENTRO)
    List<Object[]> obtenerCatalogoEstatusCentro();
}
