package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Dto para los datos de salida del WS PUT/GET
 * 
 * @author Z483900
 *
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
public class PutGetWSDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1375214719937689147L;

	/**Variable para almacenar URI CORRESPONDIENTE AL PUT*/
	private String uriPUTWS;

	/**Variable para almacenar URI CORRESPONDIENTE AL GET*/
	private String uriGETWS;

	/**Variable para almacenar URI CORRESPONDIENTE AL WS PARA LA CONSULTA*/
	private String uriConsultaWS;

	/**Variable para alamcenar CERT PARA WS*/
	private String certificadoWS;

}
