package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.model.mapper.ProductModelMapping;
import mx.santander.h2h.monitoreo.model.response.ProductResponse;
import mx.santander.h2h.monitoreo.repository.IProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * ProductService.
 * Define los metodos de negocio para le obtencion de l catalogo de productos.
 *
 * @author Jesus Soto Aguilar
 * @since 20/04/2023
 */
@Service
public class ProductService implements IProductService{

    /**
     * Servicio para ejecutar las consultas de productos.
     */
    @Autowired
    private IProductRepository productRepository;

    /**
     * Obtiene la lista de productos activos.
     *
     * @return Lista de productos.
     */
    @Override
    public List<ProductResponse> getProductos() {
        return ProductModelMapping.mappingEntityListToDtoList(productRepository.findProductos());
    }

    /**
     * Obtiene el producto por su clave.
     *
     * @return Objeto con los datos del producto.
     */
    @Override
    public ProductResponse getProductoByClave(String claveProducto) {
        return ProductModelMapping.mappingEntityToDto(productRepository.findByCveProdOper(claveProducto));
    }


}
