package mx.santander.h2h.monitoreo.constants;
/**
 * ErrorConstant 
 * Clase para constantes con valores genericos para los mensajes de error
 * 
 * @author pquintra
 * @since 14/06/2022
 */
public final class ErrorConstant {
	/**
	 * Código genérico.
	 */
	public static final String GENERIC_ERROR_CODE = "500";
	/**
	 * Mensaje genérico.
	 */
	public static final String GENERIC_ERROR_MESSAGE = "Ocurrió un error desconocido";
	/**
	 * Código para dato no encontrado.
	 */
	public static final String BAD_REQUEST_CODE = "400";
	/**
	 * Código para dato no encontrado.
	 */
	public static final String RECORD_NOT_FOUND_CODE = "404";
	/**
	 * Mensaje para dato no encontrado.
	 */
	public static final String RECORD_NOT_FOUND_MESSAGE = "No se encontraron datos";
	/**
	 * Mensaje para dato no encontrado.
	 */
	public static final String CONTRACT_NOT_FOUND_MESSAGE = "No se encontraron los datos del contrato.";
	/**
	 * Mensaje para indicar cuando una propiedad esta null o empty
	 */
	public static final String MESSAGE_PROPERTY_NULL = "La propiedad no puede estar vacia o nula.";
	/**
	 * Mensaje para indicar cuando la información ya esta registrada
	 */
	public static final String MESSAGE_ALREADY_REGISTER = "Error, la información ya se encuentra registrada.";
	/**
	 * Mensaje para indicar el registro o actualización fue exitoso
	 */
	public static final String MESSAGE_SUCCESS_REGISTER = "Información guardada correctamente.";
	/**
	 * Cadena de mensaje para asignar al format del string
	 */
	public static final String ERROR_FORMATSTRING = "{0} : {1}";
	/**
	 * Mensaje de error al guardar
	 */
	public static final String ERROR_SAVE_UPDATE = "Ocurrio un error al guardar la información";
	/**
	 * Mensaje de error al convetir a un numero
	 */
	public static final String ERROR_CONVERTO_NUMBER = "Ocurrio un error al convertir el valor a numero";
	/**
	 * Mensaje para dato no encontrado.
	 */
	public static final String ERRND00 = "ERRND00";
	/**
	 * Mensaje para dato no encontrado.
	 */
	public static final String ERRRC00 = "ERRRC00";
	/**
	 * Mensaje exitoso para consulta en bd.
	 */
	public static final String OKC01 = "OKC01";
	/**
	 * Mensaje de error para consulta en bd.
	 */
	public static final String ERRDB01 = "ERRDB01";
	/**
	 * Mensaje exitoso para guardado en bd.
	 */
	public static final String OKG01 = "OKG01";
	/**
	 * Mensaje de error para guardado bd.
	 */
	public static final String ERUP00 = "ERUP00";
	/**
	 * Texto Request:
	 */
	public static final String REQUEST = "Request: ";
	/**
	 * Texto Response:
	 */
	public static final String RESPONSE = "Response: ";
	/**
	 * Codigo de error para respuesta
	 */
	public static final String FAILURE_CODE = "ER00000";

	/**
	 * Constructor.
	 */
	private ErrorConstant() {
	}
}
