/**
* Santander SCIB - Banco Santander Negocios Globales
* Todos los derechos reservados
* IConsultaTrackingNativeBRepository.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <3 dic 2024 18:15:30>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.model.response.ProdArchResponse;



/**
 * Clase generada para IConsultaTrackingNativeBRepository.
 *
 * @autor FSW
 * @modifico C320868
 */
public interface IConsultaTrackingNativeBRepository {
	
	/**
	 * Obtener detalle archivos nivel archivo.
	 *
	 * @param page para page
	 * @param fecha para fecha
	 * @param codCliente para cod cliente
	 * @param nomArch para nom arch
	 * @param estatus para estatus
	 * @return el map
	 */
	Map<String, Object> obtenerDetalleArchivosNivelArchivo(Pageable page, String fecha, String codCliente, String nomArch, Integer estatus);
	
	/**
	 * Obtener list detalle archivos nivel archivo.
	 *
	 * @param fecha para fecha
	 * @param codCliente para cod cliente
	 * @param nomArch para nom arch
	 * @param estatus para estatus
	 * @return el list
	 */
	List<ProdArchResponse> obtenerListDetalleArchivosNivelArchivo(String fecha, String codCliente, String nomArch, Integer estatus);

}
