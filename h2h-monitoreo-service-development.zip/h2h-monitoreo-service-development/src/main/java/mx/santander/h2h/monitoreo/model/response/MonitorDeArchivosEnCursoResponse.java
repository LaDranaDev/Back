package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Clase encarga de definir los datos de salida de notificaciones
 * 
 * @author emendoza
 * @since 12/04/2023
 */
@Getter
@Setter
@NoArgsConstructor
@ToString
public class MonitorDeArchivosEnCursoResponse implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Lista de notificaciones
	 */
	private List<MonitorDeArchivosEnCursoDetallesResponse> monitorDeArchivosEnCurso;
	
	/**
	 * Lista de notificaciones
	 */
	private List<MonitorDeArchivosEnCursoDetallesOperacionResponse> monitorDeArchivosEnCursoOperacion;
	
	/***
	 * Codigo del error
	 */
	private String codError;
}


