/**
* Santander SCIB - Banco Santander Negocios Globales
* Todos los derechos reservados
* UtilOperationsMonitor.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <4 jul. 2024 12:21:17>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.util;

import java.util.Map;

import org.apache.commons.lang.StringUtils;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;

/**
 * Clase generada para UtilOperationsMonitor.
 *
 * @autor FSW
 * @modifico C320868
 */
@Slf4j
public class UtilOperationsMonitor {

	/** Tabla PROD */
	protected static final String TMP_DIVI = "TMP.DIVI DIVISA,";
	/** SELECT 'H2H_REG_TRAN' TABLA, */
	protected static final String SELECT_H2H_REG_TRAN_TABLA = "SELECT 'H2H_REG_TRAN' TABLA, ";
	/** SELECT 'H2H_REG' TABLA, */
	protected static final String SELECT_H2H_REG_TABLA = "SELECT 'H2H_REG' TABLA, ";
	/** MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, */
	protected static final String MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN = "MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, ";
	/** NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, **/
	protected static final String NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA = "NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, ";
	/** NULL BUC_EMPLEADO, */
	protected static final String NULL_BUC_EMPLEADO = " NULL BUC_EMPLEADO, ";
	/** "NULL SUCURSAL_TUTORA, NULL RFC, NULL TIPO, " **/
	protected static final String NULL_SUCURSAL_TUTORA_NULL_RFC_NULL_TIPO = "NULL SUCURSAL_TUTORA, NULL RFC, NULL TIPO, ";
	/** NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, **/
	protected static final String NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA = "NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, ";
	/** NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD, */
	protected static final String PIF_INTERMEDIARIO_ORD_NULL_DIVISA_ORD = "DETA.OBSE_ABO INTERMEDIARIO_ORD, TMP.DIVI DIVISA_ORD, ";
	/** NULL INTERMEDIARIO_REC, NULL BENEFICIARIO, */
	protected static final String NULL_INTERMEDIARIO_REC_NULL_BENEFICIARIO = "MSG.MSG_H2H INTERMEDIARIO_REC, NULL BENEFICIARIO, ";
	/** NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD, */
	protected static final String NULL_INTERMEDIARIO_OTROSPROD = "NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD, ";
	/** INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS */
	protected static final String INNER_JOIN_H2H_CAT_ESTATUS_EST_ON_REG_ID_ESTATUS_EST_ID_CAT_ESTATUS = "INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS ";
	/** INNER JOIN H2H_CNTR CNTR USING (ID_CNTR) */
	protected static final String INNER_JOIN_H2H_CNTR_CNTR_USING_ID_CNTR = " INNER JOIN H2H_CNTR CNTR USING (ID_CNTR) ";
	/**
	 * constante para la tabla de H2H_MX_PROD_TRAN_INTN
	 *
	 */
	private static final String H2H_MX_PROD_TRAN_INTN = "H2H_MX_PROD_TRAN_INTN";

	/***
	 *
	 * @param query query
	 */
	protected static void agrega01y97y02(StringBuilder query) {
		String sqlProdTran = query.toString();
		
		// Iniciamos procedimiento
		query.delete(0, sqlProdTran.length());
		sqlProdTran = sqlProdTran.replace(TMP_DIVI,
				"DECODE(DIVI_ABON.CLAV_CAPTA,NULL,TMP.DIVI,DIVI_ABON.CLAV_CAPTA) DIVISA,");
		query.append(sqlProdTran)
			.append("DETA.CLAV_INTE_ORDE INTERMEDIARIO_ORD, DIVI_CARG.CLAV_CAPTA DIVISA_ORD, ")
			.append("MSG.MSG_H2H INTERMEDIARIO_REC, DECODE(CNTA_ABON.NOMB_TITU, NULL, ")
			.append("DETA.NOMB_RECE, CNTA_ABON.NOMB_TITU) BENEFICIARIO, ")
			.append("DETA.COME_1_CONC_PAGO COMENTARIO_1, DETA.COME_2 COMENTARIO_2, ")
			.append("DETA.COME_3 COMENTARIO_3, CNTA_CARG.NOMB_TITU TITULAR, BNCO.NOMBRE_BANCO BANCO_RECEPTOR, ")
			.append("NULL TIPO_PAGO, NULL MODALIDAD, DETA.IMPO_CARG IMPORTE_CARGO, ")
			.append("MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, ")
			.append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, ")
			.append("NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, ")
			.append("NULL BUC_EMPLEADO, ")
			.append("NULL SUCURSAL_TUTORA, NULL RFC, NULL TIPO, ")
			.append("NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, ");
	}

	/***
	 *
	 * @param query query
	 */
	protected static void agrega80y81(StringBuilder query) {
		query.append("NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD, NULL INTERMEDIARIO_REC, ")
			.append("DETA.NOMB_BENE || ' ' || DETA.APE_PATE_BENE || ' ' || DETA.APE_MATE_BENE BENEFICIARIO, ")
			.append(" NULL COMENTARIO_1, NULL COMENTARIO_2, ")
			.append("NULL COMENTARIO_3, NULL TITULAR, NULL BANCO_RECEPTOR, ")
			.append("DETA.FORM_PAGO TIPO_PAGO, DETA.FORM_ALTA MODALIDAD, DETA.IMPO_GIRO IMPORTE_CARGO, ")
			.append("MSG.MSG_H2H MSG_H2H, MSG.MSG_H2H MSG_ORDEN_PAGO, DETA.NUM_ORDEN, ")
			.append("DETA.FECH_LIMI_LIQ FECHA_LIMITE_PAGO, DETA.OFIC_PAGO NUM_SUCURSAL, ")
			.append(" NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, ")
			.append(" NULL BUC_EMPLEADO, NULL SUCURSAL_TUTORA, NULL RFC, NULL TIPO, ")
			.append(" NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, ");
	}

	/***
	 * Columnas para Pago Directo PGODIRECT
	 * 
	 * @param query query
	 */
	protected static void agrega40(StringBuilder query) {
		query.append("NULL INTERMEDIARIO_ORD, NULL DIVISA_ORD, NULL INTERMEDIARIO_REC, ")
			.append("DETA.NOM_BENE BENEFICIARIO, ")
			.append(" NULL COMENTARIO_1, NULL COMENTARIO_2, ")
			.append("NULL COMENTARIO_3, info.NOMB_TITU TITULAR, NULL BANCO_RECEPTOR, ")
			.append("DECODE(DETA.FORM_PAG,'C','CHEQUE','E','EFECTIVO','ABONO A CUENTA') TIPO_PAGO, ")
			.append("NULL MODALIDAD, TO_NUMBER(DETA.IMP_PAGO) IMPORTE_CARGO, ")
			.append("MSG.MSG_H2H MSG_H2H, MSG.MSG_H2H MSG_ORDEN_PAGO, DETA.NO_ORDEN NUM_ORDEN, ")
			.append("abt.FECH_RESP_BE FECHA_LIMITE_PAGO, DETA.CLV_SUC NUM_SUCURSAL, ")
			.append(" NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, NULL BUC_EMPLEADO,  ")
			.append(" NULL SUCURSAL_TUTORA, NULL RFC, NULL TIPO, ")
			.append(" NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, ");
	}

	/***
	 *
	 * @param query query
	 *
	 */
	protected static void agrega95y96(StringBuilder query) {
		String sqlProdTran = query.toString();
		query.delete(0, sqlProdTran.length());
		sqlProdTran = sqlProdTran.replace(TMP_DIVI,
				"DECODE(DIVI_ABON.CLAV_CAPTA,NULL,TMP.DIVI,DIVI_ABON.CLAV_CAPTA) DIVISA,");
		query.append(sqlProdTran)
			.append("NULL INTERMEDIARIO_ORD, DIVI_CARG.CLAV_CAPTA DIVISA_ORD, ")
			.append("MSG.MSG_H2H INTERMEDIARIO_REC, DECODE(CNTA_ABON.NOMB_TITU,NULL, ")
			.append("DETA.NOMB_RECE,CNTA_ABON.NOMB_TITU) BENEFICIARIO, ")
			.append("NULL COMENTARIO_1, NULL COMENTARIO_2, ")
			.append("NULL COMENTARIO_3, CNTA_CARG.NOMB_TITU TITULAR, BNCO.NOMBRE_BANCO BANCO_RECEPTOR, ")
			.append("NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO, ")
			.append("MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, ")
			.append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, ")
			.append("NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA,  ")
			.append("NULL BUC_EMPLEADO, NULL SUCURSAL_TUTORA, NULL RFC, NULL TIPO,  ")
			.append("NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA,  ");
	}

	/***
	 *
	 * @param query query
	 *
	 */
	protected static void agrega9y99(StringBuilder query) {
		String sqlProdTran = query.toString();
		query.delete(0, sqlProdTran.length());
		sqlProdTran = sqlProdTran.replace(TMP_DIVI, "DIVI_ABON.CLAV_CAPTA DIVISA,");
		query.append(sqlProdTran);
		query.append("NULL INTERMEDIARIO_ORD, DIVI_CARG.CLAV_CAPTA DIVISA_ORD, ")
			.append("MSG.MSG_H2H INTERMEDIARIO_REC, CNTA_ABON.NOMB_TITU BENEFICIARIO, ")
			.append("NULL COMENTARIO_1, NULL COMENTARIO_2,  ")
			.append("NULL COMENTARIO_3, CNTA_CARG.NOMB_TITU TITULAR, BNCO.NOMBRE_BANCO BANCO_RECEPTOR, ")
			.append("NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO, ")
			.append("MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN,  ")
			.append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL,  ")
			.append("NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA,  ")
			.append("NULL BUC_EMPLEADO, NULL SUCURSAL_TUTORA, NULL RFC, NULL TIPO,  ")
			.append("NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA,  ");
	}

	
	/**
	 *
	 * @param query       query para Transferencias Internacionales
	 * @param cveOperProd prod oper
	 */
	protected static void agregaTIconsulta(StringBuilder query, String cveOperProd) {
		query.append("null INTERMEDIARIO_ORD, TMP.DIVI DIVISA_ORD, ")
			.append("MSG.MSG_H2H INTERMEDIARIO_REC, DETA.TXT_NOM_BENE BENEFICIARIO, ")
			.append("NULL COMENTARIO_1, NULL COMENTARIO_2,NULL COMENTARIO_3, ")
			.append("DETA.TXT_NOM_ORD TITULAR, NULL BANCO_RECEPTOR, ")
			.append("NULL TIPO_PAGO, NULL MODALIDAD,");
		if ("33".equals(cveOperProd)) {
			query.append("DETA.IMP_CARGO IMPORTE_CARGO, ")
				.append("DECODE(DETA.DSC_ERROR, null, MSG.MSG_H2H, DETA.DSC_ERROR) MSG_H2H, ")
				.append("NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN,");
		} else {
			query.append("DETA.IMP_CARGO_ORD IMPORTE_CARGO, ")
				.append(MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN);
		}
		
		query.append(" NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, ")
			.append(NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA)
			.append(NULL_BUC_EMPLEADO)
			.append(NULL_SUCURSAL_TUTORA_NULL_RFC_NULL_TIPO)
			.append(NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA);
	}

	/**
	 *
	 * @param query       query
	 * @param cveOperProd prod oper
	 */

	protected static void agregaPifconsulta(StringBuilder query, String cveOperProd) {
		query.append(PIF_INTERMEDIARIO_ORD_NULL_DIVISA_ORD)
			.append(NULL_INTERMEDIARIO_REC_NULL_BENEFICIARIO)
			.append("OBSE_ABO COMENTARIO_1,");
		if ("23".equals(cveOperProd)) {
			query.append(" DETA.REG_PATR COMENTARIO_2,DETA.NUME_FOLI_SUA COMENTARIO_3,");
		} else {
			query.append(" NULL COMENTARIO_2,NULL COMENTARIO_3, ");
		}
		query.append(" DETA.NOMB_CLTE TITULAR, NULL BANCO_RECEPTOR, ")
			.append("NULL TIPO_PAGO, NULL MODALIDAD, DETA.IMPO_MOVI IMPORTE_CARGO, ")
			.append(MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN)
			.append(" NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL,  ")
			.append(NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA)
			.append(NULL_BUC_EMPLEADO)
			.append(NULL_SUCURSAL_TUTORA_NULL_RFC_NULL_TIPO)
			.append(NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA);
	}

	/**
	 * Completa el query de productos para el producto 91, 93 y 30.
	 * 
	 * @param cveOperProd Clave de operacion del producto.
	 * @return SQL query
	 */
	protected static void completaQueryProducto919330(final StringBuilder query, String cveOperProd, boolean agregar) {
		if ("91".equals(cveOperProd)) {
			String sqlConfirming = query.toString();
			query.delete(0, sqlConfirming.length());
			// Agregamos la consulta
			query.append(sqlConfirming);
			// Agregamos los campos
			query.append("NULL INTERMEDIARIO_ORD, DETA.DIVI_CARG DIVISA_ORD, ")
				.append("NULL INTERMEDIARIO_REC, DETA.NOMB_RAZON_SOCI_PROV BENEFICIARIO, ")
				.append("NULL COMENTARIO_1, NULL COMENTARIO_2,  ").append("NULL COMENTARIO_3, ")
				.append("DECODE (CLTE.PERSONALIDAD,'F',CLTE.nombre  || ' '  || ")
				.append("CLTE.appaterno  || ' '  || CLTE.apmaterno, CLTE.RAZON_SCIA) TITULAR, ")
				.append("DETA.BANC_ABON BANCO_RECEPTOR, ")
				.append("NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO,  ")
				.append("MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN,  ")
				.append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL,  ")
				.append(NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA).append(NULL_BUC_EMPLEADO)
				.append(NULL_SUCURSAL_TUTORA_NULL_RFC_NULL_TIPO).append(NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA);
		} else if ("93".equals(cveOperProd)) {
			/** Alta Masiva Empleados */
			query.append(NULL_INTERMEDIARIO_OTROSPROD).append(NULL_INTERMEDIARIO_REC_NULL_BENEFICIARIO)
				.append("NULL COMENTARIO_1, NULL COMENTARIO_2, ")
				.append("NULL COMENTARIO_3, NULL TITULAR, NULL BANCO_RECEPTOR, ")
				.append("NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO,  ")
				.append(MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN)
				.append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, ")
				.append("DETA.NUME_EMPL NUMERO_EMPLEADO, DETA.NUME_TARJ_NUEV NUMERO_TARJETA, ")
				.append("DETA.NUME_BUC_EMPL BUC_EMPLEADO, ")
				.append("DETA.SUCU_TUTO SUCURSAL_TUTORA, DETA.RFC_EMPL RFC, DETA.NUME_CTA TIPO, ")
				.append("DETA.NOMB_EMPL || ' ' || DETA.APEL_PATE_EMPL || ' ' || DETA.APEL_MATE_EMPL NOMBRE_EMPLEADO, DETA.NUME_CTA_NUEV NUMERO_CUENTA, ");
		} else if ("30".equals(cveOperProd)) {
			/************************* DOMICILIACIONES **************************/
			query.append(NULL_INTERMEDIARIO_OTROSPROD).append(NULL_INTERMEDIARIO_REC_NULL_BENEFICIARIO)
				.append("NULL COMENTARIO_1, NULL COMENTARIO_2, ")
				.append(" NULL COMENTARIO_3, NULL TITULAR, NULL BANCO_RECEPTOR, ")
				.append("NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO, ")
				.append(MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN)
				.append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, ")
				.append(NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA).append(NULL_BUC_EMPLEADO)
				.append(NULL_SUCURSAL_TUTORA_NULL_RFC_NULL_TIPO).append(NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA);

		} else if ("29".equals(cveOperProd)) {
			/************************* DOMICILIACIONES **************************/
			query.append(NULL_INTERMEDIARIO_OTROSPROD).append(NULL_INTERMEDIARIO_REC_NULL_BENEFICIARIO)
				.append("NULL COMENTARIO_1, NULL COMENTARIO_2, ")
				.append(" NULL COMENTARIO_3, NULL TITULAR, NULL BANCO_RECEPTOR, ")
				.append("NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO, ")
				.append(MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN)
				.append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, ")
				.append(NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA).append(NULL_BUC_EMPLEADO)
				.append(NULL_SUCURSAL_TUTORA_NULL_RFC_NULL_TIPO).append(NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA);
		}
	}

	/**
	 * Crea el query por producto y si el dlel dia de hoy o el de tres meses
	 * 
	 * @param cveOperProd         clave del producto
	 * @param consultaOperaciones DTO de restricciones
	 * @return SQL del producto
	 */
	public static void completaConsultaByProducto(String cveOperProd,
			OperationsMonitorQueryRequest consultaOperaciones, final StringBuilder query, 
			Map<String, Object> params) {
		
		if ("11".equals(consultaOperaciones.getIdProducto())
				&& (consultaOperaciones.getCveProveedor() != null 
					|| consultaOperaciones.getTipOperacion() != null)
				&& (!StringUtils.EMPTY.equals(consultaOperaciones.getCveProveedor())
						|| !StringUtils.EMPTY.equals(consultaOperaciones.getTipOperacion()))) {
			log.info("*****AGREGA EL WHERE EN CASO DE SER CONFIRMING Y QUE ALGUNO DE LOS PARAMTROS NO SEA VACIO*****");
			query.append("WHERE ");
			if (!StringUtils.EMPTY.equals(consultaOperaciones.getTipOperacion())) {
				log.info("*****SI NO ES VACIO AGREGA TIPO OPERACION*****");
				query.append("DETA.CLVE_OPER = :tipOperacion ");
				params.put("tipOperacion", consultaOperaciones.getTipOperacion());
			}
			if (!StringUtils.EMPTY.equals(consultaOperaciones.getCveProveedor())) {
				log.info("*****SI NO ES VACIO AGREGA CLAVE DE PROVEEDOR*****");
				if (!StringUtils.EMPTY.equals(consultaOperaciones.getTipOperacion())) {
					query.append("AND DETA.CLVE_PROV LIKE ('%' || :cveProveedor || '%') ");
				} else {
					query.append("DETA.CLVE_PROV LIKE ('%' || :cveProveedor || '%') ");
				}
				params.put("cveProveedor", consultaOperaciones.getCveProveedor());
			}
		}

		if ("01".equals(cveOperProd) 
				|| "97".equals(cveOperProd) 
				|| "02".equals(cveOperProd)) {
			query.append("LEFT JOIN H2H_CAT_BNCO BNCO ON DETA.CLAV_INTER_RECE  = BNCO.CODI_TRAN ");

		}
		if ("95".equals(cveOperProd) 
				|| "96".equals(cveOperProd)) {
			query.append("LEFT JOIN H2H_CAT_BNCO BNCO USING(ID_BANCO) ");

		}
		if ("98".equals(cveOperProd) 
				|| "99".equals(cveOperProd)) {
			query.append("LEFT JOIN H2H_CAT_BNCO BNCO ON DETA.ID_BANC = BNCO.ID_BANCO ");
		}
		UtilVostroDatosExportar.completaQueryByCveProdOper(query, params);
	}

	
	/**
	 *
	 * @param delDia Dia
	 * @param idcntr String
	 * @return String con query de Transferencias Internacionales
	 */
	public static void getselectTransfInter(boolean delDia, StringBuilder query, String idcntr) {
		String tabla = "";
		if ("31".equals(idcntr)) {
			tabla = H2H_MX_PROD_TRAN_INTN;
		} else if ("33".equals(idcntr)) {
			tabla = "H2H_MX_PROD_BANC_CAMB";
		}
		query.append(delDia ? SELECT_H2H_REG_TRAN_TABLA : SELECT_H2H_REG_TABLA)
			.append("REG.ID_REG, CLTE.BUC, REG.CNTA_CARG NUM_CTA_CARGO, REG.CNTA_ABON NUN_CTA_ABONO, PROD.CVE_PROD_OPER, PROD.DESC_PROD,")
			.append("ARCH.NOMBRE_ARCH,");

		if ("33".equals(idcntr)) {
			query.append("TRIN.NUM_ORDEN  REFERENCIA, REG.ID_ESTATUS,EST.DESC_ESTATUS, REG.MONT IMPORTE, CNTR.NUM_CNTR, REG.DIVI DIVISA, ")
				.append("ARCH.FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, REG.NUM_EMAIL,'' OBSE_ABO, CLTE.BUC BUC_EMPLEADO,")
				.append(" CANL.NOMB_CANL ");
		} else {
			query.append("TRIN.TXT_REF REFERENCIA, ")
				.append("REG.ID_ESTATUS, EST.DESC_ESTATUS, REG.MONT IMPORTE, CNTR.NUM_CNTR, REG.DIVI DIVISA, ")
				.append("ARCH.FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, REG.NUM_EMAIL,'' OBSE_ABO, CLTE.BUC BUC_EMPLEADO, ")
				.append("CANL.NOMB_CANL  ");
		}
		query.append(UtilQuery.fromH2hArchivo(delDia)).append(UtilQuery.innerJoinH2hReg(delDia))
			.append(INNER_JOIN_H2H_CNTR_CNTR_USING_ID_CNTR)
			.append(" INNER JOIN H2H_CLTE CLTE USING (ID_CLTE) ")
			.append(" INNER JOIN H2H_CAT_PROD PROD on PROD.CVE_PROD_OPER=REG.CVE_PROD_OPER ")
			.append(INNER_JOIN_H2H_CAT_ESTATUS_EST_ON_REG_ID_ESTATUS_EST_ID_CAT_ESTATUS)
			.append(" INNER JOIN H2H_CAT_CANL CANL ON ARCH.ID_CANL = CANL.ID_CANL ")
			.append(delDia ? " INNER JOIN " + tabla + "_TRAN TRIN  ON  TRIN.ID_REG = REG.ID_REG "
					: "INNER JOIN " + tabla + " TRIN ON TRIN.ID_REG = REG.ID_REG");
	}
}
