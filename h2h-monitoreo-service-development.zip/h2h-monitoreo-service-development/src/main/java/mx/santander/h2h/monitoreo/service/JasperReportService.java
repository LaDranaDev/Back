package mx.santander.h2h.monitoreo.service;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.constants.ReportConstants;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.util.Util;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRParameter;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRRtfExporter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleWriterExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;

/**
 * Servicio para la generación de reportes en formato pdf, excel y rft ademas
 * permite poder realizar el procesamiento para generar los reportes y tambien
 * permite poder eliminar el reporte que se creo de forma temporal
 *
 * @author Paul Quintero
 * @since 23/05/22
 */
@Slf4j
@Service
public class JasperReportService implements IJasperReportService {

	/**
	 * Metodo para obtener el pdf con su metadato
	 *
	 * @param jasperName Nombre del archivo jasper report
	 * @param params     Map con listado de parametros para llenar jasper report
	 * @param dataSet    Registro para llenar el listado del jasper report
	 * @return ReportResponse contiene el pdf generado y su metadato
	 * @throws IOException excepcion de entrada informacion
	 * @throws JRException excepcion al generar el jasper
	 */
	@Override
	public ReportResponse getPdf(String jasperName, Map<String, Object> params, List<?> dataSet) {
		log.info(MessageFormat.format("Generar reporte en pdf: {0}", jasperName));
		params.put(JRParameter.IS_IGNORE_PAGINATION, false);
		JasperPrint jasperprint = this.fillReport(jasperName, params, dataSet);
		byte[] pdf = new byte[10];
		try {
			log.info("Se obtienen los bytes del reporte en pdf");
			pdf = JasperExportManager.exportReportToPdf(jasperprint);
		} catch (JRException e) {
			log.info("Error getPdf: " + e.getMessage(), e);
			throw new BusinessException(e.getMessage());
		}
		return new ReportResponse(this.convertBase64(pdf), pdf.length,
				this.getNameReport(this.removeJasperExtention(jasperName), ReportConstants.PDF_EXTENTION),
				MediaType.APPLICATION_PDF_VALUE);
	}

	/**
	 * Metodo para obtener el excel con su metadato
	 *
	 * @param jasperName Nombre del archivo jasper report
	 * @param params     Map con listado de parametros para llenar jasper report
	 * @param dataSet    Registro para llenar el listado del jasper report
	 * @return ReportResponse contiene el pdf generado y su metadato
	 * @throws IOException excepcion de entrada informacion
	 * @throws JRException excepcion al generar el jasper
	 */
	@Override
	public ReportResponse getXls(String jasperName, Map<String, Object> params, List<?> dataSet) {
		log.info(MessageFormat.format("Generar reporte en excel: {0}", jasperName));
		params.put(JRParameter.IS_IGNORE_PAGINATION, true);
		JasperPrint jasperPrint = this.fillReport(jasperName, params, dataSet);
		log.info("Se define nombre de reporte");
		String cleanName = this.getNameReport(this.removeJasperExtention(jasperName), ReportConstants.XLSX_EXTENTION);
		log.info("Nombre de reporte: " + cleanName);
		byte[] xls = new byte[10];
		try {
			log.info("Se inicia la exportacion del archivo xls");
			xls = this.exportXls(jasperPrint);
		} catch (JRException | IOException e) {
			log.info("Error getXls: " + e.getMessage(), e);
			throw new BusinessException(e.getMessage());
		}
		return new ReportResponse(this.convertBase64(xls), xls.length, cleanName,
				MediaType.APPLICATION_OCTET_STREAM_VALUE);
	}

	@Override
	/**
	 * Metodo para poder generar el reporte pero en formato rft
	 *
	 * @param jasperName Nombre del archivo jasper report
	 * @param params     Map con listado de parametros para llenar jasper report
	 * @param dataSet    Registro para llenar el listado del jasper report
	 *
	 * @return ReportResponse contiene el pdf generado y su metadato
	 */
	public ReportResponse getRtf(String jasperName, Map<String, Object> params, List<?> dataSet) {
		log.info(MessageFormat.format("Generar reporte en rtf: {0}", jasperName));
		params.put(JRParameter.IS_IGNORE_PAGINATION, true);
		JasperPrint jasperPrint = this.fillReport(jasperName, params, dataSet);
		String cleanName = this.getNameReport(this.removeJasperExtention(jasperName), ReportConstants.RTF_EXTENTION);
		byte[] rtf = new byte[10];
		try {
			log.info("Se inicia la exportacion del archivo xls");
			rtf = this.exportRtf(jasperPrint);
		} catch (JRException | IOException e) {
			log.info("Error getRtf: " + e.getMessage(), e);
			throw new BusinessException(e.getMessage());
		}
		return new ReportResponse(this.convertBase64(rtf), rtf.length, cleanName,
				MediaType.APPLICATION_OCTET_STREAM_VALUE);
	}

	/**
	 * Metodo para llenar un reporte y retonar un objeto para su retulización en
	 * diferentes extensiones
	 *
	 * @param jasperName Nombre del archivo jasper report
	 * @param params     Map con listado de parametros para llenar jasper report
	 * @param dataSet    Registro para llenar el listado del jasper report
	 * @return JasperPrint - jasper generado listo para realizar la impresión en
	 *         diferentes formatos
	 * @throws IOException excepcion de entrada informacion
	 * @throws JRException excepcion al generar el jasper
	 */
	private JasperPrint fillReport(String jasperName, Map<String, Object> params, List<?> dataSet) {
		JasperPrint jasperPrint = null;
		try {
			log.info("Metodo para realizar la conversion a jaspert");
			StringBuilder reportPath = new StringBuilder(ReportConstants.REPORTS_FOLDER).append(jasperName);
			log.info("Se define el path del reporte: " + reportPath);
			ClassPathResource dirRepor = new ClassPathResource(reportPath.toString());
			log.info("Se obtiene el pathresource del directorio : " + reportPath);
			ClassPathResource pathLogo = new ClassPathResource(ReportConstants.SANTANDER_LOGO);
			log.info("Se obtiene el pathresource del logo santander : " + ReportConstants.SANTANDER_LOGO);
			try {
				params.put(ReportConstants.PARAM_LOGO_SATANDER, pathLogo.getURL().toString());
				log.info("Se define el parametro logo");
			} catch (IOException e1) {
				log.info("Error fillReport Path: " + e1.getMessage(), e1);
				throw new BusinessException(e1.getMessage());
			}
			InputStream jasperStream;
			try {
				log.info("Se inicia llenado de reporte");
				jasperStream = dirRepor.getInputStream();
				log.info("Se obtiene el inputstream");
				JasperReport jasperReport = (JasperReport) JRLoader.loadObject(jasperStream);
				log.info("Se carga el jasper del reporte");
				if(dataSet.isEmpty()) {
					jasperPrint = JasperFillManager.fillReport(jasperReport, params, new JREmptyDataSource());
				}else{
					JRBeanCollectionDataSource ds = new JRBeanCollectionDataSource(dataSet);
					jasperPrint = JasperFillManager.fillReport(jasperReport, params, ds);
				}
				log.info("Se llena el reporte");
				log.info("Se termina de llenar el reporte");
			} catch (Exception e) {
				log.info("Error fillReport: " + e.getMessage(), e);
				throw new BusinessException(e.getMessage());
			}
		} catch (Exception e) {
			log.info("Error general en el llenado del reporte: " + e.getMessage(), e);
			
		}
		return jasperPrint;
	}

	/**
	 * Convierte un arreglo de bytes en una cadena base64
	 *
	 * @param file arreglo de bytes con el archivo
	 * @return cadena en base64
	 */
	private String convertBase64(byte[] file) {
		return Base64.getEncoder().encodeToString(file);
	}

	/**
	 * Metodo para obhtener el nombre del reporte
	 *
	 * @param name      nombre del archivo
	 * @param extention nombre de la extensión del archivo
	 * @return nombre del archivo generado
	 */
	private String getNameReport(String name, String extention) {
		StringBuilder nameReport = new StringBuilder();
		if( name.contains("rptHistorialOper" ) ) {
			final SimpleDateFormat formatoDeFecha = new SimpleDateFormat("dd-MM-yyyy hh_MM", Locale.getDefault());
			nameReport.append("HistorialOperaciones ")
				.append(formatoDeFecha.format(Util.getCurrentDate().getTime())  );
		} else {
			nameReport.append(name)
				.append(Util.getCurrentDate().getTime());
		}
		nameReport.append(extention);
		return nameReport.toString();
	}

	/**
	 * Metodo para remover la extensión .jasper
	 *
	 * @param name nombre completo del jasper report con extensión .jasper
	 * @return nombre sin extension .jasper
	 */
	private String removeJasperExtention(String name) {
		return name.substring(0, name.indexOf(ReportConstants.JASPER_EXTENTION)).trim();
	}

	/**
	 * Metodo para exportar un reporte en formato Excel (XLS)
	 *
	 * @param jasper - objeto de jasperPrint para realizar su conversión a excel
	 * @param name   nombre del reporte
	 * @return arreglo de bytes con el archivo
	 * @throws IOException excepcion de entrada informacion
	 * @throws JRException excepcion al generar el jasper
	 */
	private byte[] exportXls(JasperPrint jasper) throws JRException, IOException {
		log.info("Metodo para exportar el archivo xls");
		byte[] xlsExported = {};
		ByteArrayOutputStream stream = new ByteArrayOutputStream();

		JRXlsxExporter exporter = new JRXlsxExporter();
		exporter.setExporterInput(new SimpleExporterInput(jasper));
		exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(stream));

		log.info("Se definen  propiedades de exportacion de excel");
		SimpleXlsxReportConfiguration reportConfig = new SimpleXlsxReportConfiguration();
		reportConfig.setSheetNames(new String[] { "Hoja" });

		log.info("Se define configuracion de propiedades del reporte");
		exporter.setConfiguration(reportConfig);
		exporter.exportReport();
		log.info("Se exporto correctamente el archivo");
		xlsExported = stream.toByteArray();
		log.info("Se cerro el archivo archivo");
		return xlsExported;
	}

	/**
	 * deleteFile Metodo para eliminar el archivo generado
	 *
	 * @param name nombre del jasper report sin extension
	 * @throws IOException excepcion de entrada informacion
	 */
	@Override
	public void deleteFile(String name) {
		ClassPathResource dirReport = new ClassPathResource(ReportConstants.REPORTS_FOLDER);
		StringBuilder reportPath;
		try {
			reportPath = new StringBuilder(dirReport.getURL().getPath()).append(name);
			File xls = new File(reportPath.toString());
			Files.deleteIfExists(xls.toPath());
		} catch (IOException e) {
			log.info("Error deleteFile: " + e.getMessage(), e);
			throw new BusinessException(e.getMessage());
		}

	}

	/**
	 * Metodo para exportar un reporte en formato Excel (XLS)
	 *
	 * @param jasper - objeto de jasperPrint para realizar su conversión a excel
	 * @param name   nombre del reporte
	 * @return arreglo de bytes con el archivo
	 * @throws IOException excepcion de entrada informacion
	 * @throws JRException excepcion al generar el jasper
	 */
	public byte[] exportRtf(JasperPrint jasper) throws JRException, IOException {
		log.info(MessageFormat.format("Generar reporte en getRtf: {0}", jasper));
		byte[] xlsExported = null;
		ByteArrayOutputStream stream = new ByteArrayOutputStream();

		JRRtfExporter exporter = new JRRtfExporter();
		exporter.setExporterInput(new SimpleExporterInput(jasper));
		exporter.setExporterOutput(new SimpleWriterExporterOutput(stream));
		exporter.exportReport();

		xlsExported = stream.toByteArray();

		return xlsExported;
	}

}
