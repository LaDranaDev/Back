package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;

/**
 * Repositorio para detalle de las operaciones ImpuFede
 */
public interface IOperationsDetailImpFedRepository {

    /**
     * Obtiene el detalle de la operacion
     * @param idOperacion - ID de operacion
     * @return Detalle de la operacion
     */
    OperationsMonitorQueryResponse obtenerDetalleOperacion(String idOperacion);

}
