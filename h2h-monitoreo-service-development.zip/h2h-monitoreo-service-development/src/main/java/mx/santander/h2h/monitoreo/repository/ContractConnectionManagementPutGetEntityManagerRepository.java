package mx.santander.h2h.monitoreo.repository;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.PersistenceException;
import jakarta.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.request.PutGetRequest;
import mx.santander.h2h.monitoreo.model.response.ProtocolResponse;
import mx.santander.h2h.monitoreo.model.response.PutGetDto;
import mx.santander.h2h.monitoreo.model.response.PutGetServiceResponse;
import mx.santander.h2h.monitoreo.service.IContractConnectionManagementPutGetDeleteDataService;
import mx.santander.h2h.monitoreo.service.IContractConnectionManagementPutGetFindDataService;
import mx.santander.h2h.monitoreo.service.IContractConnectionManagementPutGetSaveDataService;
import mx.santander.h2h.monitoreo.service.IContractConnectionManagementPutGetUpdateDataService;
import mx.santander.h2h.monitoreo.util.ContractConnectionManagementPutGetMapping;

/**
 * Repository de operación de archivos PUT / GET de administración de conexión de contrato
 * @author sbautish
 *
 */
@Slf4j
@Repository
@Transactional
public class ContractConnectionManagementPutGetEntityManagerRepository implements IContractConnectionManagementPutGetEntityManagerRepository {

	@Autowired
	private IContractConnectionManagementPutGetFindDataService iContractConnectionManagementPutGetFindDataService;

	@Autowired
	private IContractConnectionManagementPutGetSaveDataService iContractConnectionManagementPutGetSaveDataService;

	@Autowired
	private IContractConnectionManagementPutGetUpdateDataService iContractConnectionManagementPutGetUpdateDataService;

	@Autowired
	private IContractConnectionManagementPutGetDeleteDataService iContractConnectionManagementPutGetDeleteDataService;

	@Autowired
	private ContractConnectionManagementPutGetMapping contractConnectionManagementPutGetMapping;
	@Autowired
	@PersistenceContext
	private EntityManager entityManager;

	/**
	 * Método para buscar archivos PUT / GET por idContrato
	 * 
	 */
	@Override
	public PutGetServiceResponse findPutGetFiles(PutGetRequest putGetRequest, Integer opcion) {

		StringBuilder queryFindPutGetFiles = new StringBuilder("SELECT PA.ID_PTCL_PARA, CAN.NOMBRE AS CANAL, PA.ID_PTCL, PA.ID_CNTR, PT.ID_PTCL_PATH, DECODE(PT.TIPO_PROC, 'G', PT.ORIG_PATH, ");
		queryFindPutGetFiles.append("PT.DEST_PATH) PATH, PT.REG_EXP AS PATRON, PT.TIPO_PROC AS TIPO, PT.BAND_ACTI, PA.HOST_IP_ADDR, PA.HOST_PORT, PA.HOST_USER_ID, PA.HOST_OS ");
		queryFindPutGetFiles.append("FROM H2H_MX_PTCL_PARA PA INNER JOIN H2H_PTCL CAN ON PA.ID_PTCL = CAN.ID_PTCL INNER JOIN H2H_MX_PTCL_PATH PT ON PA.ID_PTCL_PARA = PT.ID_PTCL_PARA ");
		queryFindPutGetFiles.append("WHERE PA.ID_CNTR = :idContrato ORDER BY PT.ID_PTCL_PATH, TIPO");

		Query putGetFilesResponse = entityManager.createNativeQuery(queryFindPutGetFiles.toString());

		putGetFilesResponse.setParameter("idContrato", putGetRequest.getIdContrato());

		List<Object[]> listPutGetFilesResponse = putGetFilesResponse.getResultList();

		return contractConnectionManagementPutGetMapping.mapFromPutGetFilesResponseToPutGetServiceResponse(listPutGetFilesResponse);
	}

	/**
	 * Método para agregar o modificar los protocolos PUT / GET
	 * 
	 */
	@Override
	public void insertPutGetProtocol(PutGetServiceResponse putGetServiceResponse, String numeroContrato) {

		if (StringUtils.isNotBlank(putGetServiceResponse.getIdProtocolo()) 
				&& (!putGetServiceResponse.getIdProtocolo().equals(putGetServiceResponse.getRegistrosPG().get(0).getIdProtocolo()))){

			iContractConnectionManagementPutGetDeleteDataService.eliminaInformacion(putGetServiceResponse);

			putGetServiceResponse.setIdPara(null);

		}

		BigDecimal idptclpara;
		String opcion="N";

		// Obetenemos primer ID
		if (StringUtils.isBlank(putGetServiceResponse.getIdPara())) {

			// Es registro nuevo
			idptclpara = iContractConnectionManagementPutGetFindDataService.findNextValue("SEQ_H2H_MX_PTCL_PARA");

		} else {

			idptclpara = BigDecimal.valueOf(Long.parseLong(putGetServiceResponse.getIdPara()));
			opcion="M";

		}

		log.info("Guarda H2H_MX_PTCL_PARA...");
		// Primer insert a H2H_MX_PTCL_PARA

		putGetServiceResponse.setLdapUser(numeroContrato + "PG");
		putGetServiceResponse.setLdapPwd(Long.toString(System.currentTimeMillis()) + numeroContrato);
		putGetServiceResponse.setKeystore(numeroContrato + "_KEY");

		iContractConnectionManagementPutGetSaveDataService.guardaPtclPara(idptclpara, putGetServiceResponse, opcion, numeroContrato);

		// Actualizar UIDLDAP

		log.debug("Guarda H2H_MX_PTCL_PATH PUT...");
		// Segundo insert a H2H_MX_PTCL_PATH

		iContractConnectionManagementPutGetSaveDataService.guardaPtclPath(putGetServiceResponse, idptclpara, numeroContrato, "P");
		log.debug("Guarda H2H_MX_PTCL_PATH GET...");
		iContractConnectionManagementPutGetSaveDataService.guardaPtclPath(putGetServiceResponse, idptclpara, numeroContrato, "G");

		iContractConnectionManagementPutGetSaveDataService.guardarParaCD(putGetServiceResponse, idptclpara, opcion);

		// Inicia grabado en LDAP si es creación
		log.debug("Grabado en LDAP si es nuevo");

		if(!putGetServiceResponse.getIdProtocolo().equals(putGetServiceResponse.getRegistrosPG().get(0).getIdProtocolo())){

			iContractConnectionManagementPutGetSaveDataService.guardaEnLDAP(putGetServiceResponse, numeroContrato);

		}

	}

	/**
	 * Actualiza los protocolos de PUT / GET
	 * 
	 */
	@Override
	public void updatePutGetProtocol(PutGetServiceResponse putGetServiceResponse, PutGetRequest putGetRequest) {

		log.info(Encode.forJava("Inicia modificarPutGet ".concat(putGetRequest.getNumeroContrato())));

		// Actualiza registros en H2H_MX_PTCL_PATH
		log.debug("modificarPutGet Actualiza H2H_MX_PTCL_PATH PUT...");

		iContractConnectionManagementPutGetUpdateDataService.actualizarPtclPath(putGetServiceResponse, putGetRequest, "P");

		iContractConnectionManagementPutGetUpdateDataService.actualizarPtclPath(putGetServiceResponse, putGetRequest, "G");

		//Actualizamos los registros en H2H_MX_PTCL_PARA
		log.debug("modificarPutGet Actualizamos H2H_MX_PTCL_PARA...");

//		agregaDatosLDAP(dto);

//		actualizaUIDLDAP(dto);

		iContractConnectionManagementPutGetUpdateDataService.actualizarPtclPara(putGetServiceResponse);

		//Actualizar SFTP o CD O WS
		iContractConnectionManagementPutGetUpdateDataService.actualizaParaSFTPCD(putGetServiceResponse);

//		if("5".equals(dto.getIdProtocolo())){
//
//			log.debug("Pista de auditoria para actualizacion H2H_MX_PARA_WS...");
//
//			BitacoraUtil.bitacora().grabaPistaString(ConstantesAuditoria.SERV_MOD_PUT_GET_WS, OperacionAuditoria.SERV_MOD_PUT_GET_WS.getIdCodigoOperacion().toString(), 
//					ConstantesAuditoria.TIPO_OPER_MOD, "H2H_MX_PARA_WS", CANAL_APP_ADMIN, new PutGetWSDTO(), dto.getPutGetDTO().getPutGetWSDTO(), String.valueOf(dto.getNumeroContrato()), 
//					architechBean, getLoggingBean());
//
//		}

		log.debug("modificarPutGet Actualizacion ok");

	}

	/**
	 * Obtiene los protocolos de archivos PUT
	 * 
	 */
	@Override
	public List<ProtocolResponse> getPutFilesProtocols() {

		String valorParamResult = getParameters("H2H_PROT_PUT_FILE");

		String[] arregloValorParamString = valorParamResult.split(",");

		StringBuilder queryProtocolo = new StringBuilder("SELECT ID_PTCL, NOMBRE FROM H2H_PTCL WHERE ID_PTCL IN (");
		queryProtocolo.append(StringUtils.join(Collections.nCopies(arregloValorParamString.length, " ? ").toArray(), ","));
		queryProtocolo.append(")");

		Query consultaProtocolos = entityManager.createNativeQuery(queryProtocolo.toString());

		Integer contador = 1;

		for (String valorParam : arregloValorParamString) {

			consultaProtocolos.setParameter(contador, Integer.valueOf(valorParam));

			contador++;

		}

		List<Object[]> listProtocols = consultaProtocolos.getResultList();

		return contractConnectionManagementPutGetMapping.mapFromListProtocolsToListProtocolsResponse(listProtocols);
	}

	/**
	 * Método para crear el query para la consulta de registros de put y get por numero de contrato
	 * 
	 * @param dtorequest con numero de contrato
	 * @param opcion opcion de busqueda
	 * @return cadena de query a ejecutar
	 */
	@Override
	public PutGetServiceResponse findPutGet(PutGetRequest putGetRequest, Integer option, PutGetServiceResponse putGetServiceResponse) {

		String idContrato = putGetRequest.getIdContrato();
		String idProtocoloPara = putGetRequest.getIdProtocoloPara();
		String idProtocoloPath2 = putGetRequest.getIdProtocoloPath2();
		String idProtocoloPath1 = putGetRequest.getIdProtocoloPath1();

		StringBuilder queryPutGet = new StringBuilder("SELECT PA.ID_PTCL_PARA, CAN.NOMBRE CANAL, PA.ID_PTCL, PA.ID_CNTR, PT.ID_PTCL_PATH, DECODE(PT.TIPO_PROC, 'G', PT.ORIG_PATH, PT.DEST_PATH) PATH, ");
		queryPutGet.append("PT.REG_EXP PATRON, PT.TIPO_PROC TIPO, PT.BAND_ACTI, PA.HOST_IP_ADDR, PA.HOST_PORT, PA.HOST_USER_ID, PA.HOST_OS FROM H2H_MX_PTCL_PARA PA ");
		queryPutGet.append("INNER JOIN H2H_PTCL CAN ON PA.ID_PTCL = CAN.ID_PTCL INNER JOIN H2H_MX_PTCL_PATH PT ON PA.ID_PTCL_PARA = PT.ID_PTCL_PARA ");

		if (option.equals(1)) {

			queryPutGet.append("WHERE PA.ID_CNTR = :idContrato ");

		} else if (option.equals(2)) {

			queryPutGet.append("WHERE PA.ID_CNTR = :idContrato ").append(" AND PA.ID_PTCL_PARA = :idProtocoloPara ");

			if (putGetRequest.getIdProtocoloPath1() != null && putGetRequest.getIdProtocoloPath2() != null) {

				queryPutGet.append("AND PT.ID_PTCL_PATH IN (:idProtocoloPath2, :idProtocoloPath1) ");

			}

		}

		queryPutGet.append("ORDER BY PT.ID_PTCL_PATH, tipo");

		Query putGetResult = entityManager.createNativeQuery(queryPutGet.toString());

		if (option.equals(1)) {

			putGetResult.setParameter("idContrato", idContrato);

		} else if (option.equals(2)) {

			putGetResult.setParameter("idContrato", idContrato);
			putGetResult.setParameter("idProtocoloPara", idProtocoloPara);
			putGetResult.setParameter("idProtocoloPath2", idProtocoloPath2);
			putGetResult.setParameter("idProtocoloPath1", idProtocoloPath1);

		}

		List<Object[]> putGetResponse = putGetResult.getResultList();

		putGetServiceResponse = contractConnectionManagementPutGetMapping.mapFromPutGetResponseToPutGetServiceResponse(putGetResponse, putGetServiceResponse);

		if (putGetServiceResponse != null && putGetServiceResponse.getRegistrosPG() != null && !putGetServiceResponse.getRegistrosPG().isEmpty()) {

			putGetServiceResponse.setHostOs(putGetServiceResponse.getHostOs());

			if ("A".equals(putGetRequest.getTipoOperPG())) {
				iContractConnectionManagementPutGetDeleteDataService.eliminaValoresnuevoReg(putGetServiceResponse);
			}

			putGetServiceResponse.setRegistrosPG(putGetServiceResponse.getRegistrosPG());

			if (putGetServiceResponse.getRegistrosPG().size() > 1 && putGetServiceResponse.getRegistrosPG().get(1) != null) {
				iContractConnectionManagementPutGetDeleteDataService.eliminaDatosSiEsAlta(putGetServiceResponse, putGetRequest.getTipoOperPG());
				putGetServiceResponse.setRegistrosPG(putGetServiceResponse.getRegistrosPG());
			}

		}

		return putGetServiceResponse;
	}

	/**
	 * Obtiene parámetros por nombre de parámetro
	 * 
	 */
	@Override
	public String getParameters(String nombreParam) {

		String valorParamResult = "0";

		try {

			StringBuilder queryParam = new StringBuilder("SELECT VALOR FROM H2H_PARAM WHERE NMBR_PARAM = :nombreParam");

			Query valorParam = entityManager.createNativeQuery(queryParam.toString());

			if (StringUtils.isNotBlank(nombreParam)) {
				valorParam.setParameter("nombreParam", nombreParam);
			}

			List<String> listaValorParamResult = valorParam.getResultList();

			if (!listaValorParamResult.isEmpty()) {

				valorParamResult = listaValorParamResult.get(0).toString();

			}

			log.info("Consultado el parametro {} ->  {}", Encode.forJava(nombreParam), Encode.forJava(valorParamResult));

		} catch (PersistenceException be) {

			log.info("No se puede obtener el parametro -> {} ", Encode.forJava(nombreParam));
			log.info(be.getMessage());

		}

		return valorParamResult;
	}

	@Override
	public String enableDisablePutGet(PutGetDto putGetDto) {

		String actualizaPutGet = "ERUPDPG1";

		try {

			StringBuilder query = new StringBuilder("UPDATE H2H_MX_PTCL_PATH SET BAND_ACTI = :estatus WHERE ID_PTCL_PATH = :idPtclPath AND ID_PTCL_PARA = :idPtclPara ");

			Query queryResult = entityManager.createNativeQuery(query.toString());

			queryResult.setParameter("estatus", putGetDto.getEstatus());
			queryResult.setParameter("idPtclPath", putGetDto.getIdPtclPath());
			queryResult.setParameter("idPtclPara", putGetDto.getIdPtclPara());

			Integer updatePutGet = queryResult.executeUpdate();

			if (updatePutGet != 0) {
				actualizaPutGet = "OKUPDPG";
			}

		} catch (BusinessException be) {

			actualizaPutGet = "ERUPDPG1";
			log.info(be.getMessage());

		}

		return actualizaPutGet;
	}

}
