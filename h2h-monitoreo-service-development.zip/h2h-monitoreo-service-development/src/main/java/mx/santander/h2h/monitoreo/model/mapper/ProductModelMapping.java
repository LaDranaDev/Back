package mx.santander.h2h.monitoreo.model.mapper;

import mx.santander.h2h.monitoreo.model.entity.ProductEntity;
import mx.santander.h2h.monitoreo.model.response.ProductResponse;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

/**
 * ProductModelMapping.
 * Mapea Objetos ProductResponse y Entidades segun corresponda.
 *
 * @author Jesus Soto Aguilar
 * @since 20/04/2023
 */
public final class ProductModelMapping implements Serializable {

    /**
     * Serial.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Constructor por defecto.
     */
    private ProductModelMapping(){}

    /**
     * Convierte una lista de tipo ProductEntity a una lista de tipo ProductResponse.
     * @param productosList Lista de tipo ProductEntity
     * @return Lista de tipo ProductResponse.
     */
    public static List<ProductResponse> mappingEntityListToDtoList(List<ProductEntity> productosList){
        return productosList.stream()
                .map(ProductModelMapping::mappingEntityToDto)
                .collect(Collectors.toList());
    }

    /**
     * Convierte un objeto de tipo ProductEntity a un objeto de tipo ProductResponse
     * @param productEntity Objeto de tipo ProductEntity
     * @return Objeto de tipo ProductResponse
     */
    public static ProductResponse mappingEntityToDto(ProductEntity productEntity){
        ProductResponse productResponse = null;
        if(productEntity != null){
            productResponse = ProductResponse.builder()
                    .idProducto(productEntity.getId())
                    .claveProducto(productEntity.getCveProdOper())
                    .descProducto(productEntity.getDescripcion())
                    .build();
        }
        return productResponse;
    }
}
