package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.constants.DetailVostroQueryConstants;
import mx.santander.h2h.monitoreo.constants.MonitorOperacionesConstants;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.util.DetalleOperacionUtils;
import mx.santander.h2h.monitoreo.util.UtilMapeoData;
import mx.santander.h2h.monitoreo.util.UtilsTramaAdicionales;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * OperationsDetailVostroRepository.
 *
 * @author Jesus Soto Aguilar
 */
@Repository
public class OperationsDetailVostroRepository implements IOperationsDetailVostroRepository {

    @Autowired
    private EntityManager entityManager;

    @Autowired
    private IParameterRepository parameterRepository;

    protected static final Map<String, String> tablas = new HashMap<>();

    /*
     * TCS (sonar)
     * Cambio de clase anonima por inicializacion en bloque estatico
     */
    static {
        tablas.put("01",MonitorOperacionesConstants.H2H_PROD_TRAN); /**SPEI*/
        tablas.put("97",MonitorOperacionesConstants.H2H_PROD_TRAN); /**TEF*/
        tablas.put("02",MonitorOperacionesConstants.H2H_PROD_TRAN); /**Nomina Interbancaria*/
        tablas.put("98","H2H_PROD_TRAN_MISM_BANC"); /**TMB*/
        tablas.put("99","H2H_PROD_NOMI_MISM_BANC"); /**Nomina Mismo Banco*/
        tablas.put("91","H2H_PROD_ALTA_PAGO"); /**ALTA PAGO PROVEEDORES CONFIRMING*/
        tablas.put("80","H2H_PROD_ORDN_PAGO"); /**ORDEN DE PAGO	*/
        tablas.put("95","H2H_ACTA_BENI"); /**Alta Cuenta Beneficiarias*/
        tablas.put("96","H2H_ACTA_BENI"); /**Alta Cuenta Beneficiarias*/
        tablas.put("81","H2H_PROD_ORDN_PAGO"); /**ORDEN DE PAGO CANCELADO*/
        tablas.put("93","H2H_PROD_ALTA_EMPL"); /**ALTA MASIVA EMPLEADOS*/
        tablas.put("135","H2H_PROD_MANTTO_PROV_TRAN"); /**MTTO PROVEEDORES DE CONFIRMING**/
        tablas.put("23","H2H_PROD_APO_OBRE_PATR");
        tablas.put("21","H2H_PROD_IMPU_FEDE");
        tablas.put("22","H2H_PROD_PAGO_REFE");
        tablas.put("36","H2H_MX_PROD_PAGO_TDC"); /**Pago a TDC Santander*/
        tablas.put("54","H2H_MX_PROD_CARD_CHECK");
        tablas.put("40","H2H_MX_PROD_PAGO_DIR"); //PGODIRECT
        tablas.put("32", "H2H_MX_PROD_TRAN_INTN");//Transferencias internacionales Cambiarias
        tablas.put("38", "H2H_MX_PROD_TVIB");//Transferencias Vostro Interbancarias
        tablas.put("39", "H2H_MX_PROD_TVMB");//Transferencias Vostro Mismo Banco
        tablas.put("85", "H2H_MX_PROD_ORDN_PAGO_ATM");//Ordenes de pago ATM
        tablas.put("41",MonitorOperacionesConstants.H2H_PROD_TRAN); /**SPEI ONLINE*/
        tablas.put("47",MonitorOperacionesConstants.H2H_PROD_TRAN); /**TEF ONLINE*/
        tablas.put("42",MonitorOperacionesConstants.H2H_PROD_TRAN); /**Nomina Interbancaria ONLINE*/
        tablas.put("48","H2H_PROD_TRAN_MISM_BANC"); /**TMB ONLINE*/
        tablas.put("49","H2H_PROD_NOMI_MISM_BANC"); /**Nomina Mismo Banco ONLINE*/
    }

    @Override
    public OperationsMonitorQueryResponse obtenerDetalleOperacion(String view, String idOperacion) {
        String stringQuery = generaConsultaDetalleOperacion(view, idOperacion);
        Query query = entityManager.createNativeQuery(stringQuery, Tuple.class);
//        query.setParameter("idOperacion", idOperacion);

        OperationsMonitorQueryResponse respuesta = new OperationsMonitorQueryResponse();
        respuesta.setProducto("OPERACION_EN_PROCESO");
        for (Object obj : query.getResultList()) {
            if (obj instanceof Tuple) {
                Tuple tuple = (Tuple) obj;
                Map<String, Object> row = new HashMap<>();
                tuple.getElements().forEach(t -> row.put(t.getAlias(), tuple.get(t)));
                rellenaRespuestaMonitorOperacionesDTO(row, respuesta);
            }
        }

        if ("OPERACION_EN_PROCESO".equals(respuesta.getProducto())){
            respuesta.setMensaje(getH2HMensaje(idOperacion));
        }

        return respuesta;
    }

    private String generaConsultaDetalleOperacion(String view, String idOperacion) {
        StringBuilder query = new StringBuilder();
        query.append(DetailVostroQueryConstants.SELECT);
        query.append(getQueryFromView(view));
        query.append(getFromTran(false,view));
        query.append(DetailVostroQueryConstants.UNION);
        query.append(getQueryFromView(view));
        query.append(getFromTran(true,view));
        query.append(DetailVostroQueryConstants.ID_REG_EQ);
        query.append(idOperacion);

        return query.toString();
    }

    private String getQueryFromView(String view) {
        String selectCampos = "";

        if(view.equals((parameterRepository.findByName("CVE_PROD_TRANINTCAMB").getValue()))){
            selectCampos = DetailVostroQueryConstants.QUERY;
        } else if(view.equals((parameterRepository.findByName("CVE_PROD_VOSTRO_INT").getValue()))){
            selectCampos = DetailVostroQueryConstants.QUERY_VOSTRO_INT;
        }else if(view.equals((parameterRepository.findByName("CVE_PROD_VOSTRO_MB").getValue()))){
            selectCampos = DetailVostroQueryConstants.QUERY_VOSTRO_MB;
        }

        return selectCampos;
    }

    /**
     * get From si es tran o no
     * @param tran
     * @param view
     * @return
     */
    private String getFromTran(boolean tran,String view) {
        StringBuilder from= new StringBuilder(" FROM ");
        from.append(tablas.get(view));
        if(tran){
            from.append(String.format(DetailVostroQueryConstants.FROM_TRAN, DetailVostroQueryConstants.GUION_TRAN,
                    DetailVostroQueryConstants.GUION_TRAN, DetailVostroQueryConstants.GUION_TRAN));
        }else{
            from.append(String.format(DetailVostroQueryConstants.FROM_TRAN," "," "," "));
        }
        if("38".equals(view)){
            from.append("  left join H2H_CAT_BNCO banc on DETA.COD_INT_REC=banc.CLAVE_BANCO  and banc.band_activo=1   ");
        }
        return from.toString();
    }

    private void rellenaRespuestaMonitorOperacionesDTO(Map<String, Object> row, OperationsMonitorQueryResponse respuesta) {
        DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols();
        formatSymbols.setDecimalSeparator('.');
        formatSymbols.setGroupingSeparator(',');
        final DecimalFormat decimalFormat = new DecimalFormat("###,###,###,###,##0.00", formatSymbols);

        respuesta.setIdOperacion(DetalleOperacionUtils.defaultObjectString(row.get("ID_REG"), "0"));
        respuesta.setCodCli(Objects.toString(row.get("BUC"), "").trim());
        respuesta.setCtaCargo(Objects.toString(row.get("NUM_CTA_CARGO"), "").trim());
        respuesta.setCtaAbono(Objects.toString(row.get("NUM_CTA_ABONO"), "").trim());
        // Enmascaramos la Cuenta
        respuesta.setCtaAbono(UtilMapeoData.getMascara(respuesta.getCtaAbono(), "abono"));
        
        respuesta.setIdProducto(DetalleOperacionUtils.defaultObjectString(row.get("CVE_PROD_OPER"), "0"));
        respuesta.setProducto(Objects.toString(row.get("DESC_PROD"), "").trim());
        respuesta.setNomArch(Objects.toString(row.get("NOMBRE_ARCH"), "").trim());

        respuesta.setReferencia(DetalleOperacionUtils.defaultObjectString(row.get("REFERENCIA"), ""));
        respuesta.setEstatus(Objects.toString(row.get("DESC_ESTATUS"), "").trim());
        respuesta.setImporte("$" + decimalFormat.format(Double.valueOf(DetalleOperacionUtils.defaultObjectString(row.get("IMPORTE"), "0.00"))));
        respuesta.setImporteCargo("$" + decimalFormat.format(Double.valueOf(DetalleOperacionUtils.defaultObjectString(row.get("IMPORTE_CARGO"), "0.00"))));
        respuesta.setComentario1(Objects.toString(row.get("CLAVE_DESE"), "").trim());
        respuesta.setComentario2(Objects.toString(row.get("TIPO_CAMBIO"), "").trim());
        respuesta.setComentario3(Objects.toString(row.get("COMENTARIO_1"), "").trim());

        respuesta.setDivisa(Objects.toString(row.get("DIVISA"), "").trim());
        if (MonitorOperacionesConstants.MN.equals(respuesta.getDivisa().trim()) || MonitorOperacionesConstants.MXN.equals(respuesta.getDivisa().trim())){
            respuesta.setDivisa(MonitorOperacionesConstants.MXP);
        }
        respuesta.setDivisaOrd(Objects.toString(row.get("DIVISA_ORD"), "").trim());
        if (MonitorOperacionesConstants.MN.equals(respuesta.getDivisaOrd().trim()) || MonitorOperacionesConstants.MXN.equals( respuesta.getDivisaOrd().trim())){
            respuesta.setDivisaOrd(MonitorOperacionesConstants.MXP);
        }

        respuesta.setFechaAplic(UtilsTramaAdicionales.getFecha(row.get("FECHA_APLICACION")));
        respuesta.setFechaCaptura(UtilsTramaAdicionales.getFecha(row.get("FECHA_REGISTRO")));
        respuesta.setFechaLimitPago(UtilsTramaAdicionales.getFecha(row.get("FECHA_LIMITE_PAGO")));
        respuesta.setFechaOper(UtilsTramaAdicionales.getFecha(row.get("FECHA_OPERACION")) );
        respuesta.setFechaPresIni(UtilsTramaAdicionales.getFecha(row.get("FECHA_PRESENTACION_INICIAL")) );
        respuesta.setNombreOrd(Objects.toString(row.get("TITULAR"), ""));
        respuesta.setIntermOrd(Objects.toString(row.get("INTERMEDIARIO_ORD"), "").trim());
        respuesta.setIntermRec(Objects.toString(row.get("INTERMEDIARIO_REC"), "").trim());
        respuesta.setNombreBenef(Objects.toString(row.get("BENEFICIARIO"), "").trim());
        respuesta.setNumSucursal(Objects.toString(row.get("NUM_SUCURSAL"), "").trim());
        respuesta.setFechaVenc(UtilsTramaAdicionales.getFecha(row.get("FECH_VENC")));
        respuesta.setNumOrden(Objects.toString(row.get("NUM_ORDEN"), "").trim());
        respuesta.setTipoPago(Objects.toString(row.get("TIPO_PAGO"), "").trim());
        respuesta.setNumeMovil(null);
        respuesta.setBancoReceptor(DetalleOperacionUtils.defaultObjectString(row.get("BANCO_RECEPTOR"), ""));
        respuesta.setBancoOrdenante("BANCO SANTANDER (MÉXICO) S.A.");
        respuesta.setMensaje(Objects.toString(row.get("MSG_H2H"), "").trim());
        respuesta.setIdEstatus(DetalleOperacionUtils.defaultObjectString(row.get("ID_ESTATUS"), "0"));
        respuesta.setMensajeOrden(DetalleOperacionUtils.defaultObjectString(row.get("MSG_ORDEN_PAGO"), "0"));
        respuesta.setReferenciaAbono(Objects.toString(row.get("REFERENCIA_ABONO"), "").trim());
        respuesta.setReferenciaCargo(Objects.toString(row.get("REFERENCIA_CARGO"), "").trim());
        respuesta.setNumEmpleado(Objects.toString(row.get("NUMERO_EMPLEADO"), "").trim());
        respuesta.setBucEmpleado(Objects.toString(row.get("BUC_EMPLEADO"), "").trim());
        respuesta.setRfc(Objects.toString(row.get("RFC"), "").trim());
        respuesta.setNumTarjeta(Objects.toString(row.get("NUMERO_TARJETA"), "").trim());
        respuesta.setNumTarjetaAct(Objects.toString(row.get("NUMERO_TARJETA_ACT"), "").trim());
        respuesta.setNumeroCuenta(Objects.toString(row.get("NUMERO_CUENTA"), "").trim());
        respuesta.setDescripcion(Objects.toString(row.get("DESCRIPCION"), "").trim());
        respuesta.setNumConvenio(row.containsKey("REF_CVE_RSTO") ? Objects.toString(row.get("REF_CVE_RSTO"), "").trim() : "");
        // Enmascaramos las Tarjetas
        respuesta.setNumTarjeta( UtilMapeoData.getMascara(respuesta.getNumTarjeta(), "tarjeta") );
        respuesta.setNumTarjetaAct( UtilMapeoData.getMascara(respuesta.getNumTarjetaAct(), "tarjeta") );
    }

    private String getH2HMensaje(String idOperacion) {
    	final StringBuilder query = new StringBuilder();
    	query.append("SELECT MSG_H2H FROM H2H_MSG INNER JOIN H2H_REG USING(ID_MSG) WHERE ID_REG = ")
    			.append(idOperacion)
    			.append(" UNION ALL ")
    			.append("SELECT MSG_H2H FROM H2H_MSG INNER JOIN H2H_REG_TRAN USING(ID_MSG) WHERE ID_REG = ")
    			.append(idOperacion);

        Query nativeQuery = entityManager.createNativeQuery(query.toString(), Tuple.class);
//        nativeQuery.setParameter("idOperacion", idOperacion);

        for (Object obj : nativeQuery.getResultList()) {
            if (obj instanceof Tuple) {
                Tuple tuple = (Tuple) obj;
                return Objects.toString(tuple.get("MSG_H2H"), "");
            }
        }

        return null;
    }

}
