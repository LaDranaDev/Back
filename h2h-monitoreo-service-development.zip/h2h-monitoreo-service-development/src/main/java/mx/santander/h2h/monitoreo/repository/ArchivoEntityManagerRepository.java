package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.constants.ArchivosConstants;
import mx.santander.h2h.monitoreo.model.response.ArchivoDetalleResponse;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;

import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * EntityManager para el Tracking de Archivos
 *
 * @author Daniel Ruiz
 * @since 19/04/2023
 */
@Repository
public class ArchivoEntityManagerRepository implements IArchivoEntityManagerRepository {

	@Autowired
    private EntityManager entityManager;

    /**
     * Obtiene el detalle del archivo de acuerdo al estatus
     * @param fecha LocalDate
     * @param codCliente String
     * @param codEstatus String
     * @param nomArch String
     * @return Lista con los beans de resultado
     */
    @Override
    public List<ArchivoDetalleResponse> detalleArchivos(
            String fecha,
            String codCliente,
            String nomArch,
            Integer codEstatus
    ) {
        Map<String, Object> params = new HashMap<>();
        String queryDetalle = queryDetalle(fecha, codCliente, nomArch, codEstatus, params);
        Query query = entityManager.createNativeQuery(queryDetalle, Tuple.class);
        params.forEach(query::setParameter);
        List<?> result = query.getResultList();
        return mapResultToResponseList(result);
    }

    /**
     * Obtiene el query Detalle.
     * @param fecha LocalDate
     * @param codCliente String
     * @param nomArch String
     * @param codEstatus Integer
     * @param params Map<String, Object>
     * @return String
     */
    private String queryDetalle(
            String fecha,
            String codCliente,
            String nomArch,
            Integer codEstatus,
            Map<String, Object> params
    ) {
        StringBuilder sql = new StringBuilder();
        sql.append(" ")
                .append("SELECT ")
                .append("A.ID_ARCHIVO,")
                .append("A.NOMBRE_ARCH,A.FECHA_REGISTRO FECHA_ORDER,")
                .append("TO_CHAR(A.FECHA_REGISTRO,'dd/mm/yyyy hh24:mi:ss') FECHA_REGISTRO,")
                .append("A.ID_ESTATUS,")
                .append("B.DESC_ESTATUS,")
                .append("C.ID_PROD,")
                .append("C.DESC_PROD,")
                .append(" H2H_CAT_CANL.NOMB_CANL, ")
                .append(" MSG_H2H MOTI_RECH, ")
                .append("SUM (NVL(D.TOTA_OPER,0)) AS TOTAL_OPER,")
                .append("SUM (NVL(D.TOTA_MONT,0)) AS TOTAL_MONT ")
                .append("FROM H2H_ARCHIVO_TRAN A ")
                .append("LEFT  JOIN H2H_ARCH_PROD_TRAN D ON D.ID_ARCHIVO = A.ID_ARCHIVO ")
                .append("INNER JOIN  H2H_CAT_ESTATUS B ON B.ID_CAT_ESTATUS  =  A.ID_ESTATUS ")
                .append("INNER JOIN H2H_PARAM P ")
                .append("ON P.VALOR = A.ID_ESTATUS ")
                .append("AND P.NMBR_PARAM LIKE 'TRCKNG_ESTATUS_%' ")
                .append("INNER JOIN H2H_CNTR E  ON  E.ID_CNTR = A.ID_CNTR ")
                .append("INNER JOIN H2H_CLTE F ON  F.ID_CLTE =  E.ID_CLTE ")
                .append("LEFT JOIN H2H_CAT_PROD C ON C.CVE_PROD_OPER = D.CVE_PROD_OPER ")
                .append("INNER JOIN H2H_CAT_CANL ")
                .append("ON H2H_CAT_CANL.ID_CANL = A.ID_CANL ")
                .append("LEFT JOIN H2H_MSG MSG ")
                .append("ON MSG.ID_MSG = A.ID_MSG ")
                .append("WHERE ")
                .append("F.BUC = :codCliente ");
        params.put("codCliente", codCliente);
        if (StringUtils.isNotBlank(nomArch)) {
            sql.append(" AND A.NOMBRE_ARCH LIKE '%' || :nomArch || '%' ");
            params.put("nomArch", nomArch);
        }
        agregarRestriccionEstatus(sql, codEstatus);
        sql.append(" GROUP BY ")
                .append("A.ID_ARCHIVO,")
                .append("A.NOMBRE_ARCH, ")
                .append("A.FECHA_REGISTRO, ")
                .append("A.ID_ESTATUS, ")
                .append("B.DESC_ESTATUS, ")
                .append("C.ID_PROD, ")
                .append("C.DESC_PROD, ")
                .append("H2H_CAT_CANL.NOMB_CANL,  ")
                .append(" MSG_H2H ");

        //IF-THEN Equivalente a metodo agregarRestriccionEstatus
        if (codEstatus == null || codEstatus == 3   || codEstatus <= 0) {
            sql.append(" UNION ALL ")
                    .append(" SELECT ID_ARCHIVO, NOMBRE_ARCH, MAX(FECHA_REGISTRO) FECHA_ORDER,")
                    .append("  TO_CHAR(MAX(FECHA_REGISTRO),'dd/mm/yyyy hh24:mi:ss') FECHA_REGISTRO, ")
                    .append("  ID_ESTATUS, DESC_ESTATUS, ID_PROD,  DESC_PROD,   NOMB_CANL,  MOTI_RECH,  ")
                    .append("  TOTAL_OPER, TOTAL_MONT FROM ( ")
                    .append("  SELECT 0 ID_ARCHIVO,   ar.NOMB_ARCH NOMBRE_ARCH,  ")
                    .append("   FECH_REG FECHA_REGISTRO,  16 ID_ESTATUS,  'RECHAZADO' DESC_ESTATUS, ")
                    .append(" 0 ID_PROD,  '' DESC_PROD,  d.NOMB_CANL NOMB_CANL, AR.MOTI_RECH, 0 TOTAL_OPER,  0 TOTAL_MONT  ")
                    .append("  FROM H2H_ARCH_RECH ar   ")
                    .append(" INNER JOIN H2H_CNTR  ON ar.ID_CNTR = H2H_CNTR.ID_CNTR  ")
                    .append(" INNER JOIN H2H_CLTE  ON H2H_CLTE.ID_CLTE      = H2H_CNTR.ID_CLTE   ")
                    .append(" INNER JOIN H2H_CAT_CANL  d      ")
                    .append(" ON d.ID_CANL = ar.ID_CANAL      ")
                    .append("  WHERE TRUNC(ar.FECH_REG) = to_date ( :fecha ,'dd/mm/yyyy')")
                    .append("  AND H2H_CLTE.BUC         = :codCliente ")
                    .append(" AND ar.MOTI_RECH        != 'Archivo Duplicado'");
            params.put("fecha", fecha);
            params.put("codCliente", codCliente);
            if (StringUtils.isNotBlank(nomArch)) {
                sql.append(" AND ar.NOMB_ARCH LIKE '%' || :nomArch || '%' ");
                params.put("nomArch", nomArch);
            }
            sql.append(" ) TMP  ")
                    .append("  GROUP BY ID_ARCHIVO, NOMBRE_ARCH, ID_ESTATUS, ")
                    .append(" DESC_ESTATUS, ID_PROD, DESC_PROD, TOTAL_OPER,TOTAL_MONT, NOMB_CANL, MOTI_RECH  ");
        }
        sql.append(" ORDER BY FECHA_ORDER DESC, ID_ARCHIVO ");
        return sql.toString();
    }

    /**
     * Agrega las restricciones por estatus.
     * @param sql Query base.
     * @param idEstatus estatus.
     */
    private void agregarRestriccionEstatus(final StringBuilder sql, Integer idEstatus) {
        if (sql != null && idEstatus != null && idEstatus > 0) {
            switch (idEstatus) {
                case 1: //DUPLICADO
                    sql.append(" AND P.DESRIPCION = 'DUPLICADO' ");
                    break;
                case 2: //RECIBIDO
                    sql.append(" AND P.DESRIPCION = 'RECIBIDO' ");
                    break;
                case 3: //RECHAZADO
                    sql.append(" AND P.DESRIPCION = 'RECHAZADO' ");
                    break;
                case 4: //VALIDADO
                    sql.append(" AND P.DESRIPCION = 'VALIDADO' ");
                    break;
                case 5: //ENVIADO CLIENTE
                    sql.append(" AND P.DESRIPCION = 'ENVIADO' ");
                    break;
                case 6: //EN PROCESO
                    sql.append(" AND P.DESRIPCION = 'PROCESO' ");
                    break;
                case 7: //EN ESPERA
                    sql.append(" AND P.DESRIPCION = 'ESPERA' ");
                    break;
                case 8: //PROCESADO
                    sql.append(" AND P.DESRIPCION = 'PROCESADO' ");
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * Map a Lista de detalle
     * @param datos List<?>
     * @return List<BeanProductoArchivo>
     */
    private List<ArchivoDetalleResponse> mapResultToResponseList(List<?> datos) {
        List<ArchivoDetalleResponse> listBean = new ArrayList<>();
        Integer idArchivoActual = -1;
        Integer idArchivoAnterior = -1;
        Integer numOp = 0;
        Integer estatus =0;
        String  motivo="";
        BigDecimal monto = new BigDecimal(0);
        for (Object object : datos) {
            if (!(object instanceof Tuple)) {
                continue;
            }
            Tuple row = (Tuple) object;
            ArchivoDetalleResponse bean = new ArchivoDetalleResponse();
            bean.setMontoFmt(String.valueOf(row.get("ID_ARCHIVO")));
            idArchivoActual = row.get("ID_ARCHIVO", BigDecimal.class).intValue();
            bean.setIdArchivo(idArchivoActual);
            bean.setNombreArchivo(String.valueOf(row.get("NOMBRE_ARCH")));
            bean.setFechaRecep(String.valueOf(row.get("FECHA_REGISTRO")));
            bean.setEstatus(String.valueOf(row.get("DESC_ESTATUS")));
            bean.setProducto(String.valueOf(row.get("DESC_PROD")));
            bean.setCanal(String.valueOf(row.get("NOMB_CANL")));
            bean.setTotalOperaciones(row.get("TOTAL_OPER", BigDecimal.class).intValue());
            bean.setMonto(row.get("TOTAL_MONT", BigDecimal.class));
            bean.setIdEstatus(row.get("ID_ESTATUS", BigDecimal.class).intValue());
            bean.setMotRechazo(String.valueOf(row.get("MOTI_RECH")));

            if (datos.indexOf(object) == 0) {
                numOp = bean.getTotalOperaciones();
                monto = bean.getMonto();
            }

            if (datos.indexOf(object) >= 1
                    && idArchivoActual != 0
                    && idArchivoActual.equals(idArchivoAnterior)) {
                numOp += bean.getTotalOperaciones();
                monto = monto.add(bean.getMonto());
                bean.setNombreArchivo(StringUtils.EMPTY);
                bean.setFechaRecep(StringUtils.EMPTY);
                bean.setEstatus(StringUtils.EMPTY);
                bean.setCanal(StringUtils.EMPTY);
            } else if (datos.indexOf(object) >= 1) {
                if(estatus==16){
                    //se agrega el motivo de rechazo para los archivos rechazados
                    addRechazo(listBean, motivo);
                }
                ArchivoDetalleResponse subTotal = new ArchivoDetalleResponse();
                subTotal.setProducto("TOTAL");
                subTotal.setTotalOperaciones(numOp);
                subTotal.setMonto(monto);
                listBean.add(subTotal);
                numOp = 0;
                monto = new BigDecimal(0);
                numOp += bean.getTotalOperaciones();
                monto = monto.add(bean.getMonto());
            }

            listBean.add(bean);
            idArchivoAnterior = idArchivoActual;
            estatus = bean.getIdEstatus();
            motivo = bean.getMotRechazo();
        }
        if (!listBean.isEmpty()) {
            if(estatus==16){
                //se agrega el motivo de rechazo para los archivos rechazados
                addRechazo(listBean, motivo);
            }
            ArchivoDetalleResponse subTotal = new ArchivoDetalleResponse();
            subTotal.setProducto("TOTAL");
            subTotal.setTotalOperaciones(numOp);
            subTotal.setMonto(monto);
            listBean.add(subTotal);
        }
        return verificarDetalleArchivos(listBean, estatus);
    }

    private void addRechazo(List<ArchivoDetalleResponse> listBean, String motivo ) {
        ArchivoDetalleResponse rechazo = new ArchivoDetalleResponse();
        rechazo.setProducto(motivo);
        listBean.add(rechazo);
    }

    private List<ArchivoDetalleResponse> verificarDetalleArchivos(List<ArchivoDetalleResponse> detalle, Integer estatus)  {

        if (detalle.isEmpty()){
            return detalle;
        }

        final String primerArchivoLista = detalle.get(0).getMontoFmt();

        List<Tuple> archivoIni = detalleArchivo(primerArchivoLista);
        int con = 0;
        while(!"TOTAL".equals((detalle.get(con++).getProducto())));
        con--;
        if (con < archivoIni.size()){
            detalle.get(0).setNombreArchivo(StringUtils.EMPTY);
            detalle.get(0).setFechaRecep(StringUtils.EMPTY);
            detalle.get(0).setEstatus(StringUtils.EMPTY);
            BigDecimal montoTotal = new BigDecimal(0);
            int totalOpers = 0;
            for (Tuple prod : archivoIni) {
                montoTotal = montoTotal.add(prod.get("TOTAL_MONT", BigDecimal.class));
                totalOpers += prod.get("TOTAL_OPER", BigDecimal.class).intValue();
            }
            detalle.get(con).setMonto(montoTotal);
            detalle.get(con).setTotalOperaciones(totalOpers);
        }

        String ultimoArchivoLista ="";
        if(estatus == 16 )
            ultimoArchivoLista = detalle.get(detalle.size() - 3).getMontoFmt();
        else
            ultimoArchivoLista = detalle.get(detalle.size() - 2).getMontoFmt();
        List<Tuple> archivoFin = detalleArchivo(ultimoArchivoLista);
        int productosoDelArchivo = 0;
        for (ArchivoDetalleResponse bean : detalle){
            if (ultimoArchivoLista.equals(bean.getMontoFmt())){
                productosoDelArchivo++;
            }
        }
        if (productosoDelArchivo < archivoFin.size() && !ultimoArchivoLista.equals(primerArchivoLista)){
            int index =  detalle.size() - 1;
            if(detalle.get(index).getNombreArchivo() == null
                    && detalle.get(index).getFechaRecep() == null
                    && detalle.get(index).getEstatus() == null ){
                detalle.remove(index);
            }
        }
        return detalle;
    }

    private List<Tuple> detalleArchivo(String idArchivo) {
        Query query = entityManager.createNativeQuery(ArchivosConstants.QUERY_DETALLE_ARCHIVO, Tuple.class);
        query.setParameter("idArchivo", idArchivo);
        List<?> result = query.getResultList();
        List<Tuple> ret = new ArrayList<>(result.size());
        result.forEach(r -> {
            if (r instanceof Tuple) ret.add((Tuple) r);
        });
        return ret;
    }

}
