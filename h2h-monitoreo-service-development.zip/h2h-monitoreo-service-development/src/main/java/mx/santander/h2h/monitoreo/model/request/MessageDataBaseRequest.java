package mx.santander.h2h.monitoreo.model.request;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MessageDataBaseRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -289479419019753541L;
	
	/** codeOperation. */
	private String codeOperation;
	
	/** typeOperation. */
	private String typeOperation;
	
	/** query. */
	private String query;

}
