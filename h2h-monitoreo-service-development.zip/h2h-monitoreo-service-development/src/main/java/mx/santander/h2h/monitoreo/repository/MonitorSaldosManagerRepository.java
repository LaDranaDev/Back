package mx.santander.h2h.monitoreo.repository;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import mx.santander.h2h.monitoreo.constants.MonitorSaldosConstants;
import mx.santander.h2h.monitoreo.model.request.MonitorSaldosRequest;

/**
 * MonitorSaldosRespository.
 * Define los metodos que permiten ejecutar las consultas del Monitor de Saldos.
 *
 * @author Jesus Soto Aguilar
 * @since 20/04/2023
 */
@Repository
public class MonitorSaldosManagerRepository implements IMonitorSaldosManagerRepository{

    /**
     * Objeto con la conexion a la base de datos.
     */
	@Autowired
    @PersistenceContext
    private EntityManager entityManager;

    /**
     * Consulta la informacion de los saldos reintentos.
     * @param request Objeto con los filtros para la consulta
     * @return Lista con la informacion de los saldos reintentos
     */
    public List<Tuple> getSaldosReintentosCliente(MonitorSaldosRequest request){
        Query query = entityManager.createNativeQuery(getSaldosReintentosQuery(request), Tuple.class);
        query.setParameter(MonitorSaldosConstants.CVE_CLIENTE_PARAM, request.getCodigoCliente());
        query.setParameter(MonitorSaldosConstants.FECHA_INICIO_PARAM, request.getFechaInicio());
        query.setParameter(MonitorSaldosConstants.FECHA_FIN_PARAM, request.getFechaFin());
        setOptionalParams(query, request);

        return query.getResultList();
    }

    /**
     * Consulta la informacion de los saldos reintentos de forma paginada.
     * @param request Objeto con los filtros para la consulta
     * @param pagination Objeto con los datos de paginacion
     * @return Pagina con informacion de los saldos reintentos
     */
    public Page<Tuple> getSaldosReintentosClientePaged(MonitorSaldosRequest request, Pageable pagination){

        Query query= entityManager.createNativeQuery(getSaldosReintentosQuery(request), Tuple.class);
        query.setParameter(MonitorSaldosConstants.CVE_CLIENTE_PARAM, request.getCodigoCliente());
        query.setParameter(MonitorSaldosConstants.FECHA_INICIO_PARAM, request.getFechaInicio());
        query.setParameter(MonitorSaldosConstants.FECHA_FIN_PARAM, request.getFechaFin());
        setOptionalParams(query, request);

        query.setFirstResult(pagination.getPageNumber() * pagination.getPageSize());
        query.setMaxResults(pagination.getPageSize());
        List<Tuple> saldoReintentos = query.getResultList();

        query.setFirstResult(0);
        query.setMaxResults(Integer.MAX_VALUE);
        Integer totalRows = query.getResultList().size();

        return new PageImpl<>(saldoReintentos, pagination, totalRows);
    }

    /**
     * Construye el query para consultar los saldos reintentos.
     * @param request Objeto con los filtros para la conulta
     * @return Query para consultar los saldos reintentos
     */
    private String getSaldosReintentosQuery(MonitorSaldosRequest request){
        StringBuilder queryBuilder = new StringBuilder();

        queryBuilder.append(createQuery(request, MonitorSaldosConstants.SUFIJO_TRAN));
        queryBuilder.append(MonitorSaldosConstants.UNION);
        queryBuilder.append(createQuery(request, MonitorSaldosConstants.NO_SUFIJO));
        queryBuilder.append(MonitorSaldosConstants.UNION);
        queryBuilder.append(createQuery(request, MonitorSaldosConstants.SUFIJO_HIST));
        queryBuilder.append(MonitorSaldosConstants.ORDER_BY_FECH_ORDEN);

        return queryBuilder.toString();
    }

    /**
     * Construye la consulta a las tablas generales, de transaccion y historica para la obtencion de los saldos.
     * @param request Objeto con los filtros para la consulta
     * @param sufijo Sufijo para definir la tabla para la creacion del query
     * @return Query para la consulta de saldos reintentos
     */
    private String createQuery(MonitorSaldosRequest request, String sufijo){
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append(MonitorSaldosConstants.LAYOUT_QUERY_SALDOS_REINTENTOS);

        if (StringUtils.isNotBlank(request.getNombreArchivo())) {
            sqlBuilder.append(MonitorSaldosConstants.NOMBRE_ARCHIVO_FILTER);
        }

        if (StringUtils.isNotBlank(request.getClaveProducto())) {
            sqlBuilder.append(MonitorSaldosConstants.CVE_PRODUCTO_FILTER);
        }
        return sqlBuilder.toString().replace(
                MonitorSaldosConstants.SUFIJO_REPLACE, sufijo);
    }

    /**
     * Agrega los valores para los filtros de la consulta.
     * Filtro por nombre archivo.
     * Filtro por clave producto.
     * @param query Query para la consulta de los saldos reintentos
     * @param request Objeto con los filtros para la consulta
     */
    private void setOptionalParams(Query query, MonitorSaldosRequest request){
        if (StringUtils.isNotBlank(request.getNombreArchivo())) {
            query.setParameter(MonitorSaldosConstants.NOMBRE_ARCHIVO_PARAM, "%" + request.getNombreArchivo() + "%");
        }

        if (StringUtils.isNotBlank(request.getClaveProducto())) {
            query.setParameter(MonitorSaldosConstants.CLAVE_PRODUCTO_PARAM, request.getClaveProducto());
        }
    }
}
