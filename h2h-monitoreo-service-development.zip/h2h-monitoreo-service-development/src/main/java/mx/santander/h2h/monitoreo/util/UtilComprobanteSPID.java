package mx.santander.h2h.monitoreo.util;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.List;

import jakarta.persistence.Tuple;

import org.apache.commons.lang.ObjectUtils;

import mx.santander.h2h.monitoreo.model.response.ComprobantesOperacionResponse;

import static mx.santander.h2h.monitoreo.util.UtilComprobante.agregaIdReg;

/**
 * @author fespinosa
 *
 */
public final class UtilComprobanteSPID {

    /**" UNION ALL "*/
    private static final String UNION_ALL=" UNION ALL ";
    
    /**
     * Obtiene el query de Transferencias Internacionales.
     *
     * @param listIds
     *            List<Integer>
     * @return String query
     */
    protected static String obtenerQuerySpid(List<Integer> listIds) {
        final StringBuilder sql = new StringBuilder()
                .append("SELECT tranin.ID_REG, cntr.NUM_CNTR CONTRATO, to_char(tranin.NUME_CUEN_ORDE) NUM_CTA_CARGO,tranin.NUME_CUEN_RECE NUN_CTA_ABONO,")
                .append("ct.DESC_PROD, tranin.IMPO_CARG IMPORTE,null REFERENCIA,CATDIVI.CLAV_CAPTA DIVISA,ce.DESC_ESTATUS,")
                .append("to_char(tranin.FECH_APLI,'dd/mm/yyyy')  FECH_APLI,tranin.NOMBRE_RECE BENEFICIARIO,null TIPO_PAGO,DECODE(cinf.NOMB_TITU,null,' ',cinf.NOMB_TITU) TITULAR,")
                .append("tranin.COME_1_CONC_PAGO CONCEPTO_PAGO,tranin.REFE_ENVI_OUT CLAVE_RASTREO,BNCO.NOMBRE_BANCO BANCO_RECEPTOR,r.FECH_ENVI_BACK FECHA_OPERACION,")
                .append("null CLAV_PROV,null NUM_DOCU,null FECH_VENCIMIENTO,null CVE_FORM_PAGO,'-'||trim(ct.CVE_PROD_OPER)||'-' ESTATUS_MOV, ")
                .append("null NUM_ORDEN,null FECHA_LIMITE_PAGO,null NUM_SUCURSAL, NULL  RAZON_SCIA,")
                .append(" null NOM_CLTE,")
                .append("clte.PERSONALIDAD, clte.RFC,cntr.NUM_CNTR,")
                .append("'0' CLAVE_BENEF,null ID_ESTA,null PERS_AUT,'' FORM_APLI, '' NOMB_RAZON_SOCI_PROV,'' RFC_PROV,")
                .append("null BANC_ABON,null REFE_ABON,to_char(tranin.REFE_OUT) TIPO_DOCU")
                .append(" FROM H2H_MX_PROD_SPID tranin ")
                .append(" INNER JOIN H2H_REG r ON r.id_reg = tranin.id_reg")
                .append(" INNER JOIN H2H_CAT_PROD ct ON r.cve_prod_oper = ct.cve_prod_oper")
                .append(" INNER JOIN H2H_ARCHIVO a ON r.id_arch = a.id_archivo")
                .append(" INNER JOIN H2H_CNTR cntr ON cntr.id_cntr = a.id_cntr")
                .append(" INNER JOIN H2H_CLTE clte ON cntr.id_clte = clte.id_clte")
                .append(" LEFT JOIN H2H_CAT_ESTATUS ce ON ce.id_CAT_estatus = r.id_estatus")
                .append(" LEFT JOIN H2H_CAT_BNCO BNCO ON tranin.CVE_INTER_RECE  = BNCO.CODI_TRAN AND BNCO.BAND_ACTIVO = 1 ")
                .append(" LEFT JOIN H2H_CTA_INFO cinf ON r.cnta_carg = cinf.NUME_CTA and cinf. TIPO_CTA='O' ")
                .append(" LEFT JOIN H2H_CAT_DIVISA CATDIVI ON CATDIVI.ID_CAT_DIVISA  = cinf.id_cat_divisa") ;
        agregaIdReg(listIds, sql);
        sql.append(UNION_ALL)
                .append("SELECT tranin.ID_REG, cntr.NUM_CNTR CONTRATO, to_char(tranin.NUME_CUEN_ORDE) NUM_CTA_CARGO,tranin.NUME_CUEN_RECE NUN_CTA_ABONO,")
                .append("ct.DESC_PROD, tranin.IMPO_CARG IMPORTE,null REFERENCIA,CATDIVI.CLAV_CAPTA DIVISA,ce.DESC_ESTATUS,")
                .append("to_char(tranin.FECH_APLI,'dd/mm/yyyy')  FECH_APLI,tranin.NOMBRE_RECE BENEFICIARIO,null TIPO_PAGO, DECODE(cinf.NOMB_TITU,null,' ',cinf.NOMB_TITU) TITULAR, ")
                .append("tranin.COME_1_CONC_PAGO CONCEPTO_PAGO,tranin.REFE_ENVI_OUT CLAVE_RASTREO,BNCO.NOMBRE_BANCO BANCO_RECEPTOR,r.FECH_ENVI_BACK FECHA_OPERACION,")
                .append("null CLAV_PROV,null NUM_DOCU,null FECH_VENCIMIENTO,null CVE_FORM_PAGO,'-'||trim(ct.CVE_PROD_OPER)||'-' ESTATUS_MOV, ")
                .append("null NUM_ORDEN,null FECHA_LIMITE_PAGO,null NUM_SUCURSAL, NULL  RAZON_SCIA, ")
                .append(" null NOM_CLTE,")
                .append("clte.PERSONALIDAD, clte.RFC,cntr.NUM_CNTR,")
                .append("'0' CLAVE_BENEF,null ID_ESTA,null PERS_AUT,'' FORM_APLI, '' NOMB_RAZON_SOCI_PROV,'' RFC_PROV,")
                .append("null BANC_ABON,null REFE_ABON,to_char(tranin.REFE_OUT) TIPO_DOCU")
                .append(" FROM H2H_MX_PROD_SPID_TRAN tranin")
                .append(" INNER JOIN H2H_REG_TRAN r ON r.id_reg = tranin.id_reg")
                .append(" INNER JOIN H2H_CAT_PROD ct ON r.cve_prod_oper = ct.cve_prod_oper")
                .append(" INNER JOIN H2H_ARCHIVO_TRAN a ON r.id_arch = a.id_archivo")
                .append(" INNER JOIN H2H_CNTR cntr ON cntr.id_cntr = a.id_cntr")
                .append(" INNER JOIN H2H_CLTE clte ON cntr.id_clte = clte.id_clte")
                .append(" LEFT JOIN H2H_CAT_ESTATUS ce ON ce.id_CAT_estatus = r.id_estatus")
                .append(" LEFT JOIN H2H_CAT_BNCO BNCO ON tranin.CVE_INTER_RECE  = BNCO.CODI_TRAN AND BNCO.BAND_ACTIVO = 1 ")
                .append(" LEFT JOIN H2H_CTA_INFO cinf ON r.cnta_carg = cinf.NUME_CTA and cinf. TIPO_CTA='O' ")
                .append(" LEFT JOIN H2H_CAT_DIVISA CATDIVI ON CATDIVI.ID_CAT_DIVISA  = cinf.id_cat_divisa") ;
        agregaIdReg(listIds, sql);
        return sql.toString();
    }
    
    /***
	 * metodo para obtener los datos para el comprobante
	 * @param bean bean allenar
	 * @param map mapa con datos
	 */
	public static void llenatransSpid(ComprobantesOperacionResponse bean, Tuple map) {
		//Formateo de importe
		final DecimalFormat decimalFormat = new DecimalFormat(
				"###,###,###,###,##0.00",
				new DecimalFormatSymbols());
		bean.setContrato(ObjectUtils.toString(map.get("CONTRATO")));
		bean.setRazonSocial(ObjectUtils.toString(map.get("RAZON_SCIA")));
		bean.setTitular(ObjectUtils.toString(map.get("TITULAR")));
		bean.setFechaAplic(ObjectUtils.toString(map.get("FECH_APLI")));
		bean.setTipoPago(ObjectUtils.toString(map.get("TIPO_PAGO")));
		bean.setRefInterbancaria(ObjectUtils.toString(map.get("TIPO_DOCU")));
		bean.setConceptoPago(ObjectUtils.toString(map.get("CONCEPTO_PAGO")));

		bean.setCuentaCargo(ObjectUtils.toString(map.get("NUM_CTA_CARGO")));
		bean.setCuentaAbono(ObjectUtils.toString(map.get("NUN_CTA_ABONO")));
		// Enmascaramos la cuenta Abono
		bean.setCuentaAbono(UtilMapeoData.getMascara(bean.getCuentaAbono(), "abono"));
		
		bean.setBeneficiario(ObjectUtils.toString(map.get("BENEFICIARIO")));
		
		final String impFormat = "$"+ decimalFormat.format(map.get("IMPORTE"));
		bean.setImporte(impFormat);
		bean.setBanco(ObjectUtils.toString(map.get("BANCO_RECEPTOR")));
		bean.setDivisa(ObjectUtils.toString(map.get("DIVISA")));
		
		bean.setEstatus(ObjectUtils.toString(map.get("DESC_ESTATUS")));
		bean.setEstatusMov(ObjectUtils.toString(map.get("ESTATUS_MOV")));
		
		bean.setFolioSua(ObjectUtils.toString(map.get("ID_REG")));
		bean.setTipoOper(ObjectUtils.toString(map.get("DESC_PROD")));
	}

}
