package mx.santander.h2h.monitoreo.util;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * Clase que contiene las constantes para realizar la consulta historica de las operaciones
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class ConstantesUtils {
    /** Constante Banco. */
    public static final String BANCO = "BANCO SANTANDER (MÉXICO) S.A.";

    /** MonitorOperaciones. */
    public static final String MONITOR_OPER = "MonitorOperacionesDAOImpl";

    /** MON002. */
    public static final String MON002 ="MON002";
    /** Codigo de operacion */
    public static final String OPERATION_CODE = "DetalleOperaciones";
    /** Codigo de operacion */
    public static final String HISTORIAL_CODE = "HistorialOperacion";
    /** Constante DIVISA MXP*/
    public static final String MXP = "MXP";
    /** Constante DIVISA MXN*/
    public static final String MXN = "MXN";
    /** Constante DIVISA COD_DIVS_SAL*/
    public static final String MN = "MN";
    /** REPROCESAR.*/
    public static final String REPROCESAR = "REPROCESAR";
    /** PROCESADO.*/
    public static final String PROCESADO = "PROCESADO";
    /** Constante DEBUG_ERROR */
    public static final String DEBUG_ERROR = "Consulta realizada con codigo de error: ";
    /** Constante ERROR_NO_EXITO */
    public static final String ERROR_NO_EXITO = "La consulta no fue realizada con exito: ";
    /** Constante de operacion en proceso. */
    public static final String OPERACION_EN_PROCESO = "OPERACION_EN_PROCESO";
    /**REG.DIVI DIVISA**/
    public static final String REG_DIVI_DIVISA="REG.DIVI DIVISA,";
    /**MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, */
    public static final String MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN="MSG.MSG_H2H, NULL MSG_ORDEN_PAGO, NULL NUM_ORDEN, ";
    /**NULL_REFERENCIA_ABONO_NULL_REFERENCIA_CARGO**/
    public static final String NULL_REFERENCIA_ABONO_NULL_REFERENCIA_CARGO="NULL REFERENCIA_ABONO, NULL REFERENCIA_CARGO, ";
    /**NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, **/
    public static final String NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA="NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, ";
    /**private NULL COMENTARIO_1, NULL COMENTARIO_2, **/
    public static final String NULL_COMENTARIO_1_NULL_COMENTARIO_2="NULL COMENTARIO_1, NULL COMENTARIO_2, ";
    /**NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO, **/
    public static final String NULL_TIPO_PAGO_NULL_MODALIDAD_NULL_IMPORTE_CARGO="NULL TIPO_PAGO, NULL MODALIDAD, NULL IMPORTE_CARGO, ";
    /**NULL BUC_EMPLEADO, */
    public static final String NULL_BUC_EMPLEADO="NULL BUC_EMPLEADO, ";
    /**NULL SUCURSAL_TUTORA, NULL RFC, */
    public static final String NULL_SUCURSAL_TUTORA_NULL_RFC="NULL SUCURSAL_TUTORA, NULL RFC, ";
    /**NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA,*/
    public static final String NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA="NULL NOMBRE_EMPLEADO, NULL NUMERO_CUENTA, ";
    /**NULL DESCRIPCION, */
    public static final String NULL_DESCRIPCION="NULL DESCRIPCION, ";
    /**constante para nombre de empleado*/
    public static final String NOMBRE_EMPLEADO="NOMBRE_EMPLEADO";
    /** String FECHA_LIMITE*/
    public static final String FECHA_LIMITE = "NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, NULL FECH_VENC, ";
    /**String NULL_COMENTARIO*/
    public static final String NULL_COMENTARIO = "NULL COMENTARIO_3, NULL TITULAR, NULL BANCO_RECEPTOR, ";
    /** String LEFT_JOIN_CONS*/
    public static final String LEFT_JOIN_CONS = "LEFT JOIN H2H_CTA_INFO CNTA_ABON ON REG.CNTA_ABON = CNTA_ABON.NUME_CTA AND CNTA_ABON.TIPO_CTA = 'B' ";
    /** String LEFT_JOIN_CONS_DOS*/
    public static final String LEFT_JOIN_CONS_DOS = "LEFT JOIN H2H_CTA_INFO CNTA_CARG ON REG.CNTA_CARG = CNTA_CARG.NUME_CTA AND CNTA_CARG.TIPO_CTA = 'O' ";
    /**String LEFT_JOIN_CONS_TRES*/
    public static final String LEFT_JOIN_CONS_TRES = "LEFT JOIN H2H_CAT_DIVISA DIVI_ABON ON DIVI_ABON.ID_CAT_DIVISA = CNTA_ABON.ID_CAT_DIVISA ";
    /*** String LEFT_JOIN_CONS_CUATRO*/
    public static final String LEFT_JOIN_CONS_CUATRO = "LEFT JOIN H2H_CAT_DIVISA DIVI_CARG ON DIVI_CARG.ID_CAT_DIVISA = CNTA_CARG.ID_CAT_DIVISA ";

    /**
     * Descripcion : Metodo que realiza el armado del query para historial de operaciones
     * @author  [z448853: Orlando Michael Mujica Garcia]
     * @since  05/06/2020
     * @param cveOperProd indica el tipo del producto
     * @return retorna String
     */
    public static String consultaProductos(int cveOperProd){
        /**Se genera instacia del query de tipo StringBuilder*/
        final StringBuilder query = new StringBuilder();
        query
		        .append("DETA.CLAV_INTE_ORDE INTERMEDIARIO_ORD, DIVI_CARG.CLAV_CAPTA DIVISA_ORD, ")
				.append("DETA.CLAV_INTER_RECE INTERMEDIARIO_REC, DECODE(CNTA_ABON.NOMB_TITU,NULL,DETA.NOMB_RECE,CNTA_ABON.NOMB_TITU) BENEFICIARIO, ")
				.append("DETA.COME_1_CONC_PAGO COMENTARIO_1, DETA.COME_2 COMENTARIO_2, ")
				.append("DETA.COME_3 COMENTARIO_3, CNTA_CARG.NOMB_TITU TITULAR, BNCO.NOMBRE_BANCO BANCO_RECEPTOR, ")
				.append("NULL TIPO_PAGO, NULL MODALIDAD, DETA.IMPO_CARG IMPORTE_CARGO, ")
                .append(MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN)
                .append("NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, NULL FECH_VENC,")
                .append(NULL_REFERENCIA_ABONO_NULL_REFERENCIA_CARGO)
                .append(NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA)
                .append(NULL_BUC_EMPLEADO)
                .append(NULL_SUCURSAL_TUTORA_NULL_RFC)
                .append(NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA)
                .append(NULL_DESCRIPCION);
        if(2 == cveOperProd || 42 == cveOperProd || 29 == cveOperProd) {
            query
                    .append("TO_CHAR(REG.HORA_APLI, 'HH24:MI') HORA_APLI,");
        }
        /**Retorna la sentencia a ejcutar para consultar el histarial de operaciones*/
        return query.toString();

    }

    /**
     * Descripcion : Metodo que realiza el armado del query para historial de operaciones
     * @author  [z448853: Orlando Michael Mujica Garcia]
     * @since  05/06/2020
     * @param cveOperProd indica el tipo del producto
     * @return retorna String
     */
    public static String consultaProductos9848(int cveOperProd){
        /**Se genera instacia del query de tipo StringBuilder*/
        final StringBuilder query = new StringBuilder();
        query.append("NULL INTERMEDIARIO_ORD, DIVI_CARG.CLAV_CAPTA DIVISA_ORD, NULL INTERMEDIARIO_REC, CNTA_ABON.NOMB_TITU BENEFICIARIO, ")
                .append(NULL_COMENTARIO_1_NULL_COMENTARIO_2+"NULL COMENTARIO_3, CNTA_CARG.NOMB_TITU TITULAR, BNCO.NOMBRE_BANCO BANCO_RECEPTOR, ")
                .append(NULL_TIPO_PAGO_NULL_MODALIDAD_NULL_IMPORTE_CARGO+MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN+FECHA_LIMITE);
        if (98 == cveOperProd || 48== cveOperProd){
        	query.append("DETA.NUME_MOV_ABONO REFERENCIA_ABONO, DETA.NUME_MOV_CARG REFERENCIA_CARGO, ");
        } else if (36 ==cveOperProd) {
        	query.append("DETA.CODI_OPER_ABO REFERENCIA_ABONO, DETA.CODI_OPER_CARG REFERENCIA_CARGO, ");
        } else {
            query.append(NULL_REFERENCIA_ABONO_NULL_REFERENCIA_CARGO);
        }
        query
                .append(NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA)
                .append(NULL_BUC_EMPLEADO)
                .append(NULL_SUCURSAL_TUTORA_NULL_RFC)
                .append(NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA)
                .append(NULL_DESCRIPCION);
        if(99 == cveOperProd|| 49 == cveOperProd || 29 == cveOperProd) {
            query
                    .append("TO_CHAR(REG.HORA_APLI, 'HH24:MI') HORA_APLI,");
        }
        /**Retorna la sentencia a ejcutar para consultar el histarial de operaciones*/
        return query.toString();
    }
    /**
     * Descripcion : Metodo que realiza el armado del query para historial de operaciones
     * @author  [z448853: Orlando Michael Mujica Garcia]
     * @since  05/06/2020
     * @param cveOperProd indica el tipo del producto
     * @return retorna String
     */
    public static String consultaProductos9949(int cveOperProd){
        /**Se genera instacia del query de tipo StringBuilder*/
        final StringBuilder query = new StringBuilder();
        query.append("NULL INTERMEDIARIO_ORD, DETA.DIVI_CARG DIVISA_ORD, NULL INTERMEDIARIO_REC, DETA.NOMB_RAZON_SOCI_PROV BENEFICIARIO, ")
                .append(ConstantesUtils.NULL_COMENTARIO_1_NULL_COMENTARIO_2+"NULL COMENTARIO_3, DECODE (CLTE.PERSONALIDAD,'F',CLTE.nombre  || ' '  || CLTE.appaterno  || ' '  || CLTE.apmaterno, CLTE.RAZON_SCIA) TITULAR, ")
                .append("DETA.BANC_ABON BANCO_RECEPTOR, "+ConstantesUtils.NULL_TIPO_PAGO_NULL_MODALIDAD_NULL_IMPORTE_CARGO)
                .append(ConstantesUtils.MSG_MSG_H2H_NULL_MSG_ORDEN_PAGO_NULL_NUM_ORDEN)
                .append(cveOperProd == 91 ? "NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, DETA.FECH_VENC FECH_VENC, " : "NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL, FECH_VENC FECH_VENC, ")
                .append(ConstantesUtils.NULL_REFERENCIA_ABONO_NULL_REFERENCIA_CARGO)
                .append(ConstantesUtils.NULL_NUMERO_EMPLEADO_NULL_NUMERO_TARJETA)
                .append(ConstantesUtils.NULL_BUC_EMPLEADO)
                .append(ConstantesUtils.NULL_SUCURSAL_TUTORA_NULL_RFC);

        if(91 == cveOperProd){
        	query
	    		.append("DETA.IVA NOMBRE_EMPLEADO, NULL NUMERO_CUENTA,")
	    		.append("DETA.REFE_ALTE DESCRIPCION, ");
        }else{
            query.append(ConstantesUtils.NULL_NOMBRE_EMPLEADO_NULL_NUMERO_CUENTA)
                    .append(ConstantesUtils.NULL_DESCRIPCION);
        }
        /**Retorna la sentencia a ejcutar para consultar el histarial de operaciones*/
        return query.toString();

    }

    /**
     * Descripcion : Metodo que define el tipo de pago
     * @author  [z448853: Orlando Michael Mujica Garcia]
     * @since  18/06/2020
     * @param tipoPago atributo que contieien el tipo de pago identificador
     * @return retorna String con la descripcion del tipo de Pago
     */
    public static String tipoPago(String tipoPago){
        /**Se define la variable que almacenara el tipo de divisa*/
        String result=tipoPago;
        if (!tipoPago.isEmpty()) {
            /**Se realiza validacion del tipo de pago*/
            if("E".equals(tipoPago)){
                result="E-EFECTIVO";
            } else if("C".equals(tipoPago)){
                result="C-CHEQUE";
            }else{
                result="OTRO";
            }
        }
        /**Se retorna la respuesta de la validacion*/
        return result;
    }

    /**
     * Descripcion : Metodo que recupera la divisa ordenantes
     * @author  [z448853: Orlando Michael Mujica Garcia]
     * @since  18/06/2020
     * @param divisaOrdenante atributo que contiene la divisa ordenante recuperada de la consulta
     * @return retorna String con la informacion de la divisa ordenante
     */
    public static String divisaOrdenante(String divisaOrdenante){
        /**Se define la variable que almacenara el tipo de divisa*/
        String result=divisaOrdenante;
        if (divisaOrdenante != null && MN.equals(divisaOrdenante.trim())){
            result=MXP;
        }
        /**Se retorna la respuesta de la validacion*/
        return result;

    }

}
