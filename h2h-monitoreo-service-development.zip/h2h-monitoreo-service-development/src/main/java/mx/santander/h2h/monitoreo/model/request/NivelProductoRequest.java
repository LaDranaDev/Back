/**
* Santander SCIB - Banco Santander Negocios Globales
* Todos los derechos reservados
* NivelProductoRequest.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <20 nov 2024 09:20:54>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.model.request;

import java.io.Serializable;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NivelProductoRequest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8457700161317878662L;

	/** Declaracion de String para codCliente. */
	@Pattern(regexp = "(^[a-zA-Z0-9]+$)?", message = "Datos de Cliente no valido")
	@Size(min = 0, max = 15, message = "Datos de Cliente erroneo")
	String codCliente;
	
	/** Declaracion de String para nomCliente. */
	@Pattern(regexp = "(^[0-9A-Za-z_. -]+$)?", message = "Datos no validos")
	@Size(min = 0, max = 120, message = "Datos erroneos")
	String nomCliente;
	
	/** Declaracion de Integer para idArchivo. */
	Integer idArchivo;
	
	/** Declaracion de Integer para idProducto. */
	Integer idProducto;
	
	/** Declaracion de Integer para idEstatus. */
	Integer idEstatus;
}
