package mx.santander.h2h.monitoreo.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.OperationsHistoryResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorCatalogsYHorasResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorTotalResponse;

/**
 * Servicio para el Monitor de Operaciones
 *
 * @author Daniel Ruiz
 * @since 13/04/2023
 */
public interface IOperationsMonitorService {

    /**
     * Realiza la consulta de las operaciones.
     *
     * @param request Request para realizar la consulta.
     * @param pageable parámetros de la paginación.
     * @return Página contiene los resultados.
     */
    Page<OperationsMonitorQueryResponse> consulta(OperationsMonitorQueryRequest request, Pageable pageable);

    /**
     * Obtiene los totales de la consulta de operaciones.
     *
     * @param request Request de la consulta.
     * @return Response con los totales
     */
    OperationsMonitorTotalResponse total(OperationsMonitorQueryRequest request);

    /**
     * Realiza el reporte de las operaciones.
     *
     * @param request Request para realizar la consulta.
     * @return DTO con los datos del reporte.
     */
    ReportResponse reporte(OperationsMonitorQueryRequest request, String tipo);

    /**
     * Consulta la lista de divisas, estatus y productos
     * @return Response de catálogos
     */
    OperationsMonitorCatalogsYHorasResponse catalogs();

    /**
     * Obtiene el detalle de la operacion
     * @param idProducto - ID del producto
     * @param idOperacion - ID de operacion
     * @return Detalle de la operacion
     */
    OperationsMonitorQueryResponse obtenerDetalleOperacion(String idProducto, String idOperacion);

    /**
     * Obtiene el historial de la operacion
     * @param idOperacion - ID de operacion
     * @return Historial de la operacion
     */
    List<OperationsHistoryResponse> obtenerHistorialOperacion(String idOperacion);

    /**
     * Obtiene el reporte del historial de la operacion
     * @param idOperacion - ID de operacion
     * @param usuario Nombre del usuario en el reporte
     * @return Reporte Historial de la operacion
     */
    ReportResponse reporteHistorialOperacion(String idOperacion, String usuario);


    /**
     * Cambia el estatus de la operacion
     * @param idOperacion - ID de operacion
     * @param estatus   - ID del estatus de la operacion
     * @param tabla - nombre de la tabla donde se encuentra el producto
     * @return true o false, indica si la actualizacion se realizo con exito o no
     */
    boolean cambiarEstatusOperacion(String idOperacion, String estatus, String tabla);

    /**
     * Consulta el horario para realizar el cambio de estatus.
     * @param producto String
     * @return boolean
     */
    boolean consultarHorario(String producto);

    /**
     * Consulta la lista de divisas, estatus y productos
     * @return Response de catálogos
     */
    OperationsMonitorCatalogsYHorasResponse catalogsConsultaTrackingArchivo();

}
