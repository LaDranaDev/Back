package mx.santander.h2h.monitoreo.util;

import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;

public interface IGenerateVouchersValidateDateUtils {

	void validateDate(OperationsMonitorQueryRequest operationsMonitorQueryRequest) throws BusinessException;

}
