package mx.santander.h2h.monitoreo.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

/**
 * Clase para obtener las propiedades de conexion al servidor sftp
 *
 * @author Omar Rosas
 * @since 20/01/2023
 */

@Getter
@Setter
@Configuration
@Component
@ConfigurationProperties(ignoreUnknownFields = false, prefix = "sftp-connection")
public class SftpConnectProperties {
	/**
	 * Propiedad que guarda la url del microservicio de conexiones a sftp
	 */
	private String url;
	/**
	 * Propiedad que guarda path para ejecutar la operacion de crear archivo xml
	 */
	private String pathcrearxml;
	/**
	 * Propiedad que guarda path para ejecutar la operacion de descarga de archivos
	 */
	private String pathdescargaarchivos;
	/**
	 * Propiedad que guarda path para ejecutar la operacion de consulta de
	 * configuracion de buzon
	 */
	private String pathconsultaconfig;
	/**
	 * Propiedad que guarda path para ejecutar la operacion de crear archivo
	 */
	private String pathcreararchivo;
	
	/**
	 * Propiedad que guarda path para descargar el reporte del catlálogo de BICS
	 */
	private String pathdescargareportebics;

	/**
	 * Propiedad que guarda path para descargar los reportes de captación
	 */
	private String pathdescargareportescaptacion;

	/**
	 * Propiedad que descarga el archivo de Admon Buzon
	 */
	private String pathdescargaarchivobuzon;
}
