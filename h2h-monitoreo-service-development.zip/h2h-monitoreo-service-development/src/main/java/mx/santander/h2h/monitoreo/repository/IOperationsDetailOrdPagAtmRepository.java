package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;

/**
 * IOperationsDetailOrdenPagoAtmRepository.
 *
 * @author Jesus Soto Aguilar
 */
public interface IOperationsDetailOrdPagAtmRepository {
    OperationsMonitorQueryResponse obtenerDetalleOperacion(String view, String idOperacion);
}
