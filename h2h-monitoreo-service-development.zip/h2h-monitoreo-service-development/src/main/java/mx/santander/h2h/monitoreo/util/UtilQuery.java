package mx.santander.h2h.monitoreo.util;

public class UtilQuery {
    /**
     * FROM H2H_ARCHIVO_TRAN
     * @param delDia <br>true: tabla TRAN <br> false: tabla sin TRAN
     * @return
     */
    public static String fromH2hArchivo(boolean delDia) {
        if (delDia) {
            return "FROM H2H_ARCHIVO_TRAN ARCH ";
        } else {
            return "FROM H2H_ARCHIVO ARCH ";
        }
    }

    /**
     * INNER JOIN H2H_REG_TRAN
     * @param delDia <br>true: tabla TRAN <br> false: tabla sin TRAN
     * @return
     */
    public static String innerJoinH2hReg(boolean delDia) {
        if (delDia) {
            return "INNER JOIN H2H_REG_TRAN REG ON ARCH.ID_ARCHIVO = REG.ID_ARCH ";
        } else {
            return "INNER JOIN H2H_REG REG ON ARCH.ID_ARCHIVO = REG.ID_ARCH ";
        }
    }
    
    public static String selectImpFedDU(boolean delDia, String tabla) {
    	StringBuilder query = new StringBuilder();
    	query.append(" INNER JOIN H2H_PROD")
    		.append(tabla);
    	if (delDia) {
            query.append("_TRAN PIF ON PIF.ID_REG = REG.ID_REG ");
        } else {
            query.append(" PIF ON PIF.ID_REG = REG.ID_REG ");
        }
    	return query.toString();
    }
    /**
     * Indicador de tabla reg.
     * @param delDia delDia <br>true: tabla TRAN <br> false: tabla sin TRAN
     * @return SELECT 'H2H_REG<Correspondiente>' TABLA,
     */
    public static String selectRegTabla(boolean delDia) {
        if (delDia) {
            return "SELECT 'H2H_REG_TRAN' TABLA, ";
        } else {
            return "SELECT 'H2H_REG' TABLA, ";
        }
    }

    /**
     * INNER JOIN H2H_MX_PROD_PAGO_DIR_TRAN PAGO ON PAGO.ID_REG = REG.ID_REG.
     * @param delDia delDia <br>true: tabla TRAN <br> false: tabla sin TRAN
     * @return INNER JOIN H2H_MX_PROD_PAGO_DIR<Correspondiente> PAGO ON PAGO.ID_REG = REG.ID_REG ,
     */
    public static String innerJoinPagoDirecto(boolean delDia) {
        if (delDia) {
            return "INNER JOIN H2H_MX_PROD_PAGO_DIR_TRAN PAGO ON PAGO.ID_REG = REG.ID_REG ";
        } else {
            return "INNER JOIN H2H_MX_PROD_PAGO_DIR PAGO ON PAGO.ID_REG = REG.ID_REG ";
        }
    }
    
    
    /**
     * Validacion de inner para pago directo
     * 
     * @param delDia
     * @return
     */
    public static String innerJoinPagoDirc(boolean delDia) {
        if (delDia) {
            return "INNER JOIN H2H_PROD_ORDN_PAGO_TRAN PAGO ON PAGO.ID_REG = REG.ID_REG ";
        } else {
            return "INNER JOIN H2H_PROD_ORDN_PAGO PAGO ON PAGO.ID_REG = REG.ID_REG ";
        }
    }
    
    
    /**
     * Validacion de inner para Alta Empl
     * 
     * @param delDia
     * @return
     */
    public static String innerJoinAltaEmp(boolean delDia) {
        if (delDia) {
            return "INNER JOIN H2H_PROD_ALTA_EMPL_TRAN EMPL ON EMPL.ID_REG = REG.ID_REG ";
        } else {
            return "INNER JOIN H2H_PROD_ALTA_EMPL EMPL ON EMPL.ID_REG = REG.ID_REG ";
        }
    }

    
    /**
     * Validacion de inner para Alta Empl
     * 
     * @param delDia
     * @return
     */
    public static String selTabla(boolean delDia) {
        if (delDia) {
            return "FROM H2H_REG_TRAN REG ";
        } else {
            return "FROM H2H_REG REG ";
        }
    }
    
    
    /**
     * Validacion de inner para Alta Empl
     * 
     * @param delDia
     * @return
     */
    public static String innerJoinArchivo(boolean delDia) {
        if (delDia) {
            return "INNER JOIN H2H_ARCHIVO_TRAN ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ";
        } else {
            return "INNER JOIN H2H_ARCHIVO ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ";
        }
    }
}
