package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;

/**
 * IOperationsDetailTransInterMBCRepository.
 *
 * @author Jesus Soto Aguilar
 */
public interface IOperationsDetailTransInterMbcRepository {

    /**
     * Obtiene el detalle de la operacion.
     *
     * @param idOperacion identificador de la operacion
     * @return Objeto con el detalle de la operacion
     */
    OperationsMonitorQueryResponse obtenerDetalleOperacion(String idOperacion);
}
