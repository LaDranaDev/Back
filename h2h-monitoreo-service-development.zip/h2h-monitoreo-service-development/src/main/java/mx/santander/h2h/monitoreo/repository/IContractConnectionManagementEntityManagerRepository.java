/**
 * 
 */
package mx.santander.h2h.monitoreo.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.model.entity.ParameterEntity;
import mx.santander.h2h.monitoreo.model.request.ContractConnectionManagementRequest;
import mx.santander.h2h.monitoreo.model.response.ContractConnectionManagementResponse;
import mx.santander.h2h.monitoreo.model.response.ParametersGetPutResponse;
import mx.santander.h2h.monitoreo.model.response.ProductEdoCtaResponse;
import mx.santander.h2h.monitoreo.model.response.ProtocolResponse;

/**
 * @author sbautish
 *
 */
public interface IContractConnectionManagementEntityManagerRepository {

	PageImpl<ContractConnectionManagementResponse> findContractConnectionByContractNumberOrClientCode(ContractConnectionManagementRequest contractConnectionManagementRequest, ParameterEntity tipoEstatus, ParameterEntity estatusCancelada, Pageable pageable);

	String findContractConnectionProtocolByIdContract(String idContrato);

	String findCustomerShippingByIdContract(String idContrato);

	List<ProductEdoCtaResponse> findContractProductsForProducts(String numeroContrato);

	List<ProtocolResponse> findProtocols();

	List<ParametersGetPutResponse> findParametersOfProtocols(Integer idContrato, Integer idProtocolo, BigDecimal idRegistro, String tipoActividad);

	BigDecimal saveParametersOfProtocols(Integer idContrato, BigDecimal idRegistro, List<ParametersGetPutResponse> parameters, Integer idOriginalProtocol, Integer idProtocoloNuevo);

}
