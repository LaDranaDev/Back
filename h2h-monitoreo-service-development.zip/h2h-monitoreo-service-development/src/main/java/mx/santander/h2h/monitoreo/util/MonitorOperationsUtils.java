package mx.santander.h2h.monitoreo.util;

import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;

@Slf4j
@Component
public class MonitorOperationsUtils {

	/** Constante DIVISA CLAV_CAPTA*/
	final private static String MXP = "MXP";
	
	/** Constante static DIVISA COD_DIVS_SAL*/
	final private static String MN = "MN";
	
	/** Constante DIVISA CLAV_CAPTA*/
	final private static String USD = "USD";
	
	/** Constante DIVISA COD_DIVS_SAL*/
	final private static String DL = "DL";

	/**
	 * Metodo que devuelve el query de la consulta de operaciones
	 * @param tresMeses boolean
	 * @return String
	 */
	public static String getSelectConsultaOperaciones(boolean tresMeses) {
		final StringBuilder query = new StringBuilder();
		query
		 	.append("SELECT REG.ID_REG, CVE_PROD_OPER ")
			.append(tresMeses ? "FROM H2H_REG_TRAN REG " : "FROM H2H_REG REG ")
			.append(tresMeses ? "INNER JOIN H2H_ARCHIVO_TRAN ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH " : "INNER JOIN H2H_ARCHIVO ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ")
			.append("INNER JOIN H2H_CNTR CNTR USING (ID_CNTR) ")
			.append("INNER JOIN H2H_CLTE CLTE USING (ID_CLTE) ")
			.append("INNER JOIN H2H_CAT_PROD PROD USING(CVE_PROD_OPER) ")
			.append("INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS ");
		return query.toString();
	}
	
	/**
	 * Metodo que devuelve la concidiciones de consulta 
	 * @param consultaOperaciones ConsultaMonitorOperacionesDTO
	 * @param aSession ArchitechSessionBean
	 * @param prodExcluidos listado de los products excluidos
	 * @return String
	 */
	public static String getWhereConsultaOperaciones(OperationsMonitorQueryRequest consultaOperaciones, String prodExcluidos){		
		final StringBuilder query = new StringBuilder();
		query
			.append("WHERE (trunc(ARCH.FECHA_REGISTRO) BETWEEN TO_DATE('")
				.append(consultaOperaciones.getFechaInicial())
				.append("', 'DD/MM/YYYY') AND (TO_DATE('")
				.append(consultaOperaciones.getFechaFinal())	
				.append("', 'DD/MM/YYYY')) OR trunc(REG.FECH_APLI) BETWEEN TO_DATE('")
				.append(consultaOperaciones.getFechaInicial())
				.append("', 'DD/MM/YYYY') AND (TO_DATE('")
				.append(consultaOperaciones.getFechaFinal())	
				.append("', 'DD/MM/YYYY'))) ")
				.append("AND REG.ID_ESTATUS = 4 ")
				.append("AND CVE_PROD_OPER != '95' AND CVE_PROD_OPER != '96' ")
				.append("AND CVE_PROD_OPER != '93' ")
				.append("AND CVE_PROD_OPER not in(  ")
				.append(prodExcluidos)
				.append(")  ");
		
		
		
		if (!"".equals(consultaOperaciones.getBuc()) && consultaOperaciones.getBuc() != null) {
			query.append("AND CLTE.BUC = '").append(consultaOperaciones.getBuc()).append("' ");
		}
		if (!"".equals(consultaOperaciones.getContrato()) && consultaOperaciones.getContrato() != null) {
			query.append("AND CNTR.NUM_CNTR = '").append(consultaOperaciones.getContrato()).append("' ");
		}
		if (!"".equals(consultaOperaciones.getNombreArchivo()) && consultaOperaciones.getNombreArchivo() != null) {
			query.append("AND UPPER(ARCH.NOMBRE_ARCH) LIKE '%")
				.append(consultaOperaciones.getNombreArchivo().toUpperCase()).append("%' ");
		}
		if (!"0".equals(consultaOperaciones.getIdProducto()) && consultaOperaciones.getIdProducto() != null) {
			query.append("AND CVE_PROD_OPER = '").append(consultaOperaciones.getIdProducto()).append("' ");
		}
		if(!"0".equals(consultaOperaciones.getIdEstatus()) && consultaOperaciones.getIdEstatus() != null) {
			query.append("AND REG.ID_ESTATUS = ").append(consultaOperaciones.getIdEstatus()).append(" ");
		}
		if (!"".equals(consultaOperaciones.getCuentaCargo()) && consultaOperaciones.getCuentaCargo() != null) {
			query.append("AND REG.CNTA_CARG = '").append(consultaOperaciones.getCuentaCargo()).append("' ");
		}
		if (!"".equals(consultaOperaciones.getCuentaAbono()) && consultaOperaciones.getCuentaAbono() != null) {
			query.append("AND REG.CNTA_ABON = '").append(consultaOperaciones.getCuentaAbono()).append("' ");
		}
		if (!"".equals(consultaOperaciones.getImporte()) && consultaOperaciones.getImporte() != null) {
			query.append("AND REG.MONT = ").append(consultaOperaciones.getImporte()).append(" ");
		}
		if (!"".equals(consultaOperaciones.getReferencia()) && consultaOperaciones.getReferencia() != null) {
			final String referenciaTmp = ((consultaOperaciones.getReferencia()).trim()).replaceFirst("^0*", "");
			query.append("AND REGEXP_LIKE (REG.REFE_BE, '^0*").append(referenciaTmp).append("') ");
		}
		if (!"0".equals(consultaOperaciones.getDivisa()) && consultaOperaciones.getDivisa() != null) {
			if (MXP.equals(consultaOperaciones.getDivisa())) {
				query.append("AND (REG.DIVI = '").append(MXP)
						.append("' OR REG.DIVI = '").append(MN)
						.append("') ");
			} else {
				if (USD.equals(consultaOperaciones.getDivisa())) {
					query.append("AND (REG.DIVI = '").append(USD)
							.append("' OR REG.DIVI = '").append(DL)
							.append("') ");
				} else {
					query.append("AND REG.DIVI = '")
							.append(consultaOperaciones.getDivisa())
							.append("' ");
				}
			}			
		}
		if (!"".equals(consultaOperaciones.getNumeroOrden()) && consultaOperaciones.getNumeroOrden() != null) {
			query.append("AND PAGO.NUM_ORDEN = '").append(consultaOperaciones.getNumeroOrden()).append("' ");
		}
		if (!"".equals(consultaOperaciones.getNombreBeneficiario()) && consultaOperaciones.getNombreBeneficiario() != null) {
			query.append("AND UPPER(PAGO.NOMB_BENE)  LIKE '%")
				.append(consultaOperaciones.getNombreBeneficiario()).append("%' ");
		}
		if (!"".equals(consultaOperaciones.getIdReg()) && consultaOperaciones.getIdReg() != null) {
			query.append("AND REG.ID_REG = ").append(consultaOperaciones.getIdReg()).append(" ");
		}		
		return query.toString();
	}
	
	/**
	 * Tranformara los ids de entero 
	 * a enteros con comillas para el in 
	 * del select
	 * @param ids
	 * @return ids con comillas
	 */
	public static String transformaids(String ids) {
		String tmp=ids;
		if(ids.contains(",")){
			String[] id=ids.split(",");
			StringBuilder fina=new StringBuilder();
			String coma="";
			for (String numero : id) {
				fina.append(coma).append("'").append(numero.trim()).append("'");
				if("".equals(coma)){
					coma=",";
				}
			}
			tmp=fina.toString();
		}
		return tmp;
	}
}
