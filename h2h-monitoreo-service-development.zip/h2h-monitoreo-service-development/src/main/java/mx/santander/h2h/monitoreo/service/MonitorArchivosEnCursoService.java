package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.constants.ReportConstants;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.MonitorArchivosEnCursoRequest;
import mx.santander.h2h.monitoreo.model.response.ComboDosResponse;
import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import mx.santander.h2h.monitoreo.model.response.MonitorDeArchivosEnCursoDetallesResponse;
import mx.santander.h2h.monitoreo.model.response.MonitorDeArchivosEnCursoResponse;
import mx.santander.h2h.monitoreo.repository.IMonitorArchivosEnCursoNivelOperacionRepository;
import mx.santander.h2h.monitoreo.repository.IMonitorArchivosEnCursoRepository;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;

import org.jfree.util.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * MonitorArchivosEnCursoService
 */
@Service
public class MonitorArchivosEnCursoService implements IMonitorArchivosEnCursoService {

	/**
	 * reportService
	 */
	@Autowired
	private IJasperReportService reportService;

	/**
	 * entityManager
	 */
	@Autowired
	private IMonitorArchivosEnCursoRepository entityManager;

	/**
	 * entityManagerOperacion
	 */
	@Autowired
	private IMonitorArchivosEnCursoNivelOperacionRepository entityManagerOperacion;
	
	/**
	 * archivosEnCursoComplementService
	 */
	@Autowired
	private IMonitorArchivosEnCursoComplementService archivosEnCursoComplementService;

	 /**
     * Obtiene detalles de los archivos en curso.
     * @param fecha Date Fecha de búsqueda.
     * @param codCliente String Codio del cliente.
     * @return Bean con los totales de archivos
     */
	@Override
	public MonitorDeArchivosEnCursoResponse consultaNivelProducto(String idArchivo, Integer idProducto,
			Integer idEstatus) {
		MonitorDeArchivosEnCursoResponse monitorDeArchivosEnCurso = new MonitorDeArchivosEnCursoResponse();
		monitorDeArchivosEnCurso.setMonitorDeArchivosEnCurso(
				entityManager.ejecutaBusquedaNivelProducto(idArchivo, idProducto, idEstatus));
		return monitorDeArchivosEnCurso;
	}

	/**
	 * consultaNivelOperacion
	 * @param idArchivo String
	 * @param idProducto Integer
	 * @param idEstatus Integer
	 * @return MonitorDeArchivosEnCursoResponse
	 */
	@Override
	public MonitorDeArchivosEnCursoResponse consultaNivelOperacion(String idArchivo, Integer idProducto,
			Integer idEstatus) {
		MonitorDeArchivosEnCursoResponse monitorDeArchivosEnCurso = new MonitorDeArchivosEnCursoResponse();
		monitorDeArchivosEnCurso.setMonitorDeArchivosEnCursoOperacion(
				entityManagerOperacion.ejecutaBusquedaNivelOperacion(idArchivo, idProducto, idEstatus));
		return monitorDeArchivosEnCurso;
	}

	/**
	 * consultaNivelOperacionHistorica
	 * @param idReg String
	 * @return MonitorDeArchivosEnCursoResponse
	 */
	@Override
	public MonitorDeArchivosEnCursoResponse consultaNivelOperacionHistorica(String idReg) {
		MonitorDeArchivosEnCursoResponse monitorDeArchivosEnCurso = new MonitorDeArchivosEnCursoResponse();
		monitorDeArchivosEnCurso.setMonitorDeArchivosEnCursoOperacion(
				entityManagerOperacion.ejecutaBusquedaNivelOperacionHistorica(idReg));
		return monitorDeArchivosEnCurso;
	}

	/**
	 * getReportXls
	 * @param archivosEnCurso MonitorArchivosEnCursoRequest
	 * @param user String
	 * @return ReportResponse
	 */
	@Override
	public ReportResponse getReportXls(MonitorArchivosEnCursoRequest archivosEnCurso, String user) {
		ReportResponse response = new ReportResponse();
		StringBuilder subReportPath = new StringBuilder(ReportConstants.REPORTS_FOLDER)
				.append("MonitorArchivosCursoSubreporte.jasper");
		ClassPathResource dirSubRepor = new ClassPathResource(subReportPath.toString());
		InputStream jasperStream;
		var descripcionProducto = "";
		var descripcionEstatus = "";
		
		List<ComboDosResponse> catProductos = archivosEnCursoComplementService.obtenerCatalogoProducto();
		for(ComboDosResponse producto : catProductos) {
			if(archivosEnCurso.getIdProducto().equals(producto.getId())) {
				descripcionProducto = producto.getValor();
			}
		}
		
		List<ComboResponse> catEstatus = archivosEnCursoComplementService.obtenerCatalogoEstatus();
		for(ComboResponse estatus : catEstatus) {
			if(estatus.getId().toString().equals(archivosEnCurso.getIdEstatus())) {
				descripcionEstatus = estatus.getValor();
			}
		}
	
		
		try {
			jasperStream = dirSubRepor.getInputStream();
			JasperReport jasperReport = (JasperReport) JRLoader.loadObject(jasperStream);
			List<MonitorDeArchivosEnCursoDetallesResponse> monitorDeArchivosEnCurso = entityManager
					.ejecutaBusquedaArchivosEnCursoReporte(archivosEnCurso);

			Map<String, Object> reportParam = new HashMap<>();

			reportParam.put("USER", user);
			reportParam.put("TITULO_REPORTE", "Monitor de archivos en Curso");
			reportParam.put("CLIENTE", "Cliente");
			reportParam.put("NOMBRE_ARCHIVO", "Nombre Archivo");
			reportParam.put("FECHA_RECEPCION", "Fecha Recepción");
			reportParam.put("CANAL", "Canal");
			reportParam.put("ESTATUS", "Estatus");
			reportParam.put("PRODUCTO", "Producto");
			reportParam.put("NUMERO_OPERACIONES", "Número Operaciones");
			reportParam.put("MONTO", "Monto");

			reportParam.put("SUBREPOTE_NIV_ARCH", jasperReport);

			reportParam.put("FILTRO_CLIENTE", "Código de Cliente");
			reportParam.put("FILTRO_CONTRATO", "Número de Contrato");
			reportParam.put("FILTRO_NOMBRE_ARCHIVO", "Nombre Archivo");
			reportParam.put("FILTRO_PRODUCTO", "Producto");
			reportParam.put("FILTRO_ESTATUS", "Estatus");
			reportParam.put("FILTRO_FCHINI", "Fecha Inicial");
			reportParam.put("FILTRO_FCHFIN", "Fecha Final");

			reportParam.put("VALOR_CLIENTE", archivosEnCurso.getBuc());
			reportParam.put("VALOR_CONTRATO", archivosEnCurso.getNumContrato());
			reportParam.put("VALOR_NOMBRE_ARCHIVO", archivosEnCurso.getNomArch());
			reportParam.put("VALOR_PRODUCTO", descripcionProducto);
			reportParam.put("VALOR_ESTATUS", descripcionEstatus);
			reportParam.put("VALOR_FCHINI", archivosEnCurso.getFechaIni());
			reportParam.put("VALOR_FCHFIN", archivosEnCurso.getFechaFin());

			reportParam.put("LISTA_DETALLE", monitorDeArchivosEnCurso);

			response = reportService.getXls("MonitorArchivosCurso.jasper", reportParam, monitorDeArchivosEnCurso);

			response.setType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
		} catch (BusinessException | IOException | JRException e) {
			return null;
		} 

		return response;
	}

}
