package mx.santander.h2h.monitoreo.util;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import jakarta.persistence.Query;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;

@Component
public class GenerateVouchersRepositoryImplUtil implements IGenerateVouchersRepositoryUtil {

	@Override
	public StringBuilder getQueryTableExport(OperationsMonitorQueryRequest operationsMonitorQueryRequest,
			List<String> listParams, StringBuilder query) {

		query.append("SELECT E.DESC_ESTATUS, E.ID_CAT_ESTATUS, P.ID_REG, P.NUM_CTA_CARG, P.COD_OPER_CARG, P.CLVE_CONV, P.NUM_CTA_ABO, P.COD_OPER_ABO, P.IMPO_MOVI, P.OBSE_CARG, P.OBSE_ABO, ");
		query.append("P.REFE_MOV, P.NUM_CNTR, P.BUC, P.NOMB_CLTE, P.PLZA, P.SUCU, P.ID_ARCH_UNIX, A.NOMBRE_ARCH, A.ID_CANL, C.DESC_CANL, P.CVE_PROD_OPER, CP.DESC_PROD, P.FECH_REG, ");
		query.append("P.NUME_MOVI_CARG, P.NUME_MOVI_ABO, P.IMPO_COMI, P.IMPO_IVA, TO_CHAR(P.FECH_REG, 'yyyy-mm-dd hh24:mi:ss') FECH_OPER, P.HORA_OPER, P.COD_ERR, ");
		query.append("DECODE(P.DESC_ERR, null, M.MSG_H2H, P.DESC_ERR) AS DESC_ERR, P.TITU_CTA, P.ID_REFE_INTE, TO_CHAR(R.FECH_OPER, 'DD/MM/YYYY') FECHA_PRESENTACION_INICIAL, R.DIVI, TO_CHAR(R.FECH_APLI, 'DD/MM/YYYY') FECHA_APLICACION, ");
		query.append("TO_CHAR(p.FECH_REG, 'dd/mm/yyyy') FECHA_OPERACION FROM H2H_CAT_ESTATUS E, H2H_REG R, H2H_PROD_PAGO_REFE P, H2H_CAT_PROD CP, H2H_ARCHIVO A, H2H_CAT_CANL C, H2H_MSG M ");
		query.append("WHERE R.CVE_PROD_OPER = '22' AND P.ID_REG = R.ID_REG AND R.ID_ESTATUS = E.ID_CAT_ESTATUS AND R.CVE_PROD_OPER = CP.CVE_PROD_OPER AND A.ID_ARCHIVO = R.ID_ARCH ");
		query.append("AND C.ID_CANL = A.ID_CANL AND P.CLVE_CONV = (SELECT VALOR FROM H2H_PARAM WHERE NMBR_PARAM = 'CONV_IMPU_CDMX') AND M.ID_MSG = R.ID_MSG ");

		query = applyFilters(operationsMonitorQueryRequest, query, listParams);

		query.append("UNION ALL ");

		query.append("SELECT E.DESC_ESTATUS, E.ID_CAT_ESTATUS, P.ID_REG, P.NUM_CTA_CARG, P.COD_OPER_CARG, P.CLVE_CONV, P.NUM_CTA_ABO, P.COD_OPER_ABO, P.IMPO_MOVI, P.OBSE_CARG, P.OBSE_ABO, ");
		query.append("P.REFE_MOV, P.NUM_CNTR, P.BUC, P.NOMB_CLTE, P.PLZA, P.SUCU, P.ID_ARCH_UNIX, A.NOMBRE_ARCH, A.ID_CANL, C.DESC_CANL, P.CVE_PROD_OPER, CP.DESC_PROD, P.FECH_REG, ");
		query.append("P.NUME_MOVI_CARG, P.NUME_MOVI_ABO, P.IMPO_COMI, P.IMPO_IVA, TO_CHAR(P.FECH_REG, 'yyyy-mm-dd hh24:mi:ss') FECH_OPER, P.HORA_OPER, P.COD_ERR, ");
		query.append("DECODE(P.DESC_ERR, null, M.MSG_H2H, P.DESC_ERR) AS DESC_ERR, P.TITU_CTA, P.ID_REFE_INTE, TO_CHAR(R.FECH_OPER, 'DD/MM/YYYY') FECHA_PRESENTACION_INICIAL, R.DIVI, TO_CHAR(R.FECH_APLI, 'DD/MM/YYYY') FECHA_APLICACION, ");
		query.append("TO_CHAR(P.FECH_REG, 'dd/mm/yyyy') FECHA_OPERACION FROM H2H_CAT_ESTATUS E, H2H_REG_TRAN R, H2H_PROD_PAGO_REFE_TRAN P, H2H_CAT_PROD CP, H2H_ARCHIVO_TRAN A, H2H_CAT_CANL C, ");
		query.append("H2H_MSG M WHERE R.CVE_PROD_OPER = '22' AND P.ID_REG = R.ID_REG AND R.ID_ESTATUS = E.ID_CAT_ESTATUS AND R.CVE_PROD_OPER = CP.CVE_PROD_OPER AND A.ID_ARCHIVO = R.ID_ARCH ");
		query.append("AND C.ID_CANL = A.ID_CANL AND P.CLVE_CONV = (SELECT VALOR FROM H2H_PARAM WHERE NMBR_PARAM = 'CONV_IMPU_CDMX') AND M.ID_MSG = R.ID_MSG ");

		query = applyFilters(operationsMonitorQueryRequest, query, listParams);

		return query;
	}

	/**
	 * @param listParams lista de parámetros
	 * @param operationsCountQuery query con parámetros asignados
	 */
	@Override
	public void setStringParamsInToQuery(List<String> listParams, Query operationsCountQuery) {
		Integer position = 1;

		for (String param : listParams) {
			operationsCountQuery.setParameter(position, param);
			position++;
		}
	}

	@Override
	public StringBuilder getPaginatedQuery(StringBuilder query, StringBuilder queryTable) {

		query.append("SELECT ID_REG, BUC, NUM_CTA_CARG, NUM_CTA_ABO, CVE_PROD_OPER, DESC_PROD, NOMBRE_ARCH, DESC_ESTATUS, ID_CAT_ESTATUS, DESC_CANL, NUME_MOVI_CARG, ");
		query.append("OBSE_ABO, FECH_OPER, IMPO_MOVI FROM (SELECT A.ID_REG, A.BUC, A.NUM_CTA_CARG, A.NUM_CTA_ABO, A.CVE_PROD_OPER, A.DESC_PROD, A.NOMBRE_ARCH, ");
		query.append("A.DESC_ESTATUS, A.ID_CAT_ESTATUS, A.DESC_CANL, A.NUME_MOVI_CARG, A.OBSE_ABO, A.FECH_OPER, A.IMPO_MOVI, ROWNUM ROW_NUMBER FROM (");
		query.append(queryTable);
		query.append(") A WHERE ROWNUM < ( 1 * 20 + 1)) WHERE ROW_NUMBER >= (( 1 - 1 ) * 20 + 1)");

		return query;
	}

	/**
	 * @param operationsMonitorQueryRequest
	 * @param listParams
	 * @param query
	 * @return
	 */
	@Override
	public StringBuilder getQueryTable(OperationsMonitorQueryRequest operationsMonitorQueryRequest, List<String> listParams, StringBuilder query) {

		query.append("SELECT E.DESC_ESTATUS, E.ID_CAT_ESTATUS, P.ID_REG, P.NUM_CTA_CARG, P.COD_OPER_CARG, P.CLVE_CONV, P.NUM_CTA_ABO, P.COD_OPER_ABO, P.IMPO_MOVI, ");
		query.append("P.OBSE_CARG, P.OBSE_ABO, P.REFE_MOV, P.NUM_CNTR, P.BUC, P.NOMB_CLTE, P.PLZA, P.SUCU, P.ID_ARCH_UNIX, A.NOMBRE_ARCH, A.ID_CANL, C.DESC_CANL, P.CVE_PROD_OPER, CP.DESC_PROD, ");
		query.append("P.FECH_REG, P.NUME_MOVI_CARG, P.NUME_MOVI_ABO, P.IMPO_COMI, P.IMPO_IVA, TO_CHAR(P.FECH_REG, 'yyyy-mm-dd hh24:mi:ss') FECH_OPER, P.HORA_OPER, P.COD_ERR, P.DESC_ERR, ");
		query.append("P.TITU_CTA, P.ID_REFE_INTE FROM H2H_CAT_ESTATUS E, H2H_REG R, H2H_PROD_PAGO_REFE P, H2H_CAT_PROD CP, H2H_ARCHIVO A, H2H_CAT_CANL C WHERE R.CVE_PROD_OPER = '22' ");
		query.append("AND P.ID_REG = R.ID_REG AND R.ID_ESTATUS = E.ID_CAT_ESTATUS AND R.CVE_PROD_OPER = CP.CVE_PROD_OPER AND A.ID_ARCHIVO = R.ID_ARCH AND C.ID_CANL = A.ID_CANL AND P.CLVE_CONV = ");
		query.append("(SELECT VALOR FROM H2H_PARAM WHERE NMBR_PARAM = 'CONV_IMPU_CDMX') ");

		query = applyFilters(operationsMonitorQueryRequest, query, listParams);

		query.append("UNION ALL ");

		query.append("SELECT E.DESC_ESTATUS, E.ID_CAT_ESTATUS, P.ID_REG, P.NUM_CTA_CARG, P.COD_OPER_CARG, P.CLVE_CONV, P.NUM_CTA_ABO, P.COD_OPER_ABO, P.IMPO_MOVI, P.OBSE_CARG, P.OBSE_ABO, ");
		query.append("P.REFE_MOV, P.NUM_CNTR, P.BUC, P.NOMB_CLTE, P.PLZA, P.SUCU, P.ID_ARCH_UNIX, A.NOMBRE_ARCH, A.ID_CANL, C.DESC_CANL, P.CVE_PROD_OPER, CP.DESC_PROD, P.FECH_REG, ");
		query.append("P.NUME_MOVI_CARG, P.NUME_MOVI_ABO, P.IMPO_COMI, P.IMPO_IVA,TO_CHAR(P.FECH_REG, 'yyyy-mm-dd hh24:mi:ss') FECH_OPER, P.HORA_OPER, P.COD_ERR, P.DESC_ERR, P.TITU_CTA, ");
		query.append("P.ID_REFE_INTE FROM H2H_CAT_ESTATUS E, H2H_REG_TRAN R, H2H_PROD_PAGO_REFE_TRAN P, H2H_CAT_PROD CP, H2H_ARCHIVO_TRAN A, H2H_CAT_CANL C WHERE R.CVE_PROD_OPER = '22' ");
		query.append("AND P.ID_REG = R.ID_REG AND R.ID_ESTATUS = E.ID_CAT_ESTATUS AND R.CVE_PROD_OPER = CP.CVE_PROD_OPER AND A.ID_ARCHIVO = R.ID_ARCH AND C.ID_CANL = A.ID_CANL AND P.CLVE_CONV = ");
		query.append("(SELECT VALOR FROM H2H_PARAM WHERE NMBR_PARAM = 'CONV_IMPU_CDMX') ");

		query = applyFilters(operationsMonitorQueryRequest, query, listParams);

		return query;
	}

	public StringBuilder applyFilters(OperationsMonitorQueryRequest operationsMonitorQueryRequest, StringBuilder query, List<String> listParams) {

		if (StringUtils.isNotBlank(operationsMonitorQueryRequest.getContrato())) {

			query.append("AND P.NUM_CNTR = ? ");

			listParams.add(operationsMonitorQueryRequest.getContrato());

		}

		if (StringUtils.isNotBlank(operationsMonitorQueryRequest.getCuentaCargo())) {

			query.append("AND P.NUM_CTA_CARG = ? ");

			listParams.add(operationsMonitorQueryRequest.getCuentaCargo());

		}

		if (StringUtils.isNotBlank(operationsMonitorQueryRequest.getLineaCaptura())) {

			query.append("AND P.OBSE_ABO = ? ");

			listParams.add(operationsMonitorQueryRequest.getLineaCaptura());

		}

		if (StringUtils.isNotBlank(operationsMonitorQueryRequest.getNombreArchivo())) {

			query.append("AND A.NOMBRE_ARCH = ? ");

			listParams.add(operationsMonitorQueryRequest.getNombreArchivo());

		}

		if (StringUtils.isNotBlank(operationsMonitorQueryRequest.getIdEstatus()) && !"0".equals(operationsMonitorQueryRequest.getIdEstatus())) {

			query.append("AND E.ID_CAT_ESTATUS = ? ");

			listParams.add(operationsMonitorQueryRequest.getIdEstatus());

		}

		if (StringUtils.isNotBlank(operationsMonitorQueryRequest.getFechaInicial())) {

			query.append("AND P.FECH_REG >= TO_DATE( ? , 'DD/MM/YYYY') ");

			listParams.add(operationsMonitorQueryRequest.getFechaInicial());

		}

		if (StringUtils.isNotBlank(operationsMonitorQueryRequest.getFechaFinal())) {

			query.append("AND P.FECH_REG <= TO_DATE( ? , 'DD/MM/YYYY')+1 ");

			listParams.add(operationsMonitorQueryRequest.getFechaFinal());

		}

		if (StringUtils.isNotBlank(operationsMonitorQueryRequest.getIdReg())) {

			query.append("AND P.ID_REG = ? ");

			listParams.add(operationsMonitorQueryRequest.getIdReg());

		}

		if (StringUtils.isNotBlank(operationsMonitorQueryRequest.getTipo()) && !"0".equals(operationsMonitorQueryRequest.getTipo())) {

			query.append("AND P.OBSE_ABO LIKE ? ");

			listParams.add(operationsMonitorQueryRequest.getTipo().concat("%"));

		}

		if (StringUtils.isNotBlank(operationsMonitorQueryRequest.getBuc())) {

			query.append("AND P.BUC = ? ");

			listParams.add(operationsMonitorQueryRequest.getBuc());

		}

		return query;
	}
}
