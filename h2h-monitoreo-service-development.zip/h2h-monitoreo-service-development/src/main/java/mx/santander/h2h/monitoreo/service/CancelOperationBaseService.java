package mx.santander.h2h.monitoreo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import mx.santander.h2h.monitoreo.repository.ICancelOperationRepository;
import mx.santander.h2h.monitoreo.repository.ICatalogoEstatusRepository;

/**
 * Clase que implementa la interfaz de ICancelOperationService Creando los
 * metodos necesarios para hacer la consultas necesarias tales como los combos
 * de estatus centro, comobo de estatus cancelado buscar una operacion por buc,
 * buscar un archivo y cancelar una operacion
 * 
 * @version 1.1
 * @author Santander
 */
@Service
public class CancelOperationBaseService implements ICancelOperationBaseService{
	/**
	 * Varaible para implementar la persistencia
	 */
	@PersistenceContext
	@Autowired
	public EntityManager entityManager;

	/**
	 * Varaible para implementar el repositorio de camcelar operaciones
	 */
	@Autowired
	private ICancelOperationRepository cancelOperationRepository;
	/**
	 * Varaible para implementar el repositorio de Catalogos
	 */
	@Autowired
	private ICatalogoEstatusRepository catalogoEstatusRepository;

	/**
	 * (non-Javadoc) Método de cargador de clases estándar para cargar una clase y
	 * resolverla.
	 * 
	 * @see ICancelOperationService#getListaComboEstatusCentro()
	 */
	@Override
	public List<ComboResponse> getListaComboEstatusCentro() {
		List<ComboResponse> listaCombo = new ArrayList<ComboResponse>();
		List<Object[]> resultQueryCatalogos = catalogoEstatusRepository.obtenerCatalogoEstatusCentro();

		if (resultQueryCatalogos != null) {
			for (Object[] map : resultQueryCatalogos) {
				ComboResponse bean = new ComboResponse();
				bean.setId(((Integer) map[0]));
				bean.setValor((String) map[1]);
				listaCombo.add(bean);
			}
		}
		return listaCombo;
	}

	/**
	 * (non-Javadoc) Método de cargador de clases estándar para cargar una clase y
	 * resolverla.
	 * 
	 * @see ICancelOperationService#getListaComboEstatus()
	 */
	@Override
	public List<ComboResponse> getListaComboEstatus() {

		List<ComboResponse> listaCombo = new ArrayList<ComboResponse>();
		List<Object[]> resultQueryCatalogos = catalogoEstatusRepository.obtenerCatalogoEstatusCancelado();

		if (resultQueryCatalogos != null) {
			for (Object[] map : resultQueryCatalogos) {
				ComboResponse bean = new ComboResponse();
				bean.setId(((Integer) map[0]));
				bean.setValor((String) map[1]);
				listaCombo.add(bean);
			}
		}
		return listaCombo;
	}
}