package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.time.LocalDate;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * DTO para la respuesta de obtener cliente
 * 
 * @author Felipe Cazarez
 * @since 12/07/2022
 */
@Getter
@Setter
@NoArgsConstructor
public class CustomerResponse implements Serializable{
	/**
	 * id serial 
	 */
	private static final long serialVersionUID = 8545414376887009140L;
	/**
	 * Identificador del cliente
	 */
	private int idCliente;
	/**
	 * Razon social del cliente
	 */
	private String razonSocial;
	/**
	 * Nombre del cliente
	 */
	private String nombre;
	/**
	 * Apellido Materno del cliente
	 */
	private String apMaterno;
	/**
	 * Apellido Paterno del cliente
	 */
	private String apPaterno;
	/**
	 * Codigo del cliente
	 */
	private String buc;
	/**
	 * Condicion del cliente: cliente, ex-cliente o anticliente
	 */
	private String condicion;
	/**
	 * Nombre del ejecutivo
	 */
	private String ejecutivo;
	/**
	 * Se refiere a la fecha de nacimiento o de la constitucion de la empresa
	 */
	private LocalDate fecha;
	/**
	 * Segmento al que pertenece el cliente
	 */
	private Integer idSegmento;
	/**
	 * Personalidad del cliente: M persona moral - F persona fisica
	 */
	private String personalidad;
	/**
	 * RFC del cliente
	 */
	private String rfc;
	/**
	 * Nemonico
	 */
	private String nemonico;
}
