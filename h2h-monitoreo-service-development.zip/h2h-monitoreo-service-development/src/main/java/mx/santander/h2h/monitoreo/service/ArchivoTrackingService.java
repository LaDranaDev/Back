package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.response.ArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.NivelGeneralResponse;
import mx.santander.h2h.monitoreo.repository.IConsultaTrackingNativeRepository;
import mx.santander.h2h.monitoreo.repository.IConsultaTrackingRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class ArchivoTrackingService implements IArchivoTrackingService {

    @Autowired
    private IJasperReportService reportService;
    
    @Autowired
    private IConsultaTrackingRepository consultaTrackingRepository;
    
    @Autowired
    private IConsultaTrackingNativeRepository consultaTrackingNativeRepository;
    
    @Override
	public NivelGeneralResponse inicio(String codCliente) {
		NivelGeneralResponse response = new NivelGeneralResponse();
		String fecha = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
		response.setFecha(fecha);
		response.setBeanArchivo(obtenerConteoArchivos());
		response.setBeanArchivoDetalle(obtenerDetalleArchivos(codCliente));
		response.setCodCliente(codCliente);
		
		return response;
	}
    
    @Override
	public ArchivoResponse obtenerConteoArchivos() {
    	ArchivoResponse result = new ArchivoResponse();
    	String stringDate= new SimpleDateFormat("dd/MM/yyyy").format(new Date());
    	
    	List<Object[]> obtenerConteoArchivosResult = consultaTrackingRepository.obtenerConteoArchivos(stringDate);
    	
    	List<ArchivoResponse> listArchTotal = new ArrayList<ArchivoResponse>();
    	
    	if(obtenerConteoArchivosResult != null) {
    		for(Object[] conteoArchivo : obtenerConteoArchivosResult) {
    			ArchivoResponse archTotal = new ArchivoResponse();
				
				archTotal.setTotArchRecib((BigDecimal)conteoArchivo[0]);
				archTotal.setTotOpeRecib((BigDecimal)conteoArchivo[1]);
				archTotal.setTotMontoRecib((BigDecimal)conteoArchivo[2]);
				
				listArchTotal.add(archTotal);
    		}
    	}
    	
		BigDecimal totalArchivo= new BigDecimal("0.0");
		BigDecimal totalOperaciones= new BigDecimal("0.0");
		BigDecimal montoRecibido= new BigDecimal("0.0");
    	
    	for(ArchivoResponse iterrchivo: listArchTotal){	
    		totalArchivo = totalArchivo.add(iterrchivo.getTotArchRecib());
    		totalOperaciones = totalOperaciones.add(iterrchivo.getTotOpeRecib());
			montoRecibido = iterrchivo.getTotMontoRecib();		
			log.info("totalArchivo "+ totalArchivo);
			log.info("totalArchivo "+ totalArchivo);
			log.info("montoRecibido "+montoRecibido);
			
		}
    	result.setTotArchRecib(totalArchivo);
    	result.setTotOpeRecib(totalOperaciones);
		result.setTotMontoRecib(montoRecibido);
    	
    	return result;
	}

	@Override
	public ArchivoResponse obtenerDetalleArchivos(String codCliente) {
		String stringDate= new SimpleDateFormat("dd/MM/yyyy").format(new Date());
		return consultaTrackingNativeRepository.obtenerConteoArchivo(codCliente, stringDate).getArchivo();
	}

	@Override
	public List<ArchivoResponse> filtradoOperacionesInicio(List<ArchivoResponse> listaArchivo) {
		return null;
	}

	@Override
	public List<ArchivoResponse> obtenerListDetalleArchivos(String codCliente) {
		String stringDate= new SimpleDateFormat("dd/MM/yyyy").format(new Date());
		return consultaTrackingNativeRepository.obtenerListDetalleArchivosGeneral(stringDate, codCliente);
	}
	
	@Override
	public ReportResponse getReportXls(String cliente, String usuario) {
		ReportResponse response = new ReportResponse();
		try {
			ArchivoResponse archResponse = obtenerConteoArchivos();
			List<ArchivoResponse> lista = this.obtenerListDetalleArchivos(cliente);
			Map<String, Object> reportParam = new HashMap<>();
			
			reportParam.put("LOGO_SANTANDER", "\\imgs\\Santander.jpg");
			reportParam.put("titulo", "Consulta Tracking de Archivo" + " - " + "Nivel General");
			reportParam.put("lblUsuario", "Usuario: ");
			reportParam.put("usuario", usuario);
			reportParam.put("lblCliente", "Cliente");
			reportParam.put("cliente", cliente);
			reportParam.put("lblTotArchRecib","Archivos Recibidos: ");
			reportParam.put("totArchRecib", archResponse.getTotArchRecib().intValue());
			reportParam.put("lblTotOpeRecib", "Operaciones Recibidas: ");
			reportParam.put("totOpeRecib", archResponse.getTotOpeRecib().intValue());
			reportParam.put("lblTotMontoRecibFmt", "Monto Recibido: ");
			reportParam.put("totMontoRecibFmt", archResponse.getTotMontoRecib());
			reportParam.put("lblCodCliente", "Código Cliente");
			reportParam.put("lblTotalArchivos","Total de Archivos");
			reportParam.put("lblTotDupl","Estatus" + " " + "Duplicado");
			reportParam.put("lblTotRecib","Estatus" + " " + "Recibido");
			reportParam.put("lblTotRecha","Estatus" + " " + "Rechazado");
			reportParam.put("lblTotVald","Estatus" + " " + "Validado");
			reportParam.put("lblTotEnroll","Estatus" + " " + "Enviado Clientë");
			reportParam.put("lblTotEnProc","Estatus" + " " + "En Proceso");
			reportParam.put("lblTotEsp","Estatus" + " " + "En Espera");
			reportParam.put("lblTotProc","Estatus" + " " + "Procesado");
			
			response = reportService.getXls("NivelGeneral.jasper", reportParam, lista);
			
			response.setType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
		}catch (BusinessException e) {
			log.error("Error en la generacion del reporte en xls Consulta Tracking Nivel General.", e);
			throw e;
		} finally {
			log.info("Fin operacion: Genera reporte en xls Consulta Tracking Nivel General");
		}
		
		return response;
	}

}
