package mx.santander.h2h.monitoreo.util;

import java.util.HashMap;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UtilVostroDatosExportarNew {

	/**
	 * Constante para la exportacion
	 *  del Monotor de operaciones
	 * CANL_NOMB_CANL
	 */
	private static final String PART_QUERY_EXP_MSG_MSG_H2H="NULL TIPO_PAGO, NULL MODALIDAD,null IMPORTE_CARGO, MSG.MSG_H2H MSG_H2H, NULL MSG_ORDEN_PAGO, ";
	
	/**
	 * Constante para la exportacion
	 *  del Monotor de operaciones
	 * PART_QUERY_EXP_NULL´s
	 */
	private static final String PART_QUERY_EXP_NULL="NULL BUC_EMPLEADO,NULL SUCURSAL_TUTORA,NULL RFC,NULL TIPO,NULL NOMBRE_EMPLEADO,  ";
	
	/**
	 * Constante para la exportacion
	 *  del Monotor de operaciones
	 * PART_QUERY_EXP_FECH_APLI_FECHA_OPERACION
	 */
	private static final String PART_QUERY_EXP_FECH_APLI_FECHA_OPERACION="NULL NUMERO_CUENTA,TMP.FECH_OPER FECHA_PRESENTACION_INICIAL, TMP.FECH_APLI FECHA_OPERACION  ";
	
	/**
	 * Parte del Query para el acceso a datos
	 * del detalle a exportar del producto
	 * de Transferencias Internacionales Cambiarias
	 * TVMB
	 */
	private static final StringBuilder QUERY_EXP_MONITOR_TRAN_INT=new StringBuilder("")
	.append("NOMB_CANL, ID_REG, CLTE.BUC, DETA.NUM_CTA_ORD NUM_CTA_CARGO,DETA.NUM_CTA_BENE NUN_CTA_ABONO, ")
	.append("PROD.CVE_PROD_OPER, PROD.DESC_PROD,TMP.NOMBRE_ARCH,DETA.TXT_REF REFERENCIA,TMP.ID_ESTATUS,  EST.DESC_ESTATUS,  ")
	.append("DETA.IMP_ABONO_BENE IMPORTE, CNTR.NUM_CNTR, TMP.DIVI DIVISA,DETA.FCH_REG FECHA_REGISTRO, TMP.FECH_APLI FECHA_APLICACION, ")
	.append("PROD.VIST_PROD,null INTERMEDIARIO_ORD,DETA.COD_DIV_CTA_ORD DIVISA_ORD,DETA.TXT_NOM_BCO_PAG INTERMEDIARIO_REC,DETA.TXT_NOM_BENE BENEFICIARIO, ")
	.append("trim(DETA.TXT_REF_LEYE_ORD)||' '||trim(DETA.TXT_REF_NUME)||' '||trim(DETA.TXT_REF_CTE) COMENTARIO_1,to_char(ID_REG) COMENTARIO_2,NULL COMENTARIO_3, DETA.TXT_NOM_ORD TITULAR, NULL BANCO_RECEPTOR,  ")
	.append(PART_QUERY_EXP_MSG_MSG_H2H)
	.append("null NUM_ORDEN,NULL FECHA_LIMITE_PAGO,NULL NUM_SUCURSAL,NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA,  ")
	.append(PART_QUERY_EXP_NULL)
	.append(PART_QUERY_EXP_FECH_APLI_FECHA_OPERACION);
	
	/**
	 * Parte del Query para el acceso a datos
	 * del detalle a exportar del producto
	 * de Transferencias Vostro Interbancarias
	 * TVIB
	 */
	private static final StringBuilder QUERY_EXP_MONITOR_VOSTRO_INT=new StringBuilder("")
	.append("NOMB_CANL, ID_REG, CLTE.BUC, DETA.NUM_CTA_ORD NUM_CTA_CARGO,DETA.NUM_CTA_BENE NUN_CTA_ABONO,  ")
	.append("PROD.CVE_PROD_OPER, PROD.DESC_PROD,TMP.NOMBRE_ARCH,to_char(DETA.TXT_REFE_OUT) REFERENCIA,TMP.ID_ESTATUS,  EST.DESC_ESTATUS,  ")
	.append("DETA.IMP_ABONO_BENE IMPORTE, CNTR.NUM_CNTR, TMP.DIVI DIVISA,DETA.FCH_REG FECHA_REGISTRO, TMP.FECH_APLI FECHA_APLICACION, ")
	.append("PROD.VIST_PROD,BNCO.NOMBRE_BANCO INTERMEDIARIO_ORD,DETA.COD_DIV_CTA_ORD DIVISA_ORD,DETA.TXT_NOM_BCO_PAG INTERMEDIARIO_REC,DETA.TXT_NOM_BENE  BENEFICIARIO, ")
	.append("trim(DETA.TXT_REF_LEYE_ORD)||' '||trim(DETA.TXT_REF_NUME)||' '||trim(DETA.TXT_REF_CTE) COMENTARIO_1,to_char(ID_REG) COMENTARIO_2,NULL COMENTARIO_3, DETA.TXT_NOM_ORD TITULAR, NULL BANCO_RECEPTOR,  ")
	.append(PART_QUERY_EXP_MSG_MSG_H2H)
	.append("DETA.NUM_CTA_VOS NUM_ORDEN,NULL FECHA_LIMITE_PAGO,NULL NUM_SUCURSAL,NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA,  ")
	.append(PART_QUERY_EXP_NULL)
	.append(PART_QUERY_EXP_FECH_APLI_FECHA_OPERACION);
	
	/**
	 * Parte del Query para el acceso a datos
	 * del detalle a exportar del producto
	 * de Transferencias Vostro Mismo Banco
	 * TVMB
	 */
	private static final StringBuilder QUERY_EXP_MONITOR_VOSTRO_MB=new StringBuilder("")
	.append("NOMB_CANL, ID_REG, CLTE.BUC, DETA.NUM_CTA_ORD NUM_CTA_CARGO,DETA.NUM_CTA_BENE_FIN NUN_CTA_ABONO,  ")
	.append("PROD.CVE_PROD_OPER, PROD.DESC_PROD,TMP.NOMBRE_ARCH,DETA.REFE_SAF REFERENCIA,TMP.ID_ESTATUS,  EST.DESC_ESTATUS,  ")
	.append("DETA.IMP_MONTO_OPER IMPORTE, CNTR.NUM_CNTR, TMP.DIVI DIVISA,DETA.FECH_REG FECHA_REGISTRO, TMP.FECH_APLI FECHA_APLICACION, ")
	.append("PROD.VIST_PROD,'BANCO SANTANDER MEXICO' INTERMEDIARIO_ORD,DETA.COD_DIVI_CARG DIVISA_ORD,DETA.CUENTA_ID_BANCO INTERMEDIARIO_REC,DETA.TXT_NOM_BEN_FIN BENEFICIARIO, ")
	.append("trim(DETA.REFE_LEYE_ORDE)||' '||trim(DETA.REFE_NUM)||' '||trim(DETA.REFE_CLTE) COMENTARIO_1,to_char(ID_REG) COMENTARIO_2,NULL COMENTARIO_3, DETA.TXT_NOMB_ORDE TITULAR, NULL BANCO_RECEPTOR,  ")
	.append(PART_QUERY_EXP_MSG_MSG_H2H)
	.append("DETA.NUM_CTA_VOS NUM_ORDEN,NULL FECHA_LIMITE_PAGO,NULL NUM_SUCURSAL,NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA,  ")
	.append(PART_QUERY_EXP_NULL)
	.append(PART_QUERY_EXP_FECH_APLI_FECHA_OPERACION);
	
	/**
	 * Tabla para los campos
	 * del Query de la exportacion
	 * de datos del monitor
	 * de operaciones
	 */
	private static Map<String,String> tablasSelCamposExpMonitor= new HashMap<String,String>();
	
	/**
	 * inicializacion del mapa de productos
	 * LFER 09-03-2018
	 */
	static{
		
		tablasSelCamposExpMonitor.put("32", QUERY_EXP_MONITOR_TRAN_INT.toString());
		tablasSelCamposExpMonitor.put("38", QUERY_EXP_MONITOR_VOSTRO_INT.toString());
		tablasSelCamposExpMonitor.put("39", QUERY_EXP_MONITOR_VOSTRO_MB.toString());
	}
	
	/**
	 * 
	 * @param tipoOper
	 * @return
	 */
	public static boolean esVostro(String tipoOper) {
		if(tipoOper==null ||tipoOper.isEmpty()){
			return false;
		}
		return tipoOper.toUpperCase().contains("38")
		|| tipoOper.toUpperCase().contains("39");
	}

	/**
	 * 
	 * @param cveOperProd
	 * @param query
	 */
	public static String getQuerySelectExportar(String cveOperProd, StringBuilder queryA) {
		StringBuilder querySE = new StringBuilder();
		log.info("getQuerySelectExportar - esVostro: " + cveOperProd);
		if(esVostro(cveOperProd)){
			queryA.setLength(0);
			querySE.append("SELECT PROD.* FROM (SELECT ");
			querySE.append( tablasSelCamposExpMonitor.get(cveOperProd));
		}
		log.info("getQuerySelectExportar - Termino: " + querySE.toString());
		return querySE.toString();
	}
	
	/**
	 * Si hay mas inner igual
	 * agregar un mapa con sud Inners 
	 * requeridos
	 * @param cveOperProd
	 * @return
	 */
	public static String addInnerVostro(String cveOperProd) {
		if("38".equalsIgnoreCase(cveOperProd)){
			return "LEFT JOIN H2H_CAT_BNCO BNCO on DETA.COD_INT_REC=BNCO.BIC ";
		}
		return "";
	}
	
	/**
	 * completaQueryByCveProdOper
	 * @param query
	 */
	public static String completaQueryByCveProdOper(StringBuilder querys, Map<String, Object> params) {
		StringBuilder queryCPO = new StringBuilder();
		queryCPO
		.append("LEFT JOIN H2H_CTA_INFO CNTA_ABON ON TMP.CNTA_ABON = CNTA_ABON.NUME_CTA AND CNTA_ABON.TIPO_CTA = 'B' ")
		.append("LEFT JOIN H2H_CTA_INFO CNTA_CARG ON TMP.CNTA_CARG = CNTA_CARG.NUME_CTA AND CNTA_CARG.TIPO_CTA = 'O' ")
		.append("LEFT JOIN H2H_CAT_DIVISA DIVI_ABON ON DIVI_ABON.ID_CAT_DIVISA = CNTA_ABON.ID_CAT_DIVISA ")
		.append("LEFT JOIN H2H_CAT_DIVISA DIVI_CARG ON DIVI_CARG.ID_CAT_DIVISA = CNTA_CARG.ID_CAT_DIVISA ");
		
//		params.put("cntaAbon", "B");
//        params.put("cntaCarg", "O");
		return queryCPO.toString();
	}
}
