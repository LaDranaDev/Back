package mx.santander.h2h.monitoreo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import mx.santander.h2h.monitoreo.constants.RoutesConstant;
import mx.santander.h2h.monitoreo.model.request.ArchivoCancelRequest;
import mx.santander.h2h.monitoreo.model.response.ArchivoCancelResponse;
import mx.santander.h2h.monitoreo.model.response.CancelOperationResponse;
import mx.santander.h2h.monitoreo.model.response.CancelOperationUpdResponse;
import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import mx.santander.h2h.monitoreo.service.ICancelOperationBaseService;
import mx.santander.h2h.monitoreo.service.ICancelOperationConsultaService;
import mx.santander.h2h.monitoreo.service.ICancelOperationService;

/**
 * Clase controller para la pantalla de cancelar operacion
 * contiene los metodos para llenar los combobox de estatus cancelado
 * el listado de operaciones disponisbles para cancelar,
 * hace la busqueda de operaciones por buc del cliente, adicional
 * permite hacer la actualización de los de las operaciones para
 * poner el estatus cancelado
 * @author NTTDATA-NRL
 * @version 1.0
 */
@Validated
@RestController
@RequestMapping(RoutesConstant.PATH_CANCEL_OPERACION)
public class OperationCancelController {
    @Autowired
    private ICancelOperationService service;
    
    @Autowired
    private ICancelOperationBaseService serviceBase;
    @Autowired
    private ICancelOperationConsultaService serviceConsulta;
    /**
     * Metodo para hacer la busqueda del encabezado por numero de cliente
     * @param bucCliente
     */
    @Operation(summary = "Busca operaciones para cancelar por buc.")
    @GetMapping(path = RoutesConstant.PATH_SEARCH_CANCEL_BUC, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CancelOperationResponse> getCancelOperationSearch(
    		@Pattern(regexp = "(^[a-zA-Z0-9]+$)?", message = "Datos de usuario no valido")
    		@Size(min = 0, max = 15, message = "Datos de Usuario erroneo")
    		@PathVariable("bucCliente")
            String bucCliente
    ) {
        return ResponseEntity.ok(
        		serviceConsulta.consultaCancel(bucCliente));
    }

    /**
     * Metodo apra buscar archivos por el nombrel del archivo, bucCliente
     * @param request [bucCliente, nomArchivo, estatus]
     * @param page paginación
     * @return ResponseEntity
     */
    @Operation(summary = "Busca archivos que se pueden cancelar.")
    @PostMapping(path = RoutesConstant.PATH_SEARCH_CANCEL_ARCHIVO, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Page<ArchivoCancelResponse>> getCancelArchiveSearch(
    	@Valid
    	@RequestBody ArchivoCancelRequest request, 
		Pageable page) {
        return ResponseEntity.ok(
                service.searchArchive(request,page));
    }

    /**
     * Metodo para cancelar una o varias operaciones, si recibe 0 cancela los
     * registros relacionados a un buc si se le mandan en especificio son los que
     * cancela si se manda cero cancela todas
     * @param idRegistros [1,2,3] o 0
     * @param request [bucCliente,NomArchivo, estatus]
     * @return ResponseEntity
     */
    @Operation(summary = "Cancela operaciones pueden ser una,algunas o todas.")
    @PutMapping(path = RoutesConstant.PATH_CANCEL_OPERACION_DO, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CancelOperationUpdResponse> cancelaOperacion(
    		@Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    		@PathVariable String idRegistros, 
    		@Valid
    		@RequestBody ArchivoCancelRequest request){
        return ResponseEntity.ok(service.cancelOperacion(idRegistros,request));
    }

    /**
     * Metodo que obtiene la lista de estatus cancelados del centro.
     * @return ResponseEntity<List<ComboResponse>>
     */
    @Operation(summary = "Estatus cancelados del centro")
    @GetMapping(path = RoutesConstant.PATH_CANCEL_CMB_ESTAT_CENTRO, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ComboResponse>> getComboEstatusCentro(){
        return ResponseEntity.ok(serviceBase.getListaComboEstatusCentro());
    }

    /**
     * Metodo que obtiene la lista de estatus cancelados.
     * @return ResponseEntity<List<ComboResponse>>
     */
    @Operation(summary = "Estatus cancelados.")
    @GetMapping(path = RoutesConstant.PATH_CANCEL_CMB_ESTAT, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ComboResponse>> getListaEstus(){
        return ResponseEntity.ok(serviceBase.getListaComboEstatus());
    }

}
