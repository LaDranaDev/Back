package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Dto para los datos de salida del PUT/GET
 * 
 * @author Z483900
 *
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class PutGetDto extends PutGetSftpCnDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -201972467441813728L;

	/**
	 * Directorio 	Se define un directorio para el Put y otro para Get) 
	 * (Requerido/Alfanumérico [A-Z a-z 0-9 -_ /  \ ] longitud maxima 50 caracteres)
	 */
	private String directorio;

	/**
	 * Directorio para Get
	 */
	private String directorioGet;

	/**Servidor  (Requerido/Alfanumerico [ 0-9 . ] longitud maxima 15 caracteres)*/
	private String  servidor;

	/**Puerto (Requerido/Numerico [ 0-9 ] longitud máxima 6 caracteres)*/
	private String puerto;

	/**Patron de Archivos (Opcional/Alfanumérico/longitud maxima 50 caracteres)*/
	private String patron;

	/**Patron de Archivos para get(Opcional/Alfanumérico/longitud maxima 50 caracteres)*/
	private String patronGet;	

	/**Id para relacionar con el protocolo*/
	private String idPtclPara;

	/**Tipo de porcesamiento: P - PUT, G - GET */
	private String tipoProceso;

	/**Usuario (Requerido/Alfanumerico [A-Z a-z 0-9 -_ /  \ ] longitud maxima 50 caracteres)*/
	private String userId;

	/**Bandera Activo(A) o Inactivo(I)*/
	private String estatus;

	/**ID del protocolo 1:SFTP,2:ConnectDirect*/
	private String idProtocolo;

	/**variable para el id del Contrato */
	private String idContrato;

	/**variable para ID_PTCL_PATH*/
	private String idPtclPath;

	/** DTO que almacena los datos de WS*/
	private PutGetWSDto putGetWSDto;

	/**
	 * numeroContrato
	 */
	private String numeroContrato;

	/**
	 * codigoCliente
	 */
	private String codigoCliente;

}
