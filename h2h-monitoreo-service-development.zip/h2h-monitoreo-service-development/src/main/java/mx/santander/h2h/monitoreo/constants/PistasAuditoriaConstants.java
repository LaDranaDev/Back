package mx.santander.h2h.monitoreo.constants;

/**
 * Clase de constantes para el guardado de pistas de auditorias
 * 
 * Mensajes y valores para las pistad de auditorias
 * 
 * @author Paul Quintero
 * @since 06/06/22
 */
public final class PistasAuditoriaConstants {
	/**
	 * Respuesta de exito
	 */
	public static final String SUCCESS = "Exitoso";
	/**
	 * Respuesta de error
	 */
	public static final String ERROR = "Error";

	/** Tabla - Consulta Monitor Saldos**/
	public static final String TABLA_H2H_SALDOS_REINT = "H2H_CONS_SALDO_REIN";

	/**Servicio/Transaccion - Consulta Monitor Saldos**/
	public static final String SERV_CONS_SALDOS = "ConsultMonitorSaldo";

	/**
	 * Constructor
	 */
	private PistasAuditoriaConstants() {
	}

}
