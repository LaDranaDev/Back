/**
 * GenerateVouchersImplService.java
 */
package mx.santander.h2h.monitoreo.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersControllerResponse;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersDtoResponse;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersTotalResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsHistoryResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.repository.IContractConnectionManagementPutGetEntityManagerRepository;
import mx.santander.h2h.monitoreo.repository.IGenerateVouchersEntityManagerRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailRepository;
import mx.santander.h2h.monitoreo.util.IGenerateVouchersUtils;
import mx.santander.h2h.monitoreo.util.OperationsMonitorUtil;

/**
 * Clase service para generar comprobantes de formatos cdmx.
 * 
 * @author sbautish
 *
 */
@Service
@Slf4j
public class GenerateVouchersImplService implements IGenerateVouchersService {

	/** Constante DETALLE_DTO. */
	private static final String DETALLE_DTO = "detalleOperacionDTO";

	/** Constante OPERACION_EN_PROCESO */
//	private static final String OPERACION_EN_PROCESO = "OPERACION_EN_PROCESO";

	@Autowired
	private IOperationsMonitorService iOperationsMonitorService;

	@Autowired
	private IContractConnectionManagementPutGetEntityManagerRepository iContractConnectionManagementPutGetEntityManagerRepository;

	@Autowired
	private IGenerateVouchersEntityManagerRepository iGenerateVouchersEntityManagerRepository;

	@Autowired
    private IOperationsDetailRepository detailRepository;

	@Autowired
    private OperationsMonitorUtil util;

	@Autowired
	private IGenerateVouchersUtils iGenerateVouchersUtils;

	/**
	 * Método que realiza la busqueda de comprobantes para la pantalla inicial.
	 */
	@Override
	public GenerateVouchersControllerResponse findVouchersCdmx() {

		GenerateVouchersControllerResponse generateVouchersControllerResponse = new GenerateVouchersControllerResponse();

		Map<String, Object> parametros = new HashMap<String, Object>();

		try {

			parametros.put("listaEstatusCmb", iOperationsMonitorService.catalogs().getOperationsMonitorCatalogsResponse().getEstatus());
			parametros.put("rangoFechas", Integer.valueOf(iContractConnectionManagementPutGetEntityManagerRepository.getParameters("MON_OP_RANGO_FECHAS")));
			parametros.put("listaTipoPagoCmb", iGenerateVouchersEntityManagerRepository.getListPaymentType().getListaTipoPago());

			generateVouchersControllerResponse.setParametros(parametros);

		} catch (BusinessException be) {

			log.info("Error al inicializar la vista ", be);
			log.info("Error al inicializar la vista: " + be.getMessage());

			/**Se pinta la excepcion en la consola*/
			parametros.put("errorCode", "ERR_MONITOR_INIT");

		}

		return generateVouchersControllerResponse;
	}

	/**
	 * Descripción: Método que realiza la consulta de operaciones
	 *
	 * @author sbautish autor
	 * @param operationsMonitorQueryRequest objeto de entrada para filtro en consulta de datos
	 *
	 */
	@Override
	public GenerateVouchersControllerResponse findOperationsMonitor(
			OperationsMonitorQueryRequest operationsMonitorQueryRequest, Pageable pageable) {

		return iGenerateVouchersUtils.findOperationsMonitor(operationsMonitorQueryRequest, findVouchersCdmx());

	}

	/**
	 * Obtiene el importe global o total y total de archivos de comprobantes formato
	 *
	 */
	@Override
	public GenerateVouchersTotalResponse findTotal(OperationsMonitorQueryRequest operationsMonitorQueryRequest) {

		GenerateVouchersTotalResponse generateVouchersTotalResponse = new GenerateVouchersTotalResponse();

		try {

//			BitacoraUtil.bitacora().grabaPistaString(SERV_NAME,OperacionAuditoria.MONITOR_CONSULTAR_OPERACION.getIdCodigoOperacion().toString(),
//					ConstantesAuditoria.TIPO_OPER_CONS,TABLE_H2H_REG, CANAL_APP_ADMIN, null, null,NA, architechBean, getLoggingBean());

//			BitacoraUtil.bitacora().grabaPistaString(SERV_NAME,OperacionAuditoria.MONITOR_CONSULTAR_OPERACION.getIdCodigoOperacion().toString(),
//					ConstantesAuditoria.TIPO_OPER_CONS,TABLE_H2H_REG, CANAL_APP_ADMIN, null, null,NA, architechBean, getLoggingBean());

			generateVouchersTotalResponse.setImporteGlobal("$".concat(iGenerateVouchersEntityManagerRepository.getLumpSum(operationsMonitorQueryRequest)));
			generateVouchersTotalResponse.setTotalArchivos(iGenerateVouchersEntityManagerRepository.getTotalFiles(operationsMonitorQueryRequest));

		} catch (BusinessException be) {

			log.info("Error al consultar las operaciones complementarias", be);

			generateVouchersTotalResponse.setImporteGlobal("ERROR...");

			throw new BusinessException(be.getCode(), be.getMessage());

		}

		return generateVouchersTotalResponse;
	}

	/**
	 * Método que realiza la consulta de operaciones con paginación.
	 * 
	 */
	@Override
	public Page<OperationsMonitorQueryResponse> paginarOperaciones(
			OperationsMonitorQueryRequest operationsMonitorQueryRequest, Pageable pageable) {

		GenerateVouchersControllerResponse generateVouchersControllerResponse = new GenerateVouchersControllerResponse();

		try {

			generateVouchersControllerResponse.setListaOperaciones(iGenerateVouchersEntityManagerRepository.findOperations(operationsMonitorQueryRequest));

		} catch (BusinessException be) {

			log.error("ERROR ", be);
			log.error("Error al consultar las operaciones");
			generateVouchersControllerResponse.setParametros(new HashMap<String, Object>());
			generateVouchersControllerResponse.getParametros().put("errorCode", "ERR_MONITOR_CONSULTA");

		}

		return new PageImpl<>(generateVouchersControllerResponse.getListaOperaciones(), pageable, generateVouchersControllerResponse.getListaOperaciones().size());
	}

	/**
	 * Descripción : Método que realiza la consulta del detalle de la operación
	 */
	@Override
	public GenerateVouchersControllerResponse detalleOperaciones(OperationsMonitorQueryResponse operationsMonitorQueryResponse) {

		GenerateVouchersControllerResponse generateVouchersControllerResponse = new GenerateVouchersControllerResponse();
		generateVouchersControllerResponse.setParametros(new HashMap<String, Object>());

		log.debug("Consultando detalle para la operación " + Encode.forJava(operationsMonitorQueryResponse.getIdOperacion()));

		OperationsMonitorQueryResponse detalleOperacion = util.obtenerDetalleOperacion(operationsMonitorQueryResponse.getVistProd(), operationsMonitorQueryResponse.getIdOperacion());

		generateVouchersControllerResponse.getParametros().put(DETALLE_DTO, detalleOperacion);

		log.info("VISTA DEL PRODUCTO : " + Encode.forJava(operationsMonitorQueryResponse.getVistProd()) + " idProd: " + Encode.forJava(detalleOperacion.getIdProducto()));

		return generateVouchersControllerResponse;

	}

	/**
	 * Descripción : Método que realiza la consulta del historial de la operación
	 */
	@Override
	public List<OperationsHistoryResponse> historialOperaciones(String idOperacion) {

		log.info("Historial de operaciones");

		return detailRepository.obtenerHistorialOperacion(idOperacion);

	}

	/**
	 * Descripción : Método que realiza la consulta del concepto valor
	 */
	@Override
	public GenerateVouchersDtoResponse conceptoValor(String lineaCaptura) {

		/**
		 * Se graba bitacora
		 */
//		BitacoraUtil.bitacora().grabaPistaString(SERV_NAME, 
//				OperacionAuditoria.MONITOR_CONSULTAR_OPERACION.getIdCodigoOperacion().toString(), 
//				ConstantesAuditoria.TIPO_OPER_CONS, TABLE_H2H_REG, CANAL_APP_ADMIN, null, null, 
//				NA, architechBean, getLoggingBean());

		return iGenerateVouchersEntityManagerRepository.conceptoValor(lineaCaptura);

	}


}

