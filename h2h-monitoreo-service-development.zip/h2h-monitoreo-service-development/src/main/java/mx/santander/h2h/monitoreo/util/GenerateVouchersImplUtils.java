package mx.santander.h2h.monitoreo.util;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.constants.ReportConstants;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.report.request.GenerateVouchersReportDto;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersControllerResponse;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersDtoResponse;
import mx.santander.h2h.monitoreo.repository.IContractConnectionManagementPutGetEntityManagerRepository;
import mx.santander.h2h.monitoreo.repository.IGenerateVouchersEntityManagerRepository;
import mx.santander.h2h.monitoreo.service.IJasperReportService;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;

@Component
@Slf4j
public class GenerateVouchersImplUtils implements IGenerateVouchersUtils {

	@Autowired
	private IContractConnectionManagementPutGetEntityManagerRepository iContractConnectionManagementPutGetEntityManagerRepository;

	@Autowired
	private IGenerateVouchersEntityManagerRepository iGenerateVouchersEntityManagerRepository;

	@Autowired
	private IGenerateVouchersValidateDateUtils iGenerateVouchersValidateDateUtils;

	/**
	 * Servicio genérico de reportería
	 */
	@Autowired
	private IJasperReportService iJasperReportService;

	/**
	 * Método para obtener la lista de operaciones con paginación
	 * 
	 * @param operationsMonitorQueryRequest Objeto con datos de entrada del request
	 * @param findVouchersCdmx Objeto a asignar los datos de operación encontrados
	 * @param generateVouchersDtoResponse Objeto con datos adicionales de operaciones
	 * @return Objeto con datos nuevos de operaciones
	 * @throws NumberFormatException excepción controlada
	 */
	@Override
	public GenerateVouchersControllerResponse findOperations(OperationsMonitorQueryRequest operationsMonitorQueryRequest,
			GenerateVouchersControllerResponse findVouchersCdmx,
			GenerateVouchersDtoResponse generateVouchersDtoResponse) throws NumberFormatException {

		findVouchersCdmx.setTotalOperaciones(generateVouchersDtoResponse.getTotalOperaciones());
		findVouchersCdmx.setListaSize(generateVouchersDtoResponse.getTotalOperaciones());

//				BitacoraUtil.bitacora().grabaPistaString(SERV_NAME,OperacionAuditoria.MONITOR_CONSULTAR_OPERACION.getIdCodigoOperacion().toString(),
//						ConstantesAuditoria.TIPO_OPER_CONS,TABLE_H2H_REG, CANAL_APP_ADMIN, null, null,NA, sessionBean, getLoggingBean());

		findVouchersCdmx.setLimiteRegistrosExportar(
				Integer.valueOf(
						iContractConnectionManagementPutGetEntityManagerRepository.getParameters("NUM_REG_EXPO_MONOP")));
		findVouchersCdmx.setTotalPaginas((int)Math.ceil(Double.parseDouble(generateVouchersDtoResponse.getTotalOperaciones()) / 20.0));
		findVouchersCdmx.setListaOperaciones(iGenerateVouchersEntityManagerRepository.findOperations(operationsMonitorQueryRequest));

		findVouchersCdmx.setInicio(1);
		findVouchersCdmx.setFin(calculaInicioFin(findVouchersCdmx.getTotalPaginas()));

		findVouchersCdmx.setRealizaCalculo(Boolean.TRUE);

		return findVouchersCdmx;

	}

	/**
	 * Método que realiza la consulta de operaciones
	 * 
	 * @param operationsMonitorQueryRequest Objeto con datos de entrada para consulta
	 * @return retorno de Objeto con resultados encontrados de operaciones
	 * @throws BusinessException Excepción controlada
	 * @throws NumberFormatException Excepción controlada
	 */
	@Override
	public GenerateVouchersControllerResponse findOperationsMonitor(
			OperationsMonitorQueryRequest operationsMonitorQueryRequest, GenerateVouchersControllerResponse findVouchersCdmx)
			throws BusinessException, NumberFormatException {

		iGenerateVouchersValidateDateUtils.validateDate(operationsMonitorQueryRequest);

		try {

			GenerateVouchersDtoResponse generateVouchersDtoResponse = iGenerateVouchersEntityManagerRepository.findOperationsCount(operationsMonitorQueryRequest);

//			BitacoraUtil.bitacora().grabaPistaString(SERV_NAME,OperacionAuditoria.MONITOR_CONSULTAR_OPERACION.getIdCodigoOperacion().toString(),
//					ConstantesAuditoria.TIPO_OPER_CONS,TABLE_H2H_REG, CANAL_APP_ADMIN, null, null,NA, sessionBean, getLoggingBean());

			if (StringUtils.isNotBlank(generateVouchersDtoResponse.getTotalOperaciones()) && !"0".equals(generateVouchersDtoResponse.getTotalOperaciones())) {

				findVouchersCdmx = findOperations(operationsMonitorQueryRequest, findVouchersCdmx, generateVouchersDtoResponse);

			} else {

				findVouchersCdmx.getParametros().put("MSG", "MON_INF01");

			}

		} catch (BusinessException be) {

			log.error("Error al consultar las operaciones " + be.toString());
			findVouchersCdmx.getParametros().put("errorCode", "ERR_MONITOR_CONSULTA");
			throw new BusinessException(be.getCode(), be.getMessage());

		}

		return findVouchersCdmx;

	}

	/**
	 * Descripción : Método que realiza la generación de jasper report a retornar en el controller
	 * 
	 * @param streamSubreport InputStream con la data para el reporte
	 * @return JasperReport reporte jasper generado
	 * @throws JRException exepcion de jasper que sera cachada en el controller
	 */
	@Override
	public JasperReport generateJR(InputStream streamSubreport) throws JRException {

		JasperReport report = null;

		final JRException[] excepcion = { null };

		try {

			report = (JasperReport) JRLoader.loadObject(streamSubreport);

		} catch (JRException e) {

			excepcion[0] = e;

		}

		if (excepcion[0] != null) {
			throw excepcion[0];
		}

		return report;

	}

	@Override
	public ReportResponse getReportePdfOrXlsx(String typeReport, String jasperName, Map<String, Object> params, List<?> dataSet) {

		ReportResponse report = null;

		if(ReportConstants.PDF_EXTENTION.equals(typeReport)) {

			report = this.iJasperReportService.getPdf(jasperName, params, dataSet);
		}else {

			report = this.iJasperReportService.getXls(jasperName, params, dataSet);
		}

		report.setName("ConsultaComprobantesCdmx ".concat(generarFecha()).concat(".xlsx"));

		return report;
	}

	/**
	 * getTypeReport Realizar la validacion del tipo de reporte a generar y asigna
	 * el nombre del reporte y su tipo de archivo
	 * 
	 * @param typeReport tipo de reporte (xls o pdf)
	 * @return Map<String, String> devuelve el nombre del reporte y su tipo de archivo
	 */
	@Override
	public Map<String, String> getTypeReport(String typeReport) {

		Map<String, String> report = new HashMap<>();

		switch (typeReport) {

			case ReportConstants.PDF_EXTENTION:
				report.put(ReportConstants.PARAM_NAME_REPORT, ReportConstants.REPORTE_COMPROBANTES_CDMX);
				report.put(ReportConstants.PARAM_MIME_TYPE, MediaType.APPLICATION_PDF_VALUE);
				break;

			case ReportConstants.XLSX_EXTENTION:
				report.put(ReportConstants.PARAM_NAME_REPORT, ReportConstants.REPORTE_COMPROBANTES_CDMX);
				report.put(ReportConstants.PARAM_MIME_TYPE, MediaType.APPLICATION_OCTET_STREAM_VALUE);
				break;

			default:
				break;

		}

		return report;
	}

	/**
	 * Método que genera el reporte excel de operaciones
	 * 
	 * @param operationsMonitorQueryRequest Objeto con datos de entrada
	 * @param xlsxExtention extención xlsx del archivo, excel
	 * @return retorna Objeto de reporte excel
	 */
	@Override
	public ReportResponse exportarOperacionesXlsx(OperationsMonitorQueryRequest operationsMonitorQueryRequest,
			String xlsxExtention) {

		final List<Object> dataList = new ArrayList<Object>();

		GenerateVouchersReportDto generateVouchersReportDto = new GenerateVouchersReportDto();

		operationsMonitorQueryRequest.setTamanioPagina("-1");

		operationsMonitorQueryRequest.setTamanioPagina(String.valueOf(20));

		Map<String, Object> mapParams = new HashMap<>();

		mapParams.put("USER", operationsMonitorQueryRequest.getUser());

		try {

			/** Se genera el jasper secundario */
			mapParams.put("SUB_REPORTE_CDMX", generateJR(
					new ClassPathResource(
							new StringBuilder(ReportConstants.REPORTS_FOLDER).append("ComprobantesCDMXSub.jasper").toString())
					.getInputStream()));

		} catch (JRException e) {

			log.error("ERROR: No se pudo obtener el archivo ComprobantesCDMXSub.jasper");
			log.error(e.getCause().toString());
			log.error(e.getMessage());

		} catch (NullPointerException | BusinessException ex) {

			log.error("ERROR: No se pudo obtener el archivo ComprobantesCDMXSub.jasper");
			log.error(ex.getCause().toString());
			log.error(ex.getMessage());

		} catch (IOException e) {
			
			log.error("ERROR: No se pudo obtener el archivo ComprobantesCDMXSub.jasper");
			log.error(e.getCause().toString());
			log.error(e.getMessage());
		}

		generateVouchersReportDto.setListaOperaciones(iGenerateVouchersEntityManagerRepository.consultaOperacionesExportar(operationsMonitorQueryRequest));
		generateVouchersReportDto.setConsultaOperaciones(operationsMonitorQueryRequest);

		dataList.add(generateVouchersReportDto);

		return getReportePdfOrXlsx(xlsxExtention, getTypeReport(xlsxExtention).get(ReportConstants.PARAM_NAME_REPORT), mapParams, dataList);

	}

	/**
	 * Descripción : Método que realiza la generación de la fecha
	 * 
	 * @return Dato de la fecha en texto
	 */
	public static String generarFecha() {

		/** Se genera un dateformat */
		final SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault());

		/** Se retorna la fecha:hora */
		return dateFormat.format(new Date()).toString();

	}

	/**
	 * Descripción : Método que realiza el set de inicio y fin de paginación
	 * 
	 * @param totalPaginas total de páginas
	 * @return retorna fin páginas
	 */
	private Integer calculaInicioFin(Integer totalPaginas) {

		Integer fin = 0;

		if (totalPaginas < 17) {
			fin = totalPaginas;
		} else {
			fin = 17;
		}

		return fin;
	}

}
