package mx.santander.h2h.monitoreo.model.entity;

import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.io.Serializable;

/**
 * Entidad para la tabla H2H_CNTR.
 *
 * @author Jesus Soto Aguilar
 * @since 13/04/2023
 */
@Entity
@Getter
@Setter
@Table(name = "H2H_CNTR")
public class ContractEntity implements Serializable {
	/**
	 * serial.
	 */
	private static final long serialVersionUID = -574413706470188232L;
	/**
	 * Identificador del contrato
	 */
	@Id
	@Column(name = "ID_CNTR")
	private Long idContrato;
	/**
	 * Numero de contrato asignado al cliente
	 */
	@Column(name = "NUM_CNTR")
	private String numeroContrato;
	/**
	 * Certificado HSM.
	 */
	@Column(name = "CVE_CANL_HSM")
	private String cveCertHSM;
	/**
	 * Periodo de Habilitacion de cuentas
	 */
	@Column(name = "HABILITA_BENE")
	private Float periodoHabilitacion;
	/**
	 * Numero de dias de anticipacion para programar archivos
	 */
	@Column(name = "DIAS_PROG_ARCH")
	private Integer diasProgramarArchivos;
	/**
	 * Bandera para indicar si se va a verificar la cuenta beneficiaria
	 */
	@Column(name = "BAND_BENEF")
	private String verificarCuentaBeneficiaria;
	/**
	 * Bandera para indicar si se va a utilizar la cuenta CLABE para Estado de
	 * Cuenta
	 */
	@Column(name = "BAND_CLABE_ECTA")
	private String usarClabeParaEdoCta;
	/**
	 * Bandera para indicar si se va a utilizar cifras de control en SFG.
	 */
	@Column(name = "BAND_CIF_CTRL")
	private String usarCifrasControl;
	/**
	 * Bandera para indicar si esta permitido el cambio de producto (SPEI, TEF)
	 */
	@Column(name = "BAND_CAMB_PROD")
	private String bandCambioProd;
	/**
	 * Contiene los valores del cliente al que se esta dando de alta el contrato
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CLTE")
	private CustomerEntity cliente;
	/**
	 * La propiedad bandActCont.
	 */
	@Column(name = "BAND_ACT_CONT")
	private String bandActCont;
	/**
	 * bic.
	 */
	@Column(name = "BIC")
	private String bic;
	/**
	 * messagePartner.
	 */
	@Column(name = "MSG_PTNR")
	private String messagePartner;
	/**
	 * tipoTransferencia.
	 */
	@Column(name = "TIPO_TRAN")
	private String tipoTransferencia;
	/**
	 * Alias del contrato
	 */
	@Column(name = "ALIAS")
	private String alias;
	/**
	 * back Confriming
	 */
	@Column(name = "CTR_BACK_CONF")
	private String backConfirming;
	/**
	 * Cod bice
	 */
	@Column(name="COD_BICE")
	private String codBice;
	/**
	 * Band Duplicado
	 */
	@Column(name = "BAND_DUPLICADO")
	private String bandDuplicado;
	/**
	 * Dev Online
	 */
	@Column(name="CNL_REP_DEV_ONL")
	private Integer repDevOnline;
	/**
	 * Ip del cliente
	 */
	@Column(name="IP_CLIENTE")
	private String ipCliente;
	/**
	 * Id canal rep optimus
	 */
	@Column(name = "ID_CANL_REP_OPTIMUS")
	private Integer idCanalRepOptimus;
}
