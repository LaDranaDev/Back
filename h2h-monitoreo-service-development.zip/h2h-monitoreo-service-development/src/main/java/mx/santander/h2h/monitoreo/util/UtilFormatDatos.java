package mx.santander.h2h.monitoreo.util;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;

public final class UtilFormatDatos {

	/**
	 * Constructor privado.
	 */
	private UtilFormatDatos() {
	}
	
	/**
	 * Asigna el valor por default indicado al Object
	 * en caso de ser null, cadena vacia o la cadena "null".
	 * <br>En caso de tener otro valor respeta el valor original, quitando los espacios.
	 * @param objeto Object
	 * @param valorDefault String
	 * @return String
	 */
	public static String defaultObjectString(Object objeto, String valorDefault) {
		String temporal = StringUtils.EMPTY;
		if (objeto != null) {
			temporal = objeto.toString();
		}
		if ("null".equals(StringUtils.trimToEmpty(temporal))) {
			temporal = StringUtils.EMPTY;
		}
		return StringUtils.defaultIfEmpty(StringUtils.trimToEmpty(temporal), valorDefault);
	}
	
	/**
	 * Si el objeto es una divisa de la forma MN o MXN retorna MXP.
	 * <br>Si es null retorna cadena vacia
	 * <br>En caso de tener otro valor respeta el valor original, quitando los espacios.
	 * @param objeto Object
	 * @return String
	 */
	public static String traduceDivisa(Object objeto) {
		String temporal = UtilFormatDatos.defaultObjectString(objeto, "");
		if ("MN".equals(temporal)) {
			return "MXP";
		}
		if ("MXN".equals(temporal)) {
			return "MXP";
		}
		return temporal;
	}
	
	/**
	 * Traduce tipo pago.
	 * <br> E: efectivo <br> C: cheque
	 * @param objeto Object
	 * @return String
	 */
	public static String traduceTipoPago(Object objeto) {
		String temporal = UtilFormatDatos.defaultObjectString(objeto, "");
		if ("E".equals(temporal)) {
			return "E-EFECTIVO";
		}
		if ("C".equals(temporal)) {
			return "C-CHEQUE";
		}
		return "OTRO";
	}

	/**
	 * Traduce tipo pago para PAGO DIRECTO.
	 * <br> E: efectivo <br> C: cheque
	 * @param objeto Object
	 * @return String
	 */
	public static String traduceTipoPagoPD(Object objeto) {
		String temporal = UtilFormatDatos.defaultObjectString(objeto, "");
		if ("E".equals(temporal)) {
			return "EFECTIVO";
		} else if ("C".equals(temporal)) {
			return "CHEQUE";
		} else {
			return "ABONO A CUENTA";
		}
	}
	
	/**
	 * Traduce el objeto pasado como parametro a importe.
	 * <br> cadena vacia y null se traduce a 0.00 
	 * @param objeto Objet
	 * @return String
	 */
	public static String traduceImporte(Object objeto) {
		DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols();
		formatSymbols.setDecimalSeparator('.');
		formatSymbols.setGroupingSeparator(',');
		final DecimalFormat decimalFormat = new DecimalFormat("###,###,###,###,##0.00", formatSymbols);
		return decimalFormat.format(Double.valueOf(defaultObjectString(objeto, "0.00")));
	}
	
	/**
	 * Retorna vacio si la cadena es un 0, puede tener o no espacios
	 * @param original String
	 * @return String
	 */
	public static String vacioSiCero(String original) {
		if ("0".equals(StringUtils.trimToEmpty(original))) {
			return "";
		}
		return original;
	}
	
	/**
	 * Acompleta con ceros a la Izquierda solo si la cadena es digitos.
	 * @param cadena Object
	 * @param longitud int 
	 * @return String
	 */
	public static String acompletaCerosIzqSiNum(Object cadena, int longitud) {
		if (cadena != null) {
			String tmp = StringUtils.trimToEmpty(cadena.toString());
			if (NumberUtils.isDigits(tmp)) {
				return StringUtils.leftPad(tmp, longitud, "0");
			}
		}
		return StringUtils.EMPTY;
	}
	
	/**
	 * Convierte el objeto pasado como parametro a String
	 * @param obj Object
	 * @return int
	 */
	public static int convierteNumero(Object obj) {
		int numero = 0;
		if (obj != null && NumberUtils.isDigits(obj.toString())) {
			return Integer.parseInt(obj.toString());
		}
		return numero;
	}
	
	
	/**
	 * Convertimos a Long una cadena
	 * @param obj
	 * @return
	 */
	public static Long convierteLong(Object obj) {
		Long numero = 0L;
		if (obj != null && NumberUtils.isDigits(obj.toString())) {
			return Long.parseLong( obj.toString() );
		}
		return numero;
	}
}
