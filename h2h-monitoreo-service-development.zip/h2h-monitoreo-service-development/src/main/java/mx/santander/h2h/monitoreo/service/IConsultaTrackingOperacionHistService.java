package mx.santander.h2h.monitoreo.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.NivelOperacionHistRequest;
import mx.santander.h2h.monitoreo.model.response.NivelOperacionHistResponse;
import mx.santander.h2h.monitoreo.model.response.OperacionArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ProductoArchivoResponse;

public interface IConsultaTrackingOperacionHistService {
	
	NivelOperacionHistResponse iniciaNivelOperacionHist(NivelOperacionHistRequest nivelOperacionHistRequest);
	
	ProductoArchivoResponse obtenerConteoArchivo(Integer idReg);

	Page<OperacionArchivoResponse> obtenerDetalleArchivo(Integer idReg, Pageable page);
	
	List<OperacionArchivoResponse> obtenerListDetalleArchivo(Integer idReg);
	
	ReportResponse getReportXls(NivelOperacionHistRequest nivelOperacionHistRequest, String usuario);
}
