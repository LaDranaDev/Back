package mx.santander.h2h.monitoreo.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.santander.h2h.monitoreo.model.response.PutGetDto;
import mx.santander.h2h.monitoreo.model.response.PutGetWSDto;

@Service
public class ContractConnectionManagementPutGetFindDataService implements IContractConnectionManagementPutGetFindDataService {
	@Autowired
	@PersistenceContext
	private EntityManager entityManager;

	/**
	 * Obtención de la siguiente secuencia
	 * 
	 * @param string secuenceName nombre de la secuencia
	 * @return Numero consecuente a registrar
	 * @throws NumberFormatException excepción controlada en caso de error
	 */
	@Override
	public BigDecimal findNextValue(String secuenceName) throws NumberFormatException {

		StringBuilder query = new StringBuilder("SELECT ");
		query.append(secuenceName);
		query.append(".NEXTVAL SEQ from DUAL");

		List<BigDecimal> nextValueResult = entityManager.createNativeQuery(query.toString()).getResultList();

		return nextValueResult.get(0);
	}

	/**
	 * Consultamos los datos complementarios para SFTP
	 * 
	 * @param dtoput datos con filtro y donde se agregaran los valores
	 * @throws BusinessException cone mensaje de error
	 */
	@Override
	public void buscarDatosdeWS(PutGetDto putGetDtoResponse) {

		StringBuilder query = new StringBuilder("SELECT URI_CONS_WS, URI_GET_WS, URI_PUT_WS, CERT_WS FROM H2H_MX_PARA_WS WHERE ID_PTCL_PARA = :idPtclPara");

		Query queryWS = entityManager.createNativeQuery(query.toString());

		queryWS.setParameter("idPtclPara", putGetDtoResponse.getIdPtclPara());

		List<Object[]> datosWSResult = queryWS.getResultList();

		for (Object[] datosWS : datosWSResult) {

			PutGetWSDto putGetWSDto = new PutGetWSDto();

			putGetWSDto.setUriConsultaWS(Objects.toString(datosWS[0], ""));
			putGetWSDto.setUriGETWS(Objects.toString(datosWS[1], ""));
			putGetWSDto.setUriPUTWS(Objects.toString(datosWS[2], ""));
			putGetWSDto.setCertificadoWS(Objects.toString(datosWS[3], ""));

			putGetDtoResponse.setPutGetWSDto(putGetWSDto);

		}

	}

	/**
	 * Metodo para consultar los datos extras de Connect Direct
	 * 
	 * @param dtoput datos con filtro y donde se agregaran los valores
	 * @throws BusinessException cone mensaje de error
	 */
	@Override
	public void buscarDatosdeCD(PutGetDto putGetDtoResponse) {

		StringBuilder query = new StringBuilder("SELECT LCAL_NODE, REMT_NODE, LCAL_USER, REMT_USER, REMT_PWD, USE_OBSC_PWD, BIN_MODE, REC_FORM, REC_LEN, DISP_MODE, SYS_OPT, REC_DISP ");
		query.append("FROM H2H_MX_PARA_CD WHERE ID_PTCL_PARA = :idPtclPara");

		Query queryDatosCD = entityManager.createNativeQuery(query.toString());

		queryDatosCD.setParameter("idPtclPara", putGetDtoResponse.getIdPtclPara());

		List<Object[]> datosCDResult = queryDatosCD.getResultList();

		for (Object[] datosCD : datosCDResult) {

			putGetDtoResponse.setNodoLocal(Objects.toString(datosCD[0], ""));
			putGetDtoResponse.setNodoRemoto(Objects.toString(datosCD[1], ""));
			putGetDtoResponse.setUsuarioLocal(Objects.toString(datosCD[2], ""));
			putGetDtoResponse.setUsuarioRemoto(Objects.toString(datosCD[3], ""));
			putGetDtoResponse.setPasswordRemoto(Objects.toString(datosCD[4], ""));
			putGetDtoResponse.setOscurecerPwd(Objects.toString(datosCD[5], ""));
			putGetDtoResponse.setModoBinario(Objects.toString(datosCD[6], ""));
			putGetDtoResponse.setFormatoRegistro(Objects.toString(datosCD[7], ""));
			putGetDtoResponse.setLongitudRegistro(Objects.toString(datosCD[8], ""));
			putGetDtoResponse.setModoDisp(Objects.toString(datosCD[9], ""));
			putGetDtoResponse.setParametroSysOpts(Objects.toString(datosCD[10], ""));
			putGetDtoResponse.setDisposicionRegistro(Objects.toString(datosCD[11], ""));

		}

	}

	/**
	 * Consultamos los datos complementarios para SFTP
	 * 
	 * @param dtoput datos con filtro y donde se agregaran los valores
	 * @throws BusinessException cone mensaje de error
	 */
	@Override
	public void buscarDatosdeSFTP(PutGetDto putGetDtoResponse) {

		StringBuilder query = new StringBuilder("SELECT PROF_ID, KNOW_HOST_KEY, USER_ID_KEY FROM H2H_MX_PARA_SFTP WHERE ID_PTCL_PARA = :idPtclPara");

		Query querySFTP = entityManager.createNativeQuery(query.toString());

		querySFTP.setParameter("idPtclPara", putGetDtoResponse.getIdPtclPara());

		List<Object[]> datosSFTPResult = querySFTP.getResultList();

		for (Object[] datosSFTP : datosSFTPResult) {

			putGetDtoResponse.setProfileId(Objects.toString(datosSFTP[0], ""));
			putGetDtoResponse.setKnowIdHost(Objects.toString(datosSFTP[1], ""));
			putGetDtoResponse.setUserIdKey(Objects.toString(datosSFTP[2], ""));

		}

	}

}
