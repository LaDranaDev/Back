package mx.santander.h2h.monitoreo.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.NivelProductoRequest;
import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import mx.santander.h2h.monitoreo.model.response.NivelProductoResponse;
import mx.santander.h2h.monitoreo.model.response.ProductoArchivoResponse;

public interface IConsultaTrackingProductoService {
	
	NivelProductoResponse iniciaNivelProducto(NivelProductoRequest nivelProducto);

	List<ComboResponse> obtenerCatalogoProducto();
	
	List<ComboResponse> obtenerCatalogoEstatus();
	
	ProductoArchivoResponse obtenerConteoArchivo(String codCliente, Integer idArchivo);
	
	Page<ProductoArchivoResponse> obtenerDetalleArchivo(NivelProductoRequest nivelProduto, Pageable page);
	
	List<ProductoArchivoResponse> obtenerDetalleArchivo(NivelProductoRequest nivelProduto);
	
	ReportResponse getReportXls(NivelProductoRequest nivelProduto, String usuario);
}
