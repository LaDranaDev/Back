package mx.santander.h2h.monitoreo.model.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * CatalogStatusEntity
 * Entidad para el catalogo de estatus
 *
 * @author Felipe Monzon
 * @since 26/04/2022
 */
@Entity
@Getter
@Setter
@ToString
@Table(name = "H2H_CAT_ESTATUS")
public class CatalogStatusEntity implements Serializable {
	/**
	 * serial.
	 */
	private static final long serialVersionUID = 4436302040611036109L;
	/**
	 * Identificador del catalogo.
	 */
	@Id
	@Column(name = "ID_CAT_ESTATUS")
	private Integer idCat;
	/**
	 * descripcion de catalogo
	 */
	@Column(name = "DESC_ESTATUS")
	private String descripcionCatalogo;
	/**
	 * estatus activo
	 */
	@Column(name = "BAND_ACTIVO")
	private String estatusActivo;
	/**
	 * Tipo de status.
	 */
	@Column(name = "TIPO_ESTATUS")
	private String type;
}
