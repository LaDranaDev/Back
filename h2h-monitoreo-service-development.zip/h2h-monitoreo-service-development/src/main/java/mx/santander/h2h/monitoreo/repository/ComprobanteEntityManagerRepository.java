package mx.santander.h2h.monitoreo.repository;


import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.model.response.ComprobantesOperacionResponse;
import mx.santander.h2h.monitoreo.util.ComprobanteEntityManagerHelper;
import mx.santander.h2h.monitoreo.util.UtilComprobante;
import mx.santander.h2h.monitoreo.util.UtilComprobantePD;
import mx.santander.h2h.monitoreo.util.UtilComprobanteSPID;
import mx.santander.h2h.monitoreo.util.UtilMapeoData;
import mx.santander.h2h.monitoreo.util.UtilOrdenesPagoAtmComprobante;
import mx.santander.h2h.monitoreo.util.UtilVostroComprobantes;

/**
 * @author Daniel Ruiz Implementacion del repositrio para Comprobantes.
 */
@Slf4j
@Repository
public class ComprobanteEntityManagerRepository implements IComprobanteEntityManagerRepository {
	/** Constante Confirmming. */
	private static final String CONFIRMMING = "CONFIRMING";
	/** Constante FECH_APLI. */
	private static final String FECH_APLI = "FECH_APLI";
	/** Constante ESTATUS_MOV. */
	private static final String ESTATUS_MOV = "ESTATUS_MOV";
	/** Constante Orden de Pago. */
	private static final String ORDEN_PAGO = "ORDEN DE PAGO";
	/** Constante Impuestos Federales */
	private static final String IMPUESTOS_FED = "-21-";
	/** Constante Pagos Referenciados */
	private static final String PAGOS_REFERENCIADOS = "-22-";
	/** Constante Aportaciones Obrero patronales */
	private static final String APORTACIONES_OBRERO_PAT = "-23-";
	/** Constante L. */
	private static final String L = "L";
	/** Constante Pago TDC Santander */
	private static final String PAGO_TDC_SANTANDER = "PAGO TDC SANTANDER";
	/** Constante LIQUIDADA. */
	private static final String LIQUIDADA = "LIQUIDADA";
	/** Constante NUM_CTA_CARGO. */
	private static final String NUM_CTA_CARGO = "NUM_CTA_CARGO";
	/** Constante Banco. */
	private static final String BANCO = "BANCO SANTANDER (MÉXICO) S.A.";
	/** Constante CONTRATO. */
	private static final String CONTRATO = "CONTRATO";
	/***
	 * cnstante de tipo string para NOMB_RAZON_SOCI_PROV
	 */
	private static final String NOMB_RAZON_SOCI_PROV = "NOMB_RAZON_SOCI_PROV";
	/** Constante TITULAR. */
	private static final String TITULAR = "TITULAR";
	/** Constante BANC_ABON. */
	private static final String BANC_ABON = "BANC_ABON";
	/** Constante RFC_PROV. */
	private static final String RFC_PROV = "RFC_PROV";
	/**
	 * constante para la variable de tipo String REFE_ABON
	 */
	private static final String REFE_ABON = "REFE_ABON";
	/***
	 * constante de tipo String para la variable de CLAVE_RASTREO
	 */
	private static final String CLAVE_RASTREO = "CLAVE_RASTREO";
	/**
	 * Constantes CONCEPTO_PAGO TCS (sonar)
	 */
	private static final String CONCEPTO_PAGO = "CONCEPTO_PAGO";
	/***
	 * Constante para NOM_CLTE de tipo String
	 */
	private static final String NOM_CLTE = "NOM_CLTE";
	@Autowired
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<ComprobantesOperacionResponse> obtenerComprobantes(List<Integer> listIds, List<String> vistaProd) {
		 String sql = vistaProd.stream()
            .map(StringUtils::trim)
            .filter(vista -> !"null".equals(vista))
            .distinct()
            .map(vista -> {
            	return UtilComprobante.obtenerQueryTabla(listIds, vista);
            })
            .filter(StringUtils::isNotBlank)
            .collect(Collectors.joining(" UNION ALL ", "", " order by IMPORTE ASC"));
		 	if (sql.equals(" order by IMPORTE ASC")) {
				return new ArrayList<>();
			}
		 	
	        Query query = entityManager.createNativeQuery(sql, Tuple.class);
	        return castMapToListComprobante(query.getResultList());
	}
	
	


	/**
	 * Elimina los elementos repetidos de la lista.
	 * 
	 * @param vistaProd Elementos originales
	 * @return Lista sin elementos repetidos.
	 */
	private List<String> eliminaRepetidos(List<String> vistaProd) {
		final List<String> sinRepetidos = new ArrayList<String>();
		final Set<String> sinRepetidosSet = new HashSet<String>();
		for (String elem : vistaProd) {
			sinRepetidosSet.add(elem);
		}
		sinRepetidos.addAll(sinRepetidosSet);
		return sinRepetidos;
	}

	/***
	 * 
	 * @param sql      StringBuilder
	 * @param vista    vista
	 * @param unionAll union
	 * @param listIds  listaIds
	 */
	private void agregawhere(StringBuilder sql, String vista, String unionAll, List<Integer> listIds) {
		final String where = UtilComprobante.obtenerQueryTabla(listIds, vista);
		if (where != null && !where.isEmpty()) {
			sql.append(where).append(unionAll);
		}
	}

	/**
	 * Castea datos a lista de DTO de comprobantes.
	 * 
	 * @param datos List<HashMap<String, Object>>
	 * @return Lista de comprobantes operaciones
	 */
	protected List<ComprobantesOperacionResponse> castMapToListComprobante(List<?> datos) {
		final List<ComprobantesOperacionResponse> listBean = new ArrayList<>();
		String tmp = null;
		boolean hayConfirming = false;
		for (Object dato : datos) {
			if (!(dato instanceof Tuple)) {
				continue;
			}
			Tuple map = (Tuple) dato;
			ComprobantesOperacionResponse bean = new ComprobantesOperacionResponse();
			// Verifica de que producto es la operacion
			bean.setTipoOper(ObjectUtils.toString(map.get("DESC_PROD")));
			bean.setEsConfirming(esDelProducto(CONFIRMMING, bean.getTipoOper()));
			hayConfirming = hayConfirming || bean.isEsConfirming();
			bean.setEsOrdenPago(esDelProducto(ORDEN_PAGO, bean.getTipoOper()));
			bean.setEsOrdenPago(esDelProducto(ORDEN_PAGO + " ATM", bean.getTipoOper().toUpperCase()));
			bean.setEsImpuFed(esDelProducto(IMPUESTOS_FED, ObjectUtils.toString(map.get(ESTATUS_MOV))));
			bean.setEsPagRef(esDelProducto(PAGOS_REFERENCIADOS, ObjectUtils.toString(map.get(ESTATUS_MOV))));
			bean.setEsApoObr(esDelProducto(APORTACIONES_OBRERO_PAT, ObjectUtils.toString(map.get(ESTATUS_MOV))));
			bean.setEsPagoTDC(esDelProducto(PAGO_TDC_SANTANDER, bean.getTipoOper()));
			// Obtiene el estado de la operacion (Solo para orden de pago)
			tmp = ObjectUtils.toString(map.get("ID_ESTA"));
			if (tmp.equals(L)) {
				tmp = LIQUIDADA;
			}
			bean.setEstatusOp(tmp);
			if (seProcesaRegistro(bean)) {
				// Campos generales
				bean.setCuentaCargo(ObjectUtils.toString(map.get(NUM_CTA_CARGO)));
				bean.setTitular(ObjectUtils.toString(map.get("TITULAR")));
				bean.setCuentaAbono(ObjectUtils.toString(map.get("NUN_CTA_ABONO")));
				// Enmascaramos la cuenta Abono
				//bean.setCuentaAbono(UtilMapeoData.getMascara(bean.getCuentaAbono(), "abono"));
				
				bean.setBeneficiario(ObjectUtils.toString(map.get("BENEFICIARIO")));
				// Formateo de importe
				final DecimalFormat decimalFormat = new DecimalFormat("###,###,###,###,##0.00",
						new DecimalFormatSymbols());
				final String impFormat = "$" + decimalFormat.format(map.get("IMPORTE"));
				bean.setImporte(impFormat);
				bean.setConceptoPago(ObjectUtils.toString(map.get("CONCEPTO_PAGO")).trim());
				bean.setClaveRastreo(ObjectUtils.toString(map.get("CLAVE_RASTREO")));
				bean.setRefInterbancaria(ObjectUtils.toString(map.get("REFERENCIA")));
				bean.setFolioOp( convertLong(map.get("ID_REG")) );

				tmp = StringUtils.isBlank(ObjectUtils.toString(map.get("BANCO_RECEPTOR"))) ? BANCO
						: ObjectUtils.toString(map.get("BANCO_RECEPTOR"));
				bean.setBanco(tmp);
				bean.setEstatus(ObjectUtils.toString(map.get("DESC_ESTATUS")));
				bean.setFechaAplic(ObjectUtils.toString(map.get(FECH_APLI)));
				// Campos para orden de pago
				bean.setCveBenef(ObjectUtils.toString(map.get("CLAVE_BENEF")));
				bean.setPersAut(ObjectUtils.toString(map.get("PERS_AUT")));
				bean.setNumOrden(ObjectUtils.toString(map.get("NUM_ORDEN")));
				bean.setTipoPago(ObjectUtils.toString(map.get("TIPO_PAGO")));
				bean.setNumSucursal(ObjectUtils.toString(map.get("NUM_SUCURSAL")));
				bean.setFechaOp(ObjectUtils.toString(map.get(FECH_APLI)));
				bean.setFechaLimPago(ObjectUtils.toString(map.get("FECHA_LIMITE_PAGO")));
				bean.setPatente(ObjectUtils.toString(map.get("CLAVE_BENEF")));
				bean.setPedimento(ObjectUtils.toString(map.get("PERS_AUT")));
				bean.setAduana(ObjectUtils.toString(map.get("FORM_APLI")));
				bean.setLineaCaptura(ObjectUtils.toString(map.get("NUN_CTA_ABONO")));
				bean.setCveProdOper(ObjectUtils.toString(map.get("CLAV_PROV")));
				bean.setFechaPago(ObjectUtils.toString(map.get("FECH_APLI")));
				bean.setHoraPago(ObjectUtils.toString(map.get("NOMB_RAZON_SOCI_PROV")));
				bean.setNumOpeBan(ObjectUtils.toString(map.get("RFC_PROV")));
				bean.setNumTrans(ObjectUtils.toString(map.get("BANC_ABON")));
				bean.setMedioPres(ObjectUtils.toString(map.get("REFE_ABON")));
				bean.setMedioCob(ObjectUtils.toString(map.get("TIPO_DOCU")));

				validaesEspeiRefIn(bean, map);
				bean.setDivisa(ObjectUtils.toString(map.get("DIVISA")));
				llenabeanPorProducto(map, bean);

				listBean.add(bean);
			}
		}
		return listBean;
	}
	
	
	/**
	 * Convertimos a Long un objeto
	 * @param obj
	 * @return
	 */
	private Long convertLong(Object obj) {
		Long resFnc = 0L;
		if(obj != null) {
			resFnc = Long.parseLong( obj.toString() );
		}
		return resFnc;
	}

	/***
	 * 
	 * @param map      mapa
	 * @param bean     dto
	 * @param tmp      strign
	 * @param aSession sessionbean
	 */
	private void llenabeanPorProducto(Tuple map, ComprobantesOperacionResponse bean) {
		if (bean.isEsConfirming()) {
			bean.setContrato(ObjectUtils.toString(map.get(CONTRATO)));
			String tmp = ObjectUtils.toString(map.get("PERSONALIDAD"));
			asignaValorrazonSoc(tmp, map, bean);
			bean.setRfc(ObjectUtils.toString(map.get("RFC")));
			bean.setCveProveedor(ObjectUtils.toString(map.get("CLAV_PROV")));
			bean.setTipoDoc(ObjectUtils.toString(map.get("TIPO_DOCU")));
			bean.setNoDocu(ObjectUtils.toString(map.get("NUM_DOCU")));
			bean.setDivisa(ObjectUtils.toString(map.get("DIVISA")));
			bean.setFechaVenci(ObjectUtils.toString(map.get("FECH_VENCIMIENTO")));
			bean.setFechaOp(ObjectUtils.toString(map.get(FECH_APLI)));
			bean.setFormaPago(ObjectUtils.toString(map.get("CVE_FORM_PAGO")));
			bean.setEstatusMov(ObjectUtils.toString(map.get(ESTATUS_MOV)));
			bean.setFormaAplic(ObjectUtils.toString(map.get("FORM_APLI")));
			bean.setContrato(ObjectUtils.toString(map.get("NUM_CNTR")));
			bean.setNomProveedor(ObjectUtils.toString(map.get(NOMB_RAZON_SOCI_PROV)));
			bean.setRfcProveedor(ObjectUtils.toString(map.get(RFC_PROV)));
			bean.setBanco(ObjectUtils.toString(map.get(BANC_ABON)));
			bean.setClaveRastreo(ObjectUtils.toString(map.get(REFE_ABON)));
			bean.setRefInterbancaria(ObjectUtils.toString(map.get("REFERENCIA")));
		}
		ComprobanteEntityManagerHelper.aplicaFormatoEspecial(bean);
		if (bean.isEsImpuFed()) {
			Query query = entityManager
					.createQuery("SELECT hp.VALOR FROM H2H_PARAM hp WHERE NMBR_PARAM = :nombre", String.class);
			query.setParameter("nombre", "LONG_REP_IMPF_CNTR");
			String longitud = (String) query.getSingleResult();
			ComprobanteEntityManagerHelper.llenaBeanImpuFed(bean, map, longitud);
		}
		if (bean.isEsApoObr()) {
			bean.setContrato(ObjectUtils.toString(map.get(CONTRATO)));
			bean.setTitular(ObjectUtils.toString(map.get(TITULAR)));
			bean.setLineaCaptura(ObjectUtils.toString(map.get(CONCEPTO_PAGO)));
			bean.setCuentaCargo(ObjectUtils.toString(map.get(NUM_CTA_CARGO)));
			bean.setFolioSua(ObjectUtils.toString(map.get(CLAVE_RASTREO)));
			bean.setRegPatronal(ObjectUtils.toString(map.get(NOMB_RAZON_SOCI_PROV)));
			bean.setPeriodoPago(ObjectUtils.toString(map.get("TIPO_DOCU")));
			bean.setFechaAplic(ObjectUtils.toString(map.get(FECH_APLI)));
			bean.setNumOperacion(ObjectUtils.toString(map.get("CVE_FORM_PAGO")));
			bean.setMedioPresentacion(ObjectUtils.toString(map.get(BANC_ABON)));
			bean.setNomProveedor(ObjectUtils.toString(map.get(RFC_PROV)));
			bean.setBeneficiario(ObjectUtils.toString(map.get(NOM_CLTE)));

		}
		if (bean.isEsPagRef()) {
			ComprobanteEntityManagerHelper.llenaPagoRefBean(bean, map);
		}
		if (esDelProducto("-31-", ObjectUtils.toString(map.get(ESTATUS_MOV)))) {
			ComprobanteEntityManagerHelper.llenatransInterBean(bean, map);
		}
		if (esDelProducto("-33-", ObjectUtils.toString(map.get(ESTATUS_MOV)))) {
			ComprobanteEntityManagerHelper.llenatransInterMBCBean(bean, map);
		}
		if (esDelProducto("-09-", ObjectUtils.toString(map.get(ESTATUS_MOV)))) {
			UtilComprobanteSPID.llenatransSpid(bean, map);
		}
		if (esDelProducto("40", ObjectUtils.toString(map.get(ESTATUS_MOV)))) { // PGODIRECT Inicio
			UtilComprobantePD.llenaBeanPagoDirecto(bean, map);
		} // PGODIRECT Fin
		log.debug("Valida si es vostro e ingresa a llenar Bean");
		UtilVostroComprobantes.llenaProductosCBF2(bean, map);
		UtilOrdenesPagoAtmComprobante.llenaBeanOpAtm(bean, map);
	}

	/**
	 * Verifica si aparece el producto en el tipo.
	 * 
	 * @param producto String
	 * @param tipo     String
	 * @return boolean
	 */
	protected boolean esDelProducto(String producto, String tipo) {
		boolean esBase = false;
		if (StringUtils.isNotBlank(producto) && StringUtils.isNotBlank(tipo)) {
			esBase = tipo.toUpperCase().contains(producto.toUpperCase());
		}
		return esBase;
	}

	/**
	 * solo si es ESPEI se queda la referencia Interbancaria con Referencia en vez
	 * de la de REFE_ABON
	 * 
	 * @param bean
	 * @param map
	 */
	protected void validaesEspeiRefIn(ComprobantesOperacionResponse bean, Tuple map) {
		if (bean.getTipoOper().contains("SPEI")) {
			bean.setRefInterbancaria(ObjectUtils.toString(map.get("REFERENCIA")));
			bean.setRfcProveedor(ObjectUtils.toString(map.get("RFC_PROV")));
		}
	}

	/***
	 * 
	 * @param tmp  cadena
	 * @param map  mapa
	 * @param bean bean
	 */
	protected void asignaValorrazonSoc(String tmp, Tuple map, ComprobantesOperacionResponse bean) {
		if ("F".equals(tmp)) {
			bean.setRazonSocial(ObjectUtils.toString(map.get("NOM_CLTE")));
		} else {
			bean.setRazonSocial(ObjectUtils.toString(map.get("RAZON_SCIA")));
		}

	}

	/**
	 * Determina si el registro debe ser descartado de la lista de comprobantes o
	 * no.
	 * 
	 * @param bean ComprobantesOperacionDTO
	 * @return boolean <br>
	 *         true: debe ser procesado <br>
	 *         false: no debe ser procesado.
	 */
	protected boolean seProcesaRegistro(ComprobantesOperacionResponse bean) {
		if (!bean.isEsOrdenPago()) {
			return true;
		} else {
			return LIQUIDADA.equals(bean.getEstatusOp());
		}
	}

}
