package mx.santander.h2h.monitoreo.repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.model.response.ContractResponse;
import mx.santander.h2h.monitoreo.model.response.CustomerResponse;
import mx.santander.h2h.monitoreo.model.response.ParametersGetPutResponse;
import mx.santander.h2h.monitoreo.model.response.ProductEdoCtaResponse;

/**
 * Repository de operación de protocolos de administración de conexión de contrato
 * @author sbautish
 *
 */
@Slf4j
@Repository
public class ContractConnectionManagementProtocolsEntityManagerRepository implements IContractConnectionManagementProtocolsEntityManagerRepository {

	@Autowired
	private IContractConnectionManagementEntityManagerRepository iContractConnectionManagementEntityManagerRepository;
	@Autowired
	@PersistenceContext
	private EntityManager entityManager;

	/**
	 * Obtiene datos de contrato por número de contrato
	 */
	@Override
	public List<ContractResponse> findContractConnectionByContractNumber(String numeroContrato) {

		StringBuilder queryFindContract = new StringBuilder("SELECT clte.BUC, clte.RAZON_SCIA RAZON_SOCIAL, clte.PERSONALIDAD, clte.NOMBRE, clte.APPATERNO, clte.APMATERNO, cta.NUM_CTA CUENTA_EJE, cntr.ID_CNTR, cntr.ID_ESTADO, cntr.NUM_CNTR, cntr.HABILITA_BENE, cntr.CVE_CANL_HSM, cntr.BAND_BENEF, cntr.BAND_CLABE_ECTA, cntr.BAND_CAMB_PROD, est.Desc_Estatus, clte.nemonico, cntr.BAND_ACT_CONT, cntr.BIC, cntr.MSG_PTNR, cntr.TIPO_TRAN, cntr.BAND_CIF_CTRL, DIAS_PROG_ARCH, NVL(cntr.ALIAS, '') AS ALIAS, cntr.CTR_BACK_CONF FROM H2H_CNTR cntr, H2H_CNTR_CTA cta, H2H_CLTE clte, H2H_CAT_ESTATUS est WHERE cntr.NUM_CNTR = :numeroContrato AND cta.TIPO_CTA = 'E' AND cta.ID_CNTR = cntr.ID_CNTR AND cntr.ID_CLTE = clte.ID_CLTE AND cntr.id_estado = est.ID_CAT_ESTATUS");

		Query contractsResult = entityManager.createNativeQuery(queryFindContract.toString());
		contractsResult.setParameter("numeroContrato", numeroContrato);

		List<Object[]> listContracts = contractsResult.getResultList();

		return mapFromListContractsToContractResponse(listContracts);
	}

	/**
	 * Obtiene id de protocolo de contrato
	 */
	@Override
	public Integer findContractIdProtocol(Integer idContrato) {

		StringBuilder queryFindContractIdProtocol = new StringBuilder("SELECT DISTINCT NVL(pp.ID_PTCL, 0) ID_PTCL FROM H2H_PATT_PTCL param, H2H_PARA_PTCL pp WHERE param.ID_CNTR = :idContrato AND pp.ID_PARA_PTCL = param.ID_PARA_PTCL");

		Query contractIdProtocolResult = entityManager.createNativeQuery(queryFindContractIdProtocol.toString());
		contractIdProtocolResult.setParameter("idContrato", idContrato);

		List<BigDecimal> listIdProtocol = contractIdProtocolResult.getResultList();

		Integer idProtocol = 0;

		if (!listIdProtocol.isEmpty()) {
			idProtocol = Integer.valueOf(listIdProtocol.get(0).intValue());
		}

		return idProtocol;
	}

	/**
	 * Obtiene parámetros GET / PUT del contrato
	 */
	@Override
	public List<ParametersGetPutResponse> findContractParametersGetPut(Integer idContrato, Integer idProtocol, String tipoActividad) {

		StringBuilder queryParametersGetPut = new StringBuilder("SELECT para.ID_PARA_PTCL, ptcl.ID_PTCL, ptcl.NOMBRE, para.NMBR_PARA, patt.VALOR, para.PARA_ES_EDIT, para.PARA_ES_OBLI, para.PARA_LONG, para.PARA_TIPO_DATO, NVL(patt.ID_SEQU_PATT, 0) ID_SEQU_PATT, patt.PATT_ACTI TIPO_ACTI, NVL(patt.ID_DATO_TRAN, 0) ID_DATO_TRAN, NVL(patt.BAND_ACTI, 'I') EDO_VALOR FROM H2H_PTCL ptcl, H2H_PARA_PTCL para, H2H_PATT_PTCL patt WHERE ptcl.ID_PTCL = :idProtocol AND ptcl.ID_PTCL = para.ID_PTCL AND para.ID_PARA_PTCL = patt.ID_PARA_PTCL(+) AND patt.ID_CNTR(+) = :idContrato AND patt.PATT_ACTI(+) = :tipoActividad AND para.BAND_ACTIVO = 1 ORDER BY patt.ID_DATO_TRAN, patt.PATT_ACTI, NLSSORT(UPPER(para.nmbr_para), 'NLS_SORT=SPANISH')");

		Query parametersGetPutResult = entityManager.createNativeQuery(queryParametersGetPut.toString());

		parametersGetPutResult.setParameter("idContrato", idContrato);
		parametersGetPutResult.setParameter("idProtocol", idProtocol);
		parametersGetPutResult.setParameter("tipoActividad", tipoActividad);

		List<Object[]> listParametersGetPutResult = parametersGetPutResult.getResultList();

		return mapFromListParametersGetPutResultToListParametersGetPutResponse(listParametersGetPutResult);
	}

	/**
	 * Obtiene los nombres de los parámetros por protocolo
	 */
	@Override
	public List<String> findParametersNameInProtocol(Integer idProtocol) {

		StringBuilder queryParametersNameInProtocol = new StringBuilder("SELECT NMBR_PARA FROM H2H_PARA_PTCL WHERE ID_PTCL = :idProtocol AND BAND_ACTIVO = 1 ORDER BY NLSSORT(UPPER(NMBR_PARA), 'NLS_SORT=SPANISH')");

		Query parametersNameInProtocolResult = entityManager.createNativeQuery(queryParametersNameInProtocol.toString());

		parametersNameInProtocolResult.setParameter("idProtocol", idProtocol);

		return parametersNameInProtocolResult.getResultList();
	}

	/**
	 * Actualiza estatus de registro de parámetro
	 */
	@Override
	@Transactional
	public void updateRegistrationStatus(Integer idRegistro, String tipoProcesamiento, String estado) {

		StringBuilder query = new StringBuilder("UPDATE H2H_PATT_PTCL SET BAND_ACTI = :estado WHERE ID_DATO_TRAN = :idRegistro AND PATT_ACTI = :tipoProcesamiento");

		Query updateRegistrationResponse = entityManager.createNativeQuery(query.toString());

		updateRegistrationResponse.setParameter("estado", estado);
		updateRegistrationResponse.setParameter("idRegistro", idRegistro);
		updateRegistrationResponse.setParameter("tipoProcesamiento", tipoProcesamiento);

		Integer executeUpdate = 0;

		executeUpdate = updateRegistrationResponse.executeUpdate();

		log.debug("updateRegistrationStatus: " + executeUpdate.toString());

	}

	private List<ParametersGetPutResponse> mapFromListParametersGetPutResultToListParametersGetPutResponse(
			List<Object[]> listParametersGetPutResult) {

		List<ParametersGetPutResponse> listParametersGetPutResponse = new ArrayList<>();

		for (Object[] parametersGetPutResult : listParametersGetPutResult) {

			ParametersGetPutResponse parametersGetPutResponse = new ParametersGetPutResponse();

			parametersGetPutResponse.setId(Objects.toString(parametersGetPutResult[0], ""));
			parametersGetPutResponse.setIdProtocolo(null);

			parametersGetPutResponse.setId(Objects.toString(parametersGetPutResult[0], ""));
			parametersGetPutResponse.setIdProtocolo(Objects.toString(parametersGetPutResult[1], ""));
			parametersGetPutResponse.setNombreProtocolo(Objects.toString(parametersGetPutResult[2], ""));
			parametersGetPutResponse.setNombreParametro(Objects.toString(parametersGetPutResult[3], ""));
			parametersGetPutResponse.setValorParametro(Objects.toString(parametersGetPutResult[4], ""));
			parametersGetPutResponse.setEditParametro(Objects.toString(parametersGetPutResult[5], ""));
			parametersGetPutResponse.setObliParametro(Objects.toString(parametersGetPutResult[6], ""));
			parametersGetPutResponse.setLongParametro(Objects.toString(parametersGetPutResult[7], ""));
			parametersGetPutResponse.setTipoDatoParametro(Objects.toString(parametersGetPutResult[8], ""));
			parametersGetPutResponse.setIdValorParametro(Objects.toString(parametersGetPutResult[9], ""));
			parametersGetPutResponse.setTipoProcesamiento(Objects.toString(parametersGetPutResult[10], ""));
			parametersGetPutResponse.setNumeroRegistro(Integer.valueOf(parametersGetPutResult[11].toString()));
			parametersGetPutResponse.setEstadoValor(Objects.toString(parametersGetPutResult[12], ""));

			listParametersGetPutResponse.add(parametersGetPutResponse);

		}

		return listParametersGetPutResponse;
	}

	private List<ContractResponse> mapFromListContractsToContractResponse(List<Object[]> listContracts) {

		List<ContractResponse> listContractResponse = new ArrayList<>();

		for (Object[] contract : listContracts) {

			ContractResponse contractResponse = new ContractResponse();

			CustomerResponse customerResponse = crearClienteResponse(contract);

			contractResponse.setIdContrato(Integer.valueOf(contract[7].toString()));
			contractResponse.setNumeroContrato(Objects.toString(contract[9], ""));
			contractResponse.setCliente(customerResponse);

			if (StringUtils.isBlank(contractResponse.getCliente().getNemonico())) {
				contractResponse.getCliente().setNemonico(contractResponse.getCliente().getRazonSocial().substring(0, 4));
			}

			List<ProductEdoCtaResponse> contractProductsForProducts = iContractConnectionManagementEntityManagerRepository.findContractProductsForProducts(contractResponse.getNumeroContrato());

			contractResponse.setProductos(contractProductsForProducts);

			listContractResponse.add(contractResponse);

		}

		return listContractResponse;
	}

	private CustomerResponse crearClienteResponse(Object[] contract) {

		CustomerResponse customerResponse = new CustomerResponse();

		customerResponse.setRazonSocial(Objects.toString(contract[1], ""));
		customerResponse.setNemonico(Objects.toString(contract[16], ""));

		return customerResponse;
	}

}
