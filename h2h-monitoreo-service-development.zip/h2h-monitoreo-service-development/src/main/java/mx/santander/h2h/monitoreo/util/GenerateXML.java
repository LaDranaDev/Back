/**
 * 
 */
package mx.santander.h2h.monitoreo.util;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.Map;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.model.response.Parametro;
import mx.santander.h2h.monitoreo.model.response.Parametros;

/**
 * Utileria para general XML de la Consulta de Operaciones
 * 
 * @author Omar Rosas
 * @since 07/07/2023
 *
 */
@Slf4j
public final class GenerateXML {

	/**
	 * Constructor default
	 */
	private GenerateXML() {
	}

	/**
	 * Metodo para crear el XML de envio a Sterling de la consulta de operaciones
	 * 
	 * @param params Parametros para generar el xml
	 * @return Array de bytes del XML
	 * @throws jakarta.xml.bind.JAXBException 
	 */
	public static byte[] creaXML(final Map<String, String> params)  {
		Parametros parametros = new Parametros();
		try {
			JAXBContext context = JAXBContext.newInstance(Parametros.class);
			Marshaller marshaller = context.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			
			Parametro parametro = null;
			for (Map.Entry<String, String> entry : params.entrySet()) {
				parametro = new Parametro();
				parametro.setNombre(entry.getKey());
				parametro.setValor(entry.getValue());
				parametros.getParametros().add(parametro);
			}
			OutputStream outputStream = new ByteArrayOutputStream();
			marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
			marshaller.marshal(parametros, outputStream);
			return ((ByteArrayOutputStream) outputStream).toByteArray();
		} catch (JAXBException ex) {
			log.error("Error al crear el XML de Consulta de Operaciones.", ex);
		}
		return null;
	}
}
