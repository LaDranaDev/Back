package mx.santander.h2h.monitoreo.service;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.response.PutGetServiceResponse;

@Slf4j
@Service
public class ContractConnectionManagementPutGetDeleteDataService implements IContractConnectionManagementPutGetDeleteDataService {
	@Autowired
	@PersistenceContext
	private EntityManager entityManager;

	/***
	 * eliminamos datos si es alta
	 * @param tipoOperacion 
	 * @param respuestadto BeanResponsePutGet
	 * @param operacion tipo de operacion
	 */
	public void eliminaDatosSiEsAlta(PutGetServiceResponse putGetServiceResponse, String tipoOperacion) {

		if("A".equals(tipoOperacion)){

			putGetServiceResponse.getRegistrosPG().get(1).setDirectorio("");
			putGetServiceResponse.getRegistrosPG().get(1).setDirectorioGet("");
			putGetServiceResponse.getRegistrosPG().get(1).setPatronGet("");

		}

	}

	/**
	 * Eliminamos los valores que se deben escribit manualemente para los nuevos registros
	 * @param respuestadto dto con datos a eliminar
	 */
	public void eliminaValoresnuevoReg(PutGetServiceResponse putGetServiceResponse) {

		putGetServiceResponse.getRegistrosPG().get(0).setDirectorio("");
		putGetServiceResponse.getRegistrosPG().get(0).setDirectorioGet("");
		putGetServiceResponse.getRegistrosPG().get(0).setPatron("");
		putGetServiceResponse.getRegistrosPG().get(0).setPatronGet("");

	}

	@Transactional
	public void eliminaInformacion(PutGetServiceResponse putGetServiceResponse) {

		String idContrato = putGetServiceResponse.getRegistrosPG().get(0).getIdContrato();

		Integer idContratoInt = Integer.parseInt(idContrato);

		log.info("Se va amodificar el tipo de Protocolo para el contrato: " + putGetServiceResponse.getIdContrato());

		log.debug("Inicia borrado de H2H_MX_PTCL_PATH...");

		StringBuilder queryPtclPath = new StringBuilder("DELETE H2H_MX_PTCL_PATH WHERE ID_PTCL_PARA IN (SELECT ID_PTCL_PARA FROM H2H_MX_PTCL_PARA WHERE ID_CNTR = :idContrato )");

		Query querySFTPCDResult = entityManager.createNativeQuery(queryPtclPath.toString());

		querySFTPCDResult.setParameter("idContrato", idContratoInt);

		try {

			Integer sftpCDResult = querySFTPCDResult.executeUpdate();

			log.info(sftpCDResult.equals(0) ? "No hay registros para eliminar." : "Se eliminaron " + sftpCDResult + " registros.");

		} catch (BusinessException e) {

			throw new BusinessException("ERDEL1", "Error al tratar de eliminar los registros en H2H_MX_PTCL_PATH " + e.getMessage().toString());

		}

		log.debug("Inicia borrado de H2H_MX_PARA_CD...");

		StringBuilder queryParaCd = new StringBuilder("DELETE H2H_MX_PARA_CD WHERE ID_PTCL_PARA IN (SELECT ID_PTCL_PARA FROM H2H_MX_PTCL_PARA WHERE ID_CNTR = :idContrato )");

		Query queryParaCDResult = entityManager.createNativeQuery(queryParaCd.toString());

		queryParaCDResult.setParameter("idContrato", idContratoInt);

		try {

			Integer paraCDResult = queryParaCDResult.executeUpdate();

			log.info(paraCDResult.equals(0) ? "No hay registros para eliminar." : "Se eliminaron " + paraCDResult + " registros.");

		} catch (BusinessException e) {

			throw new BusinessException("ERDEL1", "Error al tratar de eliminar los registros en H2H_MX_PARA_CD" + e.getMessage().toString());

		}

		log.debug("Inicia borrado de H2H_MX_PARA_SFTP...");

		StringBuilder querySftp = new StringBuilder("DELETE H2H_MX_PARA_SFTP WHERE ID_PTCL_PARA IN (SELECT ID_PTCL_PARA FROM H2H_MX_PTCL_PARA WHERE ID_CNTR = :idContrato )");

		Query querySftpResult = entityManager.createNativeQuery(querySftp.toString());

		querySftpResult.setParameter("idContrato", idContratoInt);

		try {

			Integer sftpResult = querySftpResult.executeUpdate();

			log.info(sftpResult.equals(0) ? "No hay registros para eliminar." : "Se eliminaron " + sftpResult + " registros.");

		} catch (BusinessException e) {

			throw new BusinessException("ERDEL1", "Error al tratar de eliminar los registros en H2H_MX_PARA_SFTP" + e.getMessage().toString());

		}

		log.debug("Inicia borrado de H2H_MX_PARA_WS...");

		StringBuilder queryWebService = new StringBuilder("DELETE H2H_MX_PARA_WS WHERE ID_PTCL_PARA IN (SELECT ID_PTCL_PARA FROM H2H_MX_PTCL_PARA WHERE ID_CNTR = :idContrato )");

		Query queryWebServiceResult = entityManager.createNativeQuery(queryWebService.toString());

		queryWebServiceResult.setParameter("idContrato", idContratoInt);

		try {

			Integer webServiceResult = queryWebServiceResult.executeUpdate();

			log.info(webServiceResult.equals(0) ? "No hay registros para eliminar." : "Se eliminaron " + webServiceResult + " registros.");

		} catch (BusinessException e) {

			throw new BusinessException("ERDEL1", "Error al tratar de eliminar los registros en H2H_MX_PARA_WS" + e.getMessage().toString());

		}

		log.debug("Inicia borrado de H2H_MX_PTCL_PARA...");

		StringBuilder queryPtclPara = new StringBuilder("DELETE H2H_MX_PTCL_PARA WHERE ID_CNTR = :idContrato ");

		Query queryPtclParaResult = entityManager.createNativeQuery(queryPtclPara.toString());

		queryPtclParaResult.setParameter("idContrato", idContratoInt);

		try {

			Integer ptclParaResult = queryPtclParaResult.executeUpdate();

			log.info(ptclParaResult.equals(0) ? "No hay registros para eliminar." : "Se eliminaron " + ptclParaResult + " registros.");

		} catch (BusinessException e) {

			throw new BusinessException("ERDEL2", "Error al tratar de eliminar los registros en H2H_MX_PTCL_PARA");

		}

		log.info("Termina borrado de información anterior del protocolo.");

	}

}
