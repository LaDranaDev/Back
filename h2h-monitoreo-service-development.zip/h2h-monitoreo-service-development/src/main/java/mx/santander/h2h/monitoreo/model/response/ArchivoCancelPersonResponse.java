package mx.santander.h2h.monitoreo.model.response;

import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;

/**
 * clase para el response de la operacion de buscar archivo
 * implementa la interfas de serializcion para el traspaso entre capas
 * Adicional se implementan las etiquetas lombok de
 * Geter, Seter,
 * para un desarrollo más rapido y con menos codigo.
 * @author NTTDATA-NRL
 * @version 1.0
 */
@Getter
@Setter
public class ArchivoCancelPersonResponse implements Serializable {

    /**
     * Serial version UID de la clase
     */
    private static final long serialVersionUID = 5676292854179642480L;

    /** buc String */
    private String buc;
    /** nomArchivo String */
    private String nomArchivo;
    /** estatus String */
    private String estatus;
    /** idEstatus String */
    private Integer idEstatus;
    /** codCliente String */
    private String codCliente;
}
