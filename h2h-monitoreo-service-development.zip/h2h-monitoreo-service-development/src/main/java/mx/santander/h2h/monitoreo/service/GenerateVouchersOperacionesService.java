package mx.santander.h2h.monitoreo.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.constants.ReportConstants;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.report.request.GenerateReportHistorialOperacionesDto;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.HistorialOperacionesRequest;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.OperationsHistoryResponse;
import mx.santander.h2h.monitoreo.model.response.SelectComboDTO;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorCatalogsResponse.Pair;
import mx.santander.h2h.monitoreo.repository.IGenerateVouchersEntityManagerRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailRepository;
import mx.santander.h2h.monitoreo.util.IGenerateVouchersUtils;
import net.sf.jasperreports.engine.JRException;

/**
 * Servicio que contiene
 * todos los metodos necesarios
 * para poder realizar
 * la exportacion del reporte en 
 * formato xls del historial de
 * operaciones
 */
@Service
@Slf4j
public class GenerateVouchersOperacionesService implements IGenerateVouchersOperacionesService {

	private static final String ERROR = "ERROR: No se pudo obtener el archivo HistorialOperSubreport.jasper";
	/**
	 * detailRepository
	 */
	@Autowired
    private IOperationsDetailRepository detailRepository;
	
	/**
	 * iGenerateVouchersUtils
	 */
	@Autowired
	private IGenerateVouchersUtils iGenerateVouchersUtils;
	
	/**
	 * Servicio genérico 
	 * de reportería
	 */
	@Autowired
	private IJasperReportService iJasperReportService;
	
	/**
	 * iOperationsMonitorService
	 */
	@Autowired
	private IOperationsMonitorService iOperationsMonitorService;
	
	/**
	 * iGenerateVouchersEntityManagerRepository
	 */
	@Autowired
	private IGenerateVouchersEntityManagerRepository iGenerateVouchersEntityManagerRepository;
	
	/**
	 * Metodo que realiza la exportacion 
	 * del hitorial de 
	 * operaciones
	 * @param historialOperacionesRequest HistorialOperacionesRequest
	 * @return ReportResponse
	 */
	@Override
	public ReportResponse exportarHistorialOperacionesXlsx(HistorialOperacionesRequest historialOperacionesRequest) {
		List<OperationsHistoryResponse> historialOperacion = detailRepository.obtenerHistorialOperacion(historialOperacionesRequest.getIdOperacion());
		return this.exportarHistorialOperacionesXlsx(historialOperacionesRequest, historialOperacion);
	}
	
	/**
	 * Metodo que realiza la exportacion del
	 * historial de
	 * operaciones
	 * @param historialOperacionesRequest HistorialOperacionesRequest
	 * @param histOperList List<OperationsHistoryResponse> 
	 * @param xlsxExtention String
	 * @return ReportResponse
	 */
	public ReportResponse exportarHistorialOperacionesXlsx(HistorialOperacionesRequest historialOperacionesRequest, List<OperationsHistoryResponse> histOperList) {
		final List<Object> dataLt = new ArrayList<Object>();
		var dto = new GenerateReportHistorialOperacionesDto();
		
		Map<String, Object> mapParams = new HashMap<>();
		mapParams.put("USER", historialOperacionesRequest.getUser());
		
		try {

			/** Se genera el jasper secundario */
			mapParams.put("HIST_OPER_SUBREPORT", iGenerateVouchersUtils.generateJR(
					new ClassPathResource(new StringBuilder(ReportConstants.REPORTS_FOLDER).append("HistorialOperSubreport.jasper").toString()).getInputStream()));

		} catch (IOException e) {
			log.error(ERROR);
			log.error(e.toString());
		} catch (NullPointerException | BusinessException ex) {
			log.error(ERROR);
			log.error(ex.toString());
		} catch (JRException e) {
			log.error(ERROR);
			log.error(e.toString());
		} 
		
		dto.setHistOperList(histOperList);
		
		dataLt.add(dto);
		
		return this.iJasperReportService.getXls("HistorialOperReport.jasper", mapParams, dataLt);
	}
	
	/**
	 * Metodo que realiza la exportacion de Operaciones XLS
	 * @param operationsMonitorQueryRequest OperationsMonitorQueryRequest
	 * @param xlsxExtention String
	 * @return ReportResponse
	 */
	@Override
	public ReportResponse exportarOperacionesXlsx(OperationsMonitorQueryRequest operationsMonitorQueryRequest,
			String xlsxExtention) {
		if(!"".equals(operationsMonitorQueryRequest.getIdEstatus())) {
			List<Pair> catalogs = iOperationsMonitorService.catalogs().getOperationsMonitorCatalogsResponse().getEstatus();
			List<Pair> resultCat = catalogs.stream().filter(key -> key.getKey().equals(operationsMonitorQueryRequest.getIdEstatus())).collect(Collectors.toList());
			operationsMonitorQueryRequest.setDescripcionEstatus(resultCat.get(0).getValue());
		}else {
			operationsMonitorQueryRequest.setDescripcionEstatus("TODOS");
		}
		
		if(!"".equals(operationsMonitorQueryRequest.getTipo())) {
			List<SelectComboDTO> catTipoPago = iGenerateVouchersEntityManagerRepository.getListPaymentType().getListaTipoPago();
			List<SelectComboDTO> restlTipoPago = catTipoPago.stream().filter(key -> key.getKey().equals(operationsMonitorQueryRequest.getTipo())).collect(Collectors.toList());
			operationsMonitorQueryRequest.setTipOperacion(restlTipoPago.get(0).getValue());
		}
		
		
		return iGenerateVouchersUtils.exportarOperacionesXlsx(operationsMonitorQueryRequest, xlsxExtention);

	}
}
