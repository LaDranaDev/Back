package mx.santander.h2h.monitoreo.service;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.model.request.PistaAuditoriaRequest;
import mx.santander.pid.logadapter.core.types.service.LogAdapterAuditService;
import mx.santander.pid.logadapter.core.types.service.LogAdapterBusinessService;
import mx.santander.pid.logadapter.exception.LogAdapterException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;

/**
 * PistaAuditoriaService
 * Implementación del objeto de negocio para la gestion de logs y pistas
 * auditables
 * 
 * @author Santander
 * @since 08/06/2022
 */
@Slf4j
@Service
public class PistaAuditoriaService implements IPistaAuditoriaService {
	/**
	 * Instancia del objeto de pistas de auditoria LogAdapterAuditService
	 */
	@Autowired
	private LogAdapterAuditService auditService;

	/**
	 * Instancia del objeto de pistas de auditoria LogAdapterBusinessService
	 */
	@Autowired
	private LogAdapterBusinessService businessService;

	/**
	 * registrar Realiza el registro de la pista de auditoria;
	 * 
	 * @param pistasRequest contiene la informacion que se registrara en la bitacora
	 *                      y ademas tambien se registrara como audit
	 */
	@Override
	public void registrarPista(PistaAuditoriaRequest pistasRequest) {
		log.info("Ingresa al metodo para registrar la pista de auditoria");
		try {
			this.businessService.bitacoriza(pistasRequest.getResultado(), pistasRequest.getCodigoOperacion(),
					pistasRequest.getNombre(), pistasRequest.getMensaje(), pistasRequest.getInfoAdicional());
			this.auditService.audit(pistasRequest.getResultado(), pistasRequest.getCodigoOperacion(),
					pistasRequest.getNombre(), pistasRequest.getInfoAdicional());
		} catch (LogAdapterException e) {
			log.info(MessageFormat.format("Ocurrio un error al realizar el registro en pistas: {0}", e.getMessage()),
					e);
		}
	}

}
