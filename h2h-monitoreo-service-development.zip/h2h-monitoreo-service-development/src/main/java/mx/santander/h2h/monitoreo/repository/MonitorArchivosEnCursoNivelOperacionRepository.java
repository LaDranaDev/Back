package mx.santander.h2h.monitoreo.repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import mx.santander.h2h.monitoreo.model.response.ComboDosResponse;
import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import mx.santander.h2h.monitoreo.model.response.MonitorDeArchivosEnCursoDetallesOperacionResponse;
import mx.santander.h2h.monitoreo.model.response.ResultTrackingResponse;
import mx.santander.h2h.monitoreo.util.UtilData;

/**
 * EntityManager para el Tracking de Archivos
 *
 * @author Daniel Ruiz
 * @since 19/04/2023
 */
@Repository
public class MonitorArchivosEnCursoNivelOperacionRepository implements IMonitorArchivosEnCursoNivelOperacionRepository {
	@Autowired
    @PersistenceContext
    private EntityManager entityManager;

   
    
    /**
     * Obtiene el detalle del archivo de acuerdo al estatus
     * @param fecha LocalDate
     * @param codCliente String
     * @param codEstatus String
     * @param nomArch String
     * @return Lista con los beans de resultado
     */
    @Override
    public List<MonitorDeArchivosEnCursoDetallesOperacionResponse> ejecutaBusquedaNivelOperacion( String idArchivo, Integer idProducto, Integer idEstatus
    ) {
        Map<String, Object> params = new HashMap<>();
        String queryDetalle = ejecutaBusquedaNivelOperacion(idArchivo, idProducto, idEstatus, params);
        Query query = entityManager.createNativeQuery(queryDetalle, Tuple.class);
        params.forEach(query::setParameter);
        List<?> result = query.getResultList();
        return mapResultToResponseList(result, 2);
    }
    
    /**
     * Obtiene el detalle del archivo de acuerdo al estatus
     * @param fecha LocalDate
     * @param codCliente String
     * @param codEstatus String
     * @param nomArch String
     * @return Lista con los beans de resultado
     */
    @Override
    public List<MonitorDeArchivosEnCursoDetallesOperacionResponse> ejecutaBusquedaNivelOperacionHistorica( String idReg
    ) {
        Map<String, Object> params = new HashMap<>();
        String queryDetalle = ejecutaBusquedaNivelOperacionHistorica(idReg , params);
        Query query = entityManager.createNativeQuery(queryDetalle, Tuple.class);
        params.forEach(query::setParameter);
        List<?> result = query.getResultList();
        return mapResultToResponseList(result, 1);
    }

    
    /**
     * Obtiene el query Detalle.
     * @param fecha LocalDate
     * @param codCliente String
     * @param nomArch String
     * @param codEstatus Integer
     * @param params Map<String, Object>
     * @return String
     */
    private String ejecutaBusquedaNivelOperacion(
             String idArchivo,
             Integer idProducto,
             Integer idEstatus,
             Map<String, Object> params
    ) {
        StringBuilder sql = new StringBuilder();
        sql.append(" ")
        .append("SELECT A.id_reg, " +
				" Refe_BE as cve_rastreo_spei, ")
		.append(" TO_CHAR(fech_apli,'dd/mm/yyyy') || ' '||  NVL(TO_CHAR(A.HORA_APLI, 'hh24:mi'),' ') AS FECHA_APLI, ")
		.append(" B.DESC_ESTATUS as desc_estatus, C.DESC_PROD, ")
		.append(" mont as IMPORTE, A.cnta_abon as cta_ben,  A.cnta_carg as cta_ord,  ")
		.append(" D.umbr, ")
		.append(" TO_CHAR( d.fech_envi_be,'dd/mm/yyyy hh24:mi:ss') AS fech_envi_be, ")
		.append(" TO_CHAR( d.fech_resp_be,'dd/mm/yyyy hh24:mi:ss') AS fech_resp_be ")
		.append("FROM h2h_reg_tran A, ")
			.append("h2h_cat_estatus B, ")
			.append("h2h_cat_prod C, ")
		.append(" h2h_arch_back_tran D  ")
		.append("WHERE B.id_cat_estatus = A.id_estatus " )
		.append(" and A.Cve_prod_oper = C.cve_prod_oper " )
		.append(" and A.id_arch_be = D.id_arch_back(+)  " )
		.append(" AND A.id_arch = :idArchivo ");
		if (idProducto != null && idProducto > 0) {
			sql.append(" AND C.id_prod = :idProducto ");
			params.put("idProducto", idProducto);
			
		}
		if (idEstatus != null && idEstatus > 0) {
			sql.append(" AND B.id_cat_estatus = :idEstatus ");
			params.put("idEstatus", idEstatus);
		}
		params.put("idArchivo", idArchivo);
		sql.append(" ORDER BY  A.id_reg  ASC ");

        return sql.toString();
    }
    
    /**
     * Obtiene el query Detalle.
     * @param fecha LocalDate
     * @param codCliente String
     * @param nomArch String
     * @param codEstatus Integer
     * @param params Map<String, Object>
     * @return String
     */
    private String ejecutaBusquedaNivelOperacionHistorica(
    		 String idReg,
             Map<String, Object> params
    ) {
        StringBuilder sql = new StringBuilder();
        sql.append(" ")
        .append("SELECT B.DESC_ESTATUS, ")
		.append("       TO_CHAR(A.FECHA_ESTATUS,'dd/mm/yyyy hh24:mi:ss') AS FECHA_ESTATUS ")
		.append("  FROM H2H_BITA_REG_TRAN A,h2h_cat_estatus B ")
		.append(" WHERE B.id_cat_estatus = A.id_estatus ")
		.append("   AND ID_REG = :idReg ");
        params.put("idReg", idReg);
        sql.append(" ORDER BY A.FECHA_ESTATUS ASC ");
        return sql.toString();
    }

    /**
	 * Metodo que tiene el queri de obtener productos
	 * @return query
	 */
	public static StringBuilder queryObtenerProductos() {
		StringBuilder querySql = new StringBuilder();
				
		return querySql.append("SELECT ID_PROD, CVE_PROD_OPER, DESC_PROD  FROM H2H_CAT_PROD ")
				.append("WHERE BAND_ACTIVO = 'A' AND BAND_VISI_CONS = 'A' ORDER BY DESC_PROD ");
				
	}
    
	 private static final String SELECT_CAT_ESTATUS = new StringBuilder().append("SELECT ")
	            .append("    ID_CAT_ESTATUS as KEY,").append("    DESC_ESTATUS as VALUE").append(" FROM ")
	            .append("    H2H_CAT_ESTATUS where tipo_estatus = 'A' and band_activo = 'A' ")
	            .append("    AND ID_CAT_ESTATUS NOT IN (18,16,69) ")
	            .append(" ORDER BY ").append("    DESC_ESTATUS ").toString();
    

    /**
     * Map a Lista de detalle
     * @param datos List<?>
     * @return List<BeanProductoArchivo>
     */
    private List<MonitorDeArchivosEnCursoDetallesOperacionResponse> mapResultToResponseList(List<?> datos, Integer numb) {
        List<MonitorDeArchivosEnCursoDetallesOperacionResponse> listBean = new ArrayList<>();
        String estatusIni = "-----------------";
        for (Object object : datos) {
            if (!(object instanceof Tuple)) {
                continue;
            }
            Tuple row = (Tuple) object;
            MonitorDeArchivosEnCursoDetallesOperacionResponse bean = new MonitorDeArchivosEnCursoDetallesOperacionResponse();
            
            if(numb == 1) {
            	bean.setFechaEnvBe(estatusIni);
                bean.setDescEstatus(String.valueOf(row.get("DESC_ESTATUS")));
                bean.setFechaApli(String.valueOf(row.get("FECHA_ESTATUS"))); 
                estatusIni = bean.getDescEstatus();
            }
            if(numb == 2) {
            	bean.setIdReg(String.valueOf(row.get("ID_REG")));
                bean.setCveRasteroSpei(String.valueOf(row.get("CVE_RASTREO_SPEI")));
                bean.setFechaApli(String.valueOf(row.get("FECHA_APLI")));
                bean.setDescEstatus(String.valueOf(row.get("DESC_ESTATUS")));
                bean.setDescProd(String.valueOf(row.get("DESC_PROD")));
                bean.setImporte(row.get("IMPORTE", BigDecimal.class));
                bean.setCtaBen(String.valueOf(row.get("CTA_BEN")));
                bean.setCtaOrd(String.valueOf(row.get("CTA_ORD")));
                bean.setUmbr(String.valueOf(row.get("UMBR")));
                bean.setFechaEnvBe(String.valueOf(row.get("FECH_ENVI_BE")));
                bean.setFechaRespBe(String.valueOf(row.get("FECH_RESP_BE")));            
            }
            listBean.add(bean);
        }
        return listBean;
    }


	@Override
	public ResultTrackingResponse obtenerCatalogoProductos() {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder = queryObtenerProductos();
		
		Query query = entityManager.createNativeQuery(queryBuilder.toString());
		
		@SuppressWarnings("unchecked")
		List<Object[]> resultQueryProductos = query.getResultList();
		
		List<ComboDosResponse> listCombo = new ArrayList<ComboDosResponse>();
		
		if (resultQueryProductos != null) {
			for (Object[] map : resultQueryProductos) {
				String id;
				try {
					id = (String) map[1];
				} catch (NumberFormatException e) {
					id = "";
				}
				ComboDosResponse bean = new ComboDosResponse();
				bean.setId(id);
				bean.setValor((String)map[2]);
				listCombo.add(bean);
			}
		}
		
		resultTrackingResponse.setListComboDos(listCombo);
		
		return resultTrackingResponse;
	}
	
	@Override
	public ResultTrackingResponse obtenerCatalogoEstatus() {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		
		Query query = entityManager.createNativeQuery(SELECT_CAT_ESTATUS);
		
		@SuppressWarnings("unchecked")
		List<Object[]> resultQueryProductos = query.getResultList();
		
		List<ComboResponse> listCombo = new ArrayList<ComboResponse>();
		
		if (resultQueryProductos != null) {
			for (Object[] map : resultQueryProductos) {
				ComboResponse bean = new ComboResponse();
				bean.setId( UtilData.toInt(map[0]) );
				bean.setValor( UtilData.toString(map[1]) );
				listCombo.add(bean);
			}
		}
		
		resultTrackingResponse.setListCombo(listCombo);
		
		return resultTrackingResponse;
	}

}
