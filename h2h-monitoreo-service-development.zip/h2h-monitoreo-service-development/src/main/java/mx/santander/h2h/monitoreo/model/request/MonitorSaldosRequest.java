package mx.santander.h2h.monitoreo.model.request;

import java.io.Serializable;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * MonitorSaldosRequest.
 * Objeto con filtros para realizar la consulta de saldos reintentos.
 *
 * @author Jesus Soto Aguilar
 * @since 20/04/2023
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MonitorSaldosRequest implements Serializable {

    /**
     * Serial.
     */
    private static final long serialVersionUID = 1L;

    /** Codigo del cliente. */
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
    private String codigoCliente;

    /** Nombre del archivo. */
    @Pattern(regexp = "(^((([a-z])?/.*)|(([a-zA-Z]:)?(\\\\([a-zA-Z0-9_.-]+\\\\?)?))?)+(([a-zA-Z0-9]+)(.([.a-zA-Z0-9]))?)+$)?", message = "Archivo No valido")
    private String nombreArchivo;

    /** Fecha inicio. */
    @Pattern(regexp = "(((\\d{2})|(\\d{4}))([-/])\\d{2}([-/])((\\d{2})|(\\d{4})))( (\\d{2}:\\d{2}:\\d{2})?)?", message = "Fecha No Valida")
    @Size(min = 0, max = 20, message = "Fecha erronea")
    private String fechaInicio;

    /** Fecha fin. */
    @Pattern(regexp = "(((\\d{2})|(\\d{4}))([-/])\\d{2}([-/])((\\d{2})|(\\d{4})))( (\\d{2}:\\d{2}:\\d{2})?)?", message = "Fecha No Valida")
    @Size(min = 0, max = 20, message = "Fecha erronea")
    private String fechaFin;

    /** Clave del producto. */
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
    private String claveProducto;
}
