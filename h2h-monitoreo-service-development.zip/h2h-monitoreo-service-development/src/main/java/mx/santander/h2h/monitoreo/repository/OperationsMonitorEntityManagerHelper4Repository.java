package mx.santander.h2h.monitoreo.repository;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.constants.MonitorOperacionesConstants;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.util.MonitorOperationsUtils;
import mx.santander.h2h.monitoreo.util.UtilMapeoData;
import mx.santander.h2h.monitoreo.util.UtilMonitorFnc;

@Slf4j
@Repository
public class OperationsMonitorEntityManagerHelper4Repository implements IOperationsMonitorEntityManagerHelper4Repository  {

	/** Declaracion de EntityManager para entityManager. */
	@Autowired
    @PersistenceContext
    private EntityManager entityManager;
	
	@Autowired
    private IOperationsMonitorEntityManagerRepository repository;
	
	/**
	 * Realiza la consulta de los id de los comprobantes de la consulta
     * de monitor de operaciones
	 *
	 * @param request para request
	 * @return el string
	 */
	@Override
	public String obtenerIdsComprobantes(OperationsMonitorQueryRequest request) {
		final StringBuilder query = new StringBuilder();
		
		String prodExcluidos = repository.consultaParametro("H2H_PROD_EXC_COMP");
		String ids = MonitorOperationsUtils.transformaids(prodExcluidos);
		log.info("Valor de prod a excluir: " + Encode.forJava(ids));
		
		if(isDateToday(request.getFechaInicial())) {
			query.append(MonitorOperationsUtils.getSelectConsultaOperaciones(true))
			     .append(MonitorOperationsUtils.getWhereConsultaOperaciones(request, ids));
		}else{
			query.append(MonitorOperationsUtils.getSelectConsultaOperaciones(false))
			     .append(MonitorOperationsUtils.getWhereConsultaOperaciones(request, ids))
			     .append(" UNION ALL ")
			     .append(MonitorOperationsUtils.getSelectConsultaOperaciones(true))
			     .append(MonitorOperationsUtils.getWhereConsultaOperaciones(request, ids));
		}
		
		String cadQuery = query.toString();
		Map<String, Object> params = new HashMap<>();
		// Recorremos los parametros para convertir a SQL
		for(Map.Entry<String, Object> item : params.entrySet() ) {
			// Remplazamos los datos
			cadQuery = cadQuery.replace(":"+item.getKey(), "'"+item.getValue().toString()+"'");
		}
		return cadQuery;
	}
	
	/**
	 * Metodo que valida la fecha de inicio es la igual al dia de hoy
	 * @param date String que con formato 'dd/MM/yyyy'
	 * @return boolean
	 */
	private static boolean isDateToday(String date){
		final SimpleDateFormat formatoDeFecha = new SimpleDateFormat("dd/MM/yyyy", new Locale("es", "MX"));
		return formatoDeFecha.format(new java.util.Date()).equals(date);
	}
	
	/**
     * Realiza la consulta de las operaciones para exportar.
     *
     * @param consultaOperaciones - Parámetros de consulta
     * @return Lista de operaciones realizadas
     */
    @Override
    public List<OperationsMonitorQueryResponse> consultaOperExport(OperationsMonitorQueryRequest consultaOperaciones) {
    	Map<String, Object> params = new HashMap<>();
        final StringBuilder queryViewsSQL = new StringBuilder();
        log.info("OperationsMonitorEntityManagerRepository - consultaOperacionesExportar: INICIO");
        // Obtenemos la consulta de datos
        String querys = MonitorOperacionesRepository.getViews(consultaOperaciones, queryViewsSQL, params);
//        MonitorOperacionesRepository.preparaConsultaOperaciones(consultaOperaciones, queryViewsSQL, params);
        log.info("OperationsMonitorEntityManagerRepository - consultaOperacionesExportar: Termino consultaOperacionesExportar - getViews: " + queryViewsSQL.toString());
        Query queryViews = entityManager.createNativeQuery(querys.toString(), Tuple.class);
        log.info("Total de datos queryViews: " + queryViews.getResultList().size());
        params.forEach(queryViews::setParameter);
        // Iniciamos la consulta de Elementos de Tablas de Views
        List<?> viewsResult = queryViews.getResultList();
        List<String> views = new ArrayList<>();
        for (Object result : viewsResult) {
            if (result instanceof Tuple) {
                Tuple row = (Tuple) result;
                views.add(UtilMonitorFnc.getData(row.get("VIST_PROD")));
            }
        }
        log.info("Total de views: " + views.size());
        if( views.size() == 0 ) {
        	log.info("No se encontraron datos VIST_PROD al consultar tabla, se cancela ejecución de operaciones");
//        	return "No existe informacion";
        }
        
        Map<String, Object> paramsExporta = new HashMap<>();
        final StringBuilder queryExportSQL = new StringBuilder();
        log.info("OperationsMonitorEntityManagerRepository - getConsultaExportar: Llego");
        //OperationsMonitorEntityManagerHelper2Repository.getConsultaExportar(views, consultaOperaciones, queryExportSQL, paramsExporta);
//        queryExportSQL.append(" SELECT * FROM ( ");
        queryExportSQL.append(OperationsMonitorEntityManagerHelper2NewRepository.getConsultaExportar(views, consultaOperaciones, queryExportSQL, paramsExporta));
//        queryExportSQL.append(" ) ");
        log.info("OperationsMonitorEntityManagerRepository - getConsultaExportar: Paso");
        Query query = entityManager.createNativeQuery(queryExportSQL.toString(), Tuple.class);
        paramsExporta.forEach(query::setParameter);
        List<?> resultList = query.getResultList();
        List<OperationsMonitorQueryResponse> operaciones = new ArrayList<>(resultList.size());
        for (Object result : resultList) {
            if (result instanceof Tuple) {
                Tuple row = (Tuple) result;
                operaciones.add(mapResponse(row, true));
            }
        }
        
        String cadQuery = queryExportSQL.toString();
        
        //Recorremos los parametros para convertir a SQL
        for(Map.Entry<String, Object> item : params.entrySet()) {
        	//Reemplazar los datos
        	cadQuery = cadQuery.replace(":" + item.getKey(), "'" + item.getValue().toString() + "'");
        }
        log.info("OperationsMonitorEntityManagerRepository - getConsultaExportar: TERMINA");
        return operaciones;
    }
    
    /**
     * Función para mapear una row del resultado de la query al DTO del response.
     *
     * @param row Tupla con los datos de la row
     * @param export Bandera para definir si el response se usa para exportación o no
     * @return Response con los datos de la operación
     */
    private OperationsMonitorQueryResponse mapResponse(Tuple row, boolean export) {
        OperationsMonitorQueryResponse respuesta = new OperationsMonitorQueryResponse();

        DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols();
        formatSymbols.setDecimalSeparator('.');
        formatSymbols.setGroupingSeparator(',');
        DecimalFormat decimalFormat = new DecimalFormat("###,###,###,###,##0.00", formatSymbols);

        respuesta.setIdOperacion(row.get("ID_REG") == null || row.get("ID_REG").toString().isEmpty() ? MonitorOperacionesConstants.CERO : row.get("ID_REG").toString());
        respuesta.setCodCli(UtilMonitorFnc.getData(row.get("BUC")));
        respuesta.setCtaCargo(UtilMonitorFnc.getData(row.get("NUM_CTA_CARGO")));
        respuesta.setCtaAbono(UtilMonitorFnc.getData(row.get("NUN_CTA_ABONO")));
        respuesta.setProducto(UtilMonitorFnc.getData(row.get("DESC_PROD")));
        respuesta.setNomArch(UtilMonitorFnc.getData(row.get("NOMBRE_ARCH")));
        respuesta.setCanal(UtilMonitorFnc.getData(row.get("NOMB_CANL")));

        respuesta.setReferencia(row.get("REFERENCIA") == null  ? StringUtils.EMPTY : row.get("REFERENCIA").toString().trim());
        if (MonitorOperacionesConstants.CERO.equals(respuesta.getReferencia()) || "null".equals(respuesta.getReferencia())){
            respuesta.setReferencia(StringUtils.EMPTY);
        }

        respuesta.setEstatus(UtilMonitorFnc.getData(row.get("DESC_ESTATUS")));
        respuesta.setImporte(row.get(MonitorOperacionesConstants.IMPORTE) == null || row.get(MonitorOperacionesConstants.IMPORTE).toString().isEmpty()
                ? "$0.00" : "$" + decimalFormat.format(Double.valueOf(row.get(MonitorOperacionesConstants.IMPORTE).toString())));

        respuesta.setImporteSinFormato(row.get(MonitorOperacionesConstants.IMPORTE) == null || row.get(MonitorOperacionesConstants.IMPORTE).toString().isEmpty()
                ? new BigDecimal("0.00") : new BigDecimal(row.get(MonitorOperacionesConstants.IMPORTE).toString()));

        respuesta.setFechaAplic(OperationsMonitorEntityManagerHelper3Repository.getFecha(row.get("FECHA_APLICACION")));
        respuesta.setFechaCaptura(OperationsMonitorEntityManagerHelper3Repository.getFecha(row.get("FECHA_REGISTRO")));
        respuesta.setBancoOrdenante("BANCO SANTANDER MEXICANO, S.A.");
        respuesta.setIdEstatus(row.get(MonitorOperacionesConstants.ID_ESTATUS) == null 
        		? MonitorOperacionesConstants.CERO : row.get(MonitorOperacionesConstants.ID_ESTATUS).toString());
        respuesta.setIdProducto(row.get(MonitorOperacionesConstants.CVE_PROD_OPER) == null 
        		? MonitorOperacionesConstants.CERO : row.get(MonitorOperacionesConstants.CVE_PROD_OPER).toString());
        respuesta.setVistProd(UtilMonitorFnc.getData(row.get("VIST_PROD")));
        respuesta.setDivisa(UtilMonitorFnc.getData(row.get("DIVISA")));
        if (MonitorOperacionesConstants.MN.equals(respuesta.getDivisa().trim())) {
            respuesta.setDivisa(MonitorOperacionesConstants.MXP);
        }
        if (MonitorOperacionesConstants.DL.equals(respuesta.getDivisa().trim())) {
            respuesta.setDivisa(MonitorOperacionesConstants.USD);
        }

        if (export) {
            respuesta.setComentario1(UtilMonitorFnc.getData(row.get("COMENTARIO_1")).trim());
            respuesta.setComentario2(UtilMonitorFnc.getData(row.get("COMENTARIO_2")).trim());
            respuesta.setComentario3(UtilMonitorFnc.getData(row.get("COMENTARIO_3")).trim());
            // Obtenemos el tipo de Divisa
            respuesta.setDivisa( UtilMonitorFnc.valDivisa(UtilMonitorFnc.getData(row.get("DIVISA"))) );
            respuesta.setDivisaOrd( UtilMonitorFnc.valDivisa(UtilMonitorFnc.getData(row.get("DIVISA_ORD"))) );

            respuesta.setFechaAplic(OperationsMonitorEntityManagerHelper3Repository.getFecha(row.get("FECHA_APLICACION")));
            respuesta.setFechaCaptura(OperationsMonitorEntityManagerHelper3Repository.getFecha(row.get("FECHA_REGISTRO")));
            respuesta.setFechaLimitPago(OperationsMonitorEntityManagerHelper3Repository.getFecha(row.get("FECHA_LIMITE_PAGO")));
            respuesta.setFechaOper(OperationsMonitorEntityManagerHelper3Repository.getFecha(row.get("FECHA_OPERACION")) );
            respuesta.setFechaPresIni(OperationsMonitorEntityManagerHelper3Repository.getFecha(row.get("FECHA_PRESENTACION_INICIAL")) );
            respuesta.setImporteCargo(row.get("IMPORTE_CARGO") == null || row.get("IMPORTE_CARGO").toString().isEmpty() ?
            respuesta.getImporte() : "$" + decimalFormat.format(Double.valueOf(row.get("IMPORTE_CARGO").toString().trim())));
            respuesta.setNombreOrd(UtilMonitorFnc.getData(row.get("TITULAR")));
            respuesta.setIntermOrd(UtilMonitorFnc.getData(row.get("INTERMEDIARIO_ORD")));
            respuesta.setIntermRec(UtilMonitorFnc.getData(row.get("INTERMEDIARIO_REC")));
            respuesta.setModalidad(UtilMonitorFnc.getData(row.get("MODALIDAD")));
            respuesta.setNombreBenef(UtilMonitorFnc.getData(row.get("BENEFICIARIO")).trim());
            respuesta.setNumSucursal(UtilMonitorFnc.getData(row.get("NUM_SUCURSAL")).trim());
            respuesta.setNumOrden(UtilMonitorFnc.getData(row.get("NUM_ORDEN")).trim());
            respuesta.setTipoPago(UtilMonitorFnc.getData(row.get("TIPO_PAGO")).trim());
            respuesta.setBancoReceptor(UtilMonitorFnc.getData(row.get("BANCO_RECEPTOR")).trim());
            respuesta.setMensaje(UtilMonitorFnc.getData(row.get("MSG_H2H")).trim());
            respuesta.setIdEstatus(row.get(MonitorOperacionesConstants.ID_ESTATUS) == null ? MonitorOperacionesConstants.CERO : row.get(MonitorOperacionesConstants.ID_ESTATUS).toString().trim());
            respuesta.setIdProducto(row.get(MonitorOperacionesConstants.CVE_PROD_OPER) == null ? MonitorOperacionesConstants.CERO : row.get(MonitorOperacionesConstants.CVE_PROD_OPER).toString().trim());
            respuesta.setMensajeOrden(row.get("MSG_ORDEN_PAGO") == null ? MonitorOperacionesConstants.CERO : row.get("MSG_ORDEN_PAGO").toString().trim());
            respuesta.setNombreEmpleado(UtilMonitorFnc.getData(row.get("NOMBRE_EMPLEADO")).trim());
            respuesta.setBucEmpleado(UtilMonitorFnc.getData(row.get("BUC_EMPLEADO")).trim());
            respuesta.setNumEmpleado(UtilMonitorFnc.getData(row.get("NUMERO_EMPLEADO")).trim());
            respuesta.setRfc(UtilMonitorFnc.getData(row.get("RFC")).trim());
            respuesta.setNumTarjeta(UtilMonitorFnc.getData(row.get("NUMERO_TARJETA")).trim());
            respuesta.setNumeroCuenta(UtilMonitorFnc.getData(row.get("NUMERO_CUENTA")).trim());
            respuesta.setSucTutora(UtilMonitorFnc.getData(row.get("SUCURSAL_TUTORA")).trim());

            if (!respuesta.getModalidad().isEmpty()) {
                respuesta.setModalidad("T".equals(respuesta.getModalidad()) ? "Al momento de hacer la orden" : "Al momento de hacer la liquidaci\u00F3n");
            }
            if (!respuesta.getTipoPago().isEmpty()) {
                respuesta.setTipoPago("E".equals(respuesta.getTipoPago()) ? "E-EFECTIVO" : ("C".equals(respuesta.getTipoPago()) ? "C-CHEQUE" : "OTRO" ));
            }
            
        } else {
            respuesta.setTabla(UtilMonitorFnc.getData(row.get("TABLA")));
        }
        // Enmascaramos la tarjeta y Cuentas Abonos
        if( respuesta != null ) {
        	// Tarjetas
        	respuesta.setNumTarjeta(
        		UtilMapeoData.getMascara(respuesta.getNumTarjeta(), "tarjeta")
        	);
        	respuesta.setNumTarjetaAct(
        		UtilMapeoData.getMascara(respuesta.getNumTarjetaAct(), "tarjeta")
        	);
        	// Cuentas
        	respuesta.setCtaAbono(
        		UtilMapeoData.getMascara(respuesta.getCtaAbono(), "abono")
        	);
        }
        return respuesta;
    }
}
