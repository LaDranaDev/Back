package mx.santander.h2h.monitoreo.exception.commons;

/**
 * Clase que es usada cuando se utiliza o sucede una exception personalizada
 *
 * @author Paul Quintero
 * @since 10/05/2022
 */
public class ForbiddenException extends RuntimeException {
	/**
	 * Serial UID
	 */
	private static final long serialVersionUID = 4673527086504613867L;
	/** Código de error. */
	private final String code;

	/** Constructor de la clase. */
	public ForbiddenException() {
		super();
		this.code = null;
	}

	/**
	 * Constructor de la clase.
	 *
	 * @param message mensaje de error
	 */
	public ForbiddenException(String message) {
		super(message);
		this.code = null;
	}

	/**
	 * Constructor de la clase.
	 *
	 * @param code    código de error
	 * @param message mensaje de error
	 */
	public ForbiddenException(String code, String message) {
		super(message);
		this.code = code;
	}

	/**
	 * Obtiene el código de error
	 *
	 * @return código de error
	 */
	public String getCode() {
		return code;
	}
}
