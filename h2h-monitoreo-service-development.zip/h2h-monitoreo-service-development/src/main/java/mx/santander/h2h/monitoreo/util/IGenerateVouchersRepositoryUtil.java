package mx.santander.h2h.monitoreo.util;

import java.util.List;

import jakarta.persistence.Query;

import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;

public interface IGenerateVouchersRepositoryUtil {

	StringBuilder getQueryTable(OperationsMonitorQueryRequest operationsMonitorQueryRequest, List<String> listParams,
			StringBuilder query);

	void setStringParamsInToQuery(List<String> listParams, Query operationsCountQuery);

	StringBuilder getPaginatedQuery(StringBuilder query, StringBuilder queryTable);

	StringBuilder getQueryTableExport(OperationsMonitorQueryRequest operationsMonitorQueryRequest,
			List<String> listParams, StringBuilder query);

}
