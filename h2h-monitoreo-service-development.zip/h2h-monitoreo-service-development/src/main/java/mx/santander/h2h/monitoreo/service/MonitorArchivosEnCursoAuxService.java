package mx.santander.h2h.monitoreo.service;


import mx.santander.h2h.monitoreo.model.request.MonitorArchivosEnCursoRequest;

import mx.santander.h2h.monitoreo.model.response.MonitorDeArchivosEnCursoDetallesResponse;

import mx.santander.h2h.monitoreo.repository.IMonitorArchivosEnCursoRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class MonitorArchivosEnCursoAuxService implements IMonitorArchivosEnCursoAuxService {


	@Autowired
	private IMonitorArchivosEnCursoRepository entityManager;



	@Override
	public Page<MonitorDeArchivosEnCursoDetallesResponse> consultaArchivosEnCurso(MonitorArchivosEnCursoRequest request, Pageable pageable) {
		request.setPagina(String.valueOf(pageable.getPageNumber() + 1));
        request.setTamanioPagina(String.valueOf(pageable.getPageSize()));
       
        List<MonitorDeArchivosEnCursoDetallesResponse> content = entityManager.ejecutaBusquedaArchivosEnCurso(request);
        long total = entityManager.countConsultaOperaciones(request);
        return new PageImpl<>(content, pageable, total);
		
	}

}
