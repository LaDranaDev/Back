package mx.santander.h2h.monitoreo.constants;

/**
 * DetailOrdPagoAtmQueryConstants.
 *
 * @author Jesus Soto Aguilar
 */
public final class DetailOrdPagoAtmQueryConstants {

    /**
     * Constante para la
     * cadena de _TRAN
     * para el query principal
     * del detalle
     * del producto
     */
    public static final String GUION_TRAN="_TRAN ";

    /**
     * constante para la parte de
     * la sentencia del query
     * Ordenes
     * de pago en ATM
     * SELECT PROD.* FROM (
     */
    public static final String SELECT = "SELECT PROD.ID_REG, PROD.BUC, PROD.NUM_CTA_CARGO, PROD.NUM_CTA_ABONO, PROD.CVE_PROD_OPER,"
    		+"PROD.DESC_PROD, PROD.NOMBRE_ARCH, PROD.REFERENCIA, PROD.ID_ESTATUS, PROD.DESC_ESTATUS," 
    		+"PROD.IMPORTE, PROD.CLAVE_DESE, PROD.TIPO_CAMBIO, PROD.NUM_CNTR, PROD.DIVISA, "
    		+"PROD.FECHA_REGISTRO, PROD.FECHA_APLICACION, PROD.VIST_PROD, PROD.INTERMEDIARIO_ORD, PROD.DIVISA_ORD,"
    		+"PROD.INTERMEDIARIO_REC, PROD.BENEFICIARIO,  PROD.COMENTARIO_1,  PROD.COMENTARIO_2, PROD.COMENTARIO_3,"
    		+"PROD.TITULAR, PROD.BANCO_RECEPTOR,  PROD.TIPO_PAGO,  PROD.MODALIDAD, PROD.IMPORTE_CARGO, "
    		+"PROD.MSG_H2H,  PROD.MSG_ORDEN_PAGO,  PROD.NUM_ORDEN,  PROD.FECHA_LIMITE_PAGO,  PROD.NUM_SUCURSAL," 
    		+"PROD.FECH_VENC, PROD.REFERENCIA_ABONO,  PROD.REFERENCIA_CARGO,  PROD.NUMERO_EMPLEADO,  PROD.NUMERO_TARJETA," 
    		+"PROD.BUC_EMPLEADO,  PROD.SUCURSAL_TUTORA,  PROD.RFC,  PROD.NOMBRE_EMPLEADO,  PROD.NUMERO_CUENTA,"
    		+"PROD.DESCRIPCION, PROD.FECHA_PRESENTACION_INICIAL, PROD.FECHA_OPERACION, PROD.NUME_MOVI FROM (";
    /**
     * Query de campos para el
     * producto de Ordenes
     * de pago en ATM
     * Cambiarias
     *
     */
    public static final String QUERY = "SELECT id_reg, CLTE.buc, REG.CNTA_CARG NUM_CTA_CARGO, "+
    		"null NUM_CTA_ABONO, REG.cve_prod_oper, PROD.desc_prod, ARCH.nombre_arch, DETA.REFE_CTE REFERENCIA, REG.id_estatus,"+ 
    		"EST.desc_estatus, DETA.IMPO_GIRO IMPORTE, null CLAVE_DESE, null TIPO_CAMBIO, CNTR.num_cntr, "+
    		"REG.divi DIVISA, ARCH.fecha_registro, REG.fech_apli FECHA_APLICACION, PROD.vist_prod,NULL INTERMEDIARIO_ORD, "+
    		"'MXP'  DIVISA_ORD, NULL INTERMEDIARIO_REC, (DETA.NOMB_BENE) BENEFICIARIO, NULL COMENTARIO_1, NULL COMENTARIO_2,"+ 
    		"NULL COMENTARIO_3, null TITULAR,null BANCO_RECEPTOR, NULL TIPO_PAGO, NULL MODALIDAD, "+
    		"DETA.IMPO_GIRO IMPORTE_CARGO, MSG.msg_h2h, NULL MSG_ORDEN_PAGO, DETA.NUM_ORDN NUM_ORDEN, DETA.FECH_LIMI_LIQ FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL,"+ 
    		"NULL FECH_VENC, DETA.TEL_BENE REFERENCIA_ABONO, NULL REFERENCIA_CARGO, NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA, "+
    		"NULL BUC_EMPLEADO, NULL SUCURSAL_TUTORA, NULL RFC, NULL NOMBRE_EMPLEADO, REG.CNTA_CARG  NUMERO_CUENTA, NULL DESCRIPCION, "+
    		"null FECHA_PRESENTACION_INICIAL, REG.FECH_REG FECHA_OPERACION, REG.nume_movi";

    /**
     * constante para el
     * From del query principal de
     * transferencias vostro
     * FROM
     */
    public static final String FROM_TRAN = "%s DETA "
    		+ "INNER JOIN h2h_reg%s REG using(id_reg) " 
            + "INNER JOIN h2h_archivo%s ARCH  ON ARCH.id_archivo = REG.id_arch "
            + "INNER JOIN h2h_cntr CNTR using (id_cntr) "
            + "INNER JOIN h2h_clte CLTE using (id_clte) "
            + "INNER JOIN h2h_cat_prod PROD ON PROD.cve_prod_oper = REG.cve_prod_oper "
            + "INNER JOIN h2h_cat_estatus EST  ON REG.id_estatus = EST.id_cat_estatus "
            + "LEFT JOIN h2h_msg MSG ON MSG.id_msg = REG.id_msg";
    /**
     * ID_REG_EQ
     * parte del query para
     *  agregar al where
     * del id del registro
     * del detalle de operaciones
     */
    public static final String ID_REG_EQ=") PROD WHERE  PROD.id_reg =";
    /**
     * constante de tipo
     * String para
     * UNION ALL
     */
    public static final String UNION = " UNION ALL ";


    /**
     * Constructor privado.
     */
    private DetailOrdPagoAtmQueryConstants() {

    }
}
