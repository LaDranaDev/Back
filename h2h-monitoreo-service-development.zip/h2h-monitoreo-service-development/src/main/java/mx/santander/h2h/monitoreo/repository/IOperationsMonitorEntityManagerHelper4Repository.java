package mx.santander.h2h.monitoreo.repository;

import java.util.List;

import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;

public interface IOperationsMonitorEntityManagerHelper4Repository {

	/**
     * Realiza la consulta de los id de los comprobantes de la consulta
     * de monitor de operaciones
     * @param consultaOperaciones ConsultaMonitorOperacionesDTO
     * @return String
     */
	String obtenerIdsComprobantes(OperationsMonitorQueryRequest request);
	
	/**
     * Realiza la consulta de las operaciones para exportar
     * @param consultaOperaciones - Parámetros de consulta
     * @return Lista de operaciones realizadas
     */
	List<OperationsMonitorQueryResponse> consultaOperExport(OperationsMonitorQueryRequest consultaOperaciones);
}
