package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OperacionArchivoResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8869095595815976980L;

	/**
	 * ID del archivo a reportar.
	 */
	private Integer idArch;
	
	/**
	 * ID del registro.
	 */
	private Integer idReg;
	
	/**
	 * Nombre del Archivo a reportar
	 */
	private String nomArch;
	
	/**
	 * ID de estatus a reportar
	 */
	private Integer idEst;
	
	/**
	 * Estatus de las operaciones a reportar.
	 */
	private String statusOpe;	
	
	/**
	 * Estatus Inicial de las operaciones a reportar.
	 */
	private String statusIni;	
	
	/**
	 * Estatus Final de las operaciones a reportar.
	 */
	private String statusFin;
	
	/**
	 * Cuenta cargo a reportar.
	 */
	private String ctaCargo;
	
	/**
	 * Cuenta abono a reportar.
	 */
	private String ctaAbono;
	
	/**
	 * Referencia a reportar.
	 */
	private String referenciaBE;
	
	/**
	 * ID de producto a reportar.
	 */
	private Integer idProd;
	
	/**
	 * Importe a reportar.
	 */
	private BigDecimal importe;
	
	/**
	 * Producto a reportar.
	 */
	private String producto;
	
	/**
	 * ID de cliente a reportar.
	 */
	private Integer idCliente;
		
	/**
	 *Fecha aplicacion.
	 */
	private String fechaAplic;
	
	
	/**
	 * Importe a reportar con formato.
	 */
	private String importeFmt;
	

	/**
	 * umbr.
	 */
	private String umbr;
	

	/**
	 * Fecha de envio BE.
	 */
	private String fchEnvioBE;
	

	/**
	 * Fecha de respuesta BE
	 */
	private String fchRespuestaBE;
	
}
