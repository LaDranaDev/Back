/**
 * 
 */
package mx.santander.h2h.monitoreo.repository;

import java.util.List;

/**
 * @author C368734
 *
 */
public interface IGeneralJPARepository {

	/**
	 * 
	 * @param natquer
	 * @return List<String>
	 */
	List<String> conteoResgistros(String natquer);
}
