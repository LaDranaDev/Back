package mx.santander.h2h.monitoreo.service;

import java.math.BigDecimal;

import mx.santander.h2h.monitoreo.model.response.PutGetServiceResponse;

public interface IContractConnectionManagementPutGetSaveDataService {

	void guardaPtclPara(BigDecimal idptclpara, PutGetServiceResponse putGetServiceResponse, String opcion,
			String numeroContrato);

	void guardaPtclPath(PutGetServiceResponse putGetServiceResponse, BigDecimal idptclpara, String numeroContrato,
			String string);

	void guardarParaCD(PutGetServiceResponse putGetServiceResponse, BigDecimal idptclpara, String opcion);

	void guardaEnLDAP(PutGetServiceResponse putGetServiceResponse, String numeroContrato);

}
