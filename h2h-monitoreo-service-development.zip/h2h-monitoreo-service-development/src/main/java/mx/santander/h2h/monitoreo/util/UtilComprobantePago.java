package mx.santander.h2h.monitoreo.util;

import static mx.santander.h2h.monitoreo.util.UtilComprobante.CE_DESC_ESTATUS;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.CLTE_NOMBRE_CLTE_APPATERNO_CLTE_APMATERNO_NOM_CLTE;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.CLTE_PERSONALIDAD;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.CLTE_PERSONALIDADCLTE_RFC_CNTR_NUM_CNTR;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.CLTE_RAZON_SCIA;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.CLTE_RFC;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.CNTR_NUM_CNTR;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.CNTR_NUM_CNTR_CONTRATO;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.CT_DESC_PROD;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.INNER_JOIN_H2H_ARCHIVO_A_ON_R_ID_ARCH_A_ID_ARCHIVO;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.INNER_JOIN_H2H_ARCHIVO_TRAN_A_ON_R_ID_ACRCH_A_ID_ARCHIVO;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.INNER_JOIN_H2H_CAT_ESTATUS_CE_ON_R_ID_ESTATUS_ID_CATESTATUS;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.INNER_JOIN_H2H_CAT_ESTATUS_CE_ON_R_ID_ESTATUS_ID_CAT_ESTATUS;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.INNER_JOIN_H2H_CAT_PROD_CT_ON_R_CVE_PROD_OPER_CT_CVE_PRODOPER;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.INNER_JOIN_H2H_CLTE_CLTE_ON_CNTR_ID_CLTE_CLTE_ID_CLTE;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.INNER_JOIN_H2H_CNTR_CNTR_ON_CNTR_ID_CNTR_A_ID_CNTR;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.INNER_JOIN_H2H_REG_R_ON_R_ID_REG_NMB_ID_REG;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.INNER_JOIN_H2H_REG_TRAN_R_ON_R_ID_REG_NMB_ID_REG;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.LEFT_JOIN_H2H_ARCH_BACK_ABT_ON_R_ID_ARCH_BE_ABT_ID_ARCH_BACK;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.LEFT_JOIN_H2H_ARCH_BACK_TRAN_ABT_ON_R_ID_ARCHBE_ABT_ID_ARCH_BAK;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.LEFT_JOIN_H2H_CTA_INFO_CA_ON_R_CNTA_ABON_CA_NUME_CTA_AND_CA_TIPO_CTA_B;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.LEFT_JOIN_H2H_CTA_INFO_CC_ON_R_CNTA_CARG_CC_NUME_CTA_AND_CC_TIPO_CTA_O;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.NULL_AS_FORM_APLI;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.NULL_AS_PERS_AUT;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.NULL_BANCO_RECEPTOR;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.NULL_BANC_ABON;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.NULL_CLAVE_RASTREO;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.NULL_CLAV_PROV;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.NULL_CVE_FORM_PAGO;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.NULL_ESTATUS_MOV;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.NULL_FECHA_LIMITE_PAGO;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.NULL_FECH_VENCIMIENTO;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.NULL_ID_ESTA;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.NULL_NOMB_RAZON_SOCI_PROV;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.NULL_NUM_DOCU;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.NULL_NUM_ORDEN;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.NULL_NUM_SUCURSAL;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.NULL_REFE_ABON;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.NULL_RFC_PROV;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.NULL_TIPO_DOCU;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.NULL_TOPO_PAGO;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.R_CNTA_ABON_NUN_CTA_ABONO;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.R_CNTA_CARG_NUM_CTA_CARGO;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.R_FECH_ENVI_BACK_FECHA_OPERACION;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.R_MONT_IMPORTE;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.SELECT_R_ID_REG;
import static mx.santander.h2h.monitoreo.util.UtilComprobante.agregaIdReg;
import static mx.santander.h2h.monitoreo.util.UtilVostroComprobantes.UNION_ALL;

import java.util.List;

public final class UtilComprobantePago {

    /**clte.RAZON_SCIA,clte.NOMBRE  || ' '  || clte.APPATERNO  || ' '  || clte.APMATERNO NOM_CLTE,
     * TCS (sonar)
     * **/
    private static final String CLTE_RAZON_SCIA_CLTE_NOMBRE_CLTE_APPATERNO_CLTE_APMATERNO_NOM_CLTE="clte.RAZON_SCIA,clte.NOMBRE  || ' '  || clte.APPATERNO  || ' '  || clte.APMATERNO NOM_CLTE, ";
    /**  TO_CHAR(abt.FECH_RESP_BE,'dd/mm/yyyy hh24:mi:ss') FECH_APLI,
     * TCS (sonar) **/
    private static final String TO_CHAR_ABT_FECH_RESP_BE_FECH_APLI="  TO_CHAR(abt.FECH_RESP_BE,'dd/mm/yyyy hh24:mi:ss') FECH_APLI,   ";
    /**  'MXP' DIVISA, */
    /**  Fecha de aplicacion para producto TMB si es nulo el de archivo de backend obtenerlo de la tabla de producto**/
    private static final String TO_CHAR_ABT_FECH_RESP_BE_FECH_APLI_TMB="  DECODE(abt.FECH_RESP_BE,null,TO_CHAR(tmb.FECH_APLI,'dd/mm/yyyy hh24:mi:ss'),TO_CHAR(abt.FECH_RESP_BE,'dd/mm/yyyy hh24:mi:ss')) FECH_APLI,   ";
    private static final String MXP_DIVISA="  'MXP' DIVISA,  ";

    private UtilComprobantePago() {}

    /**
     * Obtiene el query de Pagos Referenciados.
     *
     * @param listIds
     *            List<Integer>
     * @return String query
     */

    protected static String obtenerQueryPagoRef(List<Integer> listIds) {
        final StringBuilder sql = new StringBuilder()
                .append("SELECT r.ID_REG, cntr.NUM_CNTR CONTRATO, nmb.NUM_CTA_CARG NUM_CTA_CARGO,r.CNTA_ABON NUN_CTA_ABONO, ")
                .append("ct.DESC_PROD, r.mont IMPORTE, NULL REFERENCIA, 'MXP' DIVISA, ce.DESC_ESTATUS, ")
                .append("to_char(nmb.FECH_REG,'dd/mm/yyyy hh24:mi:ss') FECH_APLI, null BENEFICIARIO, 'H2H' TIPO_PAGO,")// cnl.nomb_canl TIPO_PAGO,")
                .append("nmb.NOMB_CLTE TITULAR,  nmb.OBSE_ABO CONCEPTO_PAGO, cnv.desr CLAVE_RASTREO, NULL BANCO_RECEPTOR,r.FECH_ENVI_BACK FECHA_OPERACION, ")
                .append("NULL CLAV_PROV,null NUM_DOCU,null FECH_VENCIMIENTO,null CVE_FORM_PAGO,'-'||trim(ct.CVE_PROD_OPER)||'-'  ESTATUS_MOV,null NUM_ORDEN, null FECHA_LIMITE_PAGO,null NUM_SUCURSAL, ")
                .append(CLTE_RAZON_SCIA_CLTE_NOMBRE_CLTE_APPATERNO_CLTE_APMATERNO_NOM_CLTE)
                .append(CLTE_PERSONALIDADCLTE_RFC_CNTR_NUM_CNTR)
                .append("nmb.CLVE_CONV CLAVE_BENEF,null ID_ESTA,null PERS_AUT,null FORM_APLI,null NOMB_RAZON_SOCI_PROV,null RFC_PROV,")
                .append(" r.LINE_CANO BANC_ABON, nmb.OBSE_CARG REFE_ABON ,null TIPO_DOCU ")
                .append(" FROM H2H_PROD_PAGO_REFE nmb  ")
                .append(INNER_JOIN_H2H_REG_R_ON_R_ID_REG_NMB_ID_REG)
                .append(INNER_JOIN_H2H_CAT_PROD_CT_ON_R_CVE_PROD_OPER_CT_CVE_PRODOPER)
                .append(INNER_JOIN_H2H_ARCHIVO_A_ON_R_ID_ARCH_A_ID_ARCHIVO)
                .append(LEFT_JOIN_H2H_ARCH_BACK_ABT_ON_R_ID_ARCH_BE_ABT_ID_ARCH_BACK)
                .append(INNER_JOIN_H2H_CNTR_CNTR_ON_CNTR_ID_CNTR_A_ID_CNTR)
                .append(INNER_JOIN_H2H_CLTE_CLTE_ON_CNTR_ID_CLTE_CLTE_ID_CLTE)
                .append(INNER_JOIN_H2H_CAT_ESTATUS_CE_ON_R_ID_ESTATUS_ID_CAT_ESTATUS)
                .append(" LEFT JOIN H2H_CAT_CONV cnv ON trim(cnv.clve_serv)=trim(nmb.CLVE_CONV)")
                .append(" LEFT JOIN H2H_CAT_CANL cnl ON trim(a.id_canl)=trim(cnl.id_canl)");
        agregaIdReg(listIds, sql);
        sql.append(UNION_ALL)
                .append("SELECT r.ID_REG, cntr.NUM_CNTR CONTRATO, nmb.NUM_CTA_CARG NUM_CTA_CARGO,r.CNTA_ABON NUN_CTA_ABONO, ")
                .append("ct.DESC_PROD, r.mont IMPORTE, NULL REFERENCIA, 'MXP' DIVISA, ce.DESC_ESTATUS, ")
                .append("to_char(nmb.FECH_REG,'dd/mm/yyyy hh24:mi:ss') FECH_APLI, null BENEFICIARIO, 'H2H' TIPO_PAGO,")// cnl.nomb_canl TIPO_PAGO,")
                .append("nmb.NOMB_CLTE TITULAR,  nmb.OBSE_ABO CONCEPTO_PAGO, cnv.desr CLAVE_RASTREO, NULL BANCO_RECEPTOR,r.FECH_ENVI_BACK FECHA_OPERACION, ")
                .append("NULL CLAV_PROV,null NUM_DOCU,null FECH_VENCIMIENTO,null CVE_FORM_PAGO,'-'||trim(ct.CVE_PROD_OPER)||'-'  ESTATUS_MOV,null NUM_ORDEN, null FECHA_LIMITE_PAGO,null NUM_SUCURSAL, ")
                .append(CLTE_RAZON_SCIA_CLTE_NOMBRE_CLTE_APPATERNO_CLTE_APMATERNO_NOM_CLTE)
                .append(CLTE_PERSONALIDADCLTE_RFC_CNTR_NUM_CNTR)
                .append("nmb.CLVE_CONV CLAVE_BENEF,null ID_ESTA,null PERS_AUT,null FORM_APLI,null NOMB_RAZON_SOCI_PROV,null RFC_PROV,")
                .append(" r.LINE_CANO BANC_ABON, nmb.OBSE_CARG REFE_ABON ,null TIPO_DOCU ")
                .append(" FROM H2H_PROD_PAGO_REFE_TRAN nmb         ")
                .append(INNER_JOIN_H2H_REG_TRAN_R_ON_R_ID_REG_NMB_ID_REG)
                .append(INNER_JOIN_H2H_CAT_PROD_CT_ON_R_CVE_PROD_OPER_CT_CVE_PRODOPER)
                .append(INNER_JOIN_H2H_ARCHIVO_TRAN_A_ON_R_ID_ACRCH_A_ID_ARCHIVO)
                .append(LEFT_JOIN_H2H_ARCH_BACK_TRAN_ABT_ON_R_ID_ARCHBE_ABT_ID_ARCH_BAK)
                .append(INNER_JOIN_H2H_CNTR_CNTR_ON_CNTR_ID_CNTR_A_ID_CNTR)
                .append(INNER_JOIN_H2H_CLTE_CLTE_ON_CNTR_ID_CLTE_CLTE_ID_CLTE)
                .append(INNER_JOIN_H2H_CAT_ESTATUS_CE_ON_R_ID_ESTATUS_ID_CAT_ESTATUS)
                .append(" LEFT JOIN H2H_CAT_CONV cnv ON trim(cnv.clve_serv)=trim(nmb.CLVE_CONV)")
                .append(" LEFT JOIN H2H_CAT_CANL cnl ON trim(a.id_canl)=trim(cnl.id_canl)");
        agregaIdReg(listIds, sql);
        return sql.toString();
    }

    /**
     * Obtiene el query de Alta Pago.
     *
     * @param listIds
     *            List<Integer>
     * @return String
     */
    protected static String obtenerQueryProdAltaPago(List<Integer> listIds) {
        final StringBuilder sql = new StringBuilder()
                .append(SELECT_R_ID_REG)
                .append(CNTR_NUM_CNTR_CONTRATO)
                .append("  TO_CHAR(ap.CNTA_CARG) NUM_CTA_CARGO,         ")
                .append("  ap.CNTA_ABON NUN_CTA_ABONO,         ")
                .append(CT_DESC_PROD).append(R_MONT_IMPORTE)
                .append("  TO_CHAR (ap.REFE_INTB) REFERENCIA, ")
                .append("  ap.DIVISA,     ")
                .append(CE_DESC_ESTATUS).append(TO_CHAR_ABT_FECH_RESP_BE_FECH_APLI)
                .append("  NULL BENEFICIARIO,       ")
                .append(NULL_TOPO_PAGO)
                .append("  NULL TITULAR,  ")
                .append("  ap.CONC_PAGO CONCEPTO_PAGO,        ")
                .append(NULL_CLAVE_RASTREO).append(NULL_BANCO_RECEPTOR).append(R_FECH_ENVI_BACK_FECHA_OPERACION)
                .append("  ap.CLAV_PROV,  ")
                .append("  ap.NUM_DOCU,   ")
                .append("  TO_CHAR(ap.FECH_VENC,'dd/mm/yyyy') FECH_VENCIMIENTO,     ")
                .append("  DECODE (ap.CVE_FORM_PAGO, 1,'ABONO A CUENTA MISMO BANCO', ")
                .append("  2,'ABONO A CUENTA DE OTROS BANCOS NACIONALES', ")
                .append("  3,'ABONO A CUENTA EN EL EXTRANJERO') CVE_FORM_PAGO,")
                .append("  ce.DESC_ESTATUS ESTATUS_MOV,")
                .append(NULL_NUM_ORDEN).append(NULL_FECHA_LIMITE_PAGO).append(NULL_NUM_SUCURSAL)
                .append(CLTE_RAZON_SCIA).append(CLTE_NOMBRE_CLTE_APPATERNO_CLTE_APMATERNO_NOM_CLTE)
                .append(CLTE_PERSONALIDAD)
                .append(CLTE_RFC)
                .append(CNTR_NUM_CNTR)
                .append("  NULL CLAVE_BENEF,  ")
                .append(NULL_ID_ESTA)
                .append(NULL_AS_PERS_AUT)
                .append("  ap.FORM_APLI,         ")
                .append("  ap.NOMB_RAZON_SOCI_PROV, ")
                .append("  ap.RFC RFC_PROV, ")
                .append("  ap.BANC_ABON, ")
                .append("  ap.REFE_ABON, ")
                .append("  DECODE (ap.tipo_docu,1,'FACTURA',2,'FACTURA','OTRO' ) TIPO_DOCU ")
                .append(" FROM H2H_PROD_ALTA_PAGO ap")
                .append(" INNER JOIN H2H_REG r ON r.id_reg = ap.id_reg  ")
                .append(INNER_JOIN_H2H_CAT_PROD_CT_ON_R_CVE_PROD_OPER_CT_CVE_PRODOPER)
                .append(INNER_JOIN_H2H_ARCHIVO_A_ON_R_ID_ARCH_A_ID_ARCHIVO)
                .append(LEFT_JOIN_H2H_ARCH_BACK_ABT_ON_R_ID_ARCH_BE_ABT_ID_ARCH_BACK)
                .append(INNER_JOIN_H2H_CNTR_CNTR_ON_CNTR_ID_CNTR_A_ID_CNTR)
                .append(INNER_JOIN_H2H_CLTE_CLTE_ON_CNTR_ID_CLTE_CLTE_ID_CLTE)
                .append(INNER_JOIN_H2H_CAT_ESTATUS_CE_ON_R_ID_ESTATUS_ID_CATESTATUS);
        agregaIdReg(listIds, sql);
        sql.append(UNION_ALL)
                .append(SELECT_R_ID_REG)
                .append(CNTR_NUM_CNTR_CONTRATO)
                .append("  TO_CHAR(ap.CNTA_CARG) NUM_CTA_CARGO,         ")
                .append("  ap.CNTA_ABON NUN_CTA_ABONO,         ")
                .append(CT_DESC_PROD)
                .append(R_MONT_IMPORTE)
                .append("  TO_CHAR (ap.REFE_INTB) REFERENCIA, ")
                .append("  ap.DIVISA,     ")
                .append(CE_DESC_ESTATUS)
                .append(TO_CHAR_ABT_FECH_RESP_BE_FECH_APLI)
                .append("  NULL BENEFICIARIO,       ")
                .append(NULL_TOPO_PAGO)
                .append("  NULL TITULAR,  ")
                .append("  ap.CONC_PAGO CONCEPTO_PAGO,        ")
                .append(NULL_CLAVE_RASTREO)
                .append(NULL_BANCO_RECEPTOR)
                .append(R_FECH_ENVI_BACK_FECHA_OPERACION)
                .append("  ap.CLAV_PROV,  ")
                .append("  ap.NUM_DOCU,   ")
                .append("  TO_CHAR(ap.FECH_VENC,'dd/mm/yyyy') FECH_VENCIMIENTO,     ")
                .append("  DECODE (ap.CVE_FORM_PAGO, 1,'ABONO A CUENTA MISMO BANCO', ")
                .append("  2,'ABONO A CUENTA DE OTROS BANCOS NACIONALES', ")
                .append("  3,'ABONO A CUENTA EN EL EXTRANJERO') CVE_FORM_PAGO,")
                .append("  ce.DESC_ESTATUS ESTATUS_MOV,")
                .append(NULL_NUM_ORDEN)
                .append(NULL_FECHA_LIMITE_PAGO)
                .append(NULL_NUM_SUCURSAL)
                .append(CLTE_RAZON_SCIA)
                .append(CLTE_NOMBRE_CLTE_APPATERNO_CLTE_APMATERNO_NOM_CLTE)
                .append(CLTE_PERSONALIDAD)
                .append(CLTE_RFC)
                .append(CNTR_NUM_CNTR)
                .append("  NULL CLAVE_BENEF,         ")
                .append(NULL_ID_ESTA)
                .append(NULL_AS_PERS_AUT)
                .append("  ap.FORM_APLI,         ")
                .append("  ap.NOMB_RAZON_SOCI_PROV, ")
                .append("  ap.RFC RFC_PROV, ")
                .append("  ap.BANC_ABON, ")
                .append("  ap.REFE_ABON, ")
                .append("  DECODE (ap.tipo_docu,1,'FACTURA',2,'FACTURA','OTRO' ) TIPO_DOCU ")
                .append(" FROM H2H_PROD_ALTA_PAGO_TRAN ap     ")
                .append(" INNER JOIN H2H_REG_TRAN r ON r.id_reg = ap.id_reg       ")
                .append(INNER_JOIN_H2H_CAT_PROD_CT_ON_R_CVE_PROD_OPER_CT_CVE_PRODOPER)
                .append(INNER_JOIN_H2H_ARCHIVO_TRAN_A_ON_R_ID_ACRCH_A_ID_ARCHIVO)
                .append(LEFT_JOIN_H2H_ARCH_BACK_TRAN_ABT_ON_R_ID_ARCHBE_ABT_ID_ARCH_BAK)
                .append(INNER_JOIN_H2H_CNTR_CNTR_ON_CNTR_ID_CNTR_A_ID_CNTR)
                .append(INNER_JOIN_H2H_CLTE_CLTE_ON_CNTR_ID_CLTE_CLTE_ID_CLTE)
                .append(INNER_JOIN_H2H_CAT_ESTATUS_CE_ON_R_ID_ESTATUS_ID_CATESTATUS);
        agregaIdReg(listIds, sql);
        return sql.toString();
    }

    /**
     * Obtiene el query de Orden de Pago.
     *
     * @param listIds
     *            List<Integer>
     * @return String
     */
    protected static String obtenerQueryProdOrdnPago(List<Integer> listIds) {
        final StringBuilder sql = new StringBuilder()
                .append(SELECT_R_ID_REG)
                .append(CNTR_NUM_CNTR_CONTRATO).append(R_CNTA_CARG_NUM_CTA_CARGO).append(R_CNTA_ABON_NUN_CTA_ABONO)
                .append(CT_DESC_PROD).append(R_MONT_IMPORTE)
                .append("  op.RESP_REF REFERENCIA,  ")
                .append(MXP_DIVISA).append(CE_DESC_ESTATUS).append(TO_CHAR_ABT_FECH_RESP_BE_FECH_APLI)
                .append("  op.NOMB_BENE  || ' '  || op.APE_PATE_BENE  || ' '  || op.APE_MATE_BENE BENEFICIARIO, ")
                .append("  DECODE(op.FORM_PAGO,'C','CHEQUE DE CAJA','E','EFECTIVO') TIPO_PAGO,  ")
                .append("  op.NOMB_ORD  || ' '  || op.APE_PATE_ORDE  || ' '  || op.APE_MATE_ORDE TITULAR,       ")
                .append("  op.conc_pago CONCEPTO_PAGO,      ")
                .append("  op.REFE_CLTE CLAVE_RASTREO,")
                .append("  op.REFE_NUM_CLTE BANCO_RECEPTOR, ")
                .append(R_FECH_ENVI_BACK_FECHA_OPERACION).append(NULL_CLAV_PROV).append(NULL_NUM_DOCU)
                .append(NULL_FECH_VENCIMIENTO).append(NULL_CVE_FORM_PAGO).append(NULL_ESTATUS_MOV)
                .append("  to_number(op.NUM_ORDEN) NUM_ORDEN,  ")
                .append("  TO_CHAR(op.FECH_LIMI_LIQ,'dd/mm/yyyy') FECHA_LIMITE_PAGO,")
                .append("  oplc.OFIC_OPER NUM_SUCURSAL,")
                .append(CLTE_RAZON_SCIA).append(CLTE_NOMBRE_CLTE_APPATERNO_CLTE_APMATERNO_NOM_CLTE)
                .append(CLTE_PERSONALIDAD).append(CLTE_RFC).append(CNTR_NUM_CNTR)
                .append("  SUBSTR (op.MENSAJE, 93, 20) CLAVE_BENEF,     ")
                .append("  DECODE(oplc.ID_ESTA, null, oplcHist.ID_ESTA, oplc.ID_ESTA) ID_ESTA,  ")
                .append("  substr(op.mensaje,21,40) AS PERS_AUT,         ")
                .append(NULL_AS_FORM_APLI).append(NULL_NOMB_RAZON_SOCI_PROV).append(NULL_RFC_PROV)
                .append(NULL_BANC_ABON).append(NULL_REFE_ABON).append(NULL_TIPO_DOCU)
                .append(" FROM H2H_PROD_ORDN_PAGO op")
                .append(" INNER JOIN H2H_REG r ON r.id_reg = op.id_reg  ")
                .append(INNER_JOIN_H2H_CAT_PROD_CT_ON_R_CVE_PROD_OPER_CT_CVE_PRODOPER)
                .append(INNER_JOIN_H2H_ARCHIVO_A_ON_R_ID_ARCH_A_ID_ARCHIVO)
                .append(LEFT_JOIN_H2H_ARCH_BACK_ABT_ON_R_ID_ARCH_BE_ABT_ID_ARCH_BACK)
                .append(INNER_JOIN_H2H_CNTR_CNTR_ON_CNTR_ID_CNTR_A_ID_CNTR)
                .append(INNER_JOIN_H2H_CLTE_CLTE_ON_CNTR_ID_CLTE_CLTE_ID_CLTE)
                .append(INNER_JOIN_H2H_CAT_ESTATUS_CE_ON_R_ID_ESTATUS_ID_CATESTATUS)
                .append(" LEFT JOIN H2H_ORDN_PAGO_LIQU_CANC_HIST oplc ON op.ID_REG = oplc.ID_REG ")
                .append(" LEFT JOIN H2H_ORDN_PAGO_LIQU_CANC_HIST oplcHist ON op.ID_REG = oplcHist.ID_REG ");

        agregaIdReg(listIds, sql);
        sql.append(UNION_ALL)
                .append(SELECT_R_ID_REG)
                .append(CNTR_NUM_CNTR_CONTRATO)
                .append(R_CNTA_CARG_NUM_CTA_CARGO)
                .append(R_CNTA_ABON_NUN_CTA_ABONO)
                .append(CT_DESC_PROD)
                .append(R_MONT_IMPORTE)
                .append("  op.RESP_REF REFERENCIA,  ")
                .append(MXP_DIVISA)
                .append(CE_DESC_ESTATUS)
                .append(TO_CHAR_ABT_FECH_RESP_BE_FECH_APLI)
                .append("  op.NOMB_BENE  || ' '  || op.APE_PATE_BENE  || ' '  || op.APE_MATE_BENE BENEFICIARIO, ")
                .append("   DECODE(op.FORM_PAGO,'C','CHEQUE DE CAJA','E','EFECTIVO') TIPO_PAGO,  ")
                .append("  op.NOMB_ORD  || ' '  || op.APE_PATE_ORDE  || ' '  || op.APE_MATE_ORDE TITULAR,       ")
                .append("  op.conc_pago CONCEPTO_PAGO,      ")
                .append("  op.REFE_CLTE CLAVE_RASTREO,")
                .append("  op.REFE_NUM_CLTE BANCO_RECEPTOR, ")
                .append(R_FECH_ENVI_BACK_FECHA_OPERACION)
                .append(NULL_CLAV_PROV)
                .append(NULL_NUM_DOCU)
                .append(NULL_FECH_VENCIMIENTO)
                .append(NULL_CVE_FORM_PAGO)
                .append(NULL_ESTATUS_MOV)
                .append("  to_number(op.NUM_ORDEN) NUM_ORDEN,  ")
                .append("  TO_CHAR(op.FECH_LIMI_LIQ,'dd/mm/yyyy') FECHA_LIMITE_PAGO,")
                .append("  oplc.OFIC_OPER NUM_SUCURSAL,")
                .append(CLTE_RAZON_SCIA)
                .append(CLTE_NOMBRE_CLTE_APPATERNO_CLTE_APMATERNO_NOM_CLTE)
                .append(CLTE_PERSONALIDAD)
                .append(CLTE_RFC)
                .append(CNTR_NUM_CNTR)
                .append("  SUBSTR (op.MENSAJE, 93, 20) CLAVE_BENEF,     ")
                .append("  DECODE(oplc.ID_ESTA, null, oplcHist.ID_ESTA, oplc.ID_ESTA) ID_ESTA,  ")
                .append("  substr(op.mensaje,21,40) AS PERS_AUT,         ")
                .append(NULL_AS_FORM_APLI)
                .append(NULL_NOMB_RAZON_SOCI_PROV)
                .append(NULL_RFC_PROV)
                .append(NULL_BANC_ABON)
                .append(NULL_REFE_ABON)
                .append(NULL_TIPO_DOCU)
                .append(" FROM H2H_PROD_ORDN_PAGO_TRAN op     ")
                .append(" INNER JOIN H2H_REG_TRAN r ON r.id_reg = op.id_reg       ")
                .append(INNER_JOIN_H2H_CAT_PROD_CT_ON_R_CVE_PROD_OPER_CT_CVE_PRODOPER)
                .append(INNER_JOIN_H2H_ARCHIVO_TRAN_A_ON_R_ID_ACRCH_A_ID_ARCHIVO)
                .append(LEFT_JOIN_H2H_ARCH_BACK_TRAN_ABT_ON_R_ID_ARCHBE_ABT_ID_ARCH_BAK)
                .append(INNER_JOIN_H2H_CNTR_CNTR_ON_CNTR_ID_CNTR_A_ID_CNTR)
                .append(INNER_JOIN_H2H_CLTE_CLTE_ON_CNTR_ID_CLTE_CLTE_ID_CLTE)
                .append(INNER_JOIN_H2H_CAT_ESTATUS_CE_ON_R_ID_ESTATUS_ID_CATESTATUS)
                .append(" LEFT JOIN H2H_ORDN_PAGO_LIQU_CANC oplc ON op.ID_REG = oplc.ID_REG ")
                .append(" LEFT JOIN H2H_ORDN_PAGO_LIQU_CANC_HIST oplcHist ON op.ID_REG = oplcHist.ID_REG ");

        agregaIdReg(listIds, sql);
        return sql.toString();
    }

    /**
     * Obtiene el query de Transferencia de Mismo Banco.
     *
     * @param listIds
     *            List<Integer>
     * @return String
     */
    protected static String obtenerQueryProdTranMismBanc(List<Integer> listIds) {
        final StringBuilder sql = new StringBuilder()
                .append("SELECT r.ID_REG,  ")
                .append("  cntr.NUM_CNTR CONTRATO,   ")
                .append("  r.CNTA_CARG NUM_CTA_CARGO,")
                .append("  r.CNTA_ABON NUN_CTA_ABONO,")
                .append("  ct.DESC_PROD,   ")
                .append("  r.mont IMPORTE, ")
                .append("  NULL REFERENCIA,      ")
                .append("  CATDIV.CLAV_CAPTA DIVISA,   ")
                .append("  ce.DESC_ESTATUS,")
                .append(TO_CHAR_ABT_FECH_RESP_BE_FECH_APLI_TMB)
                .append("  ca.NOMB_TITU BENEFICIARIO,        ")
                .append("  NULL TIPO_PAGO, ")
                .append("  cc.NOMB_TITU TITULAR,   ")
                .append("  SUBSTR(tmb.OBSE_ABON,1,40)  CONCEPTO_PAGO,       ")
                .append("  NULL CLAVE_RASTREO,       ")
                .append("  NULL BANCO_RECEPTOR,      ")
                .append("  r.FECH_ENVI_BACK FECHA_OPERACION,   ")
                .append("  NULL CLAV_PROV, ")
                .append("  NULL NUM_DOCU,  ")
                .append("  NULL FECH_VENCIMIENTO,    ")
                .append("  NULL CVE_FORM_PAGO,       ")
                .append("  NULL ESTATUS_MOV,         ")
                .append("  NULL NUM_ORDEN, ")
                .append("  NULL FECHA_LIMITE_PAGO,   ")
                .append("  NULL NUM_SUCURSAL,        ")
                .append("  clte.RAZON_SCIA,")
                .append("  clte.nombre  || ' '  || clte.appaterno  || ' '  || clte.apmaterno NOM_CLTE, ")
                .append("  clte.PERSONALIDAD,        ")
                .append("  clte.RFC,       ").append(CNTR_NUM_CNTR)
                .append("  NULL CLAVE_BENEF, ").append(NULL_ID_ESTA)
                .append(NULL_AS_PERS_AUT).append(NULL_AS_FORM_APLI).append(NULL_NOMB_RAZON_SOCI_PROV)
                .append(NULL_RFC_PROV).append(NULL_BANC_ABON).append(NULL_REFE_ABON).append(NULL_TIPO_DOCU)
                .append(" FROM H2H_PROD_TRAN_MISM_BANC tmb     ")
                .append(" INNER JOIN H2H_REG r ON r.id_reg = tmb.id_reg  ")
                .append(" INNER JOIN H2H_CAT_PROD ct ON r.cve_prod_oper = ct.cve_prod_oper   ")
                .append(" INNER JOIN H2H_ARCHIVO a ON r.id_arch = a.id_archivo     ")
                .append(LEFT_JOIN_H2H_ARCH_BACK_ABT_ON_R_ID_ARCH_BE_ABT_ID_ARCH_BACK)
                .append(" INNER JOIN H2H_CNTR cntr ON cntr.id_cntr = a.id_cntr     ")
                .append(" INNER JOIN H2H_CLTE clte ON cntr.id_clte = clte.id_clte  ")
                .append(" INNER JOIN H2H_CAT_ESTATUS ce ON r.id_estatus = id_cat_estatus     ")
                .append(LEFT_JOIN_H2H_CTA_INFO_CA_ON_R_CNTA_ABON_CA_NUME_CTA_AND_CA_TIPO_CTA_B)
                .append(LEFT_JOIN_H2H_CTA_INFO_CC_ON_R_CNTA_CARG_CC_NUME_CTA_AND_CC_TIPO_CTA_O)
                .append(" LEFT JOIN H2H_CAT_DIVISA  CATDIV ON CATDIV.ID_CAT_DIVISA=CC.ID_CAT_DIVISA ");
        agregaIdReg(listIds, sql);
        sql.append(UNION_ALL)
                .append(SELECT_R_ID_REG)
                .append(CNTR_NUM_CNTR_CONTRATO)
                .append(R_CNTA_CARG_NUM_CTA_CARGO)
                .append(R_CNTA_ABON_NUN_CTA_ABONO)
                .append(CT_DESC_PROD)
                .append(R_MONT_IMPORTE)
                .append("  NULL REFERENCIA,     ")
                .append(" CATDIV.CLAV_CAPTA DIVISA, ")
                .append(CE_DESC_ESTATUS)
                .append(TO_CHAR_ABT_FECH_RESP_BE_FECH_APLI_TMB)
                .append("  ca.NOMB_TITU BENEFICIARIO,       ")
                .append(NULL_TOPO_PAGO)
                .append("  cc.NOMB_TITU TITULAR,  ")
                .append("  SUBSTR(tmb.OBSE_ABON,1,40) CONCEPTO_PAGO,      ")
                .append(NULL_CLAVE_RASTREO)
                .append(NULL_BANCO_RECEPTOR)
                .append(R_FECH_ENVI_BACK_FECHA_OPERACION)
                .append(NULL_CLAV_PROV)
                .append(NULL_NUM_DOCU)
                .append(NULL_FECH_VENCIMIENTO)
                .append(NULL_CVE_FORM_PAGO)
                .append(NULL_ESTATUS_MOV)
                .append(NULL_NUM_ORDEN)
                .append(NULL_FECHA_LIMITE_PAGO)
                .append("  NULL NUM_SUCURSAL,  ")
                .append("  clte.RAZON_SCIA,    ")
                .append(CLTE_NOMBRE_CLTE_APPATERNO_CLTE_APMATERNO_NOM_CLTE)
                .append("  clte.PERSONALIDAD,  ")
                .append("  clte.RFC,   ")
                .append(CNTR_NUM_CNTR)
                .append("  NULL CLAVE_BENEF,  ")
                .append(NULL_ID_ESTA)
                .append(NULL_AS_PERS_AUT)
                .append(NULL_AS_FORM_APLI)
                .append(NULL_NOMB_RAZON_SOCI_PROV)
                .append(NULL_RFC_PROV)
                .append(NULL_BANC_ABON)
                .append(NULL_REFE_ABON)
                .append(NULL_TIPO_DOCU)
                .append(" FROM H2H_PROD_TRAN_MISM_BANC_TRAN tmb ")
                .append(" INNER JOIN H2H_REG_TRAN r ON r.id_reg = tmb.id_reg       ")
                .append(INNER_JOIN_H2H_CAT_PROD_CT_ON_R_CVE_PROD_OPER_CT_CVE_PRODOPER)
                .append(" INNER JOIN H2H_ARCHIVO_TRAN a ON r.id_arch = a.id_archivo")
                .append(LEFT_JOIN_H2H_ARCH_BACK_TRAN_ABT_ON_R_ID_ARCHBE_ABT_ID_ARCH_BAK)
                .append(" INNER JOIN H2H_CNTR cntr ON cntr.id_cntr = a.id_cntr     ")
                .append(" INNER JOIN H2H_CLTE clte ON cntr.id_clte = clte.id_clte  ")
                .append(INNER_JOIN_H2H_CAT_ESTATUS_CE_ON_R_ID_ESTATUS_ID_CATESTATUS)
                .append(LEFT_JOIN_H2H_CTA_INFO_CA_ON_R_CNTA_ABON_CA_NUME_CTA_AND_CA_TIPO_CTA_B)
                .append(LEFT_JOIN_H2H_CTA_INFO_CC_ON_R_CNTA_CARG_CC_NUME_CTA_AND_CC_TIPO_CTA_O)
                .append(" LEFT JOIN H2H_CAT_DIVISA  CATDIV ON CATDIV.ID_CAT_DIVISA=CC.ID_CAT_DIVISA ");
        agregaIdReg(listIds, sql);
        return sql.toString();
    }

    /**
     * Obtiene el query de Pago a TDC Santander.
     *
     * @param listIds
     *            List<Integer>
     * @return String
     */
    protected static String obtenerQueryPagoTDC(List<Integer> listIds) {
        final StringBuilder sql = new StringBuilder()
                .append("SELECT r.ID_REG,  ")
                .append("  cntr.NUM_CNTR CONTRATO,   ")
                .append("  r.CNTA_CARG NUM_CTA_CARGO,")
                .append("  r.CNTA_ABON NUN_CTA_ABONO,")
                .append("  ct.DESC_PROD,   ")
                .append("  r.mont IMPORTE, ")
                .append("  NULL REFERENCIA,      ")
                .append("  CATDIV.CLAV_CAPTA DIVISA,   ")
                .append("  ce.DESC_ESTATUS,")
                .append("  TO_CHAR(abt.FECH_RESP_BE,'dd/mm/yyyy hh24:mi:ss') FECH_APLI,    ")
                .append("  ca.NOMB_TITU BENEFICIARIO,        ")
                .append("  NULL TIPO_PAGO, ")
                .append("  cc.NOMB_TITU TITULAR,   ")
                .append("  tdc.OBSER_ABO  CONCEPTO_PAGO,       ")
                .append("  NULL CLAVE_RASTREO,       ")
                .append("  NULL BANCO_RECEPTOR,      ")
                .append("  r.FECH_ENVI_BACK FECHA_OPERACION,   ")
                .append("  NULL CLAV_PROV, ")
                .append("  NULL NUM_DOCU,  ")
                .append("  NULL FECH_VENCIMIENTO,    ")
                .append("  NULL CVE_FORM_PAGO,       ")
                .append("  NULL ESTATUS_MOV,         ")
                .append("  NULL NUM_ORDEN, ")
                .append("  NULL FECHA_LIMITE_PAGO,   ")
                .append("  NULL NUM_SUCURSAL,        ")
                .append("  clte.RAZON_SCIA,")
                .append("  clte.nombre  || ' '  || clte.appaterno  || ' '  || clte.apmaterno NOM_CLTE, ")
                .append("  clte.PERSONALIDAD,        ")
                .append("  clte.RFC,       ").append(CNTR_NUM_CNTR)
                .append("  NULL CLAVE_BENEF, ").append(NULL_ID_ESTA).append(NULL_AS_PERS_AUT).append(NULL_AS_FORM_APLI)
                .append(NULL_NOMB_RAZON_SOCI_PROV).append(NULL_RFC_PROV).append(NULL_BANC_ABON).append(NULL_REFE_ABON)
                .append(NULL_TIPO_DOCU)
                .append(" FROM H2H_MX_PROD_PAGO_TDC tdc     ")
                .append(" INNER JOIN H2H_REG r ON r.id_reg = tdc.id_reg  ")
                .append(" INNER JOIN H2H_CAT_PROD ct ON r.cve_prod_oper = ct.cve_prod_oper   ")
                .append(" INNER JOIN H2H_ARCHIVO a ON r.id_arch = a.id_archivo     ")
                .append(LEFT_JOIN_H2H_ARCH_BACK_ABT_ON_R_ID_ARCH_BE_ABT_ID_ARCH_BACK)
                .append(" INNER JOIN H2H_CNTR cntr ON cntr.id_cntr = a.id_cntr     ")
                .append(" INNER JOIN H2H_CLTE clte ON cntr.id_clte = clte.id_clte  ")
                .append(" INNER JOIN H2H_CAT_ESTATUS ce ON r.id_estatus = id_cat_estatus     ")
                .append(LEFT_JOIN_H2H_CTA_INFO_CA_ON_R_CNTA_ABON_CA_NUME_CTA_AND_CA_TIPO_CTA_B)
                .append(LEFT_JOIN_H2H_CTA_INFO_CC_ON_R_CNTA_CARG_CC_NUME_CTA_AND_CC_TIPO_CTA_O)
                .append(" LEFT JOIN H2H_CAT_DIVISA  CATDIV ON CATDIV.ID_CAT_DIVISA=CC.ID_CAT_DIVISA ");
        agregaIdReg(listIds, sql);
        sql.append(UNION_ALL)
                .append(SELECT_R_ID_REG)
                .append(CNTR_NUM_CNTR_CONTRATO)
                .append(R_CNTA_CARG_NUM_CTA_CARGO)
                .append(R_CNTA_ABON_NUN_CTA_ABONO)
                .append(CT_DESC_PROD)
                .append(R_MONT_IMPORTE)
                .append("  NULL REFERENCIA,     ")
                .append(" CATDIV.CLAV_CAPTA DIVISA, ")
                .append(CE_DESC_ESTATUS)
                .append(TO_CHAR_ABT_FECH_RESP_BE_FECH_APLI)
                .append("  ca.NOMB_TITU BENEFICIARIO,       ")
                .append(NULL_TOPO_PAGO)
                .append("  cc.NOMB_TITU TITULAR,  ")
                .append("  tdc.OBSER_ABO CONCEPTO_PAGO,      ")
                .append(NULL_CLAVE_RASTREO)
                .append(NULL_BANCO_RECEPTOR)
                .append(R_FECH_ENVI_BACK_FECHA_OPERACION)
                .append(NULL_CLAV_PROV)
                .append(NULL_NUM_DOCU)
                .append(NULL_FECH_VENCIMIENTO)
                .append(NULL_CVE_FORM_PAGO)
                .append(NULL_ESTATUS_MOV)
                .append(NULL_NUM_ORDEN)
                .append(NULL_FECHA_LIMITE_PAGO)
                .append("  NULL NUM_SUCURSAL,  ")
                .append("  clte.RAZON_SCIA,    ")
                .append(CLTE_NOMBRE_CLTE_APPATERNO_CLTE_APMATERNO_NOM_CLTE)
                .append("  clte.PERSONALIDAD,  ")
                .append("  clte.RFC,   ")
                .append(CNTR_NUM_CNTR)
                .append("  NULL CLAVE_BENEF,  ")
                .append(NULL_ID_ESTA)
                .append(NULL_AS_PERS_AUT)
                .append(NULL_AS_FORM_APLI)
                .append(NULL_NOMB_RAZON_SOCI_PROV)
                .append(NULL_RFC_PROV)
                .append(NULL_BANC_ABON)
                .append(NULL_REFE_ABON)
                .append(NULL_TIPO_DOCU)
                .append(" FROM H2H_MX_PROD_PAGO_TDC_TRAN tdc ")
                .append(" INNER JOIN H2H_REG_TRAN r ON r.id_reg = tdc.id_reg       ")
                .append(INNER_JOIN_H2H_CAT_PROD_CT_ON_R_CVE_PROD_OPER_CT_CVE_PRODOPER)
                .append(" INNER JOIN H2H_ARCHIVO_TRAN a ON r.id_arch = a.id_archivo")
                .append(LEFT_JOIN_H2H_ARCH_BACK_TRAN_ABT_ON_R_ID_ARCHBE_ABT_ID_ARCH_BAK)
                .append(" INNER JOIN H2H_CNTR cntr ON cntr.id_cntr = a.id_cntr     ")
                .append(" INNER JOIN H2H_CLTE clte ON cntr.id_clte = clte.id_clte  ")
                .append(INNER_JOIN_H2H_CAT_ESTATUS_CE_ON_R_ID_ESTATUS_ID_CATESTATUS)
                .append(LEFT_JOIN_H2H_CTA_INFO_CA_ON_R_CNTA_ABON_CA_NUME_CTA_AND_CA_TIPO_CTA_B)
                .append(LEFT_JOIN_H2H_CTA_INFO_CC_ON_R_CNTA_CARG_CC_NUME_CTA_AND_CC_TIPO_CTA_O)
                .append(" LEFT JOIN H2H_CAT_DIVISA  CATDIV ON CATDIV.ID_CAT_DIVISA=CC.ID_CAT_DIVISA ");
        agregaIdReg(listIds, sql);
        return sql.toString();
    }

    /**
     * Obtiene el query de Pago a TDC Santander.
     *
     * @param listIds
     *            List<Integer>
     * @return String
     */
    protected static String obtenerQueryPagoImpAduan(List<Integer> listIds) {
        final StringBuilder sql = new StringBuilder()
                .append(" SELECT r.id_reg, ")
                .append("     cntr.num_cntr contrato, ")
                .append("     TO_CHAR(r.cnta_carg) num_cta_cargo, ")
                .append("    hpp.linea_captura nun_cta_abono, ")
                .append("    ct.desc_prod desc_prod, ")
                .append("     hpp.importe, ")
                .append("     NULL referencia, ")
                .append("     NULL divisa, ")
                .append("     ce.desc_estatus desc_estatus, ")
                .append("     TO_CHAR(hpp.fecha_pago,'DD-MM-YYYY') fech_apli, ")/*fecha_pago antes*/
                .append("      null beneficiario, ")
                .append("      null tipo_pago, ")
                .append("      null titular, ")
                .append("      null concepto_pago, ")
                .append("      null clave_rastreo, ")
                .append("      null banco_receptor, ")
                .append("      null fecha_operacion, ")
                .append("      hpp.cve_prod_oper clav_prov, ")
                .append("     null num_docu, ")
                .append("     null fech_vencimiento,  ")
                .append("     null cve_form_pago, ")
                .append("    '-' ")
                .append("      || TRIM(hpp.cve_prod_oper) ")
                .append("      || '-' estatus_mov,     NULL num_orden,  NULL fecha_limite_pago, NULL num_sucursal, null razon_scia, NULL nom_clte,  clte.personalidad,   clte.rfc, ")
                .append("     cntr.num_cntr,   hpp.patente clave_benef,     null id_esta,      hpp.pedimento pers_aut,    hpp.aduana form_apli, ")
                .append("     TO_CHAR(hpp.hora_pago,'HH24:mi')  nomb_razon_soci_prov,  ")/*hora_pago*/
                .append("     hpp.num_ope_banc rfc_prov,   hpp.num_transacc banc_abon,  hpp.medio_present refe_abon, ")
                .append("     hpp.medio_cobro tipo_docu ")
                .append(" FROM ")
                .append("     h2h_mx_prod_pece hpp ")
                .append("     INNER JOIN h2h_reg r ON r.id_reg = hpp.id_reg ")
                .append("     INNER JOIN h2h_cat_prod ct ON r.cve_prod_oper = ct.cve_prod_oper ")
                .append("     INNER JOIN h2h_archivo a ON r.id_arch = a.id_archivo ")
                .append("     INNER JOIN h2h_cntr cntr ON cntr.id_cntr = a.id_cntr ")
                .append("     INNER JOIN h2h_clte clte ON cntr.id_clte = clte.id_clte ")
                .append("     LEFT JOIN h2h_cat_estatus ce ON ce.id_cat_estatus = r.id_estatus ");
        agregaIdReg(listIds, sql);
        sql.append(UNION_ALL)
                .append(" SELECT r.id_reg, ")
                .append("     cntr.num_cntr contrato, ")
                .append("     TO_CHAR(r.cnta_carg) num_cta_cargo, ")
                .append("    hpp.linea_captura nun_cta_abono, ")
                .append("    ct.desc_prod desc_prod, ")
                .append("     hpp.importe, ")
                .append("     NULL referencia, ")
                .append("     NULL divisa, ")
                .append("     ce.desc_estatus desc_estatus, ")
                .append("     TO_CHAR(hpp.fecha_pago,'DD-MM-YYYY') fech_apli, ")/*fecha_pago antes*/
                .append("      null beneficiario, ")
                .append("      null tipo_pago, ")
                .append("      null titular, ")
                .append("      null concepto_pago, ")
                .append("      null clave_rastreo, ")
                .append("      null banco_receptor, ")
                .append("      null fecha_operacion, ")
                .append("      hpp.cve_prod_oper clav_prov, ")
                .append("     null num_docu, ")
                .append("     null fech_vencimiento,  ")
                .append("     null cve_form_pago, ")
                .append("    '-' ")
                .append("      || TRIM(hpp.cve_prod_oper) ")
                .append("      || '-' estatus_mov, ")
                .append("       NULL num_orden, ")
                .append("     NULL fecha_limite_pago, ")
                .append("     NULL num_sucursal, ")
                .append("     null razon_scia, ")
                .append("     NULL nom_clte,  clte.personalidad, clte.rfc,  cntr.num_cntr,     hpp.patente clave_benef,   null id_esta,    hpp.pedimento pers_aut,    hpp.aduana form_apli, ")
                .append("     TO_CHAR(hpp.hora_pago,'HH24:mi')  nomb_razon_soci_prov,  ")/*hora_pago*/
                .append("     hpp.num_ope_banc rfc_prov,      hpp.num_transacc banc_abon,     hpp.medio_present refe_abon,     hpp.medio_cobro tipo_docu ")
                .append(" FROM ")
                .append("     H2H_MX_PROD_PECE_TRAN hpp ")
                .append("     INNER JOIN H2H_REG_TRAN r ON r.id_reg = hpp.id_reg ")
                .append("     INNER JOIN h2h_cat_prod ct ON r.cve_prod_oper = ct.cve_prod_oper ")
                .append("     INNER JOIN h2h_archivo_tran a ON r.id_arch = a.id_archivo ")
                .append("     INNER JOIN h2h_cntr cntr ON cntr.id_cntr = a.id_cntr ")
                .append("     INNER JOIN h2h_clte clte ON cntr.id_clte = clte.id_clte ")
                .append("     LEFT JOIN h2h_cat_estatus ce ON ce.id_cat_estatus = r.id_estatus ");
        agregaIdReg(listIds, sql);
        return sql.toString();
    }

}
