package mx.santander.h2h.monitoreo.util;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.repository.IMotivoRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailAporPatrRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailDomisRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailImpFedRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailMttoProvRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailOrdPagAtmRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailPagDirectRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailPagImpAduanRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailPagRefRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailSpidRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailTransInterMbcRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailTransInterRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailVostroRepository;
import mx.santander.h2h.monitoreo.repository.IParameterRepository;

@Slf4j
@Component
public class OperationsMonitorUtil {

    @Autowired
    private IOperationsDetailRepository detailRepository;

    @Autowired
    private IOperationsDetailDomisRepository detailDomisRepository;

    @Autowired
    private IOperationsDetailMttoProvRepository detailMttoProvRepository;

    @Autowired
    private IOperationsDetailImpFedRepository detailImpFedRepository;

    @Autowired
    private IOperationsDetailPagRefRepository detailPagRefRepository;

    @Autowired
    private IOperationsDetailAporPatrRepository detailAporPatrRepository;

    @Autowired
    private IParameterRepository parameterRepository;

    @Autowired
    private IOperationsDetailTransInterRepository detailTransInterRepository;

    @Autowired
    private IOperationsDetailSpidRepository operationsDetailSpidRepository;

    @Autowired
    private IOperationsDetailPagDirectRepository operationsDetailPagDirectRepository;

    @Autowired
    private IOperationsDetailVostroRepository operationsDetailVostroRepository;

    @Autowired
    private IOperationsDetailOrdPagAtmRepository operationsDetailOrdPagAtmRepository;

    @Autowired
    private IOperationsDetailPagImpAduanRepository operationsDetailPagImpAduanRepository;

    @Autowired
    private IOperationsDetailTransInterMbcRepository operationsDetailTransInterMbcRepository;

    @Autowired
    private IMotivoRepository motivoRepository;

    public OperationsMonitorQueryResponse obtenerDetalleOperacion(String view, String idOperacion) {

        OperationsMonitorQueryResponse operationsMonitorQueryResponse;
        if ("29".equals(view)) {
            operationsMonitorQueryResponse =  detailDomisRepository.obtenerDetalleOperacion(idOperacion, "H2H_PROD_DOMI_CXH");
        }else if ("30".equals(view) || view.equals(parameterRepository.findByName("CVE_OPER_PROD_DOMIS").getValue())) {
            operationsMonitorQueryResponse =  detailDomisRepository.obtenerDetalleOperacion(idOperacion, "H2H_PROD_DOMI");
        } else if (view.equals(parameterRepository.findByName("CVE_OPER_PROD_MT_CNF").getValue())) {
            operationsMonitorQueryResponse =  detailMttoProvRepository.obtenerDetalleOperacion(view, idOperacion);
        } else if (view.equals(parameterRepository.findByName("CVE_OPER_PROD_I_FED").getValue())){
            operationsMonitorQueryResponse =  detailImpFedRepository.obtenerDetalleOperacion(idOperacion);
        } else if (view.equals(parameterRepository.findByName("CVE_OPER_PROD_P_REF").getValue())) {
            operationsMonitorQueryResponse =  detailPagRefRepository.obtenerDetalleOperacion(idOperacion);
        } else if (view.equals(parameterRepository.findByName("CVE_OPER_PROD_A_PATR").getValue())) {
            operationsMonitorQueryResponse =  detailAporPatrRepository.obtenerDetalleOperacion(idOperacion);
        } else if (view.equals(parameterRepository.findByName("CVE_OP_PROD_TRAN_INT").getValue())) {
            operationsMonitorQueryResponse =  detailTransInterRepository.obtenerDetalleOperacion(idOperacion);
        } else if (view.equals(parameterRepository.findByName("CVE_OP_PROD_TRAN_MMB").getValue())) {
            operationsMonitorQueryResponse =  operationsDetailTransInterMbcRepository.obtenerDetalleOperacion(idOperacion);
        } else if (view.equals(parameterRepository.findByName("CVE_OP_PROD_SPID").getValue())) {
            operationsMonitorQueryResponse =  operationsDetailSpidRepository.obtenerDetalleOperacion(idOperacion);
        } else if (view.equals(parameterRepository.findByName("CVE_PROD_PAG_DIRE").getValue())) {
            operationsMonitorQueryResponse =  operationsDetailPagDirectRepository.obtenerDetalleOperacion(view, idOperacion);
        } else if (validaOperacionesVostro(view)) {
            operationsMonitorQueryResponse =  operationsDetailVostroRepository.obtenerDetalleOperacion(view, idOperacion);
        } else if ("85".equals(view)) {
            operationsMonitorQueryResponse =  operationsDetailOrdPagAtmRepository.obtenerDetalleOperacion(view, idOperacion);
        } else if ("25".equals(view)) {
            log.info("EL PRODUCTO ES IMPUESTOS ADUANALES");
            operationsMonitorQueryResponse =  operationsDetailPagImpAduanRepository.obtenerDetalleOperacion(view, idOperacion);
        } else {
            operationsMonitorQueryResponse =  detailRepository.obtenerDetalleOperacion(view, idOperacion);
        }

        String motivo = motivoRepository.consultaMotivoOperacion(idOperacion);

        StringBuilder sb = new StringBuilder();
        String msj = operationsMonitorQueryResponse.getMensaje() ;
        sb.append(Objects.toString(msj, ""));
        sb.append(" ");
        sb.append(motivo);
        operationsMonitorQueryResponse.setMensaje(sb.toString().trim());

        StringBuilder sbMensajeOrden = new StringBuilder();
        String msjOrden = operationsMonitorQueryResponse.getMensajeOrden() ;
        sbMensajeOrden.append(Objects.toString(msjOrden, ""));
        sbMensajeOrden.append(" ");
        sbMensajeOrden.append(motivo);
        operationsMonitorQueryResponse.setMensajeOrden(sbMensajeOrden.toString().trim());

        // Enmascaramos la tarjeta
        if( operationsMonitorQueryResponse != null ) {
        	// Tarjetas
        	operationsMonitorQueryResponse.setNumTarjeta(
        		UtilMapeoData.getMascara(operationsMonitorQueryResponse.getNumTarjeta(), "tarjeta")
        	);
        	operationsMonitorQueryResponse.setNumTarjetaAct(
        		UtilMapeoData.getMascara(operationsMonitorQueryResponse.getNumTarjetaAct(), "tarjeta")
        	);
        	// Cuentas
        	operationsMonitorQueryResponse.setCtaAbono(
        		UtilMapeoData.getMascara(operationsMonitorQueryResponse.getCtaAbono(), "abono")
        	);
        }
        
        return operationsMonitorQueryResponse;
    }
    
    
    private boolean validaOperacionesVostro(String view) {
        return view.equals((parameterRepository.findByName("CVE_PROD_TRANINTCAMB").getValue()))
                || view.equals((parameterRepository.findByName("CVE_PROD_VOSTRO_INT").getValue()))
                || view.equals((parameterRepository.findByName("CVE_PROD_VOSTRO_MB").getValue()));
    }

}
