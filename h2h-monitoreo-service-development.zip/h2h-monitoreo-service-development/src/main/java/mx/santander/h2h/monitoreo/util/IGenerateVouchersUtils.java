package mx.santander.h2h.monitoreo.util;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersControllerResponse;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersDtoResponse;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperReport;

public interface IGenerateVouchersUtils {

	GenerateVouchersControllerResponse findOperations(OperationsMonitorQueryRequest operationsMonitorQueryRequest,
			GenerateVouchersControllerResponse findVouchersCdmx,
			GenerateVouchersDtoResponse generateVouchersDtoResponse) throws NumberFormatException;

	GenerateVouchersControllerResponse findOperationsMonitor(
			OperationsMonitorQueryRequest operationsMonitorQueryRequest,
			GenerateVouchersControllerResponse findVouchersCdmx);

	JasperReport generateJR(InputStream streamSubreport) throws JRException;

	Map<String, String> getTypeReport(String xlsxExtention);

	ReportResponse getReportePdfOrXlsx(String xlsxExtention, String jasperName, Map<String, Object> mapParams,
			List<?> dataList);

	ReportResponse exportarOperacionesXlsx(OperationsMonitorQueryRequest operationsMonitorQueryRequest,
			String xlsxExtention);

}
