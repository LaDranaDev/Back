package mx.santander.h2h.monitoreo.model.response;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 * Clase con los totales del conteo de archivos.
 *
 * @author Daniel Ruiz
 * @since 19/04/2023
 */
@Getter
@Setter
public class ArchivoConteoResponse implements Serializable {

    /** Serial de la clase. */
    private static final long serialVersionUID = -926188421858173956L;

    /** Total de archivos recibidos.*/
    private Long totArchRecib;

    /** Total de operaciones recibidas.*/
    private Long totOpeRecib;

    /** Total del monto recibido. */
    private BigDecimal totMontoRecib;

    /** Nombre del cliente. */
    private String cliente;

    /** Codigo del cliente. */
    private String codCliente;

    /** Archivos con alerta. */
    private Long totAlerta;

    /** Archivos en duplicado. */
    private Long totDupl;

    /** Archivos en espera. */
    private Long totEsp;

    /** Archivos en proceso. */
    private Long totEnProc;

    /** Archivos en enrollment. */
    private Long totEnroll;

    /** Archivos procesados. */
    private Long totProc;

    /** Archivos programados. */
    private Long totProg;

    /** Archivos rechazados. */
    private Long totRecha;

    /** Archivos recibidos. */
    private Long totRecib;

    /** Archivos validados. */
    private Long totVald;

    /** Detalle de archivos. */
    private List<ArchivoConteoResponse> detalle;

}
