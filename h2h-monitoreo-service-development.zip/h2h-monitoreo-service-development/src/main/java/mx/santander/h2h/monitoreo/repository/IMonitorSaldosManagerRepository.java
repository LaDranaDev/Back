package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.request.MonitorSaldosRequest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import jakarta.persistence.Tuple;
import java.util.List;

/**
 * IMonitorSaldosManagerRepository.
 * Implementan los metodos que permiten ejecutar las consultas del Monitor de Saldos.
 *
 * @author Jesus Soto Aguilar
 * @since 20/04/2023
 */
public interface IMonitorSaldosManagerRepository {

    /**
     * Consulta la informacion de los saldos reintentos.
     * @param request Objeto con los filtros para la consulta
     * @return Lista con la informacion de los saldos reintentos
     */
    List<Tuple> getSaldosReintentosCliente(MonitorSaldosRequest request);


    /**
     * Consulta la informacion de los saldos reintentos de forma paginada.
     * @param request Objeto con los filtros para la consulta
     * @param pagination Objeto con los datos de paginacion
     * @return Pagina con informacion de los saldos reintentos
     */
    Page<Tuple> getSaldosReintentosClientePaged(MonitorSaldosRequest request, Pageable pagination);
}
