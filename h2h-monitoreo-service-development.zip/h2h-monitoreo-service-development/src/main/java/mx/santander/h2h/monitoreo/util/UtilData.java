/**
* Santander SCIB - Banco Santander Negocios Globales
* Todos los derechos reservados
* UtilData.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <12 jul. 2024 19:17:07>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.util;

import java.math.BigDecimal;

import lombok.extern.slf4j.Slf4j;

/**
 * Clase generada para utilerias de Datos.
 *
 * @autor C320868
 * @modifico C320868
 */
@Slf4j
public class UtilData {
	
	/**
	 * Metodo para validar un objeto y obtener su contenido.
	 *
	 * @param obj para obj
	 * @return el string
	 */
	public static String toString(Object obj) {
		String cadResp = "";
		if( obj != null) {
			cadResp = obj.toString();
		}
		return cadResp;
	}
	
	
	/**
	 * Metodo para obtener la longitud de un Objeto.
	 *
	 * @param obj para obj
	 * @return el string
	 */
	public static int getLen(Object obj) {
		String cadResp = toString(obj);
		return cadResp.length();
	}
	
	/**
	 * Val int.
	 *
	 * @param obj para obj
	 * @return el int
	 */
	public static int toInt(Object obj) {
		String cadResp = toString( obj );
		int valInt = 0;
		if( !"".equals(cadResp) ) {
			try {
				valInt = Integer.parseInt( cadResp );
			} catch(NumberFormatException e) {
				valInt = 0;
				log.error("Error al convertir dato a Entero: "+ cadResp);
			}
		}
		return valInt;
	}
	
	
	/**
	 * Val double.
	 *
	 * @param obj para obj
	 * @return el double
	 */
	public static Double toDouble(Object obj) {
		String cadResp = toString( obj );
		Double valDouble = 0.0;
		
		if( !"".equals(cadResp) ) {
			try {
				valDouble = Double.parseDouble( cadResp );
			} catch(NumberFormatException e) {
				log.error("Error al convertir dato a BigDecimal: "+ cadResp);
			}
		}
		return valDouble;
	}
	
	
	/**
	 * Val long.
	 *
	 * @param obj para obj
	 * @return el long
	 */
	public static Long toLong(Object obj) {
		String cadResp = toString( obj );
		Long valLong = 0L;
		if( !"".equals(cadResp) ) {
			try {
				valLong = Long.parseLong( cadResp );
			} catch(NumberFormatException e) {
				log.error("Error al convertir dato a BigDecimal: "+ cadResp);
			}
		}
		return valLong;
	}


	/**
	 * Val big decimal.
	 *
	 * @param obj para obj
	 * @return el big decimal
	 */
	public static BigDecimal toBigDecimal(Object obj) {
		String cadResp = toString( obj );
		BigDecimal valBig = BigDecimal.valueOf( Double.parseDouble("0.0") );
		if( !"".equals(cadResp) ) {
			try {
				valBig = new BigDecimal( cadResp );
			} catch(NumberFormatException e) {
				log.error("Error al convertir dato a BigDecimal: "+ cadResp);
			}
		}
		return valBig;
	}


	/**
	 * Metodo para validar si un objeto si esta vacio o nulo
	 * 
	 * @param obj
	 * @return
	 */
	public static boolean isVacio(Object obj) {
		boolean respFnc = true;
		if( obj != null && !"".equals(obj.toString() ) ) {
			respFnc = false;
		}
		return respFnc;
	}
	
	
	/**
	 * Metodo para validar si dos cadenas son iguales
	 * 
	 * @param obj
	 * @param cadena
	 * @return
	 */
	public static boolean esIgual(Object obj, String cadena) {
		boolean esIgual = false;
		boolean esVacio = isVacio(obj);
		if(!esVacio) {
			// Validamos que los componentes tengan los mismos datos
			if( cadena.equalsIgnoreCase(obj.toString() ) ) {
				esIgual = true;
			}
		}
		return esIgual;
	}
	
	
	/**
	 * Verifica si el producto es Pagos de impuestos federales,
	 *
	 * @param consultaOperaciones parametros de la consulta operaciones
	 * @return boolean valor del tipo de prodcuto
	 */
	public static boolean isPif(String idProducto) {
		return "21".equals(idProducto) 
				|| "22".equals(idProducto)
				|| "23".equals(idProducto);
	}
	
	
	/**
	 * Verifica si el producto es Pago Directo
	 * 
	 * @param consultaOperaciones parametros de la consulta operaciones
	 * @return boolean valor del tipo de producto
	 */
	public static boolean isPagoDirecto(String idProducto) { // PGODIRECT
		return "40".equals(idProducto);
	}
}
