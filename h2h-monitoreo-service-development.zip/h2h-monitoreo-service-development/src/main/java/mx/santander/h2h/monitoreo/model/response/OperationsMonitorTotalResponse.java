package mx.santander.h2h.monitoreo.model.response;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * Response para mostrar los totales de la consulta de operaciones
 *
 * @author Daniel Ruiz
 * @since 21/04/2023
 */
@Getter
@Setter
public class OperationsMonitorTotalResponse implements Serializable {
    /** Serial id */
    private static final long serialVersionUID = -5556933585507298640L;
    /** Total de correos enviados */
    private long correosEnv;
    /** Total de archivos */
    private long archivos;
    /** ImporteGlobal */
    private double importeGlobal;
    /** Limite de operaciones a exportar */
    private String limiteOperaciones;
}
