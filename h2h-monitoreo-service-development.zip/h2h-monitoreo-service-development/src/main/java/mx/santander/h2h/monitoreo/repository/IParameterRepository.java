package mx.santander.h2h.monitoreo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import mx.santander.h2h.monitoreo.model.entity.ParameterEntity;

/**
 * Repositorio para los parametros.
 *
 * @author Felipe Monzon
 * @since 09/05/2022
 */
public interface IParameterRepository extends JpaRepository<ParameterEntity, Integer> {
	/**
	 * Consulta un parametro s por su nombre.
	 * 
	 * @param name nombre del parametro
	 * @return datos del parametro encontrado
	 */
	ParameterEntity findByName(String name);
	
	/**
	 * Contrato para obtener el ultimo registro insertado
	 * 
	 * @return Optional<ParameterEntity> registro del catalogo
	 */
	Optional<ParameterEntity> findTopByOrderByIdDesc();
}
