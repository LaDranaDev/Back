package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class NivelGeneralResponse implements Serializable {
	
	/**
	 * Serial version UID 
	 */
	private static final long serialVersionUID = -2965234272563335220L;

	private String fecha;
	
	private ArchivoResponse beanArchivo;
	
	private ArchivoResponse beanArchivoDetalle;
	
	private List<ArchivoResponse> listBeanArchivo;
	
	private String codCliente;
	
}
