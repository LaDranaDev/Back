package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Dto para los datos de respuesta de los protocoloes de conexion del contrato
 * 
 * @author Z483900
 *
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ContractConnectionProtocolsResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4954363168557246159L;

	/** Propiedades para consulta de parámetros */

	/**
	 * codClienteP
	 */
	private String codClienteP;

	/**
	 * idContratoP
	 */
	private String idContratoP;

	/**
	 * Objeto de lista respuestaProt
	 */
	private List<ProtocolResponse> respuestaProt;

	/**
	 * Objeto de lista parametros
	 */
	private List<String> parametros;

	/**
	 * nombreProtocolo
	 */
	private String nombreProtocolo;

	/** Propidades de editar parámetros */

	/**
	 * idProt
	 */
	private Integer idProt;

	/**
	 * idRegistro
	 */
	private String idRegistro;

	/**
	 * Objeto de lista parametrosGetProt
	 */
	private List<ParametersGetPutResponse> parametrosGet;

	/**
	 * Objeto de lista parametrosPutProt
	 */
	private List<ParametersGetPutResponse> parametrosPut;

	/**
	 * codigoOp
	 */
	private String codigoOp;

	/**
	 * estadoValor
	 */
	private String estadoValor;

}
