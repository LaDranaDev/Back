package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Clase encargada de definir los datos de entrada de notificaciones
 * 
 * @author emendoza
 * @since 12/04/2023
 */
@Getter
@Setter
@NoArgsConstructor
@ToString
public class MonitorDeArchivosEnCursoDetallesOperacionResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Identificador de idArchivo
	 */
	private String idReg;
	/**
	 * Identificador de numContrato
	 */
	private String cveRasteroSpei;
	/**
	 * Identificador de nombreArch
	 */
	private String fechaApli;
	/***
	 * Identificador de fechaOrder
	 */
	private String descEstatus;
	/***
	 * Identificador de fechaRegistro 
	 */
	private String descProd;
	/***
	 * Identificador de idEstatus
	 */
	private BigDecimal importe;
	/***
	 * Identificador de descEstatus
	 */
	private String ctaBen;
	/***
	 * Identificador de idProd
	 */
	private String ctaOrd;
	/***
	 * Identificador de idClte  
	 */
	private String umbr;
	/***
	 * Identificador de cliente 
	 */
	private String fechaEnvBe;
	/***
	 * Identificador de razonScia 
	 */
	private String fechaRespBe;
	

	@JsonIgnore
	private String cveProdOper;
}
