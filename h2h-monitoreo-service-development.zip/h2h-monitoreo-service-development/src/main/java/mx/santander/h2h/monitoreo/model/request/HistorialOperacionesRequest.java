package mx.santander.h2h.monitoreo.model.request;

import java.io.Serializable;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

/**
 * --------------------------------
 * Request oara obtener
 * el historial de las operaciones
 * --------------------------------
 */
@Getter
@Setter
public class HistorialOperacionesRequest implements Serializable {

	/**
	 * Serial UID
	 */
	private static final long serialVersionUID = -1168087727017315317L;

	/**
	 * Id de operacion
	 */
	private String idOperacion;
	
	/**
	 * Usuario de la sesion
	 */
    @Size(min = 0, max = 12, message = "El user debe tener máximo 12 dígitos")
    @Pattern(regexp = "(^[a-zA-Z0-9]+$)?",  message = "Solo se permiten caracteres numéricos")
    private String user;
}
