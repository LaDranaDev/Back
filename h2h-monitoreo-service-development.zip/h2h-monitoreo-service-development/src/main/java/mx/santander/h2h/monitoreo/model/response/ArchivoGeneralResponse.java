package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;

import org.springframework.data.domain.Page;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class ArchivoGeneralResponse implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6675098560258723203L;

	private Page<ArchivoResponse> detalleArchivo;
	
	private SubtotalResponse subtotal;
}
