package mx.santander.h2h.monitoreo.repository;

import java.util.List;

import mx.santander.h2h.monitoreo.model.response.MonitorDeArchivosEnCursoDetallesOperacionResponse;
import mx.santander.h2h.monitoreo.model.response.ResultTrackingResponse;

/**
 * EntityManager para el Tracking de Archivos
 *
 * @author Daniel Ruiz
 * @since 19/04/2023
 */
public interface IMonitorArchivosEnCursoNivelOperacionRepository {

	/**
	 * Obtiene el detalle del archivo de acuerdo al estatus
	 * @param fecha LocalDate
	 * @param codCliente String
	 * @param codEstatus String
	 * @param nomArch String
	 * @return Lista con los beans de resultado
	 */
	List<MonitorDeArchivosEnCursoDetallesOperacionResponse> ejecutaBusquedaNivelOperacion(String idArchivo, Integer idProducto, Integer idEstatus);

	/**
	 * Obtiene el detalle del archivo de acuerdo al estatus
	 * @param fecha LocalDate
	 * @param codCliente String
	 * @param codEstatus String
	 * @param nomArch String
	 * @return Lista con los beans de resultado
	 */
	List<MonitorDeArchivosEnCursoDetallesOperacionResponse> ejecutaBusquedaNivelOperacionHistorica(String idReg);

	ResultTrackingResponse obtenerCatalogoProductos();

	ResultTrackingResponse obtenerCatalogoEstatus();
}
