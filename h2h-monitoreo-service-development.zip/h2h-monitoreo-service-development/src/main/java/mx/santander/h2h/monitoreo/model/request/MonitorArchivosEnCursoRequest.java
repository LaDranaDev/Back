package mx.santander.h2h.monitoreo.model.request;

import java.io.Serializable;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

/**
 * Petition para la information del Archivo y sus productos asociados.
 *
 * @author emendoza
 * @since 19/04/2023
 */
@Getter
@Setter
public class MonitorArchivosEnCursoRequest implements Serializable {

    /** Serial id */
    private static final long serialVersionUID = 7324417559159313067L;

    /** buc (opcional) */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos de BUC no valido")
    @Size(min = 0, max = 15, message = "Datos de BUC erroneo")
    private String buc;
    
    /** Pagina  */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String pagina;
    
    /** tamanio pagina */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String tamanioPagina;
    
    /** Identificador de nombreArch */
    @Pattern(regexp = "(^((([a-z. ])?/.*)|(([a-zA-Z. ]:)?(\\\\([a-zA-Z0-9_. -]+\\\\?)?))?)+(([a-zA-Z0-9_. ]+)(.([.a-zA-Z0-9_. ]))?)+$)?", message = "Archivo No valido")
    private String nombreArch;
	
    /** Fecha de búsqueda (opcional) */
    @Pattern(regexp = "((((\\d{2})|(\\d{4}))([-/])\\d{2}([-/])((\\d{2})|(\\d{4})))( (\\d{2}:\\d{2}:\\d{2})?)?)?", message = "Fecha No Valida")
    @Size(min = 0, max = 20, message = "Fecha erronea")
    private String fechaIni;
    
    /** Fecha de búsqueda (opcional) */
    @Pattern(regexp = "((((\\d{2})|(\\d{4}))([-/])\\d{2}([-/])((\\d{2})|(\\d{4})))( (\\d{2}:\\d{2}:\\d{2})?)?)?", message = "Fecha No Valida")
    @Size(min = 0, max = 20, message = "Fecha erronea")
    private String fechaFin;

    /** Código del cliente */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String codCliente;

    /** Nombre del archivo (opcional) */
    @Pattern(regexp = "(^((([a-z. ])?/.*)|(([a-zA-Z. ]:)?(\\\\([a-zA-Z0-9_.-]+\\\\?)?))?)+(([a-zA-Z0-9. ]+)(.([.a-zA-Z0-9]))?)+$)?", message = "Archivo No valido")
    private String nomArch;

    /** Código de estatus (opcional) */
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
    private String estatus;
    
    /** Numero de contrato (opcional) */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String numContrato;
    
    /** Producto (opcional) */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String idProducto;
    
    /*** Identificador de idEstatus */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String idEstatus;

}
