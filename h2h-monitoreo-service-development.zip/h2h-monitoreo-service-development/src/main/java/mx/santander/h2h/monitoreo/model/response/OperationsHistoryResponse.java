package mx.santander.h2h.monitoreo.model.response;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * Clase para el historial de la operación
 */
@Getter
@Setter
public class OperationsHistoryResponse implements Serializable {
    /** Version serial de la clase */
    private static final long serialVersionUID = 2487780953723545778L;
    /** Estatus */
    private String estatus;
    /** Fecha */
    private String fecha;
    /** Hora */
    private String hora;
    /** ref oper. */
    private String refOper;
}
