package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.Setter;

/**
 * Clase auxiliar para la definicion de estructura del archivo XML de entrada
 */
@XmlRootElement
@Getter
@Setter
public class Parametro implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4641890979519696001L;
	/**
	 * Valor del parametro
	 */
	private String valor;
	/**
	 * Nombre del parametro
	 */
	private String nombre;

	/**
	 * Establece la informacion en nombre
	 *
	 * @param nombre Valor a actualizar en la variable
	 */
	@XmlElement(name = "nombreParametro")
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
}