package mx.santander.h2h.monitoreo.repository;

import java.util.List;

import mx.santander.h2h.monitoreo.model.request.PutGetRequest;
import mx.santander.h2h.monitoreo.model.response.ProtocolResponse;
import mx.santander.h2h.monitoreo.model.response.PutGetDto;
import mx.santander.h2h.monitoreo.model.response.PutGetServiceResponse;

public interface IContractConnectionManagementPutGetEntityManagerRepository {

	PutGetServiceResponse findPutGetFiles(PutGetRequest putGetRequest, Integer opcion);

	void insertPutGetProtocol(PutGetServiceResponse putGetServiceResponse, String numeroContrato);

	void updatePutGetProtocol(PutGetServiceResponse putGetServiceResponse, PutGetRequest putGetRequest);

	List<ProtocolResponse> getPutFilesProtocols();

	PutGetServiceResponse findPutGet(PutGetRequest putGetRequest, Integer option, PutGetServiceResponse putGetServiceResponse);

	String getParameters(String string);

	String enableDisablePutGet(PutGetDto putGetDto);

}
