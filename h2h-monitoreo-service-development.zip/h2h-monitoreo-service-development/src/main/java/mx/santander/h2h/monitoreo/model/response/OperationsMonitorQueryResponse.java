package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.math.BigDecimal;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Response para mostrar el resultado de la consulta de operacioness
 *
 * @author Daniel Ruiz
 * @since 13/04/2023
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
public class OperationsMonitorQueryResponse implements Serializable {

	/** Serial id */
    private static final long serialVersionUID = -929941562818730346L;

    /** ID de operacion */
    @Size(min = 0, max = 15, message = "El id operacion debe tener máximo 15 dígitos")
    @Pattern(regexp = "([0-9 ]+$)?", message = "Solo se permiten caracteres númericos")
    private String idOperacion;

    /** cod cli. */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos de Cliente no valido")
    @Size(min = 0, max = 10, message = "Datos de Cliente erroneo")
    private String codCli;
    
    /** cta cargo. */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Cuenta Cargo no valido")
    private String ctaCargo;
    
    /** cta abono. */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Cuenta Abono no valido")
    private String ctaAbono;
    
    /** num orden. */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Num Orden no valido")
    private String numOrden;
    
    /** producto. */
    @Pattern(regexp = "(^[a-zA-Z0-9 _-]+$)?", message = "Datos no validos")
    private String producto;
    
    /** nom arch. */
    @Pattern(regexp = "(^((([a-z])?/.*)|(([a-zA-Z]:)?(\\\\([a-zA-Z0-9_.-]+\\\\?)?))?)+(([a-zA-Z0-9]+)(.([.a-zA-Z0-9]))?)+$)?", message = "Archivo No valido")
    private String nomArch;
    
    /** referencia. */
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
    private String referencia;
    
    /** importe. */
    @Pattern(regexp = "(^(([$])?)\\d((,)?)((.)?)+$)?", message = "Importe no valido")
    private String importe;
    
    /** fecha captura. */
    @Pattern(regexp = "(((\\d{2})|(\\d{4}))([-/])\\d{2}([-/])((\\d{2})|(\\d{4})))( (\\d{2}:\\d{2}:\\d{2})?)?", message = "Fecha No Valida")
    @Size(min = 0, max = 20, message = "Fecha erronea")
    private String fechaCaptura;
    
    /** interm ord. */
    @Pattern(regexp = "(^[a-zA-Z0-9 _-]+$)?", message = "Datos no validos")
    private String intermOrd;
    
    /** divisa **/
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
    private String divisa;
    
    /** divisa ord. */
    @Pattern(regexp = "(^[A-Za-z ]+$)?", message = "Datos no validos")
    private String divisaOrd;
    
    /** importe cargo. */
    @Pattern(regexp = "(^(([$])?)\\d((,)?)((.)?)+$)?", message = "Importe no valido")
    private String importeCargo;
    
    /** interm rec. */
    @Pattern(regexp = "(^[a-zA-Z0-9 _-]+$)?", message = "Datos no validos")
    private String intermRec;
    
    /** nombre benef. */
    @Pattern(regexp = "(^[0-9A-Za-zñÑáéíóúÁÉÍÓÚ ]+$)?", message = "Datos no validos")
    @Size(min = 0, max = 120, message = "Datos erroneos")
    private String nombreBenef;

    /** comentario1. */
    @Pattern(regexp = "(^[0-9A-Za-zñÑáéíóúÁÉÍÓÚ ]+$)?", message = "Datos no validos")
    @Size(min = 0, max = 120, message = "Datos erroneos")
    private String comentario1;
    
    /** comentario2. */
    @Pattern(regexp = "(^[0-9A-Za-zñÑáéíóúÁÉÍÓÚ ]+$)?", message = "Datos no validos")
    @Size(min = 0, max = 120, message = "Datos erroneos")
    private String comentario2;
    
    /** comentario3. */
    @Pattern(regexp = "(^[0-9A-Za-zñÑáéíóúÁÉÍÓÚ ]+$)?", message = "Datos no validos")
    @Size(min = 0, max = 120, message = "Datos erroneos")
    private String comentario3;
    
    /** tipo pago. */
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
    private String tipoPago;
    
    /** modalidad. */
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
    private String modalidad;
    
    /** estatus. */
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
    private String estatus;
    
    /** fecha pres ini. */
    @Pattern(regexp = "(((\\d{2})|(\\d{4}))([-/])\\d{2}([-/])((\\d{2})|(\\d{4})))( (\\d{2}:\\d{2}:\\d{2})?)?", message = "Fecha No Valida")
    @Size(min = 0, max = 20, message = "Fecha erronea")
    private String fechaPresIni;
    
    /** fecha aplic. */
    @Pattern(regexp = "(((\\d{2})|(\\d{4}))([-/])\\d{2}([-/])((\\d{2})|(\\d{4})))( (\\d{2}:\\d{2}:\\d{2})?)?", message = "Fecha No Valida")
    @Size(min = 0, max = 20, message = "Fecha erronea")
    private String fechaAplic;
    
    /** fecha limit pago. */
    @Pattern(regexp = "(((\\d{2})|(\\d{4}))([-/])\\d{2}([-/])((\\d{2})|(\\d{4})))( (\\d{2}:\\d{2}:\\d{2})?)?", message = "Fecha No Valida")
    @Size(min = 0, max = 20, message = "Fecha erronea")
    private String fechaLimitPago;
    
    /** fecha oper. */
    @Pattern(regexp = "(((\\d{2})|(\\d{4}))([-/])\\d{2}([-/])((\\d{2})|(\\d{4})))( (\\d{2}:\\d{2}:\\d{2})?)?", message = "Fecha No Valida")
    @Size(min = 0, max = 20, message = "Fecha erronea")
    private String fechaOper;
    
    /** Numero de sucursal */
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
    private String numSucursal;
    
    /** Banco Ordenante **/
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
    private String bancoOrdenante;
    
    /** Banco Receptor **/
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
    private String bancoReceptor;
    
    /** Mensaje **/
    @Pattern(regexp = "(^[0-9A-Za-zñÑáéíóúÁÉÍÓÚ ]+$)?", message = "Datos no validos")
    @Size(min = 0, max = 120, message = "Datos erroneos")
    private String mensaje;
    
    /** Mensaje Orden de Pago **/
    @Pattern(regexp = "(^[0-9A-Za-zñÑáéíóúÁÉÍÓÚ ]+$)?", message = "Datos no validos")
    @Size(min = 0, max = 120, message = "Datos erroneos")
    private String mensajeOrden;
    
    /** id del estatus */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String idEstatus;
    
    /** id del producto */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String idProducto;
    
    /** Variable para guardar la vista del producto. */
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
    private String vistProd;
    
    /** Variable para guardar la tabla de origen del producto. */
    @Pattern(regexp = "(^[a-zA-Z0-9 _-]+$)?", message = "Datos no validos")
    private String tabla;
    
    /** Nombre ord */
    @Pattern(regexp = "(^[a-zA-Z0-9 _-]+$)?", message = "Datos no validos")
    private String nombreOrd;
    
    /** Fecha de vencimiento. */
    @Pattern(regexp = "(((\\d{2})|(\\d{4}))([-/])\\d{2}([-/])((\\d{2})|(\\d{4})))( (\\d{2}:\\d{2}:\\d{2})?)?", message = "Fecha No Valida")
    @Size(min = 0, max = 20, message = "Fecha erronea")
    private String fechaVenc;
    
    /** Referencia Abono */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String referenciaAbono;
    
    /** Referencia Cargo */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String referenciaCargo;
    
    /** Canal del archivo.*/
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
    private String canal;
    
    /** Numero Empleado */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String numEmpleado;
    
    /** BUC empleado **/
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String bucEmpleado;
    
    /** Nombre Empleado */
    @Pattern(regexp = "(^[0-9A-Za-zñÑáéíóúÁÉÍÓÚ ]+$)?", message = "Datos no validos")
    @Size(min = 0, max = 120, message = "Datos erroneos")
    private String nombreEmpleado;
    
    /** Sucursal Tutora */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String sucTutora;
    
    /** Numero Tarjeta */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String numTarjeta;
    
    /** Numero Tarjeta */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String numTarjetaAct;
    
    /** RFC*/
    @Pattern(regexp = "(^([a-zA-Z]{3,4})+(([0-9]){6})+([a-zA-Z0-9]{3})+$)?", message = "RFC no Valido")
    private String rfc;
    
    /** Numero cuenta */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String numeroCuenta;
    
    /** Importe sin formato para la exportacion */
    private BigDecimal importeSinFormato;
    
    /** Descripcion de alta masiva de empelados */
    @Pattern(regexp = "(^[0-9A-Za-zñÑáéíóúÁÉÍÓÚ ]+$)?", message = "Datos no validos")
    @Size(min = 0, max = 120, message = "Datos erroneos")
    private String descripcion;
    
    /** Numero Movil */
    @Pattern(regexp = "(^[0-9 -]+$)?", message = "Datos no validos")
    private String numeMovil;
    
    /** Nombre proveedor. */
    @Pattern(regexp = "(^[0-9A-Za-zñÑáéíóúÁÉÍÓÚ ]+$)?", message = "Datos no validos")
    private String nomProveedor;
    
    /** Tipo de operacion. */
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
    private String tipoOperacion;
    
    /** Clave de operacion. */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String cveProveedor;
    
    /** Tipo de persona juridica. */
    @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
    private String tipoPerJuridica;
    
    /**Numero de folio.*/
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String numFolio;
    
    /**Codigo registro*/
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String codRegistro;
    
    /**Horario de programación*/
    @Pattern(regexp = "(^\\d{2}:\\d{2}((:\\d{2})?)+$)?", message = "Hora No Valida")
    @Size(min = 0, max = 8, message = "Hora Erronea")
    private String horarioProg;
    
    /**Id mensaje*/
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String idMensaje;
    
    /** Atributo que representa la variable idCliente del tipo String */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String idCliente;
    
    /** Atributo que representa la variable fechaIni del tipo String */
    @Pattern(regexp = "(((\\d{2})|(\\d{4}))([-/])\\d{2}([-/])((\\d{2})|(\\d{4})))( (\\d{2}:\\d{2}:\\d{2})?)?", message = "Fecha No Valida")
    @Size(min = 0, max = 20, message = "Fecha erronea")
    private String fechaIni;
    
    /** Atributo que representa la variable fechaFin del tipo String */
    @Pattern(regexp = "(((\\d{2})|(\\d{4}))([-/])\\d{2}([-/])((\\d{2})|(\\d{4})))( (\\d{2}:\\d{2}:\\d{2})?)?", message = "Fecha No Valida")
    @Size(min = 0, max = 20, message = "Fecha erronea")
    private String fechaFin;
    
    /** Número de convenio - Clave de Rastreo */
    @Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos no validos")
    private String numConvenio;
}
