package mx.santander.h2h.monitoreo.repository;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Repository;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.constants.MonitorOperacionesConstants;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.util.MonitorOperacionesComunes;
import mx.santander.h2h.monitoreo.util.OperMonEntityManHelp1Util;
import mx.santander.h2h.monitoreo.util.UtilData;
import mx.santander.h2h.monitoreo.util.UtilMonitorFnc;
import mx.santander.h2h.monitoreo.util.UtilOrdenesPagoAtmDatosExportar;
import mx.santander.h2h.monitoreo.util.UtilQuery;

/**
 * OperationsMonitorEntityManagerHelper1Repository.
 *
 * @author Daniel Ruiz
 */
@Slf4j
@Repository
public class OperationsMonitorEntityManagerHelper1Repository
		implements IOperationsMonitorEntityManagerHelper1Repository {
	
	
	/**
	 * Prepara la consulta de operaciones
	 * 
	 * @param consultaOperaciones - Parametros de la consulta
	 * @param query               StringBuilder para el query
	 * @param params              Map para los parámetros
	 */
	protected static void preparaConsultaOperaciones(OperationsMonitorQueryRequest consultaOperaciones, 
			StringBuilder querySQL, Map<String, Object> params) {
		
		log.debug("Preparando consulta de operaciones");

		// Iniciamos las validaciones
		if (OperationsMonitorEntityManagerHelper3Repository.isDateToday(consultaOperaciones.getFechaInicial())) {
			log.info("*****MIGAJA  A*****");
			querySQL.append(MonitorOperacionesConstants.SEL_PROD);
			
			OperMonEntityManHelp1Util.validaciones(consultaOperaciones, querySQL, params, "subcons", true);
			
			querySQL.append(MonitorOperacionesConstants.TABLA_PROD);
			getWhereConsultaOperaciones(consultaOperaciones, querySQL, params, false);
			querySQL.append(" ORDER BY PROD.ID_REG DESC ");
			
		} else {
			log.info("*****MIGAJA  B ii*****");
			querySQL.append(MonitorOperacionesConstants.SEL_PROD)
				.append(MonitorOperacionesConstants.SEL_PROD);
			
			OperMonEntityManHelp1Util.validaciones(consultaOperaciones, querySQL, params, "subcons", false);
			
			/** Llamamos al formato para generar la consulta QUERY getWhereConsultaOperaciones */
			querySQL.append( MonitorOperacionesConstants.TABLA_PROD );
			getWhereConsultaOperaciones(consultaOperaciones, querySQL, params, false);
			
			querySQL.append(MonitorOperacionesConstants.UNION_ALL)
				.append(MonitorOperacionesConstants.SEL_PROD);

			OperMonEntityManHelp1Util.validaciones(consultaOperaciones, querySQL, params, "subcons", true);
			
			querySQL.append( MonitorOperacionesConstants.TABLA_PROD );
			/** Llamamos al formato para generar la consulta QUERY getWhereConsultaOperaciones */
			getWhereConsultaOperaciones(consultaOperaciones, querySQL, params, false);
				
			querySQL.append( MonitorOperacionesConstants.TABLA_PROD)
				.append(" ORDER BY PROD.ID_REG DESC ");
		}
	}
	
	
	/**
	 * Agrega el where de parametros de consulta.
	 * 
	 * @param consultaOperaciones DTO de restricciones
	 * @param query               StringBuilder para el query
	 * @param params              Map para los parámetros
	 * @param exportar            true para flujo de exportacion
	 */
	protected static void getWhereConsultaOperaciones(
			OperationsMonitorQueryRequest consultaOperaciones, 
			StringBuilder querySQLOrigen,
			Map<String, Object> params, 
			boolean exportar) {
		boolean someFilter =  false;
		StringBuilder querySQL = new StringBuilder();
		
		querySQL.append(" WHERE ");
		if (!exportar) {
			someFilter =  true;  // Bandera que indica que entro a un filtro
			// Agregamos los valores del rango de Fechas
			querySQL.append("(PROD.FECHA_REGISTRO BETWEEN TO_DATE(:fechaInicial, 'DD/MM/YYYY HH24:MI:SS') ")
				.append("AND (TO_DATE(:fechaFinal, 'DD/MM/YYYY HH24:MI:SS')) ")
				.append("OR PROD.FECHA_APLICACION BETWEEN TO_DATE(:fechaInicial, 'DD/MM/YYYY HH24:MI:SS') ")
				.append("AND (TO_DATE(:fechaFinal, 'DD/MM/YYYY HH24:MI:SS'))) ");
			
			params.put("fechaInicial", consultaOperaciones.getFechaInicial() + MonitorOperacionesConstants.HORARIOINICIAL);
			params.put("fechaFinal", consultaOperaciones.getFechaFinal() + MonitorOperacionesConstants.HORARIOFINAL);
		}
		
		// Cargamos las validaciones de los componentes
		UtilMonitorFnc.getValidacion(consultaOperaciones, querySQL, params, someFilter); 
		
		// Validamos el tipo de Divisa
		if (!UtilData.isVacio(consultaOperaciones.getDivisa())
				&& !UtilData.esIgual(consultaOperaciones.getDivisa(), MonitorOperacionesConstants.CERO)) {
			if (MonitorOperacionesConstants.MXP.equals(consultaOperaciones.getDivisa())) {
				UtilMonitorFnc.cadDivisa(querySQL, MonitorOperacionesConstants.MXP, MonitorOperacionesConstants.MN, params, someFilter); 
			} else {
				if (MonitorOperacionesConstants.USD.equals(consultaOperaciones.getDivisa())) {
					UtilMonitorFnc.cadDivisa(querySQL, MonitorOperacionesConstants.USD, MonitorOperacionesConstants.DL, params, someFilter);
				} else {
					UtilMonitorFnc.armaQueryAnd(querySQL, "PROD.DIVISA = :divisa ", someFilter);
					params.put("divisa", consultaOperaciones.getDivisa());
				}
			}
			someFilter = true;
		}
		
		// Seccion PIF 2
		OperationsMonitorEntityManagerHelper3Repository.validatePif2(consultaOperaciones, querySQL, params, someFilter);
		
		OperationsMonitorEntityManagerHelper3Repository.validatePif(consultaOperaciones, querySQL, params, exportar);
		
		// Validamos si se trata de exportar y el contenido de los filtros
		if( exportar && !someFilter) {
			// Limpiamos los datos
			querySQL.setLength(0);
			params = new HashMap<>();
			return;
		}
		
		querySQLOrigen.append( querySQL.toString() );
	}
	

	/**
	 * 
	 * @param delDia Dia
	 * @param idcntr String
	 * @return String con query de Transferencias Internacionales
	 */
	public static String getselectTransfInter(boolean delDia, StringBuilder querySQL, String idcntr) {
		StringBuilder qryTrnsFin = new StringBuilder();
		String tabla = "";
		
		if ("31".equals(idcntr)) {
			tabla = MonitorOperacionesConstants.H2H_MX_PROD_TRAN_INTN;
		} else if ("33".equals(idcntr)) {
			tabla = "H2H_MX_PROD_BANC_CAMB";
		}
		qryTrnsFin.append(delDia ? MonitorOperacionesConstants.SELECT_H2H_REG_TRAN_TABLA : MonitorOperacionesConstants.SELECT_H2H_REG_TABLA)
		.append("REG.ID_REG, CLTE.BUC, REG.CNTA_CARG NUM_CTA_CARGO, REG.CNTA_ABON NUN_CTA_ABONO, PROD.CVE_PROD_OPER, PROD.DESC_PROD,")
		.append("ARCH.NOMBRE_ARCH,");
		if ("33".equals(idcntr)) {
			qryTrnsFin.append("TRIN.NUM_ORDEN REFERENCIA, REG.ID_ESTATUS,EST.DESC_ESTATUS, REG.MONT IMPORTE, CNTR.NUM_CNTR, REG.DIVI DIVISA,")
			.append("ARCH.FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, REG.NUM_EMAIL,'' OBSE_ABO, CLTE.BUC BUC_EMPLEADO,")
			.append(" CANL.NOMB_CANL ");
		} else {
			qryTrnsFin.append("TRIN.TXT_REF ")
			.append("REFERENCIA, REG.ID_ESTATUS,EST.DESC_ESTATUS, REG.MONT IMPORTE, CNTR.NUM_CNTR, REG.DIVI DIVISA,")
			.append("ARCH.FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, REG.NUM_EMAIL,'' OBSE_ABO, CLTE.BUC BUC_EMPLEADO")
			.append(",CANL.NOMB_CANL  ");
		}
		qryTrnsFin.append(UtilQuery.fromH2hArchivo(delDia))
		.append(UtilQuery.innerJoinH2hReg(delDia))
		.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CNTR_CNTR_USING_ID_CNTR)
		.append(" INNER JOIN H2H_CLTE CLTE USING (ID_CLTE) ")
		.append(" INNER JOIN H2H_CAT_PROD PROD on PROD.CVE_PROD_OPER=REG.CVE_PROD_OPER ")
		.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CAT_ESTATUS_EST_ON_REG_ID_ESTATUS_EST_ID_CAT_ESTATUS)
		.append(" INNER JOIN H2H_CAT_CANL CANL ON ARCH.ID_CANL = CANL.ID_CANL ")
		.append(delDia ? " INNER JOIN " + tabla + "_TRAN TRIN  ON  TRIN.ID_REG = REG.ID_REG "
			: "INNER JOIN " + tabla + " TRIN ON TRIN.ID_REG = REG.ID_REG");
		return qryTrnsFin.toString();
	}

	/**
	 * Genera la consulta de las operaciones de pago directo
	 * 
	 * @param delDia indica si se usan las tablas del diario
	 * @return String con la consulta
	 */
	public static void getSelectConsultaOperacionesPagoDirecto(StringBuilder querySQL, boolean delDia) { // Inicia PGODIRECT
		log.info("*****MIGAJA PD *****");
		querySQL.append(UtilQuery.selectRegTabla(delDia)).append(MonitorOperacionesConstants.REG_ID_REG_CLTE_BUC_REG_CNTA_CARG_NUM_CTA_CARGO)
			.append(MonitorOperacionesConstants.REG_CNTA_ABON_NUN_CTA_ABONO_CVE_PROD_OPER_PROD_DESC_PROD)
			.append(MonitorOperacionesConstants.ARCH_NOMBRE_ARCH_REG_REFE_BE_REFERENCIA_REG_ID_ESTATUS)
			.append(MonitorOperacionesConstants.EST_DESC_ESTATUS_REG_MONT_IMPORTE_CNTR_NUM_CNTR_REG_DIVI_DIVISA)
			.append(" ARCH.FECHA_REGISTRO, PAGO.FECH_LIBE FECHA_APLICACION, PROD.VIST_PROD, REG.NUM_EMAIL, ")
			.append("CANL.NOMB_CANL, ").append("PAGO.NO_ORDEN NUM_ORDEN, PAGO.NOM_BENE BENEFICIARIO ")
			.append(UtilQuery.fromH2hArchivo(delDia)).append(UtilQuery.innerJoinH2hReg(delDia))
			.append(" INNER JOIN H2H_CNTR CNTR USING (ID_CNTR) ").append(MonitorOperacionesConstants.INNER_JOIN_H2H_CLTE)
			.append(MonitorOperacionesConstants.PART_QUERY_SELECT_INNER_CAT_PROD)
			.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CAT_ESTATUS_EST_ON_REG_ID_ESTATUS_EST_ID_CAT_ESTATUS)
			.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CAT_CANL).append(UtilQuery.innerJoinPagoDirecto(delDia));
	} // Fin PGODIRECT

	
	/**
	 * Metodo par ala consutla de datos
	 * 
	 * @param tresMeses
	 * @param consultaOperaciones
	 * @return
	 */
	protected static void getSelectConsultaOperaciones (
			OperationsMonitorQueryRequest consultaOperaciones, StringBuilder querySQL, 
			Map<String, Object> params, boolean tresMeses
		){
		log.info("*****MIGAJA  1*****");
		
		querySQL.append(tresMeses ? 
			MonitorOperacionesConstants.SELECT_H2H_REG_TRAN_TABLA  
		 		: MonitorOperacionesConstants.SELECT_H2H_REG_TABLA)
			.append(MonitorOperacionesConstants.REG_ID_REG_CLTE_BUC_REG_CNTA_CARG_NUM_CTA_CARGO)
			.append(MonitorOperacionesConstants.REG_CNTA_ABON_NUN_CTA_ABONO_CVE_PROD_OPER_PROD_DESC_PROD)
			.append(MonitorOperacionesConstants.ARCH_NOMBRE_ARCH_REG_REFE_BE_REFERENCIA_REG_ID_ESTATUS)
			.append(MonitorOperacionesConstants.EST_DESC_ESTATUS_REG_MONT_IMPORTE_CNTR_NUM_CNTR_REG_DIVI_DIVISA)
			.append(MonitorOperacionesConstants.PART_QUERY_SELECT_FECHA_REGISTRO_APLI_PROD)
			.append(" CANL.NOMB_CANL ")
			.append(tresMeses ? "FROM H2H_REG_TRAN REG " : "FROM H2H_REG REG ")
			.append(tresMeses ? "INNER JOIN H2H_ARCHIVO_TRAN ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH " 
				: "INNER JOIN H2H_ARCHIVO ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ")
			.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CNTR_CNTR_USING_ID_CNTR)
			.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CLTE)
			.append(MonitorOperacionesConstants.INNER_CAT_PROD)
			.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CAT_ESTATUS_EST_ON_REG_ID_ESTATUS_EST_ID_CAT_ESTATUS)
			.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CAT_CANL);
		
		// Inicio: si se trata de un producto confirmig y alguno de los parametros incluye informacion
		log.info("*****MIGAJA  REVISA SI ES EL PRODUCTO CONFIRMING*****");
		log.info("*****consultaOperaciones.getCveProveedor()*****"+consultaOperaciones.getCveProveedor());
		log.info("*****consultaOperaciones.getTipOperacion()*****"+consultaOperaciones.getTipOperacion());
		
		if("11".equals(consultaOperaciones.getIdProducto()) 
			&& (consultaOperaciones.getCveProveedor()!= null 
			|| consultaOperaciones.getTipOperacion()!=null) 
			&& (!StringUtils.EMPTY.equals(consultaOperaciones.getCveProveedor()) 
			|| !StringUtils.EMPTY.equals(consultaOperaciones.getTipOperacion()))  ){
			
			log.info("*****AGREGA EL WHERE EN CASO DE SER CONFIRMING Y QUE ALGUNO DE LOS PARAMTROS NO SEA VACIO*****");
			
			querySQL.append(tresMeses ? "LEFT JOIN H2H_PROD_MTTO_PROV_TRAN " 
				: " LEFT JOIN H2H_PROD_MTTO_PROV ") 
			.append("PCONF ON REG.ID_REG = PCONF.ID_REG ");
			
			MonitorOperacionesComunes.agregaFiltrosConsultaOperaciones(consultaOperaciones, querySQL, params);
		}
	}


	/**
	 * Genera la consulta de las operaciones de Centro de Pago MIT
	 * @param delDia indica si se usan las tablas del diario
	 * @return String con la consulta
	 */
	protected static String getSelectCentroPagoMit(final StringBuilder query, boolean delDia){ //Inicia CentroPagoMIT 
		log.info("*****MIGAJA PD *****");
		StringBuilder qryMit = new StringBuilder();
		qryMit
		 .append(UtilQuery.selectRegTabla(delDia))
			.append(MonitorOperacionesConstants.REG_ID_REG_CLTE_BUC_REG_CNTA_CARG_NUM_CTA_CARGO)
			.append(MonitorOperacionesConstants.REG_CNTA_ABON_NUN_CTA_ABONO_CVE_PROD_OPER_PROD_DESC_PROD)
			.append(MonitorOperacionesConstants.ARCH_NOMBRE_ARCH_REG_REFE_BE_REFERENCIA_REG_ID_ESTATUS)
			.append(MonitorOperacionesConstants.EST_DESC_ESTATUS_REG_MONT_IMPORTE_CNTR_NUM_CNTR_REG_DIVI_DIVISA)
			.append(" ARCH.FECHA_REGISTRO,REG.FECH_APLI FECHA_APLICACION,PROD.VIST_PROD,REG.NUM_EMAIL, ")
			.append("CANL.NOMB_CANL ")
			.append(UtilQuery.fromH2hArchivo(delDia))
			.append(UtilQuery.innerJoinH2hReg(delDia))
			.append(" INNER JOIN H2H_CNTR CNTR USING (ID_CNTR) ")
			.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CLTE)
			.append(MonitorOperacionesConstants.PART_QUERY_SELECT_INNER_CAT_PROD)
			.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CAT_ESTATUS_EST_ON_REG_ID_ESTATUS_EST_ID_CAT_ESTATUS)
			.append(MonitorOperacionesConstants.INNER_JOIN_H2H_CAT_CANL);
		 return qryMit.toString();
	}

	public static String generaQueryProductosOrdenPagoatm(boolean tresMeses,
			String idProducto) {
		StringBuilder query= new StringBuilder();
		log.info("*****generaQueryProductosVostro*****>");
		 query
		 .append("SELECT '") 
		 	.append(UtilOrdenesPagoAtmDatosExportar.getTablaPorCveProdOp(tresMeses, idProducto))
		 	.append("' TABLA,")
			.append(UtilOrdenesPagoAtmDatosExportar.getTablasSelCampos().get(idProducto))
//		 	.append(UtilOrdenesPagoAtmDatosExportar.tablasSelCampos.get(idProducto))
			.append(" FROM ")
			.append(UtilOrdenesPagoAtmDatosExportar.getTranop("H2H_REG",tresMeses)).append(" REG ")
			.append(" INNER JOIN ").append(UtilOrdenesPagoAtmDatosExportar.getTranop("H2H_ARCHIVO",tresMeses)).append(" ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ")
			.append("INNER JOIN H2H_CNTR CNTR USING (ID_CNTR)  INNER JOIN H2H_CLTE CLTE USING (ID_CLTE) ")
			.append(" INNER JOIN H2H_CAT_PROD PROD  ON PROD.CVE_PROD_OPER = REG.CVE_PROD_OPER ")
			.append("INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS ")
			.append("INNER JOIN H2H_CAT_CANL CANL ON ARCH.ID_CANL = CANL.ID_CANL ")
		    .append(" INNER JOIN ").append(UtilOrdenesPagoAtmDatosExportar.getTablaPorCveProdOp(tresMeses,idProducto))
		    .append(" DETA ON REG.ID_REG=DETA.ID_REG ");
		 return query.toString();
	}
}
