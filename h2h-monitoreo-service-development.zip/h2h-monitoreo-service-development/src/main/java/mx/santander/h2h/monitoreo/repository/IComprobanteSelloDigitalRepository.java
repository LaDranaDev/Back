package mx.santander.h2h.monitoreo.repository;

import mx.isban.h2h.comprobantefiscal.ConsultaInfoConcepto;
import mx.isban.h2h.comprobantefiscal.ConsultaInfoConceptoResponse;
import mx.isban.h2h.comprobantefiscal.GeneraComprobante;
import mx.isban.h2h.comprobantefiscal.GeneraComprobanteResponse;
import mx.isban.h2h.comprobantefiscal.RegistraMovimiento;
import mx.isban.h2h.comprobantefiscal.RegistraMovimientoResponse;
import mx.isban.h2h.comprobantefiscal.ValidaComprobante;
import mx.isban.h2h.comprobantefiscal.ValidaComprobanteResponse;

/**
 * IComprobanteSelloDigitalRepository interface principal de las operaciones de
 * WS ComprobanteSelloDigital
 * 
 * @author Omar Rosas
 * @since 13/10/2023
 *
 */
public interface IComprobanteSelloDigitalRepository {
	/**
	 * Metodo que consume la operacion de consulta de informacion del concepto
	 * 
	 * @param request Datos de entrada para la consulta
	 * @param url     Url del servicio de comprobantes
	 * @return Respuesta de la consulta de informacion de concepto
	 */
	ConsultaInfoConceptoResponse consultaInfoConcepto(final ConsultaInfoConcepto request, final String url);

	/**
	 * Metodo que consume la operacion de registro de movimientos
	 * 
	 * @param request Datos de entrada para el registro
	 * @param url     Url del servicio de comprobantes
	 * @return Respuesta del registro de movimientos
	 */
	RegistraMovimientoResponse registraMovimiento(final RegistraMovimiento request, final String url);

	/**
	 * Metodo que consume la operacion de validacion del comprobante
	 * 
	 * @param request Datos de entrada para la validacion del comprobante
	 * @param url     Url del servicio de comprobantes
	 * @return Respuesta de la validacion del comprobante
	 */
	ValidaComprobanteResponse validaComprobante(final ValidaComprobante request, final String url);

	/**
	 * Metodo que consume la operacion de generacion de comprobante
	 * 
	 * @param request Datos de entrada para la generacion del comprobante
	 * @param url     Url del servicio de comprobantes
	 * @return Respuesta de la generacion del comprobante
	 */
	GeneraComprobanteResponse generaComprobante(final GeneraComprobante request, final String url);

}
