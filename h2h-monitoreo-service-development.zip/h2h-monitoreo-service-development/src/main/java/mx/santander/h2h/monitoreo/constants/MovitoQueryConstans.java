package mx.santander.h2h.monitoreo.constants;

/**
 * MovitoQueryConstans.
 *
 * @author Jesus Soto Aguilar
 */
public final class MovitoQueryConstans {

    /** Query para obtener motivo de rechazo
     con la propiedad  SQL_MOTIVO */
    public static final String SQL_MOTIVO =
            "SELECT NVL(ARCH.MOTIVO_RECH_DUPLI, '') MOTIVO_RECH_DUPLI " +
            "FROM H2H_REG REG INNER JOIN H2H_ARCHIVO ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH " +
            "WHERE REG.ID_MSG IN (2570,2569) AND ID_REG = :idOperacion";

    /** Query para obtener motivo de rechazo  con la propiedad  SQL_MOTIVO_TRAN  */
    public static final String SQL_MOTIVO_TRAN =
            "SELECT NVL(ARCH.MOTIVO_RECH_DUPLI, '') MOTIVO_RECH_DUPLI " +
            "FROM H2H_REG_TRAN REG INNER JOIN H2H_ARCHIVO_TRAN ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH " +
            "WHERE REG.ID_MSG IN (2570,2569) AND ID_REG = :idOperacion";

    private MovitoQueryConstans() {}

}
