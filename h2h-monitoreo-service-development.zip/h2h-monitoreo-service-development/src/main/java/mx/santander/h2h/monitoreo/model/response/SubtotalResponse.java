package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class SubtotalResponse implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4270869297129544411L;

	/** Subtotal de archivos. Monitoreo Tracking*/
	private int subTotalArchivos=0;
	/** Subtotal de archivos alerta.*/
	private int subAlerta=0;
	/** Subtotal de archivos duplicados.*/
	private int subDuplicado=0; 
	/** Subtotal de archivos espera.*/
	private int subEspera=0;
	/** Subtotal de archivos proceso.*/
	private int subproceso=0; 
	/** Subtotal de archivos enrollment.*/
	private int subEnrollment=0; 	
	/** Subtotal de archivos procesados.*/
	private int subProcesado=0;	
	/** Subtotal de archivos programados.*/
	private int subProgramado=0; 	
	/** Subtotal de archivos rechazados.*/
	private int subRechazados=0;	
	/** Subtotal de archivos recibido.*/
	private int subRecibido=0;
	/** Subtotal de archivos validado.*/
	private int subValidado=0;
	
	/** Totales. Consulta Comisiones*/
	
	/** Total Precio */
	private BigDecimal totPrecio;
	
	/** Total Comision */
	private BigDecimal totComision;
	
	/** Total Importe Comision */
	private BigDecimal totImporteComision;
	
	/** Total Iva Comision */
	private BigDecimal totIvaComision;
	
	/** Total Total Comision */
	private BigDecimal totTotalComision;
	
	/** Total Total Porcentaje */
	private BigDecimal totPorcentaje;
}
