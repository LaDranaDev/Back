package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NivelProductoResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1305301459791517197L;

	/** Fecha de consulta. */
	private String fecha;
	
	/** Codigo del cliente. */
	private String codCliente;
	
	/** Cliente. */
	private String cliente;
	
	/** Id del archivo. */
	private Integer idArchivo;
	
	/** Lista de estatus operacion. */
	private List<ComboResponse> listEstatus;
	
	/** Lista de producto operacion. */
	private List<ComboResponse> listProducto;
	
	/** Datos del archivo. */
	private ProductoArchivoResponse archivo;
	
}
