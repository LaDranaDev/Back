package mx.santander.h2h.monitoreo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import mx.santander.h2h.monitoreo.constants.RoutesConstant;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.MonitorArchivosEnCursoRequest;
import mx.santander.h2h.monitoreo.model.response.ComboDosResponse;
import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import mx.santander.h2h.monitoreo.model.response.MonitorDeArchivosEnCursoDetallesResponse;
import mx.santander.h2h.monitoreo.model.response.MonitorDeArchivosEnCursoResponse;
import mx.santander.h2h.monitoreo.service.IMonitorArchivosEnCursoAuxService;
import mx.santander.h2h.monitoreo.service.IMonitorArchivosEnCursoComplementService;
import mx.santander.h2h.monitoreo.service.IMonitorArchivosEnCursoService;

/**
 * APIS para monitor de archivos en curso.
 *
 * @author emendoza
 * @since 12/04/2023
 */
@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping(RoutesConstant.MONITOREO_ARCHIVOS_EN_CURSO)
public class MonitorArchivosEnCursoController {

    /**
     * Servicio del módulo de monitor de archivos en curso.
     */
    @Autowired
    private IMonitorArchivosEnCursoService iMonitorArchivosEnCursoService;
    
    /**
     * Servicio del módulo de monitor de archivos en curso.
     */
    @Autowired
    private IMonitorArchivosEnCursoAuxService iMonitorArchivosEnCursoAuxService;
    
    @Autowired
    private IMonitorArchivosEnCursoComplementService archivosEnCursoComplementService;
	
	/**
	 * API Get - Consulta los archivos en curso
	 *
	 * @param idContract id de contrato
	 * @return Datos de salida lista de notificaciones
	 */
	 @Operation(summary = "Realiza la consulta de los archivos en curso.")
	    @PostMapping(path = "/consulta", produces = MediaType.APPLICATION_JSON_VALUE)
	    public ResponseEntity<Page<MonitorDeArchivosEnCursoDetallesResponse>> consulta(
	    		@Valid
	            @RequestBody MonitorArchivosEnCursoRequest request,
	            @PageableDefault Pageable pageable
	    ) {
	        return ResponseEntity.ok(iMonitorArchivosEnCursoAuxService.consultaArchivosEnCurso(request, pageable));
	    }
	
	

    /**
     * API Get - Consulta los archivos en curso
     *
     * @param idContract id de contrato
     * @return Datos de salida lista de notificaciones
     */
    @Operation(summary = "Consulta datos nivel producto .")
    @GetMapping(path = "/nivelProducto/{idArchivo}/{idProducto}/{idEstatus}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<MonitorDeArchivosEnCursoResponse> consultaNivelProducto(
    		@Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
    		@PathVariable("idArchivo") String idArchivo, 
            
            @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
            @PathVariable("idProducto") String idProducto,
            
            @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
            @PathVariable("idEstatus") String idEstatus) {

        return ResponseEntity.ok(
                iMonitorArchivosEnCursoService.consultaNivelProducto(
                        idArchivo, idProducto != null && !idProducto.equals("null") ? Integer.parseInt(idProducto) : 0,
                        idEstatus != null && !idEstatus.equals("null") ? Integer.parseInt(idEstatus) : 0));
    }

    /**
     * API Get - Consulta los archivos en curso
     *
     * @param idContract id de contrato
     * @return Datos de salida lista de notificaciones
     */
    @Operation(summary = "Consulta datos nivel operacion .")
    @GetMapping(path = "/nivelOperacion/{idArchivo}/{idProducto}/{idEstatus}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<MonitorDeArchivosEnCursoResponse> consultaNivelOperacion(
    		@Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
            @PathVariable("idArchivo") String idArchivo, 
            
            @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
            @PathVariable("idProducto") String idProducto,
            
            @Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
            @PathVariable("idEstatus") String idEstatus) {
        return ResponseEntity.ok(
                iMonitorArchivosEnCursoService.consultaNivelOperacion(
                        idArchivo, idProducto != null && !idProducto.equals("null") ? Integer.parseInt(idProducto) : 0,
                        idEstatus != null && !idEstatus.equals("null") ? Integer.parseInt(idEstatus) : 0));
    }

    /**
     * API Get - Consulta los archivos en curso
     *
     * @param idContract id de contrato
     * @return Datos de salida lista de notificaciones
     */
    @Operation(summary = "Consulta datos nivel operacion historica.")
    @GetMapping(path = "/nivelOperacionHistorica/{idReg}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<MonitorDeArchivosEnCursoResponse> consultaNivelOperacionHistorica(
    		@Pattern(regexp = "(^[a-zA-Z0-9 ]+$)?", message = "Datos no validos")
            @PathVariable("idReg") String idReg) {

        return ResponseEntity.ok(
                iMonitorArchivosEnCursoService.consultaNivelOperacionHistorica(
                        idReg));
    }

    /**
     * API Get - Consulta los archivos en curso
     *
     * @param idContract id de contrato
     * @return Datos de salida lista de notificaciones
     */
    @Operation(summary = "Consulta datos nivel operacion historica.")
    @GetMapping(path = "/catEstatus", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ComboResponse>> consultaListaEstatus() {
        return ResponseEntity.ok(
        		archivosEnCursoComplementService.obtenerCatalogoEstatus());
    }

    /**
     * API Get - Consulta los archivos en curso
     *
     * @param idContract id de contrato
     * @return Datos de salida lista de notificaciones
     */
    @Operation(summary = "Consulta datos nivel operacion historica.")
    @GetMapping(path = "/catProductos", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ComboDosResponse>> consultaListaProductos() {
        return ResponseEntity.ok(
        		archivosEnCursoComplementService.obtenerCatalogoProducto());
    }

    /**
     * API Get - Consulta los archivos en curso
     *
     * @param idContract id de contrato
     * @return Datos de salida lista de notificaciones
     */
    @Operation(summary = "Consulta datos nivel operacion historica.")
    @GetMapping(path = "/catEstatusProd", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ComboResponse>> consultaListaEstatusProd() {
        return ResponseEntity.ok(
        		archivosEnCursoComplementService.obtenerCatalogoEstatusProd());
    }

    /**
     * API Get - Consulta los archivos en curso
     *
     * @param idContract id de contrato
     * @return Datos de salida lista de notificaciones
     */
    @Operation(summary = "Consulta datos nivel operacion historica.")
    @GetMapping(path = "/catProductosProd", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ComboResponse>> consultaListaProductosProd() {
        return ResponseEntity.ok(
        		archivosEnCursoComplementService.obtenerCatalogoProductoProd());
    }

    /**
     * Controller para exportar Detalle nivel producto
     * @param request MonitorArchivosEnCursoRequest
     * @param user String
     * @return ResponseEntity<ReportResponse>
     */
    @Operation(summary = "Genera reporte en formato xls de Consulta archivos en curso.")
    @PostMapping(value = "/xlsArchivosEnCurso/{user}")
    public ResponseEntity<ReportResponse> getReportXlsDetalleNivelProducto(
    		@Valid
            @RequestBody MonitorArchivosEnCursoRequest request,
            @PathVariable String user) {
        return ResponseEntity.ok(this.iMonitorArchivosEnCursoService.getReportXls(request, user));
    }

}
