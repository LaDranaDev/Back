package mx.santander.h2h.monitoreo.util;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;
import mx.isban.h2h.comprobantes.GeneradorComprobantes;
import mx.isban.h2h.comprobantes.model.Comprobante;
import mx.isban.h2h.comprobantes.model.ComprobanteSalida;
import mx.isban.h2h.comprobantes.model.GeneraComprobanteBean;
import mx.santander.h2h.monitoreo.model.response.ComprobantesOperacionResponse;

/**
 * Genera el reporte con el jar de GeneraComprobantes
 * para homologar la generacion de los comprobantes
 * y concentracion de componentes de genarcacion de
 * pdf en un solo componente centarl
 * Clase para la generacion de los reportes
 * en PDF con el Generador de reportes
 * se pude reducir el codigo se trabajara
 * en la version siguiente
 *
 */
@Slf4j
public final class ComprobanteGenerador2 {

    /**
     * Genera el reporte con el jar de GeneraComprobantes
     * para homologar la generacion de los comprobantes
     * y concentracion de componentes de genarcacion de
     * pdf en un solo componente centarl
     * para el producto de
     * generaOrdenPago
     * @param obj ComprobantesOperacionDTO
     * @return  byte[]
     */
    public static byte[] generaOrdenPago(ComprobantesOperacionResponse obj) {

        GeneradorComprobantes gen=new GeneradorComprobantes();
        GeneraComprobanteBean entrada= new GeneraComprobanteBean();
        entrada.setComprobante(Comprobante.ORDEN_PAGO);
        List<String> datos= new ArrayList<>();
        datos.add("");
        datos.add("");
        datos.add(obj.getCuentaCargo());
        datos.add(obj.getTitular());
        datos.add(obj.getCveBenef());
        datos.add(obj.getBeneficiario());
        datos.add(obj.getImporte());
        datos.add(obj.getPersAut());
        datos.add(obj.getConceptoPago());
        datos.add(obj.getNumOrden());
        datos.add(obj.getRefInterbancaria());
        datos.add(obj.getTipoOper());
        datos.add(obj.getTipoPago());
        datos.add(obj.getNumSucursal());
        datos.add(obj.getEstatus());
        datos.add(obj.getFechaOp());
        datos.add(obj.getFechaLimPago());
        datos.add(obj.getClaveRastreo());

        entrada.setDatosBase(datos);

        ComprobanteSalida salidaComp= gen.generaComprobante(entrada);
        log.info("Comprobante APOR_OBR_PAT generado:" +salidaComp.getMensaje());
        return salidaComp.getComprobanteBytes();
    }

    /**
     * Metodo para generar
     * el reporte de Vostro
     * de tipo:
     * TRANSFERENCIAS INTERNACIONALES CAMBIARIAS
     * TRANSFERENCIAS VOSTRO INTERBANCARIAS
     * o
     * TRANSFERENCIAS VOSTRO MISMO BANCO
     * @param obj
     * @return
     */
    public static byte[] generaVostro(ComprobantesOperacionResponse obj) {
        GeneradorComprobantes gen=new GeneradorComprobantes();
        GeneraComprobanteBean entrada= new GeneraComprobanteBean();
        List<String> datos= new ArrayList<String>();
        datos.add("");
        datos.add("");
        datos.add(obj.getContrato());
        datos.add(obj.getNoDocu());
        datos.add(obj.getRfc());
        datos.add(obj.getFechaAplic());
        datos.add(obj.getRefInterbancaria());
        if(obj.getTipoOper().toUpperCase().contains("-32-")){
            entrada.setComprobante(Comprobante.TRAN_INT_CAM);

            datos.add(obj.getEstatusMov());
            datos.add(obj.getConceptoPago());
            datos.add(obj.getCuentaCargo());
            datos.add(obj.getTitular());
            datos.add(UtilMapeoData.getMascara(obj.getCuentaAbono(), "abono"));
            datos.add(obj.getCveProveedor());
            datos.add(obj.getRazonSocial());
            datos.add(obj.getBanco());
            datos.add(obj.getFormaAplic());
            datos.add(obj.getCveBenef());
            datos.add(obj.getDivisa());
            datos.add(obj.getTipoDoc());
            datos.add(obj.getImporte());
            datos.add("0.0");
            datos.add(obj.getClaveRastreo());
        }else if(obj.getTipoOper().toUpperCase().contains("-38-")){
            entrada.setComprobante(Comprobante.TRAN_VOSTRO_INTBAN);

            datos.add(obj.getEstatusMov());
            addMismosDatosProd(obj, datos);
            datos.add(obj.getBanco());
        }else if(obj.getTipoOper().toUpperCase().contains("-39-")){
            entrada.setComprobante(Comprobante.TRAN_VOSTRO_MIS_BAN);

            addMismosDatosProd(obj, datos);
            datos.add("BANCO SANTANDER (MÉXICO) S.A");
        }
        datos.add(obj.getEstatus());
        entrada.setDatosBase(datos);

        ComprobanteSalida salidaComp= gen.generaComprobante(entrada);
        log.info("Comprobante de cambios Vostro generado:" +salidaComp.getMensaje());
        return salidaComp.getComprobanteBytes();
    }


    /**
     * se agregan los datos
     * similares para
     * el producto
     * de vostros
     * @param obj
     * @param datos
     */
    private static void addMismosDatosProd(ComprobantesOperacionResponse obj,
                                    List<String> datos) {
        datos.add(obj.getConceptoPago());
        datos.add(obj.getCuentaCargo());
        datos.add(obj.getTitular());
        datos.add(UtilMapeoData.getMascara(obj.getCuentaAbono(), "abono"));
        datos.add(obj.getCveProveedor());
        datos.add(obj.getNumOrden());
        datos.add(obj.getBeneficiario());
        datos.add(obj.getRazonSocial());
        datos.add(obj.getFormaAplic());
        datos.add(obj.getCveBenef());
        datos.add(obj.getDivisa());
        datos.add(obj.getImporte());
    }


    /**
     * Metodo para generar los
     * comprobantes de Ordenes de
     * pago de ATM
     * @param obj
     * @return
     */
    public static byte[] generaOrdenPagoAtm(ComprobantesOperacionResponse obj) {

        GeneradorComprobantes gen=new GeneradorComprobantes();
        GeneraComprobanteBean entrada= new GeneraComprobanteBean();
        entrada.setComprobante(Comprobante.ORDENES_PAGO_ATM);
        List<String> datos= new ArrayList<String>();
        datos.add("");
        datos.add("");
        datos.add(obj.getCuentaCargo());
        datos.add(obj.getTitular());
        datos.add(obj.getRazonSocial());
        datos.add(obj.getImporte());
        datos.add(obj.getNumOrden());
        datos.add(obj.getClaveRastreo());
        datos.add(obj.getConceptoPago());
        datos.add(obj.getTipoOper());
        datos.add(obj.getTipoPago());
        datos.add(obj.getCveBenef());
        datos.add(obj.getEstatus());
        datos.add(obj.getFechaAplic());
        datos.add(obj.getBanco());
        datos.add(obj.getNumSucursal());
        entrada.setDatosBase(datos);

        ComprobanteSalida salidaComp= gen.generaComprobante(entrada);
        log.info("Comprobante APOR_OBR_PAT generado:" +salidaComp.getMensaje());
        return salidaComp.getComprobanteBytes();
    }

    /**
     * Genera Reportes de Tipo SPEI y SPID:
     * Utilizando la Utileria de GeneraComprobantes
     * el cual recibe la lista de datos
     * a crear en un pdf, solo enviando los
     * datos y enviando los datos a agregar en el
     * Reporte, este es regresado en un arreglo de bytes,
     * si no se pude generar se regresara uncodigo de
     * error y el arreglo de bytes vacio.
     *
     * @param obj datos del comprobante
     * @return comprobante en arreglo de bytes¿
     */
    public static byte[] generaReportes(ComprobantesOperacionResponse obj, Comprobante comprobante) {

        GeneraComprobanteBean peticion= new GeneraComprobanteBean();
        peticion.setComprobante(comprobante);
        List<String> datos= new ArrayList<>();
        datos.add("");
        datos.add("");
        datos.add(obj.getCuentaCargo());
        datos.add(obj.getTitular());
        datos.add(UtilMapeoData.getMascara(obj.getCuentaAbono(), "abono"));
        datos.add(obj.getBeneficiario());
        datos.add(obj.getImporte());
        datos.add(obj.getDivisa());
        datos.add(obj.getConceptoPago());
        datos.add(obj.getClaveRastreo());
        datos.add(obj.getRefInterbancaria());
        datos.add(String.valueOf(obj.getFolioOp()));
        datos.add(obj.getTipoOper());
        datos.add(obj.getBanco());
        datos.add(obj.getEstatus());
        datos.add(obj.getFechaAplic());
        peticion.setDatosBase(datos);
        GeneradorComprobantes gen= new GeneradorComprobantes();
        ComprobanteSalida salida= gen.generaComprobante(peticion);
        return salida.getComprobanteBytes();

    }

    /**
     * Acomodo de datos para el comprobante de Pago Directo
     * @param obj ComprobantesOperacionDTO
     * @param comprobante Comprobante
     * @return byte[]
     */
    public static byte[] generaReportesPD(ComprobantesOperacionResponse obj, Comprobante comprobante) { //PGODIRECT Inicio
        GeneraComprobanteBean peticion = new GeneraComprobanteBean();
        peticion.setComprobante(comprobante);
        List<String> datos = new ArrayList<String>();
        datos.add("");
        datos.add("");
        datos.add(obj.getCuentaCargo());
        datos.add(obj.getTitular());
        datos.add(obj.getCveBenef());
        datos.add(obj.getBeneficiario());
        datos.add(obj.getImporte());
        datos.add(obj.getBeneficiario());
        datos.add(obj.getConceptoPago());
        datos.add(obj.getNumOrden());
        datos.add(obj.getClaveRastreo());
        datos.add(obj.getTipoOper());
        datos.add(obj.getFormaPago());
        datos.add(obj.getSucursal());
        datos.add(obj.getEstatus());
        datos.add(obj.getFechaOp());
        datos.add(obj.getFechaLimPago());
        datos.add(obj.getClaveRastreo());
        peticion.setDatosBase(datos);
        GeneradorComprobantes gen = new GeneradorComprobantes();
        ComprobanteSalida salida = gen.generaComprobante(peticion);
        return salida.getComprobanteBytes();
    } //PGODIRECT Fin

    /**
     * Genera el reporte con el jar de GeneraComprobantes
     * para homologar la generacion de los comprobantes
     * y concentracion de componentes de genarcacion de
     * pdf en un solo componente centarl
     * para el producto de
     * generaTransferenciasCambiarias
     * @param comprobantetranMBC ComprobantesOperacionDTO
     * @return  byte[]
     */
    public static byte[] generaTransferenciasCambiarias(ComprobantesOperacionResponse comprobantetranMBC) {
        GeneradorComprobantes gen=new GeneradorComprobantes();
        GeneraComprobanteBean entrada= new GeneraComprobanteBean();

        entrada.setComprobante(Comprobante.TRAN_MBC);
        List<String> datos= new ArrayList<String>();
        datos.add("");
        datos.add("");
        datos.add(comprobantetranMBC.getFechaAplic());
        datos.add(comprobantetranMBC.getTipoPago());
        datos.add(comprobantetranMBC.getRefInterbancaria());
        datos.add(comprobantetranMBC.getConceptoPago());
        datos.add(comprobantetranMBC.getClaveRastreo());
        datos.add(comprobantetranMBC.getCuentaCargo());
        datos.add(comprobantetranMBC.getBanco());
        datos.add(comprobantetranMBC.getCuentaAbono() );
        datos.add(comprobantetranMBC.getPersAut());
        datos.add(comprobantetranMBC.getBeneficiario());
        datos.add(comprobantetranMBC.getTipoDoc());
        datos.add(comprobantetranMBC.getImporte());
        datos.add(comprobantetranMBC.getNumOrden());
        datos.add(comprobantetranMBC.getFormaPago());
        datos.add(comprobantetranMBC.getEstatus());
        entrada.setDatosBase(datos);
        ComprobanteSalida salidaComp= gen.generaComprobante(entrada);
        return salidaComp.getComprobanteBytes();
    }

}
