package mx.santander.h2h.monitoreo.constants;


/**
 * MonitorSaldosConstants.
 * Declaracion de las contantes para la construccion del query de saldos reintentos.
 *
 * @author Jesus Soto Aguilar
 * @since 20/04/2023
 */
public final class MonitorSaldosConstants {

    /**
     * String a ser remplazado en la consulta.
     */
    public static final String SUFIJO_REPLACE = "%sufijo% ";

    /**
     * Sufijo de las tablas de transaccion.
     */
    public static final String SUFIJO_TRAN = "_TRAN";

    /**
     * Sufijo para las tablas del historico.
     */
    public static final String SUFIJO_HIST = "_HIST";

    /**
     * String de remplazo para las tablas sin sufijo.
     */
    public static final String NO_SUFIJO = "";

    /**
     * UNION sql.
     */
    public static final String UNION = "UNION";

    /**
     * Ordenamiento de la consulta de saldos reintentos.
     */
    public static final String ORDER_BY_FECH_ORDEN = " ORDER BY fechaOrden DESC";

    /**
     * Query principal para la generacion de la consulta de saldos reintentos.
     */
    public static final String LAYOUT_QUERY_SALDOS_REINTENTOS =
            new StringBuilder().append(" SELECT  DISTINCT FECHA_CONSULTA AS fechaOrden, ")
                    .append("TO_CHAR(FECHA_CONSULTA,'dd/mm/yyyy' ) AS fechaConsulta, ")
                    .append("TO_CHAR(FECHA_CONSULTA,'hh24:mi:ss' ) AS horaConsulta, ")
                    .append("NUM_CTA_ORD AS numeroCuenta, ")
                    .append("TO_CHAR (MONTO_REQUERIDO, '$999,999,999,999,999.00')  AS montoRequerido, ")
                    .append("TO_CHAR (SALDO, '$999,999,999,999,999.00') AS saldo, ")
                    .append("TO_NUMBER ((TO_NUMBER(SALDO) - TO_NUMBER(MONTO_REQUERIDO))) AS saldoFaltante, ")
                    .append("LINEA_CREDITO AS lineaCredito, ")
                    .append("H2H_ARCHIVO ")
                    .append(SUFIJO_REPLACE)
                    .append(".NOMBRE_ARCH AS nombreArchivo, ")
                    .append("H2H_CONS_SALD_REIN ")
                    .append(SUFIJO_REPLACE)
                    .append(".CVE_PROD_OPER AS claveProducto, ")
                    .append("H2H_CAT_PROD.DESC_PROD AS descProducto ")
                    .append("FROM H2H_CONS_SALD_REIN ")
                    .append("%sufijo% ")
                    .append("INNER JOIN H2H_ARCHIVO")
                    .append(SUFIJO_REPLACE)
                    .append(" ON H2H_ARCHIVO")
                    .append(SUFIJO_REPLACE)
                    .append(".ID_ARCHIVO= H2H_CONS_SALD_REIN ")
                    .append(SUFIJO_REPLACE)
                    .append(".ID_ARCHIVO  ")
                    .append("INNER JOIN H2H_CAT_PROD ON H2H_CAT_PROD.CVE_PROD_OPER = H2H_CONS_SALD_REIN").append(SUFIJO_REPLACE).append(".CVE_PROD_OPER ")
                    .append("INNER JOIN H2H_CNTR ON H2H_CNTR.ID_CNTR=H2H_ARCHIVO").append(SUFIJO_REPLACE).append(".ID_CNTR  ")
                    .append("INNER JOIN H2H_CLTE ON H2H_CLTE.ID_CLTE =  H2H_CNTR.ID_CLTE ")
                    .append("WHERE  ")
                    .append("H2H_CLTE.BUC= :claveCliente ")
                    .append("AND  FECHA_CONSULTA BETWEEN NVL (TO_DATE(:fechaInicio, 'dd/mm/yyyy'), FECHA_CONSULTA) ")
                    .append("AND NVL (TO_DATE(:fechaFin, 'dd/mm/yyyy'),  FECHA_CONSULTA) + 1 ").toString();

    /**
     * Filtro por nombre archivo de la consulta de saldos reintentos.
     */
    public static final String NOMBRE_ARCHIVO_FILTER = " AND H2H_ARCHIVO%sufijo%.NOMBRE_ARCH LIKE :nombreArchivo ";

    /**
     * Filtro por clave producto de la consulta de saldos reintentos
     */
    public  static final String CVE_PRODUCTO_FILTER = " AND H2H_CONS_SALD_REIN%sufijo%.CVE_PROD_OPER = :claveProducto ";

    /**
     * Parametro claveCliente.
     */
    public static final String CVE_CLIENTE_PARAM = "claveCliente";

    /**
     * Parametro nombreArchivo.
     */
    public static final String NOMBRE_ARCHIVO_PARAM = "nombreArchivo";

    /**
     * Parametro claveProducto.
     */
    public static final String CLAVE_PRODUCTO_PARAM = "claveProducto";

    /**
     * Parametro fechaInicio.
     */
    public static final String FECHA_INICIO_PARAM = "fechaInicio";

    /**
     * Parametro fechaFin.
     */
    public static final String FECHA_FIN_PARAM = "fechaFin";

    /**
     * String formato 0.0
     */
    public static final String CERO_CERO = "0.0";

    /**
     * Constructor privado.
     */
    private MonitorSaldosConstants (){}
}
