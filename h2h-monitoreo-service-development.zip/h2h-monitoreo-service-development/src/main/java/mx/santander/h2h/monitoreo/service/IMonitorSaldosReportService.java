package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.model.report.request.MonitorSaldosReportRequest;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import org.springframework.stereotype.Service;

/**
 * IMonitorSaldosReportService.
 * Define los metodos de negocio para generar el reporte de saldos reintentos.
 *
 * @author Jesus Soto Aguilar
 * @since 20/04/2023
 */
@Service
public interface IMonitorSaldosReportService {

    /**
     * Genera el reporte de los saldos reintentos en formato xlsx.
     *
     * @param request Objeto con los datos para generar el reporte
     * @return Objeto con los datos del reporte en base 64
     */
    ReportResponse getReportSaldosReintentos(MonitorSaldosReportRequest request);

}
