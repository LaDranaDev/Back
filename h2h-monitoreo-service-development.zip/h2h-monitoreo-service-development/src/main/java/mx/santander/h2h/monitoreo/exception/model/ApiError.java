package mx.santander.h2h.monitoreo.exception.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

import mx.santander.h2h.monitoreo.constants.ApiConstants;
import org.apache.commons.lang.StringUtils;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * ApiError
 * Clase estándar para errores.
 *
 * @author Felipe Monzón
 * @since 19/04/22
 */
@Getter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ApiError implements Serializable {
	/**
	 * serial ID
	 */
	private static final long serialVersionUID = -6096930350337420937L;
	/** Tipo de error. */
	private String type;
	/** Código de error. */
	private String code;
	/** Fecha y hora de error. */
	@Builder.Default
	@JsonSerialize(using = LocalDateTimeSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ApiConstants.DATE_TIME_FULL_PATTERN)
	private LocalDateTime timestamp = LocalDateTime.now();
	/** Mensaje de error. */
	private String message;
	/** Mensaje de error para el desarrollador. */
	@Builder.Default
	private String moreInfo = StringUtils.EMPTY;
	/** Identificador de la petición. */
	private String uuid;
}
