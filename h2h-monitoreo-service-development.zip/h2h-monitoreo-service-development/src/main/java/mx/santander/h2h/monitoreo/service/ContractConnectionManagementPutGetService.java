package mx.santander.h2h.monitoreo.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import jakarta.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.request.PutGetRequest;
import mx.santander.h2h.monitoreo.model.request.PutGetSaveRequest;
import mx.santander.h2h.monitoreo.model.response.CatalogStatusResponse;
import mx.santander.h2h.monitoreo.model.response.ProtocolResponse;
import mx.santander.h2h.monitoreo.model.response.PutGetDto;
import mx.santander.h2h.monitoreo.model.response.PutGetRestResponse;
import mx.santander.h2h.monitoreo.model.response.PutGetServiceResponse;
import mx.santander.h2h.monitoreo.model.response.PutGetWSDto;
import mx.santander.h2h.monitoreo.repository.IContractConnectionManagementEntityManagerRepository;
import mx.santander.h2h.monitoreo.repository.IContractConnectionManagementProtocolsEntityManagerRepository;
import mx.santander.h2h.monitoreo.repository.IContractConnectionManagementPutGetEntityManagerRepository;

/**
 * Servicio para gestión de archivos PUT / GET de gestión de contratos en el módulo gestión de conexión de contratos
 * @author sbautish
 *
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ContractConnectionManagementPutGetService implements IContractConnectionManagementPutGetService {

	@Autowired
	private IContractConnectionManagementPutGetEntityManagerRepository iContractConnectionManagementPutGetEntityManagerRepository;

	@Autowired
	private IContractConnectionManagementEntityManagerRepository iContractConnectionManagementEntityManagerRepository;

	@Autowired
	private IContractConnectionManagementProtocolsEntityManagerRepository iContractConnectionManagementProtocolsEntityManagerRepository;

	@Override
	public PutGetRestResponse findPutGetFiles(PutGetRequest putGetRequest) {

		PutGetRestResponse putGetRestResponse = new PutGetRestResponse();

		try {

			PutGetServiceResponse putGetServiceResponse = iContractConnectionManagementPutGetEntityManagerRepository.findPutGetFiles(putGetRequest, 1);

			putGetRestResponse.setIdcntrPutGet(putGetRequest.getIdContrato());
			putGetRestResponse.setCltePutget(putGetRequest.getCodigoCliente());
			putGetRestResponse.setCntrPutget(putGetRequest.getNumeroContrato());
			putGetRestResponse.setTipoOperPG("V");

			if (putGetServiceResponse != null) {

				putGetRestResponse.setProtocolos(putGetServiceResponse.getRegistrosPG());

				if (!putGetServiceResponse.getRegistrosPG().isEmpty() && StringUtils.isNotBlank(putGetServiceResponse.getIdPara())) {

					putGetRestResponse.setProtocoloActivo(putGetServiceResponse.getNombreProtocolo());
					putGetRestResponse.setIdProtocolo(putGetServiceResponse.getIdProtocolo());
					putGetRestResponse.setIdPtclPara(putGetServiceResponse.getIdPara());

				}

			}

		} catch (BusinessException be) {

			log.info("ERROR...".concat(be.getCode()), be.getMessage());
			throw new BusinessException(be.getMessage());

		}

		return putGetRestResponse;
	}

	@Override
	public PutGetRestResponse verAgregaPutGet(PutGetRequest putGetRequest, Boolean isSavePutGet) {

		PutGetRestResponse putGetRestResponse = new PutGetRestResponse();

		String tipoOperPG = putGetRequest.getTipoOperPG();

		putGetRestResponse.setTipoOperPG(tipoOperPG);
		putGetRestResponse.setIdProtocolo(putGetRequest.getIdProtocolo());
		putGetRestResponse.setIdcntrPutGet(putGetRequest.getIdContrato());
		putGetRestResponse.setCntrPutget(putGetRequest.getNumeroContrato());
		putGetRestResponse.setCltePutget(putGetRequest.getCodigoCliente());
		putGetRestResponse.setIdPtclPara(putGetRequest.getIdProtocoloPara());
		putGetRestResponse.setIdProtocoloPath1(putGetRequest.getIdProtocoloPath1());
		putGetRestResponse.setIdProtocoloPath2(putGetRequest.getIdProtocoloPath2());

		if (Boolean.TRUE.equals(isSavePutGet)) {

			PutGetServiceResponse putGetServiceResponse = getPutGetDto(putGetRequest);

			if ("A".equals(tipoOperPG)) {

				log.info("Guardamos Protocolo Nuevo Put y Get.");

				iContractConnectionManagementPutGetEntityManagerRepository.insertPutGetProtocol(putGetServiceResponse, putGetRequest.getNumeroContrato());

//				BitacoraUtil.bitacora().grabaPistaString

			} else if ("M".equals(tipoOperPG)) {

				log.info("Modificamos Protocolo Put y Get...");

				iContractConnectionManagementPutGetEntityManagerRepository.updatePutGetProtocol(putGetServiceResponse, putGetRequest);

			}

			putGetRestResponse = findPutGetFiles(putGetRequest);

		} else {

			List<ProtocolResponse> listPutGetResponse = iContractConnectionManagementPutGetEntityManagerRepository.getPutFilesProtocols();

			PutGetServiceResponse putGetServiceResponse = new PutGetServiceResponse();

			for (ProtocolResponse protocolResponse : listPutGetResponse) {

				protocolResponse.setParametrosGet(iContractConnectionManagementEntityManagerRepository.findParametersOfProtocols(
						Integer.valueOf(putGetRequest.getIdContrato()), protocolResponse.getIdProtocolo(), BigDecimal.valueOf(0), "GET"));

				protocolResponse.setParametrosPut(iContractConnectionManagementEntityManagerRepository.findParametersOfProtocols(
						Integer.valueOf(putGetRequest.getIdContrato()), protocolResponse.getIdProtocolo(), BigDecimal.valueOf(0), "PUT"));

				protocolResponse.setNombreParametros(iContractConnectionManagementProtocolsEntityManagerRepository.findParametersNameInProtocol(
						protocolResponse.getIdProtocolo()));

			}

			putGetServiceResponse.setProtocolos(listPutGetResponse);

			putGetRestResponse.setLstProtocolos(listPutGetResponse);
			putGetRestResponse.setPutGetResponse(putGetServiceResponse);

			getParamLstOs(putGetRestResponse);

			putGetServiceResponse = iContractConnectionManagementPutGetEntityManagerRepository.findPutGet(putGetRequest, 2, putGetServiceResponse);

			putGetRestResponse.setPutGetResponse(putGetServiceResponse);

		}

		return putGetRestResponse;
	}

	@Override
	public PutGetRestResponse enableDisablePutGet(@Valid PutGetDto putGetDto) {

		String actualizaPutGet = "ERUPDPG1";

		if (StringUtils.isNotBlank(putGetDto.getIdPtclPara()) && StringUtils.isNotBlank(putGetDto.getIdPtclPath())) {

			putGetDto.setEstatus(validateEstatusChangeEnableDisable(putGetDto.getEstatus()));

			actualizaPutGet = iContractConnectionManagementPutGetEntityManagerRepository.enableDisablePutGet(putGetDto);

		}

		try {

			PutGetRequest putGetRequest = new PutGetRequest();

			putGetRequest.setCodigoCliente(putGetDto.getCodigoCliente());
			putGetRequest.setIdContrato(putGetDto.getIdContrato());
			putGetRequest.setNumeroContrato(putGetDto.getNumeroContrato());

			PutGetRestResponse findPutGetFiles = findPutGetFiles(putGetRequest);

			findPutGetFiles.setMSG_ERR(actualizaPutGet);

			return findPutGetFiles;

		} catch (BusinessException be) {

			log.info("ERROR...".concat(be.getCode()), be.getMessage());
			throw new BusinessException(be.getMessage());

		}

	}

	/**
	 * Método para validar estatus y cambiar el valor a Activo o Inactivo o viceversa.
	 * 
	 * @param estatus valor actual del estatus Ativo o Inactivo que se cambiará al estatus contrario.
	 * @return regresa nuevo estatus al que se cambiará.
	 */
	private String validateEstatusChangeEnableDisable(String estatus) {

		String estatusNuevo = "I";

		if (StringUtils.isNotBlank(estatus) && estatusNuevo.equals(estatus)) {

			estatusNuevo = "A";

		}

		return estatusNuevo;

	}

	/**
	 * Método para obtener el DTO con los valores de la vista
	 * @param putGetRequest
	 * @return
	 */
	private PutGetServiceResponse getPutGetDto(PutGetRequest putGetRequest) {

		PutGetDto putGetDtoResponse = new PutGetDto();

		PutGetSaveRequest putGetSaveRequest = putGetRequest.getPutGetSaveRequest();

		putGetDtoResponse.setDirectorio(putGetSaveRequest.getDirectorioPut());
		putGetDtoResponse.setDirectorioGet(putGetSaveRequest.getDirectorioGet());
		putGetDtoResponse.setPuerto(putGetSaveRequest.getPuertoPutGet());
		putGetDtoResponse.setServidor(putGetSaveRequest.getServidorPutGet());
		putGetDtoResponse.setUserId(putGetSaveRequest.getUseriIDPutGet());
		putGetDtoResponse.setPatron(putGetSaveRequest.getPatronPutGet());
		putGetDtoResponse.setPatronGet(putGetSaveRequest.getPatronGetPutGet());
		putGetDtoResponse.setIdProtocolo(putGetSaveRequest.getIdSelTipoProtocolo());
		putGetDtoResponse.setIdContrato(putGetRequest.getIdContrato());

		putGetDtoResponse.setProfileId(putGetSaveRequest.getProfileIdPutGet());
		putGetDtoResponse.setKnowIdHost(putGetSaveRequest.getKnowIdHostPutGet());
		putGetDtoResponse.setUserIdKey(putGetSaveRequest.getUserIdKeyPutGet());
		putGetDtoResponse.setNodoRemoto(putGetSaveRequest.getNodoRemotoPutGet());
		putGetDtoResponse.setUsuarioRemoto(putGetSaveRequest.getUsuarioRemotoPutGet());
		putGetDtoResponse.setNodoLocal(putGetSaveRequest.getNodoLocalPutGet());
		putGetDtoResponse.setUsuarioLocal(putGetSaveRequest.getUsuarioLocalPutGet());
		putGetDtoResponse.setPasswordRemoto(putGetSaveRequest.getPasswordRemotoPutGet());
		putGetDtoResponse.setOscurecerPwd(putGetSaveRequest.getOscurecerPwdPutGet());
		putGetDtoResponse.setModoBinario(putGetSaveRequest.getModoBinarioPutGet());
		putGetDtoResponse.setFormatoRegistro(putGetSaveRequest.getFormatoRegistroPutGet());
		putGetDtoResponse.setLongitudRegistro(putGetSaveRequest.getLongitudRegistroPutGet());
		putGetDtoResponse.setModoDisp(putGetSaveRequest.getModoDispPutGet());
		putGetDtoResponse.setParametroSysOpts(putGetSaveRequest.getParametroSysOptsPutGet());
		putGetDtoResponse.setDisposicionRegistro(putGetSaveRequest.getDisposicionRegistroPutGet());

		List<PutGetDto> listPutGetDtoResponse = new ArrayList<>();
		listPutGetDtoResponse.add(putGetDtoResponse);

		PutGetServiceResponse putGetServiceResponse = new PutGetServiceResponse();

		putGetServiceResponse.setHostOs(putGetSaveRequest.getHostOSPutGet());
		putGetServiceResponse.setRegistrosPG(listPutGetDtoResponse);
		putGetServiceResponse.setIdPara(putGetRequest.getIdProtocoloPara());
		putGetServiceResponse.setIdProtocolo(putGetRequest.getIdProtocolo());

		if ("5".equals(putGetDtoResponse.getIdProtocolo()) || ("5".equals(putGetServiceResponse.getIdProtocolo()) && StringUtils.isNotBlank(putGetDtoResponse.getIdProtocolo()))) {

			PutGetWSDto putGetWSDto = new PutGetWSDto();

			putGetDtoResponse.setPuerto(putGetSaveRequest.getWebServiceRequest().getWsportPutGet());
			putGetDtoResponse.setServidor(putGetSaveRequest.getWebServiceRequest().getWsipserverPutGet());
			putGetDtoResponse.setDirectorio(putGetSaveRequest.getWebServiceRequest().getWsrutaPut());
			putGetDtoResponse.setDirectorioGet(putGetSaveRequest.getWebServiceRequest().getWsrutaGet());
			putGetDtoResponse.setPatron(putGetSaveRequest.getWebServiceRequest().getWspatronPutGet());
			putGetDtoResponse.setPatronGet(putGetSaveRequest.getWebServiceRequest().getWspatronGetPutGet());
			putGetWSDto.setUriPUTWS(putGetSaveRequest.getWebServiceRequest().getWsuriPut());
			putGetWSDto.setUriGETWS(putGetSaveRequest.getWebServiceRequest().getWsuriGet());
			putGetWSDto.setUriConsultaWS(putGetSaveRequest.getWebServiceRequest().getWsurldestPutGet());
			putGetWSDto.setCertificadoWS(putGetSaveRequest.getWebServiceRequest().getWscertPutGet());

			putGetDtoResponse.setPutGetWSDto(putGetWSDto);

		}

//		putGetServiceResponse.setNumeroContrato(putGetRequest.getNumeroContrato());

		return putGetServiceResponse;
	}

	/**
	 * @param putGetRestResponse
	 */
	private void getParamLstOs(PutGetRestResponse putGetRestResponse) {

		String valorParamResult = iContractConnectionManagementPutGetEntityManagerRepository.getParameters("H2H_PA_OS");

		if(StringUtils.isNotBlank(valorParamResult)){

			//dividimos por -
			String[] sodiv = valorParamResult.split("-");

			List<CatalogStatusResponse> catalogos = new ArrayList<CatalogStatusResponse>();

			for (int i = 0; i < sodiv.length; i++) {

				CatalogStatusResponse catalogo = new CatalogStatusResponse();

				catalogo.setDescripcionCatalogo(sodiv[i]);
				catalogo.setType(sodiv[i]);

				catalogos.add(catalogo);

			}

			putGetRestResponse.getPutGetResponse().setLstOs(catalogos);

		}

	}

}
