package mx.santander.h2h.monitoreo.repository;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import mx.santander.h2h.monitoreo.commons.utils.ConsultaTrackingUtil;
import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import mx.santander.h2h.monitoreo.model.response.ProductoArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ResultTrackingResponse;

@Repository
public class ConsultaTrackingProductoRepository implements IConsultaTrackingProductoRepository {
	@Autowired
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public ResultTrackingResponse obtenerCatalogoProductos() {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder = ConsultaTrackingUtil.queryObtenerProductos();
		
		Query query = entityManager.createNativeQuery(queryBuilder.toString());
		
		List<Object[]> resultQueryProductos = query.getResultList();
		
		List<ComboResponse> listCombo = new ArrayList<ComboResponse>();
		
		if (resultQueryProductos != null) {
			for (Object[] map : resultQueryProductos) {
				ComboResponse bean = new ComboResponse();
				bean.setId(((Integer)map[0]));
				bean.setValor((String)map[1]);
				listCombo.add(bean);
			}
		}
		
		resultTrackingResponse.setListCombo(listCombo);
		return resultTrackingResponse;
	}

	@Override
	public ResultTrackingResponse obtenerCatalogoEstatus(String tipoStatus) {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder = ConsultaTrackingUtil.queryObtenerCatalogos();
		
		Query query = entityManager.createNativeQuery(queryBuilder.toString());
		setParamsObtenerCatalogos(tipoStatus, query);
		
		List<Object[]> resultQueryCatalogos = query.getResultList();
		
		List<ComboResponse> listCombo = new ArrayList<ComboResponse>();
		
		if (resultQueryCatalogos != null) {
			for (Object[] map : resultQueryCatalogos) {
				ComboResponse bean = new ComboResponse();
				bean.setId((Integer)map[0]);
				bean.setValor((String)map[1]);
				listCombo.add(bean);
			}
		}
		
		resultTrackingResponse.setListCombo(listCombo);
		
		return resultTrackingResponse;
	}
	
	
	public void setParamsObtenerCatalogos(String tipoEstatus, Query query) {
		query.setParameter("tipoEstatus", tipoEstatus);
	}

	@Override
	public ResultTrackingResponse obtenerConteoArchivo(String codCliente, Integer idArchivo) {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder = queryObtenerConteoArchivos();
		
		Query query = entityManager.createNativeQuery(queryBuilder.toString());
		setParamsObtenerConteoArchivos(codCliente, idArchivo, query);
		
		List<Object[]> resultQueryConteoArchivos = query.getResultList();
		
		ProductoArchivoResponse productoArchivoResponse = new ProductoArchivoResponse();
		
		if (resultQueryConteoArchivos != null) {
			for (Object[] map : resultQueryConteoArchivos) {
				productoArchivoResponse.setNombreArchivo((String)map[0]);
				productoArchivoResponse.setFechaRecep((String)map[2]);
				productoArchivoResponse.setEstatus((String)map[1]);
				if(map[3] == null) {
					productoArchivoResponse.setTotalOperaciones(0);
				}else {
					BigInteger totalOperaciones = new BigInteger(map[3].toString());
					productoArchivoResponse.setTotalOperaciones(totalOperaciones.intValue());
				}
				productoArchivoResponse.setMonto((BigDecimal)map[4]);
			}
		}
		
		resultTrackingResponse.setArchProd(productoArchivoResponse);
		
		return resultTrackingResponse;
	}
	
	public StringBuilder queryObtenerConteoArchivos() {
		StringBuilder querySql = new StringBuilder()
				
		.append("SELECT A.NOMBRE_ARCH as NOMBRE_ARCH, ")
		.append("B.DESC_ESTATUS AS DESC_ESTATUS, ")
		.append("TO_CHAR(A.FECHA_REGISTRO,'dd/mm/yyyy hh24:mi:ss') AS FECHA_ARCH, ")
		.append("A.TOTA_OPER as NUM_OP, A.TOTA_MONT as IMP_OP ")
		.append("FROM h2h_archivo_tran A, ")
		.append(" h2h_cat_estatus B, h2h_cntr C, h2h_clte D ")
		.append("WHERE B.id_cat_estatus = A.id_estatus ")
		.append(" and A.id_cntr = C.id_cntr ")
		.append(" and C.id_clte = D.id_clte ")
		.append("AND D.buc = :codCliente ")
		.append("AND A.ID_ARCHIVO = :idArchivo");
		
		return querySql;
	}
	
	public void setParamsObtenerConteoArchivos(String codCliente, Integer idArchivo, Query query) {
		query.setParameter("codCliente", codCliente);
		query.setParameter("idArchivo", idArchivo);
	}

	@Override
	public Page<ProductoArchivoResponse> obtenerDetalleArchivo(Pageable page, Integer idArchivo, Integer idProducto, Integer idEstatus) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder = queryObtenerDetalleArchivos(idProducto, idEstatus);
		
		Query query = entityManager.createNativeQuery(queryBuilder.toString());
		this.setParamsObtenerDetalleArchivos(idArchivo, idProducto, idEstatus, query);
		
		query.setFirstResult(page.getPageNumber() * page.getPageSize());
		query.setMaxResults(page.getPageSize());
		
		List<Object[]> detalleArchivosResult = query.getResultList();
		
		List<ProductoArchivoResponse> lista = new ArrayList<ProductoArchivoResponse>();
		if (detalleArchivosResult != null) {
			for (Object[] map : detalleArchivosResult) {
				ProductoArchivoResponse bean = new ProductoArchivoResponse();
				bean.setIdProducto((Integer)map[0]);
				bean.setProducto((String)map[2]);
				bean.setTotalOperaciones(((BigDecimal)map[4]).intValue());
				bean.setIdEstatus((Integer)map[1]);
				bean.setEstatus((String)map[3]);
				bean.setMonto((BigDecimal)map[5]);
				lista.add(bean);
			}
		}
		
		for (int i = 0; i < lista.size(); i++) {
			lista.get(i).setMontoFmt(ConsultaTrackingUtil.formateaImporteProducto(lista.get(i).getMonto()));
			//lista.get(i).setMontoFmt(UtilGenericError.getLabelFront(bean.getListaDetalle().get(i).getMontoFmt())); // leyenda                                                                                                    // sfg
        }
		
		query.setFirstResult(0);
		query.setMaxResults(Integer.MAX_VALUE);
		
		Integer totalRows = query.getResultList().size();
		return new PageImpl<>(lista, page, totalRows);
	}
	
	public StringBuilder queryObtenerDetalleArchivos(Integer idProducto, Integer idEstatus) {
		StringBuilder querySql = new StringBuilder()
				
		.append("SELECT C.id_prod as ID_PROD, A.id_estatus, ")
		.append(" C.DESC_PROD as DESC_PROD, B.DESC_ESTATUS as DESC_ESTATUS, ")
		.append(" count(*) as NUM_OP, sum(mont) as IMP_OP ")
		.append(" FROM h2h_reg_tran A, ")
		.append(" h2h_cat_estatus B, ")
		.append(" h2h_cat_prod C ")
		.append(" WHERE A.id_estatus = B.id_cat_estatus ")
		.append(" AND A.cve_prod_oper = C.cve_prod_oper ")
		.append(" AND A.id_arch = :idArchivo");
		if (idProducto != null && idProducto > 0) {
			querySql.append(" AND C.id_prod = :idProducto");
		}
		if (idEstatus != null && idEstatus > 0) {
			querySql.append(" AND B.id_cat_estatus = :idEstatus");
		}
		querySql.append(" group by C.id_prod, C.DESC_PROD,A.id_estatus, B.DESC_ESTATUS ");
		querySql.append(" order by B.DESC_ESTATUS ");
		
		return querySql;
	}
	
	public void setParamsObtenerDetalleArchivos(Integer idArchivo, Integer idProducto, Integer idEstatus, Query query) {
		query.setParameter("idArchivo", idArchivo);
		if (idProducto != null && idProducto > 0) {
			query.setParameter("idProducto", idProducto);
		}
		if (idEstatus != null && idEstatus > 0) {
			query.setParameter("idEstatus", idEstatus);
		}
	}

	@Override
	public List<ProductoArchivoResponse> obtenerListDetalleArchivo(Integer idArchivo, Integer idProducto, Integer idEstatus) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder = queryObtenerDetalleArchivos(idProducto, idEstatus);
		
		Query query = entityManager.createNativeQuery(queryBuilder.toString());
		this.setParamsObtenerDetalleArchivos(idArchivo, idProducto, idEstatus, query);
		
		List<Object[]> detalleArchivosResult = query.getResultList();
		
		List<ProductoArchivoResponse> lista = new ArrayList<ProductoArchivoResponse>();
		if (detalleArchivosResult != null) {
			for (Object[] map : detalleArchivosResult) {
				ProductoArchivoResponse bean = new ProductoArchivoResponse();
				bean.setIdProducto((Integer)map[0]);
				bean.setProducto((String)map[2]);
				BigInteger totalOperaciones = new BigInteger(map[4].toString());
				bean.setTotalOperaciones(totalOperaciones.intValue());
				bean.setIdEstatus((Integer)map[1]);
				bean.setEstatus((String)map[3]);
				bean.setMonto((BigDecimal)map[5]);
				lista.add(bean);
			}
		}
		
		for (int i = 0; i < lista.size(); i++) {
			lista.get(i).setMontoFmt(ConsultaTrackingUtil.formateaImporteProducto(lista.get(i).getMonto()));
			//lista.get(i).setMontoFmt(UtilGenericError.getLabelFront(bean.getListaDetalle().get(i).getMontoFmt())); // leyenda                                                                                                    // sfg
        }
		
		return lista;
	}
}
