package mx.santander.h2h.monitoreo.util;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;

@Slf4j
public class UtilOrdenesPagoAtmDatosExportarNew {

	/** Constante CERO */
	protected static final String CERO = "0";
	
	/**
	 * Constante para la exportacion
	 *  del Monotor de operaciones
	 * PART_QUERY_EXP_NULL´s
	 */
	private static final String PART_QUERY_EXP_NULL="NULL BUC_EMPLEADO,NULL SUCURSAL_TUTORA,NULL RFC,NULL TIPO,NULL NOMBRE_EMPLEADO,  ";
	
	/**
	 * Constante para la exportacion
	 *  del Monotor de operaciones
	 * PART_QUERY_EXP_FECH_APLI_FECHA_OPERACION
	 */
	private static final String PART_QUERY_EXP_FECH_APLI_FECHA_OPERACION="NULL NUMERO_CUENTA,TMP.FECH_OPER FECHA_PRESENTACION_INICIAL, TMP.FECH_APLI FECHA_OPERACION  ";
	
	/** Constante producto proveedor confirming */
	protected static final String PROD_PROV_CONFIRMING = "11";
	
	/**
	 * Parte del Query para el acceso a datos
	 * del detalle a exportar del producto
	 * de Transferencias Vostro Mismo Banco
	 * TVMB
	 */
	private static final StringBuilder QUERY_EXP_MONITOR_OREDENES_PAGO_ATM=new StringBuilder("")
	.append("NOMB_CANL, ID_REG, CLTE.BUC, TMP.CNTA_CARG NUM_CTA_CARGO,null NUN_CTA_ABONO, ")
	.append("PROD.CVE_PROD_OPER, PROD.DESC_PROD,TMP.NOMBRE_ARCH,DETA.REFE_CTE REFERENCIA,TMP.ID_ESTATUS, EST.DESC_ESTATUS DESC_ESTATUS, ")
	.append("DETA.IMPO_GIRO IMPORTE, CNTR.NUM_CNTR, TMP.DIVI DIVISA,DETA.FECH_REG FECHA_REGISTRO, TMP.FECH_APLI FECHA_APLICACION,")
	.append("PROD.VIST_PROD,' ' INTERMEDIARIO_ORD,null DIVISA_ORD,null INTERMEDIARIO_REC, (DETA.NOMB_BENE) BENEFICIARIO,")
	.append("null COMENTARIO_1,to_char(ID_REG) COMENTARIO_2,NULL COMENTARIO_3, null TITULAR, NULL BANCO_RECEPTOR, ")
	.append("'E' TIPO_PAGO, NULL MODALIDAD,null IMPORTE_CARGO, MSG.MSG_H2H MSG_H2H, NULL MSG_ORDEN_PAGO, ")
	.append("DECODE( PROD.CVE_PROD_OPER,85, DECODE(DETA.NUM_ORDN,null,'' ,'****'|| SUBSTRB(DETA.NUM_ORDN,-4,4)), DETA.NUM_ORDN) NUM_ORDEN,FECH_LIMI_LIQ FECHA_LIMITE_PAGO,NULL NUM_SUCURSAL,NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA,  ")
	.append(PART_QUERY_EXP_NULL)
	.append(PART_QUERY_EXP_FECH_APLI_FECHA_OPERACION);
	
	/**
	 * Tabla para los campos
	 * del Query de la exportacion
	 * de datos del monitor
	 * de operaciones
	 */
	private static Map<String,String> tablasSelCamposExpMonitor= new HashMap<String,String>();
	
	/**
	 * inicializacion del mapa de productos
	 * LFER 09-03-2018
	 */
	static{
		tablasSelCamposExpMonitor.put("85", QUERY_EXP_MONITOR_OREDENES_PAGO_ATM.toString());
	}

	/**
	 * 
	 * @param tipoOper
	 * @return
	 */
	public static boolean esOrdenPago(String tipoOper) {
		if(tipoOper==null ||tipoOper.isEmpty()){
			return false;
		}
		return tipoOper.toUpperCase().contains("85");
	}
	
	/**
	 * 
	 * @param cveOperProd
	 * @param query
	 */
	public static String getQuerySelectExportar(String cveOperProd, StringBuilder queryS) {
		StringBuilder querySL = new StringBuilder();
		log.info("getQuerySelectExportar - Inicia esOrderPago: " + cveOperProd);
		if(esOrdenPago(cveOperProd)){
			queryS.setLength(0);
			querySL.append("SELECT PROD.* FROM (SELECT ");
			querySL.append( tablasSelCamposExpMonitor.get(cveOperProd));
		}
		log.info("getQuerySelectExportar - Termino esOrderPago: " + querySL.toString());
		return querySL.toString();
	}
	
	/**
	 * Agrega el where de parametros de consulta.
	 * @param consultaOperaciones DTO de restricciones
	 * @param someFilter de tipo Boolean
	 * @return String gener el where de la cosnulta
	 */
	public static String getWhereConsultaOperacionesCont(OperationsMonitorQueryRequest consultaOperaciones, Map<String, Object> params, boolean someFilter){
		log.info("Entro a metodo UtilOrdenesPagoAtmDatosExportarNew - getWhereConsultaOperacionesCont");
		final StringBuilder queryW = new StringBuilder();
		if (consultaOperaciones.getBuc() != null && !StringUtils.EMPTY.equals(consultaOperaciones.getBuc())) {		
			queryW.append(someFilter ? "AND PROD.BUC = '" : "PROD.BUC = '").append(consultaOperaciones.getBuc()).append("' ");
			someFilter = true;
		}
		if (consultaOperaciones.getContrato() != null && !StringUtils.EMPTY.equals(consultaOperaciones.getContrato())) {	
			queryW.append(someFilter ? "AND PROD.NUM_CNTR = '" : "PROD.NUM_CNTR = '").append(consultaOperaciones.getContrato()).append("' ");
			someFilter = true;
		}
		if (!StringUtils.EMPTY.equals(consultaOperaciones.getNombreArchivo()) && consultaOperaciones.getNombreArchivo() != null) {
			queryW.append(someFilter ? "AND UPPER(PROD.NOMBRE_ARCH) LIKE '%" : "UPPER(PROD.NOMBRE_ARCH) LIKE '%")
				 .append(consultaOperaciones.getNombreArchivo().toUpperCase()).append("%' ");
			someFilter = true;
		}
		if (!CERO.equals(consultaOperaciones.getIdProducto()) && consultaOperaciones.getIdProducto() != null) {
			
			queryW.append(someFilter ?  "AND PROD.CVE_PROD_OPER = '" : "PROD.CVE_PROD_OPER = '").append(consultaOperaciones.getIdProducto()).append("' ");
			someFilter = true;
		}
		if(!CERO.equals(consultaOperaciones.getIdEstatus()) && consultaOperaciones.getIdEstatus() != null) {
			queryW.append(someFilter ? "AND PROD.ID_ESTATUS = " : "PROD.ID_ESTATUS = ").append(consultaOperaciones.getIdEstatus()).append(" ");
			someFilter = true;
		}
		if (consultaOperaciones.getCuentaCargo() != null && !StringUtils.EMPTY.equals(consultaOperaciones.getCuentaCargo())) {
			queryW.append(someFilter ? "AND TRIM(PROD.NUM_CTA_CARGO) = '": "PROD.NUM_CTA_CARGO = '").append(consultaOperaciones.getCuentaCargo()).append("' ");
			someFilter = true;
		}
		if (consultaOperaciones.getCuentaAbono() != null && !StringUtils.EMPTY.equals(consultaOperaciones.getCuentaAbono())) {
			queryW.append(someFilter ? "AND TRIM(PROD.NUN_CTA_ABONO) = '" : "PROD.NUN_CTA_ABONO = '").append(consultaOperaciones.getCuentaAbono()).append("' ");
			someFilter = true;
		}
		if (consultaOperaciones.getImporte() != null && !StringUtils.EMPTY.equals(consultaOperaciones.getImporte())) {
			queryW.append(someFilter ? "AND PROD.IMPORTE = '" : "PROD.IMPORTE = '").append(consultaOperaciones.getImporte()).append("' ");
			someFilter = true;
		}
		if (consultaOperaciones.getReferencia() !=  null && StringUtils.isNotEmpty(consultaOperaciones.getReferencia())) {	
			final String referenciaTmp = ((consultaOperaciones.getReferencia()).trim()).replaceFirst("^0*", StringUtils.EMPTY);
			queryW.append(someFilter ? "AND REGEXP_LIKE (PROD.REFERENCIA, '^0*" : " REGEXP_LIKE (PROD.REFERENCIA, '^0*").append(referenciaTmp).append("') ");
			someFilter = true;
		}
		log.info("Termino metodo UtilOrdenesPagoAtmDatosExportarNew - getWhereConsultaOperacionesCont");
		return queryW.toString();
	}
	
	/**
	 * 
	 * @param query query a modificar
	 * @param consultaOperaciones dto
	 * @param exportar validacion
	 */
	public static String agregaQueryPIF(StringBuilder querys, OperationsMonitorQueryRequest consultaOperaciones, Map<String, Object> params, boolean exportar) {
		StringBuilder query = new StringBuilder();
		if(isPif(consultaOperaciones)){
			if( !UtilData.isVacio(consultaOperaciones.getLineaCaptura()) && consultaOperaciones.getLineaCaptura() != null 
					&& consultaOperaciones.getLineaCaptura().length() > 0) {
				query.append("AND PIF.OBSE_ABO like (" + consultaOperaciones.getLineaCaptura() + "'%') ");
//				params.put("lineaCaptura", consultaOperaciones.getLineaCaptura());
			}
			if ( !UtilData.isVacio(consultaOperaciones.getConvenio()) && consultaOperaciones.getConvenio() != null) {
				if (exportar) {
					query.append("AND PROD.COMENTARIO_1 = " + consultaOperaciones.getConvenio());
				} else {
					query.append("AND PIF.CLVE_CONV = " + consultaOperaciones.getConvenio());
				}
//				params.put("convenio", consultaOperaciones.getConvenio());
			}
			if ( UtilData.esIgual(consultaOperaciones.getIdProducto(), "23")) {
				if ( !UtilData.isVacio(consultaOperaciones.getFolioSUA()) && consultaOperaciones.getFolioSUA() != null
						 && consultaOperaciones.getFolioSUA().length()>0) {
					query.append(exportar ? "AND UPPER(PROD.COMENTARIO_3) LIKE UPPER('%'" + consultaOperaciones.getFolioSUA() + "'%') " : 
						"AND UPPER(PIF.NUME_FOLI_SUA) LIKE UPPER('%'" + consultaOperaciones.getFolioSUA() + "'%') ");
//					if (exportar) {
//						query.append("AND UPPER(PROD.COMENTARIO_3) LIKE UPPER('%' || :folioSUA || '%') ");
//					} else {
//						query.append("AND UPPER(PIF.NUME_FOLI_SUA) LIKE UPPER('%' || :folioSUA || '%') ");
//					}
//					params.put("folioSUA", consultaOperaciones.getFolioSUA());
				}
				if ( !UtilData.isVacio(consultaOperaciones.getRegPat()) && consultaOperaciones.getRegPat() != null
						 && consultaOperaciones.getRegPat().length()>0) {
					query.append(exportar ? "AND UPPER(PROD.COMENTARIO_2) " : "AND UPPER(PIF.REG_PATR) ");
//					if (exportar) {
//						query.append("AND UPPER(PROD.COMENTARIO_2) ");
//							
//					} else {
//						query.append("AND UPPER(PIF.REG_PATR) ");
//					}
					query.append("like UPPER('%'" + consultaOperaciones.getRegPat() + "'%') ");
//					params.put("consOperRegPat", consultaOperaciones.getRegPat());
				}
			}
		}
		return query.toString();
	}
	
	/**
	 * Verifica si el producto es Pagos de impuestos federales, 
	 *  
	 * @param consultaOperaciones parametros de la consulta operaciones
	 * @return boolean valor del tipo de prodcuto
	 */
	public static boolean isPif(OperationsMonitorQueryRequest consultaOperaciones){
		return "21".equals(consultaOperaciones.getIdProducto()) || "22".equals(consultaOperaciones.getIdProducto())
		|| "23".equals(consultaOperaciones.getIdProducto());
	}
	
	/**
	 * Metodo para validar el campo PIF2
	 * 
	 * @param consultaOperaciones
	 * @param query
	 * @param params
	 * @param someFilter
	 */
	public static String isPif2( OperationsMonitorQueryRequest consultaOperaciones, StringBuilder querys, Map<String, Object> params, boolean someFilter) {
		StringBuilder query = new StringBuilder();
		log.info("Entro al metodo isPif2");
		if (consultaOperaciones.getNumeroOrden()!= null && !StringUtils.EMPTY.equals(consultaOperaciones.getNumeroOrden())) {		
			query.append(someFilter ? "AND PROD.NUM_ORDEN = " : "PROD.NUM_ORDEN = ").append(consultaOperaciones.getNumeroOrden()).append(" ");
//			params.put("numeroOrden", consultaOperaciones.getNumeroOrden());
			someFilter = true;
		}
		if (consultaOperaciones.getNombreBeneficiario() != null && !StringUtils.EMPTY.equals(consultaOperaciones.getNombreBeneficiario())) {	
			query.append(someFilter ? "AND UPPER(PROD.BENEFICIARIO)  LIKE '%'" : "UPPER(PROD.BENEFICIARIO)  LIKE '%' ")
				.append(consultaOperaciones.getNombreBeneficiario()).append("'%'   ");
//			params.put("nombreBeneficiario", consultaOperaciones.getNombreBeneficiario());
			someFilter = true;
		}
		//Falta la parte de personalidad
//		if (consultaOperaciones.getPersonaAutorizada() != null && !StringUtils.EMPTY.equals(consultaOperaciones.getPersonaAutorizada())) {	
//			query.append(someFilter ? "AND UPPER(PROD.NOMB_PERS_AUT_EXT)  LIKE '%" : "UPPER(PROD.NOMB_PERS_AUT_EXT)  LIKE '%")
//				.append(consultaOperaciones.getPersonaAutorizada()).append("%' ");
//			someFilter = true;
//		}
		log.info("ID REG: " + consultaOperaciones.getIdReg());
		if (consultaOperaciones.getIdReg() != null && !StringUtils.EMPTY.equals(consultaOperaciones.getIdReg())) {		
			query.append(someFilter ? "AND PROD.ID_REG = " : "PROD.ID_REG = ").append(consultaOperaciones.getIdReg()).append(" ");
//			params.put("idReg", consultaOperaciones.getIdReg());
			someFilter = true;
		}
		
		if (consultaOperaciones.getNumEmpleado() != null && !StringUtils.EMPTY.equals(consultaOperaciones.getNumEmpleado())	&& !PROD_PROV_CONFIRMING.equals(consultaOperaciones.getIdProducto())) {		
			query.append(someFilter ? "AND TRIM(PROD.NUMERO_EMPLEADO) = " : "PROD.NUMERO_EMPLEADO = ").append(consultaOperaciones.getNumEmpleado()).append(" ");
//			params.put("numEmpleado", consultaOperaciones.getNumEmpleado());
			someFilter = true;
		}
		if (consultaOperaciones.getNumTarjeta() != null && !StringUtils.EMPTY.equals(consultaOperaciones.getNumTarjeta()) && !PROD_PROV_CONFIRMING.equals(consultaOperaciones.getIdProducto())) {		
			query.append(someFilter ? "AND TRIM(PROD.NUMERO_TARJETA) = " : "PROD.NUMERO_TARJETA = ").append(consultaOperaciones.getNumTarjeta()).append(" ");
//			params.put("numTarjeta", consultaOperaciones.getNumTarjeta());
			someFilter = true;
		}
		if (consultaOperaciones.getSucTutora() != null && !StringUtils.EMPTY.equals(consultaOperaciones.getSucTutora()) && !PROD_PROV_CONFIRMING.equals(consultaOperaciones.getIdProducto())) {		
			query.append(someFilter ? "AND TRIM(PROD.SUCURSAL_TUTORA) = " : "PROD.SUCURSAL_TUTORA = ").append(consultaOperaciones.getSucTutora()).append(" ");
//			params.put("sucTutora", consultaOperaciones.getSucTutora());
			someFilter = true;
		}
		if (consultaOperaciones.getTipo() != null && !CERO.equals(consultaOperaciones.getTipo())) {
			if ("PREEXISTENTE".equals(consultaOperaciones.getTipo())){
				query.append(someFilter ? "AND PROD.TIPO IS NOT NULL " : "PROD.TIPO IS NOT NULL ");
			} else {
				query.append(someFilter ? "AND PROD.TIPO IS NULL " : "PROD.TIPO IS NULL ");
			}
			someFilter = true;
		}
		log.info("Querie isPif2: " + query.toString());
		return query.toString();
	}
}
