package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.constants.QueryConstant;
import mx.santander.h2h.monitoreo.model.entity.ContractEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Interfaz de repositori para los contratos
 * extendiendo de JPA para hacer una persitencia
 * entre la tabla Contrato y el objeto ContarcEntity
 * @author NTTDATA-NRL
 * @version 1.0
 */
public interface IContractRepository extends JpaRepository<ContractEntity, Long> {

    /**
     * Metodo para hacer la busqueda de contratos por buc y estatus
     * @param bucCliente buc del cliente
     * @param idEstatus estatus
     * @return List<Object[]>
     */
    @Query(nativeQuery = true, value = QueryConstant.CNTR_NO_CANCELADO_POR_BUC)
    List<Object[]> findCntrByBUCAndEstatus(@Param("bucCliente") String bucCliente, @Param("idEstatus") int idEstatus);
}
