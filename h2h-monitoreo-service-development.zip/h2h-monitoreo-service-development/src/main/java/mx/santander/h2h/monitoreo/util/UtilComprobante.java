package mx.santander.h2h.monitoreo.util;

import org.apache.commons.lang.StringUtils;

import java.util.List;

/**
 * @author Z484929
 * Clase Utileria para obtener los querys del comprobante.
 */
public final class UtilComprobante {

    /** Constante vista producto confirmming. */
    private static final String H2H_PROD_ALTA_PAGO = "H2H_PROD_ALTA_PAGO";
    /** Constante vista producto SPEI NI TEF. */
    private static final String H2H_PROD_TRAN = "H2H_PROD_TRAN";
    /** Constante vista producto . */
    private static final String H2H_PROD_NOMI_MISM_BANC = "H2H_PROD_NOMI_MISM_BANC";
    /** Constante vista producto . */
    private static final String H2H_PROD_ORDN_PAGO = "H2H_PROD_ORDN_PAGO";
    /** Constante vista producto . */
    private static final String H2H_PROD_TRAN_MISM_BANC = "H2H_PROD_TRAN_MISM_BANC";
    /** Constante vista Impuestos Federales . */
    private static final String H2H_PROD_IMPU_FEDE = "H2H_PROD_IMPU_FEDE";
    /** Constante vista PAgo Referenciados. */
    private static final String H2H_PROD_PAGO_REFE = "H2H_PROD_PAGO_REFE";
    /** Constante vista producto Transferencias Internacionales. */
    private static final String H2H_MX_PROD_TRAN_INTN = "H2H_MX_PROD_TRAN_INTN";
    /** Constante vista producto Transferencias mismo banco. */
    private static final String H2H_MX_PROD_BANC_CAMB = "H2H_MX_PROD_BANC_CAMB";
    /** Constante vista producto Aportaciones Obrero Patronales. */
    private static final String H2H_PROD_APO_OBRE_PATR = "H2H_PROD_APO_OBRE_PATR";
    /** Constante vista producto Pago de Impuestos Aduanales*/
    private static final String H2H_MX_PROD_PECE = "H2H_MX_PROD_PECE";
    /**INNER JOIN H2H_REG r ON r.id_reg = nmb.id_reg **/
    protected static final String INNER_JOIN_H2H_REG_R_ON_R_ID_REG_NMB_ID_REG=" INNER JOIN H2H_REG r ON r.id_reg = nmb.id_reg ";
    /**INNER JOIN H2H_CAT_PROD ct ON r.cve_prod_oper = ct.cve_prod_oper*/
    protected static final String INNER_JOIN_H2H_CAT_PROD_CT_ON_R_CVE_PROD_OPER_CT_CVE_PRODOPER=" INNER JOIN H2H_CAT_PROD ct ON r.cve_prod_oper = ct.cve_prod_oper  ";
    /**INNER_JOIN_H2H_ARCHIVO_A_ON_R_ID_ARCH_A_ID_ARCHIVO*/
    protected static final String INNER_JOIN_H2H_ARCHIVO_A_ON_R_ID_ARCH_A_ID_ARCHIVO=" INNER JOIN H2H_ARCHIVO a ON r.id_arch = a.id_archivo    ";
    /**LEFT JOIN H2H_ARCH_BACK abt ON  r.id_arch_be = abt.id_arch_back */
    protected static final String LEFT_JOIN_H2H_ARCH_BACK_ABT_ON_R_ID_ARCH_BE_ABT_ID_ARCH_BACK=" LEFT JOIN H2H_ARCH_BACK abt ON  r.id_arch_be = abt.id_arch_back  ";
    /**" INNER JOIN H2H_CNTR cntr ON cntr.id_cntr = a.id_cntr    "*/
    protected static final String INNER_JOIN_H2H_CNTR_CNTR_ON_CNTR_ID_CNTR_A_ID_CNTR=" INNER JOIN H2H_CNTR cntr ON cntr.id_cntr = a.id_cntr    ";
    /**INNER JOIN H2H_CLTE clte ON cntr.id_clte = clte.id_clte
     * TCS (sonar) */
    protected static final String INNER_JOIN_H2H_CLTE_CLTE_ON_CNTR_ID_CLTE_CLTE_ID_CLTE=" INNER JOIN H2H_CLTE clte ON cntr.id_clte = clte.id_clte ";
    /**INNER JOIN H2H_CAT_ESTATUS ce ON r.id_estatus = id_cat_estatus*/
    protected static final String INNER_JOIN_H2H_CAT_ESTATUS_CE_ON_R_ID_ESTATUS_ID_CAT_ESTATUS=" INNER JOIN H2H_CAT_ESTATUS ce ON r.id_estatus = id_cat_estatus";
    /** LEFT JOIN H2H_CTA_INFO cc ON r.CNTA_CARG = cc.NUME_CTA AND cc.TIPO_CTA = 'O' **/
    protected static final String LEFT_JOIN_H2H_CTA_INFO_CC_ON_R_CNTA_CARG_CC_NUME_CTA_AND_CC_TIPO_CTA_O=" LEFT JOIN H2H_CTA_INFO cc ON r.CNTA_CARG = cc.NUME_CTA AND cc.TIPO_CTA = 'O' ";
    /**" UNION ALL "*/
    protected static final String UNION_ALL=" UNION ALL ";
    /**INNER JOIN H2H_REG_TRAN r ON r.id_reg = nmb.id_reg*/
    protected static final String INNER_JOIN_H2H_REG_TRAN_R_ON_R_ID_REG_NMB_ID_REG=" INNER JOIN H2H_REG_TRAN r ON r.id_reg = nmb.id_reg      ";
    /** INNER JOIN H2H_ARCHIVO_TRAN a ON r.id_arch = a.id_archivo */
    protected static final String INNER_JOIN_H2H_ARCHIVO_TRAN_A_ON_R_ID_ACRCH_A_ID_ARCHIVO=" INNER JOIN H2H_ARCHIVO_TRAN a ON r.id_arch = a.id_archivo         ";
    /**LEFT JOIN H2H_ARCH_BACK_TRAN abt ON  r.id_arch_be = abt.id_arch_back  */
    protected static final String LEFT_JOIN_H2H_ARCH_BACK_TRAN_ABT_ON_R_ID_ARCHBE_ABT_ID_ARCH_BAK=" LEFT JOIN H2H_ARCH_BACK_TRAN abt ON  r.id_arch_be = abt.id_arch_back  ";
    /**CLTE_PERSONALIDADCLTE_RFC_CNTR_NUM_CNTR*/
    protected static final String CLTE_PERSONALIDADCLTE_RFC_CNTR_NUM_CNTR="clte.PERSONALIDAD, clte.RFC,cntr.NUM_CNTR,";
    /**SELECT r.ID_REG, */
    protected static final String SELECT_R_ID_REG="SELECT r.ID_REG, ";
    /** cntr.NUM_CNTR CONTRATO,  */
    protected static final String CNTR_NUM_CNTR_CONTRATO="  cntr.NUM_CNTR CONTRATO,  ";
    /** ct.DESC_PROD,
     * TCS (sonar) **/
    protected static final String CT_DESC_PROD="  ct.DESC_PROD,  ";
    /**r.mont IMPORTE,*/
    protected static final String R_MONT_IMPORTE="  r.mont IMPORTE,";
    /** ce.DESC_ESTATUS,*/
    protected static final String CE_DESC_ESTATUS="  ce.DESC_ESTATUS,         ";
    /** NULL TIPO_PAGO,*/
    protected static final String NULL_TOPO_PAGO="  NULL TIPO_PAGO,";
    /** NULL CLAVE_RASTREO,      */
    protected static final String NULL_CLAVE_RASTREO="  NULL CLAVE_RASTREO,      ";
    /** NULL BANCO_RECEPTOR,  */
    protected static final String NULL_BANCO_RECEPTOR="  NULL BANCO_RECEPTOR,     ";
    /** r.FECH_ENVI_BACK FECHA_OPERACION,  */
    protected static final String R_FECH_ENVI_BACK_FECHA_OPERACION="  r.FECH_ENVI_BACK FECHA_OPERACION,  ";
    /**  NULL NUM_ORDEN,*/
    protected static final String NULL_NUM_ORDEN="  NULL NUM_ORDEN,";
    /**"  NULL FECHA_LIMITE_PAGO,  "*/
    protected static final String NULL_FECHA_LIMITE_PAGO="  NULL FECHA_LIMITE_PAGO,  ";
    /**  NULL NUM_SUCURSAL,  **/
    protected static final String NULL_NUM_SUCURSAL="  NULL NUM_SUCURSAL,       ";
    /** clte.RAZON_SCIA,         **/
    protected static final String CLTE_RAZON_SCIA="  clte.RAZON_SCIA,         ";
    /**  clte.PERSONALIDAD,**/
    protected static final String CLTE_PERSONALIDAD="  clte.PERSONALIDAD,       ";
    /**  clte.RFC, **/
    protected static final String CLTE_RFC="  clte.RFC,      ";
    /**  cntr.NUM_CNTR, **/
    protected static final String CNTR_NUM_CNTR="  cntr.NUM_CNTR,      ";
    /**"  NULL ID_ESTA,  "**/
    protected static final String NULL_ID_ESTA="  NULL ID_ESTA,  ";
    /**  NULL AS PERS_AUT, **/
    protected static final String NULL_AS_PERS_AUT="  NULL AS PERS_AUT,         ";
    /**INNER_JOIN_H2H_CAT_ESTATUS_CE_ON_R_ID_ESTATUS_ID_CATESTATUS*/
    protected static final String INNER_JOIN_H2H_CAT_ESTATUS_CE_ON_R_ID_ESTATUS_ID_CATESTATUS=" INNER JOIN H2H_CAT_ESTATUS ce ON r.id_estatus = id_cat_estatus    ";
    /** NULL AS FORM_APLI,     */
    protected static final String NULL_AS_FORM_APLI="  NULL AS FORM_APLI,         ";
    /**"  NULL NOMB_RAZON_SOCI_PROV, "*/
    protected static final String NULL_NOMB_RAZON_SOCI_PROV="  NULL NOMB_RAZON_SOCI_PROV, ";
    /** NULL RFC_PROV, */
    protected static final String NULL_RFC_PROV="  NULL RFC_PROV, ";
    /**  NULL BANC_ABON,*/
    protected static final String NULL_BANC_ABON="  NULL BANC_ABON, ";
    /**  NULL REFE_ABON,*/
    protected static final String NULL_REFE_ABON="  NULL REFE_ABON, ";
    /**  NULL TIPO_DOCU */
    protected static final String NULL_TIPO_DOCU="  NULL TIPO_DOCU ";
    /** LEFT JOIN H2H_CTA_INFO ca ON r.CNTA_ABON = ca.NUME_CTA AND ca.TIPO_CTA = 'B' */
    protected static final String LEFT_JOIN_H2H_CTA_INFO_CA_ON_R_CNTA_ABON_CA_NUME_CTA_AND_CA_TIPO_CTA_B=" LEFT JOIN H2H_CTA_INFO ca ON r.CNTA_ABON = ca.NUME_CTA AND ca.TIPO_CTA = 'B' ";
    /** r.CNTA_CARG NUM_CTA_CARGO,         */
    protected static final String R_CNTA_CARG_NUM_CTA_CARGO="  r.CNTA_CARG NUM_CTA_CARGO,         ";
    /**  r.CNTA_ABON NUN_CTA_ABONO, */
    protected static final String R_CNTA_ABON_NUN_CTA_ABONO="  r.CNTA_ABON NUN_CTA_ABONO,         ";
    /** NULL CLAV_PROV,*/
    protected static final String NULL_CLAV_PROV="  NULL CLAV_PROV,";
    /**  NULL NUM_DOCU, */
    protected static final String NULL_NUM_DOCU="  NULL NUM_DOCU, ";
    /**  NULL FECH_VENCIMIENTO,   */
    protected static final String NULL_FECH_VENCIMIENTO="  NULL FECH_VENCIMIENTO,   ";
    /**  NULL CVE_FORM_PAGO,   */
    protected static final String NULL_CVE_FORM_PAGO="  NULL CVE_FORM_PAGO,      ";
    /**  NULL ESTATUS_MOV,    */
    protected static final String NULL_ESTATUS_MOV="  NULL ESTATUS_MOV,        ";
    /**  clte.NOMBRE  || ' '  || clte.APPATERNO  || ' '  || clte.APMATERNO NOM_CLTE,*/
    protected static final String CLTE_NOMBRE_CLTE_APPATERNO_CLTE_APMATERNO_NOM_CLTE="  clte.NOMBRE  || ' '  || clte.APPATERNO  || ' '  || clte.APMATERNO NOM_CLTE,";
    /** Constante vista producto . */
    private static final String H2H_MX_PROD_PAGO_TDC = "H2H_MX_PROD_PAGO_TDC";
    /**  Fecha de aplicacion para producto NMB si es nulo el de archivo de backend obtenerlo de la tabla de producto**/
    private static final String TO_CHAR_ABT_FECH_RESP_BE_FECH_APLI_NMB="  DECODE(abt.FECH_RESP_BE,null,TO_CHAR(nmb.FECH_APLI,'dd/mm/yyyy hh24:mi:ss'),TO_CHAR(abt.FECH_RESP_BE,'dd/mm/yyyy hh24:mi:ss')) FECH_APLI,   ";

    /** Constructor privado de la clase. */
    private UtilComprobante() {	}

    /**
     * Obtiene el query correspondiente a la tabla solicitada.
     *
     * @param listIds
     *            List<Integer>
     * @param tabla
     *            String
     * @return String
     */
    public static String obtenerQueryTabla(List<Integer> listIds, String tabla) {
        String sql = "";
        if (StringUtils.isNotBlank(tabla)) {
            if (tabla.equals(H2H_PROD_ALTA_PAGO)) {
                sql = UtilComprobantePago.obtenerQueryProdAltaPago(listIds);
            }
            if (tabla.equals(H2H_PROD_TRAN)) {
                sql = obtenerQueryProdTran(listIds);
            }
            if (tabla.equals(H2H_PROD_NOMI_MISM_BANC)) {
                sql = obtenerQueryProdNomiMismBanc(listIds);
            }
            if (tabla.equals(H2H_PROD_ORDN_PAGO)) {
                sql = UtilComprobantePago.obtenerQueryProdOrdnPago(listIds);
            }
            if (tabla.equals(H2H_PROD_TRAN_MISM_BANC)) {
                sql = UtilComprobantePago.obtenerQueryProdTranMismBanc(listIds);
            }
            if (tabla.equals(H2H_PROD_IMPU_FEDE)) {
                sql = obtenerQueryImpFederales(listIds);
            }
            if (tabla.equals(H2H_PROD_PAGO_REFE)) {
                sql = UtilComprobantePago.obtenerQueryPagoRef(listIds);
            }
            if (tabla.equals(H2H_PROD_APO_OBRE_PATR)) {
                sql = obtenerQueryAportacionesPat(listIds);
            }
            if (tabla.equals(H2H_MX_PROD_TRAN_INTN)) {
                sql = UtilComprobanteTI.obtenerQueryTranasferenciasInernacionales(listIds);
            }
            if (tabla.equals(H2H_MX_PROD_BANC_CAMB)) {
                sql = UtilComprobanteTI.obtenerQueryTranasferenciasIntMBC(listIds);
            }
            if ("H2H_MX_PROD_SPID".equals(tabla)) {
                sql = UtilComprobanteSPID.obtenerQuerySpid(listIds);
            }
            if (tabla.equals(H2H_MX_PROD_PAGO_TDC)) {
                sql = UtilComprobantePago.obtenerQueryPagoTDC(listIds);
            }
            if ("H2H_MX_PROD_PAGO_DIR".equals(tabla)) { //PGODIRECT Inicio
                sql = UtilComprobantePD.obtenerQuery(listIds);
            } //PGODIRECT Fin
            if(tabla.equals(H2H_MX_PROD_PECE)) {
                sql = UtilComprobantePago.obtenerQueryPagoImpAduan(listIds);
            }
            sql=UtilVostroComprobantes.obtenerQuerys(listIds,tabla,sql);
            sql=UtilOrdenesPagoAtmComprobante.obtenerQuerys(listIds,tabla,sql);
        }
        return sql;
    }

    /**
     * Obtiene el query de Impuestos Federales Pago.
     *
     * @param listIds
     *            List<Integer>
     * @return String query
     */
    private static String obtenerQueryImpFederales(List<Integer> listIds) {
        final StringBuilder sql = new StringBuilder()
                .append("SELECT r.ID_REG, cntr.NUM_CNTR CONTRATO, r.CNTA_CARG NUM_CTA_CARGO,r.CNTA_ABON NUN_CTA_ABONO,")
                .append("ct.DESC_PROD, r.mont IMPORTE, NULL REFERENCIA, 'MXP' DIVISA, ce.DESC_ESTATUS,")
                .append("to_char(TO_DATE(trim(nmb.FECH_OPER), 'YYYY-MM-DD'),'DD/MM/YYYY')||' '||nmb.HORA_OPER FECH_APLI, null BENEFICIARIO,")
                .append("'INTERNET' TIPO_PAGO,nmb.BUC TITULAR,  nmb.OBSE_ABO CONCEPTO_PAGO, NULL CLAVE_RASTREO, NULL BANCO_RECEPTOR,r.FECH_ENVI_BACK FECHA_OPERACION,")
                .append("NULL CLAV_PROV,nmb.LLAV_PAGO NUM_DOCU,NULL FECH_VENCIMIENTO, NULL CVE_FORM_PAGO, '-'||trim(ct.CVE_PROD_OPER)||'-' ESTATUS_MOV, nmb.NUME_MOVI_ABO NUM_ORDEN, NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL,")
                .append(" nmb.NOMB_CLTE RAZON_SCIA,nmb.NOMB_CLTE NOM_CLTE,")
                // .append("DECODE(clte.PERSONALIDAD,'F',clte.NOMBRE  || ' '  || clte.APPATERNO  || ' '  || clte.APMATERNO,clte.RAZON_SCIA) RAZON_SCIA,nmb.NOMB_CLTE NOM_CLTE,")
                .append("clte.PERSONALIDAD, clte.RFC,cntr.NUM_CNTR, NULL CLAVE_BENEF,NULL ID_ESTA,NULL AS PERS_AUT,NULL AS FORM_APLI,nmb.NOMB_CLTE_BACK NOMB_RAZON_SOCI_PROV, NULL RFC_PROV,")
                .append("nmb.SUCU BANC_ABON, nmb.PLZA REFE_ABON, NULL TIPO_DOCU ")
                .append(" FROM H2H_PROD_IMPU_FEDE nmb  ")
                .append(INNER_JOIN_H2H_REG_R_ON_R_ID_REG_NMB_ID_REG)
                .append(INNER_JOIN_H2H_CAT_PROD_CT_ON_R_CVE_PROD_OPER_CT_CVE_PRODOPER)
                .append(INNER_JOIN_H2H_ARCHIVO_A_ON_R_ID_ARCH_A_ID_ARCHIVO)
                .append(LEFT_JOIN_H2H_ARCH_BACK_ABT_ON_R_ID_ARCH_BE_ABT_ID_ARCH_BACK)
                .append(INNER_JOIN_H2H_CNTR_CNTR_ON_CNTR_ID_CNTR_A_ID_CNTR)
                .append(INNER_JOIN_H2H_CLTE_CLTE_ON_CNTR_ID_CLTE_CLTE_ID_CLTE)
                .append(INNER_JOIN_H2H_CAT_ESTATUS_CE_ON_R_ID_ESTATUS_ID_CAT_ESTATUS)
                .append(LEFT_JOIN_H2H_CTA_INFO_CC_ON_R_CNTA_CARG_CC_NUME_CTA_AND_CC_TIPO_CTA_O);
        agregaIdReg(listIds, sql);
        sql.append(UNION_ALL)
                .append("SELECT r.ID_REG, cntr.NUM_CNTR CONTRATO, r.CNTA_CARG NUM_CTA_CARGO,r.CNTA_ABON NUN_CTA_ABONO,")
                .append("ct.DESC_PROD, r.mont IMPORTE, NULL REFERENCIA, 'MXP' DIVISA, ce.DESC_ESTATUS,")
                .append("to_char(TO_DATE(trim(nmb.FECH_OPER), 'YYYY-MM-DD'),'DD/MM/YYYY')||' '||nmb.HORA_OPER FECH_APLI, null BENEFICIARIO,")
                .append("'INTERNET' TIPO_PAGO,nmb.BUC TITULAR,  nmb.OBSE_ABO CONCEPTO_PAGO, NULL CLAVE_RASTREO, NULL BANCO_RECEPTOR,r.FECH_ENVI_BACK FECHA_OPERACION,")
                .append("NULL CLAV_PROV,nmb.LLAV_PAGO NUM_DOCU,NULL FECH_VENCIMIENTO, NULL CVE_FORM_PAGO, '-'||trim(ct.CVE_PROD_OPER)||'-' ESTATUS_MOV, nmb.NUME_MOVI_ABO NUM_ORDEN, NULL FECHA_LIMITE_PAGO, NULL NUM_SUCURSAL,")
                .append(" nmb.NOMB_CLTE RAZON_SCIA,nmb.NOMB_CLTE NOM_CLTE,")
                .append("clte.PERSONALIDAD, clte.RFC,cntr.NUM_CNTR, NULL CLAVE_BENEF,NULL ID_ESTA,NULL AS PERS_AUT,NULL AS FORM_APLI,nmb.NOMB_CLTE_BACK NOMB_RAZON_SOCI_PROV, NULL RFC_PROV,")
                .append("nmb.SUCU BANC_ABON, nmb.PLZA REFE_ABON, NULL TIPO_DOCU ")
                .append(" FROM H2H_PROD_IMPU_FEDE_TRAN nmb  ")
                .append(INNER_JOIN_H2H_REG_TRAN_R_ON_R_ID_REG_NMB_ID_REG)
                .append(INNER_JOIN_H2H_CAT_PROD_CT_ON_R_CVE_PROD_OPER_CT_CVE_PRODOPER)
                .append(INNER_JOIN_H2H_ARCHIVO_TRAN_A_ON_R_ID_ACRCH_A_ID_ARCHIVO)
                .append(LEFT_JOIN_H2H_ARCH_BACK_TRAN_ABT_ON_R_ID_ARCHBE_ABT_ID_ARCH_BAK)
                .append(INNER_JOIN_H2H_CNTR_CNTR_ON_CNTR_ID_CNTR_A_ID_CNTR)
                .append(INNER_JOIN_H2H_CLTE_CLTE_ON_CNTR_ID_CLTE_CLTE_ID_CLTE)
                .append(INNER_JOIN_H2H_CAT_ESTATUS_CE_ON_R_ID_ESTATUS_ID_CAT_ESTATUS)
                .append(LEFT_JOIN_H2H_CTA_INFO_CC_ON_R_CNTA_CARG_CC_NUME_CTA_AND_CC_TIPO_CTA_O);
        agregaIdReg(listIds, sql);
        return sql.toString();
    }

    /**
     * Obtiene el query de Aportaciones Obrero Patronales.
     *
     * @param listIds
     *            List<Integer>
     * @return String query
     */
    private static String obtenerQueryAportacionesPat(List<Integer> listIds) {
        final StringBuilder sql = new StringBuilder()
                .append("SELECT r.ID_REG, cntr.NUM_CNTR CONTRATO, nmb.NUM_CTA_CARG NUM_CTA_CARGO,r.CNTA_ABON NUN_CTA_ABONO, ")
                .append("ct.DESC_PROD, r.mont IMPORTE,null REFERENCIA, 'MXP' DIVISA, ce.DESC_ESTATUS, ")
                .append("to_char(nmb.FECH_REG,'dd/mm/yyyy hh24:mi:ss')  FECH_APLI,null BENEFICIARIO,null TIPO_PAGO, ")
                .append(" nmb.BUC TITULAR,  nmb.OBSE_ABO CONCEPTO_PAGO,nmb.NUME_FOLI_SUA CLAVE_RASTREO,null BANCO_RECEPTOR,r.FECH_ENVI_BACK FECHA_OPERACION,")
                .append("null CLAV_PROV,null NUM_DOCU,null FECH_VENCIMIENTO,to_char(nmb.NUME_MOVI_CARG) CVE_FORM_PAGO,'-'||trim(ct.CVE_PROD_OPER)||'-' ESTATUS_MOV,null NUM_ORDEN,null FECHA_LIMITE_PAGO,null NUM_SUCURSAL,")
                .append("clte.RAZON_SCIA,nmb.NOMB_CLTE NOM_CLTE, ")
                .append(CLTE_PERSONALIDADCLTE_RFC_CNTR_NUM_CNTR)
                .append("null CLAVE_BENEF,null ID_ESTA,'H2H' PERS_AUT,nmb.CVE_PROD_OPER FORM_APLI, nmb.REG_PATR NOMB_RAZON_SOCI_PROV,nmb.TITU_CTA RFC_PROV,'INTERNET' BANC_ABON,")
                .append("nmb.OBSE_CARG REFE_ABON,nmb.PRDO_PAGO TIPO_DOCU ")
                .append(" FROM H2H_PROD_APO_OBRE_PATR nmb    ")
                .append(INNER_JOIN_H2H_REG_R_ON_R_ID_REG_NMB_ID_REG)
                .append(INNER_JOIN_H2H_CAT_PROD_CT_ON_R_CVE_PROD_OPER_CT_CVE_PRODOPER)
                .append(INNER_JOIN_H2H_ARCHIVO_A_ON_R_ID_ARCH_A_ID_ARCHIVO)
                .append(LEFT_JOIN_H2H_ARCH_BACK_ABT_ON_R_ID_ARCH_BE_ABT_ID_ARCH_BACK)
                .append(INNER_JOIN_H2H_CNTR_CNTR_ON_CNTR_ID_CNTR_A_ID_CNTR)
                .append(INNER_JOIN_H2H_CLTE_CLTE_ON_CNTR_ID_CLTE_CLTE_ID_CLTE)
                .append(INNER_JOIN_H2H_CAT_ESTATUS_CE_ON_R_ID_ESTATUS_ID_CAT_ESTATUS);
        agregaIdReg(listIds, sql);
        sql.append(UNION_ALL)
                .append("SELECT r.ID_REG, cntr.NUM_CNTR CONTRATO, nmb.NUM_CTA_CARG,r.CNTA_ABON NUN_CTA_ABONO, ")
                .append("ct.DESC_PROD, r.mont IMPORTE,null REFERENCIA, 'MXP' DIVISA, ce.DESC_ESTATUS, ")
                .append("to_char(nmb.FECH_REG,'dd/mm/yyyy hh24:mi:ss') FECH_APLI,null BENEFICIARIO,null TIPO_PAGO, ")
                .append("nmb.BUC TITULAR,  nmb.OBSE_ABO CONCEPTO_PAGO,nmb.NUME_FOLI_SUA CLAVE_RASTREO,null BANCO_RECEPTOR,r.FECH_ENVI_BACK FECHA_OPERACION,")
                .append("null CLAV_PROV,null NUM_DOCU,null FECH_VENCIMIENTO,to_char(nmb.NUME_MOVI_CARG) CVE_FORM_PAGO,'-'||trim(ct.CVE_PROD_OPER)||'-' ESTATUS_MOV,null NUM_ORDEN,null FECHA_LIMITE_PAGO,null NUM_SUCURSAL,")
                .append("clte.RAZON_SCIA,nmb.NOMB_CLTE NOM_CLTE, ")
                .append(CLTE_PERSONALIDADCLTE_RFC_CNTR_NUM_CNTR)
                .append("null CLAVE_BENEF,null ID_ESTA,'H2H' PERS_AUT,nmb.CVE_PROD_OPER FORM_APLI, nmb.REG_PATR NOMB_RAZON_SOCI_PROV,nmb.TITU_CTA RFC_PROV,'INTERNET' BANC_ABON,")
                .append("nmb.OBSE_CARG REFE_ABON,nmb.PRDO_PAGO TIPO_DOCU ")
                .append(" FROM H2H_PROD_APO_OBRE_PATR_TRAN nmb         ")
                .append(INNER_JOIN_H2H_REG_TRAN_R_ON_R_ID_REG_NMB_ID_REG)
                .append(INNER_JOIN_H2H_CAT_PROD_CT_ON_R_CVE_PROD_OPER_CT_CVE_PRODOPER)
                .append(INNER_JOIN_H2H_ARCHIVO_TRAN_A_ON_R_ID_ACRCH_A_ID_ARCHIVO)
                .append(LEFT_JOIN_H2H_ARCH_BACK_TRAN_ABT_ON_R_ID_ARCHBE_ABT_ID_ARCH_BAK)
                .append(INNER_JOIN_H2H_CNTR_CNTR_ON_CNTR_ID_CNTR_A_ID_CNTR)
                .append(INNER_JOIN_H2H_CLTE_CLTE_ON_CNTR_ID_CLTE_CLTE_ID_CLTE)
                .append(INNER_JOIN_H2H_CAT_ESTATUS_CE_ON_R_ID_ESTATUS_ID_CAT_ESTATUS);
        agregaIdReg(listIds, sql);
        return sql.toString();
    }

    /**
     * Obtiene el query de NI SPEI y TEF.
     *
     * @param listIds
     *            List<Integer>
     * @return String
     */
	private static String obtenerQueryProdTran(List<Integer> listIds) {
		final StringBuilder sql = new StringBuilder()
				.append("SELECT r.ID_REG,   ")
				.append("  cntr.num_cntr CONTRATO,    ")
				.append("  r.cnta_carg NUM_CTA_CARGO, ")
				.append("  r.cnta_abon NUN_CTA_ABONO, ")
				.append("  ct.DESC_PROD,    ")
				.append("  r.mont IMPORTE,  ")
				.append("  TO_CHAR (pt.refe_out) REFERENCIA,    ")
				.append("  pt.divi_abon DIVISA,       ")
				.append("  ce.DESC_ESTATUS, ")
				.append("  to_char(decode(pt.FCH_ACEP_TRFR_OUT ,null,abt.FECH_RESP_BE,pt.FCH_ACEP_TRFR_OUT),'dd/mm/yyyy hh24:mi:ss')  FECH_APLI,    ")
				.append("  DECODE(ca.NOMB_TITU,null,pt.nomb_rece,ca.NOMB_TITU) BENEFICIARIO, ")
				.append("  NULL TIPO_PAGO,  ")
				.append("  cc.NOMB_TITU TITULAR,      ")
				.append("  DECODE(r.cve_prod_oper, '02',SUBSTR(pt.come_1_conc_pago,8),SUBSTR(pt.come_1_conc_pago,1,40)) CONCEPTO_PAGO, ")
				.append("  pt.refe_envi_out CLAVE_RASTREO,      ")
				.append("  bnco.NOMBRE_BANCO BANCO_RECEPTOR,    ")
				.append("  r.fech_envi_back FECHA_OPERACION,    ")
				.append("  NULL CLAV_PROV,  ")
				.append("  NULL NUM_DOCU,   ")
				.append("  NULL FECH_VENCIMIENTO,     ")
				.append("  NULL CVE_FORM_PAGO,        ")
				.append("  NULL ESTATUS_MOV,")
				.append("  NULL NUM_ORDEN,  ")
				.append("  NULL FECHA_LIMITE_PAGO,    ")
				.append("  NULL NUM_SUCURSAL,         ")
				.append("  clte.RAZON_SCIA, ")
				.append("  clte.nombre  || ' '  || clte.appaterno  || ' '  || clte.apmaterno NOM_CLTE,  ")
				.append("  clte.PERSONALIDAD,         ")
				.append("  clte.RFC,        ")
				.append(CNTR_NUM_CNTR)
				.append("  NULL CLAVE_BENEF, ")
				.append(NULL_ID_ESTA)
				.append("  NULL AS PERS_AUT,        ")
				.append(NULL_AS_FORM_APLI)
				.append(NULL_NOMB_RAZON_SOCI_PROV)
				.append(" cntr.BAND_HOMO_COMP_SPEI RFC_PROV,")
				.append(NULL_BANC_ABON)
				.append(" r.REFE_BE REFE_ABON,")
				.append(NULL_TIPO_DOCU)
				.append(" FROM H2H_PROD_TRAN pt       ")
				.append(" INNER JOIN H2H_REG r ON r.id_reg = pt.id_reg    ")
				.append(" INNER JOIN H2H_CAT_PROD ct ON r.cve_prod_oper = ct.cve_prod_oper    ")
				.append(" INNER JOIN H2H_ARCHIVO a ON r.id_arch = a.id_archivo      ")
				.append(LEFT_JOIN_H2H_ARCH_BACK_ABT_ON_R_ID_ARCH_BE_ABT_ID_ARCH_BACK)
				.append(" INNER JOIN H2H_CNTR cntr ON cntr.id_cntr = a.id_cntr      ")
				.append(" INNER JOIN H2H_CLTE clte ON cntr.id_clte = clte.id_clte   ")
				.append(" INNER JOIN H2H_CAT_ESTATUS ce ON r.id_estatus = id_cat_estatus      ")
				//Se agrega condicion AND bnco.BAND_ACTIVO = 1 debido a que exisitan bancos inactivos y estaba duplicando registros
				.append(" LEFT JOIN H2H_CAT_BNCO bnco ON pt.CLAV_INTER_RECE  = bnco.CODI_TRAN AND bnco.BAND_ACTIVO = 1      ")
				.append(LEFT_JOIN_H2H_CTA_INFO_CA_ON_R_CNTA_ABON_CA_NUME_CTA_AND_CA_TIPO_CTA_B)
				.append(LEFT_JOIN_H2H_CTA_INFO_CC_ON_R_CNTA_CARG_CC_NUME_CTA_AND_CC_TIPO_CTA_O);
		agregaIdReg(listIds, sql);
		sql.append(UNION_ALL)
				.append("SELECT r.ID_REG,    ")
				.append("  cntr.num_cntr CONTRATO,     ")
				.append("  r.cnta_carg NUM_CTA_CARGO,  ")
				.append("  r.cnta_abon NUN_CTA_ABONO,  ")
				.append("  ct.DESC_PROD,     ")
				.append("  r.mont IMPORTE,   ")
				.append("  TO_CHAR (pt.refe_out) REFERENCIA,     ")
				.append("  pt.divi_abon DIVISA,        ")
				.append("  ce.DESC_ESTATUS,  ")
				.append("  to_char(decode(pt.FCH_ACEP_TRFR_OUT ,null,abt.FECH_RESP_BE,pt.FCH_ACEP_TRFR_OUT),'dd/mm/yyyy hh24:mi:ss')  FECH_APLI,    ")
				.append("  DECODE(ca.NOMB_TITU,null,pt.nomb_rece,ca.NOMB_TITU) BENEFICIARIO,  ")
				.append("  NULL TIPO_PAGO,   ")
				.append("  cc.NOMB_TITU TITULAR,       ")
				.append("  DECODE(r.cve_prod_oper, '02',SUBSTR(pt.come_1_conc_pago,8),SUBSTR(pt.come_1_conc_pago,1,40)) CONCEPTO_PAGO, ")
				.append("  pt.refe_envi_out CLAVE_RASTREO,       ")
				.append("  bnco.NOMBRE_BANCO BANCO_RECEPTOR,     ")
				.append("  r.fech_envi_back FECHA_OPERACION,     ")
				.append("  NULL CLAV_PROV,   ")
				.append("  NULL NUM_DOCU,    ")
				.append("  NULL FECH_VENCIMIENTO,      ")
				.append("  NULL CVE_FORM_PAGO,         ")
				.append("  NULL ESTATUS_MOV, ")
				.append("  NULL NUM_ORDEN,   ")
				.append("  NULL FECHA_LIMITE_PAGO,     ")
				.append("  NULL NUM_SUCURSAL,")
				.append("  clte.RAZON_SCIA,  ")
				.append("  clte.nombre  || ' '  || clte.appaterno  || ' '  || clte.apmaterno NOM_CLTE,   ")
				.append("  clte.PERSONALIDAD,")
				.append("  clte.RFC,         ")
				.append(CNTR_NUM_CNTR)
				.append("  NULL CLAVE_BENEF,  ")
				.append(NULL_ID_ESTA)
				.append(NULL_AS_PERS_AUT)
				.append(NULL_AS_FORM_APLI)
				.append(NULL_NOMB_RAZON_SOCI_PROV)
				.append(obtenerQueryProdTranAux(listIds));
				
		return sql.toString();
	}
	
	private static StringBuilder obtenerQueryProdTranAux(List<Integer> listIds) {
		StringBuilder sqlAux = new StringBuilder();
		// Para SPEI
		sqlAux.append(" cntr.BAND_HOMO_COMP_SPEI RFC_PROV,").append(NULL_BANC_ABON)
				.append(" r.REFE_BE REFE_ABON,").append(NULL_TIPO_DOCU).append(" FROM H2H_PROD_TRAN_TRAN pt   ")
				.append(" INNER JOIN H2H_REG_TRAN r ON r.id_reg = pt.id_reg")
				.append(" INNER JOIN H2H_CAT_PROD ct ON r.cve_prod_oper = ct.cve_prod_oper     ")
				.append(" INNER JOIN H2H_ARCHIVO_TRAN a ON r.id_arch = a.id_archivo  ")
				.append(LEFT_JOIN_H2H_ARCH_BACK_TRAN_ABT_ON_R_ID_ARCHBE_ABT_ID_ARCH_BAK)
				.append(" INNER JOIN H2H_CNTR cntr ON cntr.id_cntr = a.id_cntr       ")
				.append(" INNER JOIN H2H_CLTE clte ON cntr.id_clte = clte.id_clte    ")
				.append(" INNER JOIN H2H_CAT_ESTATUS ce ON r.id_estatus = id_cat_estatus       ")
				// Se agrega condicion AND bnco.BAND_ACTIVO = 1 debido a que exisitan bancos
				// inactivos y estaba duplicando registros
				.append(" LEFT JOIN H2H_CAT_BNCO bnco ON pt.CLAV_INTER_RECE  = bnco.CODI_TRAN AND bnco.BAND_ACTIVO = 1      ")
				.append(LEFT_JOIN_H2H_CTA_INFO_CA_ON_R_CNTA_ABON_CA_NUME_CTA_AND_CA_TIPO_CTA_B)
				.append(LEFT_JOIN_H2H_CTA_INFO_CC_ON_R_CNTA_CARG_CC_NUME_CTA_AND_CC_TIPO_CTA_O);
		agregaIdReg(listIds, sqlAux);

		return sqlAux;
	}

    /**
     * Obtiene el query de Nomina mismo banco.
     *
     * @param listIds
     *            List<Integer>
     * @return String
     */
    private static String obtenerQueryProdNomiMismBanc(List<Integer> listIds) {
        final StringBuilder sql = new StringBuilder()
                .append(SELECT_R_ID_REG)
                .append(CNTR_NUM_CNTR_CONTRATO).append(R_CNTA_CARG_NUM_CTA_CARGO).append(R_CNTA_ABON_NUN_CTA_ABONO)
                .append(CT_DESC_PROD).append(R_MONT_IMPORTE).append("  NULL REFERENCIA,         ")
                .append(" CATDIV.CLAV_CAPTA DIVISA, ").append(CE_DESC_ESTATUS)
                .append(TO_CHAR_ABT_FECH_RESP_BE_FECH_APLI_NMB).append("  ca.NOMB_TITU BENEFICIARIO,       ")
                .append(NULL_TOPO_PAGO).append("  cc.NOMB_TITU TITULAR,  ")
                .append("  nmb.OBSE_ABON CONCEPTO_PAGO,       ")
                .append(NULL_CLAVE_RASTREO)
                .append(NULL_BANCO_RECEPTOR)
                .append(R_FECH_ENVI_BACK_FECHA_OPERACION)
                .append(NULL_CLAV_PROV)
                .append(NULL_NUM_DOCU)
                .append(NULL_FECH_VENCIMIENTO)
                .append(NULL_CVE_FORM_PAGO)
                .append(NULL_ESTATUS_MOV)
                .append(NULL_NUM_ORDEN)
                .append(NULL_FECHA_LIMITE_PAGO)
                .append(NULL_NUM_SUCURSAL)
                .append(CLTE_RAZON_SCIA)
                .append(CLTE_NOMBRE_CLTE_APPATERNO_CLTE_APMATERNO_NOM_CLTE)
                .append(CLTE_PERSONALIDAD)
                .append(CLTE_RFC)
                .append(CNTR_NUM_CNTR)
                .append("  NULL CLAVE_BENEF,         ")
                .append(NULL_ID_ESTA)
                .append(NULL_AS_PERS_AUT)
                .append(NULL_AS_FORM_APLI)
                .append(NULL_NOMB_RAZON_SOCI_PROV)
                .append(NULL_RFC_PROV)
                .append(NULL_BANC_ABON)
                .append(NULL_REFE_ABON)
                .append(NULL_TIPO_DOCU)
                .append(" FROM H2H_PROD_NOMI_MISM_BANC nmb    ")
                .append(INNER_JOIN_H2H_REG_R_ON_R_ID_REG_NMB_ID_REG)
                .append(INNER_JOIN_H2H_CAT_PROD_CT_ON_R_CVE_PROD_OPER_CT_CVE_PRODOPER)
                .append(INNER_JOIN_H2H_ARCHIVO_A_ON_R_ID_ARCH_A_ID_ARCHIVO)
                .append(LEFT_JOIN_H2H_ARCH_BACK_ABT_ON_R_ID_ARCH_BE_ABT_ID_ARCH_BACK)
                .append(INNER_JOIN_H2H_CNTR_CNTR_ON_CNTR_ID_CNTR_A_ID_CNTR)
                .append(INNER_JOIN_H2H_CLTE_CLTE_ON_CNTR_ID_CLTE_CLTE_ID_CLTE)
                .append(INNER_JOIN_H2H_CAT_ESTATUS_CE_ON_R_ID_ESTATUS_ID_CATESTATUS)
                .append(LEFT_JOIN_H2H_CTA_INFO_CA_ON_R_CNTA_ABON_CA_NUME_CTA_AND_CA_TIPO_CTA_B)
                .append(LEFT_JOIN_H2H_CTA_INFO_CC_ON_R_CNTA_CARG_CC_NUME_CTA_AND_CC_TIPO_CTA_O)
                .append(" LEFT JOIN H2H_CAT_DIVISA  CATDIV ON CATDIV.ID_CAT_DIVISA=CC.ID_CAT_DIVISA ");
        agregaIdReg(listIds, sql);
        sql.append(UNION_ALL)
                .append(SELECT_R_ID_REG)
                .append(CNTR_NUM_CNTR_CONTRATO)
                .append(R_CNTA_CARG_NUM_CTA_CARGO)
                .append(R_CNTA_ABON_NUN_CTA_ABONO)
                .append(CT_DESC_PROD)
                .append(R_MONT_IMPORTE)
                .append("  NULL REFERENCIA,         ")
                .append(" CATDIV.CLAV_CAPTA DIVISA, ")
                .append(CE_DESC_ESTATUS)
                .append(TO_CHAR_ABT_FECH_RESP_BE_FECH_APLI_NMB)
                .append("  ca.NOMB_TITU BENEFICIARIO,       ")
                .append(NULL_TOPO_PAGO)
                .append("  cc.NOMB_TITU TITULAR,  ")
                .append("  nmb.OBSE_ABON CONCEPTO_PAGO,       ")
                .append(NULL_CLAVE_RASTREO)
                .append(NULL_BANCO_RECEPTOR)
                .append(R_FECH_ENVI_BACK_FECHA_OPERACION)
                .append(NULL_CLAV_PROV)
                .append(NULL_NUM_DOCU)
                .append(NULL_FECH_VENCIMIENTO)
                .append(NULL_CVE_FORM_PAGO)
                .append(NULL_ESTATUS_MOV)
                .append(NULL_NUM_ORDEN)
                .append(NULL_FECHA_LIMITE_PAGO)
                .append(NULL_NUM_SUCURSAL)
                .append(CLTE_RAZON_SCIA)
                .append(CLTE_NOMBRE_CLTE_APPATERNO_CLTE_APMATERNO_NOM_CLTE)
                .append(CLTE_PERSONALIDAD)
                .append(CLTE_RFC)
                .append(CNTR_NUM_CNTR)
                .append("  NULL CLAVE_BENEF,         ")
                .append(NULL_ID_ESTA)
                .append(NULL_AS_PERS_AUT)
                .append(NULL_AS_FORM_APLI)
                .append(NULL_NOMB_RAZON_SOCI_PROV)
                .append(NULL_RFC_PROV)
                .append(NULL_BANC_ABON)
                .append(NULL_REFE_ABON)
                .append(NULL_TIPO_DOCU)
                .append(" FROM H2H_PROD_NOMI_MISM_BANC_TRAN nmb         ")
                .append(INNER_JOIN_H2H_REG_TRAN_R_ON_R_ID_REG_NMB_ID_REG)
                .append(INNER_JOIN_H2H_CAT_PROD_CT_ON_R_CVE_PROD_OPER_CT_CVE_PRODOPER)
                .append(INNER_JOIN_H2H_ARCHIVO_TRAN_A_ON_R_ID_ACRCH_A_ID_ARCHIVO)
                .append(LEFT_JOIN_H2H_ARCH_BACK_TRAN_ABT_ON_R_ID_ARCHBE_ABT_ID_ARCH_BAK)
                .append(INNER_JOIN_H2H_CNTR_CNTR_ON_CNTR_ID_CNTR_A_ID_CNTR)
                .append(INNER_JOIN_H2H_CLTE_CLTE_ON_CNTR_ID_CLTE_CLTE_ID_CLTE)
                .append(INNER_JOIN_H2H_CAT_ESTATUS_CE_ON_R_ID_ESTATUS_ID_CATESTATUS)
                .append(LEFT_JOIN_H2H_CTA_INFO_CA_ON_R_CNTA_ABON_CA_NUME_CTA_AND_CA_TIPO_CTA_B)
                .append(LEFT_JOIN_H2H_CTA_INFO_CC_ON_R_CNTA_CARG_CC_NUME_CTA_AND_CC_TIPO_CTA_O)
                .append(" LEFT JOIN H2H_CAT_DIVISA  CATDIV ON CATDIV.ID_CAT_DIVISA=CC.ID_CAT_DIVISA ");
        agregaIdReg(listIds, sql);
        return sql.toString();
    }

    /**
     * Agrega id's reg.
     *
     * @param listIds
     *            List<Integer>
     * @param sql
     *            StringBuilder
     */
    protected static void agregaIdReg(List<Integer> listIds, StringBuilder sql) {
        if (listIds != null && !listIds.isEmpty() && sql != null) {
            int l = 0;
            for (Integer idReg : listIds) {
                if (l == 0) {
                    sql.append(" WHERE ( r.id_reg = ").append(idReg);
                } else {
                    sql.append(" OR r.id_reg = ").append(idReg);
                }
                l++;
            }
            sql.append(" ) ");
        }
    }

}
