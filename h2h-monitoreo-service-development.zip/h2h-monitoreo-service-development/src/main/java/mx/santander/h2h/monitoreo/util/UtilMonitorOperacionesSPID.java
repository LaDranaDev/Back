package mx.santander.h2h.monitoreo.util;

/**
 * Clase generada para UtilMonitorOperacionesSPID.
 *
 * @autor fsw
 * @modifico C320868
 */
public class UtilMonitorOperacionesSPID {
    
	/** Declaracion de Constante PROD_PROV_CONFIRMING. */
	private static final String PROD_PROV_CONFIRMING = "11"; 
	
	/** Declaracion de Constante SELECT_H2H_REG_TRAN_TABLA. */
	private static final String SELECT_H2H_REG_TRAN_TABLA="SELECT 'H2H_REG_TRAN' TABLA, ";
	
	/** Declaracion de Constante SELECT_H2H_REG_TABLA. */
	private static final String SELECT_H2H_REG_TABLA="SELECT 'H2H_REG' TABLA, ";
	
	/**REG.ID_REG, CLTE.BUC, REG.CNTA_CARG NUM_CTA_CARGO*/
	private static final String REG_ID_REG_CLTE_BUC_REG_CNTA_CARG_NUM_CTA_CARGO="REG.ID_REG, CLTE.BUC, REG.CNTA_CARG NUM_CTA_CARGO, ";
	
	/**REG.CNTA_ABON NUN_CTA_ABONO, CVE_PROD_OPER, PROD.DESC_PROD*/
	private static final String REG_CNTA_ABON_NUN_CTA_ABONO_CVE_PROD_OPER_PROD_DESC_PROD="REG.CNTA_ABON NUN_CTA_ABONO, PROD.CVE_PROD_OPER, PROD.DESC_PROD, ";
	
	/** EST_DESC_ESTATUS_REG_MONT_IMPORTE_CNTR_NUM_CNTR_REG_DIVI_DIVISA. */
	private static final String EST_DESC_ESTATUS_REG_MONT_IMPORTE_CNTR_NUM_CNTR_REG_DIVI_DIVISA="EST.DESC_ESTATUS, REG.MONT IMPORTE, CNTR.NUM_CNTR, REG.DIVI DIVISA, ";
	
	/** INNER_JOIN_H2H_CAT_ESTATUS_EST_ON_REG_ID_ESTATUS_EST_ID_CAT_ESTATUS. */
	private static final String INNER_JOIN_H2H_CAT_ESTATUS_EST_ON_REG_ID_ESTATUS_EST_ID_CAT_ESTATUS="INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS ";
	
	/**INNER JOIN H2H_CAT_CANL CANL ON ARCH.ID_CANL = CANL.ID_CANL*/
	private static final String INNER_JOIN_H2H_CAT_CANL_CANL_ON_ARCH_ID_CANL_CANL_ID_CANL="INNER JOIN H2H_CAT_CANL CANL ON ARCH.ID_CANL = CANL.ID_CANL ";
	
	/** Declaracion de Constante ARCH_NOMBRE_ARCH_REG_REFE_BE_REFERENCIA_REG_ID_ESTATUS. */
	private static final String ARCH_NOMBRE_ARCH_REG_REFE_BE_REFERENCIA_REG_ID_ESTATUS = "ARCH.NOMBRE_ARCH, DECODE( PROD.CVE_PROD_OPER,85 , DECODE(REG.REFE_BE,null,'' ,'****'|| SUBSTRB(REG.REFE_BE,-4,4)), REG.REFE_BE) REFERENCIA, REG.ID_ESTATUS, ";
	
	/** Declaracion de Constante INNER_JOIN_H2H_CLTE. */
	private static final String INNER_JOIN_H2H_CLTE="INNER JOIN H2H_CLTE CLTE USING (ID_CLTE) ";
	
	/** Declaracion de Constante PART_QUERY_SELECT_INNER_CAT_PROD. */
	private static final String PART_QUERY_SELECT_INNER_CAT_PROD="INNER JOIN H2H_CAT_PROD PROD  ON PROD.CVE_PROD_OPER = REG.CVE_PROD_OPER ";
    
    /** Declaracion de Constante INNER_JOIN_H2H_CAT_CANL. */
    private static final String INNER_JOIN_H2H_CAT_CANL="INNER JOIN H2H_CAT_CANL CANL ON ARCH.ID_CANL = CANL.ID_CANL ";
    
    /** Tabla principal del producto. */
    public static final String SELECT_TABLA_REG="H2H_MX_PROD_SPID";
    
    /** Tabla Tran del producto*. */
    public static final String SELECT_TABLA_REG_TRAN=SELECT_TABLA_REG+"_TRAN";
    
    /** tabla historica del producto*. */
    public static final String SELECT_TABLA_REG_HIST=SELECT_TABLA_REG+"_HIST";

    /** Declaracion de Constante SELECT_TABLA. */
    public static final String SELECT_TABLA = "H2H_REG_TRAN";
    
    /** Declaracion de Constante SELECT_TABLA_TRAN. */
    public static final String SELECT_TABLA_TRAN = SELECT_TABLA+ "_TRAN";
    
    
    /**
     * Contructor default.
     */
    public UtilMonitorOperacionesSPID() {}

    
    /**
     * *
     * Metodo para saber si se elcciono en especifico el producto por su cve_prod_Oper.
     *
     * @param consultaOperaciones  con datos a comparar
     * @return boolean true si es la clve de producto operante false en otro caso
     */
    public static boolean esProductoActivo(String idProducto) {
        return "09".equals(idProducto);
    }
    
    
    /**
     * obtiene la cadena select para el producto.
     *
     * @param delDia para saber si se utilizara la tabla del producto o la historica
     * @return cadena con select del producto
     */
    public static String getselectSPID(StringBuilder query, boolean delDia) {
        // Iniciamos armado de Query SQL
    	StringBuilder qrySPID = new StringBuilder();
    	qrySPID
    	.append("SELECT '")
        .append(delDia ? SELECT_TABLA_REG_TRAN  : SELECT_TABLA_REG).append("' TABLA,")
        .append("REG.ID_REG, ")
        .append("CLTE.BUC, ")
        .append("PIF.NUME_CUEN_ORDE NUM_CTA_CARGO, ")
        .append("REG.CNTA_ABON NUN_CTA_ABONO, ")
        .append("PROD.CVE_PROD_OPER, ")
        .append("PROD.DESC_PROD, ")
        .append("ARCH.NOMBRE_ARCH, ")
        .append("PIF.REFE_OUT REFERENCIA, ")
        .append("REG.ID_ESTATUS, ")
        .append("EST.DESC_ESTATUS, ")
        .append("PIF.IMPO_CARG IMPORTE, ")
        .append("CNTR.NUM_CNTR,")
        .append("PIF.CVE_DIVISA_ORDE DIVISA,")
        .append("ARCH.FECHA_REGISTRO FECHA_REGISTRO, ")
        .append("REG.FECH_APLI FECHA_APLICACION, ")
        .append("PROD.VIST_PROD, ")
        .append("REG.NUM_EMAIL, ")
        .append("MSG.MSG_H2H OBSE_ABO, ")
        .append("PIF.NOMBRE_ORDE BUC_EMPLEADO, ")
        .append("PIF.REFE_ENVI_OUT CLVE_CONV, ")
        .append("CANL.NOMB_CANL ")
        .append(delDia ? "FROM H2H_ARCHIVO_TRAN ARCH " : "FROM H2H_ARCHIVO ARCH ")
        .append(delDia ? "INNER JOIN H2H_REG_TRAN REG ON ARCH.ID_ARCHIVO = REG.ID_ARCH " : "INNER JOIN H2H_REG REG ON ARCH.ID_ARCHIVO = REG.ID_ARCH ")
        .append("INNER JOIN H2H_CNTR CNTR USING (ID_CNTR) ")
        .append("INNER JOIN H2H_CLTE CLTE USING (ID_CLTE) ")
        .append("INNER JOIN H2H_CAT_PROD PROD on PROD.CVE_PROD_OPER=REG.CVE_PROD_OPER ")
        .append("INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS ")
        .append("INNER JOIN H2H_CAT_CANL CANL ON ARCH.ID_CANL = CANL.ID_CANL ")
        .append(delDia ? "INNER JOIN "+SELECT_TABLA_REG_TRAN+" PIF ON PIF.ID_REG = REG.ID_REG " : "INNER JOIN "+SELECT_TABLA_REG+" PIF ON PIF.ID_REG = REG.ID_REG")
        .append(" LEFT JOIN H2H_MSG MSG ON MSG.ID_MSG = REG.ID_MSG ");
    	return qrySPID.toString();
    }
    
    
    
    /**
     * Metodo Getter para selectConsultaOperacionesCEntroPAgos.
     *
     * @param delDia para del dia
     * @return selectConsultaOperacionesCEntroPAgos select consulta operaciones C entro P agos
     */
    public static String getSelectConsultaOperacionesCentroPagos( boolean delDia) {
    	final StringBuilder query = new StringBuilder();
    	query
    		.append("SELECT '")
    		.append(delDia ? SELECT_TABLA  : SELECT_TABLA_TRAN)
    		.append("' TABLA, ")
    		.append(REG_ID_REG_CLTE_BUC_REG_CNTA_CARG_NUM_CTA_CARGO)
			.append(REG_CNTA_ABON_NUN_CTA_ABONO_CVE_PROD_OPER_PROD_DESC_PROD)
			.append(ARCH_NOMBRE_ARCH_REG_REFE_BE_REFERENCIA_REG_ID_ESTATUS)
			.append(EST_DESC_ESTATUS_REG_MONT_IMPORTE_CNTR_NUM_CNTR_REG_DIVI_DIVISA)
			.append(" ARCH.FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, REG.NUM_EMAIL, ")
			.append("CANL.NOMB_CANL ")
			.append(UtilQuery.fromH2hArchivo(delDia))
			.append(UtilQuery.innerJoinH2hReg(delDia))
			.append(" INNER JOIN H2H_CNTR CNTR USING (ID_CNTR) ")
			.append(INNER_JOIN_H2H_CLTE)
			.append(PART_QUERY_SELECT_INNER_CAT_PROD)
			.append(INNER_JOIN_H2H_CAT_ESTATUS_EST_ON_REG_ID_ESTATUS_EST_ID_CAT_ESTATUS)
			.append(INNER_JOIN_H2H_CAT_CANL);
    	
    	return query.toString();
    }
}
