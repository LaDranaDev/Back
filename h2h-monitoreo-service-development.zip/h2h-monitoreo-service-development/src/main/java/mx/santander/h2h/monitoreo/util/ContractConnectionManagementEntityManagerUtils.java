package mx.santander.h2h.monitoreo.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.response.ParametersGetPutResponse;
import mx.santander.h2h.monitoreo.model.response.ProductEdoCtaResponse;
import mx.santander.h2h.monitoreo.model.response.ProtocolResponse;

@Slf4j
@Component
public class ContractConnectionManagementEntityManagerUtils {
	@Autowired
	@PersistenceContext
	private EntityManager entityManager;

	@Transactional
	public void actualizarParametro(String valorParametro, BigDecimal idValorParametro, String nombreParametro) {

		StringBuilder query = new StringBuilder("UPDATE H2H_PATT_PTCL SET VALOR = :valorParametro WHERE ID_SEQU_PATT = :idValorParametro");

		Query updateParametersResult = entityManager.createNativeQuery(query.toString());

		updateParametersResult.setParameter("valorParametro", valorParametro);
		updateParametersResult.setParameter("idValorParametro", idValorParametro);

		Integer updatedParametersResult = updateParametersResult.executeUpdate();

		log.info("La respuesta de la actualizacion de Nombre " + nombreParametro + " Valor " + valorParametro + " Id " + idValorParametro);
		log.info(String.format("Respuesta de actualizar el parametro %s COD_ERROR %s", nombreParametro, updatedParametersResult.toString()));

	}

	@Transactional
	public void insertParameters(Integer idContrato, String valorParametro, BigDecimal idValorParametro, BigDecimal idRegistroSeq, ParametersGetPutResponse parametersGetPutResponse) {

		String idParaProt = parametersGetPutResponse.getId();
		String tipoProcesamiento = parametersGetPutResponse.getTipoProcesamiento();
		String nombreParametro = parametersGetPutResponse.getNombreParametro();

		StringBuilder query = new StringBuilder("INSERT INTO H2H_PATT_PTCL (ID_SEQU_PATT, ID_CNTR, ID_PARA_PTCL, VALOR, PATT_ACTI, FECH_REG, ID_DATO_TRAN, BAND_ACTI)");
		query.append(" VALUES (:idValorParametro, :idContrato, :idParaProt, :valorParametro, :tipoProcesamiento, sysdate, :idRegistroSeq, 'A')");

		Query insertParametersResult = entityManager.createNativeQuery(query.toString());

		insertParametersResult.setParameter("idValorParametro", idValorParametro);
		insertParametersResult.setParameter("idContrato", idContrato);
		insertParametersResult.setParameter("idParaProt", idParaProt);
		insertParametersResult.setParameter("valorParametro", valorParametro);
		insertParametersResult.setParameter("tipoProcesamiento", tipoProcesamiento);
		insertParametersResult.setParameter("idRegistroSeq", idRegistroSeq);

		Integer insertedParametersResult = insertParametersResult.executeUpdate();

		if(insertedParametersResult.equals(0)){

			log.info(Encode.forJava(String.format("La respuesta de la inserción de Nombre %s Valor %s Id %s es nula", nombreParametro, valorParametro, idValorParametro.toString())));

			throw new BusinessException("ERGC010");

		} else {

			log.info(String.format("Respuesta de actualizar el parametro %s COD_ERROR %s", nombreParametro, insertedParametersResult.toString()));

		}

	}

	@Transactional
	public void deleteParameters(Integer idContrato) throws DataAccessException {

		StringBuilder query = new StringBuilder("DELETE FROM H2H_PATT_PTCL WHERE ID_CNTR = :idContrato");

		Query queryDeleteParameters = entityManager.createNativeQuery(query.toString());

		queryDeleteParameters.setParameter("idContrato", idContrato);

		Integer deleteParametersResult = queryDeleteParameters.executeUpdate();

		log.info(String.format("Respuesta de eliminar parametros del canal %s COD_ERROR %s", idContrato.toString(), deleteParametersResult.toString()));

	}

	/**
	 * @param parameters
	 * @param llavesInsercion
	 * @throws NumberFormatException
	 */
	public void getInsertionKeysFromParameters(List<ParametersGetPutResponse> parameters, final Map<String, BigDecimal> llavesInsercion) throws NumberFormatException {

		for (ParametersGetPutResponse parametersGetPutResponse : parameters) {

			final String idValorParametro = parametersGetPutResponse.getIdValorParametro();

			if (StringUtils.isBlank(idValorParametro) || "0".equals(idValorParametro)) {

				StringBuilder query = new StringBuilder("SELECT H2H_PATT_PTCL_SEQ.NEXTVAL FROM DUAL");

				Query nextValueResult = entityManager.createNativeQuery(query.toString());

				List<BigDecimal> listNextValueResult = nextValueResult.getResultList();

				if (!listNextValueResult.isEmpty()) {

					llavesInsercion.put(String.format("%s_%s", parametersGetPutResponse.getId(), parametersGetPutResponse.getTipoProcesamiento()), listNextValueResult.get(0));

				}

			}

		}

	}

	public List<ParametersGetPutResponse> mapFromListParametersOfProtocolsToListParametersGetPutResponse(List<Object[]> listParametersOfProtocols) {

		List<ParametersGetPutResponse> listParametersGetPutResponse = new ArrayList<>();

		for (Object[] parametersOfProtocols : listParametersOfProtocols) {

			ParametersGetPutResponse parametersGetPutResponse = new ParametersGetPutResponse();

			parametersGetPutResponse.setId(Objects.toString(parametersOfProtocols[0], ""));
			parametersGetPutResponse.setIdProtocolo(Objects.toString(parametersOfProtocols[1], ""));
			parametersGetPutResponse.setNombreProtocolo(Objects.toString(parametersOfProtocols[2], ""));
			parametersGetPutResponse.setNombreParametro(Objects.toString(parametersOfProtocols[3], ""));
			parametersGetPutResponse.setValorParametro(Objects.toString(parametersOfProtocols[4], ""));
			parametersGetPutResponse.setEditParametro(Objects.toString(parametersOfProtocols[5], ""));
			parametersGetPutResponse.setObliParametro(Objects.toString(parametersOfProtocols[6], ""));
			parametersGetPutResponse.setLongParametro(Objects.toString(parametersOfProtocols[7], ""));
			parametersGetPutResponse.setTipoDatoParametro(Objects.toString(parametersOfProtocols[8], ""));
			parametersGetPutResponse.setIdValorParametro(Objects.toString(parametersOfProtocols[9], ""));
			parametersGetPutResponse.setTipoProcesamiento(Objects.toString(parametersOfProtocols[10], ""));
			parametersGetPutResponse.setNumeroRegistro(Integer.valueOf(parametersOfProtocols[11].toString()));
			parametersGetPutResponse.setEstadoValor(Objects.toString(parametersOfProtocols[12], ""));

			listParametersGetPutResponse.add(parametersGetPutResponse);

		}

		return listParametersGetPutResponse;
	}

	public List<ProtocolResponse> mapFromObjectProtocolsResponseToListProtocolResponse(List<Object[]> listProtocolsResponse) {

		List<ProtocolResponse> listaProtocolResponse = new ArrayList<>();

		for (Object[] protocol : listProtocolsResponse) {

			ProtocolResponse protocolResponse = new ProtocolResponse();

			protocolResponse.setIdProtocolo(Integer.parseInt(protocol[0].toString()));
			protocolResponse.setNombre(Objects.toString(protocol[1], ""));
			protocolResponse.setActivo(Objects.toString(protocol[2], ""));

			listaProtocolResponse.add(protocolResponse);

		}

		return listaProtocolResponse;
	}

	public List<ProductEdoCtaResponse> mapFromContractProductsResponseToProductEdoCtaResponse(List<Object[]> listContractProductsResponse) {

		List<ProductEdoCtaResponse> listaProductEdoCtaResponse = new ArrayList<>();

		for (Object[] contractProduct : listContractProductsResponse) {

			ProductEdoCtaResponse productEdoCtaResponse = new ProductEdoCtaResponse();

			Integer idProducto;
			Integer numeroReintentos;
			Integer intervaloReintentos;
			Integer vigencia;
			String bandConfirming;

			try {
				idProducto = Integer.parseInt(contractProduct[1].toString());
			} catch (NumberFormatException e) {
				idProducto = 0;
			}

			try {
				numeroReintentos = Integer.parseInt(Objects.toString(contractProduct[13], "0"));
			} catch (NumberFormatException e) {
				numeroReintentos = 0;
			}

			try {
				intervaloReintentos = Integer.parseInt(Objects.toString(contractProduct[14], "0"));
			} catch (NumberFormatException e) {
				intervaloReintentos = 0;
			}

			try {
				vigencia = Integer.parseInt(Objects.toString(contractProduct[10], "0"));
			} catch (NumberFormatException e) {
				vigencia = 30;
			}

			try {
				bandConfirming = Objects.toString(contractProduct[11], "");
			} catch (NumberFormatException e) {
				bandConfirming = "";
			}

			if (vigencia <= 0) {
				vigencia = 30;
			}

			productEdoCtaResponse.setId(idProducto);
			productEdoCtaResponse.setIdContratoProducto(Integer.valueOf(contractProduct[0].toString()));
			productEdoCtaResponse.setClave(Objects.toString(contractProduct[3], ""));
			productEdoCtaResponse.setDescripcion(Objects.toString(contractProduct[2], ""));
			productEdoCtaResponse.setAsignado(Objects.toString(contractProduct[4], ""));
			productEdoCtaResponse.setAplicaEmail(Objects.toString(contractProduct[5], ""));
			productEdoCtaResponse.setEnvioEmail(Objects.toString(contractProduct[6], ""));
			productEdoCtaResponse.setAplicaTipoCargo(Objects.toString(contractProduct[7], ""));
			productEdoCtaResponse.setTipoCargo(Objects.toString(contractProduct[8], ""));
			productEdoCtaResponse.setAplicaVigencia(Objects.toString(contractProduct[9], ""));
			productEdoCtaResponse.setVigencia(vigencia);
			productEdoCtaResponse.setAplicaReintentos(Objects.toString(contractProduct[12], ""));
			productEdoCtaResponse.setNumeroReintentos(numeroReintentos);
			productEdoCtaResponse.setIntervaloReintentos(intervaloReintentos);
			productEdoCtaResponse.setAplicaContratoConfirming(bandConfirming);
			productEdoCtaResponse.setAplicaContratoProvConfirming(productEdoCtaResponse.getDescripcion().contains("PROV CONFIRMING") ? bandConfirming : "");
			productEdoCtaResponse.setActivo(Objects.toString(contractProduct[15], ""));

			listaProductEdoCtaResponse.add(productEdoCtaResponse);

		}

		return listaProductEdoCtaResponse;
	}
	
	/**
	 * Convierte el idValorParametro de String a Integer. 
	 * @param idContrato ID del contrato
	 * @param parametersGetPutResponse Objeto de donde se obtiene idValorParametro
	 * @param idValorParametro variable que almacena nuevo dato en entero
	 * @return retona valor entero de idValorParametro
	 */
	public BigDecimal obtenerIdValorParametro(Integer idContrato, ParametersGetPutResponse parametersGetPutResponse,
			BigDecimal idValorParametro) {

		try {

			idValorParametro = new BigDecimal(parametersGetPutResponse.getIdValorParametro());

		} catch (NumberFormatException nfe) {

			log.info(String.format("No fue posible convertir a numerico el idValorParametro de %s - Canal %s", parametersGetPutResponse.getNombreParametro(), idContrato.toString()));

		}

		return idValorParametro;
	}

}
