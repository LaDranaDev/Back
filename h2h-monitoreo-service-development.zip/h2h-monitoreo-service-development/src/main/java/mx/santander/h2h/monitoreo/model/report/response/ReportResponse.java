package mx.santander.h2h.monitoreo.model.report.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * Respuesta base para retorno de reportes
 *
 * DTO para indicar una respuesta de exito o error
 * 
 * @author Paul Quintero
 * @since 23/05/22
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class ReportResponse implements Serializable {
	/**
	 * Serial ID
	 */
	private static final long serialVersionUID = 49224157029445960L;
	/**
	 * Valor del archivo en base64
	 */
	private String data;
	/**
	 * Tamaño del archivo
	 */
	private Integer length;
	/**
	 * Nombre del archivo
	 */
	private String name;	
	/**
	 * Tipo del archivo
	 */
	private String type;
}
