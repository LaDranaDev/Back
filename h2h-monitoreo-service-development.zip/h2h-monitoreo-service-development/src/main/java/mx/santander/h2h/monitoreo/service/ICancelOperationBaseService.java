package mx.santander.h2h.monitoreo.service;

import java.util.List;

import mx.santander.h2h.monitoreo.model.response.ComboResponse;

/**
 * Interfas con las servcios disponibles
 * @author NTTDATA-NRL
 * @version 1.0
 */
public interface ICancelOperationBaseService {

    /**
     * Funcion para obtener los registros del combo de estatus centro
     * @return List<ComboResponse>
     */
    List<ComboResponse> getListaComboEstatusCentro();

    /**
     * Funcion para obtener los registros del combo de estatus
     * @return List<ComboResponse>
     */
    List<ComboResponse> getListaComboEstatus();
}
