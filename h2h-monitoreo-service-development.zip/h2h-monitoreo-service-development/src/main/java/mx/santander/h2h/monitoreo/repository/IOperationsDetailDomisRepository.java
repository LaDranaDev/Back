package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;

/**
 * Repositorio para detalle de las operaciones Domis
 */
public interface IOperationsDetailDomisRepository {

    /**
     * Obtiene el detalle de la operacion
     * @param idOperacion - ID de operacion
     * @param tabla the tabla
     * @return Detalle de la operacion
     */
    OperationsMonitorQueryResponse obtenerDetalleOperacion(String idOperacion, String tabla);

}
