package mx.santander.h2h.monitoreo.model.report.request;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import mx.santander.h2h.monitoreo.model.response.OperationsHistoryResponse;

/**
 * ----------------------------------
 * DTO que contiene los atributos 
 * a colocar en el reporte
 * ----------------------------------
 */
@Getter
@Setter
@ToString
public class GenerateReportHistorialOperacionesDto implements Serializable {

	/**
	 * Serial UID
	 */
	private static final long serialVersionUID = -379177052745427440L;

	/**
	 * List<OperationsHistoryResponse>
	 */
	private List<OperationsHistoryResponse> histOperList;
	
}
