package mx.santander.h2h.monitoreo.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.model.response.OperacionArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ResultTrackingResponse;

public interface IConsultaTrackingOperacionHistRepository {
	
	ResultTrackingResponse obtenerConteoArchivo(Integer idReg);

	Page<OperacionArchivoResponse> obtenerDetalleArchivo(Pageable page, Integer idReg);
	
	List<OperacionArchivoResponse> obtenerListDetalleArchivo(Integer idReg);
}
