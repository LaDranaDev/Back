package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import net.sf.jasperreports.engine.JRException;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Servicio para la generación de reportes
 * 
 * @since 23/05/22
 * @author Paul Quintero
 *
 */
public interface IJasperReportService {
	/**
	 * Metodo para obtener el pdf con su metadato
	 * 
	 * @param jasperName Nombre del archivo jasper report
	 * @param params     Map con listado de parametros para llenar jasper report
	 * @param dataSet    Registro para llenar el listado del jasper report
	 * 
	 * @return ReportResponse contiene el pdf generado y su metadato
	 * 
	 * @throws IOException excepcion de entrada informacion
	 * @throws JRException excepcion al generar el jasper
	 */
	ReportResponse getPdf(String jasperName, Map<String, Object> params, List<?> dataSet);

	/**
	 * Metodo para obtener el excel con su metadato
	 * 
	 * @param jasperName Nombre del archivo jasper report
	 * @param params     Map con listado de parametros para llenar jasper report
	 * @param dataSet    Registro para llenar el listado del jasper report
	 * 
	 * @return ReportResponse contiene el pdf generado y su metadato
	 * 
	 * @throws IOException excepcion de entrada informacion
	 * @throws JRException excepcion al generar el jasper
	 */
	ReportResponse getXls(String jasperName, Map<String, Object> params, List<?> dataSet);

	/**
	 * Metodo para eliminar el archivo generado
	 * 
	 * @param name nombre del jasper report sin extension
	 * 
	 * @throws IOException excepcion de entrada informacion
	 */
	void deleteFile(String name);

	/**
	 * Metodo para obtener el rft con su metadato
	 * 
	 * @param jasperName Nombre del archivo jasper report
	 * @param params     Map con listado de parametros para llenar jasper report
	 * @param dataSet    Registro para llenar el listado del jasper report
	 * 
	 * @return ReportResponse contiene el pdf generado y su metadato
	 * 
	 * @throws IOException excepcion de entrada informacion
	 * @throws JRException excepcion al generar el jasper
	 */
	ReportResponse getRtf(String jasperName, Map<String, Object> params, List<?> dataSet);
}
