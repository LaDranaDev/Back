package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NivOperacionResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2682519812131945691L;
	
	/** Codigo del cliente. */
	private String codCliente;
	
	/** Cliente. */
	private String cliente;
		
	/** Id del archivo. */
	private Integer idArchivo;
	
	/** Datos del archivo. */
	private ProductoArchivoResponse archivo;
	
	/** Lista de estatus operacion. */
	private List<ComboResponse> listEstatus;
	
	/** Lista detalle de la operacion. */
	private List<OperacionArchivoResponse> listaDetalle;
	
	/** Id del producto. */
	private Integer idProducto;
	
	/** Id del estatus. */
	private Integer identEstatus;
	
	/** Variable para mensaje de error. */
	private String msgError;

	/** Variable para codigo de error. */
	private String codError;

	/** Variable para mensaje de aviso. */
	private String msgAviso;

	/** Variable para codigo de aviso. */
	private String codAviso;

}
