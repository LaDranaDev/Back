/**
 * 
 */
package mx.santander.h2h.monitoreo.repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

/**
 * @author C368734
 *
 */
@Repository
@Transactional
public class GeneralJPARepository implements IGeneralJPARepository {

	@Autowired
    @PersistenceContext
    private EntityManager entityManager;
	/***
	 * numero maximom de registros
	 */
	private static final double NUM_MAX_REG=2000;
	
	@Override
	public List<String> conteoResgistros(String natquer) {
		 String query= "select count(*) from ( "+natquer+")";
		 ArrayList<String> queryes= new ArrayList<>();
		 BigDecimal tamano= (BigDecimal)entityManager.createNativeQuery(query).getSingleResult();
		 
		if(tamano.doubleValue() >NUM_MAX_REG) {
			double paginas= Math.ceil(tamano.doubleValue()/NUM_MAX_REG);
			
			for(int s=0;s< (int)paginas;s++ ) {
			
			String qeryTemp= "SELECT ID_REG, CVE_PROD_OPER FROM ( SELECT a.*, ROWNUM regd FROM (" + 
					natquer + "ORDER BY ID_REG ) a  WHERE ROWNUM <= "+ ((s+1)* (int)NUM_MAX_REG) + ") WHERE regd > "+((int)NUM_MAX_REG*s);
			queryes.add(qeryTemp);
			}
			
		}else {
			queryes.add(natquer);
		} 
		 return queryes;
	}

}
