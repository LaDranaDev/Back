package mx.santander.h2h.monitoreo.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.model.response.ProductoArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ResultTrackingResponse;

public interface IConsultaTrackingProductoRepository {

	ResultTrackingResponse obtenerCatalogoProductos();
	
	ResultTrackingResponse obtenerCatalogoEstatus(String tipoStatus);
	
	ResultTrackingResponse obtenerConteoArchivo(String codCliente, Integer idArchivo);
	
	Page<ProductoArchivoResponse> obtenerDetalleArchivo(Pageable page, Integer idArchivo, Integer idProducto, Integer idEstatus);
	
	List<ProductoArchivoResponse> obtenerListDetalleArchivo(Integer idArchivo, Integer idProducto, Integer idEstatus);
	
}
