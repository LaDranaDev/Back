package mx.santander.h2h.monitoreo.model.request;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * OperationsMonitorRoutesResponse.
 * Modelo de respuesta de la ruta.
 *
 * @author Jesus Soto Aguilar
 * @since 08/07/2023
 */

@Getter
@Setter
public class OperationsDetailRoutesResponse implements Serializable {

    /**
     * Identificador del objeto serializado.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Ruta de detalle.
     */
    private String ruta;

}
