package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.response.OperationsHistoryResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorCatalogsYHorasResponse.HorasCatalogo;

import java.util.List;

/**
 * Repositorio para detalle de las operaciones
 */
public interface IOperationsDetailRepository {

    /**
     * Obtiene el detalle de la operacion
     * @param view - nombre de la vista del producto
     * @param idOperacion - ID de operacion
     * @return Detalle de la operacion
     */
    OperationsMonitorQueryResponse obtenerDetalleOperacion(String view, String idOperacion);

    /**
     * Obtiene el historial de la operacion
     * @param idOperacion - ID de operacion
     * @return Historial de la operacion
     */
    List<OperationsHistoryResponse> obtenerHistorialOperacion(String idOperacion);

    /**
     * Cambia el estatus de la operacion
     * @param idOperacion - ID de operacion
     * @param estatus   - ID del estatus de la operacion
     * @param tabla - nombre de la tabla donde se encuentra el producto
     * @return true o false, indica si la actualizacion se realizo con exito o no
     */
    boolean cambiarEstatusOperacion(String idOperacion, String estatus, String tabla);

    /**
     * Consulta el horario para realizar el cambio de estatus.
     * @param producto String
     * @return boolean
     */
    boolean consultarHorario(String producto);
    
    /**
     * Metodo que obtiene los horarios 
     * @param producto id de producto a obtener
     * @return lista de horas
     */
    List<HorasCatalogo> listaHorarios(String producto);
}
