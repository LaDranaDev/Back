/**
* Santander SCIB - Banco Santander Negocios Globales
* Todos los derechos reservados
* ConsultaTrackingOperacionHistRepository.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <16 jul. 2024 14:39:37>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.repository;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import mx.santander.h2h.monitoreo.model.response.OperacionArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ProductoArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ResultTrackingResponse;
import mx.santander.h2h.monitoreo.util.UtilData;


/**
 * Clase generada para ConsultaTrackingOperacionHistRepository.
 *
 * @autor fsw
 * @modifico C320868
 */
@Repository
public class ConsultaTrackingOperacionHistRepository implements IConsultaTrackingOperacionHistRepository {

	/** Declaracion de EntityManager para entityManager. */
	@Autowired
	private EntityManager entityManager;
	
	
	/**
	 * Obtener conteo archivo.
	 *
	 * @param idReg para id reg
	 * @return el result tracking response
	 */
	@Override
	public ResultTrackingResponse obtenerConteoArchivo(Integer idReg) {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder = queryObtenerConteoArchivo();
		
		Query query = entityManager.createNativeQuery(queryBuilder.toString());
		this.setParamsIdReg(idReg, query);
		
		List<Object[]> detalleArchivosResult = query.getResultList();
		ProductoArchivoResponse productoArchivoResponse = new ProductoArchivoResponse();
		if (detalleArchivosResult != null) {
			for (Object[] map : detalleArchivosResult) {
				productoArchivoResponse.setNombreArchivo( UtilData.toString(map[0]) );
				productoArchivoResponse.setEstatus( UtilData.toString(map[1]) );
				productoArchivoResponse.setProducto( UtilData.toString(map[2]) );
			}
		}
		resultTrackingResponse.setArchProd(productoArchivoResponse);
		return resultTrackingResponse;
	}
	
	/**
	 * Query obtener conteo archivo.
	 *
	 * @return el string builder
	 */
	public StringBuilder queryObtenerConteoArchivo() {
		StringBuilder querySql = new StringBuilder()
				
		.append("SELECT A.NOMBRE_ARCH, ")
		.append("B.DESC_ESTATUS AS DESC_ESTATUS, ")
		.append("F.DESC_PROD ")
		.append("FROM h2h_archivo_tran A, ")
		.append(" h2h_cat_estatus B, ")
		.append(" h2h_reg_tran E,")
		.append(" h2h_cat_prod F ")
		.append(" WHERE B.id_cat_estatus = A.id_estatus")
		.append(" AND A.id_archivo       = E.id_arch ")
		.append(" AND E.cve_prod_oper    = F.cve_prod_oper ")
		.append(" AND E.ID_REG = :idReg ");
		
		return querySql;
	}
	
	/**
	 * Establece el params id reg.
	 *
	 * @param idReg para id reg
	 * @param query para query
	 */
	public void setParamsIdReg(Integer idReg, Query query) {
		query.setParameter("idReg", idReg);
	}

	/**
	 * Obtener detalle archivo.
	 *
	 * @param page para page
	 * @param idReg para id reg
	 * @return el page
	 */
	@Override
	public Page<OperacionArchivoResponse> obtenerDetalleArchivo(Pageable page, Integer idReg) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder = queryObtenerDetalleArchivos();
		
		Query query = entityManager.createNativeQuery(queryBuilder.toString());
		this.setParamsIdReg(idReg, query);
		
		query.setFirstResult(page.getPageNumber() * page.getPageSize());
		query.setMaxResults(page.getPageSize());
		
		List<Object[]> detalleArchivosResult = query.getResultList();
		List<OperacionArchivoResponse> lista = new ArrayList<OperacionArchivoResponse>();
		String estatusIni = "-----------------";
		
		if (detalleArchivosResult != null) {
			for (Object[] map : detalleArchivosResult) {
				OperacionArchivoResponse bean = new OperacionArchivoResponse();
				bean.setStatusIni(estatusIni);
				bean.setStatusFin( UtilData.toString(map[0]) );
				bean.setFechaAplic( UtilData.toString(map[1]) );
				estatusIni = bean.getStatusFin();
				lista.add(bean);
			}
		}
		query.setFirstResult(0);
		query.setMaxResults(Integer.MAX_VALUE);
		
		Integer totalRows = query.getResultList().size();
		return new PageImpl<>(lista, page, totalRows);
	}
	
	/**
	 * Query obtener detalle archivos.
	 *
	 * @return el string builder
	 */
	public StringBuilder queryObtenerDetalleArchivos() {
		StringBuilder querySql = new StringBuilder()
				
		.append("SELECT B.DESC_ESTATUS, ")
		.append("       TO_CHAR(A.FECHA_ESTATUS,'dd/mm/yyyy hh24:mi:ss') AS FECHA_ESTATUS ")
		.append("  FROM H2H_BITA_REG_TRAN A,h2h_cat_estatus B ")
		.append(" WHERE B.id_cat_estatus = A.id_estatus ")
		.append("   AND ID_REG = :idReg ")
		.append(" ORDER BY A.FECHA_ESTATUS ASC ");
		
		return querySql;
	}

	/**
	 * Obtener list detalle archivo.
	 *
	 * @param idReg para id reg
	 * @return el list
	 */
	@Override
	public List<OperacionArchivoResponse> obtenerListDetalleArchivo(Integer idReg) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder = queryObtenerDetalleArchivos();
		
		Query query = entityManager.createNativeQuery(queryBuilder.toString());
		this.setParamsIdReg(idReg, query);
		
		List<Object[]> detalleArchivosResult = query.getResultList();
		List<OperacionArchivoResponse> lista = new ArrayList<OperacionArchivoResponse>();
		String estatusIni = "-----------------";
		
		if (detalleArchivosResult != null) {
			for (Object[] map : detalleArchivosResult) {
				OperacionArchivoResponse bean = new OperacionArchivoResponse();
				bean.setStatusIni(estatusIni);
				bean.setStatusFin( UtilData.toString(map[0]) );
				bean.setFechaAplic( UtilData.toString(map[1]) );
				estatusIni = bean.getStatusFin();
				lista.add(bean);
			}
		}
		return lista;
	}
	
}
