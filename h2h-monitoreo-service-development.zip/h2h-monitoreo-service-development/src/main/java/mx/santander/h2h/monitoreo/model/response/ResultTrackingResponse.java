package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResultTrackingResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4612382625184280423L;

	/** Codigo de error. */
	private String codError;
	
	/** Mensaje de error. */
	private String msgError;
	
	/** Cadena de Respuesta. */
	private String respuesta;
	
	/** Numero de elementos de la consulta.*/
	private int numElem;

	/** Lista de datos para los combos.*/
	private List<ComboResponse> listCombo;
	
	/** Lista de datos para los combos.*/
	private List<ComboDosResponse> listComboDos;
	
	/** Estado de exito. */
	private boolean exitoso;
	
	/** Variable para guardar el valor de X parametro. */
	private int param;
	
	/** Bean de Arhivo.*/
	private ArchivoResponse archivo;
	
	/** Bean de Archivo-Producto.*/
	private ProductoArchivoResponse archProd;
	
	/** Lista de archivos y sus productos.*/
	private List<ProductoArchivoResponse> listArchProd;
	
	/** Lista las operaciones de un archivo.*/
	private List<OperacionArchivoResponse> listArchOpe;
	
	/** Lista  de totales .*/
	private  List<ArchivoResponse> listBeanArchivo;
}
