package mx.santander.h2h.monitoreo.repository;

import java.util.List;

import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersDtoResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;

public interface IGenerateVouchersEntityManagerRepository {

	GenerateVouchersDtoResponse getListPaymentType();

	GenerateVouchersDtoResponse findOperationsCount(OperationsMonitorQueryRequest operationsMonitorQueryRequest);

	List<OperationsMonitorQueryResponse> findOperations(OperationsMonitorQueryRequest operationsMonitorQueryRequest);

	String getLumpSum(OperationsMonitorQueryRequest operationsMonitorQueryRequest);

	String getTotalFiles(OperationsMonitorQueryRequest operationsMonitorQueryRequest);

	GenerateVouchersDtoResponse conceptoValor(String lineaCaptura);

	List<OperationsMonitorQueryResponse> consultaOperacionesExportar(
			OperationsMonitorQueryRequest operationsMonitorQueryRequest);
	
	GenerateVouchersDtoResponse recuperarParamsGenComprobante();

}
