package mx.santander.h2h.monitoreo.exception;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.comunes.exception.ExceptionHandlerBase;
import mx.santander.h2h.monitoreo.constants.ApiConstants;
import mx.santander.h2h.monitoreo.constants.ErrorConstant;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.exception.commons.ForbiddenException;
import mx.santander.h2h.monitoreo.exception.commons.NotDataFoundException;
import mx.santander.h2h.monitoreo.exception.model.ApiError;
import org.owasp.encoder.Encode;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Administrador de excepciones.
 *
 * Clase global para manejar las exepciones presentadas en tiempo de ejecucion
 * 
 * @author Felipe Monzón
 * @since 21/11/21
 */
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler extends ExceptionHandlerBase{


	/**
	 * Método para manejar una excepción de tipo {@link NotDataFoundException}.
	 *
	 * Maneja excepcion unicamente del tipo NotDataFoundException originadas or
	 * consultas a la bd
	 * 
	 * @param request Objeto Http Servlet de petición.
	 * @param ex      Excepción recibida {@link NotDataFoundException}
	 * @return errorResponse {@link ApiError} respuesta específica para
	 *         {@link NotDataFoundException}.
	 */
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	@ExceptionHandler(NotDataFoundException.class)
	public ApiError notDataFoundException(NotDataFoundException ex, WebRequest request) {
		ApiError apiError = ApiError.builder().type(ErrorType.WARN.name()).code(ErrorConstant.RECORD_NOT_FOUND_CODE)
				.message(ErrorConstant.RECORD_NOT_FOUND_MESSAGE).moreInfo(ex.getMessage())
				.uuid(request.getHeader(ApiConstants.HEADER_UUID)).build();
		
		log.info(Encode.forJava(apiError.toString()));
		return apiError;
	}

	/**
	 * Método para manejar una excepción de tipo
	 * {@link HttpRequestMethodNotSupportedException}.
	 *
	 * Maneja excepcion unicamente del tipo HttpRequestMethodNotSupportedException
	 * originada por peticiones no soportadas
	 * 
	 * @param request Objeto Http Servlet de petición.
	 * @param ex      Excepción recibida
	 *                {@link HttpRequestMethodNotSupportedException}
	 * @return errorResponse {@link ApiError} respuesta específica para
	 *         {@link HttpRequestMethodNotSupportedException}.
	 */
	@ExceptionHandler(HttpRequestMethodNotSupportedException.class)
	@ResponseStatus(value = HttpStatus.METHOD_NOT_ALLOWED)
	public ApiError resolveHttpRequestMethodNotSupportedException(HttpRequestMethodNotSupportedException ex,
			WebRequest request) {
		ApiError apiError = ApiError.builder().type(ErrorType.ERROR.name()).code(ErrorConstant.BAD_REQUEST_CODE)
				.message(ex.getMessage()).uuid(request.getHeader(ApiConstants.HEADER_UUID)).build();
		
		log.info(Encode.forJava(apiError.toString()));
		return apiError;
	}

	/**
	 * Método para manejar una excepción de tipo
	 * {@link HttpMediaTypeNotSupportedException}.
	 *
	 * @param request Objeto Http Servlet de petición.
	 * @param ex      Excepción recibida {@link HttpMediaTypeNotSupportedException}
	 * @return errorResponse {@link ApiError} respuesta específica para
	 *         {@link HttpMediaTypeNotSupportedException}.
	 */
	@ExceptionHandler(HttpMediaTypeNotSupportedException.class)
	@ResponseStatus(value = HttpStatus.UNSUPPORTED_MEDIA_TYPE)
	public ApiError resolveHttpMediaTypeNotSupportedException(HttpMediaTypeNotSupportedException ex,
			WebRequest request) {
		ApiError apiError = ApiError.builder().type(ErrorType.ERROR.name()).code(ErrorConstant.BAD_REQUEST_CODE)
				.message(ex.getMessage()).uuid(request.getHeader(ApiConstants.HEADER_UUID)).build();
		
		log.info(Encode.forJava(apiError.toString()));
		return apiError;
	}

	/**
	 * Método para manejar una excepción de tipo
	 * {@link HttpMediaTypeNotAcceptableException}.
	 *
	 * @param request Objeto Http Servlet de petición.
	 * @param ex      Excepción recibida {@link HttpMediaTypeNotAcceptableException}
	 * @return errorResponse {@link ApiError} respuesta específica para
	 *         {@link HttpMediaTypeNotAcceptableException}.
	 */
	@ExceptionHandler(HttpMediaTypeNotAcceptableException.class)
	@ResponseStatus(value = HttpStatus.NOT_ACCEPTABLE)
	public ApiError resolveHttpMediaTypeNotAcceptableException(WebRequest request,
			HttpMediaTypeNotAcceptableException ex) {
		ApiError apiError = ApiError.builder().type(ErrorType.INVALID.name()).code(ErrorConstant.BAD_REQUEST_CODE)
				.message(ex.getMessage()).uuid(request.getHeader(ApiConstants.HEADER_UUID)).build();
		
		log.info(Encode.forJava(apiError.toString()));
		return apiError;
	}

	/**
	 * Método para manejar una excepción de tipo
	 * {@link MethodArgumentNotValidException}.
	 *
	 * @param request Objeto Http Servlet de petición.
	 * @param ex      Excepción recibida {@link MethodArgumentNotValidException}
	 * @return errorResponse {@link ApiError} respuesta específica para
	 *         {@link MethodArgumentNotValidException}.
	 */
	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public ApiError resolveMethodArgumentNotValidException(MethodArgumentNotValidException ex, WebRequest request) {
		List<FieldError> fieldErrors = ex.getBindingResult().getFieldErrors();

		List<String> fields = new ArrayList<>();
		Map<String, List<String>> groupedErrors = new HashMap<>();

		for (FieldError fieldError : fieldErrors) {
			String field = fieldError.getField();
			groupedErrors.computeIfAbsent(fieldError.getDefaultMessage(), key -> Collections.singletonList(field));
			fields.add(field);
		}
		ApiError apiError = ApiError.builder().type(ErrorType.INVALID.name()).code(ErrorConstant.BAD_REQUEST_CODE)
				.message(groupedErrors.toString()).moreInfo(fields.toString())
				.uuid(request.getHeader(ApiConstants.HEADER_UUID)).build();
		
		log.info(Encode.forJava(apiError.toString()));
		return apiError;
	}

	/**
	 * Método para manejar una excepción de tipo {@link BusinessException}.
	 *
	 * @param request Objeto Http Servlet de petición.
	 * @param ex      Excepción recibida {@link BusinessException}
	 * @return errorResponse {@link ApiError} respuesta específica para
	 *         {@link BusinessException}.
	 */
	@ExceptionHandler(BusinessException.class)
	@ResponseStatus(value = HttpStatus.OK)
	public ApiError resolveBusinessException(WebRequest request, BusinessException ex) {
		ApiError apiError = ApiError.builder().type(ErrorType.WARN.name()).code(ex.getCode())
				.message(ex.getMessage()).uuid(request.getHeader(ApiConstants.HEADER_UUID)).build();
		
		log.info(Encode.forJava(apiError.toString()));
		return apiError;
	}

	/**
	 * Método para manejar una excepción de tipo {@link ForbiddenException}.
	 *
	 * @param request Objeto Http Servlet de petición.
	 * @param ex      Excepción recibida {@link ForbiddenException}
	 * @return errorResponse {@link ApiError} respuesta específica para
	 *         {@link ForbiddenException}.
	 */
	@ExceptionHandler(ForbiddenException.class)
	@ResponseStatus(value = HttpStatus.FORBIDDEN)
	public ApiError resolveForbiddenException(WebRequest request, ForbiddenException ex) {
		ApiError apiError = ApiError.builder().type(ErrorType.WARN.name()).code(ex.getCode()).message(ex.getMessage())
				.uuid(request.getHeader(ApiConstants.HEADER_UUID)).build();
		
		log.info(Encode.forJava(apiError.toString()));
		return apiError;
	}
}
