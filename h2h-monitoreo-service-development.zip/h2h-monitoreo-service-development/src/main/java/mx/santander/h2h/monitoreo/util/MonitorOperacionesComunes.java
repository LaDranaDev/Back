package mx.santander.h2h.monitoreo.util;

import java.util.Map;

import org.apache.commons.lang.StringUtils;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;


/**
 *  Declaracion de Constante log.
 *
 * @autor C320868
 * @modifico C320868
 */
@Slf4j
public class MonitorOperacionesComunes {
	
	/**
	 * Metodo de ayuda para la clase de MonitorOperacionesProdDAOHelper.
	 *
	 * @param consultaOperaciones Filtros del query
	 * @return mapa de datos
	 */
	public static void agregaFiltrosConsultaOperaciones(
			OperationsMonitorQueryRequest consultaOperaciones, StringBuilder query,
			Map<String, Object> params
		) {
		boolean addAnd = false;
		query.append(" WHERE ");
		if (!StringUtils.EMPTY.equals(consultaOperaciones.getTipOperacion())) {
			log.info("*****SI NO ES VACIO AGREGA TIPO OPERACION*****");
			query.append("PCONF.CLVE_OPER = :cveOper ");
			params.put("cveOper", consultaOperaciones.getTipOperacion());
			addAnd = true;
		}
		if (!StringUtils.EMPTY.equals(consultaOperaciones.getCveProveedor())) {
			log.info("*****SI NO ES VACIO AGREGA CLAVE DE PROVEEDOR*****");
			if( addAnd ) {
				query.append(" AND ");
			}
			query.append("PCONF.CLVE_PROV LIKE '%' || :cveProv || '%'");
			params.put("cveProv", consultaOperaciones.getCveProveedor());
		}
	}
	

	/**
	 * Constructor default.
	 */
	private MonitorOperacionesComunes() {
	}
}
