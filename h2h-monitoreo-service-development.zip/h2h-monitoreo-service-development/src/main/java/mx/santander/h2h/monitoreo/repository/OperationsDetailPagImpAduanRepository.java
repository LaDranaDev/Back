package mx.santander.h2h.monitoreo.repository;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.constants.MonitorOperacionesConstants;
import mx.santander.h2h.monitoreo.model.response.MonitorProdOperacionesCompResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;

/**
 * OperationsDetailPagImpAduan.
 *
 * @author Jesus Soto Aguilar
 */
@Slf4j
@Repository
public class OperationsDetailPagImpAduanRepository implements IOperationsDetailPagImpAduanRepository {

    @Autowired
    private EntityManager entityManager;

    @Override
    public OperationsMonitorQueryResponse obtenerDetalleOperacion(String view, String idOperacion) {
        String stringQuery = generaConsultaDetalleOperacion(idOperacion);
        Query query = entityManager.createNativeQuery(stringQuery, Tuple.class);
//        query.setParameter("idOperacion", idOperacion);

        MonitorProdOperacionesCompResponse respuesta = new MonitorProdOperacionesCompResponse();
        for (Object obj : query.getResultList()) {
            if (obj instanceof Tuple) {
                Tuple tuple = (Tuple) obj;
                Map<String, Object> row = new HashMap<>();
                tuple.getElements().forEach(t -> row.put(t.getAlias(), tuple.get(t)));
                rellenaRespuestaMonitorOperacionesDTO(row, respuesta);
            }
        }

        return respuesta;
    }

    private void rellenaRespuestaMonitorOperacionesDTO(Map<String, Object> row, MonitorProdOperacionesCompResponse respuestaPagImpAdu) {
        DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols();
        formatSymbols.setDecimalSeparator('.');
        formatSymbols.setGroupingSeparator(',');
        final DecimalFormat decimalFormat = new DecimalFormat("###,###,###,###,##0.00", formatSymbols);

        respuestaPagImpAdu.setProducto(Objects.toString(row.get("DESC_PROD"), ""));
        respuestaPagImpAdu.setCodCli(Objects.toString(row.get("BUC"), ""));
        respuestaPagImpAdu.setFechaAplic(Objects.toString(row.get("FECHA_APLICACION"), ""));
        respuestaPagImpAdu.setNomArch(Objects.toString(row.get("NOMBRE_ARCH"), ""));
        respuestaPagImpAdu.setEstatus(Objects.toString(row.get("DESC_ESTATUS"), ""));

        respuestaPagImpAdu.setLineaCaptura(Objects.toString(row.get("LINEA_CAPTURA"), ""));
        respuestaPagImpAdu.setIdOperacion(Objects.toString(row.get("ID_REG"), ""));

        respuestaPagImpAdu.setTransSat(Objects.toString(row.get("NUM_TRANSACC"), ""));
        respuestaPagImpAdu.setNombreOrd(Objects.toString(row.get("NOMB_CLTE"), ""));
        respuestaPagImpAdu.setCtaCargo(Objects.toString(row.get("NUM_CTA_CARG"), ""));

        respuestaPagImpAdu.setPatente(Objects.toString(row.get("PATENTE"), ""));
        respuestaPagImpAdu.setPedimento(Objects.toString(row.get("PEDIMENTO"), ""));
        respuestaPagImpAdu.setAduana(Objects.toString(row.get("ADUANA"), ""));
        respuestaPagImpAdu.setDivisa(Objects.toString(row.get("DIVISA"), ""));
        respuestaPagImpAdu.setImporte(row.get(MonitorOperacionesConstants.IMPORTE) == null || Objects.toString(row.get(MonitorOperacionesConstants.IMPORTE), "").trim().isEmpty()
                ? "$0.00" : "$" + decimalFormat.format(Double.valueOf(row.get(MonitorOperacionesConstants.IMPORTE).toString().trim())));
        respuestaPagImpAdu.setDescError(Objects.toString(row.get("MSG_H2H"), ""));

    }

    /**
     * Genera la consulta del detalle de la operacion
     *
     * @param idOperacion - ID de operacion
     * @return Consulta de detalle de operacion
     */
    private String generaConsultaDetalleOperacion(String idOperacion) {

        log.info("Preparando consulta de operaciones");
        final StringBuilder query = new StringBuilder();
        query.append("SELECT PROD.* FROM ( ")
                .append(getConsultaByProducto(true))
                .append(" UNION ALL ")
                .append(getConsultaByProducto(false))
                .append(") PROD WHERE PROD.ID_REG = ")
                .append(idOperacion);

        return query.toString();
    }

    /**
     * Crea el query por producto y si el del dia de hoy o el de tres meses
     * @param tresMeses boleano indicador de tres meses
     * @return SQL del producto
     */
    private String getConsultaByProducto(boolean tresMeses) {
        final StringBuilder query = new StringBuilder();
        query
		        .append("SELECT ")
				.append(" REG.DIVI DIVISA,REG.CNTA_CARG NUM_CTA_CARGO, ") 
			    .append("ARCH.NOMBRE_ARCH, DETA.LINEA_CAPTURA, REG.ID_ESTATUS, EST.DESC_ESTATUS, DETA.NUM_TRANSACC, REG.MONT IMPORTE, ")
			    .append(" to_char(REG.FECH_APLI, 'dd/mm/yyyy') FECHA_APLICACION, ")
			    .append(" to_char(DETA.FECHA_PAGO,'dd/mm/yyyy') FECHA_PAGO , DETA.BUC, ")
			    .append("DETA.ID_REG, DETA.PATENTE, DETA.PEDIMENTO, DETA.ADUANA, CNTA_CARG.NOMB_TITU NOMB_CLTE, ")
		        .append("DETA.NUM_CTA_CARG,REG.CVE_PROD_OPER,PROD.DESC_PROD, ")
				.append("DECODE(MSG.ID_MSG, 0, deta.msg_error, MSG.MSG_H2H) MSG_H2H ")
				.append("FROM  H2H_MX_PROD_PECE")
                .append(tresMeses ? "_TRAN DETA ": " DETA ")
                .append("INNER JOIN ").append(tresMeses ? "H2H_REG_TRAN" : "H2H_REG").append(" REG ON REG.ID_REG=DETA.ID_REG ")
                .append("INNER JOIN ").append(tresMeses ? "H2H_ARCHIVO_TRAN" : "H2H_ARCHIVO").append(" ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ")
                .append("INNER JOIN H2H_CAT_PROD PROD ON PROD.CVE_PROD_OPER=REG.CVE_PROD_OPER ")
    			.append("INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS ")
    			.append("INNER JOIN H2H_MSG MSG ON MSG.ID_MSG = REG.ID_MSG ")
    			.append("LEFT JOIN H2H_CTA_INFO CNTA_CARG ON REG.CNTA_CARG = CNTA_CARG.NUME_CTA AND CNTA_CARG.TIPO_CTA = 'O' ");
        return query.toString();
    }

}
