package mx.santander.h2h.monitoreo.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.commons.utils.ConsultaTrackingUtil;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.NivelOperacionRequest;
import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import mx.santander.h2h.monitoreo.model.response.NivelOperacionResponse;
import mx.santander.h2h.monitoreo.model.response.OperacionArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ProductoArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ResultTrackingResponse;
import mx.santander.h2h.monitoreo.repository.IConsultaTrackingOperacionRepository;

@Service
@Slf4j
public class ConsultaTrackingOperacionService implements IConsultaTrackingOperacionService {
	
	@Autowired
	private IConsultaTrackingOperacionRepository consultaTrackingOperacionRepository;
	
	/**
	 * Servicio para generacion de Reportes con JasperReport
	 */
	@Autowired
	private IJasperReportService jasperReportService;
	
	@Override
	public NivelOperacionResponse iniciaNivelOperacion(NivelOperacionRequest nivelOperacion) {
		NivelOperacionResponse nivelOperacionResponse = new NivelOperacionResponse();
		
		nivelOperacionResponse.setCodCliente(nivelOperacion.getCodCliente());
		nivelOperacionResponse.setCliente(nivelOperacion.getNomCliente());
		nivelOperacionResponse.setIdArchivo(nivelOperacion.getIdArchivo());
		nivelOperacionResponse.setIdProducto(nivelOperacion.getIdProducto());
		nivelOperacionResponse.setFecha(new SimpleDateFormat("dd/MM/yyyy").format(new Date()));
		nivelOperacionResponse.setFechaActual(new Date());
		
		nivelOperacionResponse.setListEstatus(obtenerCatalogoEstatus());
		nivelOperacionResponse.setArchivo(obtenerConteoArchivo(nivelOperacion.getCodCliente(), nivelOperacion.getIdArchivo(), nivelOperacion.getIdProducto(), nivelOperacion.getIdEstatus()));
		
		nivelOperacionResponse.getArchivo().setMontoFmt(ConsultaTrackingUtil.formateaImporteOperacion(nivelOperacionResponse.getArchivo().getMonto()));
        //bean.getArchivo().setMontoFmt(UtilGenericError.getLabelFront(bean.getArchivo().getMontoFmt()));
		
		return nivelOperacionResponse;
	}

	@Override
	public List<ComboResponse> obtenerCatalogoEstatus() {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		resultTrackingResponse = consultaTrackingOperacionRepository.obtenerCatalogoEstatus("R");
		return resultTrackingResponse.getListCombo();
	}

	@Override
	public ProductoArchivoResponse obtenerConteoArchivo(String codCliente, Integer idArchivo, Integer idProducto, Integer idEstatus) {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		resultTrackingResponse = consultaTrackingOperacionRepository.obtenerConteoArchivo(codCliente, idArchivo, idProducto, idEstatus);
		return resultTrackingResponse.getArchProd();
	}

	@Override
	public Page<OperacionArchivoResponse> obtenerDetalleArchivo(NivelOperacionRequest nivelOperacion, Pageable page) {
		return consultaTrackingOperacionRepository.obtenerDetalleArchivo(page, nivelOperacion.getIdArchivo(), nivelOperacion.getIdProducto(), nivelOperacion.getIdEstatus());
	}

	@Override
	public List<OperacionArchivoResponse> obtenerListDetalleArchivo(Integer idArchivo, Integer idProducto, Integer idEstatus) {
		return consultaTrackingOperacionRepository.obtenerListDetalleArchivo(idArchivo, idProducto, idEstatus);
	}
	
	@Override
	public ReportResponse getReportXls(NivelOperacionRequest nivelOperacion, String usuario) {
		ReportResponse response = new ReportResponse();
		try {
			NivelOperacionResponse bean = this.iniciaNivelOperacion(nivelOperacion);
			List<OperacionArchivoResponse> lista = this.obtenerListDetalleArchivo(nivelOperacion.getIdArchivo(), nivelOperacion.getIdProducto(), nivelOperacion.getIdEstatus());
			Map<String, Object> reportParam = new HashMap<>();
            
			reportParam.put("USER", usuario);
			reportParam.put("LOGO_SANTANDER", "\\imgs\\Santander.jpg");
			reportParam.put("ID_MOVIMIENTO_H2H", "Id. Movimiento H2H");
			reportParam.put("ESTATUS", "Estatus Movimiento");
			reportParam.put("PRODUCTO", "Producto");
			reportParam.put("MONTO", "Monto");
			reportParam.put("CUENTA_CARGO", "Cuenta Cargo");
			reportParam.put("CUENTA_ABONO", "Cuenta Abono");
            reportParam.put("REFERENCIA_BE", "Referencia BE");
            reportParam.put("FECHA_APLICACION", "Fecha Aplicación");
            reportParam.put("UMBRAL_BE", "Umbral de BE");
            reportParam.put("HORA_ENVIO_BE", "Hora de Envío a BE");
            reportParam.put("HORA_REGRESO_BE", "Hora de Regreso a BE");
            reportParam.put("FILTRO_CLIENTE", "Cliente");
            reportParam.put("FILTRO_NOMBRE_ARCHIVO", "Nombre Archivo");
            reportParam.put("FILTRO_FECHA_RECEPCION", "Fecha Recepción");
            reportParam.put("FILTRO_ESTATUS_ARCHIVO", "Estatus Archivo");
            reportParam.put("FILTRO_NO_MOVIMIENTOS", "No. Movimientos");
            reportParam.put("FILTRO_MONTO", "Monto");
            reportParam.put("FILTRO_ESTATUS_MOV", "Estatus Movimiento");
            reportParam.put("TITULO_REPORTE", "Consulta Tracking de Archivo" + " - "  + "Nivel Operación");
            reportParam.put("VALOR_ESTATUS_MOV", bean.getArchivo().getEstatus());
            
            reportParam.put("cliente", bean.getCliente());
            reportParam.put("nombreArchivo", bean.getArchivo().getNombreArchivo());
            reportParam.put("estatus", bean.getArchivo().getEstatus());
            reportParam.put("totalOperaciones", bean.getArchivo().getTotalOperaciones());
            reportParam.put("montoFmt", bean.getArchivo().getMontoFmt());
			
			response = jasperReportService.getXls("NivelOperacion.jasper", reportParam, lista);
			
			response.setType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
		}catch (BusinessException e) {
			log.error("Error en la generacion del reporte en xls operacion historica.", e);
			throw e;
		} finally {
			log.info("Fin operacion: Genera reporte en xls operacion historica");
		}
		
		return response;
	}

}
