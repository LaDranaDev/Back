package mx.santander.h2h.monitoreo.service;

import java.net.MalformedURLException;
import java.net.URL;

import org.springframework.stereotype.Service;

import mx.isban.h2h.comprobantefiscal.ComprobanteSelloDigitalWSServiceFII;

/**
 * Clase que inicia el servicio de ComprobanteSelloDigitalWSServiceFII para su
 * invocacion
 * 
 * @author Omar Rosas
 * @since 20/10/2023
 *
 */
@Service
public class ComprobanteSelloDigitalWSServiceFIIService implements IComprobanteSelloDigitalWSServiceFIIService {

	@Override
	public ComprobanteSelloDigitalWSServiceFII getWSComprobanteSelloDigitalWSServiceFII(String url)
			throws MalformedURLException {
		return new ComprobanteSelloDigitalWSServiceFII(new URL(url));
	}
}
