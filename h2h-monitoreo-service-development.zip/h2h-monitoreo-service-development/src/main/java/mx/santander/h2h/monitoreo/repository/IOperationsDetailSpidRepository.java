package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;

/**
 * IOperationsDetailSpidRepository.
 *
 * @author Jesus Soto Aguilar
 * @Since 07/07/2023
 */
public interface IOperationsDetailSpidRepository {

    /**
     * Obtiene el detalle de la operacion
     * @param idOperacion - ID de operacion
     * @return Detalle de la operacion
     */
    OperationsMonitorQueryResponse obtenerDetalleOperacion(String idOperacion);
}
