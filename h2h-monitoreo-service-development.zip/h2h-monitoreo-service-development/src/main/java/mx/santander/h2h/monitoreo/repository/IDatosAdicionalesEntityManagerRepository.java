package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.response.GenerateVouchersDtoResponse;
import mx.santander.h2h.monitoreo.model.response.VoucherRequestDto;

/**
 * Repositorio para definir las operaciones para optener los datos adicionales
 * del comprobantes
 * 
 * @author Omar Rosas
 * @since 19/10/2023
 *
 */
public interface IDatosAdicionalesEntityManagerRepository {

	/**
	 * Descripcion : Metodo que realiza la consulta de un Id_Reg en la tabla
	 * H2H_PROD_PAGO_REFE
	 * 
	 * @param datosAdicionales bean que contiene los atributos necesarios para la
	 *                         operacion
	 * @return GenerateVouchersDtoResponse bean que almacenara la respuesta de DAO
	 */
	GenerateVouchersDtoResponse existeEnPagoRefe(VoucherRequestDto datosAdicionales);

	/**
	 * Descripcion : Metodo que realiza la consulta de un Id_Reg en la tabla
	 * H2H_PROD_PAGO_REFE_TRAN
	 * 
	 * @param datosAdicionales bean que contiene los atributos necesarios para la
	 *                         operacion
	 * @return GenerateVouchersDtoResponse bean que almacenara la respuesta de DAO
	 */
	GenerateVouchersDtoResponse existeEnPagoRefeTran(VoucherRequestDto datosAdicionales);

	/**
	 * Descripcion : Metodo que realiza la actualizacion de los datos adicionales
	 * asociados a un Id_Reg en la tabla H2H_PROD_PAGO_REFE
	 * 
	 * @param datosAdicionales bean que contiene los atributos necesarios para la
	 *                         operacion
	 */
	void actualizaPagoRefe(VoucherRequestDto datosAdicionales);

	/**
	 * Descripcion : Metodo que realiza la actualizacion de los datos adicionales
	 * asociados a un Id_Reg en la tabla H2H_PROD_PAGO_REFE_TRAN
	 * 
	 * @param datosAdicionales bean que contiene los atributos necesarios para la
	 *                         operacion
	 */
	void actualizaPagoRefeTran(VoucherRequestDto datosAdicionales);

}
