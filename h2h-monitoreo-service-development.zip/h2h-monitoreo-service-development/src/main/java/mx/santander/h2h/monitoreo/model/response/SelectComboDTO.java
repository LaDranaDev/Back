/**
 * Descripción: Objetos de acceso a datos de combos para el Monitor de Operaciones
 * 
 */
package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Objetos de acceso a datos de combos para el Monitor de Operaciones
 * 
 * @author sbautish
 * @version 1.0
 *
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
public class SelectComboDTO implements Serializable {

	/**
	 * Versión serial de la clase
	 */
	private static final long serialVersionUID = 6274219268026819246L;

	/** Llave */
	private String key;

	/** Valor */
	private String value;

}
