package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NivelOperacionHistResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1745680724592686176L;
	
	/** Cliente. */
	private String cliente;
	
	/** Id del archivo. */
	private String nomArch;
	
	/** Id del archivo. */
	private String estatusArch;
	
	/** Id del archivo. */
	private String producto;
	
	/** Fecha de consulta. */
	private String fecha;
	
	/** Id de movimiento H2H. */
	private Integer idReg;

}
