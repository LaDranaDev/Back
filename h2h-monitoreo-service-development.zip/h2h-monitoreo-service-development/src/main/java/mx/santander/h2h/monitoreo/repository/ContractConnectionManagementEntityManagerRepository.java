package mx.santander.h2h.monitoreo.repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.entity.CatalogStatusEntity;
import mx.santander.h2h.monitoreo.model.entity.ParameterEntity;
import mx.santander.h2h.monitoreo.model.request.ContractConnectionManagementRequest;
import mx.santander.h2h.monitoreo.model.response.ContractConnectionManagementResponse;
import mx.santander.h2h.monitoreo.model.response.ParametersGetPutResponse;
import mx.santander.h2h.monitoreo.model.response.ProductEdoCtaResponse;
import mx.santander.h2h.monitoreo.model.response.ProtocolResponse;
import mx.santander.h2h.monitoreo.util.ContractConnectionManagementEntityManagerUtils;

/**
 * Repository de operación de administración de conexión de contrato
 * 
 * @author sbautish
 *
 */
@Slf4j
@Repository
public class ContractConnectionManagementEntityManagerRepository
		implements IContractConnectionManagementEntityManagerRepository {

	private static final String ID_CONTRATO = "idContrato";
	@Autowired
	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private ContractConnectionManagementEntityManagerUtils contractConnectionManagementEntityManagerUtils;

	/**
	 * Obtiene datos del contrato buscando por número de contrato o código del
	 * cliente
	 */
	@Override
	public PageImpl<ContractConnectionManagementResponse> findContractConnectionByContractNumberOrClientCode(
			ContractConnectionManagementRequest contractConnectionManagementRequest, ParameterEntity tipoEstatus,
			ParameterEntity estatusCancelada, Pageable pageable) {

		log.debug(
				"ContractConnectionManagementEntityManagerRepositoryImpl consulta findContractConnectionByContractNumberOrClientCode");

		StringBuilder queryCatalogStatus = new StringBuilder(
				"SELECT catalogEstatus FROM CatalogStatusEntity catalogEstatus WHERE TIPO_ESTATUS = :tipoEstatus AND DESC_ESTATUS = :estatusCancelada ORDER BY DESC_ESTATUS");

		List<CatalogStatusEntity> listCatalogStatusEntity = entityManager
				.createQuery(queryCatalogStatus.toString(), CatalogStatusEntity.class)
				.setParameter("tipoEstatus", tipoEstatus.getValue())
				.setParameter("estatusCancelada", estatusCancelada.getValue()).getResultList();

		Integer idCat = listCatalogStatusEntity.get(0).getIdCat();

		StringBuilder queryContractConnection = new StringBuilder(
				"SELECT DISTINCT cntr.NUM_CNTR AS CONTRATO, DECODE(clte.personalidad, 'F', TRIM(nombre) || ' ' || TRIM(appaterno) || ' ' || TRIM(apmaterno), DECODE(clte.RAZON_SCIA, 'null', ' ', NVL(TRIM(clte.RAZON_SCIA), ' '))) AS RAZON_SOCIAL, clte.BUC AS CODIGO_CLIENTE, est.Desc_Estatus AS DESC_ESTATUS, clte.nombre || ' ' || clte.APPATERNO || ' ' || clte.apmaterno AS NOMBRE, clte.personalidad, cta.NUM_CTA CTA_EJE, cntr.ID_CNTR FROM H2H_CNTR cntr, H2H_CLTE clte, H2H_CNTR_CTA cta, H2H_CAT_ESTATUS est WHERE cntr.ID_CLTE = clte.Id_Clte AND cntr.Id_Cntr = cta.Id_Cntr AND cntr.Id_Estado = est.Id_cat_Estatus AND est.Tipo_Estatus = 'C' AND cta.TIPO_CTA = 'E'");

		if (idCat > 0) {

			queryContractConnection.append(" AND est.ID_CAT_ESTATUS != :idCat");
		}

		if (StringUtils.isNotBlank(contractConnectionManagementRequest.getCodigoCliente())) {

			queryContractConnection.append(" AND clte.BUC = :codigoCliente");
		}

		if (StringUtils.isNotBlank(contractConnectionManagementRequest.getNumeroContrato())) {

			queryContractConnection.append(" AND cntr.NUM_CNTR = :numeroContrato");
		}

		queryContractConnection.append(" ORDER BY 1");

		Query contractConnectionResult = entityManager.createNativeQuery(queryContractConnection.toString());

		if (idCat > 0) {

			contractConnectionResult.setParameter("idCat", idCat);
		}

		if (StringUtils.isNotBlank(contractConnectionManagementRequest.getCodigoCliente())) {

			contractConnectionResult.setParameter("codigoCliente",
					contractConnectionManagementRequest.getCodigoCliente());
		}

		if (StringUtils.isNotBlank(contractConnectionManagementRequest.getNumeroContrato())) {

			contractConnectionResult.setParameter("numeroContrato",
					contractConnectionManagementRequest.getNumeroContrato());
		}

		contractConnectionResult.setFirstResult(pageable.getPageNumber() * pageable.getPageSize());
		contractConnectionResult.setMaxResults(pageable.getPageSize());

		List<Object[]> listContractConnectionResult = contractConnectionResult.getResultList();

		contractConnectionResult.setFirstResult(0);
		contractConnectionResult.setMaxResults(Integer.MAX_VALUE);

		Integer totalRows = contractConnectionResult.getResultList().size();

		return new PageImpl<>(mapFromContractConnectionEntityManagerToContractConnectionManagementResponse(
				listContractConnectionResult), pageable, totalRows);
	}

	/**
	 * Obtiene datos de protocolo por id de contrato
	 */
	@Override
	public String findContractConnectionProtocolByIdContract(String idContrato) {

		StringBuilder queryProtocolName = new StringBuilder(
				"SELECT DISTINCT NVL(pp.ID_PTCL, 0) ID_PTCL, pt.nombre AS NOMBRE FROM H2H_PATT_PTCL param, H2H_PARA_PTCL pp, h2h_ptcl pt WHERE param.ID_CNTR = :idContrato AND pp.ID_PARA_PTCL = param.ID_PARA_PTCL AND pp.id_ptcl = pt.id_ptcl");

		List<Object[]> listProtocolName = entityManager.createNativeQuery(queryProtocolName.toString())
				.setParameter(ID_CONTRATO, idContrato).getResultList();

		String protocolo = "";

		for (Object[] protocolName : listProtocolName) {

			protocolo = protocolName[1].toString();
		}

		return protocolo;
	}

	/**
	 * Obtiene envío al cliente por id contrato
	 */
	@Override
	public String findCustomerShippingByIdContract(String idContrato) {

		StringBuilder queryCustomerShipping = new StringBuilder(
				"SELECT ID_PTCL_PARA FROM H2H_MX_PTCL_PARA WHERE ID_CNTR = :idContrato");

		List<BigDecimal> listCustomerShipping = entityManager.createNativeQuery(queryCustomerShipping.toString())
				.setParameter(ID_CONTRATO, idContrato).getResultList();

		String envioCliente = "";

		for (BigDecimal customerShipping : listCustomerShipping) {

			envioCliente = customerShipping.toString();
		}

		return envioCliente;
	}

	/**
	 * Obtiene productos por número de contrato
	 */
	@Override
	public List<ProductEdoCtaResponse> findContractProductsForProducts(String numeroContrato) {

		StringBuilder queryFindContractProducts = new StringBuilder(
				"SELECT NVL(pa.ID_CNTR_PROD, 0) AS ID_CNTR_PROD, p.Id_Prod, p.desc_prod, p.Cve_Prod,");
		queryFindContractProducts.append(
				" CASE WHEN NVL(pa.Id_Prod, 0) > 0 AND pa.Band_Activo = 'A' THEN 'S' ELSE 'N' END prod_asignado, p.band_Email, DECODE(NVL(pa.Envio_Email, 'I'), 'A', 'checked', '') AS envio_email,");
		queryFindContractProducts.append(
				" p.band_Tipo_Cargo, pa.Tipo_Cargo, p.band_Vigencia, pa.Vigencia, p.band_Confirming, p.band_Reintentos, pa.num_rein, pa.interv_rein, pa.Band_Activo");
		queryFindContractProducts.append(
				" FROM H2h_Cat_Prod p, (SELECT pc.ID_CNTR_PROD, cntr.NUM_CNTR FOLIO, pc.ID_PROD, pc.ENVIO_EMAIL, pc.TIPO_CARGO, pc.NUM_REIN, pc.INTERV_REIN, pc.VIGENCIA,");
		queryFindContractProducts.append(
				" pc.Band_Activo FROM H2H_CNTR cntr, H2H_CNTR_PROD pc WHERE cntr.Num_Cntr = :numeroContrato AND cntr.Id_Cntr = Pc.Id_Cntr) pa");
		queryFindContractProducts.append(
				" WHERE p.Id_Prod = pa.id_prod(+) AND (p.VISIBILIDAD = 'A' OR p.VISIBILIDAD = 'P') AND p.Band_Activo = 'A' ORDER BY p.Id_Prod");

		List<Object[]> listContractProductsResponse = entityManager
				.createNativeQuery(queryFindContractProducts.toString()).setParameter("numeroContrato", numeroContrato)
				.getResultList();

		return contractConnectionManagementEntityManagerUtils
				.mapFromContractProductsResponseToProductEdoCtaResponse(listContractProductsResponse);
	}

	/**
	 * Obtiene todos los protocolos
	 */
	@Override
	public List<ProtocolResponse> findProtocols() {

		StringBuilder queryFindProtocols = new StringBuilder(
				"SELECT NVL(ID_PTCL, 0) AS ID_PROT, NOMBRE, BAND_ACTIVO AS ESTADO FROM H2H_PTCL WHERE BAND_ACTIVO = 'A' ORDER BY NLSSORT(UPPER(NOMBRE), 'NLS_SORT=SPANISH')");

		List<Object[]> listProtocolsResponse = entityManager.createNativeQuery(queryFindProtocols.toString())
				.getResultList();

		return contractConnectionManagementEntityManagerUtils
				.mapFromObjectProtocolsResponseToListProtocolResponse(listProtocolsResponse);
	}

	/**
	 * Obtiene parámetros de protocolos
	 */
	@Override
	public List<ParametersGetPutResponse> findParametersOfProtocols(Integer idContrato, Integer idProtocolo,
			BigDecimal idRegistro, String tipoActividad) {

		StringBuilder query = new StringBuilder(
				"SELECT para.ID_PARA_PTCL, ptcl.ID_PTCL, ptcl.NOMBRE, para.NMBR_PARA, patt.VALOR, para.PARA_ES_EDIT, para.PARA_ES_OBLI, para.PARA_LONG,");
		query.append(
				" para.PARA_TIPO_DATO, NVL(patt.ID_SEQU_PATT, 0) AS ID_SEQU_PATT, patt.PATT_ACTI AS TIPO_ACTI, NVL(patt.ID_DATO_TRAN, 0) AS ID_DATO_TRAN, NVL(patt.BAND_ACTI, 'I') EDO_VALOR");
		query.append(
				" FROM H2H_PTCL ptcl, H2H_PARA_PTCL para, H2H_PATT_PTCL patt WHERE ptcl.ID_PTCL = :idProtocolo AND ptcl.ID_PTCL = para.ID_PTCL AND para.ID_PARA_PTCL = patt.ID_PARA_PTCL(+)");
		query.append(
				" AND patt.ID_CNTR(+) = :idContrato AND patt.ID_DATO_TRAN(+) = :idRegistro AND patt.PATT_ACTI(+) = :tipoActividad AND para.BAND_ACTIVO = 1");
		query.append(" ORDER BY NLSSORT(UPPER(para.nmbr_para), 'NLS_SORT=SPANISH')");

		Query parametersOfProtocolsResult = entityManager.createNativeQuery(query.toString());

		parametersOfProtocolsResult.setParameter("idProtocolo", idProtocolo);
		parametersOfProtocolsResult.setParameter(ID_CONTRATO, idContrato);
		parametersOfProtocolsResult.setParameter("idRegistro", idRegistro);
		parametersOfProtocolsResult.setParameter("tipoActividad", tipoActividad);

		List<Object[]> listParametersOfProtocols = parametersOfProtocolsResult.getResultList();

		return contractConnectionManagementEntityManagerUtils
				.mapFromListParametersOfProtocolsToListParametersGetPutResponse(listParametersOfProtocols);
	}

	/**
	 * Guarda los datos de parámetros de los protocolos
	 */
	@Override
	@Transactional
	public BigDecimal saveParametersOfProtocols(Integer idContrato, BigDecimal idRegistro,
			List<ParametersGetPutResponse> parameters, Integer idOriginalProtocol, Integer idProtocoloNuevo) {

		BigDecimal idRegistroSeq = idRegistro;

		try {

			final Map<String, BigDecimal> llavesInsercion = new HashMap<String, BigDecimal>();

			if (idRegistroSeq.compareTo(BigDecimal.ZERO) == 0) {

				StringBuilder query = new StringBuilder("SELECT H2H_PATT_PTCL_DATO_TRAN_SEQ.NEXTVAL FROM DUAL");

				List<BigDecimal> nextValueResult = entityManager.createNativeQuery(query.toString()).getResultList();

				if (!nextValueResult.isEmpty()) {

					idRegistroSeq = nextValueResult.get(0);
				}

			}

			contractConnectionManagementEntityManagerUtils.getInsertionKeysFromParameters(parameters, llavesInsercion);

			if (!idProtocoloNuevo.equals(idOriginalProtocol)) {
				contractConnectionManagementEntityManagerUtils.deleteParameters(idContrato);
			}

			for (ParametersGetPutResponse parametersGetPutResponse : parameters) {

				String valorParametro = parametersGetPutResponse.getValorParametro();

				if (StringUtils.isBlank(valorParametro)) {
					valorParametro = StringUtils.EMPTY;
				}

				BigDecimal idValorParametro = new BigDecimal(0);

				idValorParametro = contractConnectionManagementEntityManagerUtils.obtenerIdValorParametro(idContrato,
						parametersGetPutResponse, idValorParametro);

				if (idRegistro.compareTo(BigDecimal.ZERO) == 0 || idValorParametro.compareTo(BigDecimal.ZERO) == 0) {

					idValorParametro = llavesInsercion.get(String.format("%s_%s", parametersGetPutResponse.getId(),
							parametersGetPutResponse.getTipoProcesamiento()));

					contractConnectionManagementEntityManagerUtils.insertParameters(idContrato, valorParametro,
							idValorParametro, idRegistroSeq, parametersGetPutResponse);

				} else {

					contractConnectionManagementEntityManagerUtils.actualizarParametro(valorParametro, idValorParametro,
							parametersGetPutResponse.getNombreParametro());

				}

			}

		} catch (NumberFormatException nbe) {

			log.info("Error: " + nbe.toString());
			throw new BusinessException("ERGC011", nbe.getMessage());

		} catch (BusinessException be) {

			log.info("Error: " + be.toString());
			throw new BusinessException("ERGC011", be.getMessage());

		}

		return idRegistroSeq;
	}

	/**
	 * Mapea respuesta de BD de datos de contrato al Objeto de respuesta para el
	 * front.
	 * 
	 * @param listContractConnectionResult Datos de respuesta de BD
	 * @return Objeto a retornar con datos mapeados, para front
	 */
	private List<ContractConnectionManagementResponse> mapFromContractConnectionEntityManagerToContractConnectionManagementResponse(
			List<Object[]> listContractConnectionResult) {

		List<ContractConnectionManagementResponse> listaContractConnectionManagementResponse = new ArrayList<>();

		ContractConnectionManagementResponse contractConnectionManagementResponse = null;

		for (Object[] contractConnectionContent : listContractConnectionResult) {

			if (contractConnectionContent.length > 0) {

				contractConnectionManagementResponse = new ContractConnectionManagementResponse();

				contractConnectionManagementResponse
						.setNumeroContrato(Objects.toString(contractConnectionContent[0], ""));
				contractConnectionManagementResponse.setRazonSocial(Objects.toString(contractConnectionContent[1], ""));
				contractConnectionManagementResponse
						.setCodigoCliente(Objects.toString(contractConnectionContent[2], ""));
				contractConnectionManagementResponse.setEstatus(Objects.toString(contractConnectionContent[3], ""));
				contractConnectionManagementResponse
						.setNombreCliente(Objects.toString(contractConnectionContent[4], ""));
				contractConnectionManagementResponse.setPersonalid(Objects.toString(contractConnectionContent[5], ""));
				contractConnectionManagementResponse.setCuentaEje(Objects.toString(contractConnectionContent[6], ""));

				String protocolo = findContractConnectionProtocolByIdContract(
						Objects.toString(contractConnectionContent[7], ""));
				contractConnectionManagementResponse.setProtocolo(protocolo);

				String envioCliente = findCustomerShippingByIdContract(
						Objects.toString(contractConnectionContent[7], ""));
				contractConnectionManagementResponse.setEnvioClte(envioCliente);

				contractConnectionManagementResponse.setIdContrato(Objects.toString(contractConnectionContent[7], ""));

				listaContractConnectionManagementResponse.add(contractConnectionManagementResponse);

			}

		}

		return listaContractConnectionManagementResponse;
	}

}
