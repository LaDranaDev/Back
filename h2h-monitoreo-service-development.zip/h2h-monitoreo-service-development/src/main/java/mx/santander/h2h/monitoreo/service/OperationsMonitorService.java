package mx.santander.h2h.monitoreo.service;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;
import lombok.Getter;
import mx.santander.h2h.monitoreo.constants.ReportConstants;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.OperationsHistoryResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorCatalogsYHorasResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorTotalResponse;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsMonitorComplementEntityManagerRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsMonitorEntityManagerHelper4Repository;
import mx.santander.h2h.monitoreo.repository.IOperationsMonitorEntityManagerRepository;
import mx.santander.h2h.monitoreo.util.OperationsMonitorUtil;

/**
 * Servicio para el Monitor de Operaciones
 *
 * @author Daniel Ruiz
 * @since 13/04/2023
 */
@Service
public class OperationsMonitorService implements IOperationsMonitorService {

    @Autowired
    private IOperationsMonitorEntityManagerRepository repository;
    
    @Autowired
    private IOperationsMonitorComplementEntityManagerRepository repositoryCompl;
    
    @Autowired
    private IOperationsMonitorEntityManagerHelper4Repository repo;

    @Autowired
    private IOperationsDetailRepository detailRepository;

    @Autowired
    private OperationsMonitorUtil util;

    @Autowired
    private IJasperReportService reportService;

    @Override
    public Page<OperationsMonitorQueryResponse> consulta(OperationsMonitorQueryRequest request, Pageable pageable) {
        request.setPagina(String.valueOf(pageable.getPageNumber() + 1));
        request.setTamanioPagina(String.valueOf(pageable.getPageSize()));
        List<OperationsMonitorQueryResponse> content = repository.consultaOperaciones(request);
        long total = repository.countConsultaOperaciones(request);
        return new PageImpl<>(content, pageable, total);
    }

    @Override
    public OperationsMonitorTotalResponse total(OperationsMonitorQueryRequest request) {
        OperationsMonitorTotalResponse response = new OperationsMonitorTotalResponse();
        response.setCorreosEnv(repository.countCorreosEnv(request));
        response.setArchivos(repository.countArchivos(request));
        response.setImporteGlobal(repository.getImporteGlobal(request));
        response.setLimiteOperaciones(repository.consultaParametro("NUM_REG_EXPO_MONOP"));
        return response;
    }

    @Override
    public ReportResponse reporte(OperationsMonitorQueryRequest request, String type) {
        List<OperationsMonitorQueryResponse> response = repo.consultaOperExport(request);//Validar este metodo JLG
        List<ReportBean> dataSet = Collections.singletonList(new ReportBean(request, response));
        Map<String, Object> params = new HashMap<>();
        params.put("user", request.getUser());
        ReportResponse report = new ReportResponse();
        if (request.getDivisa().equals("0")) {
			request.setDivisa("Todos");
		}
        if (ReportConstants.PDF_FORMAT.equals(type)) {
            report = reportService.getPdf(ReportConstants.REPORT_MON_OPER, params, dataSet);
            report.setName("MonitorOperaciones " + new SimpleDateFormat("dd-MM-yyyy HH_mm").format(new Date()) + ReportConstants.PDF_EXTENTION);
        } else {
            report = reportService.getXls(ReportConstants.REPORT_MON_OPER, params, dataSet);
            report.setName("MonitorOperaciones " + new SimpleDateFormat("dd-MM-yyyy HH_mm").format(new Date()) + ReportConstants.XLSX_EXTENTION);
        }
        return report;
    }

    @Override
    public OperationsMonitorCatalogsYHorasResponse catalogs() {
    	OperationsMonitorCatalogsYHorasResponse response = new OperationsMonitorCatalogsYHorasResponse();
    	response.setOperationsMonitorCatalogsResponse(repository.catalogs());
    	response.setListaHorario29(detailRepository.listaHorarios("29"));
    	response.setListaHorario99(detailRepository.listaHorarios("99"));
    	response.setListaHorario02(detailRepository.listaHorarios("02"));
        return response;
    }

    @Override
    public OperationsMonitorQueryResponse obtenerDetalleOperacion(String idProducto, String idOperacion) {
        return util.obtenerDetalleOperacion(idProducto, idOperacion);
    }

    @Override
    public List<OperationsHistoryResponse> obtenerHistorialOperacion(String idOperacion) {
        return detailRepository.obtenerHistorialOperacion(idOperacion);
    }

    @Override
    public ReportResponse reporteHistorialOperacion(String idOperacion, String usuario) {
        Map<String, Object> params = new HashMap<>();
        params.put("USER", usuario);
        List<OperationsHistoryResponse> histOperList = detailRepository.obtenerHistorialOperacion(idOperacion);
        // Validamos que contenga campos si no enviamos un campo vacio
        if( histOperList.isEmpty() ) {
	        OperationsHistoryResponse datos = new OperationsHistoryResponse();
	        datos.setRefOper("");
	        datos.setFecha("");
	        datos.setHora("");
	        datos.setEstatus("");
	        histOperList.add(datos);
        }
        return reportService.getXls("rptHistorialOper.jasper", params, histOperList);
    }

    @Override
    public boolean cambiarEstatusOperacion(String idOperacion, String estatus, String tabla) {
        return detailRepository.cambiarEstatusOperacion(idOperacion, estatus, tabla);
    }

    @Override
    public boolean consultarHorario(String producto) {
        return detailRepository.consultarHorario(producto);
    }

    @Getter
    @AllArgsConstructor
    public static class ReportBean {
        private OperationsMonitorQueryRequest consultaOperaciones;
        private List<OperationsMonitorQueryResponse> listaOperaciones;
    }

	@Override
	public OperationsMonitorCatalogsYHorasResponse catalogsConsultaTrackingArchivo() {
		OperationsMonitorCatalogsYHorasResponse response = new OperationsMonitorCatalogsYHorasResponse();
    	response.setOperationsMonitorCatalogsResponse(repositoryCompl.catalogs());
    	response.setListaHorario29(detailRepository.listaHorarios("29"));
    	response.setListaHorario99(detailRepository.listaHorarios("99"));
    	response.setListaHorario02(detailRepository.listaHorarios("02"));
        return response;

	}

}
