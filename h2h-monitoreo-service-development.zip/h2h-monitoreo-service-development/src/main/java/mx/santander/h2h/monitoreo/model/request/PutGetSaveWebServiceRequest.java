package mx.santander.h2h.monitoreo.model.request;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Objeto que almacena los datos para guardar la información PUT y GET
 * Objeto para datos de protocolo WebService
 * 
 * @author sbautish
 *
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class PutGetSaveWebServiceRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2730528900022788442L;

	/**
	 * wsportPutGet
	 */
	private String wsportPutGet;

	/**
	 * wsipserverPutGet
	 */
	private String wsipserverPutGet;

	/**
	 * wsrutaPut
	 */
	private String wsrutaPut;

	/**
	 * wsrutaGet
	 */
	private String wsrutaGet;

	/**
	 * wspatronPutGet
	 */
	private String wspatronPutGet;

	/**
	 * wspatronGetPutGet
	 */
	private String wspatronGetPutGet;

	/**
	 * wsuriPut
	 */
	private String wsuriPut;

	/**
	 * wsuriGet
	 */
	private String wsuriGet;

	/**
	 * wsurldestPutGet
	 */
	private String wsurldestPutGet;

	/**
	 * wscertPutGet
	 */
	private String wscertPutGet;

}
