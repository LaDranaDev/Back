package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.model.request.MonitorSaldosRequest;
import mx.santander.h2h.monitoreo.model.response.MonitorSaldosResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

/**
 * Irvice.
 * Define los metodos de negocio para obtener los datos de los saldos reintentos.
 *
 * @author Jesus Soto Aguilar
 * @since 20/04/2023
 */
public interface IMonitorSaldosService {

    /**
     * Obtiene los saldos reintentos paginados.
     *
     * @param request Objeto con los filtros de consulta
     * @param pagination Objeto con los datos de paginacion
     * @return Objeto con los datos paginado
     */
    Page<MonitorSaldosResponse> getSaldosReintentosCliente(MonitorSaldosRequest request, Pageable pagination);

    /**
     * Genera el reporte de los saldos reintentos.
     *
     * @param request Objeto con los datos para generar el reporte
     * @return Objeto con los datos del reporte en base 64
     */
    List<MonitorSaldosResponse> getSaldosReintentosCliente(MonitorSaldosRequest request);
}
