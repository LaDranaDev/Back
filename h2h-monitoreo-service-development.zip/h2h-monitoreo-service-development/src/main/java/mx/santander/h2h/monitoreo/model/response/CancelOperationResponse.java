package mx.santander.h2h.monitoreo.model.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * Clase para responde llamada de la operacion
 * Implemnetar la interfaz Serializable para el paso entre capas del sistema
 * Adicional se implementan las etiquetas lombok de
 * Geter, Seter, ToString, NoArgumentsConstructor
 * para un desarrollo más rapido y con menos codigo.
 * @author NTTDATA-NRL
 * @version 1.0
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
public class CancelOperationResponse implements Serializable {

    private static final long serialVersionUID = -8084609779342746968L;
    /** Muestra busqeuda */
    private String muestraBusqueda;
    /** Solo lectura*/
    private String readOnly;
    /** Folio del contrato*/
    private String hdnContratoFolio;

}
