package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.constants.PistasAuditoriaConstants;
import mx.santander.h2h.monitoreo.enums.OperacionAuditoria;
import mx.santander.h2h.monitoreo.model.mapper.MonitorSaldosModelMapping;
import mx.santander.h2h.monitoreo.model.request.MonitorSaldosRequest;
import mx.santander.h2h.monitoreo.model.request.PistaAuditoriaRequest;
import mx.santander.h2h.monitoreo.model.response.MonitorSaldosResponse;
import mx.santander.h2h.monitoreo.repository.IMonitorSaldosManagerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import jakarta.persistence.Tuple;
import java.util.List;

/**
 * MonitorSaldosService.
 * Implementa los metodos de negocio para obtener los datos de los saldos reintentos.
 *
 * @author Jesus Soto Aguilar
 * @since 20/04/2023
 */
@Service
public class MonitorSaldosService implements IMonitorSaldosService {

    /**
     * Repositorio para ejecutar las consultas del monitor de saldos.
     */
    @Autowired
    private IMonitorSaldosManagerRepository monitorSaldosManagerRepository;

    /**
     * Servicio para registrar las pistas auditoria.
     */
    @Autowired
    private PistaAuditoriaService pistaAuditoriaService;

    /**
     * Obtiene los saldos reintentos paginados.
     *
     * @param request Objeto con los filtros de consulta
     * @param pagination Objeto con los datos de paginacion
     * @return Objeto con los datos paginado
     */
    @Override
    public Page<MonitorSaldosResponse> getSaldosReintentosCliente(MonitorSaldosRequest request, Pageable pagination) {
        Page<Tuple> saldosReintentos =
                monitorSaldosManagerRepository.getSaldosReintentosClientePaged(request, pagination);
        if(!saldosReintentos.getContent().isEmpty()){
            registraOperacionBitacora();
        }
        return new PageImpl<>(MonitorSaldosModelMapping.mappingTupleListToDtoList(saldosReintentos.getContent()),
                pagination, saldosReintentos.getTotalElements());
    }

    /**
     * Genera el reporte de los saldos reintentos.
     *
     * @param request Objeto con los datos para generar el reporte
     * @return Objeto con los datos del reporte en base 64
     */
    @Override
    public List<MonitorSaldosResponse> getSaldosReintentosCliente(MonitorSaldosRequest request) {
        List<MonitorSaldosResponse> response = MonitorSaldosModelMapping.mappingTupleListToDtoList(
                monitorSaldosManagerRepository.getSaldosReintentosCliente(request));
        if(!response.isEmpty()){
            registraOperacionBitacora();
        }
        return response;
    }

    /**
     * Registra la informacion de las consultas de los saldos reintentos
     * en la bitacora de auditoria.
     */
    private void registraOperacionBitacora(){
        PistaAuditoriaRequest pistaAuditoriaRequest = new PistaAuditoriaRequest(
                OperacionAuditoria.CONSULTAR_SALDOS_REINTENTOS.getIdCodigoOperacion().toString(),
                PistasAuditoriaConstants.SUCCESS,
                PistasAuditoriaConstants.SERV_CONS_SALDOS,
                OperacionAuditoria.CONSULTAR_SALDOS_REINTENTOS.getDescripcion(),
                PistasAuditoriaConstants.TABLA_H2H_SALDOS_REINT
        );

        pistaAuditoriaService.registrarPista(pistaAuditoriaRequest);
    }

}
