package mx.santander.h2h.monitoreo.repository;

/**
 * IOperationsMonitorEntityManagerHelper3Repository.
 */
public interface IOperationsMonitorEntityManagerHelper3Repository {
}
