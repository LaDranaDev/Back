package mx.santander.h2h.monitoreo.constants;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Propiedades externalizadas de la aplicación.
 *
 * @author Felipe Monzón
 * @since 31/01/22
 */
@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = ApiConstants.PROPERTY_PREFIX)
public class PropertiesConstant {
	/** Ruta para la intercepción de la petición. */
	private String interceptorPath;
}
