package mx.santander.h2h.monitoreo.service;

import java.math.BigDecimal;

import mx.santander.h2h.monitoreo.model.response.PutGetDto;

public interface IContractConnectionManagementPutGetFindDataService {

	BigDecimal findNextValue(String string);

	void buscarDatosdeSFTP(PutGetDto putGetDtoResponse);

	void buscarDatosdeCD(PutGetDto putGetDtoResponse);

	void buscarDatosdeWS(PutGetDto putGetDtoResponse);

}
