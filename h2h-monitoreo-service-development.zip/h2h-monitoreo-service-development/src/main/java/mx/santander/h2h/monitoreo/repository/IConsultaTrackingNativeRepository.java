package mx.santander.h2h.monitoreo.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.model.response.ArchivoGeneralResponse;
import mx.santander.h2h.monitoreo.model.response.ArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ResultTrackingResponse;

public interface IConsultaTrackingNativeRepository {

	ArchivoGeneralResponse obtenerDetalleArchivosGeneral(Pageable page, String fecha, String codCliente);
	
	ResultTrackingResponse obtenerConteoArchivo(String codCliente, String fecha);
	
	List<ArchivoResponse> obtenerListDetalleArchivosGeneral(String fecha, String codCliente);
	
}
