package mx.santander.h2h.monitoreo.enums;

/**
 * Enumeracion para el manejo de las operaciones del catalogo de pistas de
 * auditoria.
 *
 * @author Jesus Soto Aguilar
 *
 */
public enum OperacionAuditoria {

    /**
     * enum values
     */
    CONSULTAR_SALDOS_REINTENTOS(44, "Consulta de saldos y reintentos");

    /**
     * Id de la operacion, este debe ser el mismo al registrado en el catalogo
     * de operaciones
     */
    private Integer idCodigoOperacion;
    /**
     * Descripcion del nombre de la pista de auditoria
     */
    private String descripcion;

    OperacionAuditoria(int idCodigoOperacion, String descripcion) {
        this.idCodigoOperacion = idCodigoOperacion;
        this.descripcion = descripcion;
    }

    /**
     * @return the idCodigoOperacion
     */
    public Integer getIdCodigoOperacion() {
        return idCodigoOperacion;
    }

    /**
     * @return the descripcion
     */
    public String getDescripcion() {
        return descripcion;
    }
}
