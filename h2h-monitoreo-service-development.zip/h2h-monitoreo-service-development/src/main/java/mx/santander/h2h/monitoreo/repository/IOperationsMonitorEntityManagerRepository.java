package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorCatalogsResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;

import java.util.List;

/**
 * Repositorio de acceso a Base de Datos del Monitor de Operaciones
 *
 * @author Daniel Ruiz
 * @since 13/04/2023
 */
public interface IOperationsMonitorEntityManagerRepository {

    /**
     * Realiza la consulta de las operaciones
     * @param consultaOperaciones - Parámetros de consulta
     * @return Lista de operaciones realizadas
     */
    List<OperationsMonitorQueryResponse> consultaOperaciones(OperationsMonitorQueryRequest consultaOperaciones);

    /**
     * Consulta el total de registros
     * @param consultaOperaciones - Parámetros de consulta
     * @return Numero de total de registros
     */
    long countConsultaOperaciones(OperationsMonitorQueryRequest consultaOperaciones);

    /**
     * Obtiene los correos enviados.
     * @param consultaOperaciones - Parámetros de consulta
     * @return Total de correos enviados
     */
    long countCorreosEnv(OperationsMonitorQueryRequest consultaOperaciones);

    /**
     * Obtiene el número de archivos.
     * @param consultaOperaciones - Parámetros de consulta
     * @return Total de archivos
     */
    long countArchivos(OperationsMonitorQueryRequest consultaOperaciones);

    /**
     * Obtiene importe global.
     * @param consultaOperaciones - Parámetros de consulta
     * @return Importe global
     */
    double getImporteGlobal(OperationsMonitorQueryRequest consultaOperaciones);

    /**
     * Realiza la consulta de las operaciones para exportar
     * @param consultaOperaciones - Parámetros de consulta
     * @return Lista de operaciones realizadas
     */
    String consultaOperacionesExportar(OperationsMonitorQueryRequest consultaOperaciones);

    /**
     * Consulta la lista de divisas, estatus y productos
     * @return Response de catálogos
     */
    OperationsMonitorCatalogsResponse catalogs();
    
    /**
     * Consulta el valor del parametro
     * 
     * @param name Nombre del parameto
     * @return Valor del parametro
     */
    String consultaParametro(final String name);
    
    /**
     * Obtiene el query para la consulta de operaciones a exportar
     * 
     * @param request Datos de la consulta de operaciones
     * @return Cadena del query para la consulta de operaciones
     */
    String consultaOperacionesExport(final OperationsMonitorQueryRequest request);
}
