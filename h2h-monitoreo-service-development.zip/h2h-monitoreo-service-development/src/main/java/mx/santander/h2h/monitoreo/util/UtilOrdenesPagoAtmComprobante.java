package mx.santander.h2h.monitoreo.util;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.persistence.Tuple;

import org.apache.commons.lang.ObjectUtils;

import mx.santander.h2h.monitoreo.model.response.ComprobantesOperacionResponse;

/**
 * @author leopoldo.espinosa
 *
 */
public class UtilOrdenesPagoAtmComprobante extends UtilVostroComprobantes{
    /**
     * Mapa para contener los diferentes queryes dependiendo
     * los productos segun la tabla enviada
     */
    private static Map<String, String> campos= new HashMap<String, String>();
    /**
     * constante para el FROM
     * de los comprobantes del
     * Producto de operaciones de
     * Vostro
     */
    private static final String FROM_QUERY_PARAM_ORD_PAG=" FROM %s%s tranin"+
            " INNER JOIN H2H_REG%s r ON r.id_reg = tranin.id_reg"+
            " INNER JOIN H2H_CAT_PROD ct ON r.cve_prod_oper = ct.cve_prod_oper"+
            " INNER JOIN H2H_ARCHIVO%s a ON r.id_arch = a.id_archivo"+
            " INNER JOIN H2H_CNTR cntr ON cntr.id_cntr = a.id_cntr"+
            " INNER JOIN H2H_CLTE clte ON cntr.id_clte = clte.id_clte"+
            " LEFT join H2H_MX_REP_ODP_ATM%s REP ON  REP.ID_REG = tranin.id_reg "+
            " LEFT JOIN H2H_CTA_INFO CTA ON r.CNTA_CARG =cta.NUME_CTA and cta.TIPO_CTA='O'"+
            " LEFT JOIN H2H_CAT_ESTATUS ce ON ce.id_CAT_estatus = r.id_estatus " +
            " LEFT JOIN H2H_MX_REP_ODP_ATM oplc ON tranin.ID_REG = oplc.ID_REG " +
            " LEFT JOIN H2H_MX_REP_ODP_ATM_TRAN oplctran ON tranin.ID_REG = oplctran.ID_REG "+
            " LEFT JOIN H2H_MX_REP_ODP_ATM_HIST oplcHist ON tranin.ID_REG = oplcHist.ID_REG " +
            "%s"
            ;
    /**
     * CAMPOS_QUERY_TRAN_INT_CAM
     * query para obtener los datos
     * del comprobante de
     * Transferencias Internacionales
     * Cambiarias
     *
     */
    private static final String CAMPOS_QUERY_ORD_PAG_ATM="SELECT tranin.ID_REG ID_REG, cntr.NUM_CNTR CONTRATO, to_char(R.CNTA_CARG) NUM_CTA_CARGO,null NUN_CTA_ABONO,ct.DESC_PROD DESC_PROD," +
            "tranin.IMPO_GIRO IMPORTE,null REFERENCIA,null DIVISA,ce.DESC_ESTATUS DESC_ESTATUS,to_char(r.FECH_APLI,'dd/mm/yyyy HH:mi:ss')  FECH_APLI," +
            "(CTA.NOMB_TITU) BENEFICIARIO,DECODE(tranin.FORM_PAGO,'C','CHEQUE DE CAJA','E','EFECTIVO') TIPO_PAGO, CTA.NOMB_TITU TITULAR,(tranin.LEY_CRGO || ' ' || tranin.refe_num_clte) CONCEPTO_PAGO,"+
            "DECODE(oplc.FOL_ATM_LIQ,null,DECODE(oplcHist.FOL_ATM_LIQ,null,oplctran.FOL_ATM_LIQ,oplcHist.FOL_ATM_LIQ), oplc.FOL_ATM_LIQ) CLAVE_RASTREO," +
            "to_char(tranin.FECH_LIMI_LIQ,'dd/mm/yyyy')   BANCO_RECEPTOR,r.FECH_ENVI_BACK FECHA_OPERACION,null CLAV_PROV,tranin.NUM_ORDN NUM_DOCU,null FECH_VENCIMIENTO," +
            QRY_PART_ESTATUS_MOV +
            "(tranin.NOMB_BENE)  RAZON_SCIA, null NOM_CLTE,clte.PERSONALIDAD, clte.RFC,cntr.NUM_CNTR,DECODE(oplc.NUM_CAJE, null, DECODE(oplcHist.NUM_CAJE,null,oplctran.NUM_CAJE,oplcHist.NUM_CAJE), oplc.NUM_CAJE) CLAVE_BENEF,"+
            " DECODE(oplc.COD_STAT, null, DECODE(oplcHist.COD_STAT,null,oplctran.COD_STAT,oplcHist.COD_STAT), oplc.COD_STAT) ID_ESTA" +
            ",clte.BUC PERS_AUT,null FORM_APLI, tranin.REFE_CTE NOMB_RAZON_SOCI_PROV,clte.NOMBRE  || ' '  || clte.APPATERNO  || ' '  || clte.APMATERNO RFC_PROV,"+
            "null BANC_ABON,null REFE_ABON,null TIPO_DOCU";

    /**
     * inicializacion del mapa de productos
     * LFER 09-03-2018
     */
    static{
        campos.put("H2H_MX_PROD_ORDN_PAGO_ATM", CAMPOS_QUERY_ORD_PAG_ATM);
    }

    /**
     * Obtiene el query de Ordenes de pago ATM
     *
     * @param listIds  List<Integer>
     * @param tabla tabla para obtener query
     * @param sqlstr sql a modificar
     * @return String query
     */
    static String obtenerQuerys(List<Integer> listIds, String tabla, String sqlstr) {
        if(validaProductos(tabla)){
            final StringBuilder sql = new StringBuilder();
            sql.append(campos.get(tabla));
            sql.append(String.format(FROM_QUERY_PARAM_ORD_PAG,tabla,"","","","",""));
            agregaIdRegAwhere(listIds, sql);
            sql.append(UNION_ALL);
            sql.append(campos.get(tabla));
            sql.append(String.format(FROM_QUERY_PARAM_ORD_PAG,tabla,TRAN_GUION,TRAN_GUION,TRAN_GUION,TRAN_GUION,""));
            agregaIdRegAwhere(listIds, sql);
            return sql.toString();
        }else{
            return sqlstr;
        }
    }
    /**
     * es Orden de Pago ATM
     * @param codCveProd
     * @return
     */
    public static boolean esOpAtm(String codCveProd) {
        return "-85-".equals(codCveProd);
    }

    /**
     * validaProductos del tipo
     * vostro o
     * internacionales
     * cambiarias
     * @param tabla
     * @return
     */
    private static boolean validaProductos(String tabla) {
        return "H2H_MX_PROD_ORDN_PAGO_ATM".equals(tabla);

    }
    
	/**
	 * Metodo para realizar el
	 * llenado de datos 
	 * para los comprobantes de
	 * los nuevos 
	 * productos de Ordenes de Pago.
	 * @param beanopatm
	 * @param map
	 */
	public static void llenaBeanOpAtm(ComprobantesOperacionResponse beanopatm,
			Tuple map) {
		//Formateo de importe
		if(esOpAtm(ObjectUtils.toString(map.get("ESTATUS_MOV")))){
		beanopatm.setContrato(ObjectUtils.toString(map.get("CONTRATO")));
		beanopatm.setNoDocu(ObjectUtils.toString(map.get("PERS_AUT")));
		beanopatm.setRfc(ObjectUtils.toString(map.get("RFC_PROV")));
		beanopatm.setFechaAplic(ObjectUtils.toString(map.get("FECH_APLI")));
		beanopatm.setRefInterbancaria(ObjectUtils.toString(map.get("REFERENCIA")));
		beanopatm.setEstatusMov(ObjectUtils.toString(map.get("REFE_ABON")));
		beanopatm.setConceptoPago(ObjectUtils.toString(map.get("CONCEPTO_PAGO")));
		beanopatm.setCuentaCargo(ObjectUtils.toString(map.get("NUM_CTA_CARGO")));
		beanopatm.setTitular(ObjectUtils.toString(map.get("TITULAR")));
		beanopatm.setCuentaAbono(ObjectUtils.toString(map.get("NUN_CTA_ABONO")));
		// Enmascaramos la cuenta Abono
		beanopatm.setCuentaAbono(UtilMapeoData.getMascara(beanopatm.getCuentaAbono(), "abono"));
		
		beanopatm.setCveProveedor(ObjectUtils.toString(map.get("NOM_CLTE")));
		beanopatm.setRazonSocial(ObjectUtils.toString(map.get("RAZON_SCIA")));
		beanopatm.setBanco(ObjectUtils.toString(map.get("BANCO_RECEPTOR")));
		beanopatm.setFormaAplic(ObjectUtils.toString(map.get("FORM_APLI")));
		beanopatm.setCveBenef(ObjectUtils.toString(map.get("CLAVE_BENEF")));
		beanopatm.setDivisa(ObjectUtils.toString(map.get("DIVISA")));
		beanopatm.setTipoDoc(ObjectUtils.toString(map.get("TIPO_DOCU")));
		final String impFormat = "$"+ new DecimalFormat().format(map.get("IMPORTE"));
		beanopatm.setImporte(impFormat);
		beanopatm.setNumOrden(ObjectUtils.toString(map.get("NUM_DOCU")));
		beanopatm.setBeneficiario(ObjectUtils.toString(map.get("BENEFICIARIO")));
		beanopatm.setTipoPago(ObjectUtils.toString(map.get("TIPO_PAGO")));
		beanopatm.setClaveRastreo(ObjectUtils.toString(map.get("CLAVE_RASTREO")));
		beanopatm.setTipoOper(ObjectUtils.toString(map.get("DESC_PROD")));
		beanopatm.setEstatus(ObjectUtils.toString(map.get("DESC_ESTATUS")));
		beanopatm.setNumSucursal(ObjectUtils.toString(map.get("NOMB_RAZON_SOCI_PROV")));
		beanopatm.setEsOrdenPago(true);
		}
		
	}
}
