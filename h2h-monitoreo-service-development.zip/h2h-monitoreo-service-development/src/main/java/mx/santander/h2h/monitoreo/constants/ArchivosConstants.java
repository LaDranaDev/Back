package mx.santander.h2h.monitoreo.constants;

public class ArchivosConstants {

    /**
     * Query que obtiene el total de archivos de acuerdo a la fecha y cliente.
     */
    public static final String QUERY_CONTEO_ARCHIVOS = " " +
            "SELECT SUM(NUM_ARCH) NUM_ARCH, " +
            " SUM (OPER_REC) AS OPER_REC, " +
            " SUM (MONT_REC) AS MONT_REC, " +
            " SUM(DUPLICADO) DUPLICADO, " +
            " SUM(RECIBIDO) RECIBIDO, " +
            " SUM(RECHAZADO) RECHAZADO, " +
            " SUM(VALIDADO) VALIDADO, " +
            " SUM(ENVIADO) ENVIADO, " +
            " SUM(PROCESO) PROCESO, " +
            " SUM(ESPERA) ESPERA, " +
            " SUM (PROCESADO) PROCESADO " +
            " FROM " +
            " ( SELECT COUNT (*) AS NUM_ARCH, " +
            "SUM (OPER_REC) AS OPER_REC, " +
            "SUM (MONT_REC) AS MONT_REC, " +
            "SUM(DECODE (DESRIPCION, 'DUPLICADO', 1, 0)) AS DUPLICADO, " +
            "SUM(DECODE (DESRIPCION, 'RECIBIDO', 1, 0))  AS RECIBIDO, " +
            "SUM(DECODE (DESRIPCION, 'RECHAZADO', 1, 0) ) AS RECHAZADO, " +
            "SUM(DECODE (DESRIPCION, 'VALIDADO', 1, 0)) AS VALIDADO, " +
            "SUM(DECODE (DESRIPCION, 'ENVIADO', 1, 0)) AS ENVIADO, " +
            "SUM(DECODE (DESRIPCION, 'PROCESO', 1, 0)) AS PROCESO, " +
            "SUM(DECODE (DESRIPCION, 'ESPERA',1,0)) AS ESPERA, " +
            "SUM(DECODE (DESRIPCION, 'PROCESADO', 1, 0)) AS PROCESADO " +
            "FROM ( " +
            "SELECT " +
            "H2H_CLTE.BUC, " +
            "H2H_ARCHIVO_TRAN.ID_ARCHIVO, " +
            "P.DESRIPCION, " +
            "SUM (NVL (H2H_ARCH_PROD_TRAN.TOTA_OPER, 0)) AS OPER_REC, " +
            "SUM (NVL (H2H_ARCH_PROD_TRAN.TOTA_MONT, 0)) AS MONT_REC " +
            "FROM " +
            " H2H_ARCHIVO_TRAN " +
            "LEFT JOIN H2H_ARCH_PROD_TRAN ON H2H_ARCH_PROD_TRAN.ID_ARCHIVO = H2H_ARCHIVO_TRAN.ID_ARCHIVO " +
            "INNER JOIN H2H_PARAM P " +
            "ON P.VALOR = H2H_ARCHIVO_TRAN.ID_ESTATUS " +
            "AND P.NMBR_PARAM LIKE 'TRCKNG_ESTATUS_%' " +
            "INNER JOIN H2H_CNTR ON H2H_CNTR.ID_CNTR = H2H_ARCHIVO_TRAN.ID_CNTR " +
            "INNER JOIN H2H_CLTE ON H2H_CLTE.ID_CLTE = H2H_CNTR.ID_CLTE " +
            "WHERE " +
            " H2H_CLTE.BUC= :codCliente " +
            "GROUP BY H2H_CLTE.BUC,H2H_ARCHIVO_TRAN.ID_ARCHIVO, P.DESRIPCION " +
            ") GROUP BY BUC " +
            "UNION ALL " +
            " SELECT COUNT(DISTINCT NOMB_ARCH) NUM_ARCH, " +
            " 0 OPER_REC, " +
            " 0 MONT_REC, " +
            " 0 DUPLICADO, " +
            " 0 RECIBIDO, " +
            " COUNT(DISTINCT NOMB_ARCH) RECHAZADO, " +
            " 0 VALIDADO, " +
            " 0 ENVIADO, " +
            " 0 PROCESO, " +
            " 0 ESPERA, " +
            " 0 PROCESADO  " +
            "FROM H2H_ARCH_RECH ar " +
            " INNER JOIN H2H_CNTR " +
            " ON ar.ID_CNTR = H2H_CNTR.ID_CNTR" +
            " INNER JOIN H2H_CLTE " +
            " ON H2H_CLTE.ID_CLTE      = H2H_CNTR.ID_CLTE " +
            " WHERE TRUNC(ar.FECH_REG) = to_date ( :fecha ,'dd/mm/yyyy') " +
            " AND H2H_CLTE.BUC         = :codCliente " +
            " AND ar.MOTI_RECH        != 'Archivo Duplicado'" +
            "  GROUP BY H2H_CLTE.BUC " +
            " ) ";

    /**
     * Recupera los datos de un archivo
     */
    public static final String QUERY_DETALLE_ARCHIVO = "SELECT A.ID_ARCHIVO,A.NOMBRE_ARCH,A.FECHA_REGISTRO," +
            "A.ID_ESTATUS,B.DESC_ESTATUS,C.ID_PROD,C.DESC_PROD," +
            "SUM (NVL(D.TOTA_OPER,0)) AS TOTAL_OPER, SUM (NVL(D.TOTA_MONT,0)) AS TOTAL_MONT " +
            "FROM H2H_ARCHIVO_TRAN A " +
            "LEFT  JOIN H2H_ARCH_PROD_TRAN D ON D.ID_ARCHIVO = A.ID_ARCHIVO " +
            "INNER JOIN H2H_CAT_ESTATUS B ON B.ID_CAT_ESTATUS  =  A.ID_ESTATUS " +
            "LEFT JOIN H2H_CAT_PROD C ON C.CVE_PROD_OPER = D.CVE_PROD_OPER " +
            "WHERE A.ID_ARCHIVO = :idArchivo " +
            "GROUP BY A.ID_ARCHIVO,A.NOMBRE_ARCH, A.FECHA_REGISTRO, A.ID_ESTATUS, B.DESC_ESTATUS, C.ID_PROD, C.DESC_PROD ";

    /**
     * Query para la consulta de archivos por buc
     */
    public static final String QUERY_CONSULTA_ARCHIVOS = "SELECT reg.ID_REG REGISTRO ,Clte.BUC BUC,reg.ID_REG MOVIMIENTO," +
            "reg.CNTA_CARG CTA_CARG,reg.CNTA_ABON CTA_ABO,prod.DESC_PROD PRODUCTO, \n" +
            "arch.NOMBRE_ARCH,can.NOMB_CANL CANAL,'' REFERENCIA,arch.ID_ESTATUS,  est.DESC_ESTATUS ESTATUS ," +
            "reg.MONT IMPORTE,'' BANDERA " +
            "from H2H_ARCHIVO_TRAN arch  " +
            "inner join H2H_REG_TRAN reg on reg.ID_ARCH=arch.ID_ARCHIVO " +
            "inner join H2H_CAT_PROD prod on reg.CVE_PROD_OPER=prod.cve_prod_oper " +
            "inner join H2H_CNTR Cntr on Cntr.ID_CNTR=arch.ID_CNTR " +
            "inner join H2H_CLTE Clte on cntr.ID_CLTE=Clte.ID_CLTE " +
            "inner join H2H_CAT_ESTATUS est on reg.ID_ESTATUS = est.ID_CAT_ESTATUS " +
            "inner join H2H_CAT_CANL can on arch.ID_CANL=can.ID_CANL " +
            "WHERE reg.ID_ESTATUS in(10,11) AND Clte.BUC =:clienteBuc ";

    /**
     * QUery para la consylta de todos los archivos
     */
    public static final String QUERY_CONSULTA_ALL_ARCHIVOS ="SELECT reg.ID_REG REGISTRO " +
            "from H2H_ARCHIVO_TRAN arch inner join H2H_REG_TRAN reg on reg.ID_ARCH=arch.ID_ARCHIVO " +
            "inner join H2H_CAT_PROD prod on reg.CVE_PROD_OPER=prod.cve_prod_oper " +
            "inner join H2H_CNTR Cntr on Cntr.ID_CNTR=arch.ID_CNTR " +
            "inner join H2H_CLTE Clte on cntr.ID_CLTE=Clte.ID_CLTE " +
            "inner join H2H_CAT_ESTATUS est on reg.ID_ESTATUS = est.ID_CAT_ESTATUS " +
            "inner join H2H_CAT_CANL can on arch.ID_CANL=can.ID_CANL " +
            "WHERE reg.ID_ESTATUS in(10,11) and Clte.BUC = :clienteBuc ";
}
