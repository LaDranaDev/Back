package mx.santander.h2h.monitoreo.util;

import java.util.HashMap;
import java.util.Map;

import org.owasp.encoder.Encode;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;


/** Declaracion de Constante log. */
@Slf4j
public class UtilVostroDatosExportar {
    
    /** Constante para la seleccion del Monotor de operaciones CANL_NOMB_CANL. */
    private static final String CANL_NOMB_CANL=" CANL.NOMB_CANL ";
    
    /** Constante para la exportacion  del Monotor de operaciones CANL_NOMB_CANL. */
    private static final String PART_QUERY_EXP_MSG_MSG_H2H="NULL TIPO_PAGO, NULL MODALIDAD,null IMPORTE_CARGO, MSG.MSG_H2H MSG_H2H, NULL MSG_ORDEN_PAGO, ";

    /** Constante para la exportacion  del Monotor de operaciones PART_QUERY_EXP_NULL´s. */
    private static final String PART_QUERY_EXP_NULL="NULL BUC_EMPLEADO,NULL SUCURSAL_TUTORA,NULL RFC,NULL TIPO,NULL NOMBRE_EMPLEADO,  ";

    /** Constante para la exportacion  del Monotor de operaciones PART_QUERY_EXP_FECH_APLI_FECHA_OPERACION. */
    private static final String PART_QUERY_EXP_FECH_APLI_FECHA_OPERACION="NULL NUMERO_CUENTA,TMP.FECH_OPER FECHA_PRESENTACION_INICIAL, TMP.FECH_APLI FECHA_OPERACION  ";
    
    /** Mapa para contener los diferentes queryes dependiendo los productos segun la tabla enviada. */
    private static Map<String, String> campos= new HashMap<String, String>();

    /** Tabla para los campos del Query principal. */
    private static Map<String,String> tablasSelCampos= new HashMap<String,String>();

    /** Tabla para los campos del Query de la exportacion de datos del monitor de operaciones. */
    private static Map<String,String> tablasSelCamposExpMonitor= new HashMap<String,String>();
    
    /** constante para el query de consulta del monitor de operaciones por producto SELECT_IDREG_BUC_NUMCTA_CARG. */
    private static final String SELECT_IDREG_BUC_NUMCTA_CARG="REG.ID_REG, CLTE.BUC, REG.CNTA_CARG NUM_CTA_CARGO, ";
    
    /** Parte del Query para el acceso a datos del detalle a exportar del producto de Transferencias Internacionales Cambiarias. */
    private static final StringBuilder QUERY_MONITOR_CAMPOS_TRAN_INT=new StringBuilder(SELECT_IDREG_BUC_NUMCTA_CARG)
            .append("DETA.NUM_CTA_BENE NUN_CTA_ABONO, PROD.CVE_PROD_OPER, PROD.DESC_PROD, ")
            .append("ARCH.NOMBRE_ARCH, DETA.TXT_REF REFERENCIA, REG.ID_ESTATUS, ")
            .append("EST.DESC_ESTATUS, DETA.IMP_ABONO_BENE IMPORTE, CNTR.NUM_CNTR, DETA.COD_DIV_CTA_ORD DIVISA, ")
            .append("DETA.FCH_REG FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, REG.NUM_EMAIL, ")
            .append(CANL_NOMB_CANL);

    /** Parte del Query para el acceso a datos del detalle a exportar del producto de Transferencias Vostro Interbancarias TVIB. */
    private static final StringBuilder QUERY_MONITOR_CAMPOS_VOSTRO_INT=new StringBuilder(SELECT_IDREG_BUC_NUMCTA_CARG)
            .append("DETA.NUM_CTA_BENE NUN_CTA_ABONO, PROD.CVE_PROD_OPER, PROD.DESC_PROD, ")
            .append("ARCH.NOMBRE_ARCH, DETA.TXT_REFE_OUT REFERENCIA, REG.ID_ESTATUS, ")
            .append("EST.DESC_ESTATUS, DETA.IMP_ABONO_BENE IMPORTE, CNTR.NUM_CNTR, DETA.COD_DIV_CTA_ORD DIVISA, ")
            .append("DETA.FCH_REG FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, REG.NUM_EMAIL, ")
            .append(CANL_NOMB_CANL)

            ;
    
    /** Parte del Query para el acceso a datos del detalle a exportar del producto de Transferencias Vostro Mismo Banco TVMB. */
    private static final StringBuilder QUERY_MONITOR_CAMPOS_VOSTRO_MB=new StringBuilder(SELECT_IDREG_BUC_NUMCTA_CARG)
            .append("DETA.NUM_CTA_BENE_FIN NUN_CTA_ABONO, PROD.CVE_PROD_OPER, PROD.DESC_PROD, ")
            .append("ARCH.NOMBRE_ARCH, DETA.REFE_SAF REFERENCIA, REG.ID_ESTATUS, ")
            .append("EST.DESC_ESTATUS, DETA.IMP_MONTO_OPER IMPORTE, CNTR.NUM_CNTR, DETA.COD_DIVI_CARG DIVISA, ")
            .append("DETA.FECH_REG FECHA_REGISTRO, REG.FECH_APLI FECHA_APLICACION, PROD.VIST_PROD, REG.NUM_EMAIL, ")
            .append(CANL_NOMB_CANL);


    /** Parte del Query para el acceso a datos del detalle a exportar del producto de Transferencias Internacionales Cambiarias TVMB. */
    private static final StringBuilder QUERY_EXP_MONITOR_TRAN_INT=new StringBuilder("")
            .append("NOMB_CANL, ID_REG, CLTE.BUC, DETA.NUM_CTA_ORD NUM_CTA_CARGO,DETA.NUM_CTA_BENE NUN_CTA_ABONO, ")
            .append("PROD.CVE_PROD_OPER, PROD.DESC_PROD,TMP.NOMBRE_ARCH,DETA.TXT_REF REFERENCIA,TMP.ID_ESTATUS,  EST.DESC_ESTATUS,  ")
            .append("DETA.IMP_ABONO_BENE IMPORTE, CNTR.NUM_CNTR, TMP.DIVI DIVISA,DETA.FCH_REG FECHA_REGISTRO, TMP.FECH_APLI FECHA_APLICACION, ")
            .append("PROD.VIST_PROD,null INTERMEDIARIO_ORD,DETA.COD_DIV_CTA_ORD DIVISA_ORD,DETA.TXT_NOM_BCO_PAG INTERMEDIARIO_REC,DETA.TXT_NOM_BENE BENEFICIARIO, ")
            .append("trim(DETA.TXT_REF_LEYE_ORD)||' '||trim(DETA.TXT_REF_NUME)||' '||trim(DETA.TXT_REF_CTE) COMENTARIO_1,to_char(ID_REG) COMENTARIO_2,NULL COMENTARIO_3, DETA.TXT_NOM_ORD TITULAR, NULL BANCO_RECEPTOR,  ")
            .append(PART_QUERY_EXP_MSG_MSG_H2H)
            .append("null NUM_ORDEN,NULL FECHA_LIMITE_PAGO,NULL NUM_SUCURSAL,NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA,  ")
            .append(PART_QUERY_EXP_NULL)
            .append(PART_QUERY_EXP_FECH_APLI_FECHA_OPERACION);

    /** Parte del Query para el acceso a datos del detalle a exportar del producto de Transferencias Vostro Interbancarias TVIB. */
    private static final StringBuilder QUERY_EXP_MONITOR_VOSTRO_INT=new StringBuilder("")
            .append("NOMB_CANL, ID_REG, CLTE.BUC, DETA.NUM_CTA_ORD NUM_CTA_CARGO,DETA.NUM_CTA_BENE NUN_CTA_ABONO,  ")
            .append("PROD.CVE_PROD_OPER, PROD.DESC_PROD,TMP.NOMBRE_ARCH,to_char(DETA.TXT_REFE_OUT) REFERENCIA,TMP.ID_ESTATUS,  EST.DESC_ESTATUS,  ")
            .append("DETA.IMP_ABONO_BENE IMPORTE, CNTR.NUM_CNTR, TMP.DIVI DIVISA,DETA.FCH_REG FECHA_REGISTRO, TMP.FECH_APLI FECHA_APLICACION, ")
            .append("PROD.VIST_PROD,BNCO.NOMBRE_BANCO INTERMEDIARIO_ORD,DETA.COD_DIV_CTA_ORD DIVISA_ORD,DETA.TXT_NOM_BCO_PAG INTERMEDIARIO_REC,DETA.TXT_NOM_BENE  BENEFICIARIO, ")
            .append("trim(DETA.TXT_REF_LEYE_ORD)||' '||trim(DETA.TXT_REF_NUME)||' '||trim(DETA.TXT_REF_CTE) COMENTARIO_1,to_char(ID_REG) COMENTARIO_2,NULL COMENTARIO_3, DETA.TXT_NOM_ORD TITULAR, NULL BANCO_RECEPTOR,  ")
            .append(PART_QUERY_EXP_MSG_MSG_H2H)
            .append("DETA.NUM_CTA_VOS NUM_ORDEN,NULL FECHA_LIMITE_PAGO,NULL NUM_SUCURSAL,NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA,  ")
            .append(PART_QUERY_EXP_NULL)
            .append(PART_QUERY_EXP_FECH_APLI_FECHA_OPERACION);

    /** Parte del Query para el acceso a datos del detalle a exportar del producto de Transferencias Vostro Mismo Banco TVMB. */
    private static final StringBuilder QUERY_EXP_MONITOR_VOSTRO_MB=new StringBuilder("")
            .append("NOMB_CANL, ID_REG, CLTE.BUC, DETA.NUM_CTA_ORD NUM_CTA_CARGO,DETA.NUM_CTA_BENE_FIN NUN_CTA_ABONO,  ")
            .append("PROD.CVE_PROD_OPER, PROD.DESC_PROD,TMP.NOMBRE_ARCH,DETA.REFE_SAF REFERENCIA,TMP.ID_ESTATUS,  EST.DESC_ESTATUS,  ")
            .append("DETA.IMP_MONTO_OPER IMPORTE, CNTR.NUM_CNTR, TMP.DIVI DIVISA,DETA.FECH_REG FECHA_REGISTRO, TMP.FECH_APLI FECHA_APLICACION, ")
            .append("PROD.VIST_PROD,'BANCO SANTANDER (MÉXICO) S.A.' INTERMEDIARIO_ORD,DETA.COD_DIVI_CARG DIVISA_ORD,DETA.CUENTA_ID_BANCO INTERMEDIARIO_REC,DETA.TXT_NOM_BEN_FIN BENEFICIARIO, ")
            .append("trim(DETA.REFE_LEYE_ORDE)||' '||trim(DETA.REFE_NUM)||' '||trim(DETA.REFE_CLTE) COMENTARIO_1,to_char(ID_REG) COMENTARIO_2,NULL COMENTARIO_3, DETA.TXT_NOMB_ORDE TITULAR, NULL BANCO_RECEPTOR,  ")
            .append(PART_QUERY_EXP_MSG_MSG_H2H)
            .append("DETA.NUM_CTA_VOS NUM_ORDEN,NULL FECHA_LIMITE_PAGO,NULL NUM_SUCURSAL,NULL NUMERO_EMPLEADO, NULL NUMERO_TARJETA,  ")
            .append(PART_QUERY_EXP_NULL)
            .append(PART_QUERY_EXP_FECH_APLI_FECHA_OPERACION);
    /**
     * inicializacion del mapa de productos
     * LFER 09-03-2018
     */
    static{
        campos.put("32", "H2H_MX_PROD_TRAN_INTN");
        campos.put("38", "H2H_MX_PROD_TVIB");
        campos.put("39", "H2H_MX_PROD_TVMB");

        tablasSelCampos.put("32", QUERY_MONITOR_CAMPOS_TRAN_INT.toString());
        tablasSelCampos.put("38", QUERY_MONITOR_CAMPOS_VOSTRO_INT.toString());
        tablasSelCampos.put("39", QUERY_MONITOR_CAMPOS_VOSTRO_MB.toString());

        tablasSelCamposExpMonitor.put("32", QUERY_EXP_MONITOR_TRAN_INT.toString());
        tablasSelCamposExpMonitor.put("38", QUERY_EXP_MONITOR_VOSTRO_INT.toString());
        tablasSelCamposExpMonitor.put("39", QUERY_EXP_MONITOR_VOSTRO_MB.toString());
    }
    
    /**
     * Es vostro.
     *
     * @param tipoOper para tipo oper
     * @return true, si tiene éxito
     */
    public static boolean esVostro(String tipoOper) {
        if(tipoOper==null ||tipoOper.isEmpty()){
            return false;
        }
        return tipoOper.toUpperCase().contains("32")
                || tipoOper.toUpperCase().contains("38")
                || tipoOper.toUpperCase().contains("39");
    }
    
    
    /**
     * Metodo Getter para querySelectExportar.
     *
     * @param cveOperProd para cve oper prod
     * @return querySelectExportar query select exportar
     */
    public static String getQuerySelectExportar(final String cveOperProd, StringBuilder queryS) {
    	StringBuilder query = new StringBuilder();
        if(esVostro(cveOperProd)){
            queryS.setLength(0);
            query.append("SELECT PROD.* FROM (SELECT ");
            query.append(tablasSelCamposExpMonitor.get(cveOperProd));
        }
        return query.toString();
    }
    
    
    /**
     * Si hay mas inner igual
     * agregar un mapa con sud Inners
     * requeridos.
     *
     * @param cveOperProd para cve oper prod
     * @return el string
     */
    public static String addInnerVostro(String cveOperProd) {
        if("38".equalsIgnoreCase(cveOperProd)){
            return "LEFT JOIN H2H_CAT_BNCO BNCO on DETA.COD_INT_REC=BNCO.BIC ";
        }
        return "";
    }

    
    /**
     * completaQueryByCveProdOper.
     *
     * @return el string
     */
    protected static void completaQueryByCveProdOper(StringBuilder query, Map<String, Object> params) {
        query
            .append("LEFT JOIN H2H_CTA_INFO CNTA_ABON ON TMP.CNTA_ABON = CNTA_ABON.NUME_CTA AND CNTA_ABON.TIPO_CTA = :cntaAbon ")
            .append("LEFT JOIN H2H_CTA_INFO CNTA_CARG ON TMP.CNTA_CARG = CNTA_CARG.NUME_CTA AND CNTA_CARG.TIPO_CTA = :cntaCarg ")
            .append("LEFT JOIN H2H_CAT_DIVISA DIVI_ABON ON DIVI_ABON.ID_CAT_DIVISA = CNTA_ABON.ID_CAT_DIVISA ")
            .append("LEFT JOIN H2H_CAT_DIVISA DIVI_CARG ON DIVI_CARG.ID_CAT_DIVISA = CNTA_CARG.ID_CAT_DIVISA ");
        // Agregamos los parametros
        params.put("cntaAbon", "B");
        params.put("cntaCarg", "O");
    }
    
    /**
     * agrega select para los 
     * productos de Vostro e
     * internacionales cambiarias.
     *
     * @param tresMeses para tres meses
     * @param consultaOperaciones para consulta operaciones
     * @return el string
     */
	public static String generaQueryProductosVostro(boolean tresMeses,
			OperationsMonitorQueryRequest consultaOperaciones) {
		StringBuilder query= new StringBuilder();
		log.info("*****generaQueryProductosVostro*****>"+Encode.forJava(consultaOperaciones.getIdProducto()));
		 query
		 .append("SELECT '")
		 	.append(getTablaPorCveProd(tresMeses,consultaOperaciones.getIdProducto()))
		 	.append("' TABLA,")
			.append(tablasSelCampos.get(consultaOperaciones.getIdProducto()))
			.append("FROM ")
			.append(getTran("H2H_REG",tresMeses)).append(" REG ")
			.append("INNER JOIN ").append(getTran("H2H_ARCHIVO",tresMeses)).append(" ARCH ON ARCH.ID_ARCHIVO = REG.ID_ARCH ")
			.append("INNER JOIN H2H_CNTR CNTR USING (ID_CNTR) ")
			.append("INNER JOIN H2H_CLTE CLTE USING (ID_CLTE) ")
			.append("INNER JOIN H2H_CAT_PROD PROD  ON PROD.CVE_PROD_OPER = REG.CVE_PROD_OPER ")
			.append("INNER JOIN H2H_CAT_ESTATUS EST ON REG.ID_ESTATUS = EST.ID_CAT_ESTATUS ")
			.append("INNER JOIN H2H_CAT_CANL CANL ON ARCH.ID_CANL = CANL.ID_CANL ")
		    .append("INNER JOIN ").append(getTablaPorCveProd(tresMeses,consultaOperaciones.getIdProducto()))
		    .append(" DETA ON REG.ID_REG=DETA.ID_REG ");
		 return query.toString();
	}
	
	
	/**
	 * Metodo para obtener la 
	 * tabla segun la clave prod oper
	 * que se ingresa .
	 *
	 * @param tresMeses para tres meses
	 * @param idProducto para id producto
	 * @return tablaPorCveProd tabla por cve prod
	 */
	protected static String getTablaPorCveProd(boolean tresMeses,
			String idProducto) {
		return getTran(campos.get(idProducto), tresMeses);
	}
	
	
	/**
	 * concatena el tran 
	 * para las tablas de
	 * tres meses.
	 *
	 * @param tabla para tabla
	 * @param tresMeses para tres meses
	 * @return tran tran
	 */
	private static String getTran(String tabla, boolean tresMeses) {
		String tablain=tabla;
		if(tresMeses){
			tablain+="_TRAN";
		}
		return tablain;
	}

}
