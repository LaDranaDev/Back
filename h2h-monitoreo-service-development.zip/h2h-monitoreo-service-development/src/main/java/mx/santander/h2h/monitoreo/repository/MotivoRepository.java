package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.constants.MovitoQueryConstans;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

/**
 * MotivoRepository.
 *
 * @author Jesus Soto Aguilar
 */
@Repository
public class MotivoRepository implements IMotivoRepository{

    @Autowired
    private EntityManager entityManager;

    @Override
    public String consultaMotivoOperacion(String idOperacion) {
        StringBuilder motivo = new StringBuilder("");

        Query query = entityManager.createNativeQuery(MovitoQueryConstans.SQL_MOTIVO, Tuple.class);
        query.setParameter("idOperacion", idOperacion);

        for (Object row : query.getResultList()) {
            if (row instanceof Tuple) {
                motivo.append(" ");
                motivo.append(((Tuple) row).get("MOTIVO_RECH_DUPLI"));
            }
        }

        query = entityManager.createNativeQuery(MovitoQueryConstans.SQL_MOTIVO_TRAN, Tuple.class);
        query.setParameter("idOperacion", idOperacion);
        for (Object row : query.getResultList()) {
            if (row instanceof Tuple) {
                motivo.append(" ");
                motivo.append(((Tuple) row).get("MOTIVO_RECH_DUPLI"));
            }
        }

        return motivo.toString();
    }
}
