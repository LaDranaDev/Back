package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * DTO para la respuesta de obtener catalog status
 * 
 * @author Felipe Cazarez
 * @since 12/07/2022
 */
@Getter
@Setter
@NoArgsConstructor
public class CatalogStatusResponse implements Serializable{
	/**
	 * id serial 
	 */
	private static final long serialVersionUID = 341023655979918839L;
	/**
	 * Identificador del catalogo.
	 */
	private Integer idCat;
	/**
	 * descripcion de catalogo
	 */
	private String descripcionCatalogo;
	/**
	 * estatus activo
	 */
	private String estatusActivo;
	/**
	 * Tipo de status.
	 */
	private String type;
}
