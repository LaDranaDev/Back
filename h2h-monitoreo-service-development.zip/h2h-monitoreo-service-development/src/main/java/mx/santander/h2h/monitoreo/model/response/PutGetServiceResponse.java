package mx.santander.h2h.monitoreo.model.response;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Dto para los datos de salida del servicio PUT/GET
 * 
 * @author Z483900
 *
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class PutGetServiceResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8865011823668218466L;

	/**Lista de registros de Put y Get*/
	private List<PutGetDto> registrosPG;

	/**lista de protocolos a mostrar solo seran 2*/
	private List<ProtocolResponse> protocolos;

	/**lista de SO*/
	private List<CatalogStatusResponse> lstOs;

	/**id del protocolo*/
	private String idProtocolo;

	/**id de protocolo contrato*/
	private String idPara;

	/**Identificador del sistema operativo del equipo del cliente*/
	private String hostOs;

	/***
	 * id del contrato
	 */
	private String idContrato;

	/**nombre del protocolo activo*/
	private String nombreProtocolo;

	/**Usuario a crear en el LDAP*/
	private String ldapUser;

	/**Password dinamico del usuario del ldap*/
	private String ldapPwd;

	/**nombre del almacen de llaves*/
	private String keystore;

}
