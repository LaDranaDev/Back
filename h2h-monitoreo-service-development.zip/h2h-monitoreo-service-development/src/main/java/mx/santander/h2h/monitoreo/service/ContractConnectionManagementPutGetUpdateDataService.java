package mx.santander.h2h.monitoreo.service;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;
import mx.santander.h2h.monitoreo.constants.ApiConstants;
import mx.santander.h2h.monitoreo.model.request.PutGetRequest;
import mx.santander.h2h.monitoreo.model.response.PutGetServiceResponse;

/**
 * Clase para realizar operaciones de actualizar información en BD
 * Para gestión de contratos
 * 
 * @author sbautish
 *
 */
@Slf4j
@Service
public class ContractConnectionManagementPutGetUpdateDataService implements IContractConnectionManagementPutGetUpdateDataService {
	@Autowired
	@PersistenceContext
	private EntityManager entityManager;

	/**
	 * @param putGetServiceResponse
	 * @param putGetRequest
	 * @param tipo
	 */
	@Override
	@Transactional
	public void actualizarPtclPath(PutGetServiceResponse putGetServiceResponse, PutGetRequest putGetRequest, String tipo) {

		log.info("Inicia Actualización H2H_MX_PTCL_PATH...");

		String directorio = ApiConstants.WHITE_SPACE;
		String idPath = ApiConstants.WHITE_SPACE;

		StringBuilder queryProtocolo = new StringBuilder("UPDATE H2H_MX_PTCL_PATH SET ");

		String patron = ApiConstants.WHITE_SPACE;

		if ("P".equals(tipo)) {

			directorio = StringUtils.isNotBlank(putGetServiceResponse.getRegistrosPG().get(0).getDirectorio()) ? putGetServiceResponse.getRegistrosPG().get(0).getDirectorio() : ApiConstants.WHITE_SPACE;

			patron = StringUtils.isNotBlank(putGetServiceResponse.getRegistrosPG().get(0).getPatron()) ? putGetServiceResponse.getRegistrosPG().get(0).getPatron() : ApiConstants.WHITE_SPACE;

			idPath = StringUtils.isNotBlank(putGetRequest.getIdProtocoloPath1()) ? putGetRequest.getIdProtocoloPath1() : ApiConstants.WHITE_SPACE;

			queryProtocolo.append("DEST_PATH = :directorio, REG_EXP = :patron WHERE ID_PTCL_PATH = :idPath");

		} else {

			directorio = StringUtils.isNotBlank(putGetServiceResponse.getRegistrosPG().get(0).getDirectorioGet()) ? putGetServiceResponse.getRegistrosPG().get(0).getDirectorioGet() : ApiConstants.WHITE_SPACE;

			patron = StringUtils.isNotBlank(putGetServiceResponse.getRegistrosPG().get(0).getPatronGet()) ? putGetServiceResponse.getRegistrosPG().get(0).getPatronGet() : ApiConstants.WHITE_SPACE;

			idPath = StringUtils.isNotBlank(putGetRequest.getIdProtocoloPath2()) ? putGetRequest.getIdProtocoloPath2() : ApiConstants.WHITE_SPACE;

			queryProtocolo.append("ORIG_PATH = :directorio, REG_EXP = :patron WHERE ID_PTCL_PATH = :idPath");

		}

		Query queryResult = entityManager.createNativeQuery(queryProtocolo.toString());

		queryResult.setParameter("directorio", directorio);
		queryResult.setParameter("patron", patron);
		queryResult.setParameter("idPath", idPath);

		queryResult.executeUpdate();

	}

	/**
	 * @param putGetServiceResponse
	 */
	@Override
	@Transactional
	public void actualizarPtclPara(PutGetServiceResponse putGetServiceResponse) {

		StringBuilder query = new StringBuilder("UPDATE H2H_MX_PTCL_PARA SET HOST_IP_ADDR = :servidor, HOST_PORT = :puerto, HOST_USER_ID = :userId, HOST_OS = :hostOs WHERE ID_PTCL_PARA = :idPara");

		Query queryResult = entityManager.createNativeQuery(query.toString());

		queryResult.setParameter("servidor", putGetServiceResponse.getRegistrosPG().get(0).getServidor());
		queryResult.setParameter("puerto", putGetServiceResponse.getRegistrosPG().get(0).getPuerto());
		queryResult.setParameter("userId", putGetServiceResponse.getRegistrosPG().get(0).getUserId());
		queryResult.setParameter("hostOs", putGetServiceResponse.getHostOs());
		queryResult.setParameter("idPara", putGetServiceResponse.getIdPara());

		queryResult.executeUpdate();

	}

	/**
	 * @param putGetServiceResponse
	 */
	@Override
	@Transactional
	public void actualizaParaSFTPCD(PutGetServiceResponse putGetServiceResponse) {

		StringBuilder query = new StringBuilder();

		String idProtocolo = putGetServiceResponse.getRegistrosPG().get(0).getIdProtocolo();
		String idptclpara = putGetServiceResponse.getIdPara();

		switch (idProtocolo) {

		case "1":

			//SFTP
			query.append("UPDATE H2H_MX_PARA_SFTP SET PROF_ID = :profileId, KNOW_HOST_KEY = :knowIdHost, USER_ID_KEY = :userIdKey WHERE ID_PTCL_PARA = :idptclpara");

			Query querySftpResult = entityManager.createNativeQuery(query.toString());

			querySftpResult.setParameter("profileId", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getProfileId()));
			querySftpResult.setParameter("knowIdHost", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getKnowIdHost()));
			querySftpResult.setParameter("userIdKey", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getUserIdKey()));
			querySftpResult.setParameter("idptclpara", idptclpara);

			querySftpResult.executeUpdate();

			break;

		case "2":

			//Connect Direct
			query.append("UPDATE H2H_MX_PARA_CD SET LCAL_NODE = :nodoLocal, REMT_NODE = :nodoRemoto, LCAL_USER = :usuarioLocal, REMT_USER = :userId, REMT_PWD = :passwordRemoto, ");
			query.append("USE_OBSC_PWD = :oscurecerPwd, BIN_MODE = :modoBinario, REC_FORM = :formatoRegistro, REC_LEN = :longitudRegistro, DISP_MODE = :modoDisp, SYS_OPT = :parametroSysOpts, ");
			query.append("REC_DISP = :disposicionRegistro WHERE ID_PTCL_PARA = :idptclpara");

			Query queryCdResult = entityManager.createNativeQuery(query.toString());

			queryCdResult.setParameter("nodoLocal", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getNodoLocal()));
			queryCdResult.setParameter("nodoRemoto", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getNodoRemoto()));
			queryCdResult.setParameter("usuarioLocal", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getUsuarioLocal()));
			queryCdResult.setParameter("userId", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getUserId()));
			queryCdResult.setParameter("passwordRemoto", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getPasswordRemoto()));
			queryCdResult.setParameter("oscurecerPwd", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getOscurecerPwd()));
			queryCdResult.setParameter("modoBinario", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getModoBinario()));
			queryCdResult.setParameter("formatoRegistro", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getFormatoRegistro()));
			queryCdResult.setParameter("longitudRegistro", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getLongitudRegistro()));
			queryCdResult.setParameter("modoDisp", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getModoDisp()));
			queryCdResult.setParameter("parametroSysOpts", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getParametroSysOpts()));
			queryCdResult.setParameter("disposicionRegistro", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getDisposicionRegistro()));
			queryCdResult.setParameter("idptclpara", idptclpara);

			queryCdResult.executeUpdate();

			break;

		case "5":

			//WEBSERVICE
			query.append("UPDATE H2H_MX_PARA_WS SET URI_CONS_WS = :uriConsultaWS, CERT_WS = :certificadoWS, URI_PUT_WS = :uriPUTWS, URI_GET_WS = :uriGETWS WHERE ID_PTCL_PARA = :idptclpara");

			Query queryWSResult = entityManager.createNativeQuery(query.toString());

			queryWSResult.setParameter("uriConsultaWS", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getPutGetWSDto().getUriConsultaWS()));
			queryWSResult.setParameter("certificadoWS", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getPutGetWSDto().getCertificadoWS()));
			queryWSResult.setParameter("uriPUTWS", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getPutGetWSDto().getUriPUTWS()));
			queryWSResult.setParameter("uriGETWS", validateEmptyString(putGetServiceResponse.getRegistrosPG().get(0).getPutGetWSDto().getUriGETWS()));
			queryWSResult.setParameter("idptclpara", validateEmptyString(idptclpara));

			queryWSResult.executeUpdate();

			break;

		default:

			log.info("IdProtocolo no encontrado. No se realiza inserción de datos.");

			break;

		}

	}

	/**
	 * Valida datos nulos para asignarlos vacíos.
	 * 
	 * @param value valor a validar
	 * @return retorna dato o vacío
	 */
	private String validateEmptyString(String value) {

		if (StringUtils.isBlank(value)) {
			value = "";
		}

		return value;
	}

}
