package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.model.response.ProductResponse;

import java.util.List;

/**
 * IProductService.
 * Define los metodos de negocio para le obtencion de l catalogo de productos.
 *
 * @author Jesus Soto Aguilar
 * @since 20/04/2023
 */
public interface IProductService {

    /**
     * Obtiene la lista de productos activos.
     *
     * @return Lista de productos.
     */
    List<ProductResponse> getProductos();

    /**
     * Obtiene el producto por su clave.
     *
     * @return Objeto con los datos del producto.
     */
    ProductResponse getProductoByClave(String claveProducto);
}
