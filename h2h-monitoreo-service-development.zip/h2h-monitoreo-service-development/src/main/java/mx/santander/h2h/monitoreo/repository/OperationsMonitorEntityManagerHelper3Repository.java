package mx.santander.h2h.monitoreo.repository;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Repository;

import mx.santander.h2h.monitoreo.constants.MonitorOperacionesConstants;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.util.UtilData;
import mx.santander.h2h.monitoreo.util.UtilMonitorFnc;

/**
 * OperationsMonitorEntityManagerHelper3Repository.
 *
 * @author Daniel Ruiz
 * @modifico C320868
 */
@Repository
public class OperationsMonitorEntityManagerHelper3Repository
		implements IOperationsMonitorEntityManagerHelper3Repository {

	/** Variable para determiar si el Producto es Confirming */
	protected static final String PROD_PROV_CONFIRMING = "11";

	
	/**
	 * Retorna la fecha del objeto pasado como parametro.
	 * 
	 * @param obj Object a parsear
	 * @return String
	 */
	protected static String getFecha(Object obj) {
		String fecha = StringUtils.EMPTY;
		final SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
		if (obj instanceof java.sql.Date || obj instanceof Timestamp) {
			fecha = dateFormat.format(obj);
		}
		if (obj instanceof String) {
			fecha = obj.toString();
		}
		return fecha;
	}

	/**
	 * Verifica si el producto es una Orden de Pago
	 * 
	 * @param consultaOperaciones parametros de la consulta operaciones
	 * @return boolean valor del tipo de prodcuto
	 */
	public static boolean isOrdenPago(OperationsMonitorQueryRequest consultaOperaciones) {
		return "80".equals(consultaOperaciones.getIdProducto()) || "81".equals(consultaOperaciones.getIdProducto());
	}

	/**
	 * Verifica si el producto es una Alta Masiva de Empleados
	 * 
	 * @param consultaOperaciones parametros de la consulta operaciones
	 * @return boolean valor del tipo de prodcuto
	 */
	public static boolean isAltaMasivaEmpleados(OperationsMonitorQueryRequest consultaOperaciones) {
		return "93".equals(consultaOperaciones.getIdProducto());
	}

	/**
	 * Metodo que valida la fecha de inicio es la igual al dia de hoy
	 * 
	 * @param date String que con formato 'dd/MM/yyyy'
	 * @return Booelan si indica si la fecha es de hoy
	 */
	public static boolean isDateToday(String date) {
		final SimpleDateFormat formatoDeFecha = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
		return formatoDeFecha.format(new java.util.Date()).equals(date);
	}


	/**
	 * Verifica si el producto es Transferencias Internacionales
	 *
	 * @param consultaOperaciones parametros de la consulta operaciones
	 * @return boolean valor del tipo de prodcuto
	 */
	public static boolean isTI(OperationsMonitorQueryRequest consultaOperaciones) {
		return "31".equals(consultaOperaciones.getIdProducto()) 
				|| "33".equals(consultaOperaciones.getIdProducto());
	}


	
	public static boolean isCentroPagoMit(String idProducto) {
		return "03".equals(idProducto);
	}
	
	/**
	 * Verifica el producto pif y en caso de que se agrega los datos al query
	 * 
	 * @param consultaOperaciones parametros de la consulta operaciones
	 * @param query               Query de la consulta
	 * @param params              Lista de parametros del query
	 * @param exporta             Bandera para ver si aplica la exportacion
	 */
	protected static void validatePif(
			OperationsMonitorQueryRequest consultaOperaciones, StringBuilder query, Map<String, Object> params, boolean exportar
		) { 
		// PGODIRECT
		if (UtilData.isPif(consultaOperaciones.getIdProducto())) {
			isPif(consultaOperaciones, query, params, exportar);
		}  // <----------------- Fin de los Filtros
		
		if (consultaOperaciones.isEsLiquidaciones()) {
			query.append(" AND PROD.CVE_PROD_OPER in(21,23) ");
		}
		if ( !UtilData.esIgual(consultaOperaciones.getHoraProgramacion(), "Todos")
				&& !UtilData.isVacio(consultaOperaciones.getHoraProgramacion())) {
			query.append("AND to_char(prod.HORA_APLI, 'HH24:MI') = :horaProg ");
			params.put("horaProg", consultaOperaciones.getHoraProgramacion());
		}
	}

	
	/**
	 * Metodo para agregar el Convenio
	 * 
	 * @param query
	 * @param exportar
	 */
	private static void isPif(
			OperationsMonitorQueryRequest consultaOperaciones, 
			StringBuilder query,  Map<String, Object> params, 
			boolean exportar) {
		if( !UtilData.isVacio(consultaOperaciones.getLineaCaptura())) {
			query.append("AND PIF.OBSE_ABO like (:lineaCaptura || '%') ");
			params.put("lineaCaptura", consultaOperaciones.getLineaCaptura());
		}
		if ( !UtilData.isVacio(consultaOperaciones.getConvenio())) {
			if (exportar) {
				query.append("AND PROD.COMENTARIO_1 = :convenio ");
			} else {
				query.append("AND PIF.CLVE_CONV = :convenio ");
			}
			params.put("convenio", consultaOperaciones.getConvenio());
		}
		if ( UtilData.esIgual(consultaOperaciones.getIdProducto(), "23")) {
			if ( !UtilData.isVacio(consultaOperaciones.getFolioSUA())
					 && consultaOperaciones.getFolioSUA().length()>0) {
				if (exportar) {
					query.append("AND UPPER(PROD.COMENTARIO_3) LIKE UPPER('%' || :folioSUA || '%') ");
				} else {
					query.append("AND UPPER(PIF.NUME_FOLI_SUA) LIKE UPPER('%' || :folioSUA || '%') ");
				}
				params.put("folioSUA", consultaOperaciones.getFolioSUA());
			}
			if ( !UtilData.isVacio(consultaOperaciones.getRegPat())
					 && consultaOperaciones.getRegPat().length()>0) {
				if (exportar) {
					query.append("AND UPPER(PROD.COMENTARIO_2) ");
						
				} else {
					query.append("AND UPPER(PIF.REG_PATR) ");
				}
				query
					.append("like UPPER('%' || :consOperRegPat || '%') ");
				params.put("consOperRegPat", consultaOperaciones.getRegPat());
			}
		}
	}
	
	
	/**
	 * Metodo para validar el campo PIF2
	 * 
	 * @param consultaOperaciones
	 * @param query
	 * @param params
	 * @param someFilter
	 */
	protected static void validatePif2(
			OperationsMonitorQueryRequest consultaOperaciones, 
			StringBuilder query,
			Map<String, Object> params, 
			boolean someFilter
		) { 
		if ( !UtilData.isVacio(consultaOperaciones.getNumeroOrden()) ) {
			UtilMonitorFnc.armaQueryAnd(query, "PROD.NUM_ORDEN = :numOrden ", someFilter);
			params.put("numOrden", consultaOperaciones.getNumeroOrden());
		}
		if ( !UtilData.isVacio(consultaOperaciones.getNombreBeneficiario()) ) {
			UtilMonitorFnc.armaQueryAnd(query, "UPPER(PROD.BENEFICIARIO) LIKE UPPER('%' || :beneficiario || '%') ", someFilter);
			params.put("beneficiario", "'"+ consultaOperaciones.getNombreBeneficiario() +"'");
		}
		if ( !UtilData.isVacio(consultaOperaciones.getPersonaAutorizada()) ) {
			UtilMonitorFnc.armaQueryAnd(query, "UPPER(PROD.NOMB_PERS_AUT_EXT) LIKE UPPER('%' || :personaAutorizada || '%') ", someFilter);
			params.put("personaAutorizada", consultaOperaciones.getPersonaAutorizada());
		}
		if ( !UtilData.isVacio(consultaOperaciones.getIdReg())) {
			UtilMonitorFnc.armaQueryAnd(query, "PROD.ID_REG = :idReg ", someFilter);
			params.put("idReg", consultaOperaciones.getIdReg());
		}
		if ( !UtilData.isVacio(consultaOperaciones.getNumEmpleado())	
				&& !PROD_PROV_CONFIRMING.equals(consultaOperaciones.getIdProducto())) {		
			UtilMonitorFnc.armaQueryAnd(query, "PROD.NUMERO_EMPLEADO = :numEmpleado", someFilter);
			params.put("numEmpleado", consultaOperaciones.getNumEmpleado());
		}
		if ( !UtilData.isVacio(consultaOperaciones.getNumTarjeta()) 
				&& !PROD_PROV_CONFIRMING.equals(consultaOperaciones.getIdProducto())) {		
			UtilMonitorFnc.armaQueryAnd(query, "PROD.NUMERO_TARJETA = :numTarjeta ", someFilter);
			params.put("numTarjeta", consultaOperaciones.getNumTarjeta());
		}
		if ( !UtilData.isVacio(consultaOperaciones.getSucTutora()) 
				&& !PROD_PROV_CONFIRMING.equals(consultaOperaciones.getIdProducto())) {		
			UtilMonitorFnc.armaQueryAnd(query, "PROD.SUCURSAL_TUTORA = :sucTutora ", someFilter);
			params.put("sucTutora", consultaOperaciones.getSucTutora());
		}if ( !UtilData.isVacio(consultaOperaciones.getTipo()) 
				&& !UtilData.esIgual(consultaOperaciones.getTipo(), MonitorOperacionesConstants.CERO) ) {
			UtilMonitorFnc.armaQueryAnd(query, "PROD.TIPO IS ", someFilter);
			if ( UtilData.esIgual(consultaOperaciones.getTipo(), "PREEXISTENTE") ) {
				query.append("NOT NULL ");
			}
			query.append("NULL ");
			someFilter = true;
		}
	}
}
