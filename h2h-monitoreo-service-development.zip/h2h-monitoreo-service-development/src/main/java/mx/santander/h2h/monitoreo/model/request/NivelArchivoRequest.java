/**
* Santander SCIB - Banco Santander Negocios Globales
* Todos los derechos reservados
* NivelArchivoRequest.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <20 nov 2024 09:18:58>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.model.request;

import java.io.Serializable;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NivelArchivoRequest implements Serializable {

	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = -385219171186379355L;

	/** Declaracion de String para idCliente. */
	@Pattern(regexp = "(^[0-9 ]+$)?", message = "Datos de Cliente no valido")
	@Size(min = 0, max = 15, message = "Datos de Cliente erroneo")
	private String idCliente;
	
	/** Declaracion de String para cliente. */
	@Pattern(regexp = "(^[a-zA-Z0-9% ]+$)?", message = "Datos de Cliente no valido")
	@Size(min = 0, max = 120, message = "Datos de Cliente erroneo")
	private String cliente;
	
	/** Declaracion de int para estatus. */
	private int estatus;
	
	/** Declaracion de String para nombreArchivo. */
	@Pattern(regexp = "(^((([a-z])?/.*)|(([a-zA-Z]:)?(\\\\([a-zA-Z0-9_.-]+\\\\?)?))?)+(([a-zA-Z0-9]+)?(.([.a-zA-Z0-9])?)?)+$)?", message = "Archivo No valido")
	private String nombreArchivo;
	
}
