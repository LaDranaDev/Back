package mx.santander.h2h.monitoreo.util;

import mx.santander.h2h.monitoreo.model.response.GenerateVouchersDtoResponse;

/**
 * Descripcion: utileria para funciones de apoyo en los datos adicionales
 * 
 * DatosAdicionalesUtils.java
 */
public final class DatosAdicionalesUtils {

	/**
	 * Descripcion : Contructor de clase
	 * 
	 */
	private DatosAdicionalesUtils() {
		/** costructor de clase */
	}

	/**
	 * Descripcion : Metodo que realiza la validacion de la trama de datos
	 * adicionales
	 * 
	 * @param bean que contiene la trama
	 * @return boolean con la respuesta de la validacion
	 */
	public static boolean validaTramaAdicionales(GenerateVouchersDtoResponse bean) {

		boolean respuesta = false;

		if (null != bean.getCdmxBean().getTramaAdicionalesEntrada()
				&& !"".equals(bean.getCdmxBean().getTramaAdicionalesEntrada())) {
			respuesta = true;
		}

		/** Se retorna la respuesta */
		return respuesta;
	}

	/**
	 * Descripcion : Metodo que realiza la validacion para determinar si son
	 * requeridos los campos adicionales
	 * 
	 * @param datosADC    string de datos adicionales
	 * @param cantidadADC cantidad de datos adicionales
	 * @return boolean con el resultado de la validacion
	 */
	public static boolean adicionalesRequeridos(String datosADC, int cantidadADC) {

		boolean respuesta = false;

		/** Se hace la validacion */
		if (!datosADC.isEmpty() || cantidadADC == 0) {
			respuesta = true;
		}

		/** Se retorna la respuesta */
		return respuesta;
	}

	/**
	 * Descripcion : Metodo que realiza la validacion de si es necesario actualizar
	 * la BD
	 * 
	 * @param base64      base 64 retornado por el ws
	 * @param cantidadADC cantidad de campos adicionales
	 * @return boolean con el resultado de la validacion
	 */
	public static boolean actualizacionBDRequerida(String base64, int cantidadADC) {

		boolean respuesta = false;

		/** Se hace la validacion */
		if (!"".equals(base64) && cantidadADC > 0) {
			respuesta = true;
		}

		/** Se retorna la respuesta */
		return respuesta;
	}

}
