package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.model.request.PistaAuditoriaRequest;

/**
 * Interfaz del objeto de negocio para la gestion de logs y pistas auditables
 * 
 * @author Santander
 * @since 16/06/2022
 */
public interface IPistaAuditoriaService {

	/**
	 * registrarPista
	 * 
	 * Metodo para registrar la pista de auditoria
	 * 
	 * @param pistaAuditoriaRequest dto con la información a registrar
	 */
	void registrarPista(PistaAuditoriaRequest pistaAuditoriaRequest);
}
