package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;

import static org.mockito.Mockito.*;

class OperationsDetailMttoProvRepositoryTest {
    @Mock
    EntityManager entityManager;
    @Mock
    Logger log;
    @InjectMocks
    OperationsDetailMttoProvRepository repository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        repository = spy(repository);
    }

    @Test
    void testObtenerDetalleOperacion() {
        doReturn("").when(repository).generaConsultaDetalleOperacion(anyString(),anyString());
        doNothing().when(repository).mapDetalleOperacion(any(), any());

        Query query = mock(Query.class);
        when(query.getResultList()).thenReturn(Collections.singletonList(mock(Tuple.class)));

        when(entityManager.createNativeQuery(any(), (Class<?>) any())).thenReturn(query);

        Assertions.assertDoesNotThrow(() ->
                repository.obtenerDetalleOperacion("view", "idOperacion")
        );
    }

    @Test
    void testMapDetalleOperacion() {
        Tuple tuple1 = mock(Tuple.class);
        when(tuple1.get((String) any())).then(answer -> {
            String arg = answer.getArgument(0);
            if ("IMPORTE".equals(arg)) return "999.99";
            if ("IMPORTE_CARGO".equals(arg)) return "999.99";
            if ("REFERENCIA".equals(arg)) return "0";
            if ("DIVISA".equals(arg)) return "MN";
            if ("DIVISA_ORD".equals(arg)) return "MN";
            if ("CVE_PROD_OPER".equals(arg)) return "99";
            return arg;
        });

        Tuple tuple2 = mock(Tuple.class);
        when(tuple2.get((String) any())).then(answer -> {
            String arg = answer.getArgument(0);
            if ("IMPORTE".equals(arg)) return "999.99";
            if ("IMPORTE_CARGO".equals(arg)) return "999.99";
            if ("REFERENCIA".equals(arg)) return "null";
            if ("DIVISA".equals(arg)) return "MXN";
            if ("DIVISA_ORD".equals(arg)) return "MXN";
            if ("SUCURSAL_TUTORA".equals(arg)) return "11";
            return arg;
        });

        Assertions.assertDoesNotThrow(() -> {
            repository.mapDetalleOperacion(tuple1, new OperationsMonitorQueryResponse());
            repository.mapDetalleOperacion(tuple2, new OperationsMonitorQueryResponse());
        });
    }

    @Test
    void testGeneraConsultaDetalleOperacion() {
        doReturn("").when(repository).getConsultaByProducto(any(), anyBoolean());

        String result = repository.generaConsultaDetalleOperacion("view","12");
        Assertions.assertNotNull(result);
    }

    @Test
    void testGetConsultaByProducto() {
        doNothing().when(repository).getConsultaByProducto(any(), any());

        for (String cveOperProd : Arrays.asList("01", "97", "02", "95", "96", "98", "99")) {
            Assertions.assertDoesNotThrow(() -> {
                repository.getConsultaByProducto(cveOperProd, true);
                repository.getConsultaByProducto(cveOperProd, false);
            });
        }
    }

    @Test
    void testGetConsultaByProducto2() {
        doNothing().when(repository).getConsultaByProductoAux(any(), any());

        for (String cveOperProd : Arrays.asList("01", "97", "02", "80", "81", "95", "96", "98", "99", "00")) {
            Assertions.assertDoesNotThrow(() ->
                    repository.getConsultaByProducto(new StringBuilder(), cveOperProd)
            );
        }
    }

    @Test
    void testGetConsultaByProductoAux() {
        for (String cveOperProd : Arrays.asList("91", "135", "11", "93", "00")) {
            Assertions.assertDoesNotThrow(() ->
                    repository.getConsultaByProductoAux(new StringBuilder(), cveOperProd)
            );
        }
    }

    @Test
    void testGetFecha() {
        String result = repository.getFecha("02/02/2020");
        Assertions.assertEquals("02/02/2020", result);

        result = repository.getFecha(
                Timestamp.valueOf(LocalDate.of(2020, 2, 2).atStartOfDay())
        );
        Assertions.assertEquals("02/02/2020", result);
    }

    @Test
    void testGetValue() {
        Tuple tuple = mock(Tuple.class);
        String result = repository.getValue(tuple, "key");
        Assertions.assertEquals("", result);

        when(tuple.get("key")).thenThrow(IllegalArgumentException.class);
        result = repository.getValue(tuple, "key");
        Assertions.assertEquals("", result);
    }

}
