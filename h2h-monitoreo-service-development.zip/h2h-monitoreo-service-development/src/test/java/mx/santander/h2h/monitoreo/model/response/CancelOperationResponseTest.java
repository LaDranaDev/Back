package mx.santander.h2h.monitoreo.model.response;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class CancelOperationResponseTest {

    CancelOperationResponse response = new CancelOperationResponse();

    @Test
    void setMuestraBusqueda() {
        response.setMuestraBusqueda("0");
        Assertions.assertEquals("0", response.getMuestraBusqueda());
    }

    @Test
    void setReadOnly() {
        response.setReadOnly("disabled='disabled'");
        Assertions.assertEquals("disabled='disabled'", response.getReadOnly());
    }

    @Test
    void setHdnContratoFolio() {
        response.setHdnContratoFolio("089000000886");
        Assertions.assertEquals("089000000886", response.getHdnContratoFolio());
    }

    @Test
    void testToString() {
        String result = response.toString();
        Assertions.assertNotNull(result);
    }
}