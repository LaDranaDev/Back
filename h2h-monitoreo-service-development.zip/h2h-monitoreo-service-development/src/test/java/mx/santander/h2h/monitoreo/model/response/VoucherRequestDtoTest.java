package mx.santander.h2h.monitoreo.model.response;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class VoucherRequestDtoTest {

	@InjectMocks
	VoucherRequestDto voucherRequestDto;

	@Test
	void getSetLineaCaptura() {

		voucherRequestDto.setLineaCaptura("lineaCaptura");

		assertEquals("lineaCaptura", voucherRequestDto.getLineaCaptura());

	}

	@Test
	void getSetCanalOperacion() {

		voucherRequestDto.setCanalOperacion(10);

		assertEquals(10, voucherRequestDto.getCanalOperacion());

	}

	@Test
	void getSetFecha() {

		voucherRequestDto.setFecha("07/06/2023");

		assertEquals("07/06/2023", voucherRequestDto.getFecha());

	}

	@Test
	void getSetImporte() {

		voucherRequestDto.setImporte(200.00);

		assertEquals(200.00, voucherRequestDto.getImporte());

	}

	@Test
	void getSetReferencia() {

		voucherRequestDto.setReferencia("Referencia");

		assertEquals("Referencia", voucherRequestDto.getReferencia());

	}

	@Test
	void getSetBase64() {

		voucherRequestDto.setBase64("Base64");

		assertEquals("Base64", voucherRequestDto.getBase64());

	}

	@Test
	void getSetIdReg() {

		voucherRequestDto.setIdReg("IdReg");

		assertEquals("IdReg", voucherRequestDto.getIdReg());

	}

	@Test
	void getSetTramaAdicionalesEntrada() {

		voucherRequestDto.setTramaAdicionalesEntrada("TramaAdicionalesEntrada");

		assertEquals("TramaAdicionalesEntrada", voucherRequestDto.getTramaAdicionalesEntrada());

	}

	@Test
	void testToString() {

		String toStringResult = voucherRequestDto.toString();

		assertEquals(
				"VoucherRequestDto(lineaCaptura=null, canalOperacion=null, fecha=null, importe=null, referencia=null, base64=null, idReg=null, tramaAdicionalesEntrada=null)",
				toStringResult);

	}

}
