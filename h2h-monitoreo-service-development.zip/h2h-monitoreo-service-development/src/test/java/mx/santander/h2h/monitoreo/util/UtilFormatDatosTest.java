package mx.santander.h2h.monitoreo.util;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;


@ExtendWith(MockitoExtension.class)
class UtilFormatDatosTest {

	@InjectMocks
    private UtilFormatDatos util;
    
	private final String VACIO = ""; 
	private final String VACIO2 = "    ";
	private final String CADENA = "cadena";
	private final String MXP = "MXP";
	private final String TEST = "TEST";
	private final String DIEZ = "10.00";
	private final String ABONO = "ABONO A CUENTA";
    
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testDefaultObjectString() {
		String resp = UtilFormatDatos.defaultObjectString(null, VACIO);
		assertThat(resp).isEqualTo(VACIO);
		
		resp = UtilFormatDatos.defaultObjectString(null, VACIO2);
		assertThat(resp).isEqualTo(VACIO2);
		
		resp = UtilFormatDatos.defaultObjectString(123456, VACIO2);
		assertThat(resp).isEqualTo("123456");
		
		resp = UtilFormatDatos.defaultObjectString(123456, VACIO);
		assertThat(resp).isEqualTo("123456");
		
		resp = UtilFormatDatos.defaultObjectString(CADENA, CADENA);
		assertThat(resp).isEqualTo(CADENA);
		
		resp = UtilFormatDatos.defaultObjectString(CADENA, "null");
		assertThat(resp).isEqualTo(CADENA);
	}

	@Test
	void testTraduceDivisa() {
		String resp = UtilFormatDatos.traduceDivisa(null);
		assertThat(resp).isEqualTo(VACIO);
		
		resp = UtilFormatDatos.traduceDivisa(VACIO);
		assertThat(resp).isEqualTo(VACIO);
		
		resp = UtilFormatDatos.traduceDivisa("MN");
		assertThat(resp).isEqualTo(MXP);
		
		resp = UtilFormatDatos.traduceDivisa(MXP);
		assertThat(resp).isEqualTo(MXP);
		
		resp = UtilFormatDatos.traduceDivisa(TEST);
		assertThat(resp).isEqualTo(TEST);
	}

	@Test
	void testTraduceTipoPago() {
		String resp = UtilFormatDatos.traduceTipoPago(null);
		assertThat(resp).isEqualTo("OTRO");
		
		resp = UtilFormatDatos.traduceTipoPago(VACIO);
		assertThat(resp).isEqualTo("OTRO");
		
		resp = UtilFormatDatos.traduceTipoPago("E");
		assertThat(resp).isEqualTo("E-EFECTIVO");
		
		resp = UtilFormatDatos.traduceTipoPago("C");
		assertThat(resp).isEqualTo("C-CHEQUE");
		
		resp = UtilFormatDatos.traduceTipoPago(TEST);
		assertThat(resp).isEqualTo("OTRO");
	}

	@Test
	void testTraduceTipoPagoPD() {
		String resp = UtilFormatDatos.traduceTipoPagoPD(null);
		assertThat(resp).isEqualTo(ABONO);
		
		resp = UtilFormatDatos.traduceTipoPagoPD(VACIO);
		assertThat(resp).isEqualTo(ABONO);
		
		resp = UtilFormatDatos.traduceTipoPagoPD("E");
		assertThat(resp).isEqualTo("EFECTIVO");
		
		resp = UtilFormatDatos.traduceTipoPagoPD("C");
		assertThat(resp).isEqualTo("CHEQUE");
		
		resp = UtilFormatDatos.traduceTipoPagoPD(TEST);
		assertThat(resp).isEqualTo(ABONO);
	}

	@Test
	void testTraduceImporte() {
		String resp = UtilFormatDatos.traduceImporte(null);
		assertThat(resp).isEqualTo("0.00");
		
		resp = UtilFormatDatos.traduceImporte(VACIO);
		assertThat(resp).isEqualTo("0.00");
		
		resp = UtilFormatDatos.traduceImporte(10.001000);
		assertThat(resp).isEqualTo(DIEZ);
		
		resp = UtilFormatDatos.traduceImporte("10.00100");
		assertThat(resp).isEqualTo(DIEZ);
	}

	@Test
	void testVacioSiCero() {
		String resp = UtilFormatDatos.vacioSiCero(null);
		assertNull(resp);
		
		resp = UtilFormatDatos.vacioSiCero(VACIO);
		assertThat(resp).isEqualTo(VACIO);
		
		resp = UtilFormatDatos.vacioSiCero("0");
		assertThat(resp).isEqualTo(VACIO);
		
		resp = UtilFormatDatos.vacioSiCero("0000");
		assertNotNull(resp);
		
		resp = UtilFormatDatos.vacioSiCero("1");
		assertNotNull(resp);
		
		resp = UtilFormatDatos.vacioSiCero("10");
		assertNotNull(resp);
	}

	@Test
	void testAcompletaCerosIzqSiNum() {
		String resp = UtilFormatDatos.acompletaCerosIzqSiNum(null, 0);
		assertThat(resp).isEqualTo(VACIO);
		
		resp = UtilFormatDatos.acompletaCerosIzqSiNum(VACIO, 10);
		assertThat(resp).isEqualTo(VACIO);
		
		resp = UtilFormatDatos.acompletaCerosIzqSiNum(123, 10);
		assertNotNull(resp);
		
		resp = UtilFormatDatos.acompletaCerosIzqSiNum("123", 10);
		assertNotNull(resp);
	}

	@Test
	void testConvierteNumero() {
		int resp = UtilFormatDatos.convierteNumero(null);
		assertThat(resp).isEqualTo(0);
		
		resp = UtilFormatDatos.convierteNumero(VACIO);
		assertThat(resp).isEqualTo(0);
		
		
		resp = UtilFormatDatos.convierteNumero("A");
		assertThat(resp).isEqualTo(0);
		
		resp = UtilFormatDatos.convierteNumero("1");
		assertNotEquals(resp, 0);
		
		resp = UtilFormatDatos.convierteNumero(1);
		assertNotEquals(resp, 0);
	}

	@Test
	void testConvierteLong() {
		Long resp = UtilFormatDatos.convierteLong(null);
		assertThat(resp).isEqualTo(0);
		
		resp = UtilFormatDatos.convierteLong(VACIO);
		assertThat(resp).isEqualTo(0);
		
		resp = UtilFormatDatos.convierteLong("A");
		assertThat(resp).isEqualTo(0);
		
		resp = UtilFormatDatos.convierteLong("1");
		assertNotEquals(resp, 0);
		
		resp = UtilFormatDatos.convierteLong( 1 );
		assertNotEquals(resp, 0);
		
		resp = UtilFormatDatos.convierteLong( 10 );
		assertNotEquals(resp, 0);
	}

}
