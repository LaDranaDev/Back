package mx.santander.h2h.monitoreo.repository;

import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import jakarta.persistence.TypedQuery;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CancelOperationRepositoryTest {
	@InjectMocks
    private CancelOperationRepository cancelOperationRepository;
	
	@Mock
    private EntityManager entityManager;

    @Mock
    private Tuple tuple1;

    
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    	tuple1 = mock(Tuple.class);
    }
    
    @Test
    void obtenerCatalogoEstatusEmtyDataTest() {
    	
        Query query = mock(Query.class, RETURNS_MOCKS);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        
        List<Object[]> lst = new ArrayList<>();
		Object[] arr = {"","QWERT","","","","","","1","","","","","","","","","" };
		lst.add(arr);
		when(query.getResultList()).thenReturn(lst);
		
        
        assertDoesNotThrow(() -> cancelOperationRepository.obtenerCatalogoEstatus("C"));
    }

    
    @Test
    void obtenerCatalogoEstatusTest() {
        TypedQuery query = Mockito.mock(TypedQuery.class);

        when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);

        cancelOperationRepository.obtenerCatalogoEstatus("C");

        Assertions.assertTrue(true);
    }
    
    
    @Test
    void updateCancelOperationTest() {
    	String[] registrosList = {"hola", "mundo", "test"};
    	Query query = mock(Query.class, RETURNS_MOCKS);
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        int resp = 0;
        
    	resp = cancelOperationRepository.updateCancelOperation(registrosList);
    	if( resp == 0) {
    		assertTrue(resp==0);
    	} else {
    		assertTrue(resp>0);
    	}
    }
}