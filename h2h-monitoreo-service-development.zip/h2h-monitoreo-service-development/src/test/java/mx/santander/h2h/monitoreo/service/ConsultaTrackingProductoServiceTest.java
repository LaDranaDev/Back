package mx.santander.h2h.monitoreo.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.NivelProductoRequest;
import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import mx.santander.h2h.monitoreo.model.response.ProductoArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ResultTrackingResponse;
import mx.santander.h2h.monitoreo.repository.IConsultaTrackingProductoRepository;

@ExtendWith(MockitoExtension.class)
class ConsultaTrackingProductoServiceTest {

	@InjectMocks
	private ConsultaTrackingProductoService consultaTrackingProductoService;
	
	@Mock
	private IConsultaTrackingProductoRepository consultaTrackingProductoRepository;
	
	@Mock
	private IJasperReportService reportService;
	
	@Test
	void test() {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		resultTrackingResponse.setListCombo(obtenerCatalogoProd());
		resultTrackingResponse.setArchProd(prodArchResponse());
		
		ResultTrackingResponse resultTrackingResponse1 = new ResultTrackingResponse();
		resultTrackingResponse1.setListCombo(obtenerCatalogoEstatus());
		
		Mockito.when(this.consultaTrackingProductoRepository.obtenerCatalogoProductos()).thenReturn(resultTrackingResponse);
		Mockito.when(this.consultaTrackingProductoRepository.obtenerCatalogoEstatus(Mockito.anyString())).thenReturn(resultTrackingResponse1);
		Mockito.when(this.consultaTrackingProductoRepository.obtenerConteoArchivo(Mockito.anyString(), Mockito.any())).thenReturn(resultTrackingResponse);
		consultaTrackingProductoService.iniciaNivelProducto(nivelProductoReq());
		Assertions.assertTrue(true);
	}
	
	public NivelProductoRequest nivelProductoReq() {
		NivelProductoRequest nivelProd = new NivelProductoRequest();
		
		nivelProd.setCodCliente("12345678");
		nivelProd.setNomCliente("Kaori");
		nivelProd.setIdArchivo(74593);
		nivelProd.setIdEstatus(5);
		
		return nivelProd;
	}

	public List<ComboResponse> obtenerCatalogoProd(){
		List<ComboResponse> listCombo = new ArrayList<>();
		
		ComboResponse combo = new ComboResponse();
		combo.setId(1);
		combo.setValor("Valor");
		
		listCombo.add(combo);
		
		return listCombo;
	}
	
	public List<ComboResponse> obtenerCatalogoEstatus(){
		List<ComboResponse> listCombo = new ArrayList<>();
		
		ComboResponse combo = new ComboResponse();
		combo.setId(1);
		combo.setValor("Final");
		
		listCombo.add(combo);
		
		return listCombo;
	}
	
	public ProductoArchivoResponse prodArchResponse(){
		ProductoArchivoResponse archivoResponse = new ProductoArchivoResponse();
		archivoResponse.setNombreArchivo("Archivo");
		archivoResponse.setFechaRecep("19-12-2021");
		archivoResponse.setEstatus("Rechazado");
		archivoResponse.setTotalOperaciones(12);
		archivoResponse.setMonto(new BigDecimal("21.3"));
		return archivoResponse;
	}
	
	@Test
	void obtenerDetalleArchivosNivelArchivo(){
		List<ProductoArchivoResponse> companies = new ArrayList<>();
		Page<ProductoArchivoResponse> pagedResponse = new PageImpl(companies);
		
		Mockito.when(this.consultaTrackingProductoRepository.obtenerDetalleArchivo(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(pagedResponse);
		
		Assertions.assertNotNull(consultaTrackingProductoService.obtenerDetalleArchivo(nivelProductoReq(), Pageable.ofSize(1)));
	}
	
	@Test
	void getReportXls(){
		ReportResponse responseData = new ReportResponse();
		responseData.setData("data");
		responseData.setLength(12);
		responseData.setName("name");
		responseData.setType("application/octet-stream");
		
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		resultTrackingResponse.setListCombo(obtenerCatalogoProd());
		resultTrackingResponse.setArchProd(prodArchResponse());
		
		ResultTrackingResponse resultTrackingResponse1 = new ResultTrackingResponse();
		resultTrackingResponse1.setListCombo(obtenerCatalogoEstatus());
		
		Mockito.when(this.consultaTrackingProductoRepository.obtenerCatalogoProductos()).thenReturn(resultTrackingResponse);
		Mockito.when(this.consultaTrackingProductoRepository.obtenerCatalogoEstatus(Mockito.anyString())).thenReturn(resultTrackingResponse);
		Mockito.when(this.consultaTrackingProductoRepository.obtenerConteoArchivo(Mockito.anyString(), Mockito.any())).thenReturn(resultTrackingResponse);
		Mockito.when(reportService.getXls(Mockito.anyString(), Mockito.any(), Mockito.any())).thenReturn(responseData);
		
		consultaTrackingProductoService.getReportXls(nivelProdReq(), "Kaori");
		
		Assertions.assertTrue(true);
	}
	
	public NivelProductoRequest nivelProdReq() {
    	NivelProductoRequest nivelProductoRequest = new NivelProductoRequest();
    	nivelProductoRequest.setIdArchivo(74593);
    	nivelProductoRequest.setCodCliente("12345678");
    	nivelProductoRequest.setIdEstatus(5);
    	nivelProductoRequest.setIdProducto(1);
    	return nivelProductoRequest;
    }
}
