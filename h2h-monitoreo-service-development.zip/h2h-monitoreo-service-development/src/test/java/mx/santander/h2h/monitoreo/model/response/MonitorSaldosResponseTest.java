package mx.santander.h2h.monitoreo.model.response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class MonitorSaldosResponseTest {

	private MonitorSaldosResponse monitorSaldosResponse;

	@BeforeEach
	void seUp() {
		monitorSaldosResponse = new MonitorSaldosResponse();
	}

	@Test
	void getCuentaOrdenante() {
		monitorSaldosResponse.setCuentaOrdenante("cuenta");
		assertEquals("cuenta", monitorSaldosResponse.getCuentaOrdenante());
	}

	@Test
	void getFechaEnvioConsulta() {
		monitorSaldosResponse.setFechaEnvioConsulta("fecha");
		assertEquals("fecha", monitorSaldosResponse.getFechaEnvioConsulta());
	}

	@Test
	void getHoraEnvioConsulta() {
		monitorSaldosResponse.setHoraEnvioConsulta("hora");
		assertEquals("hora", monitorSaldosResponse.getHoraEnvioConsulta());
	}

	@Test
	void getMontoRequerido() {
		monitorSaldosResponse.setMontoRequerido("123");
		assertEquals("123", monitorSaldosResponse.getMontoRequerido());
	}

	@Test
	void getSaldoConsulta() {
		monitorSaldosResponse.setSaldoConsulta("123");
		assertEquals("123", monitorSaldosResponse.getSaldoConsulta());
	}

	@Test
	void getSaldoFaltante() {
		monitorSaldosResponse.setSaldoFaltante("123");
		assertEquals("123", monitorSaldosResponse.getSaldoFaltante());
	}

	@Test
	void getLineaCredito() {
		monitorSaldosResponse.setLineaCredito("A");
		assertEquals("A", monitorSaldosResponse.getLineaCredito());
		
		Parametros par = new Parametros();
		par.setParametros(null);
		par.getParametros();
		
	}

	@Test
	void getNombreArchivo() {
		monitorSaldosResponse.setNombreArchivo("nombre");
		assertEquals("nombre", monitorSaldosResponse.getNombreArchivo());
		
		ResultTrackingResponse res = new ResultTrackingResponse();
		res.setCodError(null);
		res.setListArchOpe(null);
		res.setListArchProd(null);
		res.setListBeanArchivo(null);
		res.setMsgError(null);
		res.setNumElem(0);
		res.setParam(0);
		res.setRespuesta(null);
		res.setExitoso(false);
		
		res.getCodError();
		res.getListArchOpe();
		res.getListArchProd();
		res.getListBeanArchivo();
		res.getMsgError();
		res.getNumElem();
		res.getParam();
		res.getRespuesta();
		res.isExitoso();
	}

	@Test
	void getCveProdOper() {
		monitorSaldosResponse.setCveProdOper("clave");
		assertEquals("clave", monitorSaldosResponse.getCveProdOper());
		
		OperationsMonitorCatalogsYHorasResponse ope = new OperationsMonitorCatalogsYHorasResponse();
		ope.getListaHorario02();
		ope.getListaHorario29();
		ope.getListaHorario99();
		ope.getOperationsMonitorCatalogsResponse();
		
		ProductoArchivoResponse pro = new ProductoArchivoResponse();
		pro.setBuc(null);
		pro.setBucDuplicado(null);
		pro.setCanal(null);
		pro.setCliente(null);
		pro.setCodigoCliente(null);
		pro.setEnvioBackend(null);
		pro.setEstatusFinal(null);
		pro.setIdArchivo(null);
		pro.setIdEstatus(null);
		pro.setIdProducto(null);
		pro.setMotRechazo(null);
		pro.setNombreArchivoProcesado(null);
		pro.setRegresoBackend(null);
		pro.setUmbral(null);
		
		pro.getBuc();
		pro.getBucDuplicado();
		pro.getCanal();
		pro.getCliente();
		pro.getCodigoCliente();
		pro.getEnvioBackend();
		pro.getEstatusFinal();
		pro.getIdArchivo();
		pro.getIdEstatus();
		pro.getIdProducto();
		pro.getMotRechazo();
		pro.getNombreArchivoProcesado();
		pro.getRegresoBackend();
		pro.getUmbral();
		
	}

	@Test
	void getProducto() {
		monitorSaldosResponse.setProducto("producto");
		assertEquals("producto", monitorSaldosResponse.getProducto());

		NivelGeneralResponse response = new NivelGeneralResponse();
		response.setBeanArchivo(null);
		response.setBeanArchivoDetalle(null);
		response.setCodCliente(null);
		response.setFecha(null);
		response.setListBeanArchivo(null);

		response.getBeanArchivo();
		response.getBeanArchivoDetalle();
		response.getCodCliente();
		response.getFecha();
		response.getListBeanArchivo();

		response.toString();

		NivelOperacionHistResponse niv = new NivelOperacionHistResponse();
		niv.getFecha();

		NivelOperacionResponse niv1 = new NivelOperacionResponse();
		niv1.getCodCliente();
		niv1.getEstatusArch();
		niv1.getFecha();
		niv1.getFechaActual();
		niv1.getIdArchivo();
		niv1.getIdentEstatus();
		niv1.getIdProducto();
		niv1.getListEstatus();
		niv1.getNomArch();
		niv1.getProducto();
		
		niv1.setEstatusArch(null);
		niv1.setIdentEstatus(null);
		niv1.setNomArch(null);
		niv1.setProducto(null);
		
		NivelProductoResponse nivP = new NivelProductoResponse();
		nivP.getCliente();
		nivP.getCodCliente();
		nivP.getFecha();
		nivP.getIdArchivo();

	}

	@Test
	void builder() {
		monitorSaldosResponse = MonitorSaldosResponse.builder().build();
		assertNotNull(monitorSaldosResponse);
		
		NivOperacionResponse niv = new NivOperacionResponse();
		niv.setArchivo(null);
		niv.setCliente(null);
		niv.setCodAviso(null);
		niv.setCodCliente(null);
		niv.setCodError(null);
		niv.setIdArchivo(null);
		niv.setIdentEstatus(null);
		niv.setIdProducto(null);
		niv.setListaDetalle(null);
		niv.setListEstatus(null);
		niv.setMsgAviso(null);
		niv.setMsgError(null);
		
		niv.getArchivo();
		niv.getCliente();
		niv.getCodAviso();
		niv.getCodCliente();
		niv.getCodError();
		niv.getIdArchivo();
		niv.getIdentEstatus();
		niv.getIdProducto();
		niv.getListaDetalle();
		niv.getListEstatus();
		niv.getMsgAviso();
		niv.getMsgError();
		
		OperacionArchivoResponse ope = new OperacionArchivoResponse();
		ope.setCtaAbono(null);
		ope.setCtaCargo(null);
		ope.setFchEnvioBE(null);
		ope.setFchRespuestaBE(null);
		ope.setFechaAplic(null);
		ope.setIdArch(null);
		ope.setIdCliente(null);
		ope.setIdEst(null);
		ope.setIdProd(null);
		ope.setIdReg(null);
		ope.setImporte(null);
		ope.setImporteFmt(null);
		ope.setNomArch(null);
		ope.setProducto(null);
		ope.setReferenciaBE(null);
		ope.setStatusFin(null);
		ope.setStatusIni(null);
		ope.setStatusOpe(null);
		ope.setUmbr(null);
		
		ope.getCtaAbono();
		ope.getCtaCargo();
		ope.getFchEnvioBE();
		ope.getFchRespuestaBE();
		ope.getFechaAplic();
		ope.getIdArch();
		ope.getIdCliente();
		ope.getIdEst();
		ope.getIdProd();
		ope.getIdReg();
		ope.getImporte();
		ope.getImporteFmt();
		ope.getNomArch();
		ope.getProducto();
		ope.getReferenciaBE();
		ope.getStatusFin();
		ope.getStatusIni();
		ope.getStatusOpe();
		ope.getUmbr();
		
	}

	@Test
	void toStringTest() {
		String response = MonitorSaldosResponse.builder().toString();
		assertNotNull(response);
	}
}