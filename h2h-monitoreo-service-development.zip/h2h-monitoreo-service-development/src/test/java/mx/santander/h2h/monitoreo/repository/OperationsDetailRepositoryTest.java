package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.response.OperationsHistoryResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.util.UtilsTramaAdicionales;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.*;

class OperationsDetailRepositoryTest {
	@Mock
	EntityManager entityManager;
	@Mock
	Logger log;
	@InjectMocks
	OperationsDetailRepository repository;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
		repository = spy(repository);
	}

	@Test
	void testObtenerDetalleOperacion() {
		doReturn("").when(repository).getH2HMensaje(any());
		doReturn("").when(repository).generaConsultaDetalleOperacion(any(),any());

		Tuple tuple = mock(Tuple.class);
		when(tuple.get((String) any())).then(answer -> {
			String s = answer.getArgument(0);
			if ("IMPORTE".equals(s) || "IMPORTE_CARGO".equals(s))
				return "0";
			return s;
		});

		Query query = mock(Query.class);
		when(query.getResultList()).thenReturn(Collections.singletonList(tuple));

		when(entityManager.createNativeQuery(any(), (Class<?>) any())).thenReturn(query);

		OperationsMonitorQueryResponse result = repository.obtenerDetalleOperacion("01", "idOperacion");
		Assertions.assertNotEquals("OPERACION_EN_PROCESO", result.getProducto());

		result = repository.obtenerDetalleOperacion("00", "idOperacion");

	}

	@Test
	void testValidarProductoConHorario() {
		Map<String, Object> row = Collections.singletonMap("HORA_APLI", "HORA_APLI");

		OperationsMonitorQueryResponse response = new OperationsMonitorQueryResponse();
		repository.validarProductoConHorario("02", response, row);
		Assertions.assertEquals("HORA_APLI", response.getHorarioProg());
	}

	@Test
	void testObtenerHistorialOperacion() {
		doReturn(ImmutablePair.nullPair()).when(repository).recuperarTablasConsulta(any());

		Tuple tuple = mock(Tuple.class);
		when(tuple.get((String) any())).then(answer -> answer.getArgument(0));

		Query query = mock(Query.class);
		when(query.getResultList()).thenReturn(Collections.singletonList(tuple));

		when(entityManager.createNativeQuery(any(), (Class<?>) any())).thenReturn(query);

		try (MockedStatic<UtilsTramaAdicionales> utilsTramaAdicionales = mockStatic(UtilsTramaAdicionales.class)) {
			List<OperationsHistoryResponse> result = repository.obtenerHistorialOperacion("idOperacion");
			Assertions.assertEquals(1, result.size());
			Assertions.assertEquals("ESTATUS", result.get(0).getEstatus());
			Assertions.assertEquals("FECHA", result.get(0).getFecha());
			Assertions.assertEquals("HORA", result.get(0).getHora());
			Assertions.assertEquals("idOperacion", result.get(0).getRefOper());
		}
	}

	@Test
	void testRecuperarTablasConsulta() {
		Tuple tuple = mock(Tuple.class);
		when(tuple.get((String) any())).then(answer -> answer.getArgument(0));

		Query query = mock(Query.class);
		when(query.getResultList()).thenReturn(Collections.singletonList(tuple));

		when(entityManager.createNativeQuery(any(), (Class<?>) any())).thenReturn(query);

		try (MockedStatic<UtilsTramaAdicionales> utilsTramaAdicionales = mockStatic(UtilsTramaAdicionales.class)) {
			utilsTramaAdicionales.when(() -> UtilsTramaAdicionales.recuperaRespuesta(any()))
					.thenReturn(ImmutablePair.nullPair());

			Pair<String, String> result = repository.recuperarTablasConsulta("idOperacion");
			Assertions.assertEquals(ImmutablePair.nullPair(), result);

			doReturn(Collections.emptyList()).when(query).getResultList();
			result = repository.recuperarTablasConsulta("idOperacion");
			Assertions.assertEquals(ImmutablePair.of("H2H_BITA_REG_TRAN", "H2H_BITA_REG"), result);
		}
	}

	@Test
	void testCambiarEstatusOperacion() {
		Query query = mock(Query.class);
		when(query.executeUpdate()).thenReturn(1);

		when(entityManager.createNativeQuery(any())).thenReturn(query);

		boolean result = repository.cambiarEstatusOperacion("idOperacion", "estatus", "H2H_REG_TRAN");
		Assertions.assertEquals(true, result);

		result = repository.cambiarEstatusOperacion("idOperacion", "PROCESADO", "H2H_REG");
		Assertions.assertEquals(true, result);

		result = repository.cambiarEstatusOperacion("idOperacion", "REPROCESAR", "H2H_MX_PROD_SPID_TRAN");
		Assertions.assertEquals(true, result);
	}

	@Test
	void testConsultarHorario() {
		Tuple tuple = mock(Tuple.class);
		when(tuple.get((String) any())).then(answer -> answer.getArgument(0));

		Query query = mock(Query.class);
		when(query.getResultList()).thenReturn(Collections.singletonList(tuple));

		when(entityManager.createNativeQuery(any(), (Class<?>) any())).thenReturn(query);

		boolean result = repository.consultarHorario("producto");
		Assertions.assertEquals(true, result);
	}

	@Test
	void testGeneraConsultaDetalleOperacion() {
		doReturn("").when(repository).getConsultaByProducto(any(), anyBoolean());

		String result = repository.generaConsultaDetalleOperacion("view","12");
		Assertions.assertNotNull(result);
	}

	@Test
	void testGetConsultaByProducto() {
		for (String cveOperProd : Arrays.asList("1", "41", "97", "47", "2", "42", "0")) {
			String result = repository.getConsultaByProducto(cveOperProd, true);
			Assertions.assertNotNull(result);
		}
	}

	@Test
	void testGetH2HMensaje() {
		Tuple tuple = mock(Tuple.class);
		when(tuple.get((String) any())).then(answer -> answer.getArgument(0));

		Query query = mock(Query.class);
		when(query.getResultList()).thenReturn(Collections.singletonList(tuple));

		when(entityManager.createNativeQuery(any(), (Class<?>) any())).thenReturn(query);

		String result = repository.getH2HMensaje("idOperacion");
		Assertions.assertEquals("MSG_H2H", result);

		when(query.getResultList()).thenReturn(Collections.emptyList());
		result = repository.getH2HMensaje("idOperacion");
		Assertions.assertNull(result);
	}

	@Test
	void listaHorarios() {
		Tuple tuple = mock(Tuple.class);
		when(tuple.get((String) any())).then(answer -> answer.getArgument(0));

		Query query = mock(Query.class);
		when(query.getResultList()).thenReturn(Collections.singletonList(tuple));

		when(entityManager.createNativeQuery(any(), (Class<?>) any())).thenReturn(query);

		when(entityManager.createNativeQuery(any(), (Class<?>) any())).thenReturn(query);

		repository.listaHorarios("29");
		Assertions.assertTrue(true);
	}

}
