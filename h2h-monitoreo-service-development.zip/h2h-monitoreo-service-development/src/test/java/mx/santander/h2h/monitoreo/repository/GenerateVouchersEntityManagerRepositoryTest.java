package mx.santander.h2h.monitoreo.repository;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersDtoResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.util.IGenerateVouchersRepositoryUtil;

class GenerateVouchersEntityManagerRepositoryTest {
	@Mock
	private EntityManager entityManager;
	@Mock
	private IGenerateVouchersRepositoryUtil util;
	@InjectMocks
	private GenerateVouchersEntityManagerRepository repository;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testGetListPaymentType() {
		Query query = mock(Query.class);

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);

		List<Object[]> lst = new ArrayList<>();
		Object[] arr = { new BigDecimal(1), "" };
		lst.add(arr);
		when(query.getResultList()).thenReturn(lst);

		GenerateVouchersDtoResponse result = repository.getListPaymentType();
		Assertions.assertNotNull(result);
	}

	@Test
	void testFindOperationsCount() {
		Query query = mock(Query.class);

		when(entityManager.createNativeQuery(anyString(), eq(Tuple.class))).thenReturn(query);

		List<Tuple> lst = new ArrayList<>();
		Tuple tuple = mock(Tuple.class);
		when(tuple.get(anyString())).thenReturn("value");
		lst.add(tuple);
		when(query.getResultList()).thenReturn(lst);

		when(util.getQueryTable(any(), any(), any())).thenReturn(new StringBuilder());

		GenerateVouchersDtoResponse result = repository.findOperationsCount(new OperationsMonitorQueryRequest());
		Assertions.assertNotNull(result);
	}

	@Test
	void testFindOperations() {
		Query query = mock(Query.class);

		when(entityManager.createNativeQuery(anyString(), eq(Tuple.class))).thenReturn(query);

		List<Tuple> lst = new ArrayList<>();
		Tuple data = mock(Tuple.class, RETURNS_DEEP_STUBS);
		lst.add(data);
		when(query.getResultList()).thenReturn(lst);

		when(util.getQueryTable(any(), any(), any())).thenReturn(new StringBuilder());
		when(util.getPaginatedQuery(any(), any())).thenReturn(new StringBuilder());

		List<OperationsMonitorQueryResponse> result = repository.findOperations(new OperationsMonitorQueryRequest());
		Assertions.assertNotNull(result);
	}

	@Test
	void testGetLumpSum() {
		Query query = mock(Query.class);

		when(entityManager.createNativeQuery(anyString(), eq(Tuple.class))).thenReturn(query);

		List<Tuple> lst = new ArrayList<>();
		Tuple tuple = mock(Tuple.class);
		when(tuple.get(anyString())).thenReturn("value");
		lst.add(tuple);
		when(query.getResultList()).thenReturn(lst);

		when(util.getQueryTable(any(), any(), any())).thenReturn(new StringBuilder());

		String result = repository.getLumpSum(new OperationsMonitorQueryRequest());
		Assertions.assertNotNull(result);
	}

	@Test
	void testGetTotalFiles() {
		Query query = mock(Query.class);

		when(entityManager.createNativeQuery(anyString(), eq(Tuple.class))).thenReturn(query);

		List<Tuple> lst = new ArrayList<>();
		Tuple tuple = mock(Tuple.class);
		when(tuple.get(anyString())).thenReturn("value");
		lst.add(tuple);
		when(query.getResultList()).thenReturn(lst);

		when(util.getQueryTable(any(), any(), any())).thenReturn(new StringBuilder());

		String result = repository.getTotalFiles(new OperationsMonitorQueryRequest());
		Assertions.assertNotNull(result);
	}

	@Test
	void testConceptoValor() {
		try {
			Query query = mock(Query.class);

			when(entityManager.createNativeQuery(anyString())).thenReturn(query);

			List<String[]> lst = new ArrayList<>();
			String[] arr = { "" };
			lst.add(arr);
			when(query.getResultList()).thenReturn(lst);

			GenerateVouchersDtoResponse result = repository.conceptoValor(anyString());
			Assertions.assertNotNull(result);
		} catch (Exception e) {
			Assertions.assertTrue(true);
		}
	}

	@Test
	void testConsultaOperacionesExportar() {
		Query query = mock(Query.class);

		when(entityManager.createNativeQuery(anyString(), eq(Tuple.class))).thenReturn(query);

		List<Tuple> lst = new ArrayList<>();
		Tuple tuple = mock(Tuple.class);
		when(tuple.get(anyString())).thenReturn("12");
		lst.add(tuple);
		when(query.getResultList()).thenReturn(lst);

		when(util.getQueryTableExport(any(), any(), any())).thenReturn(new StringBuilder());

		List<OperationsMonitorQueryResponse> result = repository
				.consultaOperacionesExportar(new OperationsMonitorQueryRequest());
		Assertions.assertNotNull(result);
	}

	@Test
	void testRecuperarParamsGenComprobante() {
		Query query = mock(Query.class);

		when(entityManager.createNativeQuery(anyString(), eq(Tuple.class))).thenReturn(query);

		List<Tuple> lst = new ArrayList<>();
		Tuple tuple = mock(Tuple.class);
		when(tuple.get(anyString())).thenReturn("12");
		lst.add(tuple);
		when(query.getResultList()).thenReturn(lst);

		GenerateVouchersDtoResponse result = repository.recuperarParamsGenComprobante();
		Assertions.assertNotNull(result);
	}

}
