package mx.santander.h2h.monitoreo.controller;

import mx.santander.h2h.monitoreo.model.request.NivelArchivoRequest;
import mx.santander.h2h.monitoreo.model.request.NivelProductoRequest;
import mx.santander.h2h.monitoreo.service.IArchivoTrackingBService;
import mx.santander.h2h.monitoreo.service.IArchivoTrackingService;
import mx.santander.h2h.monitoreo.service.IConsultaTrackingProductoService;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Pageable;

class ArchivoTrackingControllerTest {
    
	@Mock
    private IArchivoTrackingService service;
    
    @Mock
    private IArchivoTrackingBService serviceB;
    
    @Mock
    private IConsultaTrackingProductoService consultaTrackingProductoService;
    
    @InjectMocks
    private ArchivoTrackingController archivoTrackingController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
    
    @Test
	void inicio() {
		Assertions.assertNotNull(this.archivoTrackingController.inicio("12345678"));
	}
    
    @Test
	void obtenerDetalleArchivos() {
		Assertions.assertNotNull(this.archivoTrackingController.obtenerDetalleArchivos("12345678", Pageable.ofSize(1)));
	}
    
    @Test
	void getReportXlsDetalleNivelOperacionHist() {
		Assertions.assertNotNull(this.archivoTrackingController.getReportXlsDetalleNivelGeneral("12345678", "Kaori"));
	}
    
    @Test
	void obtenerDetalleArchivos2() {
		Assertions.assertNotNull(this.archivoTrackingController.obtenerDetalleArchivos(nivelArchReq()));
	}
    
    @Test
	void obtenerDetalleArchivoNivelArchivo() {
		Assertions.assertNotNull(this.archivoTrackingController.obtenerDetalleArchivoNivelArchivo(nivelArchReq(), Pageable.ofSize(1)));
	}
    
    @Test
	void getReportXlsDetalleNivelArchivo() {
		Assertions.assertNotNull(this.archivoTrackingController.getReportXlsDetalleNivelArchivo(nivelArchReq(), "Kaori"));
	}
    
    @Test
   	void iniciaNivelProducto() {
   		Assertions.assertNotNull(this.archivoTrackingController.iniciaNivelProducto(nivelProdReq()));
   	}
       
       @Test
   	void obtenerDetalleArchivosNivelProducto() {
   		Assertions.assertNotNull(this.archivoTrackingController.obtenerDetalleArchivosNivelProducto(nivelProdReq(), Pageable.ofSize(1)));
   	}
       
       @Test
   	void getReportXlsDetalleNivelProducto() {
   		Assertions.assertNotNull(this.archivoTrackingController.getReportXlsDetalleNivelProducto(nivelProdReq(), "Kaori"));
   	}
    
    public NivelArchivoRequest nivelArchReq() {
    	NivelArchivoRequest archivoRequest = new NivelArchivoRequest();
    	
    	return archivoRequest;
    }
    
    public NivelProductoRequest nivelProdReq() {
    	NivelProductoRequest nivelProductoRequest = new NivelProductoRequest();
    	return nivelProductoRequest;
    }
    
}
