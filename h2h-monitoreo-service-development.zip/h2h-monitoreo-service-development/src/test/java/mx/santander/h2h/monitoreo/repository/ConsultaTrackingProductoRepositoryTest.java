package mx.santander.h2h.monitoreo.repository;

import static org.mockito.Mockito.when;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;

@ExtendWith(MockitoExtension.class)
class ConsultaTrackingProductoRepositoryTest {
	
	@InjectMocks
	private ConsultaTrackingProductoRepository consultaTrackingProductoRepository;
	
	@Mock
	private EntityManager entityManager;

	@Test
	void obtenerCatalogoProductosTest() {
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		consultaTrackingProductoRepository.obtenerCatalogoProductos();
		Assertions.assertTrue(true);
	}
	
	@Test
	void obtenerCatalogoEstatusTest() {
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		consultaTrackingProductoRepository.obtenerCatalogoEstatus("R");
		Assertions.assertTrue(true);
	}
	
	@Test
	void obtenerConteoArchivoTest() {
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		consultaTrackingProductoRepository.obtenerConteoArchivo("04158057", 74593);
		Assertions.assertTrue(true);
	}
	
	@Test
	void obtenerDetalleArchivoTest() {
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		consultaTrackingProductoRepository.obtenerDetalleArchivo(Pageable.ofSize(1), 74593, 158057, 5);
		Assertions.assertTrue(true);
	}

	@Test
	void obtenerListDetalleArchivoTest() {
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		consultaTrackingProductoRepository.obtenerListDetalleArchivo(74593, 158057, 5);
		Assertions.assertTrue(true);
	}
}
