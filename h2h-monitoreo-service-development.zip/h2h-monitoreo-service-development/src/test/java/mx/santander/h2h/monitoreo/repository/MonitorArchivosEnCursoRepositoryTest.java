package mx.santander.h2h.monitoreo.repository;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import mx.santander.h2h.monitoreo.model.request.MonitorArchivosEnCursoRequest;
import mx.santander.h2h.monitoreo.model.response.MonitorDeArchivosEnCursoDetallesResponse;

class MonitorArchivosEnCursoRepositoryTest {

	@Mock
	private EntityManager entityManager;
	@InjectMocks
	private MonitorArchivosEnCursoRepository repository;
	
	@BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }



	@Test
	void testEjecutaBusquedaNivelProductoStringIntegerInteger() {
		 Query query = mock(Query.class);

	     when(entityManager.createNativeQuery(anyString(), eq(Tuple.class))).thenReturn(query);
	     
	     List<Tuple> lst = new ArrayList<>();
	     Tuple tuple = mock(Tuple.class);
	     when(tuple.get(anyString())).thenReturn("value");
	     when(tuple.get(anyString(), eq(BigDecimal.class))).thenReturn(new BigDecimal(0));
	     lst.add(tuple);
	     when(query.getResultList()).thenReturn(lst);
	     
	     List<MonitorDeArchivosEnCursoDetallesResponse> result = repository.ejecutaBusquedaNivelProducto("", 1, 1);
	     Assertions.assertNotNull(result);
	}
	
//	@Test
//	void testejecutaBusquedaArchivosEnCurso() {
//		 Query query = mock(Query.class);
//	     when(entityManager.createNativeQuery(anyString(), eq(Tuple.class))).thenReturn(query);
//	     
//	     List<Tuple> lst = new ArrayList<>();
//	     Tuple tuple = mock(Tuple.class);
//	     when(tuple.get(anyString())).thenReturn("value");
//	     when(tuple.get(anyString(), eq(BigDecimal.class))).thenReturn(new BigDecimal(0));
//	     lst.add(tuple);
//	     when(query.getResultList()).thenReturn(lst);
//	     MonitorArchivosEnCursoRequest r = new MonitorArchivosEnCursoRequest();
//	     r.setBuc("test");
//	     r.setCodCliente("59786498");
//	     r.setPagina("2");
//	     r.setTamanioPagina("12");
//	     List<MonitorDeArchivosEnCursoDetallesResponse> result = new ArrayList<>();
//	     MonitorDeArchivosEnCursoDetallesResponse rs = new MonitorDeArchivosEnCursoDetallesResponse();
//	     rs.setBuc("398173");
//	     rs.setIdArchivo("12");
//	     result.add(rs);
//	     
//	     result = repository.ejecutaBusquedaArchivosEnCurso(r);
//	     Assertions.assertNotNull(result);
//	}
	
	@Test
	void test() {
		MonitorArchivosEnCursoRequest r = new MonitorArchivosEnCursoRequest();
	    r.setBuc("test");
	    r.setCodCliente("59786498");
	    r.setPagina("2");
	    r.setTamanioPagina("12");
	    List<MonitorDeArchivosEnCursoDetallesResponse> result = new ArrayList<>();
	    MonitorDeArchivosEnCursoDetallesResponse rs = new MonitorDeArchivosEnCursoDetallesResponse();
	    rs.setBuc("398173");
	    rs.setIdArchivo("1");
	    result.add(rs);
		repository.mapResultToResponseList(result, 1);
		Assertions.assertNotNull(rs);
	}
	
	@Test
	void test1() {
		Map<String, Object> params = new HashMap<>();
		MonitorArchivosEnCursoRequest r = new MonitorArchivosEnCursoRequest();
	    r.setBuc("test");
	    r.setCodCliente("59786498");
	    r.setPagina("2");
	    r.setTamanioPagina("12");
	    r.setFechaIni("2025-03-01");
	    r.setFechaFin("2025-06-01");
	    StringBuilder rs = new StringBuilder();
	    rs.append("SELECT * FROM ( ");
		repository.completaWhere(rs, r, params);
		Assertions.assertNotNull(r);
	}

}
