package mx.santander.h2h.monitoreo.util;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import jakarta.persistence.Tuple;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import mx.santander.h2h.monitoreo.exception.commons.BusinessException;

class UtilsTramaAdicionalesTest {

    @Test
    void testGenerarListaCPA() {
        List<Pair<String, String>> result = UtilsTramaAdicionales.generarListaCPA("a|b");
        Assertions.assertEquals(Collections.singletonList(ImmutablePair.of("a", "b")), result);
    }

    @Test
    void testGeneraConsultaHistorialOperacion() {
        String result = UtilsTramaAdicionales.generaConsultaHistorialOperacion("tabla1", "tabla2");
        Assertions.assertNotNull(result);
    }

    @Test
    void testGetFecha() {
        String result = UtilsTramaAdicionales.getFecha("02/02/2020");
        Assertions.assertEquals("02/02/2020", result);

        result = UtilsTramaAdicionales.getFecha(
                Timestamp.valueOf(LocalDate.of(2020, 2, 2).atStartOfDay())
        );
        Assertions.assertEquals("02/02/2020", result);
    }

    @Test
    void testGetConsultaProdructoUtils() {
        for (int cveOperProd : Arrays.asList(1, 41, 97, 47, 2, 42, 44)) {
            String result = UtilsTramaAdicionales.getConsultaProdructoUtils(cveOperProd);
            Assertions.assertNotNull(result);
        }
    }

    @Test
    void testGetConsultaProdructo80819596Utils() {
        for (int cveOperProd : Arrays.asList(80, 81, 95, 96, 99)) {
            String result = UtilsTramaAdicionales.getConsultaProdructo80819596Utils(cveOperProd);
            Assertions.assertNotNull(result);
        }
    }

    @Test
    void testGetConsultaProdructo489899493691135Utils() {
        for (int cveOperProd : Arrays.asList(48, 98, 99, 49, 36, 91, 135, 1)) {
            String result = UtilsTramaAdicionales.getConsultaProdructo489899493691135Utils(cveOperProd);
            Assertions.assertNotNull(result);
        }
    }

    @Test
    void testGetConsultaProdructo9354Utils() {
        for (int cveOperProd : Arrays.asList(93, 54, 1)) {
            String result = UtilsTramaAdicionales.getConsultaProdructo9354Utils(cveOperProd);
            Assertions.assertNotNull(result);
        }
    }

    @Test
    void testArmadoTramaSegundaParte() {
        for (int cveOperProd : Arrays.asList(95, 96, 98, 48, 99, 49, 36, 1)) {
            String result = UtilsTramaAdicionales.armadoTramaSegundaParte(cveOperProd);
            Assertions.assertNotNull(result);
        }
    }

    @Test
    void testRecuperaRespuesta() {
        Tuple tuple = Mockito.mock(Tuple.class);
        Mockito.when(tuple.get("ID_OPER_ONL")).thenReturn("ID_OPER_ONL");

        Pair<String, String> result = UtilsTramaAdicionales.recuperaRespuesta(
                Arrays.asList("", Mockito.mock(Tuple.class), tuple)
        );
        Assertions.assertEquals(ImmutablePair.of("h2h_bita_reg_online_tran", "h2h_bita_reg_online"), result);
    }

    @Test
    void testCleanTable() {
        List<String> tables = Arrays.asList(
                "H2H_REG_TRAN", "H2H_REG",
                "H2H_MX_PROD_SPID_TRAN", "H2H_MX_PROD_SPID",
                "H2H_PROD_DOMI_TRAN", "H2H_PROD_DOMI"
        );

        for (String table : tables) {
            String result = UtilsTramaAdicionalesAux.cleanTable(table);
            Assertions.assertEquals(table, result);
        }

        Assertions.assertThrows(BusinessException.class, () -> UtilsTramaAdicionalesAux.cleanTable(""));
    }

}
