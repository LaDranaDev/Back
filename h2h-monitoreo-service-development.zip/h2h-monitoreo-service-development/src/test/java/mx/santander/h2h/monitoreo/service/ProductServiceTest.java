package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.model.entity.ProductEntity;
import mx.santander.h2h.monitoreo.repository.IProductRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProductServiceTest {

    @Mock
    private IProductRepository productRepository;

    @InjectMocks
    private ProductService productService;

    @Test
    void getProductos() {
        List<ProductEntity> productEntities = new ArrayList<>();
        productEntities.add(mock(ProductEntity.class));

        when(productRepository.findProductos()).thenReturn(productEntities);

        productService.getProductos();

        verify(productRepository).findProductos();
    }
    
    @Test
    void getProductoByClave() {
        when(productRepository.findByCveProdOper(anyString())).thenReturn(mock(ProductEntity.class));

        productService.getProductoByClave("001");

        verify(productRepository).findByCveProdOper("001");
    }
}