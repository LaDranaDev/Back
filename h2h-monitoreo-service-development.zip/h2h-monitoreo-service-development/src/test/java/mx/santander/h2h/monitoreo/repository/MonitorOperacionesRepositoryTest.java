package mx.santander.h2h.monitoreo.repository;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;

@ExtendWith(MockitoExtension.class)
class MonitorOperacionesRepositoryTest {
	@InjectMocks
    private MonitorOperacionesRepository repository;
    
	@Mock
	private StringBuilder query;
	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testPreparaConsultaOperaciones() {
		OperationsMonitorQueryRequest consOperaciones = new OperationsMonitorQueryRequest();
		consOperaciones.setFechaInicial("02/02/2024");
		consOperaciones.setFechaFinal("12/02/2024");
		query = new StringBuilder();
		query.append("SELECT ");
		Map<String, Object> params = new HashMap<>();
		
		MonitorOperacionesRepository.preparaConsultaOperaciones(consOperaciones, query, params);
		assertNotNull(params);
		
		consOperaciones = getData();
		MonitorOperacionesRepository.preparaConsultaOperaciones(consOperaciones, query, params);
		assertNotNull(params);
	}

	
	private OperationsMonitorQueryRequest getData() {
		OperationsMonitorQueryRequest consOperacion = new OperationsMonitorQueryRequest();
		consOperacion.setFechaInicial("27/09/2024");
		consOperacion.setFechaFinal("31/09/2024");
		consOperacion.setBuc("12345");
		consOperacion.setContrato("09876542345");
		consOperacion.setNombreArchivo("TEST.com");
		consOperacion.setIdProducto("1");
		consOperacion.setIdEstatus("A");
		consOperacion.setCuentaCargo("12354768");
		consOperacion.setCuentaAbono("52453787");
		consOperacion.setImporte("10.00");
		consOperacion.setReferencia("5643");
		consOperacion.setDivisa("MXN");
		consOperacion.setNumeroOrden("3254");
		consOperacion.setNombreBeneficiario("TEST TEST");
		consOperacion.setIdReg("101");
		consOperacion.setNumEmpleado("56245");
		consOperacion.setNumTarjeta("264573567");
		consOperacion.setSucTutora("356");
		consOperacion.setLineaCaptura("56735835245624562456");
		consOperacion.setConvenio("5234");
		consOperacion.setFolioSUA("25");
		consOperacion.setRegPat("134");
		
		return consOperacion;
	}
}
