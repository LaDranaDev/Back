package mx.santander.h2h.monitoreo.model.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
class ArchivoEntityTest {

    private ArchivoEntity archivoEntity;

    @BeforeEach
    void setUp(){
        archivoEntity = new ArchivoEntity();
    }

    @Test
    void getIdArchivo() {
        archivoEntity.setIdArchivo(123L);
        assertEquals(123L, archivoEntity.getIdArchivo());
    }

    @Test
    void getNombreArchivo() {
        archivoEntity.setNombreArchivo("nombreArchivo");
        assertEquals("nombreArchivo", archivoEntity.getNombreArchivo());
    }

    @Test
    void getIdLayout() {
        archivoEntity.setIdLayout(123L);
        assertEquals(123L, archivoEntity.getIdLayout());
    }

    @Test
    void getIdStatus() {
        archivoEntity.setIdStatus(123L);
        assertEquals(123L, archivoEntity.getIdStatus());
    }

    @Test
    void getContractEntity() {
        ContractEntity contractEntity = mock(ContractEntity.class);
        archivoEntity.setContractEntity(contractEntity);
        assertEquals(contractEntity, archivoEntity.getContractEntity());
    }

    @Test
    void getTamano() {
        archivoEntity.setTamano(123L);
        assertEquals(123L, archivoEntity.getTamano());
    }

    @Test
    void getBandEnrollment() {
        archivoEntity.setBandEnrollment('A');
        assertEquals('A', archivoEntity.getBandEnrollment());
    }

    @Test
    void getFechaRegistro() {
        LocalDate date = LocalDate.parse("2023-04-19");
        archivoEntity.setFechaRegistro(date);
        assertEquals(date, archivoEntity.getFechaRegistro());
    }

    @Test
    void getTotoalProductos() {
        archivoEntity.setTotoalProductos(123);
        assertEquals(123, archivoEntity.getTotoalProductos());
    }

    @Test
    void getBandFondeo() {
        archivoEntity.setBandFondeo('T');
        assertEquals('T', archivoEntity.getBandFondeo());
    }

    @Test
    void getIdCanal() {
        archivoEntity.setIdCanal(123);
        assertEquals(123, archivoEntity.getIdCanal());
    }

    @Test
    void getIdCatProcesamiento() {
        archivoEntity.setIdCatProcesamiento(123L);
        assertEquals(123L, archivoEntity.getIdCatProcesamiento());
    }

    @Test
    void getIdProcesoRegistro() {
        archivoEntity.setIdProcesoRegistro(123L);
        assertEquals(123L, archivoEntity.getIdProcesoRegistro());
    }

    @Test
    void getBandCierre() {
        archivoEntity.setBandCierre('A');
        assertEquals('A', archivoEntity.getBandCierre());
    }

    @Test
    void getBandCifrado() {
        archivoEntity.setBandCifrado('A');
        assertEquals('A', archivoEntity.getBandCifrado());
    }

    @Test
    void getTotalOperaciones() {
        archivoEntity.setTotalOperaciones(123);
        assertEquals(123, archivoEntity.getTotalOperaciones());
    }

    @Test
    void getTotalMonto() {
        archivoEntity.setTotalMonto(BigDecimal.ZERO);
        assertEquals(BigDecimal.ZERO, archivoEntity.getTotalMonto());
    }

    @Test
    void getMbxMsgId() {
        archivoEntity.setMbxMsgId(123);
        assertEquals(123, archivoEntity.getMbxMsgId());
    }

    @Test
    void getNotMsgId() {
        archivoEntity.setNotMsgId(123);
        assertEquals(123, archivoEntity.getNotMsgId());
    }

    @Test
    void getBandDispWeb() {
        archivoEntity.setBandDispWeb('N');
        assertEquals('N', archivoEntity.getBandDispWeb());
    }

    @Test
    void getIdMensaje() {
        archivoEntity.setIdMensaje(123);
        assertEquals(123, archivoEntity.getIdMensaje());
    }

    @Test
    void getBandDispWebClte() {
        archivoEntity.setBandDispWebClte('N');
        assertEquals('N', archivoEntity.getBandDispWebClte());
    }

    @Test
    void getDivisa() {
        archivoEntity.setDivisa('T');
        assertEquals('T', archivoEntity.getDivisa());
    }

    @Test
    void getNumSerieCert() {
        archivoEntity.setNumSerieCert("1234");
        assertEquals("1234", archivoEntity.getNumSerieCert());
    }

    @Test
    void getHashCifrado() {
        archivoEntity.setHashCifrado("hashArchivo");
        assertEquals("hashArchivo", archivoEntity.getHashCifrado());
    }

    @Test
    void getHashArchivo() {
        archivoEntity.setHashArchivo("hashArchivo");
        assertEquals("hashArchivo", archivoEntity.getHashArchivo());
    }

    @Test
    void getMbxMsgIdCifr() {
        archivoEntity.setMbxMsgIdCifr(123);
        assertEquals(123, archivoEntity.getMbxMsgIdCifr());
    }

    @Test
    void getMotivoRechDupl() {
        archivoEntity.setMotivoRechDupl("motivo");
        assertEquals("motivo", archivoEntity.getMotivoRechDupl());
    }

    @Test
    void getIdArchDupl() {
        archivoEntity.setIdArchDupl(123);
        assertEquals(123, archivoEntity.getIdArchDupl());
    }

    @Test
    void getEncodingArchivo() {
        archivoEntity.setEncodingArchivo("UTF-8");
        assertEquals("UTF-8", archivoEntity.getEncodingArchivo());
    }
}