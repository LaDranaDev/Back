package mx.santander.h2h.monitoreo.repository;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import mx.santander.h2h.monitoreo.model.response.ContractResponse;
import mx.santander.h2h.monitoreo.model.response.ParametersGetPutResponse;

class ContractConnectionManagementProtocolsEntityManagerRepositoryTest {
	@Mock
	private EntityManager entityManager;
	@Mock
	private IContractConnectionManagementEntityManagerRepository repo;
	@InjectMocks
	private ContractConnectionManagementProtocolsEntityManagerRepository repository;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testFindContractConnectionByContractNumber() {
		Query query = mock(Query.class);

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);

		List<Object[]> lst = new ArrayList<>();
		Object[] arr = {"","QWERT","","","","","","1","","","","","","","","","" };
		lst.add(arr);
		when(query.getResultList()).thenReturn(lst);

		List<ContractResponse> result = repository.findContractConnectionByContractNumber("");
		Assertions.assertNotNull(result);
	}

	@Test
	void testFindContractIdProtocol() {
		Query query = mock(Query.class);

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);

		List<BigDecimal> lst = new ArrayList<>();
		lst.add(new BigDecimal(1));
		when(query.getResultList()).thenReturn(lst);

		Integer result = repository.findContractIdProtocol(0);
		Assertions.assertNotNull(result);
	}

	@Test
	void testFindContractParametersGetPut() {
		Query query = mock(Query.class);

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);

		List<Object[]> lst = new ArrayList<>();
		Object[] arr = {"","QWERT","","","","","","1","","","","1",""};
		lst.add(arr);
		when(query.getResultList()).thenReturn(lst);

		List<ParametersGetPutResponse> result = repository.findContractParametersGetPut(0,0,"");
		Assertions.assertNotNull(result);
	}

	@Test
	void testFindParametersNameInProtocol() {
		Query query = mock(Query.class);

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);

		List<String> lst = new ArrayList<>();
		lst.add("A");
		when(query.getResultList()).thenReturn(lst);

		List<String> result = repository.findParametersNameInProtocol(0);
		Assertions.assertNotNull(result);
	}

	@Test
	void testUpdateRegistrationStatus() {
		Query query = mock(Query.class);

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);
		
		repository.updateRegistrationStatus(0, "", "");
		
		Assertions.assertTrue(true);
		
	}

}
