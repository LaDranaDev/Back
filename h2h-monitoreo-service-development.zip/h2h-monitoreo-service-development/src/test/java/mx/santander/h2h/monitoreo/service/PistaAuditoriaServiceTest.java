package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.model.request.PistaAuditoriaRequest;
import mx.santander.pid.logadapter.core.types.service.LogAdapterAuditService;
import mx.santander.pid.logadapter.core.types.service.LogAdapterBusinessService;
import mx.santander.pid.logadapter.exception.LogAdapterException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class PistaAuditoriaServiceTest {
	
	@InjectMocks
    PistaAuditoriaService auditoriaService;
	
	@Mock
	LogAdapterAuditService auditService;
	
	@Mock
	LogAdapterBusinessService businessService;
	
	@Test
	void registrarTest() {
		this.auditoriaService.registrarPista(getPistaAuditoriaRequest());
		Assertions.assertTrue(true);
	}
	
	@Test
	void registrarErrorTest() {
		try {
			Mockito.doThrow(Mockito.mock(LogAdapterException.class)).when(this.businessService).bitacoriza(
					Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
					Mockito.anyString());
			this.auditoriaService.registrarPista(getPistaAuditoriaRequest());
		} catch (Exception e) {
			Assertions.assertNotNull(e);
		}
	}
	
	private PistaAuditoriaRequest getPistaAuditoriaRequest() {
		PistaAuditoriaRequest pistaAuditoriaRequest = new PistaAuditoriaRequest();
		pistaAuditoriaRequest.setCodigoOperacion("000");
		pistaAuditoriaRequest.setInfoAdicional("info");
		pistaAuditoriaRequest.setMensaje("mensaje");
		pistaAuditoriaRequest.setNombre("nombre");
		pistaAuditoriaRequest.setResultado("resultado");

		pistaAuditoriaRequest.getCodigoOperacion();
		pistaAuditoriaRequest.getInfoAdicional();
		pistaAuditoriaRequest.getMensaje();
		pistaAuditoriaRequest.getNombre();
		pistaAuditoriaRequest.getResultado();

		new PistaAuditoriaRequest("", "", "", "", "");
		pistaAuditoriaRequest.toString();
		return pistaAuditoriaRequest;
	}
}
