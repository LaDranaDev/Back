package mx.santander.h2h.monitoreo.repository;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.util.UtilData;


class OperationsMonitorEntityManagerHelper3RepositoryTest {

    @Mock
    Logger log;

    @InjectMocks
    OperationsMonitorEntityManagerHelper3Repository operationsMonitorEntityManagerHelper3Repository;

    private static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

    
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    
    @Test
    void testGetFecha() throws ParseException {
        String dateString = "02/02/2020";
        Date date = sdf.parse(dateString);
        Timestamp ts = new Timestamp(date.getTime());

        String result = OperationsMonitorEntityManagerHelper3Repository.getFecha(ts);
        Assertions.assertEquals(dateString, result);

        result = OperationsMonitorEntityManagerHelper3Repository.getFecha(dateString);
        Assertions.assertEquals(dateString, result);
    }

    
    @Test
    void testIsOrdenPago() {
        OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();
        consultaOperaciones.setIdProducto("81");
        boolean result = OperationsMonitorEntityManagerHelper3Repository.isOrdenPago(consultaOperaciones);
        Assertions.assertTrue(result);
    }

    
    @Test
    void testIsAltaMasivaEmpleados() {
        OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();
        consultaOperaciones.setIdProducto("93");
        boolean result = OperationsMonitorEntityManagerHelper3Repository.isAltaMasivaEmpleados(consultaOperaciones);
        Assertions.assertTrue(result);
    }

    
    @Test
    void testIsDateToday() {
        String date = sdf.format(new Date());
        boolean result = OperationsMonitorEntityManagerHelper3Repository.isDateToday(date);
        Assertions.assertTrue(result);
    }

    
    @Test
    void testIsPif() {
        OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();
        consultaOperaciones.setIdProducto("23");
        boolean result = UtilData.isPif(consultaOperaciones.getIdProducto());
        Assertions.assertTrue(result);
    }
    
    
    @Test
    void testIsTI() {
        OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();
        consultaOperaciones.setIdProducto("31");
        boolean result = OperationsMonitorEntityManagerHelper3Repository.isTI(consultaOperaciones);
        Assertions.assertTrue(result);
    }
    
    
    @Test
    void testIsPagoDirecto() {
        OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();
        consultaOperaciones.setIdProducto("40");
        boolean result = UtilData.isPagoDirecto(consultaOperaciones.getIdProducto());
        Assertions.assertTrue(result);
    }
    
    
    @Test
    void testValidatePif() {
    	Map<String, Object> params = new HashMap<String, Object>();
    	StringBuilder query = new StringBuilder();
		
        OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();
        consultaOperaciones.setLineaCaptura("ads");
        consultaOperaciones.setConvenio("ada");
        consultaOperaciones.setFolioSUA("asda");
        consultaOperaciones.setRegPat("asdasd");
        consultaOperaciones.setIdProducto("21");
        
        OperationsMonitorEntityManagerHelper3Repository.validatePif(consultaOperaciones, query, params, false); 
        if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}
    }
    
    
    @Test
    void testValidatePifExport() {
    	Map<String, Object> params = new HashMap<String, Object>();
    	StringBuilder query = new StringBuilder();
		
    	OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();
        
        consultaOperaciones.setLineaCaptura("ads");
        consultaOperaciones.setConvenio("ada");
        consultaOperaciones.setFolioSUA("asda");
        consultaOperaciones.setRegPat("asdasd");
        consultaOperaciones.setIdProducto("23");
        consultaOperaciones.setEsLiquidaciones(true);
        consultaOperaciones.setHoraProgramacion("4654");;
        
        OperationsMonitorEntityManagerHelper3Repository.validatePif(consultaOperaciones, query, params, true); 
        if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}
    }
}
