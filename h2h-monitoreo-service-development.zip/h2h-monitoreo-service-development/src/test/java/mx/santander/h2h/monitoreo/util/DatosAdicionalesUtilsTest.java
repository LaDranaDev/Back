package mx.santander.h2h.monitoreo.util;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import mx.santander.h2h.monitoreo.model.response.GenerateVouchersDtoResponse;
import mx.santander.h2h.monitoreo.model.response.VoucherRequestDto;


@ExtendWith(MockitoExtension.class)
class DatosAdicionalesUtilsTest {

	@InjectMocks
	private DatosAdicionalesUtils datAdicional;
	
	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testValidaTramaAdicionales() {
		GenerateVouchersDtoResponse bean = new GenerateVouchersDtoResponse();
		VoucherRequestDto beanCdmx = new VoucherRequestDto();
		beanCdmx.setBase64("testbase64");
		beanCdmx.setCanalOperacion(101);
		beanCdmx.setFecha("03/10/2024");
		beanCdmx.setIdReg("0001");
		bean.setCdmxBean( beanCdmx );
		
		boolean resp = DatosAdicionalesUtils.validaTramaAdicionales(bean);
		assertFalse(resp);
		
		beanCdmx.setTramaAdicionalesEntrada("tramaadicional");
		bean.setCdmxBean(beanCdmx);
		
		resp = DatosAdicionalesUtils.validaTramaAdicionales(bean);
		assertTrue(resp);
	}

	@Test
	void testAdicionalesRequeridos() {
		boolean resp = DatosAdicionalesUtils.adicionalesRequeridos("", 0);
		assertTrue(resp);
		
		resp = DatosAdicionalesUtils.adicionalesRequeridos("", 10);
		assertFalse(resp);
		
		resp = DatosAdicionalesUtils.adicionalesRequeridos("TEST", 0);
		assertTrue(resp);
		
		resp = DatosAdicionalesUtils.adicionalesRequeridos("TEST", 10);
		assertTrue(resp);
	}

	@Test
	void testActualizacionBDRequerida() {
		boolean resp = DatosAdicionalesUtils.actualizacionBDRequerida("", 0);
		assertFalse(resp);
		
		resp = DatosAdicionalesUtils.actualizacionBDRequerida("", 10);
		assertFalse(resp);
		
		resp = DatosAdicionalesUtils.actualizacionBDRequerida("TEST", 0);
		assertFalse(resp);
		
		resp = DatosAdicionalesUtils.actualizacionBDRequerida("TEST", 10);
		assertTrue(resp);
	}

}
