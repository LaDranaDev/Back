package mx.santander.h2h.monitoreo.model.response;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import mx.santander.h2h.monitoreo.util.JavaBeanTester;

/**
 * GeneralResponseTest.
 *
 * @author Jesus Soto Aguilar
 * @since 04/05/2023
 */
class GeneralResponseTest {

	@Test
	void testFields() {
		assertDoesNotThrow(() -> JavaBeanTester.test(GeneralResponse.class));
		NivelArchivoResponse response = new NivelArchivoResponse();
		response.setBeanArchivo(null);
		response.setBeanArchivoDetalle(null);
		response.setCodCliente(null);
		response.setEstatus(0);
		response.setFecha(null);
		response.setListBeanArchivo(null);
		response.setNombreArchivo(null);
		response.setNombreCliente(null);
		
		response.getBeanArchivo();
		response.getBeanArchivoDetalle();
		response.getCodCliente();
		response.getEstatus();
		response.getFecha();
		response.getListBeanArchivo();
		response.getNombreArchivo();
		response.getNombreCliente();
	}

	@Test
	void builderToStringTest() {
		GeneralResponse response = new GeneralResponse();
		response = new GeneralResponse(null, null);
		response.toString();
		
		MonitorProdOperacionesCompResponse mon = new MonitorProdOperacionesCompResponse();
		mon.getAduana();
		mon.getBancoOrdenante();
		mon.getBancoReceptor();
		mon.getBucEmpleado();
		mon.getCanal();
		mon.getCodCli();
		mon.getCodRegistro();
		mon.getComentario1();
		mon.getComentario2();
		mon.getComentario3();
		mon.getCtaAbono();
		mon.getCtaCargo();
		mon.getCveProveedor();
		mon.getDescError();
		mon.getDescripcion();
		mon.getDivisa();
		mon.getDivisaOrd();
		mon.getEstatus();
		mon.getFechaAplic();
		mon.getFechaCaptura();
		mon.getFechaFin();
		mon.getFechaIni();
		mon.getFechaLimitPago();
		mon.getFechaOper();
		mon.getFechaPresIni();
		mon.getFechaVenc();
		mon.getHorarioProg();
		mon.getIdCliente();
		mon.getIdEstatus();
		mon.getIdMensaje();
		mon.getIdOperacion();
		mon.getIdProducto();
		mon.getImporte();
		mon.getImporteCargo();
		mon.getImporteSinFormato();
		mon.getIntermOrd();
		mon.getIntermRec();
		mon.getLineaCaptura();
		mon.getMensaje();
		mon.getMensajeOrden();
		mon.getModalidad();
		mon.getNomArch();
		mon.getNombreBenef();
		mon.getNombreEmpleado();
		mon.getNombreOrd();
		mon.getNomProveedor();
		mon.getNumeMovil();
		mon.getNumEmpleado();
		mon.getNumeroCuenta();
		mon.getNumFolio();
		mon.getNumOrden();
		mon.getNumSucursal();
		mon.getNumTarjeta();
		mon.getNumTarjetaAct();
		mon.getPatente();
		mon.getPedimento();
		mon.getProducto();
		mon.getReferencia();
		mon.getReferenciaAbono();
		mon.getReferenciaCargo();
		mon.getRfc();
		mon.getSucTutora();
		mon.getTabla();
		mon.getTipoOperacion();
		mon.getTipoPago();
		mon.getTipoPerJuridica();
		mon.getTransSat();
		mon.getVistProd();
		Assertions.assertTrue(true);
	}
}