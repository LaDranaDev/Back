package mx.santander.h2h.monitoreo.repository;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import java.math.BigDecimal;
import java.util.Arrays;

import static org.mockito.Mockito.*;

class ArchivoEntityManagerRepositoryTest {
    @Mock
    EntityManager entityManager;
    @InjectMocks
    ArchivoEntityManagerRepository archivoEntityManagerRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testDetalleArchivos() {
        Query query = mock(Query.class);
        when(entityManager.createNativeQuery(any(), (Class<?>) any())).thenReturn(query);

        Tuple tuple1 = mock(Tuple.class);
        when(tuple1.get(any(), any())).then(answer -> {
            String param = answer.getArgument(0, String.class);
            if ("ID_ARCHIVO".equals(param)) return BigDecimal.ONE;
            Class<?> class_ = answer.getArgument(1, Class.class);
            return BigDecimal.class.equals(class_) ? BigDecimal.ZERO : class_.newInstance();
        });

        Tuple tuple2 = mock(Tuple.class);
        when(tuple2.get(any(), any())).then(answer -> {
            String param = answer.getArgument(0, String.class);
            if ("ID_ARCHIVO".equals(param)) return BigDecimal.TEN;
            if ("ID_ESTATUS".equals(param)) return BigDecimal.valueOf(16);
            Class<?> class_ = answer.getArgument(1, Class.class);
            return BigDecimal.class.equals(class_) ? BigDecimal.ZERO : class_.newInstance();
        });

        when(query.getResultList()).thenReturn(Arrays.asList(tuple1, tuple2, tuple2));

        for (int i = 1; i <= 9; i++) {
            int codEstatus = i;
            Assertions.assertDoesNotThrow(() ->
                    archivoEntityManagerRepository.detalleArchivos("fecha", "codCliente", "nomArch", codEstatus)
            );
        }
    }
}
