package mx.santander.h2h.monitoreo.repository;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import mx.santander.h2h.monitoreo.model.request.PutGetRequest;
import mx.santander.h2h.monitoreo.model.response.ProtocolResponse;
import mx.santander.h2h.monitoreo.model.response.PutGetDto;
import mx.santander.h2h.monitoreo.model.response.PutGetServiceResponse;
import mx.santander.h2h.monitoreo.service.IContractConnectionManagementPutGetDeleteDataService;
import mx.santander.h2h.monitoreo.service.IContractConnectionManagementPutGetFindDataService;
import mx.santander.h2h.monitoreo.service.IContractConnectionManagementPutGetSaveDataService;
import mx.santander.h2h.monitoreo.service.IContractConnectionManagementPutGetUpdateDataService;
import mx.santander.h2h.monitoreo.util.ContractConnectionManagementPutGetMapping;

class ContractConnectionManagementPutGetEntityManagerRepositoryTest {
	@Mock
	private IContractConnectionManagementPutGetFindDataService iContractConnectionManagementPutGetFindDataService;
	@Mock
	private IContractConnectionManagementPutGetSaveDataService iContractConnectionManagementPutGetSaveDataService;
	@Mock
	private IContractConnectionManagementPutGetUpdateDataService iContractConnectionManagementPutGetUpdateDataService;
	@Mock
	private IContractConnectionManagementPutGetDeleteDataService iContractConnectionManagementPutGetDeleteDataService;
	@Mock
	private ContractConnectionManagementPutGetMapping contractConnectionManagementPutGetMapping;
	@Mock
	private EntityManager entityManager;
	@InjectMocks
	private ContractConnectionManagementPutGetEntityManagerRepository repository;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testFindPutGetFiles() {
		Query query = mock(Query.class);

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);

		List<Object[]> lst = new ArrayList<>();
		Object[] arr = { "", "QWERT", "", "", "", "", "", "1", "", "", "", "", "", "", "", "", "" };
		lst.add(arr);
		when(query.getResultList()).thenReturn(lst);

		when(contractConnectionManagementPutGetMapping.mapFromPutGetFilesResponseToPutGetServiceResponse(lst))
				.thenReturn(new PutGetServiceResponse());

		PutGetServiceResponse result = repository.findPutGetFiles(new PutGetRequest(), 1);
		Assertions.assertNotNull(result);
	}

	@Test
	void testInsertPutGetProtocol() {
		PutGetServiceResponse response = new PutGetServiceResponse();
		response.setIdProtocolo("1");
		response.setIdPara("1");
		List<PutGetDto> lst = new ArrayList<>();
		lst.add(new PutGetDto(null, null, null, null, null, null, null, null, null, null, "1", null, null, null, null,
				null));
		response.setRegistrosPG(lst);
		repository.insertPutGetProtocol(response, "");
		Assertions.assertTrue(true);
	}

	@Test
	void testInsertPutGetProtocol1() {
		PutGetServiceResponse response = new PutGetServiceResponse();
		response.setIdProtocolo("2");
		response.setIdPara("1");
		List<PutGetDto> lst = new ArrayList<>();
		lst.add(new PutGetDto(null, null, null, null, null, null, null, null, null, null, "1", null, null, null, null,
				null));
		response.setRegistrosPG(lst);
		repository.insertPutGetProtocol(response, "");
		Assertions.assertTrue(true);
	}

	@Test
	void testUpdatePutGetProtocol() {
		PutGetRequest req = new PutGetRequest();
		req.setNumeroContrato("");
		repository.updatePutGetProtocol(new PutGetServiceResponse(), req);
		Assertions.assertTrue(true);
	}

	@Test
	void testGetPutFilesProtocols() {
		Query query = mock(Query.class);

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);
		List<String> lst = new ArrayList<>();
		lst.add("1");
		when(query.getResultList()).thenReturn(lst);
		when(contractConnectionManagementPutGetMapping.mapFromListProtocolsToListProtocolsResponse(anyList()))
				.thenReturn(new ArrayList<>());
		
		List<ProtocolResponse> result = repository.getPutFilesProtocols();
		Assertions.assertNotNull(result);
	}

	@Test
	void testFindPutGet() {
		Query query = mock(Query.class);

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);

		List<Object[]> lst = new ArrayList<>();
		Object[] arr = { "", "QWERT", "", "", "", "", "", "1", "", "", "", "", "", "", "", "", "" };
		lst.add(arr);
		when(query.getResultList()).thenReturn(lst);
		when(contractConnectionManagementPutGetMapping.mapFromPutGetResponseToPutGetServiceResponse(anyList(), any()))
				.thenReturn(new PutGetServiceResponse());

		PutGetServiceResponse result = repository.findPutGet(new PutGetRequest(), 1, new PutGetServiceResponse());
		Assertions.assertNotNull(result);
	}

	@Test
	void testFindPutGet1() {
		Query query = mock(Query.class);

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);

		List<Object[]> lst = new ArrayList<>();
		Object[] arr = { "", "QWERT", "", "", "", "", "", "1", "", "", "", "", "", "", "", "", "" };
		lst.add(arr);
		when(query.getResultList()).thenReturn(lst);
		PutGetRequest request = new PutGetRequest();
		request.setIdProtocoloPath1("x");
		request.setIdProtocoloPath2("x");
		request.setTipoOperPG("A");
		PutGetServiceResponse response = new PutGetServiceResponse();
		response.setIdProtocolo("2");
		response.setIdPara("1");
		List<PutGetDto> lsta = new ArrayList<>();
		lsta.add(new PutGetDto(null, null, null, null, null, null, null, null, null, null, "1", null, null, null, null,
				null));
		lsta.add(new PutGetDto(null, null, null, null, null, null, null, null, null, null, "1", null, null, null, null,
				null));
		response.setRegistrosPG(lsta);
		when(contractConnectionManagementPutGetMapping.mapFromPutGetResponseToPutGetServiceResponse(anyList(), any()))
				.thenReturn(response);

		PutGetServiceResponse result = repository.findPutGet(request, 2, response);
		Assertions.assertNotNull(result);
	}

	@Test
	void testGetParameters() {
		Query query = mock(Query.class);

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);
		List<String> lst = new ArrayList<>();
		lst.add("X");
		when(query.getResultList()).thenReturn(lst);

		String result = repository.getParameters("x");
		Assertions.assertNotNull(result);
	}

	@Test
	void testEnableDisablePutGet() {
		Query query = mock(Query.class);

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);
		when(query.executeUpdate()).thenReturn(1);

		String result = repository.enableDisablePutGet(new PutGetDto());
		Assertions.assertNotNull(result);
	}

}
