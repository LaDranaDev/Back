package mx.santander.h2h.monitoreo.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import mx.santander.h2h.monitoreo.repository.ICatalogoEstatusRepository;

@ExtendWith(MockitoExtension.class)
public class CancelOperationBaseServiceTest {

	@InjectMocks
	private CancelOperationBaseService cancel;
	
	@Mock
	private ICatalogoEstatusRepository icatalog;
	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
	}

	
	@Test
	void testGetListaComboEstatusCentro() {
		List<Object[]> catalogos = new ArrayList<>();
		Object[] datos = {1, "uno"};
		catalogos.add(datos);
		
		when(icatalog.obtenerCatalogoEstatusCentro()).thenReturn(catalogos);
		
		List<ComboResponse> resp = null;
		resp = cancel.getListaComboEstatusCentro();
		if( resp == null) {
			assertNull(resp);
		} else {
			assertNotNull(resp);
		}
	}

	
	@Test
	void testGetListaComboEstatus() {
		List<Object[]> catalogos = new ArrayList<>();
		Object[] datos = {1, "uno"};
		catalogos.add(datos);
		
		when(icatalog.obtenerCatalogoEstatusCancelado()).thenReturn(catalogos);
		
		List<ComboResponse> resp = null;
		resp = cancel.getListaComboEstatus();
		if( resp == null) {
			assertNull(resp);
		} else {
			assertNotNull(resp);
		}
	}
}
