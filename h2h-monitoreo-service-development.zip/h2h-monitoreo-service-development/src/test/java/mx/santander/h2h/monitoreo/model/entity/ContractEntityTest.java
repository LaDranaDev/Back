package mx.santander.h2h.monitoreo.model.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class ContractEntityTest {

    private ContractEntity contractEntity;

    @BeforeEach
    void setUp(){
        contractEntity = new ContractEntity();
    }

    @Test
    void getIdContrato() {
        contractEntity.setIdContrato(123L);
        assertEquals(123L, contractEntity.getIdContrato());
    }

    @Test
    void getNumeroContrato() {
        contractEntity.setNumeroContrato("123");
        assertEquals("123", contractEntity.getNumeroContrato());
    }

    @Test
    void getCveCertHSM() {
        contractEntity.setCveCertHSM("cveCert");
        assertEquals("cveCert", contractEntity.getCveCertHSM());
    }

    @Test
    void getPeriodoHabilitacion() {
        contractEntity.setPeriodoHabilitacion(0.0F);
        assertEquals(0.0F, contractEntity.getPeriodoHabilitacion());
    }

    @Test
    void getDiasProgramarArchivos() {
        contractEntity.setDiasProgramarArchivos(123);
        assertEquals(123, contractEntity.getDiasProgramarArchivos());
    }

    @Test
    void getVerificarCuentaBeneficiaria() {
        contractEntity.setVerificarCuentaBeneficiaria("verificar");
        assertEquals("verificar", contractEntity.getVerificarCuentaBeneficiaria());
    }

    @Test
    void getUsarClabeParaEdoCta() {
        contractEntity.setUsarClabeParaEdoCta("clave");
        assertEquals("clave", contractEntity.getUsarClabeParaEdoCta());
    }

    @Test
    void getUsarCifrasControl() {
        contractEntity.setUsarCifrasControl("T");
        assertEquals("T", contractEntity.getUsarCifrasControl());
    }

    @Test
    void getBandCambioProd() {
        contractEntity.setBandCambioProd("T");
        assertEquals("T", contractEntity.getBandCambioProd());
    }

    @Test
    void getCliente() {
        CustomerEntity customerEntity = mock(CustomerEntity.class);
        contractEntity.setCliente(customerEntity);
        assertEquals(customerEntity, contractEntity.getCliente());
    }

    @Test
    void getBandActCont() {
        contractEntity.setBandActCont("A");
        assertEquals("A", contractEntity.getBandActCont());
    }

    @Test
    void getBic() {
        contractEntity.setBic("bic");
        assertEquals("bic", contractEntity.getBic());
    }

    @Test
    void getMessagePartner() {
        contractEntity.setMessagePartner("pattern");
        assertEquals("pattern", contractEntity.getMessagePartner());
    }

    @Test
    void getTipoTransferencia() {
        contractEntity.setTipoTransferencia("tipoTransfer");
        assertEquals("tipoTransfer", contractEntity.getTipoTransferencia());
    }

    @Test
    void getAlias() {
        contractEntity.setAlias("alias");
        assertEquals("alias", contractEntity.getAlias());
    }

    @Test
    void getBackConfirming() {
        contractEntity.setBackConfirming("confirmacion");
        assertEquals("confirmacion", contractEntity.getBackConfirming());
    }

    @Test
    void getCodBice() {
        contractEntity.setCodBice("codBice");
        assertEquals("codBice", contractEntity.getCodBice());
    }

    @Test
    void getBandDuplicado() {
        contractEntity.setBandDuplicado("A");
        assertEquals("A", contractEntity.getBandDuplicado());
    }

    @Test
    void getRepDevOnline() {
        contractEntity.setRepDevOnline(123);
        assertEquals(123, contractEntity.getRepDevOnline());
    }

    @Test
    void getIpCliente() {
        contractEntity.setIpCliente("ipCliente");
        assertEquals("ipCliente", contractEntity.getIpCliente());
    }

    @Test
    void getIdCanalRepOptimus() {
        contractEntity.setIdCanalRepOptimus(123);
        assertEquals(123, contractEntity.getIdCanalRepOptimus());
    }
}