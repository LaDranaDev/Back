package mx.santander.h2h.monitoreo.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.EntityManager;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import mx.santander.h2h.monitoreo.model.request.PutGetRequest;
import mx.santander.h2h.monitoreo.model.request.PutGetSaveRequest;
import mx.santander.h2h.monitoreo.model.request.PutGetSaveWebServiceRequest;
import mx.santander.h2h.monitoreo.model.response.ProtocolResponse;
import mx.santander.h2h.monitoreo.model.response.PutGetDto;
import mx.santander.h2h.monitoreo.model.response.PutGetRestResponse;
import mx.santander.h2h.monitoreo.model.response.PutGetServiceResponse;
import mx.santander.h2h.monitoreo.repository.IContractConnectionManagementEntityManagerRepository;
import mx.santander.h2h.monitoreo.repository.IContractConnectionManagementProtocolsEntityManagerRepository;
import mx.santander.h2h.monitoreo.repository.IContractConnectionManagementPutGetEntityManagerRepository;

class ContractConnectionManagementPutGetServiceTest {
	@Mock
	private EntityManager entityManager;
	@Mock
	private IContractConnectionManagementPutGetEntityManagerRepository iContractConnectionManagementPutGetEntityManagerRepository;
	@Mock
	private IContractConnectionManagementEntityManagerRepository iContractConnectionManagementEntityManagerRepository;
	@Mock
	private IContractConnectionManagementProtocolsEntityManagerRepository iContractConnectionManagementProtocolsEntityManagerRepository;
	@InjectMocks
	private ContractConnectionManagementPutGetService service;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	void testFindPutGetFiles() {
		PutGetServiceResponse res = new PutGetServiceResponse();
		List<PutGetDto> lst = new ArrayList<>();
		lst.add(new PutGetDto());
		res.setRegistrosPG(lst);
		res.setIdPara("1");
		when(iContractConnectionManagementPutGetEntityManagerRepository.findPutGetFiles(any(), anyInt())).thenReturn(res);
		
		PutGetRestResponse result = service.findPutGetFiles(new PutGetRequest());
		Assertions.assertNotNull(result);
	}

	@Test
	void testVerAgregaPutGet() {
		PutGetRequest req = new PutGetRequest();
		req.setTipoOperPG("A");
		req.setIdProtocolo("5");
		PutGetSaveRequest save = new PutGetSaveRequest();
		save.setIdSelTipoProtocolo("5");
		save.setWebServiceRequest(new PutGetSaveWebServiceRequest());
		req.setPutGetSaveRequest(save);
		PutGetRestResponse result = service.verAgregaPutGet(req, true);
		Assertions.assertNotNull(result);
	}
	
	@Test
	void testVerAgregaPutGet1() {
		PutGetRequest req = new PutGetRequest();
		req.setTipoOperPG("M");
		req.setPutGetSaveRequest(new PutGetSaveRequest());
		PutGetRestResponse result = service.verAgregaPutGet(req, true);
		Assertions.assertNotNull(result);
	}
	
	@Test
	void testVerAgregaPutGet2() {
		List<ProtocolResponse> lst = new ArrayList<>();
		lst.add(new ProtocolResponse());
		when(iContractConnectionManagementPutGetEntityManagerRepository.getPutFilesProtocols()).thenReturn(lst);
		when(iContractConnectionManagementPutGetEntityManagerRepository.getParameters("H2H_PA_OS")).thenReturn("xx");
		
		PutGetRequest req = new PutGetRequest();
		req.setTipoOperPG("Z");
		req.setIdContrato("1");
		PutGetRestResponse result = service.verAgregaPutGet(req, false);
		Assertions.assertNotNull(result);
	}

	@Test
	void testEnableDisablePutGet() {
		PutGetServiceResponse res = new PutGetServiceResponse();
		List<PutGetDto> lst = new ArrayList<>();
		lst.add(new PutGetDto());
		res.setRegistrosPG(lst);
		res.setIdPara("1");
		when(iContractConnectionManagementPutGetEntityManagerRepository.findPutGetFiles(any(), anyInt())).thenReturn(res);
		
		PutGetDto dto = new PutGetDto();
		dto.setIdPtclPara("x");
		dto.setIdPtclPath("z");
		dto.setEstatus("I");
		PutGetRestResponse result = service.enableDisablePutGet(dto);
		Assertions.assertNotNull(result);
	}

}
