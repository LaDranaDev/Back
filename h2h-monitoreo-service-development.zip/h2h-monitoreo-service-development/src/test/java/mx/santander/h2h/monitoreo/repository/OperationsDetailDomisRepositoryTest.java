package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.Collections;

import static org.mockito.Mockito.*;

class OperationsDetailDomisRepositoryTest {
    @Mock
    EntityManager entityManager;
    @Mock
    Logger log;
    @InjectMocks
    OperationsDetailDomisRepository repository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        repository = spy(repository);
    }

    @Test
    void testObtenerDetalleOperacion() {
        doReturn("").when(repository).generaConsultaDetalleOperacion(anyString(), anyString());
        doNothing().when(repository).rellenaRespuestaMonitorOperacionesDTO(any(), any(), any());

        Query query = mock(Query.class);
        when(query.getResultList()).thenReturn(Collections.singletonList(mock(Tuple.class)));

        when(entityManager.createNativeQuery(any(), (Class<?>) any())).thenReturn(query);

        Assertions.assertDoesNotThrow(() ->
                repository.obtenerDetalleOperacion("idOperacion", "H2H_REG_TRAN")
        );
    }

    @Test
    void testRellenaRespuestaMonitorOperacionesDTO() {
        Tuple tuple = mock(Tuple.class);
        when(tuple.get((String) any())).then(answer -> {
            String arg = answer.getArgument(0);
            if ("REFERENCIA".equals(arg)) return "0";
            if ("SUCURSAL_TUTORA".equals(arg)) return "11";
            if ("DIVISA".equals(arg)) return "MN";
            if ("DIVISA_ORD".equals(arg)) return "MN";
            if ("CVE_PROD_OPER".equals(arg)) return "29";
            if ("IMPORTE".equals(arg)) return "999.99";
            if ("IMPORTE_CARGO".equals(arg)) return "999.99";
            return arg;
        });

        Assertions.assertDoesNotThrow(() ->
                repository.rellenaRespuestaMonitorOperacionesDTO(tuple, new OperationsMonitorQueryResponse(), "")
        );
    }

    @Test
    void testRellenaDivisas() {
        Tuple tuple = mock(Tuple.class);
        when(tuple.get((String) any())).then(answer -> {
            String arg = answer.getArgument(0);
            if ("DIVISA".equals(arg)) return "MXN";
            if ("DIVISA_ORD".equals(arg)) return "MXN";
            if ("IMPORTE".equals(arg)) return "999.99";
            if ("IMPORTE_CARGO".equals(arg)) return "999.99";
            return arg;
        });

        Assertions.assertDoesNotThrow(() ->
                repository.rellenaDivisas(tuple, new OperationsMonitorQueryResponse())
        );
    }

    @Test
    void testGeneraConsultaDetalleOperacion() {
        doReturn("").when(repository).getConsultaByProducto(anyBoolean(), any());

        String result = repository.generaConsultaDetalleOperacion("tabla","189");
        Assertions.assertNotNull(result);
    }

    @Test
    void testGetConsultaByProducto() {
        String result = repository.getConsultaByProducto(true, "H2H_PROD_DOMI_CXH");
        Assertions.assertNotNull(result);
    }

    @Test
    void testGetFecha() {
        String result = repository.getFecha("02/02/2020");
        Assertions.assertEquals("02/02/2020", result);

        result = repository.getFecha(
                Timestamp.valueOf(LocalDate.of(2020, 2, 2).atStartOfDay())
        );
        Assertions.assertEquals("02/02/2020", result);
    }


    @Test
    void testGetValue() {
        Tuple tuple = mock(Tuple.class);
        String result = repository.getValue(tuple, "key");
        Assertions.assertEquals("", result);

        when(tuple.get("key")).thenThrow(IllegalArgumentException.class);
        result = repository.getValue(tuple, "key");
        Assertions.assertEquals("", result);
    }

}
