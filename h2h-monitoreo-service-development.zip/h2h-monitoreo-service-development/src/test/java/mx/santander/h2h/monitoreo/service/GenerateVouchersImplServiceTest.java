package mx.santander.h2h.monitoreo.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;

import mx.santander.h2h.monitoreo.constants.ReportConstants;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersControllerResponse;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersDtoResponse;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersTotalResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsHistoryResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorCatalogsResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorCatalogsResponse.Pair;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorCatalogsYHorasResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.model.response.ProductEdoCtaResponse;
import mx.santander.h2h.monitoreo.model.response.SelectComboDTO;
import mx.santander.h2h.monitoreo.model.response.SubtotalResponse;
import mx.santander.h2h.monitoreo.model.response.VoucherRequestDto;
import mx.santander.h2h.monitoreo.repository.IContractConnectionManagementPutGetEntityManagerRepository;
import mx.santander.h2h.monitoreo.repository.IGenerateVouchersEntityManagerRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailRepository;
import mx.santander.h2h.monitoreo.util.IGenerateVouchersUtils;
import mx.santander.h2h.monitoreo.util.IGenerateVouchersValidateDateUtils;
import mx.santander.h2h.monitoreo.util.OperationsMonitorUtil;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperReport;

@ExtendWith(MockitoExtension.class)
class GenerateVouchersImplServiceTest {

	@InjectMocks
	GenerateVouchersImplService generateVouchersImplService;

	@Mock
	IOperationsMonitorService iOperationsMonitorService;

	@Mock
	IGenerateVouchersEntityManagerRepository iGenerateVouchersEntityManagerRepository;

	@Mock
	IContractConnectionManagementPutGetEntityManagerRepository iContractConnectionManagementPutGetEntityManagerRepository;

	@Mock
	IGenerateVouchersUtils iGenerateVouchersUtil;

	@Mock
	IGenerateVouchersValidateDateUtils iGenerateVouchersValidateDateUtils;

	@Mock
	OperationsMonitorUtil util;

	@Mock
	IOperationsDetailRepository detailRepository;

	@Mock
	Pageable pageable;

	@Mock
	JasperReport jasperReport;
	
	@Mock
	IGenerateVouchersOperacionesService generateVouchersOperacionesService;

	@Test
	void findVouchersCdmx() {

		OperationsMonitorCatalogsYHorasResponse operationsMonitorCatalogsResponse = crearOperationsMonitorCatalogsResponse();
		when(iOperationsMonitorService.catalogs()).thenReturn(operationsMonitorCatalogsResponse);

		GenerateVouchersDtoResponse generateVouchersDtoResponse = crearGenerateVouchersDtoResponse("1");
		when(iGenerateVouchersEntityManagerRepository.getListPaymentType()).thenReturn(generateVouchersDtoResponse);

		when(iContractConnectionManagementPutGetEntityManagerRepository.getParameters(anyString())).thenReturn("7");

		GenerateVouchersControllerResponse findVouchersCdmx = generateVouchersImplService.findVouchersCdmx();

		assertNotNull(findVouchersCdmx);
		assertEquals(operationsMonitorCatalogsResponse.getOperationsMonitorCatalogsResponse().getEstatus(),
				findVouchersCdmx.getParametros().get("listaEstatusCmb"));
		assertEquals(7, findVouchersCdmx.getParametros().get("rangoFechas"));
		assertEquals(generateVouchersDtoResponse.getListaTipoPago(),
				findVouchersCdmx.getParametros().get("listaTipoPagoCmb"));

		verify(iOperationsMonitorService, times(1)).catalogs();
		verify(iGenerateVouchersEntityManagerRepository, times(1)).getListPaymentType();
		verify(iContractConnectionManagementPutGetEntityManagerRepository, times(1)).getParameters(anyString());

	}

	@Test
	void findOperationsMonitor() {

		OperationsMonitorCatalogsYHorasResponse operationsMonitorCatalogsResponse = crearOperationsMonitorCatalogsResponse();
		when(iOperationsMonitorService.catalogs()).thenReturn(operationsMonitorCatalogsResponse);

		GenerateVouchersDtoResponse generateVouchersDtoResponse = crearGenerateVouchersDtoResponse("1");
		when(iGenerateVouchersEntityManagerRepository.getListPaymentType()).thenReturn(generateVouchersDtoResponse);

		when(iContractConnectionManagementPutGetEntityManagerRepository.getParameters(anyString())).thenReturn("7");

		when(iGenerateVouchersUtil.findOperationsMonitor(any(), any()))
				.thenReturn(crearGenerateVouchersControllerResponse(operationsMonitorCatalogsResponse,
						generateVouchersDtoResponse, "1"));

		GenerateVouchersControllerResponse findOperationsMonitor = generateVouchersImplService
				.findOperationsMonitor(new OperationsMonitorQueryRequest(), pageable);

		assertNotNull(findOperationsMonitor);
		assertEquals(operationsMonitorCatalogsResponse.getOperationsMonitorCatalogsResponse().getEstatus(),
				findOperationsMonitor.getParametros().get("listaEstatusCmb"));
		assertEquals(7, findOperationsMonitor.getParametros().get("rangoFechas"));
		assertEquals(generateVouchersDtoResponse.getListaTipoPago(),
				findOperationsMonitor.getParametros().get("listaTipoPagoCmb"));

		verify(iOperationsMonitorService, times(1)).catalogs();
		verify(iGenerateVouchersEntityManagerRepository, times(1)).getListPaymentType();
		verify(iContractConnectionManagementPutGetEntityManagerRepository, times(1)).getParameters(anyString());

	}

	@Test
	void findOperationsMonitorTotalOperaciones0() {

		OperationsMonitorCatalogsYHorasResponse operationsMonitorCatalogsResponse = crearOperationsMonitorCatalogsResponse();
		when(iOperationsMonitorService.catalogs()).thenReturn(operationsMonitorCatalogsResponse);

		GenerateVouchersDtoResponse generateVouchersDtoResponse = crearGenerateVouchersDtoResponse("0");
		when(iGenerateVouchersEntityManagerRepository.getListPaymentType()).thenReturn(generateVouchersDtoResponse);

		when(iContractConnectionManagementPutGetEntityManagerRepository.getParameters(anyString())).thenReturn("7");

		when(iGenerateVouchersUtil.findOperationsMonitor(any(), any()))
				.thenReturn(crearGenerateVouchersControllerResponse(operationsMonitorCatalogsResponse,
						generateVouchersDtoResponse, "1"));

		GenerateVouchersControllerResponse findOperationsMonitor = generateVouchersImplService
				.findOperationsMonitor(new OperationsMonitorQueryRequest(), pageable);

		assertNotNull(findOperationsMonitor);
		assertEquals(operationsMonitorCatalogsResponse.getOperationsMonitorCatalogsResponse().getEstatus(),
				findOperationsMonitor.getParametros().get("listaEstatusCmb"));
		assertEquals(7, findOperationsMonitor.getParametros().get("rangoFechas"));
		assertEquals(generateVouchersDtoResponse.getListaTipoPago(),
				findOperationsMonitor.getParametros().get("listaTipoPagoCmb"));

		verify(iOperationsMonitorService, times(1)).catalogs();
		verify(iGenerateVouchersEntityManagerRepository, times(1)).getListPaymentType();
		verify(iContractConnectionManagementPutGetEntityManagerRepository, times(1)).getParameters(anyString());

	}

	@Test
	void findOperationsMonitorTotalOperacionesNull() {

		OperationsMonitorCatalogsYHorasResponse operationsMonitorCatalogsResponse = crearOperationsMonitorCatalogsResponse();
		when(iOperationsMonitorService.catalogs()).thenReturn(operationsMonitorCatalogsResponse);

		GenerateVouchersDtoResponse generateVouchersDtoResponse = crearGenerateVouchersDtoResponse(null);
		when(iGenerateVouchersEntityManagerRepository.getListPaymentType()).thenReturn(generateVouchersDtoResponse);

		when(iContractConnectionManagementPutGetEntityManagerRepository.getParameters(anyString())).thenReturn("7");

		when(iGenerateVouchersUtil.findOperationsMonitor(any(), any()))
				.thenReturn(crearGenerateVouchersControllerResponse(operationsMonitorCatalogsResponse,
						generateVouchersDtoResponse, "1"));

		GenerateVouchersControllerResponse findOperationsMonitor = generateVouchersImplService
				.findOperationsMonitor(new OperationsMonitorQueryRequest(), pageable);

		assertNotNull(findOperationsMonitor);
		assertEquals(operationsMonitorCatalogsResponse.getOperationsMonitorCatalogsResponse().getEstatus(),
				findOperationsMonitor.getParametros().get("listaEstatusCmb"));
		assertEquals(7, findOperationsMonitor.getParametros().get("rangoFechas"));
		assertEquals(generateVouchersDtoResponse.getListaTipoPago(),
				findOperationsMonitor.getParametros().get("listaTipoPagoCmb"));

		verify(iOperationsMonitorService, times(1)).catalogs();
		verify(iGenerateVouchersEntityManagerRepository, times(1)).getListPaymentType();
		verify(iContractConnectionManagementPutGetEntityManagerRepository, times(1)).getParameters(anyString());

	}

	@Test
	void findTotal() {

		when(iGenerateVouchersEntityManagerRepository.getLumpSum(any())).thenReturn("10");

		when(iGenerateVouchersEntityManagerRepository.getTotalFiles(any())).thenReturn("10");

		GenerateVouchersTotalResponse findTotal = generateVouchersImplService
				.findTotal(new OperationsMonitorQueryRequest());

		assertNotNull(findTotal);
		assertEquals("$10", findTotal.getImporteGlobal());
		assertEquals("10", findTotal.getTotalArchivos());

		verify(iGenerateVouchersEntityManagerRepository, times(1)).getLumpSum(any());
		verify(iGenerateVouchersEntityManagerRepository, times(1)).getTotalFiles(any());

	}

	@Test
	void paginarOperaciones() {

		List<OperationsMonitorQueryResponse> listaOperaciones = crearListaOperationsMonitorQueryResponse();

		when(iGenerateVouchersEntityManagerRepository.findOperations(any())).thenReturn(listaOperaciones);

		Page<OperationsMonitorQueryResponse> paginarOperaciones = generateVouchersImplService
				.paginarOperaciones(new OperationsMonitorQueryRequest(), pageable);

		assertNotNull(paginarOperaciones);
		assertEquals(listaOperaciones, paginarOperaciones.getContent());

		verify(iGenerateVouchersEntityManagerRepository, times(1)).findOperations(any());

	}

	@Test
	void detalleOperaciones() {

		OperationsMonitorQueryResponse operationsMonitorQueryResponse = crearOperationsMonitorQueryResponse();

		when(util.obtenerDetalleOperacion(anyString(), anyString())).thenReturn(operationsMonitorQueryResponse);

		GenerateVouchersControllerResponse detalleOperaciones = generateVouchersImplService
				.detalleOperaciones(crearOperationsMonitorQueryResponse());

		assertNotNull(detalleOperaciones);
		assertEquals(operationsMonitorQueryResponse, detalleOperaciones.getParametros().get("detalleOperacionDTO"));

		verify(util, times(1)).obtenerDetalleOperacion(anyString(), anyString());

	}

	@Test
	void historialOperaciones() {

		List<OperationsHistoryResponse> listaOperationsHistoryResponse = crearListaOperationsHistoryResponse();

		when(detailRepository.obtenerHistorialOperacion(anyString())).thenReturn(listaOperationsHistoryResponse);

		List<OperationsHistoryResponse> historialOperaciones = generateVouchersImplService
				.historialOperaciones("123456");

		assertNotNull(historialOperaciones);
		assertEquals(listaOperationsHistoryResponse, historialOperaciones);

		verify(detailRepository, times(1)).obtenerHistorialOperacion(anyString());

	}

	@Test
	void conceptoValor() {

		GenerateVouchersDtoResponse generateVouchersDtoResponse = crearGenerateVouchersDtoResponse("1");

		when(iGenerateVouchersEntityManagerRepository.conceptoValor(anyString()))
				.thenReturn(generateVouchersDtoResponse);

		GenerateVouchersDtoResponse conceptoValor = generateVouchersImplService.conceptoValor("123456");

		assertNotNull(conceptoValor);
		assertEquals(generateVouchersDtoResponse, conceptoValor);

		verify(iGenerateVouchersEntityManagerRepository, times(1)).conceptoValor(anyString());

	}

	@Test
	void exportarOperacionesXlsx() throws JRException {
		getSubtotalResponse();
		getProductEdoCtaResponse();

		ReportResponse exportarOperacionesXlsx = generateVouchersOperacionesService
				.exportarOperacionesXlsx(new OperationsMonitorQueryRequest(), "xlsx");

		assertTrue(true);
	}

	private ReportResponse crearReportResponse() {

		ReportResponse reportResponse = new ReportResponse();

		reportResponse.setData("data");
		reportResponse.setLength(123456);
		reportResponse.setName("nameFileReport");
		reportResponse.setType("xlsx");

		return reportResponse;
	}

	private Map<String, String> crearTypeReport() {

		Map<String, String> typeReport = new HashMap<>();

		typeReport.put(ReportConstants.PARAM_NAME_REPORT, ReportConstants.REPORTE_COMPROBANTES_CDMX);
		typeReport.put(ReportConstants.PARAM_MIME_TYPE, MediaType.APPLICATION_OCTET_STREAM_VALUE);

		return typeReport;
	}

	private List<OperationsHistoryResponse> crearListaOperationsHistoryResponse() {

		List<OperationsHistoryResponse> listaOperationsHistory = new ArrayList<>();

		listaOperationsHistory.add(crearOperationsHistoryResponse());

		return listaOperationsHistory;
	}

	private OperationsHistoryResponse crearOperationsHistoryResponse() {

		OperationsHistoryResponse operationsHistoryResponse = new OperationsHistoryResponse();

		operationsHistoryResponse.setEstatus("A");
		operationsHistoryResponse.setFecha("12-07-2023");
		operationsHistoryResponse.setHora("12:00:00.0");
		operationsHistoryResponse.setRefOper("refOper");

		return operationsHistoryResponse;
	}

	private GenerateVouchersControllerResponse crearGenerateVouchersControllerResponse(
			OperationsMonitorCatalogsYHorasResponse operationsMonitorCatalogsResponse,
			GenerateVouchersDtoResponse generateVouchersDtoResponse, String totalOperaciones) {

		GenerateVouchersControllerResponse generateVouchersControllerResponse = new GenerateVouchersControllerResponse();

		generateVouchersControllerResponse.setFin(1);
		generateVouchersControllerResponse.setInicio(1);
		generateVouchersControllerResponse.setTotalOperaciones(totalOperaciones);
		generateVouchersControllerResponse
				.setParametros(crearMapaParametros(operationsMonitorCatalogsResponse, generateVouchersDtoResponse));
		generateVouchersControllerResponse.setListaOperaciones(crearListaOperationsMonitorQueryResponse());

		return generateVouchersControllerResponse;
	}

	private List<OperationsMonitorQueryResponse> crearListaOperationsMonitorQueryResponse() {

		List<OperationsMonitorQueryResponse> listaOperaciones = new ArrayList<OperationsMonitorQueryResponse>();

		listaOperaciones.add(crearOperationsMonitorQueryResponse());

		return listaOperaciones;
	}

	private OperationsMonitorQueryResponse crearOperationsMonitorQueryResponse() {

		OperationsMonitorQueryResponse operationsMonitorQueryResponse = new OperationsMonitorQueryResponse();

		operationsMonitorQueryResponse.setBancoOrdenante("bancoOrden");
		operationsMonitorQueryResponse.setBancoReceptor("bancoReceptor");
		operationsMonitorQueryResponse.setBucEmpleado("123456");
		operationsMonitorQueryResponse.setCanal("1");
		operationsMonitorQueryResponse.setCodCli("1");
		operationsMonitorQueryResponse.setCodRegistro("1");

		operationsMonitorQueryResponse.setIdOperacion("123456");
		operationsMonitorQueryResponse.setVistProd("24");

		return operationsMonitorQueryResponse;
	}

	private Map<String, Object> crearMapaParametros(
			OperationsMonitorCatalogsYHorasResponse operationsMonitorCatalogsResponse,
			GenerateVouchersDtoResponse generateVouchersDtoResponse) {

		Map<String, Object> mapaParametros = new HashMap<>();

		mapaParametros.put("listaEstatusCmb",
				operationsMonitorCatalogsResponse.getOperationsMonitorCatalogsResponse().getEstatus());
		mapaParametros.put("rangoFechas", 7);
		mapaParametros.put("listaTipoPagoCmb", generateVouchersDtoResponse.getListaTipoPago());

		return mapaParametros;
	}

	private GenerateVouchersDtoResponse crearGenerateVouchersDtoResponse(String totalOperaciones) {

		GenerateVouchersDtoResponse generateVouchersDtoResponse = new GenerateVouchersDtoResponse();

		generateVouchersDtoResponse.setCdmxBean(new VoucherRequestDto());
		generateVouchersDtoResponse.setConceptoValor("conceptoValor");
		generateVouchersDtoResponse.setListaTipoPago(crearListaSelectComboDTO());
		generateVouchersDtoResponse.setImporteTotal(null);
		generateVouchersDtoResponse.setListaOperaciones(null);
		generateVouchersDtoResponse.setMsgError(null);
		generateVouchersDtoResponse.setParametrosAdicionalesComprobante(null);
		generateVouchersDtoResponse.setTotalArchivos(null);
		generateVouchersDtoResponse.setTotalOperaciones(totalOperaciones);

		generateVouchersDtoResponse.getCdmxBean();
		generateVouchersDtoResponse.getConceptoValor();
		generateVouchersDtoResponse.getImporteTotal();
		generateVouchersDtoResponse.getListaOperaciones();
		generateVouchersDtoResponse.getListaTipoPago();
		generateVouchersDtoResponse.getMsgError();
		generateVouchersDtoResponse.getParametrosAdicionalesComprobante();
		generateVouchersDtoResponse.getTotalArchivos();
		generateVouchersDtoResponse.getTotalOperaciones();

		generateVouchersDtoResponse.toString();

		return generateVouchersDtoResponse;
	}

	private List<SelectComboDTO> crearListaSelectComboDTO() {

		List<SelectComboDTO> listaSelectComboDTO = new ArrayList<>();

		listaSelectComboDTO.add(crearSelectComboDTO());

		return listaSelectComboDTO;
	}

	private SelectComboDTO crearSelectComboDTO() {

		SelectComboDTO selectComboDTO = new SelectComboDTO();

		selectComboDTO.setKey("key");
		selectComboDTO.setValue("value");

		selectComboDTO.getKey();
		selectComboDTO.getValue();

		selectComboDTO.toString();

		return selectComboDTO;
	}

	private OperationsMonitorCatalogsYHorasResponse crearOperationsMonitorCatalogsResponse() {

		OperationsMonitorCatalogsYHorasResponse operationsMonitorCatalogsResponse = new OperationsMonitorCatalogsYHorasResponse();

		OperationsMonitorCatalogsResponse catalogsResponse = new OperationsMonitorCatalogsResponse();

		operationsMonitorCatalogsResponse.setOperationsMonitorCatalogsResponse(catalogsResponse);

		operationsMonitorCatalogsResponse.getOperationsMonitorCatalogsResponse().setEstatus(crearListaPair());

		return operationsMonitorCatalogsResponse;
	}

	private List<Pair> crearListaPair() {

		List<Pair> listaPair = new ArrayList<>();

		listaPair.add(crearPair());

		return listaPair;
	}

	private Pair crearPair() {

		Pair pair = new Pair("key", "value");

		return pair;
	}
	
	private SubtotalResponse getSubtotalResponse() {
		SubtotalResponse response = new SubtotalResponse();
		response.setSubAlerta(0);
		response.setSubDuplicado(0);
		response.setSubEnrollment(0);
		response.setSubEspera(0);
		response.setSubProcesado(0);
		response.setSubproceso(0);
		response.setSubProgramado(0);
		response.setSubRechazados(0);
		response.setSubRecibido(0);
		response.setSubTotalArchivos(0);
		response.setSubValidado(0);
		response.setTotComision(null);
		response.setTotImporteComision(null);
		response.setTotIvaComision(null);
		response.setTotPorcentaje(null);
		response.setTotPrecio(null);
		response.setTotTotalComision(null);
		
		response.getSubAlerta();
		response.getSubDuplicado();
		response.getSubEnrollment();
		response.getSubEspera();
		response.getSubProcesado();
		response.getSubproceso();
		response.getSubProgramado();
		response.getSubRechazados();
		response.getSubRecibido();
		response.getSubTotalArchivos();
		response.getSubValidado();
		response.getTotComision();
		response.getTotImporteComision();
		response.getTotIvaComision();
		response.getTotPorcentaje();
		response.getTotPrecio();
		response.getTotTotalComision();
		
		response.toString();
		
		return response;
	}
	
	private ProductEdoCtaResponse getProductEdoCtaResponse() {
		ProductEdoCtaResponse response = new ProductEdoCtaResponse();
		response.setActivo(null);
		response.setAplicaContratoConfirming(null);
		response.setAplicaContratoProvConfirming(null);
		response.setAplicaEmail(null);
		response.setAplicaReintentos(null);
		response.setAplicaTipoCargo(null);
		response.setAplicaVigencia(null);
		response.setAsignado(null);
		response.setClave(null);
		response.setDescripcion(null);
		response.setEnvioEmail(null);
		response.setId(null);
		response.setIdContratoProducto(0);
		response.setIntervaloReintentos(null);
		response.setNumeroContrato(null);
		response.setNumeroReintentos(null);
		response.setTipoCargo(null);
		response.setVigencia(null);
		
		response.getActivo();
		response.getAplicaContratoConfirming();
		response.getAplicaContratoProvConfirming();
		response.getAplicaEmail();
		response.getAplicaReintentos();
		response.getAplicaTipoCargo();
		response.getAplicaVigencia();
		response.getAsignado();
		response.getClave();
		response.getDescripcion();
		response.getEnvioEmail();
		response.getId();
		response.getIdContratoProducto();
		response.getIntervaloReintentos();
		response.getNumeroContrato();
		response.getNumeroReintentos();
		response.getTipoCargo();
		response.getVigencia();
		
		response.toString();
		
		return response;
	}
}
