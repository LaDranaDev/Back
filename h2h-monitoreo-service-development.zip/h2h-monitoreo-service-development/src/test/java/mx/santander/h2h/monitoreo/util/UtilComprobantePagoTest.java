package mx.santander.h2h.monitoreo.util;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

class UtilComprobantePagoTest {

    @Test
    void testObtenerQueryPagoRef() {
        String result = UtilComprobantePago.obtenerQueryPagoRef(Arrays.asList(1, 2));
        Assertions.assertNotNull(result);
    }

    @Test
    void testObtenerQueryProdAltaPago() {
        String result = UtilComprobantePago.obtenerQueryProdAltaPago(Arrays.asList(1, 2));
        Assertions.assertNotNull(result);
    }

    @Test
    void testObtenerQueryProdOrdnPago() {
        String result = UtilComprobantePago.obtenerQueryProdOrdnPago(Arrays.asList(1, 2));
        Assertions.assertNotNull(result);
    }

    @Test
    void testObtenerQueryProdTranMismBanc() {
        String result = UtilComprobantePago.obtenerQueryProdTranMismBanc(Arrays.asList(1, 2));
        Assertions.assertNotNull(result);
    }

    @Test
    void testObtenerQueryPagoTDC() {
        String result = UtilComprobantePago.obtenerQueryPagoTDC(Arrays.asList(1, 2));
        Assertions.assertNotNull(result);
    }

    @Test
    void testObtenerQueryPagoImpAduan() {
        String result = UtilComprobantePago.obtenerQueryPagoImpAduan(Arrays.asList(1, 2));
        Assertions.assertNotNull(result);
    }

}
