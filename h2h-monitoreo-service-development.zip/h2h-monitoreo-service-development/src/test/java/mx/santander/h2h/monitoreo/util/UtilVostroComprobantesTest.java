package mx.santander.h2h.monitoreo.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Arrays;
import java.util.Collections;

import org.junit.jupiter.api.Test;

public class UtilVostroComprobantesTest {

    @Test
    public void testObtenerQuerys() throws Exception {
        String result = UtilVostroComprobantes.obtenerQuerys(Collections.emptyList(), "tabla", "sqlstr");
        assertEquals("sqlstr", result);

        result = UtilVostroComprobantes.obtenerQuerys(Arrays.asList(1, 2), "H2H_MX_PROD_TVMB", "sqlstr");
        assertNotNull(result);

        result = UtilVostroComprobantes.obtenerQuerys(Arrays.asList(1, 2), "H2H_MX_PROD_TVIB", "sqlstr");
        assertNotNull(result);

        result = UtilVostroComprobantes.obtenerQuerys(Arrays.asList(1, 2), "H2H_MX_PROD_TRAN_INTN_32", "sqlstr");
        assertNotNull(result);
    }

    @Test
    public void testAgregaIdRegAwhere() {
        StringBuilder sql = new StringBuilder();
        UtilVostroComprobantes.agregaIdRegAwhere(Arrays.asList(1, 2), sql);
        assertEquals(" WHERE ( r.id_reg = 1 OR r.id_reg = 2 ) ", sql.toString());
    }

    @Test
    public void testEsVostro() throws Exception {
        boolean result = UtilVostroComprobantes.esVostro("-39-");
        assertEquals(true, result);
    }
}
