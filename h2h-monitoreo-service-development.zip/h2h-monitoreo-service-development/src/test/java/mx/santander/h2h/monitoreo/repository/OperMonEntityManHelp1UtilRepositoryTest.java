/**
* Santander SCIB - Banco Santander Negocios Globales
* Todos los derechos reservados
* OperMonEntityManHelp1UtilTest.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <5 jul. 2024 12:39:49>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.repository;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.util.OperMonEntityManHelp1Util;

/**
 * Clase generada para OperMonEntityManHelp1UtilTest.
 *
 * @autor C320868
 * @modifico C320868
 */
class OperMonEntityManHelp1UtilRepositoryTest {

	/**
	 * Test validaciones.
	 */
	@Test
	void testValidaciones() {
		Map<String, Object> params = new HashMap<String, Object>();
    	StringBuilder query = new StringBuilder();
		
		
		try {
			OperMonEntityManHelp1Util.validaciones(llenado(), query, params, "subcons", false);
		} catch(Exception e) { }
		
		if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}
	}
	
	/**
	 * Test validaciones 2.
	 */
	@Test
	void testValidaciones2() {
		Map<String, Object> params = null;
		StringBuilder query = new StringBuilder();
		try {
			OperMonEntityManHelp1Util.validaciones(llenado(), query, params, "subcons", true);
		} catch(Exception e) { }
		
		if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}
	}
	
	/**
	 * Test validaciones 3.
	 */
	@Test
	void testValidaciones3() {
		Map<String, Object> params = new HashMap<String, Object>();
    	StringBuilder query = new StringBuilder();
		
		try {
			OperMonEntityManHelp1Util.validaciones(llenado(), query, params, "subcons", false);
		} catch(Exception e) { }
		
		if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}
	}
	
	/**
	 * Test validaciones 4.
	 */
	@Test
	void testValidaciones4() {
		Map<String, Object> params = new HashMap<String, Object>();
    	StringBuilder query = new StringBuilder();
		
		try {
			OperMonEntityManHelp1Util.validaciones(llenado(), query, params, "SelectConsult", true);
		} catch(Exception e) { }
		
		if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}
	}
	
	/**
	 * Test validaciones 5.
	 */
	@Test
	void testValidaciones5() {
		Map<String, Object> params = new HashMap<String, Object>();
    	StringBuilder query = new StringBuilder();
		
		try {
			OperMonEntityManHelp1Util.validaciones(llenado(), query, params, "SelectConsult", false);
		} catch(Exception e) { }
		
		if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}
	}

	/**
	 * Test condicion sub cons.
	 */
	@Test
	void testCondicionSubCons() {
		StringBuilder query = new StringBuilder();
		boolean[] ingresoVal = {false};
		try {
			OperMonEntityManHelp1Util.condicionSubCons(llenado(), query, false, ingresoVal);
		} catch(Exception e) { }
		
		if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}
	}
	
	
	/**
	 * Test condicion sub cons 2.
	 */
	@Test
	void testCondicionSubCons2() {
    	StringBuilder query = new StringBuilder();
    	boolean[] ingresoVal = {false};
		try {
			OperMonEntityManHelp1Util.condicionSubCons(llenado(), query, true, ingresoVal);
		} catch(Exception e) { }
		
		if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}
	}


	/**
	 * Test get select consulta operaciones orden pago.
	 */
	@Test
    void testGetSelectConsultaOperacionesOrdenPago() {
		StringBuilder query = new StringBuilder();
		
        OperMonEntityManHelp1Util.getSelectConsultaOperacionesOrdenPago(query, true);
        Assertions.assertNotNull(query);
    }
	
	
	/**
	 * Test get select consulta operaciones alta masiva empleados.
	 */
	@Test
	void testGetSelectConsultaOperacionesAltaMasivaEmpleados() {
		StringBuilder query = new StringBuilder();
		
		OperMonEntityManHelp1Util.getSelectConsultaOperacionesAltaMasivaEmpleados(query, true);
        Assertions.assertNotNull(query);
	}

	/**
	 * Test get select consulta operaciones.
	 */
	@Test
	void testGetSelectConsultaOperaciones2() {
		StringBuilder query = new StringBuilder();
		
		OperMonEntityManHelp1Util.getSelectConsultaOperacionesOrdenPago(query, true);
        Assertions.assertNotNull(query);
	}

	@Test
	void testGetSelectConsultaOperaciones() {
		StringBuilder query = new StringBuilder();
		
		OperMonEntityManHelp1Util.getSelectConsultaOperacionesOrdenPago(query, false);
        Assertions.assertNotNull(query);
	}
	

	/**
	 * Test getselect imp fed.
	 */
	@Test
    void testGetselectImpFed() {
		StringBuilder query = new StringBuilder();
		
        for (String idcntr : Arrays.asList("21", "22", "23")) {
            OperMonEntityManHelp1Util.getselectImpFed(true, query, idcntr);
            Assertions.assertNotNull(query);
        }
    }
	
	
	
    /**
     * Llenado.
     *
     * @return el operations monitor query request
     */
    private OperationsMonitorQueryRequest llenado() {
    	OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();
        consultaOperaciones.setBuc("buc");
        consultaOperaciones.setContrato("contrato");
        consultaOperaciones.setNombreArchivo("nombreArchivo");
        consultaOperaciones.setIdProducto("23");
        consultaOperaciones.setIdEstatus("idEstatus");
        consultaOperaciones.setCuentaCargo("cuentaCargo");
        consultaOperaciones.setCuentaAbono("cuentaAbono");
        consultaOperaciones.setImporte("importe");
        consultaOperaciones.setReferencia("referencia");
        consultaOperaciones.setDivisa("MXP");
        consultaOperaciones.setNumeroOrden("numeroOrden");
        consultaOperaciones.setNombreBeneficiario("nombreBeneficiario");
        consultaOperaciones.setIdReg("idReg");
        consultaOperaciones.setNumEmpleado("numEmpleado");
        consultaOperaciones.setNumTarjeta("numTarjeta");
        consultaOperaciones.setSucTutora("sucTutora");
        consultaOperaciones.setTipo("tipo");
        consultaOperaciones.setLineaCaptura("lineaCaptura");
        consultaOperaciones.setConvenio("convenio");
        consultaOperaciones.setFolioSUA("folioSUA");
        consultaOperaciones.setRegPat("regPat");
        
        return consultaOperaciones;
    }
}
