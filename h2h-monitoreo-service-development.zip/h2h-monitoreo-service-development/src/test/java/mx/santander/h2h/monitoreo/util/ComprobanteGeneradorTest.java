package mx.santander.h2h.monitoreo.util;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mockConstruction;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedConstruction;

import mx.isban.h2h.comprobantes.GeneradorComprobantes;
import mx.isban.h2h.comprobantes.model.ComprobanteSalida;
import mx.santander.h2h.monitoreo.model.response.ComprobantesOperacionResponse;

class ComprobanteGeneradorTest {

    MockedConstruction<GeneradorComprobantes> generadorComprobantes;

    byte[] ret = new byte[]{(byte) 89};

    @BeforeEach
    void setUp() {
        ComprobanteSalida salida = new ComprobanteSalida();
        salida.setComprobanteBytes(ret);
        generadorComprobantes = mockConstruction(GeneradorComprobantes.class, (generador, context) ->
                when(generador.generaComprobante(any())).thenReturn(salida)
        );
    }

    @AfterEach
    void after() {
        generadorComprobantes.close();
    }

    @Test
    void testGeneraReporteAportObrerPat() {
        ComprobantesOperacionResponse obj = new ComprobantesOperacionResponse();
        byte[] result = ComprobanteGenerador.generaReporteAportObrerPat(obj);
        Assertions.assertArrayEquals(ret, result);

        obj.setPeriodoPago("AAAAAA");
        result = ComprobanteGenerador.generaReporteAportObrerPat(obj);
        Assertions.assertArrayEquals(ret, result);
    }

    @Test
    void testGeneraImpFed() {
        byte[] result = ComprobanteGenerador.generaImpFed(new ComprobantesOperacionResponse());
        Assertions.assertArrayEquals(ret, result);
    }

    @Test
    void testGeneraReportePagRef() {
        byte[] result = ComprobanteGenerador.generaReportePagRef(new ComprobantesOperacionResponse());
        Assertions.assertArrayEquals(ret, result);
    }

    @Test
    void testGeneraPagoTDC() {
        byte[] result = ComprobanteGenerador.generaPagoTDC(new ComprobantesOperacionResponse());
        Assertions.assertArrayEquals(ret, result);
    }

    @Test
    void testGeneraConfirming() {
        byte[] result = ComprobanteGenerador.generaConfirming(new ComprobantesOperacionResponse());
        Assertions.assertArrayEquals(ret, result);
    }

    @Test
    void testGeneraTEF() {
        byte[] result = ComprobanteGenerador.generaTEF(new ComprobantesOperacionResponse());
        Assertions.assertArrayEquals(ret, result);
    }

    @Test
    void testGeneraNominaMismoBanco() {
        byte[] result = ComprobanteGenerador.generaNominaMismoBanco(new ComprobantesOperacionResponse());
        Assertions.assertArrayEquals(ret, result);
    }

    @Test
    void testGeneraTMB() {
        byte[] result = ComprobanteGenerador.generaTMB(new ComprobantesOperacionResponse());
        Assertions.assertArrayEquals(ret, result);
    }

    @Test
    void testGeneraTransferenciasMismaDiv() {
        byte[] result = ComprobanteGenerador.generaTransferenciasMismaDiv(new ComprobantesOperacionResponse());
        Assertions.assertArrayEquals(ret, result);
    }

    @Test
    void testGeneraPagImpAdua() {
        byte[] result = ComprobanteGenerador.generaPagImpAdua(new ComprobantesOperacionResponse());
        Assertions.assertArrayEquals(ret, result);
    }
}
