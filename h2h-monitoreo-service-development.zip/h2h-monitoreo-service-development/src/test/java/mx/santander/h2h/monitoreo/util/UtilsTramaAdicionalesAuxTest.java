package mx.santander.h2h.monitoreo.util;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import mx.santander.h2h.monitoreo.model.response.CampoAdicionalBean;

class UtilsTramaAdicionalesAuxTest {
	@InjectMocks
	private UtilsTramaAdicionalesAux aux;

	@Test
	void testGenerarListaCPA() {
		List<CampoAdicionalBean> result = UtilsTramaAdicionalesAux.generarListaCPA("asdasd|adsasd");
		Assertions.assertNotNull(result);
	}

	@Test
	void testGetTramaCamposAdicionales() {
		List<CampoAdicionalBean> campos = new ArrayList<>();
		CampoAdicionalBean bean = new CampoAdicionalBean();
		bean.setCampo("asda");
		bean.setValue("asda");
		campos.add(bean);
		campos.add(bean);
		String result = UtilsTramaAdicionalesAux.getTramaCamposAdicionales(campos);
		Assertions.assertNotNull(result);
	}

	@Test
	void addCfdiFieldsToQuery() {
		List<CampoAdicionalBean> campos = new ArrayList<>();
		CampoAdicionalBean bean = new CampoAdicionalBean();
		bean.setCampo("asda");
		bean.setValue("asda");
		campos.add(bean);
		campos.add(bean);
		String result = UtilsTramaAdicionalesAux.addCfdiFieldsToQuery(true);
		String resultFalse = UtilsTramaAdicionalesAux.addCfdiFieldsToQuery(false);
		Assertions.assertNotNull(result);
		Assertions.assertNotNull(resultFalse);
	}
}
