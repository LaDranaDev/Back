package mx.santander.h2h.monitoreo.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import mx.isban.h2h.comprobantefiscal.BeanRespuestaConcepto;
import mx.isban.h2h.comprobantefiscal.BeanRespuestaGeneracion;
import mx.isban.h2h.comprobantefiscal.BeanRespuestaValidacion;
import mx.isban.h2h.comprobantefiscal.ConsultaInfoConceptoResponse;
import mx.isban.h2h.comprobantefiscal.GeneraComprobanteResponse;
import mx.isban.h2h.comprobantefiscal.RegistraMovimientoResponse;
import mx.isban.h2h.comprobantefiscal.Respuesta;
import mx.isban.h2h.comprobantefiscal.ValidaComprobanteResponse;
import mx.santander.h2h.monitoreo.constants.ApiConstants;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersDtoResponse;
import mx.santander.h2h.monitoreo.model.response.VoucherRequestDto;
import mx.santander.h2h.monitoreo.repository.IComprobanteSelloDigitalRepository;
import mx.santander.h2h.monitoreo.repository.IDatosAdicionalesEntityManagerRepository;
import mx.santander.h2h.monitoreo.repository.IGenerateVouchersEntityManagerRepository;

class GenerateVouchersExportImplServiceTest {
	@Mock
	private IGenerateVouchersEntityManagerRepository iGenerateVouchersEntityManagerRepository;
	@Mock
	private IDatosAdicionalesEntityManagerRepository iDatosAdicionalesEntityManagerRepository;
	@Mock
	private IComprobanteSelloDigitalRepository comprobante;
	@InjectMocks
	private GenerateVouchersExportImplService service;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testExportarOperacionesPdf() {
		GenerateVouchersDtoResponse responseDAO = new GenerateVouchersDtoResponse();
		List<String> lst = new ArrayList<>();
		lst.add("0");
		lst.add("0");
		lst.add("w");
		responseDAO.setParametrosAdicionalesComprobante(lst);
		when(iGenerateVouchersEntityManagerRepository.recuperarParamsGenComprobante()).thenReturn(responseDAO);

		ConsultaInfoConceptoResponse concepto = new ConsultaInfoConceptoResponse();
		BeanRespuestaConcepto bean = new BeanRespuestaConcepto();
		bean.setCodError(ApiConstants.CODE_RES_WS_COMPROBANTE);
		concepto.setReturn(bean);
		when(comprobante.consultaInfoConcepto(any(), anyString())).thenReturn(concepto);

		RegistraMovimientoResponse movimiento = new RegistraMovimientoResponse();
		Respuesta res = new Respuesta();
		res.setCodError(ApiConstants.CODE_RES_WS_COMPROBANTE);
		movimiento.setReturn(res);
		when(comprobante.registraMovimiento(any(), anyString())).thenReturn(movimiento);

		ValidaComprobanteResponse valida = new ValidaComprobanteResponse();
		BeanRespuestaValidacion beanV = new BeanRespuestaValidacion();
		beanV.setCodError(ApiConstants.CODE_RES_WS_COMPROBANTE);
		beanV.setCodRespuesta("1");
		beanV.setNumCampAdicionales(1);
		beanV.setCampAdicionales("adasda||asdasd||sdfsdfs");
		valida.setReturn(beanV);
		when(comprobante.validaComprobante(any(), anyString())).thenReturn(valida);

		GeneraComprobanteResponse genera = new GeneraComprobanteResponse();
		BeanRespuestaGeneracion beanG = new BeanRespuestaGeneracion();
		bean.setCodError(ApiConstants.CODE_RES_WS_COMPROBANTE);
		genera.setReturn(beanG);
		when(comprobante.generaComprobante(any(), anyString())).thenReturn(genera);

		try {
			VoucherRequestDto voucher = new VoucherRequestDto();
			voucher.setImporte(0.0);
			voucher.setTramaAdicionalesEntrada("xxxxxx");
			ReportResponse result = service.exportarOperacionesPdf(voucher);
			Assertions.assertNotNull(result);
		} catch (Exception e) {
			Assertions.assertTrue(true);
		}
	}

}
