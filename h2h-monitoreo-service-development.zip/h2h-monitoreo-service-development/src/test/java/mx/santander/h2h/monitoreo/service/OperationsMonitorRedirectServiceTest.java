package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.model.entity.ParameterEntity;
import mx.santander.h2h.monitoreo.repository.IParameterRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

/**
 * OperationsMonitorRedirectServiceTest.
 *
 * @author Jesus Soto Aguilar
 */
@ExtendWith(MockitoExtension.class)
class OperationsMonitorRedirectServiceTest {

    @Mock
    private IParameterRepository parameterRepository;

    @InjectMocks
    private OperationsMonitorRedirectService operationsMonitorRedirectService;

    @ParameterizedTest
    @ValueSource(strings = {"80", "93", "54", "21", "22", "23", "85", "25"})
    void getNameRutaDetalleByIdProducto(String idProducto) {
        assertNotNull(operationsMonitorRedirectService.getNameRutaDetalle(idProducto));
    }

    @Test
    void getNameRutaDetalleByParam_CVE_OPER_PROD_DOMIS() {
        when(parameterRepository.findByName(anyString())).thenReturn(new ParameterEntity());
        when(parameterRepository.findByName("CVE_OPER_PROD_DOMIS")).thenReturn(getParameterEntity("1"));
        assertNotNull(operationsMonitorRedirectService.getNameRutaDetalle("1"));

    }

    @Test
    void getNameRutaDetalleByParam_CVE_OPER_PROD_MT_CNF() {
        when(parameterRepository.findByName(anyString())).thenReturn(new ParameterEntity());
        when(parameterRepository.findByName("CVE_OPER_PROD_MT_CNF")).thenReturn(getParameterEntity("1"));
        assertNotNull(operationsMonitorRedirectService.getNameRutaDetalle("1"));

    }

    @Test
    void getNameRutaDetalleByParam_CVE_OPER_PROD_I_FED() {
        when(parameterRepository.findByName(anyString())).thenReturn(new ParameterEntity());
        when(parameterRepository.findByName("CVE_OPER_PROD_I_FED")).thenReturn(getParameterEntity("1"));
        assertNotNull(operationsMonitorRedirectService.getNameRutaDetalle("1"));

    }

    @Test
    void getNameRutaDetalleByParam_CVE_OPER_PROD_P_REF() {
        when(parameterRepository.findByName(anyString())).thenReturn(new ParameterEntity());
        when(parameterRepository.findByName("CVE_OPER_PROD_P_REF")).thenReturn(getParameterEntity("1"));
        assertNotNull(operationsMonitorRedirectService.getNameRutaDetalle("1"));

    }

    @Test
    void getNameRutaDetalleByParam_CVE_OPER_PROD_A_PATR() {
        when(parameterRepository.findByName(anyString())).thenReturn(new ParameterEntity());
        when(parameterRepository.findByName("CVE_OPER_PROD_A_PATR")).thenReturn(getParameterEntity("1"));
        assertNotNull(operationsMonitorRedirectService.getNameRutaDetalle("1"));

    }

    @Test
    void getNameRutaDetalleByParam_CVE_OP_PROD_TRAN_INT() {
        when(parameterRepository.findByName(anyString())).thenReturn(new ParameterEntity());
        when(parameterRepository.findByName("CVE_OP_PROD_TRAN_INT")).thenReturn(getParameterEntity("1"));
        assertNotNull(operationsMonitorRedirectService.getNameRutaDetalle("1"));

    }

    @Test
    void getNameRutaDetalleByParam_CVE_OP_PROD_TRAN_MMB() {
        when(parameterRepository.findByName(anyString())).thenReturn(new ParameterEntity());
        when(parameterRepository.findByName("CVE_OP_PROD_TRAN_MMB")).thenReturn(getParameterEntity("1"));
        assertNotNull(operationsMonitorRedirectService.getNameRutaDetalle("1"));

    }

    @Test
    void getNameRutaDetalleByParam_CVE_OP_PROD_SPID() {
        when(parameterRepository.findByName(anyString())).thenReturn(new ParameterEntity());
        when(parameterRepository.findByName("CVE_OP_PROD_SPID")).thenReturn(getParameterEntity("1"));
        assertNotNull(operationsMonitorRedirectService.getNameRutaDetalle("1"));

    }

    @Test
    void getNameRutaDetalleByParam_CVE_PROD_PAG_DIRE() {
        when(parameterRepository.findByName(anyString())).thenReturn(new ParameterEntity());
        when(parameterRepository.findByName("CVE_PROD_PAG_DIRE")).thenReturn(getParameterEntity("1"));
        assertNotNull(operationsMonitorRedirectService.getNameRutaDetalle("1"));

    }

    @Test
    void getNameRutaDetalleDefault() {
        when(parameterRepository.findByName(anyString())).thenReturn(new ParameterEntity());
        assertNotNull(operationsMonitorRedirectService.getNameRutaDetalle("1"));

    }

    private ParameterEntity getParameterEntity(String idProducto) {
        ParameterEntity parameterEntity = new ParameterEntity();
        parameterEntity.setValue(idProducto);
        return parameterEntity;
    }

}