package mx.santander.h2h.monitoreo.model.request;

import mx.santander.h2h.monitoreo.model.response.GenerateVouchersTotalResponse;
import mx.santander.h2h.monitoreo.model.response.ParametersGetPutResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class ContractConnectionParametersManagementRequestTest {

    private ContractConnectionParametersManagementRequest contractConnectionParameters;

    @BeforeEach
    void setUp(){
        contractConnectionParameters = new ContractConnectionParametersManagementRequest();
    }

    @Test
    void allArgsConstructor(){
        contractConnectionParameters = new ContractConnectionParametersManagementRequest(
                "123", "123", "123", "123", "T", "A", new ArrayList<>());
        assertNotNull(contractConnectionParameters);
    }

    @Test
    void getNumeroContrato() {
        contractConnectionParameters.setNumeroContrato("123");
        assertEquals("123", contractConnectionParameters.getNumeroContrato());
    }

    @Test
    void getCodigoCliente() {
        contractConnectionParameters.setCodigoCliente("123");
        assertEquals("123", contractConnectionParameters.getCodigoCliente());
    }

    @Test
    void getIdProtocolo() {
        contractConnectionParameters.setIdProtocolo("123");
        assertEquals("123", contractConnectionParameters.getIdProtocolo());
    }

    @Test
    void getIdRegistro() {
        contractConnectionParameters.setIdRegistro("213");
        assertEquals("213", contractConnectionParameters.getIdRegistro());
    }

    @Test
    void getTipoProcesamiento() {
        contractConnectionParameters.setTipoProcesamiento("T");
        assertEquals("T", contractConnectionParameters.getTipoProcesamiento());
    }

    @Test
    void getEstadoValor() {
        contractConnectionParameters.setEstadoValor("A");
        assertEquals("A", contractConnectionParameters.getEstadoValor());
    }

    @Test
    void getParametrosGetPut() {
        ArrayList<ParametersGetPutResponse> parametersGetPutResponses =
                new ArrayList<>();
        contractConnectionParameters.setParametrosGetPut(parametersGetPutResponses);
        assertEquals(parametersGetPutResponses, contractConnectionParameters.getParametrosGetPut());
    }

    @Test
    void testToString() {
    	getGenerateVouchersTotalResponse();
    	
        assertNotNull(contractConnectionParameters.toString());
    }
    
    private GenerateVouchersTotalResponse getGenerateVouchersTotalResponse() {
    	GenerateVouchersTotalResponse response = new GenerateVouchersTotalResponse();
    	response.setCorreosEnviados(null);
    	response.setImporteGlobal(null);
    	response.setTotalArchivos(null);
    	
    	response.getCorreosEnviados();
    	response.getImporteGlobal();
    	response.getTotalArchivos();
    	
    	response.toString();
    	
    	return response;
    	
    }
}