package mx.santander.h2h.monitoreo.utils;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.response.PutGetDto;
import mx.santander.h2h.monitoreo.model.response.PutGetServiceResponse;
import mx.santander.h2h.monitoreo.service.ContractConnectionManagementPutGetDeleteDataService;

@ExtendWith(MockitoExtension.class)
class ContractConnectionManagementPutGetDeleteDataServiceTest {

	private static final String MSJ_ERROR = "ERROR";

	private static final int VALOR_ENTERO_DOS = 2;

	@InjectMocks
	ContractConnectionManagementPutGetDeleteDataService contractConnectionManagementPutGetDeleteDataUtils;

	@Mock
	EntityManager entityManager;

	@Mock
	Query query;

	@Test
	void eliminaDatisSiesalta() {

		PutGetServiceResponse putGetServiceResponse = crearPutGetServiceResponse();

		contractConnectionManagementPutGetDeleteDataUtils.eliminaDatosSiEsAlta(putGetServiceResponse, "A");

		assertNotNull(putGetServiceResponse);

	}

	@Test
	void eliminaDatisSiesaltaStatusI() {

		PutGetServiceResponse putGetServiceResponse = crearPutGetServiceResponse();

		contractConnectionManagementPutGetDeleteDataUtils.eliminaDatosSiEsAlta(putGetServiceResponse, "I");

		assertNotNull(putGetServiceResponse);

	}

	@Test
	void eliminaValoresnuevoReg() {

		PutGetServiceResponse putGetServiceResponse = crearPutGetServiceResponse();

		contractConnectionManagementPutGetDeleteDataUtils.eliminaValoresnuevoReg(putGetServiceResponse);

		assertNotNull(putGetServiceResponse);

	}

	@Test
	void eliminaInformacion() {

		PutGetServiceResponse putGetServiceResponse = crearPutGetServiceResponse();

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);

		when(query.setParameter(anyString(), any())).thenReturn(query);

		when(query.executeUpdate()).thenReturn(VALOR_ENTERO_DOS);

		contractConnectionManagementPutGetDeleteDataUtils.eliminaInformacion(putGetServiceResponse);

		assertNotNull(putGetServiceResponse);

	}

	@Test
	void eliminaInformacionExceptionSftpCD() {

		PutGetServiceResponse putGetServiceResponse = crearPutGetServiceResponse();

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);

		when(query.setParameter(anyString(), any())).thenReturn(query);

		doThrow(new BusinessException(MSJ_ERROR)).when(query).executeUpdate();

		assertThrows(BusinessException.class,
				() -> contractConnectionManagementPutGetDeleteDataUtils.eliminaInformacion(putGetServiceResponse));

	}

	@Test
	void eliminaInformacionExceptionParaCD() {

		PutGetServiceResponse putGetServiceResponse = crearPutGetServiceResponse();

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);

		when(query.setParameter(anyString(), any())).thenReturn(query);

		when(query.executeUpdate()).thenReturn(VALOR_ENTERO_DOS).thenThrow(new BusinessException(MSJ_ERROR));

		assertThrows(BusinessException.class,
				() -> contractConnectionManagementPutGetDeleteDataUtils.eliminaInformacion(putGetServiceResponse));

	}

	@Test
	void eliminaInformacionExceptionSftp() {

		PutGetServiceResponse putGetServiceResponse = crearPutGetServiceResponse();

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);

		when(query.setParameter(anyString(), any())).thenReturn(query);

		when(query.executeUpdate()).thenReturn(VALOR_ENTERO_DOS).thenReturn(VALOR_ENTERO_DOS)
				.thenThrow(new BusinessException(MSJ_ERROR));

		assertThrows(BusinessException.class,
				() -> contractConnectionManagementPutGetDeleteDataUtils.eliminaInformacion(putGetServiceResponse));

	}

	@Test
	void eliminaInformacionExceptionWebService() {

		PutGetServiceResponse putGetServiceResponse = crearPutGetServiceResponse();

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);

		when(query.setParameter(anyString(), any())).thenReturn(query);

		when(query.executeUpdate()).thenReturn(VALOR_ENTERO_DOS).thenReturn(VALOR_ENTERO_DOS)
				.thenReturn(VALOR_ENTERO_DOS).thenThrow(new BusinessException(MSJ_ERROR));

		assertThrows(BusinessException.class,
				() -> contractConnectionManagementPutGetDeleteDataUtils.eliminaInformacion(putGetServiceResponse));

	}

	@Test
	void eliminaInformacionExceptionPtclPara() {

		PutGetServiceResponse putGetServiceResponse = crearPutGetServiceResponse();

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);

		when(query.setParameter(anyString(), any())).thenReturn(query);

		when(query.executeUpdate()).thenReturn(VALOR_ENTERO_DOS).thenReturn(VALOR_ENTERO_DOS)
				.thenReturn(VALOR_ENTERO_DOS).thenReturn(VALOR_ENTERO_DOS)
				.thenThrow(new BusinessException(MSJ_ERROR));

		assertThrows(BusinessException.class,
				() -> contractConnectionManagementPutGetDeleteDataUtils.eliminaInformacion(putGetServiceResponse));

	}

	/**
	 * @return
	 */
	private PutGetServiceResponse crearPutGetServiceResponse() {

		PutGetServiceResponse putGetServiceResponse = new PutGetServiceResponse();

		ArrayList<PutGetDto> listPutGetDtoResponse = crearListaPutGetDtoResponse();

		putGetServiceResponse.setRegistrosPG(listPutGetDtoResponse);

		return putGetServiceResponse;
	}

	/**
	 * @return
	 */
	private ArrayList<PutGetDto> crearListaPutGetDtoResponse() {

		ArrayList<PutGetDto> listPutGetDtoResponse = new ArrayList<PutGetDto>();

		PutGetDto putGetDtoResponse = crearPutGetDtoResponse();

		listPutGetDtoResponse.add(putGetDtoResponse);
		listPutGetDtoResponse.add(putGetDtoResponse);

		return listPutGetDtoResponse;
	}

	/**
	 * @return
	 */
	private PutGetDto crearPutGetDtoResponse() {

		PutGetDto putGetDtoResponse = new PutGetDto();

		putGetDtoResponse.setDirectorio("directorio");
		putGetDtoResponse.setDirectorioGet("directorioGet");
		putGetDtoResponse.setIdContrato("97");
		putGetDtoResponse.setPatronGet("patronGet");

		return putGetDtoResponse;
	}

}
