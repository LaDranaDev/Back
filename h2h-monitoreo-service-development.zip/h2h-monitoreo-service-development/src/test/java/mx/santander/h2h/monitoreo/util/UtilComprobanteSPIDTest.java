package mx.santander.h2h.monitoreo.util;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Collections;

class UtilComprobanteSPIDTest {

    @Test
    void testObtenerQuerySpid() {
        String result = UtilComprobanteSPID.obtenerQuerySpid(Collections.singletonList(1));
        Assertions.assertNotNull(result);
    }
}
