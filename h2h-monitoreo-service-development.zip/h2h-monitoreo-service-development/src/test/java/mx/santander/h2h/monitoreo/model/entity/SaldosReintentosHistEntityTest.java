package mx.santander.h2h.monitoreo.model.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
class SaldosReintentosHistEntityTest {

    private SaldosReintentosHistEntity saldosReintentosHistEntity;

    @BeforeEach
    void setUp(){
        saldosReintentosHistEntity = new SaldosReintentosHistEntity();
    }

    @Test
    void getIdSaldosReintentos() {
        saldosReintentosHistEntity.setIdSaldosReintentos(1L);
        assertEquals(1L, saldosReintentosHistEntity.getIdSaldosReintentos());
    }

    @Test
    void getNumCtaOrdenante() {
        saldosReintentosHistEntity.setNumCtaOrdenante("1234");
        assertEquals("1234", saldosReintentosHistEntity.getNumCtaOrdenante());
    }

    @Test
    void getSaldo() {
        saldosReintentosHistEntity.setSaldo(BigDecimal.ZERO);
        assertEquals(BigDecimal.ZERO, saldosReintentosHistEntity.getSaldo());
    }

    @Test
    void getFechaConsulta() {
        LocalDate fecha = LocalDate.parse("2023-04-19");
        saldosReintentosHistEntity.setFechaConsulta(fecha);
        assertEquals(fecha, saldosReintentosHistEntity.getFechaConsulta());
    }

    @Test
    void getArchivoEntity() {
        ArchivoHistEntity archivoEntity = mock(ArchivoHistEntity.class);
        saldosReintentosHistEntity.setArchivoHistEntity(archivoEntity);
        assertEquals(archivoEntity, saldosReintentosHistEntity.getArchivoHistEntity());
    }

    @Test
    void getMontoRequerido() {
        saldosReintentosHistEntity.setMontoRequerido(BigDecimal.ZERO);
        assertEquals(BigDecimal.ZERO, saldosReintentosHistEntity.getMontoRequerido());
    }

    @Test
    void getLineaCredito() {
        saldosReintentosHistEntity.setLineaCredito('T');
        assertEquals('T', saldosReintentosHistEntity.getLineaCredito());
    }

    @Test
    void getClaveProducto() {
        saldosReintentosHistEntity.setClaveProducto("cveProd");
        assertEquals("cveProd", saldosReintentosHistEntity.getClaveProducto());
    }

}