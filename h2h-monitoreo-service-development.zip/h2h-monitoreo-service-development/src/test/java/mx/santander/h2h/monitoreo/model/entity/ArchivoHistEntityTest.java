package mx.santander.h2h.monitoreo.model.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
class ArchivoHistEntityTest {

    private ArchivoHistEntity archivoHistEntity;

    @BeforeEach
    void setUp(){
        archivoHistEntity = new ArchivoHistEntity();
    }

    @Test
    void getIdArchivo() {
        archivoHistEntity.setIdArchivo(123L);
        assertEquals(123L, archivoHistEntity.getIdArchivo());
    }

    @Test
    void getNombreArchivo() {
        archivoHistEntity.setNombreArchivo("nombreArchivo");
        assertEquals("nombreArchivo", archivoHistEntity.getNombreArchivo());
    }

    @Test
    void getIdLayout() {
        archivoHistEntity.setIdLayout(123L);
        assertEquals(123L, archivoHistEntity.getIdLayout());
    }

    @Test
    void getIdStatus() {
        archivoHistEntity.setIdStatus(123L);
        assertEquals(123L, archivoHistEntity.getIdStatus());
    }

    @Test
    void getContractEntity() {
        ContractEntity contractEntity = mock(ContractEntity.class);
        archivoHistEntity.setContractEntity(contractEntity);
        assertEquals(contractEntity, archivoHistEntity.getContractEntity());
    }

    @Test
    void getTamano() {
        archivoHistEntity.setTamano(123L);
        assertEquals(123L, archivoHistEntity.getTamano());
    }

    @Test
    void getBandEnrollment() {
        archivoHistEntity.setBandEnrollment('A');
        assertEquals('A', archivoHistEntity.getBandEnrollment());
    }

    @Test
    void getFechaRegistro() {
        LocalDate date = LocalDate.parse("2023-04-19");
        archivoHistEntity.setFechaRegistro(date);
        assertEquals(date, archivoHistEntity.getFechaRegistro());
    }

    @Test
    void getTotoalProductos() {
        archivoHistEntity.setTotoalProductos(123);
        assertEquals(123, archivoHistEntity.getTotoalProductos());
    }

    @Test
    void getBandFondeo() {
        archivoHistEntity.setBandFondeo('T');
        assertEquals('T', archivoHistEntity.getBandFondeo());
    }

    @Test
    void getIdCanal() {
        archivoHistEntity.setIdCanal(123);
        assertEquals(123, archivoHistEntity.getIdCanal());
    }

    @Test
    void getIdCatProcesamiento() {
        archivoHistEntity.setIdCatProcesamiento(123L);
        assertEquals(123L, archivoHistEntity.getIdCatProcesamiento());
    }

    @Test
    void getIdProcesoRegistro() {
        archivoHistEntity.setIdProcesoRegistro(123L);
        assertEquals(123L, archivoHistEntity.getIdProcesoRegistro());
    }

    @Test
    void getBandCierre() {
        archivoHistEntity.setBandCierre('A');
        assertEquals('A', archivoHistEntity.getBandCierre());
    }

    @Test
    void getBandCifrado() {
        archivoHistEntity.setBandCifrado('A');
        assertEquals('A', archivoHistEntity.getBandCifrado());
    }

    @Test
    void getTotalOperaciones() {
        archivoHistEntity.setTotalOperaciones(123);
        assertEquals(123, archivoHistEntity.getTotalOperaciones());
    }

    @Test
    void getTotalMonto() {
        archivoHistEntity.setTotalMonto(BigDecimal.ZERO);
        assertEquals(BigDecimal.ZERO, archivoHistEntity.getTotalMonto());
    }

    @Test
    void getMbxMsgId() {
        archivoHistEntity.setMbxMsgId(123);
        assertEquals(123, archivoHistEntity.getMbxMsgId());
    }

    @Test
    void getNotMsgId() {
        archivoHistEntity.setNotMsgId(123);
        assertEquals(123, archivoHistEntity.getNotMsgId());
    }

    @Test
    void getBandDispWeb() {
        archivoHistEntity.setBandDispWeb('N');
        assertEquals('N', archivoHistEntity.getBandDispWeb());
    }

    @Test
    void getIdMensaje() {
        archivoHistEntity.setIdMensaje(123);
        assertEquals(123, archivoHistEntity.getIdMensaje());
    }

    @Test
    void getBandDispWebClte() {
        archivoHistEntity.setBandDispWebClte('N');
        assertEquals('N', archivoHistEntity.getBandDispWebClte());
    }

    @Test
    void getDivisa() {
        archivoHistEntity.setDivisa('T');
        assertEquals('T', archivoHistEntity.getDivisa());
    }

    @Test
    void getNumSerieCert() {
        archivoHistEntity.setNumSerieCert("1234");
        assertEquals("1234", archivoHistEntity.getNumSerieCert());
    }

    @Test
    void getHashCifrado() {
        archivoHistEntity.setHashCifrado("hashArchivo");
        assertEquals("hashArchivo", archivoHistEntity.getHashCifrado());
    }

    @Test
    void getHashArchivo() {
        archivoHistEntity.setHashArchivo("hashArchivo");
        assertEquals("hashArchivo", archivoHistEntity.getHashArchivo());
    }

    @Test
    void getMbxMsgIdCifr() {
        archivoHistEntity.setMbxMsgIdCifr(123);
        assertEquals(123, archivoHistEntity.getMbxMsgIdCifr());
    }

    @Test
    void getMotivoRechDupl() {
        archivoHistEntity.setMotivoRechDupl("motivo");
        assertEquals("motivo", archivoHistEntity.getMotivoRechDupl());
    }

    @Test
    void getIdArchDupl() {
        archivoHistEntity.setIdArchDupl(123);
        assertEquals(123, archivoHistEntity.getIdArchDupl());
    }

    @Test
    void getEncodingArchivo() {
        archivoHistEntity.setEncodingArchivo("UTF-8");
        assertEquals("UTF-8", archivoHistEntity.getEncodingArchivo());
    }

}