package mx.santander.h2h.monitoreo.model.response;


import mx.santander.h2h.monitoreo.util.JavaBeanTester;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNotNull;

/**
 * ContractConnectionManagementResponseTest.
 *
 * @author Jesus Soto Aguilar
 * @since 04/05/2023
 */
class ContractConnectionManagementResponseTest {

    @Test
    void testFields() {
        Assertions.assertDoesNotThrow(() ->
                JavaBeanTester.test(ContractConnectionManagementResponse.class)
        );
    }

    @Test
    void toStringTest() {
        ContractConnectionManagementResponse response = new ContractConnectionManagementResponse();
        assertNotNull(response.toString());
    }
}