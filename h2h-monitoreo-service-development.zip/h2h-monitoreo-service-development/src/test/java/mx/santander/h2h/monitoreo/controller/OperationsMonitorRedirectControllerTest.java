package mx.santander.h2h.monitoreo.controller;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import mx.santander.h2h.monitoreo.service.IOperationsMonitorRedirectService;

/**
 * OperationsMonitorRedirectControllerTest.
 *
 * @author Jesus Soto Aguilar
 */
@ContextConfiguration(classes = {OperationsMonitorRedirectController.class})
class OperationsMonitorRedirectControllerTest {

    @Mock
    private IOperationsMonitorRedirectService operationsMonitorRedirectService;

    @InjectMocks
    private OperationsMonitorRedirectController operationsMonitorRedirectController;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp(){
        MockitoAnnotations.openMocks(this);
        this.mockMvc = MockMvcBuilders
                .standaloneSetup(operationsMonitorRedirectController).build();
    }

    @Test
    void getRutaDetalleOperacionesProducto() throws Exception {
        when(operationsMonitorRedirectService.getNameRutaDetalle(anyString()))
                .thenReturn("NOMBRE_VISTA");

        mockMvc.perform(get("/monitorOperaciones/detalle/80").contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
}