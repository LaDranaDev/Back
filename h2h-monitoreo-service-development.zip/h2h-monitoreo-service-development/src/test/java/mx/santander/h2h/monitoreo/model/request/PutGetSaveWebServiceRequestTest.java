package mx.santander.h2h.monitoreo.model.request;

import static org.hibernate.validator.internal.util.Contracts.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * @author sbautish
 *
 */
@ExtendWith(MockitoExtension.class)
class PutGetSaveWebServiceRequestTest {

	@InjectMocks
	PutGetSaveWebServiceRequest putGetSaveWebServiceRequest;

	@BeforeEach
	void setUp() {
		putGetSaveWebServiceRequest = new PutGetSaveWebServiceRequest();
	}

	@Test
	void allArgsConstuction() {
		putGetSaveWebServiceRequest = new PutGetSaveWebServiceRequest("wsportPutGet", "wsipserverPutGet", "wsrutaPut",
				"wsrutaGet", "wspatronPutGet", "wspatronGetPutGet", "wsuriPut", "wsuriGet", "wsurldestPutGet",
				"wscertPutGet");
		assertNotNull(putGetSaveWebServiceRequest);
	}

	@Test
	void getWsportPutGet() {
		putGetSaveWebServiceRequest.setWsportPutGet("wsportPutGet");
		assertEquals("wsportPutGet", putGetSaveWebServiceRequest.getWsportPutGet());
	}

	@Test
	void getWsipserverPutGet() {
		putGetSaveWebServiceRequest.setWsipserverPutGet("wsipserverPutGet");
		assertEquals("wsipserverPutGet", putGetSaveWebServiceRequest.getWsipserverPutGet());
	}

	@Test
	void getWsrutaPut() {
		putGetSaveWebServiceRequest.setWsrutaPut("wsrutaPut");
		assertEquals("wsrutaPut", putGetSaveWebServiceRequest.getWsrutaPut());
	}

	@Test
	void getWsrutaGet() {
		putGetSaveWebServiceRequest.setWsrutaGet("wsrutaGet");
		assertEquals("wsrutaGet", putGetSaveWebServiceRequest.getWsrutaGet());
	}

	@Test
	void getWspatronPutGet() {
		putGetSaveWebServiceRequest.setWspatronPutGet("wspatronPutGet");
		assertEquals("wspatronPutGet", putGetSaveWebServiceRequest.getWspatronPutGet());
	}

	@Test
	void getWspatronGetPutGet() {
		putGetSaveWebServiceRequest.setWspatronGetPutGet("wspatronGetPutGet");
		assertEquals("wspatronGetPutGet", putGetSaveWebServiceRequest.getWspatronGetPutGet());
	}

	@Test
	void getWsuriPut() {
		putGetSaveWebServiceRequest.setWsuriPut("wsuriPut");
		assertEquals("wsuriPut", putGetSaveWebServiceRequest.getWsuriPut());
	}

	@Test
	void getWsuriGet() {
		putGetSaveWebServiceRequest.setWsuriGet("wsuriGet");
		assertEquals("wsuriGet", putGetSaveWebServiceRequest.getWsuriGet());
	}

	@Test
	void getWsurldestPutGet() {
		putGetSaveWebServiceRequest.setWsurldestPutGet("wsurldestPutGet");
		assertEquals("wsurldestPutGet", putGetSaveWebServiceRequest.getWsurldestPutGet());
	}

	@Test
	void getWscertPutGet() {
		putGetSaveWebServiceRequest.setWscertPutGet("wscertPutGet");
		assertEquals("wscertPutGet", putGetSaveWebServiceRequest.getWscertPutGet());
	}

	@Test
	void testToString() {
		assertNotNull(putGetSaveWebServiceRequest.toString());
	}

}
