package mx.santander.h2h.monitoreo.util;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Collections;

class UtilComprobanteTITest {

    @Test
    void testObtenerQueryTranasferenciasInernacionales() {
        String result = UtilComprobanteTI.obtenerQueryTranasferenciasInernacionales(Collections.singletonList(1));
        Assertions.assertNotNull(result);
    }

    @Test
    void testObtenerQueryTranasferenciasIntMBC() {
        String result = UtilComprobanteTI.obtenerQueryTranasferenciasIntMBC(Collections.singletonList(1));
        Assertions.assertNotNull(result);
    }
}
