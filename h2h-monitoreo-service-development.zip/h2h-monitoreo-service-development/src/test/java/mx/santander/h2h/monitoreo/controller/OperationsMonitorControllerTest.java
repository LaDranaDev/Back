package mx.santander.h2h.monitoreo.controller;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.OperationsHistoryResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorCatalogsYHorasResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorTotalResponse;
import mx.santander.h2h.monitoreo.service.IComprobanteService;
import mx.santander.h2h.monitoreo.service.IOperationsMonitorService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.List;

import static org.mockito.Mockito.*;

class OperationsMonitorControllerTest {
    @Mock
    IOperationsMonitorService service;
    @Mock

    IComprobanteService comprobanteService;
    @InjectMocks
    OperationsMonitorController operationsMonitorController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testConsulta() {
        Page<OperationsMonitorQueryResponse> responsePage = Page.empty();
        when(service.consulta(any(), any())).thenReturn(responsePage);

        ResponseEntity<Page<OperationsMonitorQueryResponse>> result = operationsMonitorController.consulta(new OperationsMonitorQueryRequest(), null);
        Assertions.assertEquals(responsePage, result.getBody());
    }

    @Test
    void testTotal() {
        OperationsMonitorTotalResponse response = new OperationsMonitorTotalResponse();
        when(service.total(any())).thenReturn(response);

        ResponseEntity<OperationsMonitorTotalResponse> result = operationsMonitorController.total(new OperationsMonitorQueryRequest());
        Assertions.assertEquals(response, result.getBody());
    }

    @Test
    void testConsultaExcel() {
        ReportResponse reportResponse = new ReportResponse("data", Integer.valueOf(0), "name", "type");
        when(service.reporte(any(), anyString())).thenReturn(reportResponse);

        ResponseEntity<ReportResponse> result = operationsMonitorController.consultaExcel(new OperationsMonitorQueryRequest());
        Assertions.assertEquals(reportResponse, result.getBody());
    }

    @Test
    void testComprobantes() {
        ReportResponse response = new ReportResponse();
        when(comprobanteService.comprobantes(any(), any())).thenReturn(response);
        ResponseEntity<ReportResponse> result = operationsMonitorController.comprobantes(Collections.emptyList(), "format");
        Assertions.assertEquals(response, result.getBody());
    }


    @Test
    void testCatalogs() {
    	OperationsMonitorCatalogsYHorasResponse response = new OperationsMonitorCatalogsYHorasResponse();
        when(service.catalogsConsultaTrackingArchivo()).thenReturn(response);

        ResponseEntity<OperationsMonitorCatalogsYHorasResponse> result = operationsMonitorController.catalogs();
        Assertions.assertEquals(response, result.getBody());
    }

    @Test
    void testDetalleOperacion() {
        OperationsMonitorQueryResponse response = new OperationsMonitorQueryResponse();
        when(service.obtenerDetalleOperacion(any(), any())).thenReturn(response);

        ResponseEntity<OperationsMonitorQueryResponse> result = operationsMonitorController.detalleOperacion(new OperationsMonitorQueryResponse());
        Assertions.assertEquals(response, result.getBody());
    }

    @Test
    void testHistorialOperacion() {
        List<OperationsHistoryResponse> response = Collections.emptyList();
        when(service.obtenerHistorialOperacion(any())).thenReturn(response);

        ResponseEntity<List<OperationsHistoryResponse>> result = operationsMonitorController.historialOperacion("idOperacion");
        Assertions.assertEquals(response, result.getBody());
    }

    @Test
    void testReporteHistorialOperacion() {
        ReportResponse response = new ReportResponse();
        when(service.reporteHistorialOperacion(any(), any())).thenReturn(response);

        ResponseEntity<ReportResponse> result = operationsMonitorController.reporteHistorialOperacion("idOperacion", "usuario");
        Assertions.assertEquals(response, result.getBody());
    }

    @Test
    void testCambiarEstatus() {
        when(service.cambiarEstatusOperacion(any(), any(), any())).thenReturn(true);

        ResponseEntity<Boolean> result = operationsMonitorController.cambiarEstatus(new OperationsMonitorQueryResponse());
        Assertions.assertEquals(Boolean.TRUE, result.getBody());
    }

    @Test
    void testConsultarHorario() {
        when(service.consultarHorario(any())).thenReturn(true);

        ResponseEntity<Boolean> result = operationsMonitorController.consultarHorario("producto");
        Assertions.assertEquals(Boolean.TRUE, result.getBody());
    }

}
