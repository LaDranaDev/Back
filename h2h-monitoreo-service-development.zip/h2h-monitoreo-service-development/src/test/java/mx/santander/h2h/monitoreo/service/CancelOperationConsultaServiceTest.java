package mx.santander.h2h.monitoreo.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import mx.santander.h2h.monitoreo.model.entity.ParameterEntity;
import mx.santander.h2h.monitoreo.model.response.CancelOperationResponse;
import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import mx.santander.h2h.monitoreo.repository.ICatalogoEstatusRepository;
import mx.santander.h2h.monitoreo.repository.IContractRepository;
import mx.santander.h2h.monitoreo.repository.IParameterRepository;


@ExtendWith(MockitoExtension.class)
class CancelOperationConsultaServiceTest {

	@InjectMocks
    private CancelOperationConsultaService repository;
	
	@Mock
	public IParameterRepository paramRepository;
	
	@Mock
	private ICatalogoEstatusRepository catalogoEstatusRepository;
	
	@Mock
	private IContractRepository contractRepository;
	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testConsultaCancelNull() {
		CancelOperationResponse resp = null;
		ComboResponse c = new ComboResponse();
		c.setId(1);
		c.setValor("test");
		List<ComboResponse> listaComboEstatus = new ArrayList<>();
		listaComboEstatus.add(c);
		List<Object[]> resultQueryCntr = new ArrayList<>();
//		when(contractRepository.findCntrByBUCAndEstatus("856748", 1)).thenReturn(resultQueryCntr);
		try {
			resp = repository.consultaCancel(null);
		} catch(Exception e) {}
		assertNull(resp);
	}
	
	@Test
	void testConsultaCancelVacio() {
		CancelOperationResponse resp = null;
		try {
			resp = repository.consultaCancel("");
		} catch(Exception e) {}
		assertNull(resp);
	}
	
	@Test
	void testConsultaCancel() {
		when( paramRepository.findByName(anyString()) ).thenReturn( new ParameterEntity() );
		
		CancelOperationResponse resp = null;
		try {
			resp = repository.consultaCancel("123456");
		} catch(Exception e) {}
		
		if( resp == null) {
			assertNull(resp);
		} else {
			assertNotNull(resp);
		}
	}
}
