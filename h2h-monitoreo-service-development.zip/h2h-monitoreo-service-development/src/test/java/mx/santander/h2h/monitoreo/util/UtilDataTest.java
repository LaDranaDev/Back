/**
* Santander SCIB - Banco Santander Negocios Globales
* Todos los derechos reservados
* UtilDataTest.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <12 jul. 2024 19:58:04>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import lombok.extern.slf4j.Slf4j;


/** Declaracion de Constante log. */
@Slf4j
@ExtendWith(MockitoExtension.class)
class UtilDataTest {

	/** Declaracion de Object[] para objStr. */
	private final Object[] objStr = {null, "", "Hola Mundo", "$#\"$%&", 1234, 13.10, 234553453.098};
	private final Object[] archivos = {null, "", " ", "   .    ", "   .txt", 
				"archivo", "archivo.", ".archivo", "archivo.txt", "archivo.archivo.txt"};
	
	private final String[] compara = {"hola", "dos", "cero"};
	private final String[] datCompara = {"ola", "holis", "hola", "2", "02", "dos", "0", "Zero", "cero", ""};
	
	@BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
	
	
	/**
	 * Test val data.
	 */
	@Test
	void testValData() {
		log.info("--- CADENA -----------------------------------");
		String cadResp = "";
		for( Object obj : objStr) {
			cadResp = UtilData.toString(obj);
			log.info("Cadena: [ "+ cadResp +" ]");
			assertNotNull(cadResp);	
		}
		
	}
	
	/**
	 * Test valnteger.
	 */
	@Test
	void testValnteger() {
		log.info("---- INTEGER ----------------------------------");
		int cadResp = 0;
		for( Object obj : objStr) {
			cadResp = UtilData.toInt(obj);
			log.info(" Entero: [ "+ cadResp +" ]");
			String val1 = String.valueOf(cadResp);
			String val2 =  "";
			try {
				val2 =String.valueOf( obj.toString() );
			} catch(Exception e) {
				val2 = "";
			}
			if( val1.equals(val2)  ) {
				assertEquals(val1, val2);
			} else {
				assertNotEquals(val1, val2);
			}
			
		}
		
	}
	
	/**
	 * Test val double.
	 */
	@Test
	void testValDouble() {
		log.info("---- DOUBLE ----------------------------------");
		Double cadResp = 0.0;
		for( Object obj : objStr) {
			cadResp = UtilData.toDouble(obj);
			log.info("Double: [ "+ cadResp +" ]");
			assertNotNull( cadResp );	
		}
		
	}
	
	
	/**
	 * Test val long.
	 */
	@Test
	void testValLong() {
		log.info("--- LONG -----------------------------------");
		Long cadResp = 0L;
		for( Object obj : objStr) {
			cadResp = UtilData.toLong(obj);
			log.info("Double: [ "+ cadResp +" ]");
			assertNotNull( cadResp );	
		}
		
	}
	
	
	/**
	 * Test val big decimal.
	 */
	@Test
	void testValBigDecimal() {
		log.info("--- BIGDECIMAL -----------------------------------");
		BigDecimal cadResp = BigDecimal.valueOf( Double.parseDouble("0.0") );
		for( Object obj : objStr) {
			cadResp = UtilData.toBigDecimal(obj);
			log.info(" BigDecimal: [ "+ cadResp +" ]");
			assertNotNull( cadResp );	
		}
	}
	
	
	/**
	 * Test para validar si es Vacio los datos del campo
	 */
	@Test
	void testIsVacio() {
		log.info("--- BIGDECIMAL -----------------------------------");
		boolean cadResp = false;
		for( Object obj : objStr) {
			cadResp = UtilData.isVacio(obj);
			if( cadResp ) {
				assertTrue(cadResp);
			} else {
				assertFalse(cadResp);
			}
		}
	}
	
	
	/**
	 * Test para validar si dos cadenas son iguales
	 */
	@Test
	void testEsIgual() {
		log.info("--- ES IGUAL -----------------------------------");
		boolean cadResp = false;
		for( Object objCmp : compara) {
			for( Object objVal : datCompara) {
				cadResp = UtilData.esIgual(objCmp, objVal.toString());
			if( cadResp ) {
					log.info(objCmp.toString()+ " === "+ objVal.toString());
				assertTrue(cadResp);
			} else {
					log.info(objCmp.toString()+ " =/= "+ objVal.toString());
				assertFalse(cadResp);
				}
			}
		}
	}
}
