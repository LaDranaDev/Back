package mx.santander.h2h.monitoreo.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import mx.santander.h2h.monitoreo.model.request.ArchivoCancelRequest;
import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import mx.santander.h2h.monitoreo.service.ICancelOperationBaseService;
import mx.santander.h2h.monitoreo.service.ICancelOperationConsultaService;
import mx.santander.h2h.monitoreo.service.ICancelOperationService;

class OperationCancelControllerTest {

    @Mock
    private ICancelOperationService service;
    
    @Mock
    private ICancelOperationBaseService serviceBase;
    
    @Mock
    private ICancelOperationConsultaService serviceConsulta;

    @InjectMocks
    OperationCancelController controller;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetCancelOperationSearch() {
    	Assertions.assertNotNull(controller.getCancelOperationSearch("22345678"));
    }

    @Test
    void getCancelArchiveSearch(){
        Assertions.assertNotNull(controller.getCancelArchiveSearch(archivCancel(), Pageable.ofSize(1)));
    }
    @Test
    void cancelaOperacion(){
        String idRegistros = "12,13,14,15";
        Assertions.assertNotNull(controller.cancelaOperacion(idRegistros,archivCancel()));
    }

    @Test
    void testGetComboEstatusCentro(){
    	ResponseEntity<List<ComboResponse>> response = null;
    	try {
    		response = controller.getComboEstatusCentro();
    	} catch(Exception e) {}
        
        if( response == null ) {
    		assertNull(response);
    	} else {
    		assertNotNull(response);
    	}
    }

    @Test
    void getListaEstus(){
        Assertions.assertNotNull(controller.getListaEstus());
    }

    private ArchivoCancelRequest archivCancel(){
        ArchivoCancelRequest request = new ArchivoCancelRequest();
        return request;
    }

}