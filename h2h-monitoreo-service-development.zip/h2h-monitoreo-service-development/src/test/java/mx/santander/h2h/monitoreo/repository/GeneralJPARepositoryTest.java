package mx.santander.h2h.monitoreo.repository;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.RETURNS_MOCKS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

@ExtendWith(MockitoExtension.class)
class GeneralJPARepositoryTest {

	@Mock
    private EntityManager entityManager;
	
	@InjectMocks
	private GeneralJPARepository repository;
	
	@Test
	void test() {
		Query query = mock(Query.class, RETURNS_MOCKS);
		when(entityManager.createNativeQuery(anyString()))
        .thenReturn(query);
		
		when(query.getSingleResult()).thenReturn(new BigDecimal("2"));
		
		assertDoesNotThrow(() -> repository.conteoResgistros("H2H_TABLA"));
	}

	@Test
	void test2() {
		Query query = mock(Query.class, RETURNS_MOCKS);
		when(entityManager.createNativeQuery(anyString()))
        .thenReturn(query);
		
		when(query.getSingleResult()).thenReturn(new BigDecimal("3000.0"));
		
		assertDoesNotThrow(() -> repository.conteoResgistros("H2H_TABLA"));
	}
}
