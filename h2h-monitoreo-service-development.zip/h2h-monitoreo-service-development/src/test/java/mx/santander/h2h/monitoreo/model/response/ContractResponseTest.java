package mx.santander.h2h.monitoreo.model.response;

import mx.santander.h2h.monitoreo.util.JavaBeanTester;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

/**
 * ContractResponseTest.
 *
 * @author Jesus Soto Aguilar
 * @since 04/05/2023
 */
class ContractResponseTest {

    @Test
    void testFields() {
        assertDoesNotThrow(() ->
                JavaBeanTester.test(ContractResponse.class)
        );
    }
}