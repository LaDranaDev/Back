package mx.santander.h2h.monitoreo.util;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

class UtilComprobantePDTest {

    @Test
    void testObtenerQuery() {
        String result = UtilComprobantePD.obtenerQuery(Arrays.asList(1, 2));
        Assertions.assertNotNull(result);
    }

}
