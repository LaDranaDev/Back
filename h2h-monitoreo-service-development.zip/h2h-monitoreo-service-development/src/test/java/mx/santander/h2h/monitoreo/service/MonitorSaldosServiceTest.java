package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.model.mapper.MonitorSaldosModelMapping;
import mx.santander.h2h.monitoreo.model.request.MonitorSaldosRequest;
import mx.santander.h2h.monitoreo.model.request.PistaAuditoriaRequest;
import mx.santander.h2h.monitoreo.model.response.MonitorSaldosResponse;
import mx.santander.h2h.monitoreo.repository.IMonitorSaldosManagerRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import jakarta.persistence.Tuple;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_MOCKS;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MonitorSaldosServiceTest {

    @Mock
    private IMonitorSaldosManagerRepository monitorSaldosManagerRepository;

    @Mock
    private PistaAuditoriaService pistaAuditoriaService;

    @InjectMocks
    private MonitorSaldosService monitorSaldosService;

    private MockedStatic<MonitorSaldosModelMapping> monitorSaldosModelMapping;

    @BeforeEach
    void setUp(){
        monitorSaldosModelMapping = mockStatic(MonitorSaldosModelMapping.class);
    }

    @AfterEach
    void after(){
        monitorSaldosModelMapping.close();
    }

    @Test
    void getSaldosReintentosClientePaged() {
        MonitorSaldosRequest request = mock(MonitorSaldosRequest.class);
        Pageable pageable = mock(Pageable.class);
        List<Tuple> data = new ArrayList<>();
        Tuple registro = mock(Tuple.class, RETURNS_MOCKS);
        data.add(registro);
        Page<Tuple> dataSaldos = new PageImpl<>(data);
        List<MonitorSaldosResponse> saldosReintentos = new ArrayList<>();
        saldosReintentos.add(mock(MonitorSaldosResponse.class));

        monitorSaldosModelMapping.when(() -> MonitorSaldosModelMapping.mappingTupleListToDtoList(any()))
                .thenReturn(saldosReintentos);
        when(monitorSaldosManagerRepository.getSaldosReintentosClientePaged(any(MonitorSaldosRequest.class), any()))
                .thenReturn(dataSaldos);
        doNothing().when(pistaAuditoriaService).registrarPista(any(PistaAuditoriaRequest.class));

        Page<MonitorSaldosResponse>response =
            monitorSaldosService.getSaldosReintentosCliente(request, pageable);

        assertNotNull(response);
        assertFalse(response.getContent().isEmpty());
        verify(monitorSaldosManagerRepository).
                getSaldosReintentosClientePaged(any(MonitorSaldosRequest.class),any());
        verify(pistaAuditoriaService).registrarPista(any(PistaAuditoriaRequest.class));
    }

    @Test
    void getSaldosReintentosClientePagedEmptyData() {
        MonitorSaldosRequest request = mock(MonitorSaldosRequest.class);
        Pageable pageable = mock(Pageable.class);
        Page<Tuple> dataSaldos = mock(PageImpl.class);
        List<MonitorSaldosResponse> saldosReintentos = new ArrayList<>();

        monitorSaldosModelMapping.when(() -> MonitorSaldosModelMapping.mappingTupleListToDtoList(any()))
                .thenReturn(saldosReintentos);
        when(monitorSaldosManagerRepository.getSaldosReintentosClientePaged(any(MonitorSaldosRequest.class), any()))
                .thenReturn(dataSaldos);

        Page<MonitorSaldosResponse>response =
                monitorSaldosService.getSaldosReintentosCliente(request, pageable);

        assertNotNull(response);
        assertTrue(response.getContent().isEmpty());
        verify(monitorSaldosManagerRepository).
                getSaldosReintentosClientePaged(any(MonitorSaldosRequest.class),any());
    }

    @Test
    void getSaldosReintentosCliente() {
        MonitorSaldosRequest request = mock(MonitorSaldosRequest.class);
        List<Tuple>  data = new ArrayList<>();
        data.add(mock(Tuple.class));
        List<MonitorSaldosResponse> saldosReintentos = new ArrayList<>();
        saldosReintentos.add(mock(MonitorSaldosResponse.class));

        monitorSaldosModelMapping.when(() -> MonitorSaldosModelMapping.mappingTupleListToDtoList(any()))
                .thenReturn(saldosReintentos);
        when(monitorSaldosManagerRepository.getSaldosReintentosCliente(any(MonitorSaldosRequest.class)))
                .thenReturn(data);
        doNothing().when(pistaAuditoriaService).registrarPista(any(PistaAuditoriaRequest.class));

        List<MonitorSaldosResponse> response = monitorSaldosService.getSaldosReintentosCliente(request);

        assertNotNull(response);
        assertFalse(response.isEmpty());
        verify(monitorSaldosManagerRepository).getSaldosReintentosCliente(any(MonitorSaldosRequest.class));
        verify(pistaAuditoriaService).registrarPista(any(PistaAuditoriaRequest.class));
    }

    @Test
    void getSaldosReintentosClienteEmptyData() {
        MonitorSaldosRequest request = mock(MonitorSaldosRequest.class);
        List<Tuple>  data = new ArrayList<>();
        List<MonitorSaldosResponse> saldosReintentos = new ArrayList<>();

        monitorSaldosModelMapping.when(() -> MonitorSaldosModelMapping.mappingTupleListToDtoList(any()))
                .thenReturn(saldosReintentos);
        when(monitorSaldosManagerRepository.getSaldosReintentosCliente(any(MonitorSaldosRequest.class)))
                .thenReturn(data);

        List<MonitorSaldosResponse> response = monitorSaldosService.getSaldosReintentosCliente(request);

        assertNotNull(response);
        assertTrue(response.isEmpty());
        verify(monitorSaldosManagerRepository).getSaldosReintentosCliente(any(MonitorSaldosRequest.class));
    }

}