package mx.santander.h2h.monitoreo.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import mx.santander.h2h.monitoreo.model.request.ArchivoCancelRequest;
import mx.santander.h2h.monitoreo.model.response.ArchivoCancelResponse;
import mx.santander.h2h.monitoreo.model.response.CancelOperationUpdResponse;
import mx.santander.h2h.monitoreo.repository.CancelOperationRepository;


@ExtendWith(MockitoExtension.class)
class CancelOperationServiceTest {

	@InjectMocks
    private CancelOperationService cancelOperationService;

    @Mock
    private CancelOperationBaseService cancelOperationBaseService;
    
    @Mock
    private CancelOperationConsultaService cancelOperationConsultaService;
    
    @Mock
    private CancelOperationRepository cancelOperationRepository;
    
    @Mock
    private EntityManager entityManager;
    
    
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void consultaCancelTest() {
    	cancelOperationConsultaService.consultaCancel("79240989");
        Assertions.assertTrue(true);
    }
    @Test
    void searchArchiveTets(){
    	List<Object[]> lstDatos = new ArrayList<>();
    	Object[] datos = {"9876543", "87654", "9876543", "675432", "876543", 
    		"342567", "456789", "897654", "897654", "87654", "897654", "987654"};
    	lstDatos.add(datos);
    	
    	Query query = mock(Query.class);
    	when(entityManager.createNativeQuery(anyString())).thenReturn(query);
    	when(query.getResultList()).thenReturn( lstDatos );
    	
    	ArchivoCancelRequest request = new ArchivoCancelRequest();
    	request.setBucCliente("09876543");
    	request.setEstatus("Activo");
    	request.setNomArchivo("");
    	
    	when(cancelOperationService.armarQuery(request, 1)).thenReturn( query );
    	Page<ArchivoCancelResponse> resp = null;
    	try {
    		resp = cancelOperationService.searchArchive(request, Pageable.ofSize(1));
    	} catch(Exception e) {}
    	
    	if( resp == null) {
        	assertNull(resp);
        } else {
        	assertNotNull(resp);
        }
    }

    
    @Test
    void canelOperacionTest(){
        String idRegistros = "";
        ArchivoCancelRequest request = new ArchivoCancelRequest();
        
//        when(cancelOperationRepository.updateCancelOperation( any() )).thenReturn(0);
        CancelOperationUpdResponse resp = null;
        try {
        	resp = cancelOperationService.cancelOperacion(idRegistros,request);
        } catch(Exception e) {}
        if( resp == null) {
        	assertNull(resp);
        } else {
        	assertNotNull(resp);
        }
        
//        when(cancelOperationRepository.updateCancelOperation( any() )).thenReturn(0);
        resp = null;
        try {
        	resp = cancelOperationService.cancelOperacion(idRegistros,request);
        } catch(Exception e) {}
        if( resp == null) {
        	assertNull(resp);
        } else {
        	assertNotNull(resp);
        }
    }

    @Test
    void getListaComboEstatusCentroTest(){
        Assertions.assertNotNull(cancelOperationBaseService.getListaComboEstatus());
    }

    @Test
    void getListaComboEstatus(){
        Assertions.assertNotNull(cancelOperationBaseService.getListaComboEstatus());
    }
    
    
    @Test
    void armarQueryTest1() {
    	ArchivoCancelRequest request = null;
    	Query query = mock(Query.class);
    	try {
    		query = cancelOperationService.armarQuery(request, 0);
    	} catch(Exception e) {}
    	if( query == null) {
    		assertNull(query);
    	} else {
    		assertNotNull(query);
    	}
    }
    
    @Test
    void armarQueryTest2() {
    	ArchivoCancelRequest request = new ArchivoCancelRequest();
    	request.setBucCliente("09876543");
    	request.setEstatus("Activo");
    	request.setNomArchivo("");
    	
    	Query query = mock(Query.class);
    	
    	when(entityManager.createNativeQuery(anyString())).thenReturn(query);
    	try {
    		query = cancelOperationService.armarQuery(request, 0);
    	} catch(Exception e) {}
    	if( query == null) {
    		assertNull(query);
    	} else {
    		assertNotNull(query);
    	}
    	
    	request.setNomArchivo(".lol");
    	query = cancelOperationService.armarQuery(request, 1);
    	if( query == null) {
    		assertNull(query);
    	} else {
    		assertNotNull(query);
    	}
    }
    
    @Test
    void armarQueryTest3() {
    	ArchivoCancelRequest request = new ArchivoCancelRequest();
    	request.setBucCliente("09876543");
    	request.setEstatus("Activo");
    	request.setNomArchivo(".lol");
    	
    	Query query = mock(Query.class);
    	
    	when(entityManager.createNativeQuery(anyString())).thenReturn(query);
    	try {
    		query = cancelOperationService.armarQuery(request, 1);
    	} catch(Exception e) {}
    	if( query == null) {
    		assertNull(query);
    	} else {
    		assertNotNull(query);
    	}
    }
}