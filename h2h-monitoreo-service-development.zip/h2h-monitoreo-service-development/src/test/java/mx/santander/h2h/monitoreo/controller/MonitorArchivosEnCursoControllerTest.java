package mx.santander.h2h.monitoreo.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;

import mx.santander.h2h.monitoreo.model.request.MonitorArchivosEnCursoRequest;
import mx.santander.h2h.monitoreo.model.response.MonitorDeArchivosEnCursoDetallesResponse;

import mx.santander.h2h.monitoreo.service.IMonitorArchivosEnCursoService;
import mx.santander.h2h.monitoreo.service.IMonitorArchivosEnCursoAuxService;
import mx.santander.h2h.monitoreo.service.IMonitorArchivosEnCursoComplementService;

class MonitorArchivosEnCursoControllerTest {
	@Mock
	private IMonitorArchivosEnCursoService service;
	
	@Mock
	private IMonitorArchivosEnCursoAuxService service2;
	
	@Mock
	private IMonitorArchivosEnCursoComplementService service3;
	
	@InjectMocks
	 MonitorArchivosEnCursoController controller;
	
	
	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testConsulta() {
		Page<MonitorDeArchivosEnCursoDetallesResponse> responsePage = Page.empty();
        when(service2.consultaArchivosEnCurso(any(), any())).thenReturn(responsePage);

        ResponseEntity<Page<MonitorDeArchivosEnCursoDetallesResponse>> result = controller.consulta(new MonitorArchivosEnCursoRequest(), null);
        Assertions.assertEquals(responsePage, result.getBody());
	}

	@Test
	void testConsultaNivelProducto() {
		Assertions.assertNotNull(controller.consultaNivelProducto("10", "10", "10"));
	}

	@Test
	void testConsultaNivelOperacion() {
		Assertions.assertNotNull(controller.consultaNivelOperacion("10", "10", "10"));
	}

	@Test
	void testConsultaNivelOperacionHistorica() {
		Assertions.assertNotNull(controller.consultaNivelOperacionHistorica("10"));
	}

	@Test
	void testConsultaListaEstatus() {
		Assertions.assertNotNull(controller.consultaListaEstatus());
	}

	@Test
	void testConsultaListaProductos() {
		Assertions.assertNotNull(controller.consultaListaProductos());
	}

	@Test
	void testConsultaListaEstatusProd() {
		Assertions.assertNotNull(controller.consultaListaEstatusProd());
	}

	@Test
	void testConsultaListaProductosProd() {
		Assertions.assertNotNull(controller.consultaListaProductosProd());
	}

	@Test
	void testGetReportXlsDetalleNivelProducto() {
		Assertions.assertNotNull(controller.getReportXlsDetalleNivelProducto(any(), anyString()));
	}

}
