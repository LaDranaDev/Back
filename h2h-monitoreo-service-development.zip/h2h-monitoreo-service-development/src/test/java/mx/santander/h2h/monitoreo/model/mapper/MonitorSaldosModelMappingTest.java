package mx.santander.h2h.monitoreo.model.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Tuple;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import mx.santander.h2h.monitoreo.model.response.MonitorSaldosResponse;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class MonitorSaldosModelMappingTest {

    private Tuple saldosReintentos;

    @BeforeEach
    void setUp(){
        saldosReintentos = mock(Tuple.class);
        when(saldosReintentos.get(anyString(), eq(String.class)))
                .thenReturn("");
        when(saldosReintentos.get(anyString(), eq(Character.class)))
                .thenReturn('A');
    }

    @Test
    void mappingTupleListToDtoList() {
        List<Tuple> dataSaldosReintentos = new ArrayList<>();
        dataSaldosReintentos.add(saldosReintentos);

        when(saldosReintentos.get(anyString(), eq(BigDecimal.class)))
                .thenReturn(new BigDecimal("1234"));

        List<MonitorSaldosResponse> saldosResponses =
                MonitorSaldosModelMapping.mappingTupleListToDtoList(dataSaldosReintentos);

        assertNotNull(saldosResponses);
        assertEquals(1, saldosResponses.size());
    }

    @ParameterizedTest
    @ValueSource(strings = {"-12345", "12234"})
    void mappingTupleToDto(String saldoFaltante) {
        when(saldosReintentos.get(anyString(), eq(BigDecimal.class)))
                .thenReturn(new BigDecimal(saldoFaltante));

        MonitorSaldosResponse saldosResponse =
                MonitorSaldosModelMapping.mappingTupleToDto(saldosReintentos);

        assertNotNull(saldosResponse);
    }

    @Test
    void mappingTupleToDto() {
        MonitorSaldosResponse saldosResponse =
                MonitorSaldosModelMapping.mappingTupleToDto(null);

        assertNull(saldosResponse);
    }
}