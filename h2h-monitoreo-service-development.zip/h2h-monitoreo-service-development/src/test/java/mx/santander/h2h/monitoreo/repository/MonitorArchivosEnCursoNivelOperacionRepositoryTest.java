package mx.santander.h2h.monitoreo.repository;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import mx.santander.h2h.monitoreo.model.response.MonitorDeArchivosEnCursoDetallesOperacionResponse;
import mx.santander.h2h.monitoreo.model.response.ResultTrackingResponse;

class MonitorArchivosEnCursoNivelOperacionRepositoryTest {
	@Mock
	private EntityManager entityManager;
	@InjectMocks
	private MonitorArchivosEnCursoNivelOperacionRepository repository;
	
	@BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
	
	@Test
	void testEjecutaBusquedaNivelOperacionStringIntegerInteger() {
		 Query query = mock(Query.class);

	     when(entityManager.createNativeQuery(anyString(), eq(Tuple.class))).thenReturn(query);
	     
	     List<Tuple> lst = new ArrayList<>();
	     Tuple tuple = mock(Tuple.class);
	     when(tuple.get(anyString())).thenReturn("value");
	     lst.add(tuple);
	     when(query.getResultList()).thenReturn(lst);
	     
	     List<MonitorDeArchivosEnCursoDetallesOperacionResponse> result = repository.ejecutaBusquedaNivelOperacion("", 1, 1);
	     Assertions.assertNotNull(result);
	}

	@Test
	void testEjecutaBusquedaNivelOperacionHistoricaString() {
		 Query query = mock(Query.class);

	     when(entityManager.createNativeQuery(anyString(), eq(Tuple.class))).thenReturn(query);
	     
	     List<Tuple> lst = new ArrayList<>();
	     Tuple tuple = mock(Tuple.class);
	     when(tuple.get(anyString())).thenReturn("value");
	     lst.add(tuple);
	     when(query.getResultList()).thenReturn(lst);
	     
	     List<MonitorDeArchivosEnCursoDetallesOperacionResponse> result = repository.ejecutaBusquedaNivelOperacionHistorica("");
	     Assertions.assertNotNull(result);
	}

	@Test
	void testQueryObtenerProductos() {
		Query query = mock(Query.class);

	     when(entityManager.createNativeQuery(anyString())).thenReturn(query);
	     
	     List<Object[]> lst = new ArrayList<>();
	     Object[] arr = {"", "1", ""};
	     lst.add(arr);
	     when(query.getResultList()).thenReturn(lst);
	     
	     ResultTrackingResponse result = repository.obtenerCatalogoProductos();
	     Assertions.assertNotNull(result);
	}

	@Test
	void testObtenerCatalogoEstatus() {
		Query query = mock(Query.class);

	     when(entityManager.createNativeQuery(anyString())).thenReturn(query);
	     
	     List<Object[]> lst = new ArrayList<>();
	     Object[] arr = {1L, ""};
	     lst.add(arr);
	     when(query.getResultList()).thenReturn(lst);
	     
	     ResultTrackingResponse result = repository.obtenerCatalogoEstatus();
	     Assertions.assertNotNull(result);
	}

}
