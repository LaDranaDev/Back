package mx.santander.h2h.monitoreo.model.request;

import static org.hibernate.validator.internal.util.Contracts.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class PutGetRequestTest {

    private PutGetRequest putGetRequest;

    @BeforeEach
    void setUp() {
        putGetRequest = new PutGetRequest();
    }

    @Test
    void allArgsConstuction() {
        putGetRequest = new PutGetRequest("123", "213", "213", "123", "123", "213", "123", "123", null);
        assertNotNull(putGetRequest);
    }

    @Test
    void getNumeroContrato() {
        putGetRequest.setNumeroContrato("123");
        assertEquals("123", putGetRequest.getNumeroContrato());
    }

    @Test
    void getCodigoCliente() {
        putGetRequest.setCodigoCliente("123");
        assertEquals("123", putGetRequest.getCodigoCliente());
    }

    @Test
    void getIdContrato() {
        putGetRequest.setIdContrato("12321");
        assertEquals("12321", putGetRequest.getIdContrato());
    }

    @Test
    void getIdProtocolo() {
        putGetRequest.setIdProtocolo("123");
        assertEquals("123", putGetRequest.getIdProtocolo());
    }

    @Test
    void getIdProtocoloPara() {
        putGetRequest.setIdProtocoloPara("123");
        assertEquals("123", putGetRequest.getIdProtocoloPara());
    }

    @Test
    void getIdProtocoloPath1() {
        putGetRequest.setIdProtocoloPath1("123");
        assertEquals("123", putGetRequest.getIdProtocoloPath1());
    }

    @Test
    void getIdProtocoloPath2() {
        putGetRequest.setIdProtocoloPath2("123");
        assertEquals("123", putGetRequest.getIdProtocoloPath2());
    }

    @Test
    void getTipoOperPG() {
        putGetRequest.setTipoOperPG("123");
        assertEquals("123", putGetRequest.getTipoOperPG());
    }

    @Test
    void setPutGetSaveRequest() {
        PutGetSaveRequest putGetSaveRequest = mock(PutGetSaveRequest.class);
        putGetRequest.setPutGetSaveRequest(putGetSaveRequest);
        assertEquals(putGetSaveRequest, putGetRequest.getPutGetSaveRequest());
    }

    @Test
    void testToString() {
        assertNotNull(putGetRequest.toString());
    }
}