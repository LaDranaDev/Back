package mx.santander.h2h.monitoreo.model.report.request;

import mx.santander.h2h.monitoreo.model.request.MonitorSaldosRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
class MonitorSaldosReportRequestTest {

    private MonitorSaldosReportRequest monitorSaldosReportRequest;

    @BeforeEach
    void setUp(){
        monitorSaldosReportRequest = new MonitorSaldosReportRequest();
    }

    @Test
    void getMonitorSaldosRequest() {
        MonitorSaldosRequest monitorSaldosRequest = mock(MonitorSaldosRequest.class);
        monitorSaldosReportRequest.setMonitorSaldosRequest(monitorSaldosRequest);
        assertEquals(monitorSaldosRequest, monitorSaldosReportRequest.getMonitorSaldosRequest());
    }

    @Test
    void getUsuario() {
        monitorSaldosReportRequest.setUsuario("prueba");
        assertEquals("prueba", monitorSaldosReportRequest.getUsuario());
    }

    @Test
    void builder() {
        monitorSaldosReportRequest = MonitorSaldosReportRequest.builder().build();
        assertNotNull(monitorSaldosReportRequest);
    }

    @Test
    void toStringTest(){
        String response = MonitorSaldosReportRequest.builder().toString();
        assertNotNull(response);
    }


}