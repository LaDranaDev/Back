package mx.santander.h2h.monitoreo.commons.utils;

import static org.mockito.Mockito.mock;

import jakarta.servlet.http.HttpServletRequest;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import mx.santander.pid.logadapter.core.model.MetadataTracker;

class LogAdapterExtractorAPITest {
	@Mock
	HttpServletRequest http;

	@InjectMocks
	LogAdapterExtractorAPI extractorAPI;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testObtenerInformacion() {
		MetadataTracker metadata = mock(MetadataTracker.class);
		HttpServletRequest request = mock(HttpServletRequest.class);
		extractorAPI.obtenerInformacion(metadata, request);
		Assertions.assertTrue(true);

	}

}
