package mx.santander.h2h.monitoreo.util;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import mx.santander.h2h.monitoreo.model.entity.ParameterEntity;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.repository.IMotivoRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailAporPatrRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailDomisRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailImpFedRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailMttoProvRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailOrdPagAtmRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailPagDirectRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailPagImpAduanRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailPagRefRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailSpidRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailTransInterRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailVostroRepository;
import mx.santander.h2h.monitoreo.repository.IParameterRepository;
import mx.santander.h2h.monitoreo.repository.OperationsDetailTransInterMbcRepository;

class OperationsMonitorUtilTest {
    @Mock
    private IOperationsDetailRepository detailRepository;
    @Mock
    private IOperationsDetailDomisRepository detailDomisRepository;
    @Mock
    private IOperationsDetailMttoProvRepository detailMttoProvRepository;
    @Mock
    private IOperationsDetailImpFedRepository detailImpFedRepository;
    @Mock
    private IOperationsDetailPagRefRepository detailPagRefRepository;
    @Mock
    private IOperationsDetailAporPatrRepository detailAporPatrRepository;
    @Mock
    private IParameterRepository parameterRepository;
    @Mock
    private IOperationsDetailTransInterRepository detailTransInterRepository;

    @Mock
    private OperationsDetailTransInterMbcRepository operationsDetailTransInterMbcRepository;

    @Mock
    private IOperationsDetailSpidRepository operationsDetailSpidRepository;

    @Mock
    private IOperationsDetailPagDirectRepository operationsDetailPagDirectRepository;

    @Mock
    private IOperationsDetailVostroRepository operationsDetailVostroRepository;

    @Mock
    private IOperationsDetailOrdPagAtmRepository operationsDetailOrdPagAtmRepository;

    @Mock
    private IOperationsDetailPagImpAduanRepository operationsDetailPagImpAduanRepository;

    @Mock
    private IMotivoRepository motivoRepository;

    @InjectMocks
    OperationsMonitorUtil operationsMonitorUtil;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        when(detailRepository.obtenerDetalleOperacion(anyString(), anyString()))
                .thenReturn(mock(OperationsMonitorQueryResponse.class, RETURNS_DEEP_STUBS));

        when(detailMttoProvRepository.obtenerDetalleOperacion(anyString(), anyString()))
                .thenReturn(mock(OperationsMonitorQueryResponse.class, RETURNS_DEEP_STUBS));

        when(detailDomisRepository.obtenerDetalleOperacion(anyString(), anyString()))
                .thenReturn(mock(OperationsMonitorQueryResponse.class, RETURNS_DEEP_STUBS));

        when(detailImpFedRepository.obtenerDetalleOperacion(anyString()))
                .thenReturn(mock(OperationsMonitorQueryResponse.class, RETURNS_DEEP_STUBS));

        when(detailPagRefRepository.obtenerDetalleOperacion(anyString()))
                .thenReturn(mock(OperationsMonitorQueryResponse.class, RETURNS_DEEP_STUBS));

        when(detailAporPatrRepository.obtenerDetalleOperacion(anyString()))
                .thenReturn(mock(OperationsMonitorQueryResponse.class, RETURNS_DEEP_STUBS));

        when(detailTransInterRepository.obtenerDetalleOperacion(anyString()))
                .thenReturn(mock(OperationsMonitorQueryResponse.class, RETURNS_DEEP_STUBS));

        when(operationsDetailTransInterMbcRepository.obtenerDetalleOperacion(anyString()))
                .thenReturn(mock(OperationsMonitorQueryResponse.class, RETURNS_DEEP_STUBS));

        when(operationsDetailSpidRepository.obtenerDetalleOperacion(anyString()))
                .thenReturn(mock(OperationsMonitorQueryResponse.class, RETURNS_DEEP_STUBS));

        when(operationsDetailVostroRepository.obtenerDetalleOperacion(anyString(), anyString()))
                .thenReturn(mock(OperationsMonitorQueryResponse.class, RETURNS_DEEP_STUBS));

        when(operationsDetailOrdPagAtmRepository.obtenerDetalleOperacion(anyString(), anyString()))
                .thenReturn(mock(OperationsMonitorQueryResponse.class, RETURNS_DEEP_STUBS));

        when(operationsDetailPagImpAduanRepository.obtenerDetalleOperacion(anyString(), anyString()))
                .thenReturn(mock(OperationsMonitorQueryResponse.class, RETURNS_DEEP_STUBS));

        when(operationsDetailPagDirectRepository.obtenerDetalleOperacion(anyString(), anyString()))
                .thenReturn(mock(OperationsMonitorQueryResponse.class, RETURNS_DEEP_STUBS));

    }

    @Test
    void testObtenerDetalleOperacion() {
        when(parameterRepository.findByName(any())).then(answer -> {
            ParameterEntity entity = new ParameterEntity();
            entity.setValue(answer.getArgument(0));
            return entity;
        });

        List<String> views = Arrays.asList(
                "CVE_OPER_PROD_DOMIS", "CVE_OPER_PROD_MT_CNF", "CVE_OPER_PROD_I_FED", "CVE_OPER_PROD_P_REF",
                "CVE_OPER_PROD_A_PATR", "CVE_OP_PROD_TRAN_INT", "CVE_OP_PROD_TRAN_MMB", "", "29", "30", "CVE_OP_PROD_SPID",
                "CVE_PROD_PAG_DIRE", "CVE_PROD_TRANINTCAMB", "CVE_PROD_VOSTRO_INT", "CVE_PROD_VOSTRO_MB", "85", "25"
        );

        for (String view : views) {
            Assertions.assertDoesNotThrow(() ->
                    operationsMonitorUtil.obtenerDetalleOperacion(view, "idOperacion")
            );
        }
    }
}
