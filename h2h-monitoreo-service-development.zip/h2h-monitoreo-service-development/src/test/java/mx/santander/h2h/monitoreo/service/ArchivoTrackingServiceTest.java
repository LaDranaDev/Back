package mx.santander.h2h.monitoreo.service;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.response.ArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ResultTrackingResponse;
import mx.santander.h2h.monitoreo.repository.IConsultaTrackingNativeRepository;
import mx.santander.h2h.monitoreo.repository.IConsultaTrackingRepository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;


class ArchivoTrackingServiceTest {
    
    @InjectMocks
    ArchivoTrackingService archivoTrackingService;
    
    @Mock
    private IConsultaTrackingRepository consultaTrackingRepository;
    
    @Mock
    private IConsultaTrackingNativeRepository consultaTrackingNativeRepository;
    
    @Mock
    IJasperReportService reportService;
    
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
    
    @Test
    void inicioTest() {
    	Mockito.when(this.consultaTrackingRepository.obtenerConteoArchivos(Mockito.anyString())).thenReturn(obtenerConteoArchivos());
    	Mockito.when(this.consultaTrackingNativeRepository.obtenerConteoArchivo(Mockito.anyString(),Mockito.anyString())).thenReturn(resultTrackingRes());
    	archivoTrackingService.inicio("79240991");
    	Assertions.assertTrue(true);
    }
    
    public ResultTrackingResponse resultTrackingRes() {
    	ResultTrackingResponse resultTracking = new ResultTrackingResponse();
    	ArchivoResponse result = new ArchivoResponse();
    	
    	result.setCliente(null);
    	result.setCodCliente(null);
    	result.setTotAlerta(new BigDecimal(0));
		result.setTotDupl(new BigDecimal(0));
		result.setTotEsp(new BigDecimal(0));
		result.setTotEnProc(new BigDecimal(0));
		result.setTotEnroll(new BigDecimal(0));
		result.setTotProc(new BigDecimal(0));
		result.setTotProg(new BigDecimal(0));
		result.setTotRecha(new BigDecimal(0));
		result.setTotRecib(new BigDecimal(0));
		result.setTotVald(new BigDecimal(0));
		
		result.getCliente();
		result.getCodCliente();
		result.getTotAlerta();
		result.getTotDupl();
		result.getTotEsp();
		result.getTotEnProc();
		result.getTotEnroll();
		result.getTotProc();
		result.getTotProg();
		result.getTotRecha();
		result.getTotRecib();
		result.getTotVald();
		
		result.toString();
		
		resultTracking.setArchivo(result);
		
    	return resultTracking;
    }
    
    private List<Object[]> obtenerConteoArchivos(){
		List<Object[]> respuesta = new ArrayList<Object[]>();
		
		Object[] resultBd = {new BigDecimal("88"),new BigDecimal("122396"),new BigDecimal("124369.62"),new BigDecimal("0"),new BigDecimal("0"),
				new BigDecimal("0"),new BigDecimal("3"),new BigDecimal("0"),new BigDecimal("80"),new BigDecimal("5"),
				new BigDecimal("0")};
		
		respuesta.add(resultBd);
		
		return respuesta;
	}
    
    @Test
    void obtenerListDetalleArchivos() {
    	archivoTrackingService.obtenerListDetalleArchivos("79240991");
    	Assertions.assertTrue(true);
    }
    
    @Test
    void getReportXls() {
    	ReportResponse responseData = new ReportResponse();
		responseData.setData("data");
		responseData.setLength(12);
		responseData.setName("name");
		responseData.setType("application/octet-stream");
		
    	Mockito.when(reportService.getXls(Mockito.anyString(), Mockito.any(), Mockito.any())).thenReturn(responseData);
    	archivoTrackingService.getReportXls("79240991", "Kaori");
    	Assertions.assertTrue(true);
    }

}
