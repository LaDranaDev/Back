package mx.santander.h2h.monitoreo.util;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class UtilQueryTest {

    @Test
    void testFromH2hArchivo() {
        String result = UtilQuery.fromH2hArchivo(true);
        Assertions.assertEquals("FROM H2H_ARCHIVO_TRAN ARCH ", result);

        result = UtilQuery.fromH2hArchivo(false);
        Assertions.assertEquals("FROM H2H_ARCHIVO ARCH ", result);
    }

    @Test
    void testInnerJoinH2hReg() {
        String result = UtilQuery.innerJoinH2hReg(true);
        Assertions.assertEquals("INNER JOIN H2H_REG_TRAN REG ON ARCH.ID_ARCHIVO = REG.ID_ARCH ", result);

        result = UtilQuery.innerJoinH2hReg(false);
        Assertions.assertEquals("INNER JOIN H2H_REG REG ON ARCH.ID_ARCHIVO = REG.ID_ARCH ", result);
    }

    @Test
    void testSelectRegTabla() {
        String result = UtilQuery.selectRegTabla(true);
        Assertions.assertEquals("SELECT 'H2H_REG_TRAN' TABLA, ", result);

        result = UtilQuery.selectRegTabla(false);
        Assertions.assertEquals("SELECT 'H2H_REG' TABLA, ", result);
    }

    @Test
    void testInnerJoinPagoDirecto() {
        String result = UtilQuery.innerJoinPagoDirecto(true);
        Assertions.assertEquals("INNER JOIN H2H_MX_PROD_PAGO_DIR_TRAN PAGO ON PAGO.ID_REG = REG.ID_REG ", result);

        result = UtilQuery.innerJoinPagoDirecto(false);
        Assertions.assertEquals("INNER JOIN H2H_MX_PROD_PAGO_DIR PAGO ON PAGO.ID_REG = REG.ID_REG ", result);
    }
    
    @Test
    void testUtilOperacionMonitorNew() {
    	StringBuilder qry = new StringBuilder();
    	qry.append("SELECT * FROM ( ");
    	String qryU = UtilOperacionMonitorNew.getCadValidacion(qry, "31");
    	Assertions.assertNotNull(qry);
    }
    
    @Test
    void testUtilOperacionMonitorNew2() {
    	StringBuilder qry = new StringBuilder();
    	qry.append("SELECT * FROM ( ");
    	String qryU = UtilOperacionMonitorNew.getCadValidacion(qry, "35");
    	Assertions.assertNotNull(qry);
    }
    
    @Test
    void testUtilOperacionMonitorNew3() {
    	StringBuilder qry = new StringBuilder();
    	qry.append("SELECT * FROM ( ");
    	String qryU = UtilOperacionMonitorNew.getCadValidacion(qry, "21");
    	Assertions.assertNotNull(qry);
    }
    
    @Test
    void testUtilOperacionMonitorNew4() {
    	StringBuilder qry = new StringBuilder();
    	qry.append("SELECT * FROM ( ");
    	String qryU = UtilOperacionMonitorNew.getCadValidacion(qry, "33");
    	Assertions.assertNotNull(qry);
    }
    
    @Test
    void testUtilOperacionMonitorNewV() {
    	StringBuilder qry = new StringBuilder();
    	qry.append("SELECT * FROM ( ");
    	String qryU = UtilOperacionMonitorNew.getValidacionCve(qry, "01");
    	Assertions.assertNotNull(qry);
    }
    
    @Test
    void testUtilOperacionMonitorNewV1() {
    	StringBuilder qry = new StringBuilder();
    	qry.append("SELECT * FROM ( ");
    	String qryU = UtilOperacionMonitorNew.getValidacionCve(qry, "80");
    	Assertions.assertNotNull(qry);
    }
    
    @Test
    void testUtilOperacionMonitorNewV2() {
    	StringBuilder qry = new StringBuilder();
    	qry.append("SELECT * FROM ( ");
    	String qryU = UtilOperacionMonitorNew.getValidacionCve(qry, "95");
    	Assertions.assertNotNull(qry);
    }
    
    @Test
    void testUtilOperacionMonitorNewV3() {
    	StringBuilder qry = new StringBuilder();
    	qry.append("SELECT * FROM ( ");
    	String qryU = UtilOperacionMonitorNew.getValidacionCve(qry, "91");
    	Assertions.assertNotNull(qry);
    }
    
    @Test
    void testUtilOperacionMonitorNewV7() {
    	StringBuilder qry = new StringBuilder();
    	qry.append("SELECT * FROM ( ");
    	String qryU = UtilOperacionMonitorNew.getValidacionCve(qry, "98");
    	Assertions.assertNotNull(qry);
    }
    
    @Test
    void testUtilOperacionMonitorNewV4() {
    	StringBuilder qry = new StringBuilder();
    	qry.append("SELECT * FROM ( ");
    	String qryU = UtilOperacionMonitorNew.getValidacionCve(qry, "21");
    	Assertions.assertNotNull(qry);
    }
    
    @Test
    void testUtilOperacionMonitorNewV5() {
    	StringBuilder qry = new StringBuilder();
    	qry.append("SELECT * FROM ( ");
    	String qryU = UtilOperacionMonitorNew.getValidacionCve(qry, "33");
    	Assertions.assertNotNull(qry);
    }
    
    @Test
    void testUtilOperacionMonitorNewV6() {
    	StringBuilder qry = new StringBuilder();
    	qry.append("SELECT * FROM ( ");
    	String qryU = UtilOperacionMonitorNew.getValidacionCve(qry, "");
    	Assertions.assertNotNull(qry);
    }
    
    @Test
    void testUtilOperacionMonitorNewC() {
    	StringBuilder qry = new StringBuilder();
    	qry.append("SELECT * FROM ( ");
    	String qryU = UtilOperacionMonitorNew.completaQueryProducto919330("93");
    	Assertions.assertNotNull(qry);
    }
    
    @Test
    void testUtilOperacionMonitorNewC1() {
    	StringBuilder qry = new StringBuilder();
    	qry.append("SELECT * FROM ( ");
    	String qryU = UtilOperacionMonitorNew.completaQueryProducto919330("30");
    	Assertions.assertNotNull(qry);
    }
    
    @Test
    void testUtilOperacionMonitorNewC2() {
    	StringBuilder qry = new StringBuilder();
    	qry.append("SELECT * FROM ( ");
    	String qryU = UtilOperacionMonitorNew.completaQueryProducto919330("29");
    	Assertions.assertNotNull(qry);
    }
    
    @Test
    void testUtilOperacionMonitorNewC3() {
    	StringBuilder qry = new StringBuilder();
    	qry.append("SELECT * FROM ( ");
    	String qryU = UtilOperacionMonitorNew.agregaPifconsulta(qry, "23");
    	Assertions.assertNotNull(qry);
    }
    
    @Test
    void testUtilOperacionMonitorNewC4() {
    	StringBuilder qry = new StringBuilder();
    	qry.append("SELECT * FROM ( ");
    	String qryU = UtilOperacionMonitorNew.agregaTIconsulta(qry, "");
    	Assertions.assertNotNull(qry);
    }

}
