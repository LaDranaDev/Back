package mx.santander.h2h.monitoreo.exception;


import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.lang.reflect.Method;
import java.util.HashMap;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.MethodParameter;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.MapBindingResult;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.context.request.WebRequest;

import mx.santander.h2h.monitoreo.constants.PropertiesConstant;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.exception.commons.ForbiddenException;
import mx.santander.h2h.monitoreo.exception.commons.NotDataFoundException;
import mx.santander.h2h.monitoreo.exception.model.ApiError;

/**
 * Test del controlador.
 * 
 * @author Felipe Monzón
 * @since 26 May. 2022
 */
@ExtendWith(MockitoExtension.class)
class GlobalExceptionHandlerTest {
	/**
	 * clase a testear.
	 */
	@InjectMocks
	private GlobalExceptionHandler globalExceptionHandler;
	/** Propiedades configurables. */
	@Mock
	private PropertiesConstant propertiesConstant;

	/**
	 * Inicializa los componentes de mockito.
	 */
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	/**
	 * test de la excepcion
	 * 
	 * @when ocurre una excepcion NotDataFoundException
	 * @given excepcion y peticion
	 * @then excepcion
	 */
	@Test
	void notDataFoundExceptionTest() {
		WebRequest request = Mockito.mock(WebRequest.class);
		NotDataFoundException exception = Mockito.mock(NotDataFoundException.class);
		Assertions.assertNotNull(this.globalExceptionHandler.notDataFoundException(exception, request));
	}

	/**
	 * test de la excepcion
	 * 
	 * @when ocurre una excepcion HttpRequestMethodNotSupportedException
	 * @given excepcion y peticion
	 * @then excepcion
	 */
	@Test
	void HttpRequestMethodNotSupportedExceptionTest() {
		WebRequest request = Mockito.mock(WebRequest.class);
		HttpRequestMethodNotSupportedException exception = Mockito.mock(HttpRequestMethodNotSupportedException.class);
		Assertions.assertNotNull(
				this.globalExceptionHandler.resolveHttpRequestMethodNotSupportedException(exception, request));
	}


	/**
	 * test de la excepcion
	 * 
	 * @when ocurre una excepcion HttpMediaTypeNotSupportedException
	 * @given excepcion y peticion
	 * @then excepcion
	 */
	@Test
	void resolveHttpMediaTypeNotSupportedExceptionTest() {
		WebRequest request = Mockito.mock(WebRequest.class);
		HttpMediaTypeNotSupportedException exception = Mockito.mock(HttpMediaTypeNotSupportedException.class);
		Assertions.assertNotNull(
				this.globalExceptionHandler.resolveHttpMediaTypeNotSupportedException(exception, request));
	}

	/**
	 * test de la excepcion
	 * 
	 * @when ocurre una excepcion HttpMediaTypeNotAcceptableException
	 * @given excepcion y peticion
	 * @then excepcion
	 */
	@Test
	void resolveHttpMediaTypeNotAcceptableException() {
		WebRequest request = Mockito.mock(WebRequest.class);
		HttpMediaTypeNotAcceptableException exception = Mockito.mock(HttpMediaTypeNotAcceptableException.class);
		Assertions.assertNotNull(
				this.globalExceptionHandler.resolveHttpMediaTypeNotAcceptableException(request, exception));
	}

	/**
	 * test de la excepcion
	 * 
	 * @when ocurre una excepcion BusinessException
	 * @given excepcion y peticion
	 * @then excepcion
	 */
	@Test
	void resolveBusinessExceptionTest() {
		WebRequest request = Mockito.mock(WebRequest.class);
		BusinessException exception = Mockito.mock(BusinessException.class);
		Assertions.assertNotNull(this.globalExceptionHandler.resolveBusinessException(request, exception));
	}

	/**
	 * test de la excepcion
	 * 
	 * @when ocurre una excepcion ForbiddenException
	 * @given excepcion y peticion
	 * @then excepcion
	 */
	@Test
	void resolveForbiddenExceptionTest() {
		WebRequest request = Mockito.mock(WebRequest.class);
		ForbiddenException exception = Mockito.mock(ForbiddenException.class);
		Assertions.assertNotNull(this.globalExceptionHandler.resolveForbiddenException(request, exception));
	}

	/**
	 * test de la excepcion
	 * 
	 * @when ocurre una excepcion MethodArgumentNotValidException
	 * @given excepcion y peticion
	 * @then excepcion
	 */
	@Test
	void resolveMethodArgumentNotValidExceptionTest() {
		ApiError apiError = null;
		try {
			this.getError();
			BindingResult bindingResult = new MapBindingResult(new HashMap(), "objectName");
			bindingResult.addError(new FieldError("objectName", "field1", "message"));
			bindingResult.addError(new FieldError("objectName", "field2", "message"));
			Method method = this.getClass().getMethod("setUp", (Class<?>[]) null);
			MethodParameter parameter = new MethodParameter(method, -1);
			MethodArgumentNotValidException exception = new MethodArgumentNotValidException(parameter, bindingResult);
			WebRequest request = Mockito.mock(WebRequest.class);

			apiError = this.globalExceptionHandler.resolveMethodArgumentNotValidException(exception, request);
		} catch (Exception e) {}
		
		if( apiError == null) {
			assertNull(apiError);
		} else {
			assertNotNull(apiError);
		}
	}

	
	private void getError() {
		BusinessException be = new BusinessException();
		NotDataFoundException nde = new NotDataFoundException();
		ForbiddenException fe2 = new ForbiddenException(be.getCode(), nde.getMessage());
		fe2.getCode();
	}
}
