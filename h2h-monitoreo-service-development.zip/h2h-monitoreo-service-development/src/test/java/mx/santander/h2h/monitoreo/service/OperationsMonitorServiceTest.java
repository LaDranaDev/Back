package mx.santander.h2h.monitoreo.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import java.beans.IntrospectionException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.util.JRLoader;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.constants.ReportConstants;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.OperationsHistoryResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorCatalogsResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorCatalogsYHorasResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorTotalResponse;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailRepository;
import mx.santander.h2h.monitoreo.repository.IOperationsMonitorEntityManagerHelper4Repository;
import mx.santander.h2h.monitoreo.repository.IOperationsMonitorEntityManagerRepository;
import mx.santander.h2h.monitoreo.repository.IParameterRepository;
import mx.santander.h2h.monitoreo.util.JavaBeanTester;
import mx.santander.h2h.monitoreo.util.OperationsMonitorUtil;

class OperationsMonitorServiceTest {
	@Mock
	IOperationsMonitorEntityManagerRepository repository;
	@Mock
	IOperationsMonitorEntityManagerHelper4Repository repo;
	@Mock
	IJasperReportService reportService;
	@Mock
	IOperationsDetailRepository detailRepository;
	@Mock
	IParameterRepository parameterRepository;
	@Mock
	OperationsMonitorUtil util;
	@Mock
	Logger log;
	@InjectMocks
	OperationsMonitorService operationsMonitorService;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testConsulta() {
		OperationsMonitorQueryResponse response = new OperationsMonitorQueryResponse();
		when(repository.consultaOperaciones(any())).thenReturn(Collections.singletonList(response));
		when(repository.countConsultaOperaciones(any())).thenReturn(1L);

		Page<OperationsMonitorQueryResponse> result = operationsMonitorService
				.consulta(new OperationsMonitorQueryRequest(), Pageable.ofSize(10));
		Assertions.assertEquals(response, result.getContent().get(0));
		Assertions.assertEquals(1L, result.getTotalElements());
	}

	@Test
	    void testTotal() {
	        when(repository.countCorreosEnv(any())).thenReturn(88L);
	        when(repository.countArchivos(any())).thenReturn(99L);
	        when(repository.getImporteGlobal(any())).thenReturn(9999d);

	        OperationsMonitorTotalResponse result = operationsMonitorService.total(new OperationsMonitorQueryRequest());
	        Assertions.assertEquals(88L, result.getCorreosEnv());
	        Assertions.assertEquals(99L, result.getArchivos());
	        Assertions.assertEquals(9999d, result.getImporteGlobal());
	    }

	@Test
	    void testReporte() {
//	        when(repository.consultaOperacionesExportar(any())).thenReturn(Collections.singletonList(new OperationsMonitorQueryResponse()));
	        when(repository.consultaOperacionesExportar(any())).thenReturn(new String());

	        ReportResponse getPdf = new ReportResponse("data", 0, "name", "type");
	        when(reportService.getPdf(any(), any(), any())).thenReturn(getPdf);

	        ReportResponse getXls = new ReportResponse("data", 0, "name", "type");
	        when(reportService.getXls(any(), any(), any())).thenReturn(getXls);

	        OperationsMonitorQueryRequest request = new OperationsMonitorQueryRequest();
	        request.setDivisa("0");
	        ReportResponse result = operationsMonitorService.reporte(request, ReportConstants.PDF_FORMAT);
	        Assertions.assertEquals(getPdf, result);

	        result = operationsMonitorService.reporte(request, ReportConstants.EXCEL_FORMAT);
	        Assertions.assertEquals(getXls, result);
	    }

	@Test
	void testCatalogs() {
		OperationsMonitorCatalogsYHorasResponse responseh = new OperationsMonitorCatalogsYHorasResponse();

		OperationsMonitorCatalogsResponse response = new OperationsMonitorCatalogsResponse();
		when(repository.catalogs()).thenReturn(response);

		responseh.setOperationsMonitorCatalogsResponse(response);

		operationsMonitorService.catalogs();
		Assertions.assertTrue(true);
	}

	@Test
	void testObtenerDetalleOperacion() {
		OperationsMonitorQueryResponse response = new OperationsMonitorQueryResponse();
		when(util.obtenerDetalleOperacion(any(), any())).thenReturn(response);

		OperationsMonitorQueryResponse result = operationsMonitorService.obtenerDetalleOperacion("view", "idOperacion");
		Assertions.assertEquals(response, result);
	}

	@Test
	void testObtenerHistorialOperacion() {
		List<OperationsHistoryResponse> responseList = Collections.singletonList(new OperationsHistoryResponse());
		when(detailRepository.obtenerHistorialOperacion(any())).thenReturn(responseList);
		List<OperationsHistoryResponse> result = operationsMonitorService.obtenerHistorialOperacion("idOperacion");
		Assertions.assertEquals(responseList, result);
	}

	@Test
	void testReporteHistorialOperacion() {
		when(detailRepository.obtenerHistorialOperacion(any())).thenReturn(Collections.singletonList(new OperationsHistoryResponse()));

		ReportResponse response = new ReportResponse();
		when(reportService.getXls(any(), any(), any())).thenReturn(response);

		try (MockedStatic<JRLoader> jrLoaderStatic = mockStatic(JRLoader.class)) {
			ReportResponse result = operationsMonitorService.reporteHistorialOperacion("idOperacion", "usuario");
			Assertions.assertEquals(response, result);
			when(reportService.getXls(any(), any(), any())).thenThrow(new BusinessException("Err01", "Error en obtencion de reporte") );
			jrLoaderStatic.when(() -> JRLoader.loadObject((InputStream) any())).thenThrow(JRException.class);
			Assertions.assertThrows(BusinessException.class, () ->
					operationsMonitorService.reporteHistorialOperacion("idOperacion", "usuario")
			);
		}
	}

	@Test
	    void testCambiarEstatusOperacion() {
	        when(detailRepository.cambiarEstatusOperacion(any(), any(), any())).thenReturn(true);
	        boolean result = operationsMonitorService.cambiarEstatusOperacion("idOperacion", "estatus", "tabla");
	        Assertions.assertTrue(result);
	    }

	@Test
	    void testConsultarHorario() {
	        when(detailRepository.consultarHorario(any())).thenReturn(true);
	        boolean result = operationsMonitorService.consultarHorario("producto");
	        Assertions.assertTrue(result);
	    }

	@Test
	void testReportBean() throws IntrospectionException {
		JavaBeanTester.test(OperationsMonitorService.ReportBean.class);
	}

}
