package mx.santander.h2h.monitoreo.model.response;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
class PutGetDtoTest {

    private PutGetDto putGetDtoResponse;

    @BeforeEach
    void setUp() {
        putGetDtoResponse = new PutGetDto();
    }

    @Test
    void allArgsContructor() {
        putGetDtoResponse = new PutGetDto("directorio", "directorio","servidor", "puerto", "patron",
                "patron", "id", "tipoProceso", "userId", "estatus", "idProtocolo", "idContrato",
                "idPtcl", mock(PutGetWSDto.class), "numeroContrato", "codigoCliente");

        assertNotNull(putGetDtoResponse);
    }

    @Test
    void getDirectorio() {
        putGetDtoResponse.setDirectorio("directorio");
        assertEquals("directorio", putGetDtoResponse.getDirectorio());
    }

    @Test
    void getDirectorioGet() {
        putGetDtoResponse.setDirectorioGet("directorio");
        assertEquals("directorio", putGetDtoResponse.getDirectorioGet());
    }

    @Test
    void getServidor() {
        putGetDtoResponse.setServidor("servidor");
        assertEquals("servidor", putGetDtoResponse.getServidor());
    }

    @Test
    void getPuerto() {
        putGetDtoResponse.setPuerto("puerto");
        assertEquals("puerto", putGetDtoResponse.getPuerto());
    }

    @Test
    void getPatron() {
        putGetDtoResponse.setPatron("patron");
        assertEquals("patron", putGetDtoResponse.getPatron());
    }

    @Test
    void getPatronGet() {
        putGetDtoResponse.setPatronGet("patron");
        assertEquals("patron", putGetDtoResponse.getPatronGet());
    }

    @Test
    void getIdPtclPara() {
        putGetDtoResponse.setIdPtclPara("id");
        assertEquals("id", putGetDtoResponse.getIdPtclPara());
    }

    @Test
    void getTipoProceso() {
        putGetDtoResponse.setTipoProceso("tipo");
        assertEquals("tipo", putGetDtoResponse.getTipoProceso());
    }

    @Test
    void getUserId() {
        putGetDtoResponse.setUserId("id");
        assertEquals("id", putGetDtoResponse.getUserId());
    }

    @Test
    void getEstatus() {
        putGetDtoResponse.setEstatus("estatus");
        assertEquals("estatus", putGetDtoResponse.getEstatus());
    }

    @Test
    void getIdProtocolo() {
        putGetDtoResponse.setIdProtocolo("id");
        assertEquals("id", putGetDtoResponse.getIdProtocolo());
    }

    @Test
    void getIdContrato() {
        putGetDtoResponse.setIdContrato("id");
        assertEquals("id", putGetDtoResponse.getIdContrato());
    }

    @Test
    void getIdPtclPath() {
        putGetDtoResponse.setIdPtclPath("id");
        assertEquals("id", putGetDtoResponse.getIdPtclPath());
    }

    @Test
    void getPutGetWSDto() {
        PutGetWSDto putGetWSDto = mock(PutGetWSDto.class);
        putGetDtoResponse.setPutGetWSDto(putGetWSDto);
        assertEquals(putGetWSDto, putGetDtoResponse.getPutGetWSDto());
    }

    @Test
    void toStringTest() {
        assertNotNull(putGetDtoResponse.toString());
    }
}