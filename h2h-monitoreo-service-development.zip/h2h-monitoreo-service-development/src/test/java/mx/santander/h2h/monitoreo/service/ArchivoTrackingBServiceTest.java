package mx.santander.h2h.monitoreo.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.NivelArchivoRequest;
import mx.santander.h2h.monitoreo.model.response.ArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ProdArchResponse;
import mx.santander.h2h.monitoreo.model.response.ProductoArchivoResponse;
import mx.santander.h2h.monitoreo.repository.IConsultaTrackingNativeBRepository;
import mx.santander.h2h.monitoreo.repository.IConsultaTrackingNativeRepository;
import mx.santander.h2h.monitoreo.repository.IConsultaTrackingRepository;

@ExtendWith(MockitoExtension.class)
class ArchivoTrackingBServiceTest {
	
	@InjectMocks
	private ArchivoTrackingBService archivoTrackingBService;
	
	@Mock
	private IConsultaTrackingNativeRepository consultaTrackingNativeRepository;
	
	@Mock
	private IConsultaTrackingRepository consultaTrackingRepository;
	
	@Mock
	private IConsultaTrackingNativeBRepository consultaTrackingNativeBRepository;
	
	@Mock
	private IJasperReportService reportService;
	
	@Test
	void obtenerDetalleArchivosTest() {
		Assertions.assertNull(archivoTrackingBService.obtenerDetalleArchivos("79240991", Pageable.ofSize(1)));
	}

	@Test
	void consultaTrakingNivelArchivoTest() {
		Mockito.when(this.consultaTrackingRepository.obtenerConteoArchivosNivelArchivo(Mockito.anyString(), Mockito.anyString())).thenReturn(obtenerConteoArchivosResult());
		
		archivoTrackingBService.consultaTrakingNivelArchivo(nivelArchivoReq());
		
		Assertions.assertTrue(true);
	}
	
	@Test
	void testObtenerDetalleArchivos() {
		Mockito.when(this.consultaTrackingRepository.obtenerConteoArchivosNivelArchivo(Mockito.anyString(), Mockito.anyString())).thenReturn(obtenerConteoArchivosResult());
		
		ArchivoResponse result = archivoTrackingBService.obtenerConteoArchivosNivelArchivo(Mockito.anyString(), Mockito.anyString());
		Assertions.assertNotNull(result);
	}
	
	public NivelArchivoRequest nivelArchivoReq() {
		NivelArchivoRequest request = new NivelArchivoRequest();
		
		request.setIdCliente("79240991");
		request.setCliente("Nombre Cliente");
		request.setEstatus(5);
		request.setNombreArchivo("nombreArch.jkh");
		
		return request;
	}
	
	private List<Object[]> obtenerConteoArchivosResult(){
		List<Object[]> respuesta = new ArrayList<Object[]>();
		
		Object[] resultBd = {new BigDecimal("88"),new BigDecimal("122396"),new BigDecimal("124369.62"),new BigDecimal("0"),new BigDecimal("0"),
				new BigDecimal("0"),new BigDecimal("3"),new BigDecimal("0"),new BigDecimal("80"),new BigDecimal("5"),
				new BigDecimal("0"),};
		
		respuesta.add(resultBd);
		
		return respuesta;
	}
	
	@Test
	void obtenerDetalleArchivosNivelArchivo(){
		List<ProductoArchivoResponse> companies = new ArrayList<>();
//		Page<ProductoArchivoResponse> pagedResponse = new PageImpl(companies);
		Map<String, Object> datResponse = new HashMap<>();
		Mockito.when(this.consultaTrackingNativeBRepository.obtenerDetalleArchivosNivelArchivo(Mockito.any(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenReturn(datResponse);
		
		archivoTrackingBService.obtenerDetalleArchivosNivelArchivo(nivelArchivoReq(), Pageable.ofSize(1));
		
		Assertions.assertTrue(true);
	}
	
	@Test
	void obtenerListDetalleArchivosNivelArchivo(){
		//List<ProductoArchivoResponse> pagedResponse = new ArrayList<ProductoArchivoResponse>();
		List<ProdArchResponse> pagedResponse = new ArrayList<>();
		Mockito.when(this.consultaTrackingNativeBRepository.obtenerListDetalleArchivosNivelArchivo(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenReturn(pagedResponse);
		
		archivoTrackingBService.obtenerListDetalleArchivosNivelArchivo(nivelArchivoReq());
		
		Assertions.assertTrue(true);
	}
	
	@Test
	void getReportXls(){
		ReportResponse responseData = new ReportResponse();
		responseData.setData("data");
		responseData.setLength(12);
		responseData.setName("name");
		responseData.setType("application/octet-stream");
		
		//List<ProductoArchivoResponse> pagedResponse = new ArrayList<ProductoArchivoResponse>();
		List<ProdArchResponse> pagedResponse = new ArrayList<>();
		Mockito.when(this.consultaTrackingRepository.obtenerConteoArchivosNivelArchivo(Mockito.anyString(), Mockito.anyString())).thenReturn(obtenerConteoArchivosResult());
		Mockito.when(this.consultaTrackingNativeBRepository.obtenerListDetalleArchivosNivelArchivo(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenReturn(pagedResponse);
		Mockito.when(reportService.getXls(Mockito.anyString(), Mockito.any(), Mockito.any())).thenReturn(responseData);
		
		archivoTrackingBService.getReportXls(nivelArchivoReq(), "Kaori");
		
		Assertions.assertTrue(true);
	}
}
