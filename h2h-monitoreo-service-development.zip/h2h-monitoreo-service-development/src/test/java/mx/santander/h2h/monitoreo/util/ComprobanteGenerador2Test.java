package mx.santander.h2h.monitoreo.util;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mockConstruction;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedConstruction;

import mx.isban.h2h.comprobantes.GeneradorComprobantes;
import mx.isban.h2h.comprobantes.model.Comprobante;
import mx.isban.h2h.comprobantes.model.ComprobanteSalida;
import mx.santander.h2h.monitoreo.model.response.ComprobantesOperacionResponse;

class ComprobanteGenerador2Test {

    MockedConstruction<GeneradorComprobantes> generadorComprobantes;

    byte[] ret = new byte[]{(byte) 89};

    @BeforeEach
    void setUp() {
        ComprobanteSalida salida = new ComprobanteSalida();
        salida.setComprobanteBytes(ret);
        generadorComprobantes = mockConstruction(GeneradorComprobantes.class, (generador, context) ->
                when(generador.generaComprobante(any())).thenReturn(salida)
        );
    }

    @AfterEach
    void after() {
        generadorComprobantes.close();
    }

    @Test
    void testGeneraOrdenPago() {
        byte[] result = ComprobanteGenerador2.generaOrdenPago(new ComprobantesOperacionResponse());
        Assertions.assertArrayEquals(ret, result);
    }

    @Test
    void testGeneraVostro() {
        ComprobantesOperacionResponse obj = new ComprobantesOperacionResponse();

        obj.setTipoOper("-39-");
        byte[] result = ComprobanteGenerador2.generaVostro(obj);
        Assertions.assertArrayEquals(ret, result);

        obj.setTipoOper("-38-");
        result = ComprobanteGenerador2.generaVostro(obj);
        Assertions.assertArrayEquals(ret, result);

        obj.setTipoOper("-32-");
        result = ComprobanteGenerador2.generaVostro(obj);
        Assertions.assertArrayEquals(ret, result);
    }

    @Test
    void testGeneraOrdenPagoAtm() {
        byte[] result = ComprobanteGenerador2.generaOrdenPagoAtm(new ComprobantesOperacionResponse());
        Assertions.assertArrayEquals(ret, result);
    }

    @Test
    void testGeneraReportes() {
        byte[] result = ComprobanteGenerador2.generaReportes(new ComprobantesOperacionResponse(), Comprobante.SPEI);
        Assertions.assertArrayEquals(ret, result);
    }

    @Test
    void testGeneraReportesPD() {
        byte[] result = ComprobanteGenerador2.generaReportesPD(new ComprobantesOperacionResponse(), Comprobante.SPEI);
        Assertions.assertArrayEquals(ret, result);
    }

    @Test
    void testGeneraTransferenciasCambiarias() {
        byte[] result = ComprobanteGenerador2.generaTransferenciasCambiarias(new ComprobantesOperacionResponse());
        Assertions.assertArrayEquals(ret, result);
    }

}
