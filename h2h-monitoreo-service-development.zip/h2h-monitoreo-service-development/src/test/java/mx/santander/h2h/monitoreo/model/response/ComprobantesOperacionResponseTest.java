package mx.santander.h2h.monitoreo.model.response;

import mx.santander.h2h.monitoreo.util.JavaBeanTester;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ComprobantesOperacionResponseTest {
    ComprobantesOperacionResponse comprobantesOperacionResponse = new ComprobantesOperacionResponse();

    @Test
    void testFields() {
        Assertions.assertDoesNotThrow(() ->
                JavaBeanTester.test(ComprobantesOperacionResponse.class)
        );
    }

    @Test
    void testHashCode() {
        int result = comprobantesOperacionResponse.hashCode();
        Assertions.assertNotEquals(0, result);
    }

    @Test
    void testToString() {
        String result = comprobantesOperacionResponse.toString();
        Assertions.assertNotNull(result);
    }
}
