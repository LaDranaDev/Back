package mx.santander.h2h.monitoreo.model.response;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class CatalogChannelResponseTest {
    CatalogChannelResponse catalogChannelResponse = new CatalogChannelResponse();

    @Test
    void testSetIdChannel() {
        catalogChannelResponse.setIdChannel(1);
        Assertions.assertEquals(1, catalogChannelResponse.getIdChannel());
    }

    @Test
    void testSetName() {
        catalogChannelResponse.setName("name");
        Assertions.assertEquals("name", catalogChannelResponse.getName());
    }

    @Test
    void testSetDescription() {
        catalogChannelResponse.setDescription("description");
        Assertions.assertEquals("description", catalogChannelResponse.getDescription());
    }

    @Test
    void testSetStatus() {
        catalogChannelResponse.setStatus("status");
        Assertions.assertEquals("status", catalogChannelResponse.getStatus());
    }

    @Test
    void testToString() {
        String result = catalogChannelResponse.toString();
        Assertions.assertNotNull(result);
    }
}
