package mx.santander.h2h.monitoreo.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.NivelOperacionRequest;
import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import mx.santander.h2h.monitoreo.model.response.OperacionArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ProductoArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ResultTrackingResponse;
import mx.santander.h2h.monitoreo.repository.IConsultaTrackingOperacionRepository;

@ExtendWith(MockitoExtension.class)
class ConsultaTrackingOperacionServiceTest {
	
	@InjectMocks
	private ConsultaTrackingOperacionService consultaTrackingOperacionService;
	
	@Mock
	private IConsultaTrackingOperacionRepository consultaTrackingOperacionRepository;
	
	/**
	 * Servicio para generacion de Reportes con JasperReport
	 */
	@Mock
	private IJasperReportService jasperReportService;

	@Test
	void iniciaNivelOperacionTest() {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		resultTrackingResponse.setListCombo(obtenerCatalogoEstatus());
		resultTrackingResponse.setArchProd(prodArchResponse());
		
		Mockito.when(this.consultaTrackingOperacionRepository.obtenerCatalogoEstatus(Mockito.anyString())).thenReturn(resultTrackingResponse);
		Mockito.when(this.consultaTrackingOperacionRepository.obtenerConteoArchivo(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(resultTrackingResponse);
		consultaTrackingOperacionService.iniciaNivelOperacion(nivelProductoReq());
		
		Assertions.assertTrue(true);
	}
	
	public List<ComboResponse> obtenerCatalogoEstatus(){
		List<ComboResponse> listCombo = new ArrayList<>();
		
		ComboResponse combo = new ComboResponse();
		combo.setId(1);
		combo.setValor("Final");
		
		listCombo.add(combo);
		
		return listCombo;
	}

	public NivelOperacionRequest nivelProductoReq() {
		NivelOperacionRequest nivelOper = new NivelOperacionRequest();
		
		nivelOper.setIdArchivo(74593);
		nivelOper.setIdProducto(12345);
		nivelOper.setCodCliente("12345678");
		nivelOper.setNomCliente("Kaori");
		nivelOper.setIdEstatus(5);
		
		return nivelOper;
	}
	
	public ProductoArchivoResponse prodArchResponse(){
		ProductoArchivoResponse archivoResponse = new ProductoArchivoResponse();
		return archivoResponse;
	}
	
	@Test
	void obtenerDetalleArchivosNivelArchivo(){
		List<OperacionArchivoResponse> companies = new ArrayList<>();
		Page<OperacionArchivoResponse> pagedResponse = new PageImpl(companies);
		
		Mockito.when(this.consultaTrackingOperacionRepository.obtenerDetalleArchivo(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(pagedResponse);
		
		Assertions.assertNotNull(consultaTrackingOperacionService.obtenerDetalleArchivo(nivelProductoReq(), Pageable.ofSize(1)));
	}
	
	@Test
	void getReportXls(){
		ReportResponse responseData = new ReportResponse();
		responseData.setData("data");
		responseData.setLength(12);
		responseData.setName("name");
		responseData.setType("application/octet-stream");
		
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		resultTrackingResponse.setListCombo(obtenerCatalogoEstatus());
		resultTrackingResponse.setArchProd(prodArchResponse());
		
		Mockito.when(this.consultaTrackingOperacionRepository.obtenerCatalogoEstatus(Mockito.anyString())).thenReturn(resultTrackingResponse);
		Mockito.when(this.consultaTrackingOperacionRepository.obtenerConteoArchivo(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(resultTrackingResponse);
		Mockito.when(jasperReportService.getXls(Mockito.anyString(), Mockito.any(), Mockito.any())).thenReturn(responseData);
		
		consultaTrackingOperacionService.getReportXls(nivelOpeReq(), "Kaori");
		
		Assertions.assertTrue(true);
	}
	
	public NivelOperacionRequest nivelOpeReq() {
		NivelOperacionRequest nivelOperacionRequest = new NivelOperacionRequest();
		nivelOperacionRequest.setIdArchivo(74593);
		nivelOperacionRequest.setCodCliente("12345678");
		nivelOperacionRequest.setNomCliente("Ermelindo");
		nivelOperacionRequest.setIdEstatus(5);
		nivelOperacionRequest.setIdProducto(1);
    	return nivelOperacionRequest;
    }
}
