package mx.santander.h2h.monitoreo.controller;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.GeneralResponse;
import mx.santander.h2h.monitoreo.service.IOperationsMonitorAuxService;

class OperationsMonitorAuxControllerTest {
	@Mock
	IOperationsMonitorAuxService service;
	@InjectMocks
	OperationsMonitorAuxController controller;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testGeneraXmlOperaciones() {
		ResponseEntity<GeneralResponse> result = controller
				.generaXmlOperaciones(new OperationsMonitorQueryRequest());
		Assertions.assertNotNull(result);
	}
	
	@Test
	void generaXmlOperacionesExport() {
		ResponseEntity<GeneralResponse> result = controller
				.generaXmlOperacionesExport(new OperationsMonitorQueryRequest());
		Assertions.assertNotNull(result);
	}
}
