package mx.santander.h2h.monitoreo.util;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;

class UtilMonitorOperacionesSPIDTest {

    @Test
    void testEsProductoActivo() {
        OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();
        consultaOperaciones.setIdProducto("09");

        boolean result = UtilMonitorOperacionesSPID.esProductoActivo(consultaOperaciones.getIdProducto());
        Assertions.assertEquals(true, result);

        consultaOperaciones.setIdProducto("00");
        result = UtilMonitorOperacionesSPID.esProductoActivo(consultaOperaciones.getIdProducto());
        Assertions.assertEquals(false, result);
    }

    @Test
    void testGetselectSPID() {
    	StringBuilder query = new StringBuilder();
		
        UtilMonitorOperacionesSPID.getselectSPID(query, true);
        Assertions.assertNotNull(query);
    }
}
