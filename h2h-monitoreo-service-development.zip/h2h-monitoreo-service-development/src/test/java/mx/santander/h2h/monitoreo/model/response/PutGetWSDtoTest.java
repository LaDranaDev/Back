package mx.santander.h2h.monitoreo.model.response;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * PutGetWSDtoTest.
 *
 * @author Jesus Soto Aguilar
 * @since 04/05/2023
 */
class PutGetWSDtoTest {

    private PutGetWSDto putGetWSDto;

    @BeforeEach
    void setUp() {
        putGetWSDto = new PutGetWSDto();
    }

    @Test
    void getUriPUTWS() {
        putGetWSDto.setUriPUTWS("uri");
        assertEquals("uri", putGetWSDto.getUriPUTWS());
    }

    @Test
    void getUriGETWS() {
        putGetWSDto.setUriGETWS("uri");
        assertEquals("uri", putGetWSDto.getUriGETWS());
    }

    @Test
    void getUriConsultaWS() {
        putGetWSDto.setUriConsultaWS("uri");
        assertEquals("uri", putGetWSDto.getUriConsultaWS());
    }

    @Test
    void getCertificadoWS() {
        putGetWSDto.setCertificadoWS("cert");
        assertEquals("cert", putGetWSDto.getCertificadoWS());
    }

    @Test
    void toStringTest() {
        assertNotNull(putGetWSDto.toString());
    }
}