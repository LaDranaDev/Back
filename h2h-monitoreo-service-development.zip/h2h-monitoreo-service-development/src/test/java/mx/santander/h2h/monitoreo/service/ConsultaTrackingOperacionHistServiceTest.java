package mx.santander.h2h.monitoreo.service;

import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.NivelOperacionHistRequest;
import mx.santander.h2h.monitoreo.model.response.ProductoArchivoResponse;
import mx.santander.h2h.monitoreo.model.response.ResultTrackingResponse;
import mx.santander.h2h.monitoreo.repository.IConsultaTrackingOperacionHistRepository;

@ExtendWith(MockitoExtension.class)
class ConsultaTrackingOperacionHistServiceTest {
	
	@InjectMocks
	private ConsultaTrackingOperacionHistService consultaTrackingOperacionHistService;
	
	@Mock
	private IConsultaTrackingOperacionHistRepository consultaTrackingOperacionHistRepository;
	
	@Mock
	private IJasperReportService jasperReportService;

	@Test
	void test() {
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		resultTrackingResponse.setArchProd(prodArchResp());
		
		when(consultaTrackingOperacionHistRepository.obtenerConteoArchivo(Mockito.any())).thenReturn(resultTrackingResponse);
		consultaTrackingOperacionHistService.iniciaNivelOperacionHist(nivelOperHistReq());
		Assertions.assertTrue(true);
	}
	
	public NivelOperacionHistRequest nivelOperHistReq() {
		NivelOperacionHistRequest histRequest = new NivelOperacionHistRequest();
		
		histRequest.setIdReg(1234);
		histRequest.setNomCliente("Kaori");
		
		return histRequest;
	}
	
	public ProductoArchivoResponse prodArchResp() {
		ProductoArchivoResponse archivoResponse = new ProductoArchivoResponse();
		archivoResponse.setNombreArchivo("Nombre Archivo");
		archivoResponse.setEstatus("0");
		archivoResponse.setProducto("Producto");
		
		return archivoResponse;
	}
	
	@Test
	void obtenerDetalleArchivo() {
		consultaTrackingOperacionHistService.obtenerDetalleArchivo(12345, Pageable.ofSize(1));
		Assertions.assertTrue(true);
	}
	
	@Test
	void obtenerListDetalleArchivo() {
		consultaTrackingOperacionHistService.obtenerListDetalleArchivo(12345);
		Assertions.assertTrue(true);
	}
	
	@Test
    void getReportXls() {
    	ReportResponse responseData = new ReportResponse();
		responseData.setData("data");
		responseData.setLength(12);
		responseData.setName("name");
		responseData.setType("application/octet-stream");
		
		ResultTrackingResponse resultTrackingResponse = new ResultTrackingResponse();
		resultTrackingResponse.setArchProd(prodArchResp());
		
		when(consultaTrackingOperacionHistRepository.obtenerConteoArchivo(Mockito.any())).thenReturn(resultTrackingResponse);
    	Mockito.when(jasperReportService.getXls(Mockito.anyString(), Mockito.any(), Mockito.any())).thenReturn(responseData);
    	consultaTrackingOperacionHistService.getReportXls(nivelOperHistReq(), "Kaori");
    	Assertions.assertTrue(true);
    }

}
