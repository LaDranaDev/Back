package mx.santander.h2h.monitoreo.model.request;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class MonitorSaldosRequestTest {

    private MonitorSaldosRequest monitorSaldosRequest;

    @BeforeEach
    void setUp(){
        monitorSaldosRequest = new MonitorSaldosRequest();
    }

    @Test
    void getCodigoCliente() {
        monitorSaldosRequest.setCodigoCliente("codigo");
        assertEquals("codigo", monitorSaldosRequest.getCodigoCliente());
    }

    @Test
    void getNombreArchivo() {
        monitorSaldosRequest.setNombreArchivo("nombreArchivo");
        assertEquals("nombreArchivo", monitorSaldosRequest.getNombreArchivo());
    }

    @Test
    void getFechaInicio() {
        monitorSaldosRequest.setFechaInicio("fecha");
        assertEquals("fecha", monitorSaldosRequest.getFechaInicio());
    }

    @Test
    void getFechaFin() {
        monitorSaldosRequest.setFechaFin("fecha");
        assertEquals("fecha", monitorSaldosRequest.getFechaFin());
    }

    @Test
    void getClaveProducto() {
        monitorSaldosRequest.setClaveProducto("clave");
        assertEquals("clave", monitorSaldosRequest.getClaveProducto());
    }

    @Test
    void builder() {
        monitorSaldosRequest = MonitorSaldosRequest.builder().build();
        assertNotNull(monitorSaldosRequest);
    }

    @Test
    void toStringTest(){
        String response = MonitorSaldosRequest.builder().toString();
        assertNotNull(response);
    }

}