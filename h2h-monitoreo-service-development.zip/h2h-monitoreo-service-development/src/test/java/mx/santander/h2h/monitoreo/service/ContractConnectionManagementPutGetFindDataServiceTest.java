package mx.santander.h2h.monitoreo.service;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import mx.santander.h2h.monitoreo.model.response.PutGetDto;

class ContractConnectionManagementPutGetFindDataServiceTest {
	@Mock
	private EntityManager entityManager;
	@InjectMocks
	private ContractConnectionManagementPutGetFindDataService service;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}


	@Test
	void testFindNextValue() {
		Query query = mock(Query.class);
		List<BigDecimal> lst = new ArrayList<>();
		lst.add(new BigDecimal(1));
		when(query.getResultList()).thenReturn(lst);
		when(entityManager.createNativeQuery(anyString())).thenReturn(query);
		
		BigDecimal result = service.findNextValue("");
		Assertions.assertNotNull(result);
	}

	@Test
	void testBuscarDatosdeWS() {
		Query query = mock(Query.class);
		List<Object[]> lst = new ArrayList<>();
		Object[] arr = {"", "", "", ""};
		lst.add(arr);
		when(query.getResultList()).thenReturn(lst);
		when(entityManager.createNativeQuery(anyString())).thenReturn(query);
		
		service.buscarDatosdeWS(new PutGetDto());
		Assertions.assertTrue(true);
	}

	@Test
	void testBuscarDatosdeCD() {
		Query query = mock(Query.class);
		List<Object[]> lst = new ArrayList<>();
		Object[] arr = {"", "", "", "", "", "", "", "", "", "", "", ""};
		lst.add(arr);
		when(query.getResultList()).thenReturn(lst);
		when(entityManager.createNativeQuery(anyString())).thenReturn(query);
		
		service.buscarDatosdeCD(new PutGetDto());
		Assertions.assertTrue(true);
	}

	@Test
	void testBuscarDatosdeSFTP() {
		Query query = mock(Query.class);
		List<Object[]> lst = new ArrayList<>();
		Object[] arr = {"", "", ""};
		lst.add(arr);
		when(query.getResultList()).thenReturn(lst);
		when(entityManager.createNativeQuery(anyString())).thenReturn(query);
		
		service.buscarDatosdeSFTP(new PutGetDto());
		Assertions.assertTrue(true);
	}

}
