package mx.santander.h2h.monitoreo.model.request;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import mx.santander.h2h.monitoreo.model.entity.CatalogChannelEntity;
import mx.santander.h2h.monitoreo.model.entity.CatalogStatusEntity;
import mx.santander.h2h.monitoreo.model.report.request.GenerateVouchersReportDto;
import mx.santander.h2h.monitoreo.model.response.AccountResponse;
import mx.santander.h2h.monitoreo.model.response.ArchivoGeneralResponse;
import mx.santander.h2h.monitoreo.model.response.CatalogStatusResponse;
import mx.santander.h2h.monitoreo.model.response.CustomerResponse;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersDtoResponse;
import mx.santander.h2h.monitoreo.model.response.MonitorDeArchivosEnCursoDetallesOperacionResponse;
import mx.santander.h2h.monitoreo.model.response.MonitorDeArchivosEnCursoDetallesResponse;
import mx.santander.h2h.monitoreo.model.response.MonitorDeArchivosEnCursoResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;


class ContractConnectionManagementRequestTest {

    private ContractConnectionManagementRequest contractConnectionManagement;

    @BeforeEach
    void setUp(){
        contractConnectionManagement = new ContractConnectionManagementRequest();
    }

    @Test
    void allArgsConstruction() {
        contractConnectionManagement = new ContractConnectionManagementRequest("123", "1234", "");
        assertNotNull(contractConnectionManagement);
    }

    @Test
    void getNumeroContrato() {
        contractConnectionManagement.setNumeroContrato("123");
        assertEquals("123", contractConnectionManagement.getNumeroContrato());
    }

    @Test
    void getCodigoCliente() {
        contractConnectionManagement.setCodigoCliente("123");
        assertEquals("123", contractConnectionManagement.getCodigoCliente());
    }

    @Test
    void testToString() {
    	getGenerateVouchersReportDto();
    	getMonitorDeArchivosEnCursoResponse();
    	getMonitorDeArchivosEnCursoDetallesResponse();
    	getMonitorDeArchivosEnCursoDetallesOperacionResponse();
    	getGenerateVouchersDtoResponse();
    	getCustomerResponse();
    	getCatalogStatusResponse();
    	getArchivoGeneralResponse();
    	getAccountResponse();
    	
        assertNotNull(contractConnectionManagement.toString());
    }
    
    private GenerateVouchersReportDto getGenerateVouchersReportDto() {
    	GenerateVouchersReportDto response = new GenerateVouchersReportDto();
    	response.setConsultaOperaciones(null);
    	response.setListaOperaciones(null);
    	
    	response.getConsultaOperaciones();
    	response.getListaOperaciones();
    	
    	response.toString();
    	
    	CatalogStatusEntity entity = new CatalogStatusEntity();
    	
    	entity.setDescripcionCatalogo(null);
    	entity.setEstatusActivo(null);
    	entity.setIdCat(null);
    	entity.setType(null);
    	
    	entity.getDescripcionCatalogo();
    	entity.getEstatusActivo();
    	entity.getIdCat();
    	entity.getType();
    	
    	entity.toString();
    	
    	CatalogChannelEntity entity2 = new CatalogChannelEntity();
    	
    	entity2.setDescription(null);
    	entity2.setIdCenter(null);
    	entity2.setIdChannel(null);
    	entity2.setName(null);
    	entity2.setStatus(null);
    	entity2.setStatusSelected(null);
    	
    	entity2.getDescription();
    	entity2.getIdCenter();
    	entity2.getIdChannel();
    	entity2.getName();
    	entity2.getStatus();
    	entity2.getStatusSelected();
    	
    	entity2.toString();
    	
    	return response;
    }
    
    private MonitorDeArchivosEnCursoResponse getMonitorDeArchivosEnCursoResponse() {
    	MonitorDeArchivosEnCursoResponse response = new MonitorDeArchivosEnCursoResponse();
    	response.setCodError(null);
    	response.setMonitorDeArchivosEnCurso(null);
    	response.setMonitorDeArchivosEnCursoOperacion(null);
    	
    	response.getCodError();
    	response.getMonitorDeArchivosEnCurso();
    	response.getMonitorDeArchivosEnCursoOperacion();
    	
    	response.toString();
    	
    	return response;
    }
    
    private MonitorDeArchivosEnCursoDetallesResponse getMonitorDeArchivosEnCursoDetallesResponse() {
    	MonitorDeArchivosEnCursoDetallesResponse response = new MonitorDeArchivosEnCursoDetallesResponse();
    	response.setBuc(null);
    	response.setCliente(null);
    	response.setCveProdOper(null);
    	response.setDescEstatus(null);
    	response.setDescProd(null);
    	response.setFechaOrder(null);
    	response.setFechaRegistro(null);
    	response.setIdArchivo(null);
    	response.setIdClte(null);
    	response.setIdEstatus(null);
    	response.setIdProd(null);
    	response.setMotiRech(null);
    	response.setNombCanl(null);
    	response.setNombreArch(null);
    	response.setNumContrato(null);
    	response.setRazonScia(null);
    	response.setTotalMont(null);
    	response.setTotalOper(null);
    	
    	response.getBuc();
    	response.getCliente();
    	response.getCveProdOper();
    	response.getDescEstatus();
    	response.getDescProd();
    	response.getFechaOrder();
    	response.getFechaRegistro();
    	response.getIdArchivo();
    	response.getIdClte();
    	response.getIdEstatus();
    	response.getIdProd();
    	response.getMotiRech();
    	response.getNombCanl();
    	response.getNombreArch();
    	response.getNumContrato();
    	response.getRazonScia();
    	response.getTotalMont();
    	response.getTotalOper();
    	
    	response.toString();
    	
    	return response;
    }
    
    private MonitorDeArchivosEnCursoDetallesOperacionResponse getMonitorDeArchivosEnCursoDetallesOperacionResponse() {
    	MonitorDeArchivosEnCursoDetallesOperacionResponse response = new MonitorDeArchivosEnCursoDetallesOperacionResponse();
    	response.setCtaBen(null);
    	response.setCtaOrd(null);
    	response.setCveProdOper(null);
    	response.setCveRasteroSpei(null);
    	response.setDescEstatus(null);
    	response.setDescProd(null);
    	response.setFechaApli(null);
    	response.setFechaEnvBe(null);
    	response.setFechaRespBe(null);
    	response.setIdReg(null);
    	response.setImporte(null);
    	response.setUmbr(null);
    	
    	response.getCtaBen();
    	response.getCtaOrd();
    	response.getCveProdOper();
    	response.getCveRasteroSpei();
    	response.getDescEstatus();
    	response.getDescProd();
    	response.getFechaApli();
    	response.getFechaEnvBe();
    	response.getFechaRespBe();
    	response.getIdReg();
    	response.getImporte();
    	response.getUmbr();
    	
    	response.toString();
    	
    	return response;
    }
    
    private GenerateVouchersDtoResponse getGenerateVouchersDtoResponse() {
    	GenerateVouchersDtoResponse response = new GenerateVouchersDtoResponse();
    	response.setCdmxBean(null);
    	response.setCodError(null);
    	response.setConceptoValor(null);
    	response.setImporteTotal(null);
    	response.setListaOperaciones(null);
    	response.setListaTipoPago(null);
    	response.setMsgError(null);
    	response.setParametrosAdicionalesComprobante(null);
    	response.setTotalArchivos(null);
    	response.setTotalOperaciones(null);
    	
    	response.getCdmxBean();
    	response.getCodError();
    	response.getConceptoValor();
    	response.getImporteTotal();
    	response.getListaOperaciones();
    	response.getListaTipoPago();
    	response.getMsgError();
    	response.getParametrosAdicionalesComprobante();
    	response.getTotalArchivos();
    	response.getTotalOperaciones();
    	
    	response.toString();
    	
    	return response;
    }
    
    private CustomerResponse getCustomerResponse() {
    	CustomerResponse response = new CustomerResponse();
    	response.setApMaterno(null);
    	response.setApPaterno(null);
    	response.setBuc(null);
    	response.setCondicion(null);
    	response.setEjecutivo(null);
    	response.setFecha(null);
    	response.setIdCliente(0);
    	response.setIdSegmento(null);
    	response.setNemonico(null);
    	response.setNombre(null);
    	response.setPersonalidad(null);
    	response.setRazonSocial(null);
    	response.setRfc(null);
    	
    	response.getApMaterno();
    	response.getApPaterno();
    	response.getBuc();
    	response.getCondicion();
    	response.getEjecutivo();
    	response.getFecha();
    	response.getIdCliente();
    	response.getIdSegmento();
    	response.getNemonico();
    	response.getNombre();
    	response.getPersonalidad();
    	response.getRazonSocial();
    	response.getRfc();
    	
    	response.toString();
    	
    	return response;
    }
    
    private CatalogStatusResponse getCatalogStatusResponse() {
    	CatalogStatusResponse response = new CatalogStatusResponse();
    	response.setDescripcionCatalogo(null);
    	response.setEstatusActivo(null);
    	response.setIdCat(null);
    	response.setType(null);
    	
    	response.getDescripcionCatalogo();
    	response.getEstatusActivo();
    	response.getIdCat();
    	response.getType();
    	
    	response.toString();
    	
    	return response;
    }
    
    private ArchivoGeneralResponse getArchivoGeneralResponse() {
    	ArchivoGeneralResponse response = new ArchivoGeneralResponse();
    	response.setDetalleArchivo(null);
    	response.setSubtotal(null);
    	
    	response.getDetalleArchivo();
    	response.getSubtotal();
    	
    	response.toString();
    	return response;
    }
    
    private AccountResponse getAccountResponse() {
    	AccountResponse response = new AccountResponse();
    	response.setActualizaBic(null);
    	response.setBandActivo(null);
    	response.setBandIntercambiaria(null);
    	response.setBandPersonalidad(null);
    	response.setBic(null);
    	response.setBicAnterior(null);
    	response.setCodigo(null);
    	response.setFechaAlta(null);
    	response.setIdContrato(0);
    	response.setIdContratoCuenta(null);
    	response.setIdContratoStr(null);
    	response.setIdDivisa(null);
    	response.setNoComisiones(null);
    	response.setNumCuenta(null);
    	response.setStatusCuenta(null);
    	response.setTerceroPropio(null);
    	response.setTerceros(null);
    	response.setTipoCuenta(null);
    	response.setTitular(null);
    	
    	response.getActualizaBic();
    	response.getBandActivo();
    	response.getBandIntercambiaria();
    	response.getBandPersonalidad();
    	response.getBic();
    	response.getBicAnterior();
    	response.getCodigo();
    	response.getFechaAlta();
    	response.getIdContrato();
    	response.getIdContratoCuenta();
    	response.getIdContratoStr();
    	response.getIdDivisa();
    	response.getNoComisiones();
    	response.getNumCuenta();
    	response.getStatusCuenta();
    	response.getTerceroPropio();
    	response.getTerceros();
    	response.getTipoCuenta();
    	response.getTitular();
    	
    	response.toString();
    	return response;
    }
}