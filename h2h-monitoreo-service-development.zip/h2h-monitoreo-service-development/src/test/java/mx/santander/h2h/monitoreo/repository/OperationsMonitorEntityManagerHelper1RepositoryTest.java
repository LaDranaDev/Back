package mx.santander.h2h.monitoreo.repository;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.util.UtilMonitorFnc;

class OperationsMonitorEntityManagerHelper1RepositoryTest {
    @Mock
    Logger log;
    @InjectMocks
    OperationsMonitorEntityManagerHelper1Repository operationsMonitorEntityManagerHelper1Repository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    private static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

    @Test
    void testPreparaConsultaOperaciones() {
    	StringBuilder querySQL = new StringBuilder();
    	Map<String, Object> params = new HashMap<String, Object>();
    	
        String today = sdf.format(new Date());

        OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();
        consultaOperaciones.setFechaInicial(today);

        consultaOperaciones.setIdProducto("81");
        OperationsMonitorEntityManagerHelper1Repository.preparaConsultaOperaciones(consultaOperaciones, querySQL, params);
    	// Obtenemos el Query del Mapa de Datos
		//String query = UtilMonitorFnc.getQuery(resCall);
        if( "".equals(querySQL.toString()) ) {
        	assertNull(querySQL);
        } else {
        	assertNotNull(querySQL);
        }

        consultaOperaciones.setIdProducto("93");
        // Obtenemos los datos del MAPA Query y Parametros
        OperationsMonitorEntityManagerHelper1Repository.preparaConsultaOperaciones(consultaOperaciones, querySQL, params);
        // Obtenemos el Query del Mapa de Datos
        //querySQL = UtilMonitorFnc.getQuery(resCall);
        if( "".equals(querySQL.toString()) ) {
            assertNull(querySQL);
        } else {
            assertNotNull(querySQL);
        }
        
        consultaOperaciones.setIdProducto("01");
        // Obtenemos los datos del MAPA Query y Parametros
        OperationsMonitorEntityManagerHelper1Repository.preparaConsultaOperaciones(consultaOperaciones, querySQL, params);
        // Obtenemos el Query del Mapa de Datos
        //querySQL = UtilMonitorFnc.getQuery(resCall);
        if( "".equals(querySQL.toString()) ) {
            assertNull(querySQL);
        } else {
            assertNotNull(querySQL);
        }
        

        consultaOperaciones.setFechaInicial("02/02/2020");
        consultaOperaciones.setIdProducto("81");
        // Obtenemos los datos del MAPA Query y Parametros
        OperationsMonitorEntityManagerHelper1Repository.preparaConsultaOperaciones(consultaOperaciones, querySQL, params);
        // Obtenemos el Query del Mapa de Datos
        //querySQL = UtilMonitorFnc.getQuery(resCall);
        if( "".equals(querySQL.toString()) ) {
            assertNull(querySQL);
        } else {
            assertNotNull(querySQL);
        }
        
        
        consultaOperaciones.setIdProducto("93");
        // Obtenemos los datos del MAPA Query y Parametros
        OperationsMonitorEntityManagerHelper1Repository.preparaConsultaOperaciones(consultaOperaciones, querySQL, params);
        // Obtenemos el Query del Mapa de Datos
        //querySQL = UtilMonitorFnc.getQuery(resCall);
        if( "".equals(querySQL.toString()) ) {
            assertNull(querySQL);
        } else {
            assertNotNull(querySQL);
        }
        
        
        consultaOperaciones.setIdProducto("01");
        // Obtenemos los datos del MAPA Query y Parametros
        OperationsMonitorEntityManagerHelper1Repository.preparaConsultaOperaciones(consultaOperaciones, querySQL, params);
        // Obtenemos el Query del Mapa de Datos
        //querySQL = UtilMonitorFnc.getQuery(resCall);
        if( "".equals(querySQL.toString()) ) {
            assertNull(querySQL);
        } else {
            assertNotNull(querySQL);
        }
    }

    
    @Test
    void testAppendWhereConsultaOperaciones() {
    	StringBuilder querySQL = new StringBuilder();
        Map<String, Object> params = new HashMap<>();
        

        OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();
        consultaOperaciones.setBuc("buc");
        consultaOperaciones.setContrato("contrato");
        consultaOperaciones.setNombreArchivo("nombreArchivo");
        consultaOperaciones.setIdProducto("23");
        consultaOperaciones.setIdEstatus("idEstatus");
        consultaOperaciones.setCuentaCargo("cuentaCargo");
        consultaOperaciones.setCuentaAbono("cuentaAbono");
        consultaOperaciones.setImporte("importe");
        consultaOperaciones.setReferencia("referencia");
        consultaOperaciones.setDivisa("MXP");
        consultaOperaciones.setNumeroOrden("numeroOrden");
        consultaOperaciones.setNombreBeneficiario("nombreBeneficiario");
        consultaOperaciones.setIdReg("idReg");
        consultaOperaciones.setNumEmpleado("numEmpleado");
        consultaOperaciones.setNumTarjeta("numTarjeta");
        consultaOperaciones.setSucTutora("sucTutora");
        consultaOperaciones.setTipo("tipo");
        consultaOperaciones.setLineaCaptura("lineaCaptura");
        consultaOperaciones.setConvenio("convenio");
        consultaOperaciones.setFolioSUA("folioSUA");
        consultaOperaciones.setRegPat("regPat");

        // Obtenemos los datos del MAPA Query y Parametros
        OperationsMonitorEntityManagerHelper1Repository.getSelectConsultaOperaciones(consultaOperaciones, querySQL, params, false);
        if( querySQL.length() > 0 ) {
			assertTrue( ( querySQL.length() > 0 ) );
		} else {
			assertFalse( ( querySQL.length() > 0 ) );
		}
        
        consultaOperaciones.setDivisa("USD");
        consultaOperaciones.setTipo("PREEXISTENTE");
        // Obtenemos los datos del MAPA Query y Parametros
        OperationsMonitorEntityManagerHelper1Repository.getSelectConsultaOperaciones(consultaOperaciones, querySQL, params, true);
        if( querySQL.length() > 0 ) {
			assertTrue( ( querySQL.length() > 0 ) );
		} else {
			assertFalse( ( querySQL.length() > 0 ) );
		}
    }

    @Test
    void testGetSelectConsultaOperaciones() {
    	StringBuilder querySQL = new StringBuilder();
        Map<String, Object> params = new HashMap<>();
        OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();
        consultaOperaciones.setIdProducto("11");
        consultaOperaciones.setCveProveedor("cveProveedor");
        consultaOperaciones.setTipOperacion("");

        // Obtenemos los datos del MAPA Query y Parametros
        OperationsMonitorEntityManagerHelper1Repository.getSelectConsultaOperaciones(consultaOperaciones, querySQL, params, true);
        if( querySQL.length() > 0 ) {
			assertTrue( ( querySQL.length() > 0 ) );
		} else {
			assertFalse( ( querySQL.length() > 0 ) );
		}

        consultaOperaciones.setTipOperacion("tipOperacion");
        // Obtenemos los datos del MAPA Query y Parametros
        OperationsMonitorEntityManagerHelper1Repository.getSelectConsultaOperaciones(consultaOperaciones, querySQL, params, true);
        if( querySQL.length() > 0 ) {
			assertTrue( ( querySQL.length() > 0 ) );
		} else {
			assertFalse( ( querySQL.length() > 0 ) );
		}
    }

    @Test
    void testGetQueryPaginado() {
    	StringBuilder querySQL = new StringBuilder();
    	StringBuilder queryCountSQL = new StringBuilder();
    	Map<String, Object> params = null;
    	
    	try {
	    	UtilMonitorFnc.getQueryPaginado(querySQL.toString(), queryCountSQL, params, 0, 0);
	    } catch(Exception e) { }
        
    	if( "".equals(queryCountSQL.toString()) ) {
        	assertNull(queryCountSQL);
        } else {
        	assertNotNull(queryCountSQL);
        }
        if(params == null) {
        	assertNull(params);
        }
    }
}
