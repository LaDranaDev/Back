package mx.santander.h2h.monitoreo.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mockConstruction;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedConstruction;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.ClassPathResource;

import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.report.request.MonitorSaldosReportRequest;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.MonitorSaldosRequest;
import mx.santander.h2h.monitoreo.model.response.MonitorSaldosResponse;
import mx.santander.h2h.monitoreo.model.response.ProductResponse;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.util.JRLoader;

@ExtendWith(MockitoExtension.class)
class MonitorSaldosReportServiceTest {

    @Mock
    private IMonitorSaldosService monitorSaldosService;
    
    @Mock
    private IProductService productService;

    @Mock
    private JasperReportService jasperReportService;

    @InjectMocks
    private MonitorSaldosReportService monitorSaldosReportService;

    @Test
    void getReportSaldosReintentos() {
        List<MonitorSaldosResponse> saldosReintentos = new ArrayList<>();
        saldosReintentos.add(getResponse());

        when(monitorSaldosService.getSaldosReintentosCliente(any(MonitorSaldosRequest.class)))
                .thenReturn(saldosReintentos);

        when(jasperReportService.getXls(anyString(), anyMap(), anyList()))
                .thenReturn(getReportResponse());
        
        when(productService.getProductoByClave(anyString())).thenReturn(new ProductResponse());
        
        ReportResponse response = monitorSaldosReportService.getReportSaldosReintentos(getRequest());

        assertNotNull(response);
        assertTrue(response.getName().contains("xlsx"));
        assertEquals("application/octet-stream", response.getType());
    }

    @Test
    void getReportSaldosReintentosJRException() {
        MonitorSaldosReportRequest request = getRequest();

        try(MockedStatic<JRLoader> jrLoaderMockedStatic = mockStatic(JRLoader.class)) {
        	 when(productService.getProductoByClave(anyString())).thenReturn(new ProductResponse());
        	 
            jrLoaderMockedStatic.when(() -> JRLoader.loadObject(any(InputStream.class)))
                    .thenThrow(JRException.class);
            assertThrows(BusinessException.class, () ->
                    monitorSaldosReportService.getReportSaldosReintentos(request));
        }
    }

    @Test
    void getReportSaldosReintentosIOException() {
        MonitorSaldosReportRequest request = getRequest();

        when(productService.getProductoByClave(anyString())).thenReturn(new ProductResponse());
        
        try(MockedConstruction<ClassPathResource> mockedConstruction =
                    mockConstruction(ClassPathResource.class,
                            (classPathResource, context) -> {
                                doThrow(IOException.class).when(classPathResource).getInputStream();
                            })) {

            assertThrows(BusinessException.class, () ->
                    monitorSaldosReportService.getReportSaldosReintentos(request));
        }
    }

    private static MonitorSaldosReportRequest getRequest() {
        return MonitorSaldosReportRequest.builder()
                .monitorSaldosRequest(MonitorSaldosRequest.builder()
                        .codigoCliente("04158057")
                        .nombreArchivo("2013")
                        .claveProducto("98")
                        .fechaInicio("23/08/2013")
                        .fechaFin("04/09/2013")
                        .build())
                .usuario("usuario_test")
                .build();
    }

    private static MonitorSaldosResponse getResponse() {
        return MonitorSaldosResponse.builder()
                .cuentaOrdenante("60500694011")
                .fechaEnvioConsulta("04/09/2013")
                .horaEnvioConsulta("22:31:04")
                .montoRequerido("$20,000,000.15")
                .saldoConsulta("$47,526.51")
                .saldoFaltante("$19,952,473.64")
                .lineaCredito("N")
                .nombreArchivo("tran04092013")
                .cveProdOper("98")
                .producto("TBM")
                .build();
    }

    private static ReportResponse getReportResponse() {
        ReportResponse reportResponse = new ReportResponse();
        reportResponse.setName("reporteMonitorSaldos1682010556834.xlsx");
        reportResponse.setType("application/octet-stream");
        return reportResponse;
    }

}