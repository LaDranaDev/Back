package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.request.MonitorSaldosRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
class MonitorSaldosManagerRepositoryTest {

    @Mock
    private EntityManager entityManager;

    @InjectMocks
    private MonitorSaldosManagerRepository respository;


    @Test
    void getSaldosReintentosClienteRequestWithOptionalParams(){
        Query query = mock(Query.class);

        when(entityManager.createNativeQuery(anyString(), eq(Tuple.class)))
                .thenReturn(query);

        List<Tuple> dataSaldosReintentos =  respository.getSaldosReintentosCliente(getRequest());

        assertNotNull(dataSaldosReintentos);

    }

    @Test
    void getSaldosReintentosClienteRequestWithOutOptionalParams(){
        Query query = mock(Query.class);

        when(entityManager.createNativeQuery(anyString(), eq(Tuple.class)))
                .thenReturn(query);

        List<Tuple> dataSaldosReintentos =
                respository.getSaldosReintentosCliente(getRequestWithOutOptionalParams());

        assertNotNull(dataSaldosReintentos);

    }

    @Test
    void getSaldosReintentosClientePaged(){
        Pageable pagination = mock(Pageable.class);
        Query query = mock(Query.class);

        when(entityManager.createNativeQuery(anyString(), eq(Tuple.class)))
                .thenReturn(query);

        Page<Tuple> dataSaldosReintentos =
                respository.getSaldosReintentosClientePaged(getRequest(), pagination);

        assertNotNull(dataSaldosReintentos);

    }

    private static MonitorSaldosRequest getRequest(){
        return MonitorSaldosRequest.builder()
                .codigoCliente("04158057")
                .nombreArchivo("2013")
                .claveProducto("98")
                .fechaInicio("23/08/2013")
                .fechaFin("04/09/2013")
                .build();
    }


    private static MonitorSaldosRequest getRequestWithOutOptionalParams(){
        return MonitorSaldosRequest.builder()
                .codigoCliente("04158057")
                .nombreArchivo("")
                .claveProducto("")
                .fechaInicio("23/08/2013")
                .fechaFin("04/09/2013")
                .build();
    }
}