package mx.santander.h2h.monitoreo.config;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class SftpConnectPropertiesTest {
    SftpConnectProperties sftpConnectProperties = new SftpConnectProperties();

    @Test
    void testSetUrl() {
        sftpConnectProperties.setUrl("url");
        sftpConnectProperties.getUrl();
        Assertions.assertTrue(true);
    }

    @Test
    void testSetPathcrearxml() {
        sftpConnectProperties.setPathcrearxml("pathcrearxml");
        sftpConnectProperties.getPathcrearxml();
        Assertions.assertTrue(true);
    }

    @Test
    void testSetPathdescargaarchivos() {
        sftpConnectProperties.setPathdescargaarchivos("pathdescargaarchivos");
        sftpConnectProperties.getPathdescargaarchivos();
        Assertions.assertTrue(true);
    }

    @Test
    void testSetPathconsultaconfig() {
        sftpConnectProperties.setPathconsultaconfig("pathconsultaconfig");
        sftpConnectProperties.getPathconsultaconfig();
        Assertions.assertTrue(true);
    }
    
    @Test
    void testSetPathcreaarchivo() {
        sftpConnectProperties.setPathcreararchivo("pathcreaarchivo");
        sftpConnectProperties.getPathcreararchivo();
        Assertions.assertTrue(true);
    }
}