package mx.santander.h2h.monitoreo.model.response;

import mx.santander.h2h.monitoreo.util.JavaBeanTester;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;


class ParametersGetPutResponseTest {
    @Test
    void allArgsConstruction() {
        ParametersGetPutResponse parametersGetPutResponse = new ParametersGetPutResponse(
                "idParametro", "nombreParametro", "valorParametro", "id", "idProtocolo",
                "nombreProtocolo", "idValorParametro", "idContrato", "obliParametro", "editParametro",
                "tipoDatoParamero", "longParametro", "tipoProcesamieto", 1, 1, "valor");

        assertNotNull(parametersGetPutResponse);
    }

    @Test
    void testFields() {
        assertDoesNotThrow(() ->
                JavaBeanTester.test(ParametersGetPutResponse.class)
        );
    }

    @Test
    void toStringTest() {
        ParametersGetPutResponse parametersGetPutResponse = new ParametersGetPutResponse();
        assertNotNull(parametersGetPutResponse.toString());
    }
}