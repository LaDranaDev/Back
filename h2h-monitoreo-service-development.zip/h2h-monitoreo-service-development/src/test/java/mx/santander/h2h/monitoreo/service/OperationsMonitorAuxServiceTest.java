package mx.santander.h2h.monitoreo.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.nio.charset.Charset;
import java.util.ArrayList;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import mx.santander.h2h.monitoreo.config.SftpConnectProperties;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.GeneralResponse;
import mx.santander.h2h.monitoreo.repository.GeneralJPARepository;
import mx.santander.h2h.monitoreo.repository.IOperationsMonitorEntityManagerHelper4Repository;

class OperationsMonitorAuxServiceTest {
//	@Mock
//	IOperationsMonitorEntityManagerRepository repository;
	@Mock
	IOperationsMonitorEntityManagerHelper4Repository repository;
	@Mock
	RestTemplate template;
	@Mock
	SftpConnectProperties properties;
	@Mock
	GeneralJPARepository generalRepo;
	@InjectMocks
	OperationsMonitorAuxService service;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testGeneraXmlOperaciones() {
		when(properties.getUrl()).thenReturn("http://localhost:8080");
		when(properties.getPathcrearxml()).thenReturn("/sftp_operaciones/crea_xml");
//		when(repository.consultaOperacionesExport(any())).thenReturn("All operationas");
		ArrayList<String> lista= new ArrayList<String>();
		lista.add("select * from tablax ");
		lista.add("select * from tablay ");
		when(generalRepo.conteoResgistros(any()) ).thenReturn(lista ) ;
		when(repository.obtenerIdsComprobantes(any())).thenReturn("All operationas");
		ResponseEntity<GeneralResponse> res = new ResponseEntity<GeneralResponse>(HttpStatus.OK);
		when(template.postForEntity(anyString(), any(), eq(GeneralResponse.class))).thenReturn(res);
		service.generaXmlOperaciones(new OperationsMonitorQueryRequest());
		Assertions.assertNotNull(properties);
	}
	
	@Test
	void testGeneraXmlOperacionesRestClientResponseException() {
		when(properties.getUrl()).thenReturn("http://localhost:8080");
		when(properties.getPathcrearxml()).thenReturn("/sftp_operaciones/crea_xml");
		when(repository.obtenerIdsComprobantes(any())).thenReturn(anyString());
		when(template.postForEntity(anyString(), any(), GeneralResponse.class)).thenThrow(new RestClientResponseException("", 132, "", HttpHeaders.EMPTY, new byte[0], Charset.defaultCharset()));
		GeneralResponse result = service
				.generaXmlOperaciones(new OperationsMonitorQueryRequest());
		Assertions.assertNotNull(result);
	}
	
	@Test
	void testGeneraXmlOperacionesRestClientException() {
		when(properties.getUrl()).thenReturn("http://localhost:8080");
		when(properties.getPathcrearxml()).thenReturn("/sftp_operaciones/crea_xml");
		when(repository.obtenerIdsComprobantes(any())).thenReturn(anyString());
		when(template.postForEntity(anyString(), any(), GeneralResponse.class)).thenThrow(new RestClientException(""));
		GeneralResponse result = service
				.generaXmlOperaciones(new OperationsMonitorQueryRequest());
		Assertions.assertNotNull(result);
	}
}
