package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

import java.util.Collections;
import java.util.Objects;

import static org.mockito.Mockito.*;

class OperationsDetailAporPatrRepositoryTest {
    @Mock
    EntityManager entityManager;
    @InjectMocks
    OperationsDetailAporPatrRepository repository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testObtenerDetalleOperacion() {
        Tuple tuple = mock(Tuple.class);
        when(tuple.get((String) any())).then(answer -> {
            String arg = answer.getArgument(0);
            if ("IMPO_MOVI".equals(arg)) return "999.99";
            return arg;
        });

        Query query = mock(Query.class);
        when(query.getResultList()).thenReturn(Collections.singletonList(tuple));

        when(entityManager.createNativeQuery(any(), (Class<?>) any())).thenReturn(query);

        OperationsMonitorQueryResponse result = repository.obtenerDetalleOperacion("idOperacion");
        Assertions.assertNotEquals("OPERACION_EN_PROCESO", result.getProducto());
    }

    protected String getValue(Tuple tuple, String key) {
        try {
            return Objects.toString(tuple.get(key), "").trim();
        } catch (IllegalArgumentException e) {
            return "";
        }
    }

}
