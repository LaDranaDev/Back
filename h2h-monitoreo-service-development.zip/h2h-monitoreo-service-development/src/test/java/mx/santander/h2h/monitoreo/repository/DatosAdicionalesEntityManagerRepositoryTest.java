package mx.santander.h2h.monitoreo.repository;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import mx.santander.h2h.monitoreo.model.response.GenerateVouchersDtoResponse;
import mx.santander.h2h.monitoreo.model.response.VoucherRequestDto;

class DatosAdicionalesEntityManagerRepositoryTest {
	@Mock
	private EntityManager entityManager;
	@InjectMocks
	private DatosAdicionalesEntityManagerRepository repository;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testExisteEnPagoRefe() {
		Tuple tuple = mock(Tuple.class);
		when(tuple.get(anyString(), eq(String.class))).thenReturn("xx");

		Query query = mock(Query.class);
		when(query.getResultList()).thenReturn(Arrays.asList(tuple));

		when(entityManager.createNativeQuery(anyString(), eq(Tuple.class))).thenReturn(query);

		GenerateVouchersDtoResponse result = repository.existeEnPagoRefe(new VoucherRequestDto());
		Assertions.assertNotNull(result);
	}

	@Test
	void testExisteEnPagoRefeTran() {
		Tuple tuple = mock(Tuple.class);
		when(tuple.get(anyString(), eq(String.class))).thenReturn("xx");

		Query query = mock(Query.class);
		when(query.getResultList()).thenReturn(Arrays.asList(tuple));

		when(entityManager.createNativeQuery(anyString(), eq(Tuple.class))).thenReturn(query);

		GenerateVouchersDtoResponse result = repository.existeEnPagoRefeTran(new VoucherRequestDto());
		Assertions.assertNotNull(result);
	}

	@Test
	void testActualizaPagoRefe() {
		Query query = mock(Query.class);

		when(entityManager.createNativeQuery(any())).thenReturn(query);

		repository.actualizaPagoRefe(new VoucherRequestDto());
		Assertions.assertTrue(true);
	}

	@Test
	void testActualizaPagoRefeTran() {
		Query query = mock(Query.class);

		when(entityManager.createNativeQuery(any())).thenReturn(query);

		repository.actualizaPagoRefeTran(new VoucherRequestDto());
		Assertions.assertTrue(true);
	}

}
