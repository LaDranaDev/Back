package mx.santander.h2h.monitoreo.model.response;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;

class ArchivoDetalleResponseTest {

    ArchivoDetalleResponse archivoDetalleResponse = new ArchivoDetalleResponse();

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSetIdArchivo() {
        archivoDetalleResponse.setIdArchivo(99);
        Assertions.assertEquals(99, archivoDetalleResponse.getIdArchivo());
    }

    @Test
    void testSetNombreArchivo() {
        archivoDetalleResponse.setNombreArchivo("nombreArchivo");
        Assertions.assertEquals("nombreArchivo", archivoDetalleResponse.getNombreArchivo());
    }

    @Test
    void testSetCliente() {
        archivoDetalleResponse.setCliente("cliente");
        Assertions.assertEquals("cliente", archivoDetalleResponse.getCliente());
    }

    @Test
    void testSetCodigoCliente() {
        archivoDetalleResponse.setCodigoCliente(99);
        Assertions.assertEquals(99, archivoDetalleResponse.getCodigoCliente());
    }

    @Test
    void testSetFechaRecep() {
        archivoDetalleResponse.setFechaRecep("fechaRecep");
        Assertions.assertEquals("fechaRecep", archivoDetalleResponse.getFechaRecep());
    }

    @Test
    void testSetEstatus() {
        archivoDetalleResponse.setEstatus("estatus");
        Assertions.assertEquals("estatus", archivoDetalleResponse.getEstatus());
    }

    @Test
    void testSetIdEstatus() {
        archivoDetalleResponse.setIdEstatus(99);
        Assertions.assertEquals(99, archivoDetalleResponse.getIdEstatus());
    }

    @Test
    void testSetProducto() {
        archivoDetalleResponse.setProducto("producto");
        Assertions.assertEquals("producto", archivoDetalleResponse.getProducto());
    }

    @Test
    void testSetIdProducto() {
        archivoDetalleResponse.setIdProducto(99);
        Assertions.assertEquals(99, archivoDetalleResponse.getIdProducto());
    }

    @Test
    void testSetTotalOperaciones() {
        archivoDetalleResponse.setTotalOperaciones(99);
        Assertions.assertEquals(99, archivoDetalleResponse.getTotalOperaciones());
    }

    @Test
    void testSetMonto() {
        archivoDetalleResponse.setMonto(BigDecimal.TEN);
        Assertions.assertEquals(BigDecimal.TEN, archivoDetalleResponse.getMonto());
    }

    @Test
    void testSetUmbral() {
        archivoDetalleResponse.setUmbral(99);
        Assertions.assertEquals(99, archivoDetalleResponse.getUmbral());
    }

    @Test
    void testSetEnvioBackend() {
        archivoDetalleResponse.setEnvioBackend("envioBackend");
        Assertions.assertEquals("envioBackend", archivoDetalleResponse.getEnvioBackend());
    }

    @Test
    void testSetRegresoBackend() {
        archivoDetalleResponse.setRegresoBackend("regresoBackend");
        Assertions.assertEquals("regresoBackend", archivoDetalleResponse.getRegresoBackend());
    }

    @Test
    void testSetMontoFmt() {
        archivoDetalleResponse.setMontoFmt("montoFmt");
        Assertions.assertEquals("montoFmt", archivoDetalleResponse.getMontoFmt());
    }

    @Test
    void testSetCanal() {
        archivoDetalleResponse.setCanal("canal");
        Assertions.assertEquals("canal", archivoDetalleResponse.getCanal());
    }

    @Test
    void testSetMotRechazo() {
        archivoDetalleResponse.setMotRechazo("motRechazo");
        Assertions.assertEquals("motRechazo", archivoDetalleResponse.getMotRechazo());
    }

    @Test
    void testSetNombreArchivoProcesado() {
        archivoDetalleResponse.setNombreArchivoProcesado("nombreArchivoProcesado");
        Assertions.assertEquals("nombreArchivoProcesado", archivoDetalleResponse.getNombreArchivoProcesado());
    }

    @Test
    void testSetEstatusFinal() {
        archivoDetalleResponse.setEstatusFinal("estatusFinal");
        Assertions.assertEquals("estatusFinal", archivoDetalleResponse.getEstatusFinal());
    }

    @Test
    void testSetBuc() {
        archivoDetalleResponse.setBuc("buc");
        Assertions.assertEquals("buc", archivoDetalleResponse.getBuc());
    }

    @Test
    void testSetBucDuplicado() {
        archivoDetalleResponse.setBucDuplicado("bucDuplicado");
        Assertions.assertEquals("bucDuplicado", archivoDetalleResponse.getBucDuplicado());
    }

}
