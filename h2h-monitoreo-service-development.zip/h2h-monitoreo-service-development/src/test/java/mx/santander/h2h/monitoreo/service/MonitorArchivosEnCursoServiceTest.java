package mx.santander.h2h.monitoreo.service;

import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.MonitorArchivosEnCursoRequest;
import mx.santander.h2h.monitoreo.model.response.ComboDosResponse;
import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import mx.santander.h2h.monitoreo.model.response.MonitorDeArchivosEnCursoDetallesResponse;
import mx.santander.h2h.monitoreo.model.response.MonitorDeArchivosEnCursoResponse;
import mx.santander.h2h.monitoreo.repository.IConsultaTrackingProductoRepository;
import mx.santander.h2h.monitoreo.repository.IMonitorArchivosEnCursoNivelOperacionRepository;
import mx.santander.h2h.monitoreo.repository.IMonitorArchivosEnCursoRepository;

class MonitorArchivosEnCursoServiceTest {
	@Mock
	private IJasperReportService reportService;
    @Mock
    private IMonitorArchivosEnCursoRepository entityManager;
    @Mock
	private IConsultaTrackingProductoRepository consultaTrackingProductoRepository;
    @Mock
    private IMonitorArchivosEnCursoNivelOperacionRepository entityManagerOperacion;
    @InjectMocks
    private MonitorArchivosEnCursoService service;
    @InjectMocks
    private MonitorArchivosEnCursoAuxService serviceAux;
    @Mock
    private IMonitorArchivosEnCursoComplementService archivosEnCursoComplementService;

    @BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}
    

	@Test
	void testConsultaNivelProducto() {
		MonitorDeArchivosEnCursoResponse result = service.consultaNivelProducto("", 0, 0);
		Assertions.assertNotNull(result);
	}

	@Test
	void testConsultaNivelOperacion() {
		MonitorDeArchivosEnCursoResponse result = service.consultaNivelOperacion("", 0, 0);
		Assertions.assertNotNull(result);
	}

	@Test
	void testConsultaNivelOperacionHistorica() {
		MonitorDeArchivosEnCursoResponse result = service.consultaNivelOperacionHistorica("");
		Assertions.assertNotNull(result);
	}

	@Test
	void testGetReportXls() {
		List<ComboDosResponse> catProductos = new ArrayList<>();
		
		ComboDosResponse producto = new ComboDosResponse();
		producto.setId("1");
		producto.setValor("Transferencia");
		
		catProductos.add(producto);
		
		List<ComboResponse> catEstatus = new ArrayList<>();
		
		ComboResponse estatus = new ComboResponse();
		estatus.setId(1);
		estatus.setValor("EN ESPERA");
		
		catEstatus.add(estatus);
		
		when(archivosEnCursoComplementService.obtenerCatalogoProducto()).thenReturn(catProductos);
		when(archivosEnCursoComplementService.obtenerCatalogoEstatus()).thenReturn(catEstatus);
		
		when(reportService.getXls(anyString(), anyMap(), anyList())).thenReturn(new ReportResponse());
		
		MonitorArchivosEnCursoRequest request = new MonitorArchivosEnCursoRequest();
		request.setIdProducto("1");
		request.setIdEstatus("1");
		
		ReportResponse result = service.getReportXls(request, "Z433223");
		Assertions.assertNotNull(result);
	}
	
	@Test
	void consultaArchivosEnCursoTest() {
		Pageable pageable = mock(Pageable.class);
		MonitorArchivosEnCursoRequest request = new MonitorArchivosEnCursoRequest();
		request.setBuc("test");
		request.setCodCliente("test");
		request.setEstatus("test");
		List<MonitorDeArchivosEnCursoDetallesResponse> content = new ArrayList<>();
		MonitorDeArchivosEnCursoDetallesResponse m = new MonitorDeArchivosEnCursoDetallesResponse();
		m.setBuc("test");
		m.setCliente("test");
		m.setCveProdOper("test");
		content.add(m);
		when(entityManager.ejecutaBusquedaArchivosEnCurso(request)).thenReturn(content);
		serviceAux.consultaArchivosEnCurso(request, pageable);
		Assertions.assertNotNull(m);
	}

}
