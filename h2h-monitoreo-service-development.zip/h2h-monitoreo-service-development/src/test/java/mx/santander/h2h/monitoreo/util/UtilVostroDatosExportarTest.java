package mx.santander.h2h.monitoreo.util;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;

class UtilVostroDatosExportarTest {

    @Test
    void testEsVostro() {
        boolean result = UtilVostroDatosExportar.esVostro("");
        Assertions.assertEquals(false, result);

        result = UtilVostroDatosExportar.esVostro("39");
        Assertions.assertEquals(true, result);
    }

    @Test
    void testGetQuerySelectExportar() {
        StringBuilder query = new StringBuilder();
        query.append( UtilVostroDatosExportar.getQuerySelectExportar("38", new StringBuilder()) );
        Assertions.assertNotNull(query.toString());
    }

    @Test
    void testAddInnerVostro() {
        String result = UtilVostroDatosExportar.addInnerVostro("38");
        Assertions.assertNotNull(result);
    }
    
    @Test
    void testAddInnerVostro1() {
        String result = UtilVostroDatosExportar.addInnerVostro("40");
        Assertions.assertNotNull(result);
    }

    @Test
    void testCompletaQueryByCveProdOper() {
        StringBuilder query = new StringBuilder();
        Map<String, Object> params = new HashMap<>();
        UtilVostroDatosExportar.completaQueryByCveProdOper(query, params);
        Assertions.assertNotNull(query.toString());
    }
    
    @Test
    void testGeneraQueryProductosVostro() {
    	String result = UtilVostroDatosExportar.generaQueryProductosVostro(true, new OperationsMonitorQueryRequest());
    	Assertions.assertNotNull(result);
    }
    
    @Test
    void testGeneraQueryProductosVostro1() {
    	String result = UtilVostroDatosExportar.generaQueryProductosVostro(false, new OperationsMonitorQueryRequest());
    	Assertions.assertNotNull(result);
    }

}
