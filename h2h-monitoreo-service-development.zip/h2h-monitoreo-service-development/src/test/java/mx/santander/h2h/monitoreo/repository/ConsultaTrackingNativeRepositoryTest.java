package mx.santander.h2h.monitoreo.repository;

import static org.mockito.Mockito.when;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;

@ExtendWith(MockitoExtension.class)
class ConsultaTrackingNativeRepositoryTest {
	
	@InjectMocks
	private ConsultaTrackingNativeRepository consultaTrackingNativeRepository;
	
	@Mock
	private EntityManager entityManager;

	@Test
	void obtenerDetalleArchivosGeneralTest() {
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		consultaTrackingNativeRepository.obtenerDetalleArchivosGeneral(Pageable.ofSize(1), "27/06/2023", "04158057");
		Assertions.assertTrue(true);
	}
	
	@Test
	void obtenerDetalleArchivosGeneralTest2() {
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		consultaTrackingNativeRepository.obtenerDetalleArchivosGeneral(Pageable.ofSize(1), "27/06/2023", "");
		Assertions.assertTrue(true);
	}

	@Test
	void obtenerConteoArchivoTest() {
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		consultaTrackingNativeRepository.obtenerConteoArchivo("27/06/2023", "04158057");
		Assertions.assertTrue(true);
	}
	
	@Test
	void obtenerListDetalleArchivosGeneralTest() {
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		consultaTrackingNativeRepository.obtenerListDetalleArchivosGeneral("27/06/2023", "04158057");
		Assertions.assertTrue(true);
	}
}
