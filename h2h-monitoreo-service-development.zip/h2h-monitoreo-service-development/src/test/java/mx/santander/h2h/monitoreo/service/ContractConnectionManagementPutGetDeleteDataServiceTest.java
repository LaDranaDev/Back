package mx.santander.h2h.monitoreo.service;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import mx.santander.h2h.monitoreo.model.response.PutGetDto;
import mx.santander.h2h.monitoreo.model.response.PutGetServiceResponse;

class ContractConnectionManagementPutGetDeleteDataServiceTest {
	@Mock
	private EntityManager entityManager;
	@InjectMocks
	private ContractConnectionManagementPutGetDeleteDataService service;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testEliminaDatosSiEsAlta() {
		PutGetServiceResponse res = new PutGetServiceResponse();
		List<PutGetDto> lst = new ArrayList<>();
		lst.add(new PutGetDto());
		lst.add(new PutGetDto());
		res.setRegistrosPG(lst);
		service.eliminaDatosSiEsAlta(res, "A");
		Assertions.assertTrue(true);
	}

	@Test
	void testEliminaValoresnuevoReg() {
		PutGetServiceResponse res = new PutGetServiceResponse();
		List<PutGetDto> lst = new ArrayList<>();
		lst.add(new PutGetDto());
		res.setRegistrosPG(lst);
		service.eliminaValoresnuevoReg(res);
		Assertions.assertTrue(true);
	}

	@Test
	void testEliminaInformacion() {
		Query query = mock(Query.class);
		when(entityManager.createNativeQuery(anyString())).thenReturn(query);
		
		PutGetServiceResponse res = new PutGetServiceResponse();
		List<PutGetDto> lst = new ArrayList<>();
		PutGetDto dto = new PutGetDto(); 
		dto.setIdContrato("0");
		lst.add(dto);
		res.setRegistrosPG(lst);
		service.eliminaInformacion(res);
		Assertions.assertTrue(true);
	}

}
