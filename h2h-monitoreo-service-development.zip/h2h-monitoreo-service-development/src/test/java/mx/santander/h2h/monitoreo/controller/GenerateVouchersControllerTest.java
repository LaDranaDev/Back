package mx.santander.h2h.monitoreo.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.HistorialOperacionesRequest;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.CampoAdicionalBean;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersControllerResponse;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersDtoResponse;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersTotalResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsHistoryResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.model.response.VoucherRequestDto;
import mx.santander.h2h.monitoreo.service.IGenerateVouchersExportService;
import mx.santander.h2h.monitoreo.service.IGenerateVouchersOperacionesService;
import mx.santander.h2h.monitoreo.service.IGenerateVouchersService;

@ExtendWith(MockitoExtension.class)
class GenerateVouchersControllerTest {

	@InjectMocks
	private GenerateVouchersController generateVouchersController;

	@Mock
	private IGenerateVouchersService iGenerateVouchersService;

	@Mock
	private IGenerateVouchersExportService exportService;
	
	@Mock
	private IGenerateVouchersOperacionesService generateVouchersOperacionesService;

	@Mock
	Pageable pageable;

	@Test
	void findVouchersCdmx() {

		GenerateVouchersControllerResponse generateVouchersControllerResponse = crearGenerateVouchersControllerResponse();

		when(iGenerateVouchersService.findVouchersCdmx()).thenReturn(generateVouchersControllerResponse);

		GenerateVouchersControllerResponse findVouchersCdmx = generateVouchersController.findVouchersCdmx();

		assertNotNull(findVouchersCdmx);
		assertEquals(generateVouchersControllerResponse.getInicio(), findVouchersCdmx.getInicio());
		assertEquals(generateVouchersControllerResponse.getFin(), findVouchersCdmx.getFin());

	}

	@Test
	void findOperationsMonitor() {

		OperationsMonitorQueryRequest operationsMonitorQueryRequest = crearOperationsMonitorQueryRequest();

		GenerateVouchersControllerResponse generateVouchersControllerResponse = crearGenerateVouchersControllerResponse();

		when(iGenerateVouchersService.findOperationsMonitor(operationsMonitorQueryRequest, pageable))
				.thenReturn(generateVouchersControllerResponse);

		GenerateVouchersControllerResponse findOperationsMonitor = generateVouchersController
				.findOperationsMonitor(operationsMonitorQueryRequest, pageable);

		assertNotNull(findOperationsMonitor);
		assertEquals(generateVouchersControllerResponse.getInicio(), findOperationsMonitor.getInicio());
		assertEquals(generateVouchersControllerResponse.getFin(), findOperationsMonitor.getFin());

	}

	@Test
	void findTotal() {

		GenerateVouchersTotalResponse generateVouchersTotalResponse = new GenerateVouchersTotalResponse();

		when(iGenerateVouchersService.findTotal(any())).thenReturn(generateVouchersTotalResponse);

		GenerateVouchersTotalResponse findTotal = generateVouchersController
				.findTotal(new OperationsMonitorQueryRequest());

		assertNotNull(findTotal);
		assertEquals(generateVouchersTotalResponse, findTotal);

	}

	@Test
	void paginarOperaciones() {

		PageImpl<OperationsMonitorQueryResponse> operationsResponsePaginado = crearOperationsMonitorQueryResponsePaginado();

		when(iGenerateVouchersService.paginarOperaciones(any(), any())).thenReturn(operationsResponsePaginado);

		ResponseEntity<Page<OperationsMonitorQueryResponse>> paginarOperaciones = generateVouchersController
				.paginarOperaciones(new OperationsMonitorQueryRequest(), pageable);

		assertNotNull(paginarOperaciones);
		assertEquals("200 OK", paginarOperaciones.getStatusCode().toString());
		assertEquals(operationsResponsePaginado.getContent(), paginarOperaciones.getBody().getContent());

	}

	@Test
	void detalleOperaciones() {

		GenerateVouchersControllerResponse generateVouchersControllerResponse = new GenerateVouchersControllerResponse();

		when(iGenerateVouchersService.detalleOperaciones(any())).thenReturn(generateVouchersControllerResponse);

		GenerateVouchersControllerResponse detalleOperaciones = generateVouchersController
				.detalleOperaciones(new OperationsMonitorQueryResponse());

		assertNotNull(detalleOperaciones);
		assertEquals(generateVouchersControllerResponse, detalleOperaciones);

	}

	@Test
	void historialOperaciones() {

		List<OperationsHistoryResponse> listOperationsHistoryResponse = new ArrayList<OperationsHistoryResponse>();

		when(iGenerateVouchersService.historialOperaciones(anyString())).thenReturn(listOperationsHistoryResponse);

		ResponseEntity<List<OperationsHistoryResponse>> historialOperaciones = generateVouchersController
				.historialOperaciones("01");

		assertNotNull(historialOperaciones);
		assertEquals("200 OK", historialOperaciones.getStatusCode().toString());
		assertEquals(listOperationsHistoryResponse, historialOperaciones.getBody());

	}

	@Test
	void conceptoValor() {

		GenerateVouchersDtoResponse generateVouchersDtoResponse = new GenerateVouchersDtoResponse();

		when(iGenerateVouchersService.conceptoValor(anyString())).thenReturn(generateVouchersDtoResponse);

		GenerateVouchersDtoResponse conceptoValor = generateVouchersController.conceptoValor("01");

		assertNotNull(conceptoValor);
		assertEquals(generateVouchersDtoResponse, conceptoValor);

	}

	@Test
	void exportarOperacionesXlsx() {

		ReportResponse reportResponse = new ReportResponse();

		when(generateVouchersOperacionesService.exportarOperacionesXlsx(any(), anyString())).thenReturn(reportResponse);

		ResponseEntity<ReportResponse> exportarOperacionesXlsx = generateVouchersController
				.exportarOperacionesXlsx(new OperationsMonitorQueryRequest());

		assertNotNull(exportarOperacionesXlsx);
		assertEquals("200 OK", exportarOperacionesXlsx.getStatusCode().toString());
		assertEquals(reportResponse, exportarOperacionesXlsx.getBody());

	}

	@Test
	void exportarOperacionesPdf() {

		ReportResponse reportResponse = new ReportResponse();
		CampoAdicionalBean campo = new CampoAdicionalBean();
		campo.toString();

		when(exportService.exportarOperacionesPdf(any())).thenReturn(reportResponse);

		ResponseEntity<ReportResponse> exportarOperacionesPdf = generateVouchersController
				.exportarOperacionesPdf(new VoucherRequestDto());

		assertNotNull(exportarOperacionesPdf);
	}

	private PageImpl<OperationsMonitorQueryResponse> crearOperationsMonitorQueryResponsePaginado() {

		List<OperationsMonitorQueryResponse> listaOperaciones = new ArrayList<OperationsMonitorQueryResponse>();

		listaOperaciones.add(crearOperationsMonitorQueryResponse());

		return new PageImpl<>(listaOperaciones);
	}

	private OperationsMonitorQueryResponse crearOperationsMonitorQueryResponse() {

		OperationsMonitorQueryResponse operationsMonitorQueryResponse = new OperationsMonitorQueryResponse();

		return operationsMonitorQueryResponse;
	}

	/**
	 * @return
	 */
	private OperationsMonitorQueryRequest crearOperationsMonitorQueryRequest() {

		OperationsMonitorQueryRequest operationsMonitorQueryRequest = new OperationsMonitorQueryRequest();

		operationsMonitorQueryRequest.setBuc("08702237");
		operationsMonitorQueryRequest.setContrato("856123456789");
		operationsMonitorQueryRequest.setNombreBeneficiario("SALVADOR PROSPERO MOMOX PEREZ");

		return operationsMonitorQueryRequest;
	}

	/**
	 * @return
	 */
	private GenerateVouchersControllerResponse crearGenerateVouchersControllerResponse() {

		GenerateVouchersControllerResponse generateVouchersControllerResponse = new GenerateVouchersControllerResponse();

		generateVouchersControllerResponse.setFin(20);
		generateVouchersControllerResponse.setInicio(1);

		return generateVouchersControllerResponse;
	}

	@Test
	void exportarHistorialOperacionesXlsx() {

		ReportResponse reportResponse = new ReportResponse();

		when(generateVouchersOperacionesService.exportarHistorialOperacionesXlsx(any())).thenReturn(reportResponse);

		ResponseEntity<ReportResponse> exportarOperacionesXlsx = generateVouchersController
				.exportarHistorialOperacionesXlsx(new HistorialOperacionesRequest());

		assertNotNull(exportarOperacionesXlsx);
		assertEquals("200 OK", exportarOperacionesXlsx.getStatusCode().toString());
		assertEquals(reportResponse, exportarOperacionesXlsx.getBody());

	}
}
