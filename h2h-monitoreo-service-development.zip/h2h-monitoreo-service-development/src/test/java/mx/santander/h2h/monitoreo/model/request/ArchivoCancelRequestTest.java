package mx.santander.h2h.monitoreo.model.request;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ArchivoCancelRequestTest {
    ArchivoCancelRequest request = new ArchivoCancelRequest();

    @Test
    void setBucCliente() {
        request.setBucCliente("79240989");
        Assertions.assertEquals("79240989", request.getBucCliente());
    }

    @Test
    void setNomArchivo() {
        request.setNomArchivo("test.txt");
        Assertions.assertEquals("test.txt", request.getNomArchivo());
    }

    @Test
    void setEstatus() {
        request.setEstatus("ACTIVO");
        Assertions.assertEquals("ACTIVO", request.getEstatus());
    }
}