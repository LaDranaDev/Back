package mx.santander.h2h.monitoreo.model.report.response;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class ReportResponseTest {

    private ReportResponse reportResponse;

    @BeforeEach
    void setUp(){
        reportResponse = new ReportResponse();
    }

    @Test
    void getData() {
        reportResponse.setData("data");
        assertEquals("data", reportResponse.getData());
    }

    @Test
    void getLength() {
        reportResponse.setLength(123);
        assertEquals(123, reportResponse.getLength());
    }

    @Test
    void getName() {
        reportResponse.setName("name");
        assertEquals("name", reportResponse.getName());
    }

    @Test
    void getType() {
        reportResponse.setType("type");
        assertEquals("type", reportResponse.getType());
    }

    @Test
    void builder() {
        reportResponse = ReportResponse.builder().build();
        assertNotNull(reportResponse);
    }

    @Test
    void toStringTest(){
        String response = ReportResponse.builder().toString();
        assertNotNull(response);
    }
}