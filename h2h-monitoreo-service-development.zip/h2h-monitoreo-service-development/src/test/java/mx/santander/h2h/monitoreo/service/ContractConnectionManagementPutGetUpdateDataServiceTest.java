package mx.santander.h2h.monitoreo.service;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import mx.santander.h2h.monitoreo.model.request.PutGetRequest;
import mx.santander.h2h.monitoreo.model.response.PutGetDto;
import mx.santander.h2h.monitoreo.model.response.PutGetServiceResponse;
import mx.santander.h2h.monitoreo.model.response.PutGetWSDto;

class ContractConnectionManagementPutGetUpdateDataServiceTest {
	@Mock
	private EntityManager entityManager;
	@InjectMocks
	private ContractConnectionManagementPutGetUpdateDataService service;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testActualizarPtclPath() {
		Query query = mock(Query.class);
		when(entityManager.createNativeQuery(anyString())).thenReturn(query);
		
		PutGetServiceResponse res = new PutGetServiceResponse();
		List<PutGetDto> lst = new ArrayList<>();
		PutGetDto dto = new PutGetDto(); 
		dto.setDirectorio("asd");
		dto.setPatron("asd");
		lst.add(dto);
		res.setRegistrosPG(lst);
		service.actualizarPtclPath(res, new PutGetRequest(), "P");
		Assertions.assertTrue(true);
	}
	
	@Test
	void testActualizarPtclPath1() {
		Query query = mock(Query.class);
		when(entityManager.createNativeQuery(anyString())).thenReturn(query);
		
		PutGetServiceResponse res = new PutGetServiceResponse();
		List<PutGetDto> lst = new ArrayList<>();
		PutGetDto dto = new PutGetDto(); 
		dto.setDirectorio("asd");
		dto.setPatron("asd");
		lst.add(dto);
		res.setRegistrosPG(lst);
		service.actualizarPtclPath(res, new PutGetRequest(), "z");
		Assertions.assertTrue(true);
	}

	@Test
	void testActualizarPtclPara() {
		Query query = mock(Query.class);
		when(entityManager.createNativeQuery(anyString())).thenReturn(query);
		
		PutGetServiceResponse res = new PutGetServiceResponse();
		List<PutGetDto> lst = new ArrayList<>();
		lst.add(new PutGetDto());
		res.setRegistrosPG(lst);
		service.actualizarPtclPara(res);
		Assertions.assertTrue(true);
	}

	@Test
	void testActualizaParaSFTPCD() {
		Query query = mock(Query.class);
		when(entityManager.createNativeQuery(anyString())).thenReturn(query);
		
		List<String> opciones = new ArrayList<>();
		opciones.add("1");
		opciones.add("2");
		opciones.add("5");
		opciones.add("4");
		for (String op : opciones) {
			PutGetServiceResponse res = new PutGetServiceResponse();
			List<PutGetDto> lst = new ArrayList<>();
			PutGetDto dto = new PutGetDto(); 
			dto.setIdProtocolo(op);
			dto.setPutGetWSDto(new PutGetWSDto());
			lst.add(dto);
			res.setRegistrosPG(lst);
			service.actualizaParaSFTPCD(res);
			Assertions.assertTrue(true);
		}
	}

}
