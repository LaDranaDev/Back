package mx.santander.h2h.monitoreo.model.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ProductEntityTest {

    private ProductEntity productEntity;

    @BeforeEach
    void setUp(){
        productEntity = new ProductEntity();
    }

    @Test
    void getId() {
        productEntity.setId(1L);
        assertEquals(1L, productEntity.getId());
    }

    @Test
    void getDescripcion() {
        productEntity.setDescripcion("descripcion");
        assertEquals("descripcion", productEntity.getDescripcion());
    }

    @Test
    void getBandTipoCargo() {
        productEntity.setBandTipoCargo("A");
        assertEquals("A", productEntity.getBandTipoCargo());
    }

    @Test
    void getBandVigencia() {
        productEntity.setBandVigencia("T");
        assertEquals("T", productEntity.getBandVigencia());
    }

    @Test
    void getBandEmail() {
        productEntity.setBandEmail("N");
        assertEquals("N", productEntity.getBandEmail());
    }

    @Test
    void getBandReintentos() {
        productEntity.setBandReintentos("T");
        assertEquals("T", productEntity.getBandReintentos());
    }

    @Test
    void getBandConfirming() {
        productEntity.setBandConfirming("A");
        assertEquals("A", productEntity.getBandConfirming());
    }

    @Test
    void getIdBack() {
        productEntity.setIdBack(2L);
        assertEquals(2L, productEntity.getIdBack());
    }

    @Test
    void getCveProd() {
        productEntity.setCveProd("cveProd");
        assertEquals("cveProd", productEntity.getCveProd());
    }

    @Test
    void getUmbral() {
        productEntity.setUmbral(12L);
        assertEquals(12L, productEntity.getUmbral());
    }

    @Test
    void getVisibilidad() {
        productEntity.setVisibilidad('T');
        assertEquals('T', productEntity.getVisibilidad());
    }

    @Test
    void getBandActivo() {
        productEntity.setBandActivo("T");
        assertEquals("T", productEntity.getBandActivo());
    }

    @Test
    void getCveProdOper() {
        productEntity.setCveProdOper("cveProdOper");
        assertEquals("cveProdOper", productEntity.getCveProdOper());
    }

    @Test
    void getCodiOperCarg() {
        productEntity.setCodiOperCarg("codigo");
        assertEquals("codigo", productEntity.getCodiOperCarg());
    }

    @Test
    void getCodiOperAbon() {
        productEntity.setCodiOperAbon("codigo");
        assertEquals("codigo", productEntity.getCodiOperAbon());
    }

    @Test
    void getDiasFecOper() {
        productEntity.setDiasFecOper(123);
        assertEquals(123, productEntity.getDiasFecOper());
    }

    @Test
    void getDiasFecTran() {
        productEntity.setDiasFecTran(123);
        assertEquals(123, productEntity.getDiasFecTran());
    }

    @Test
    void getDiasFecApli() {
        productEntity.setDiasFecApli(123);
        assertEquals(123, productEntity.getDiasFecApli());
    }

    @Test
    void getCodiOperComi() {
        productEntity.setCodiOperComi("codigo");
        assertEquals("codigo", productEntity.getCodiOperComi());
    }

    @Test
    void getBandVisiCons() {
        productEntity.setBandVisiCons('A');
        assertEquals('A', productEntity.getBandVisiCons());
    }

    @Test
    void getVisitProd() {
        productEntity.setVisitProd("T");
        assertEquals("T", productEntity.getVisitProd());
    }

    @Test
    void getBandComision() {
        productEntity.setBandComision('N');
        assertEquals('N', productEntity.getBandComision());
    }

    @Test
    void getHoraMaxOpera() {
        productEntity.setHoraMaxOpera(123L);
        assertEquals(123L, productEntity.getHoraMaxOpera());
    }
}