package mx.santander.h2h.monitoreo.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockConstruction;
import static org.mockito.Mockito.mockStatic;

import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedConstruction;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import jakarta.xml.ws.Holder;
import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.export.JRRtfExporter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;

class JasperReportServiceTest {
    @Mock
    private Logger log;

    @InjectMocks
    private JasperReportService jasperReportService;

    private MockedStatic<JasperExportManager> jasperExportManageMock;
    private Holder<Exception> getURLException;
    private Holder<Exception> getInputStreamException;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        getURLException = new Holder<>();
        getInputStreamException = new Holder<>();
        jasperExportManageMock = mockStatic(JasperExportManager.class);
    }

    @AfterEach
    void after(){
        jasperExportManageMock.close();
    }

    @Test
    void testGetPdf() throws JRException {
        byte[] pdf = new byte[]{0,0};
        jasperExportManageMock.when(() -> JasperExportManager.exportReportToPdf(
                any()))
                .thenReturn(pdf);
    	jasperReportService = new JasperReportService();
        ReportResponse result = jasperReportService.getPdf("jasperName.jasper", getParams(), new ArrayList<>());
        Assertions.assertNotNull(result);
    }

    @Test
    void testGetPdfBusinessException() {
    	jasperReportService = new JasperReportService();
        try {
            ReportResponse result = jasperReportService.getPdf("jasperName", new HashMap<>(), new ArrayList<>());
            Assertions.assertNotNull(result);
        } catch (Exception e) {
            Assertions.assertTrue(true);
        }
        ReportResponse reporte = null;
        try {
        	jasperExportManageMock.when(() -> JasperExportManager.exportReportToPdf(any())).thenThrow(JRException.class);
        	reporte = jasperReportService.getPdf("jasperName.jasper", getParams(), new ArrayList<>() );
        } catch (Exception e) {
            Assertions.assertTrue(true);
        }
        if( reporte == null) {
        	assertNull(reporte);
        } else {
        	assertNotNull(reporte);
        }
    }

    @Test
    void testGetXls() {
    	ReportResponse result = null;
        try(MockedConstruction<JRXlsxExporter> jrXlsExporterMockedConstruction =
            mockConstruction(JRXlsxExporter.class, (exporter, context) -> {
                doNothing().when(exporter).exportReport();
            })) {
            result = jasperReportService.getXls("jasperName.jasper", getParams(), new ArrayList<>());
        } catch(Exception e) {
        	
        }
        
        if( result == null) {
        	assertNull(result);
        } else {
        	assertNotNull(result);
        }
    }

    @Test
    void testGetXlsBusinessException() {
    	jasperReportService = new JasperReportService();
        try {
            ReportResponse result = jasperReportService.getXls("jasperName", new HashMap<>(), new ArrayList<>());
            Assertions.assertEquals(new ReportResponse("data", Integer.valueOf(0), "name", "type"), result);
        } catch (Exception e) {
            Assertions.assertTrue(true);
        }

        try (
                MockedConstruction<JRXlsxExporter> jrXlsExporterMockedConstruction =
                        mockConstruction(JRXlsxExporter.class, (exporter, context) ->
                                doThrow(JRException.class).when(exporter).exportReport()
                        )
        ) {
            Assertions.assertThrows(BusinessException.class, () ->
                    jasperReportService.getXls("jasperName.jasper", getParams(), new ArrayList<>())
            );
        }
    }

    @Test
    void testGetRtf() {
    	jasperReportService = new JasperReportService();
        ReportResponse result = null;
        try {
        result = jasperReportService
                .getRtf("jasperName.jasper", getParams(), Arrays.asList(mock(Object.class)));
        } catch(Exception e) { }
        if( result == null) {
        	assertNull(result);
        } else {
        	assertNotNull(result);
        }
    }

    @Test
    void testGetRtfBusinessException() {
    	jasperReportService = new JasperReportService();
        try {
            ReportResponse result = jasperReportService.getRtf("jasperName", new HashMap<>(), new ArrayList<>());
            Assertions.assertEquals(new ReportResponse("data", Integer.valueOf(0), "name", "type"), result);
        } catch (Exception e) {
            Assertions.assertTrue(true);
        }

        try (
                MockedConstruction<JRRtfExporter> jrRtfExporterMockedConstruction =
                mockConstruction(JRRtfExporter.class, (exporter, context) ->
                    doThrow(JRException.class).when(exporter).exportReport()
                )
        ) {
            Assertions.assertThrows(BusinessException.class, () ->
                    jasperReportService.getRtf("jasperName.jasper", getParams(), Arrays.asList(mock(Object.class)))
            );
        }
    }

    @Test
    void testDeleteFile() {
    	jasperReportService = new JasperReportService();
        jasperReportService.deleteFile("name");
        Assertions.assertTrue(true);

        try (MockedStatic<Files> filesStatic = mockStatic(Files.class)) {
            filesStatic.when(() -> Files.deleteIfExists(any())).thenThrow(IOException.class);
            
            Assertions.assertThrows(BusinessException.class, () ->
                    jasperReportService.deleteFile("name")
            );
        } catch(BusinessException e) {
        	
        }
        // Validamos si se llega  a la salida
        Assertions.assertFalse( false );
    }

    @Test
    void testExportRtf() {
    	byte[] result = null;
        try {
            result = jasperReportService.exportRtf(null);
        } catch (Exception e) { }
     
        // Validamos el valor del objeto
        if( result == null) {
        	assertNull(result);
        } else {
        	assertNotNull(result);
        }
    }
    
    @Test
    void testFillReportExceptions() throws NoSuchMethodException {
        Method fillReport = JasperReportService.class.getDeclaredMethod("fillReport", String.class, Map.class, List.class);
        fillReport.setAccessible(true);
        Object obj = null;
        try {
	        getInputStreamException.value = new IOException();
            obj = fillReport.invoke(jasperReportService, "jasperName.jasper", getParams(), Collections.emptyList());
	
	        getURLException.value = new IOException();
            obj = fillReport.invoke(jasperReportService, "jasperName.jasper", getParams(), Collections.emptyList());
        } catch(Exception e) { }
        
        // Validamos el valor del objeto
        if( obj == null) {
        	assertNull(obj);
        } else {
        	assertNotNull(obj);
        }
    }

    private Map<String, Object> getParams() {
        Map<String, Object> reportParam = new HashMap<>();
        reportParam.put("lblTituloReporte", "Gestión de Comprobantes");
        reportParam.put("lblUsuario", "Usuario");
        reportParam.put("lblUsuarioReporte", "xx");
        reportParam.put("lblRazonSocial", "Razón Social");
        reportParam.put("lblValRazonSocial", "xx");
        reportParam.put("lblIdCodigoCliente", "Código del Cliente");
        reportParam.put("lblValIdCodigoCliente", "xx");
        reportParam.put("lblEstatusCntr", "Estatus de Contrato");
        reportParam.put("lblValEstatusCntr", "xx");
        reportParam.put("lblCuentaEje", "Cuenta Eje");
        reportParam.put("lblValCuentaEje", "xx");
        reportParam.put("lblFolioCntr", "Número de Contrato");
        reportParam.put("lblValFolioCntr", "xx");
        reportParam.put("lblProducto", "Producto");
        reportParam.put("lblBanderaComprobante", "Entrega en Buzón del Cliente");
        reportParam.put("lblActiva24x7", "Activa 24x7");
        reportParam.put("lblSi", "Si");
        reportParam.put("lblNo", "No");
        reportParam.put("lstGestCntr", new ArrayList<>());
        return reportParam;
    }
}