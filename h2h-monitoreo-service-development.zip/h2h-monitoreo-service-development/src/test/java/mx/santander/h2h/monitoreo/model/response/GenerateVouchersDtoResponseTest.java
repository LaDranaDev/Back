package mx.santander.h2h.monitoreo.model.response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class GenerateVouchersDtoResponseTest {

	@InjectMocks
	GenerateVouchersDtoResponse generateVouchersDtoResponse;

	@Test
	void getSetImporteTotal() {

		generateVouchersDtoResponse.setImporteTotal("200");

		assertEquals("200", generateVouchersDtoResponse.getImporteTotal());

	}

	@Test
	void getSetConceptoValor() {

		generateVouchersDtoResponse.setConceptoValor("ConceptoValor");

		assertEquals("ConceptoValor", generateVouchersDtoResponse.getConceptoValor());

	}

	@Test
	void getSetListaOperaciones() {

		List<OperationsMonitorQueryResponse> listaOperaciones = new ArrayList<OperationsMonitorQueryResponse>();

		generateVouchersDtoResponse.setListaOperaciones(listaOperaciones);

		assertEquals(listaOperaciones, generateVouchersDtoResponse.getListaOperaciones());

	}

	@Test
	void getSetParametrosAdicionalesComprobante() {

		List<String> listaParametros = new ArrayList<String>();

		generateVouchersDtoResponse.setParametrosAdicionalesComprobante(listaParametros);

		assertEquals(listaParametros, generateVouchersDtoResponse.getParametrosAdicionalesComprobante());

	}

	@Test
	void getSetListaTipoPago() {

		List<SelectComboDTO> listaSelectCombo = new ArrayList<SelectComboDTO>();

		generateVouchersDtoResponse.setListaTipoPago(listaSelectCombo);

		assertEquals(listaSelectCombo, generateVouchersDtoResponse.getListaTipoPago());

	}

	@Test
	void getSetTotalOperaciones() {

		generateVouchersDtoResponse.setTotalOperaciones("TotalOperaciones");

		assertEquals("TotalOperaciones", generateVouchersDtoResponse.getTotalOperaciones());

	}

	@Test
	void getSetTotalArchivos() {

		generateVouchersDtoResponse.setTotalArchivos("TotalArchivos");

		assertEquals("TotalArchivos", generateVouchersDtoResponse.getTotalArchivos());

	}

	@Test
	void getSetCdmxBean() {

		VoucherRequestDto voucherRequestDto = new VoucherRequestDto();

		generateVouchersDtoResponse.setCdmxBean(voucherRequestDto);

		assertEquals(voucherRequestDto, generateVouchersDtoResponse.getCdmxBean());

	}

	@Test
	void getSetMsgError() {

		generateVouchersDtoResponse.setMsgError("MsgError");

		assertEquals("MsgError", generateVouchersDtoResponse.getMsgError());

	}

	@Test
	void getSetCodError() {

		generateVouchersDtoResponse.setCodError("CodError");

		assertEquals("CodError", generateVouchersDtoResponse.getCodError());

	}

	@Test
	void testToString() {

		String toStringResult = generateVouchersDtoResponse.toString();

		assertNotNull(toStringResult);

	}

}
