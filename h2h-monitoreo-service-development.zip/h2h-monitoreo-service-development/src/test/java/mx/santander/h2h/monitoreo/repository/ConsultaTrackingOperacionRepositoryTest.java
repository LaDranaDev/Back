package mx.santander.h2h.monitoreo.repository;

import static org.mockito.Mockito.when;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;

@ExtendWith(MockitoExtension.class)
class ConsultaTrackingOperacionRepositoryTest {
	
	@InjectMocks
	private ConsultaTrackingOperacionRepository consultaTrackingOperacionRepository;
	
	@Mock
	private EntityManager entityManager;

	@Test
	void obtenerCatalogoEstatusTest() {
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		
		consultaTrackingOperacionRepository.obtenerCatalogoEstatus("R");
		Assertions.assertTrue(true);
	}
	
	@Test
	void obtenerConteoArchivoTest() {
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		
		consultaTrackingOperacionRepository.obtenerConteoArchivo("79240991", 74593, 1, 5);
		Assertions.assertTrue(true);
	}
	
	@Test
	void obtenerConteoArchivoTest2() {
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		
		consultaTrackingOperacionRepository.obtenerConteoArchivo("79240991", 74593, null, 0);
		Assertions.assertTrue(true);
	}
	
	@Test
	void obtenerConteoArchivoTest3() {
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		
		consultaTrackingOperacionRepository.obtenerConteoArchivo("79240991", 74593, 0, null);
		Assertions.assertTrue(true);
	}
	
	@Test
	void obtenerDetalleArchivoTest() {
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		
		consultaTrackingOperacionRepository.obtenerDetalleArchivo(Pageable.ofSize(1), 74593, 1, 5);
		Assertions.assertTrue(true);
	}
	
	@Test
	void obtenerDetalleArchivoTest2() {
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		
		consultaTrackingOperacionRepository.obtenerDetalleArchivo(Pageable.ofSize(1), 74593, null, 0);
		Assertions.assertTrue(true);
	}

	@Test
	void obtenerDetalleArchivoTest3() {
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		
		consultaTrackingOperacionRepository.obtenerDetalleArchivo(Pageable.ofSize(1), 74593, 0, null);
		Assertions.assertTrue(true);
	}
	
	@Test
	void obtenerListDetalleArchivo() {
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		consultaTrackingOperacionRepository.obtenerListDetalleArchivo(74593, 158057, 5);
		Assertions.assertTrue(true);
	}
}
