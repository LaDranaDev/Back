package mx.santander.h2h.monitoreo.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.model.entity.CatalogStatusEntity;
import mx.santander.h2h.monitoreo.model.entity.ParameterEntity;
import mx.santander.h2h.monitoreo.model.request.ContractConnectionManagementRequest;
import mx.santander.h2h.monitoreo.model.response.ContractConnectionManagementResponse;
import mx.santander.h2h.monitoreo.util.ContractConnectionManagementEntityManagerUtils;

/**
 * @author sbautish
 *
 */
@ExtendWith(MockitoExtension.class)
class ContractConnectionManagementEntityManagerRepositoryTest {

	@InjectMocks
	ContractConnectionManagementEntityManagerRepository contractConnectionManagementEntityManagerRepository;

	@Mock
	EntityManager entityManager;

	@Mock
	TypedQuery<CatalogStatusEntity> typedQuery;

	@Mock
	Query query;

	@Mock
	ContractConnectionManagementEntityManagerUtils contractConnectionManagementEntityManagerUtils;

	@Mock
	Pageable pageable;

	@Test
	void findContractConnectionByContractNumberOrClientCode() {

		ContractConnectionManagementRequest contractConnectionManagementRequest = crearContractConnectionManagementRequest();

		ParameterEntity parameterEntity = crearParameterEntity();

		when(entityManager.createQuery(anyString(), (Class<CatalogStatusEntity>) any())).thenReturn(typedQuery);

		when(typedQuery.setParameter(anyString(), any())).thenReturn(typedQuery);

		when(typedQuery.getResultList()).thenReturn(crearListaCatalogStatusEntity());

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);

		when(query.setParameter(anyString(), any())).thenReturn(query);

		when(query.getResultList()).thenReturn(crearListaDatosObjeto()).thenReturn(crearListaDatosObjeto())
				.thenReturn(new ArrayList<BigDecimal>(10));

		PageImpl<ContractConnectionManagementResponse> contractConnectionManagementResponse = contractConnectionManagementEntityManagerRepository
				.findContractConnectionByContractNumberOrClientCode(contractConnectionManagementRequest,
						parameterEntity, parameterEntity, pageable);

		assertNotNull(contractConnectionManagementResponse);
		assertNotNull(contractConnectionManagementResponse.getContent());
		assertEquals("value", contractConnectionManagementResponse.getContent().get(0).getCodigoCliente());

	}

	@Test
	void findContractConnectionProtocolByIdContract() {

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);

		when(query.setParameter(anyString(), any())).thenReturn(query);

		when(query.getResultList()).thenReturn(crearListaDatosObjeto());

		String findContractConnectionProtocolByIdContract = contractConnectionManagementEntityManagerRepository
				.findContractConnectionProtocolByIdContract("123");

		assertNotNull(findContractConnectionProtocolByIdContract);
		assertEquals("value", findContractConnectionProtocolByIdContract);

	}

	/**
	 * @return
	 */
	private ArrayList<Object[]> crearListaDatosObjeto() {

		ArrayList<Object[]> listaDatosObjeto = new ArrayList<Object[]>();

		Object[] arrayObject = crearArrayObject();

		listaDatosObjeto.add(arrayObject);

		return listaDatosObjeto;
	}

	/**
	 * 
	 */
	private Object[] crearArrayObject() {

		Object[] arrayObject = { "value", "value", "value", "value", "value", "value", "value", "value" };

		return arrayObject;
	}

	/**
	 * @return
	 */
	private ParameterEntity crearParameterEntity() {

		ParameterEntity parameterEntity = new ParameterEntity();

		parameterEntity.setValue("A");

		return parameterEntity;
	}

	/**
	 * @return
	 */
	private ArrayList<CatalogStatusEntity> crearListaCatalogStatusEntity() {

		ArrayList<CatalogStatusEntity> listaCatalogStatusEntity = new ArrayList<CatalogStatusEntity>();

		CatalogStatusEntity catalogStatusEntity = new CatalogStatusEntity();

		catalogStatusEntity.setIdCat(1);
		catalogStatusEntity.setType("GET");
		catalogStatusEntity.setEstatusActivo("A");
		catalogStatusEntity.setDescripcionCatalogo("CATALOG");

		listaCatalogStatusEntity.add(catalogStatusEntity);

		return listaCatalogStatusEntity;
	}

	/**
	 * @return
	 */
	private ContractConnectionManagementRequest crearContractConnectionManagementRequest() {

		ContractConnectionManagementRequest contractConnectionManagementRequest = new ContractConnectionManagementRequest();

		contractConnectionManagementRequest.setCodigoCliente("123");
		contractConnectionManagementRequest.setNumeroContrato("123");

		return contractConnectionManagementRequest;
	}

}
