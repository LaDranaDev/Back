package mx.santander.h2h.monitoreo.model.response;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

class ArchivoConteoResponseTest {

    ArchivoConteoResponse archivoConteoResponse = new ArchivoConteoResponse();

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSetTotArchRecib() {
        archivoConteoResponse.setTotArchRecib(99L);
        Assertions.assertEquals(99L, archivoConteoResponse.getTotArchRecib());
    }

    @Test
    void testSetTotOpeRecib() {
        archivoConteoResponse.setTotOpeRecib(99L);
        Assertions.assertEquals(99L, archivoConteoResponse.getTotOpeRecib());
    }

    @Test
    void testSetTotMontoRecib() {
        archivoConteoResponse.setTotMontoRecib(BigDecimal.TEN);
        Assertions.assertEquals(BigDecimal.TEN, archivoConteoResponse.getTotMontoRecib());
    }

    @Test
    void testSetCliente() {
        archivoConteoResponse.setCliente("cliente");
        Assertions.assertEquals("cliente", archivoConteoResponse.getCliente());
    }

    @Test
    void testSetCodCliente() {
        archivoConteoResponse.setCodCliente("codCliente");
        Assertions.assertEquals("codCliente", archivoConteoResponse.getCodCliente());
    }

    @Test
    void testSetTotAlerta() {
        archivoConteoResponse.setTotAlerta(99L);
        Assertions.assertEquals(99L, archivoConteoResponse.getTotAlerta());
    }

    @Test
    void testSetTotDupl() {
        archivoConteoResponse.setTotDupl(99L);
        Assertions.assertEquals(99L, archivoConteoResponse.getTotDupl());
    }

    @Test
    void testSetTotEsp() {
        archivoConteoResponse.setTotEsp(99L);
        Assertions.assertEquals(99L, archivoConteoResponse.getTotEsp());
    }

    @Test
    void testSetTotEnProc() {
        archivoConteoResponse.setTotEnProc(99L);
        Assertions.assertEquals(99L, archivoConteoResponse.getTotEnProc());
    }

    @Test
    void testSetTotEnroll() {
        archivoConteoResponse.setTotEnroll(99L);
        Assertions.assertEquals(99L, archivoConteoResponse.getTotEnroll());
    }

    @Test
    void testSetTotProc() {
        archivoConteoResponse.setTotProc(99L);
        Assertions.assertEquals(99L, archivoConteoResponse.getTotProc());
    }

    @Test
    void testSetTotProg() {
        archivoConteoResponse.setTotProg(99L);
        Assertions.assertEquals(99L, archivoConteoResponse.getTotProg());
    }

    @Test
    void testSetTotRecha() {
        archivoConteoResponse.setTotRecha(99L);
        Assertions.assertEquals(99L, archivoConteoResponse.getTotRecha());
    }

    @Test
    void testSetTotRecib() {
        archivoConteoResponse.setTotRecib(99L);
        Assertions.assertEquals(99L, archivoConteoResponse.getTotRecib());
    }

    @Test
    void testSetTotVald() {
        archivoConteoResponse.setTotVald(99L);
        Assertions.assertEquals(99L, archivoConteoResponse.getTotVald());
    }

    @Test
    void testSetDetalle() {
        List<ArchivoConteoResponse> detalle = Collections.singletonList(new ArchivoConteoResponse());
        archivoConteoResponse.setDetalle(detalle);
        Assertions.assertEquals(detalle, archivoConteoResponse.getDetalle());
    }

}
