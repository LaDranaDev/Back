package mx.santander.h2h.monitoreo.controller;

import mx.santander.h2h.monitoreo.model.report.request.MonitorSaldosReportRequest;
import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.MonitorSaldosRequest;
import mx.santander.h2h.monitoreo.model.response.MonitorSaldosResponse;
import mx.santander.h2h.monitoreo.service.IMonitorSaldosReportService;
import mx.santander.h2h.monitoreo.service.IMonitorSaldosService;
import mx.santander.h2h.monitoreo.utils.TestUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ContextConfiguration(classes = {MonitorSaldosController.class})
class MonitorSaldosControllerTest {

    @Mock
    private IMonitorSaldosService monitorSaldosService;

    @Mock
    private IMonitorSaldosReportService monitorSaldosReportService;

    @InjectMocks
    private MonitorSaldosController monitorSaldosController;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp(){
        MockitoAnnotations.openMocks(this);
        this.mockMvc = MockMvcBuilders
                .standaloneSetup(monitorSaldosController)
                .setCustomArgumentResolvers(new PageableHandlerMethodArgumentResolver()).build();
    }

    @Test
    void getSaldosReintentosCliente() throws Exception {
        MonitorSaldosRequest request = getRequest();
        List<MonitorSaldosResponse> dataResponse = Arrays.asList(getResponse());
        Page<MonitorSaldosResponse> response = new PageImpl<>(dataResponse);

        when(monitorSaldosService.getSaldosReintentosCliente(any(MonitorSaldosRequest.class), any()))
                .thenReturn(response);

        mockMvc.perform(post("/saldos")
                .content(TestUtils.asJsonString(request)).contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON));
        verify(monitorSaldosService).getSaldosReintentosCliente(any(MonitorSaldosRequest.class), any());

    }

    @Test
    void getReportSaldosReintentos() throws Exception {
        MonitorSaldosReportRequest request = getReportRequest();
        ReportResponse response = getReportResponse();

        when(monitorSaldosReportService.getReportSaldosReintentos(any(MonitorSaldosReportRequest.class)))
                .thenReturn(response);

        mockMvc.perform(post("/saldos/reporte/xlsx")
                        .content(TestUtils.asJsonString(request)).contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        verify(monitorSaldosReportService).getReportSaldosReintentos(any(MonitorSaldosReportRequest.class));
    }

    private MonitorSaldosRequest getRequest(){
        return MonitorSaldosRequest.builder()
                .codigoCliente("04158057")
                .nombreArchivo("file2013.txt")
                .claveProducto("98")
                .fechaInicio("23/08/2013")
                .fechaFin("04/09/2013")
                .build();
    }

    private MonitorSaldosResponse getResponse(){
        return MonitorSaldosResponse.builder()
                .cuentaOrdenante("60500694011")
                .fechaEnvioConsulta("04/09/2013")
                .horaEnvioConsulta("22:31:04")
                .montoRequerido("$20,000,000.15")
                .saldoConsulta("$47,526.51")
                .saldoFaltante("$19,952,473.64")
                .lineaCredito("N")
                .nombreArchivo("tran04092013")
                .cveProdOper("98")
                .producto("TBM")
                .build();
    }

    private MonitorSaldosReportRequest getReportRequest(){
        return MonitorSaldosReportRequest.builder()
                .monitorSaldosRequest(getRequest())
                .usuario("prueba")
                .build();
    }

    private ReportResponse getReportResponse(){
        return ReportResponse.builder()
                .data("report")
                .length(123)
                .name("report_name")
                .type("type")
                .build();
    }

}