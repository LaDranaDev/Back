package mx.santander.h2h.monitoreo.model.response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PutGetServiceResponseTest {

    private PutGetServiceResponse putGetServiceResponse;

    @BeforeEach
    void setUp() {
        putGetServiceResponse = new PutGetServiceResponse();
    }

    @Test
    void allArgsConstructot() {
        putGetServiceResponse = new PutGetServiceResponse(new ArrayList<>(), new ArrayList<>(),
                new ArrayList<>(), "protocolo", "id", "host", "id", "nombre", "ldapUser", "ldapPwd", "keystore");

        assertNotNull(putGetServiceResponse);
    }

    @Test
    void getRegistrosPG() {
        List<PutGetDto> registrosPG = new ArrayList<>();
        putGetServiceResponse.setRegistrosPG(registrosPG);
        assertEquals(registrosPG, putGetServiceResponse.getRegistrosPG());
    }

    @Test
    void getProtocolos() {
        List<ProtocolResponse> protocolos = new ArrayList<>();
        putGetServiceResponse.setProtocolos(protocolos);
        assertEquals(protocolos, putGetServiceResponse.getProtocolos());
    }

    @Test
    void getLstOs() {
        List<CatalogStatusResponse> lstOs = new ArrayList<>();
        putGetServiceResponse.setLstOs(lstOs);
        assertEquals(lstOs, putGetServiceResponse.getLstOs());
    }

    @Test
    void getIdProtocolo() {
        putGetServiceResponse.setIdProtocolo("protocolo");
        assertEquals("protocolo", putGetServiceResponse.getIdProtocolo());
    }

    @Test
    void getIdPara() {
        putGetServiceResponse.setIdPara("id");
        assertEquals("id", putGetServiceResponse.getIdPara());
    }

    @Test
    void getHostOs() {
        putGetServiceResponse.setHostOs("host");
        assertEquals("host", putGetServiceResponse.getHostOs());
    }

    @Test
    void getIdContrato() {
        putGetServiceResponse.setIdContrato("id");
        assertEquals("id", putGetServiceResponse.getIdContrato());
    }

    @Test
    void getNombreProtocolo() {
        putGetServiceResponse.setNombreProtocolo("nombre");
        assertEquals("nombre", putGetServiceResponse.getNombreProtocolo());
    }

    @Test
    void getLdapUser() {
        putGetServiceResponse.setLdapUser("ldapUser");
        assertEquals("ldapUser", putGetServiceResponse.getLdapUser());
    }

    @Test
    void getLdapPwd() {
        putGetServiceResponse.setLdapPwd("ldapPwd");
        assertEquals("ldapPwd", putGetServiceResponse.getLdapPwd());
    }

    @Test
    void getKeystore() {
        putGetServiceResponse.setKeystore("keystore");
        assertEquals("keystore", putGetServiceResponse.getKeystore());
    }

    @Test
    void toStringTest() {
     assertNotNull(putGetServiceResponse.toString());
    }
}