package mx.santander.h2h.monitoreo.service;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import mx.santander.h2h.monitoreo.model.response.PutGetDto;
import mx.santander.h2h.monitoreo.model.response.PutGetServiceResponse;
import mx.santander.h2h.monitoreo.model.response.PutGetWSDto;

class ContractConnectionManagementPutGetSaveDataServiceTest {
	@Mock
	private EntityManager entityManager;
	@Mock
	private ContractConnectionManagementPutGetFindDataService util;
	@InjectMocks
	private ContractConnectionManagementPutGetSaveDataService service;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	void testGuardaEnLDAP() {
		PutGetServiceResponse put = new PutGetServiceResponse();
		put.setLdapUser("");
		service.guardaEnLDAP(put, "");
		Assertions.assertTrue(true);
	}

	@Test
	void testGuardarParaCD() {
		Query query = mock(Query.class);
		when(entityManager.createNativeQuery(anyString())).thenReturn(query);
		
		List<String> opciones = new ArrayList<>();
		opciones.add("1");
		opciones.add("2");
		opciones.add("5");
		opciones.add("4");
		for (String op : opciones) {
			PutGetServiceResponse res = new PutGetServiceResponse();
			List<PutGetDto> lst = new ArrayList<>();
			PutGetDto dto = new PutGetDto(); 
			dto.setIdProtocolo(op);
			dto.setPutGetWSDto(new PutGetWSDto());
			lst.add(dto);
			res.setRegistrosPG(lst);
			service.guardarParaCD(res, new BigDecimal(1), "N");
			Assertions.assertTrue(true);
		}
	}
	
	@Test
	void testGuardarParaCD1() {
		Query query = mock(Query.class);
		when(entityManager.createNativeQuery(anyString())).thenReturn(query);
		
		List<String> opciones = new ArrayList<>();
		opciones.add("1");
		opciones.add("2");
		opciones.add("5");
		opciones.add("4");
		for (String op : opciones) {
			PutGetServiceResponse res = new PutGetServiceResponse();
			List<PutGetDto> lst = new ArrayList<>();
			PutGetDto dto = new PutGetDto(); 
			dto.setIdProtocolo(op);
			dto.setPutGetWSDto(new PutGetWSDto());
			lst.add(dto);
			res.setRegistrosPG(lst);
			service.guardarParaCD(res, new BigDecimal(1), "a");
			Assertions.assertTrue(true);
		}
	}

	@Test
	void testGuardaPtclPath() {
		Query query = mock(Query.class);
		when(entityManager.createNativeQuery(anyString())).thenReturn(query);
		
		PutGetServiceResponse res = new PutGetServiceResponse();
		List<PutGetDto> lst = new ArrayList<>();
		lst.add(new PutGetDto());
		res.setRegistrosPG(lst);
		service.guardaPtclPath(res, new BigDecimal(1), "a", "P");
		Assertions.assertTrue(true);
	}
	
	@Test
	void testGuardaPtclPath1() {
		Query query = mock(Query.class);
		when(entityManager.createNativeQuery(anyString())).thenReturn(query);
		
		PutGetServiceResponse res = new PutGetServiceResponse();
		List<PutGetDto> lst = new ArrayList<>();
		lst.add(new PutGetDto());
		res.setRegistrosPG(lst);
		service.guardaPtclPath(res, new BigDecimal(1), "a", "x");
		Assertions.assertTrue(true);
	}

	@Test
	void testGuardaPtclPara() {
		Query query = mock(Query.class);
		when(entityManager.createNativeQuery(anyString())).thenReturn(query);
		
		PutGetServiceResponse res = new PutGetServiceResponse();
		List<PutGetDto> lst = new ArrayList<>();
		lst.add(new PutGetDto());
		res.setRegistrosPG(lst);
		service.guardaPtclPara(new BigDecimal(1), res, "M", "x");
		Assertions.assertTrue(true);
	}
	
	@Test
	void testGuardaPtclPara1() {
		Query query = mock(Query.class);
		when(entityManager.createNativeQuery(anyString())).thenReturn(query);
		
		PutGetServiceResponse res = new PutGetServiceResponse();
		List<PutGetDto> lst = new ArrayList<>();
		lst.add(new PutGetDto());
		res.setRegistrosPG(lst);
		service.guardaPtclPara(new BigDecimal(1), res, "a", "x");
		Assertions.assertTrue(true);
	}

}
