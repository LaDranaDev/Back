package mx.santander.h2h.monitoreo.model.response;

import java.math.BigDecimal;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ArchivoCancelResponseTest {
    ArchivoCancelResponse response = new ArchivoCancelResponse();

    @Test
    void setIdRegistro() {
        response.setIdRegistro(123L);
        Assertions.assertEquals(123L, response.getIdRegistro());
    }

    @Test
    void setIdOperacion() {
        response.setIdOperacion("25368");
        Assertions.assertEquals("25368", response.getIdOperacion());
    }

    @Test
    void setCtaCargo() {
        response.setCtaCargo("894526");
        Assertions.assertEquals("894526", response.getCtaCargo());
    }

    @Test
    void setCtaAbono() {
        response.setCtaAbono("25648952");
        Assertions.assertEquals("25648952", response.getCtaAbono());
    }

    @Test
    void setProducto() {
        response.setProducto("12345678");
        Assertions.assertEquals("12345678", response.getProducto());
    }

    @Test
    void setCanal() {
        response.setCanal("25");
        Assertions.assertEquals("25", response.getCanal());
    }

    @Test
    void setReferencia() {
        response.setReferencia("hola");
        Assertions.assertEquals("hola", response.getReferencia());
    }

    @Test
    void setImporte() {
        response.setImporte(new BigDecimal(123.25));
        Assertions.assertEquals(new BigDecimal(123.25), response.getImporte());
    }

    @Test
    void setBandera() {
        response.setBandera("true");
        Assertions.assertEquals("true", response.getBandera());
    }

    @Test
    void setMovimiento() {
        response.setMovimiento(2568L);
        Assertions.assertEquals(2568L, response.getMovimiento());
    }

    @Test
    void setBuc() {
        response.setBuc("79240989");
        Assertions.assertEquals("79240989", response.getBuc());
    }

    @Test
    void setNomArchivo() {
        response.setNomArchivo("test.txt");
        Assertions.assertEquals("test.txt", response.getNomArchivo());
    }

    @Test
    void setEstatus() {
        response.setEstatus("ACTIVO");
        Assertions.assertEquals("ACTIVO", response.getEstatus());
    }

    @Test
    void setIdEstatus() {
        response.setIdEstatus(78);
        Assertions.assertEquals(78, response.getIdEstatus());
    }

    @Test
    void setCodCliente() {
        response.setCodCliente("79240989");
        Assertions.assertEquals("79240989", response.getCodCliente());
    }

    @Test
    void testToString() {
        String result = response.toString();
        Assertions.assertNotNull(result);
    }
}