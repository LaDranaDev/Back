package mx.santander.h2h.monitoreo.model.response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class PutGetRestResponseTest {

    private PutGetRestResponse putGetRestResponse;

    @BeforeEach
    void setUp() {
        putGetRestResponse = new PutGetRestResponse();
    }

    @Test
    void allArgsConstruction() {
        putGetRestResponse = new PutGetRestResponse("id", "cntr", "ctle","tipo", "id", new ArrayList<>(),
                new ArrayList<>(), "protocolo", "id", "id", "id", "MSG_ERR", mock(PutGetServiceResponse.class));

        assertNotNull(putGetRestResponse);
    }

    @Test
    void getIdcntrPutGet() {
        putGetRestResponse.setIdcntrPutGet("id");
        assertEquals("id", putGetRestResponse.getIdcntrPutGet());
    }

    @Test
    void getCntrPutget() {
        putGetRestResponse.setCntrPutget("cntr");
        assertEquals("cntr", putGetRestResponse.getCntrPutget());
    }

    @Test
    void getCltePutget() {
        putGetRestResponse.setCltePutget("clte");
        assertEquals("clte", putGetRestResponse.getCltePutget());
    }

    @Test
    void getTipoOperPG() {
        putGetRestResponse.setTipoOperPG("tipo");
        assertEquals("tipo", putGetRestResponse.getTipoOperPG());
    }

    @Test
    void getIdPtclPara() {
        putGetRestResponse.setIdPtclPara("id");
        assertEquals("id", putGetRestResponse.getIdPtclPara());
    }

    @Test
    void getProtocolos() {
        List<PutGetDto> protocolos = new ArrayList<>();
        putGetRestResponse.setProtocolos(protocolos);
        assertEquals(protocolos, putGetRestResponse.getProtocolos());
    }

    @Test
    void getLstProtocolos() {
        List<ProtocolResponse> lstProtocolos = new ArrayList<>();
        putGetRestResponse.setLstProtocolos(lstProtocolos);
        assertEquals(lstProtocolos, putGetRestResponse.getLstProtocolos());
    }

    @Test
    void getProtocoloActivo() {
        putGetRestResponse.setProtocoloActivo("protocolo");
        assertEquals("protocolo", putGetRestResponse.getProtocoloActivo());
    }

    @Test
    void getIdProtocolo() {
        putGetRestResponse.setIdProtocolo("id");
        assertEquals("id", putGetRestResponse.getIdProtocolo());
    }

    @Test
    void getIdProtocoloPath1() {
        putGetRestResponse.setIdProtocoloPath1("id");
        assertEquals("id", putGetRestResponse.getIdProtocoloPath1());
    }

    @Test
    void getIdProtocoloPath2() {
        putGetRestResponse.setIdProtocoloPath2("id");
        assertEquals("id", putGetRestResponse.getIdProtocoloPath2());
    }

    @Test
    void getPutGetResponse() {
        PutGetServiceResponse putGetRestResponse1 = mock(PutGetServiceResponse.class);
        putGetRestResponse.setPutGetResponse(putGetRestResponse1);
        assertEquals(putGetRestResponse1, putGetRestResponse.getPutGetResponse());
    }

    @Test
    void toStringTest() {
        assertNotNull(putGetRestResponse.toString());
    }
}