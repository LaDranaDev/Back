package mx.santander.h2h.monitoreo.util;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.mockito.Mockito.mock;
import static org.mockito.ArgumentMatchers.anyList;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import jakarta.persistence.Tuple;
import mx.santander.h2h.monitoreo.model.entity.CatalogChannelEntity;
import mx.santander.h2h.monitoreo.model.response.CatalogChannelResponse;
import mx.santander.h2h.monitoreo.model.response.MonitorDeArchivosEnCursoDetallesResponse;

class UtilTest {

    @Mock
    Logger log;

    @InjectMocks
    Util util;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFilterList() {
        CatalogChannelEntity channelEntity1 = new CatalogChannelEntity();
        channelEntity1.setIdChannel(1);

        CatalogChannelEntity channelEntity2 = new CatalogChannelEntity();
        channelEntity2.setIdChannel(2);

        CatalogChannelEntity channelEntity3 = new CatalogChannelEntity();
        channelEntity3.setIdChannel(3);

        List<CatalogChannelEntity> list = Arrays.asList(channelEntity1, channelEntity2, channelEntity3);

        List<CatalogChannelResponse> result = Util.filterList("2|3", list);
        Assertions.assertEquals(1, result.size());
    }

    @Test
    void testGetCurrentDate() {
        Date result = Util.getCurrentDate();
        Assertions.assertEquals(LocalDate.now(), result.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
    }

    @Test
    void testValidateCheck() {
        String result = Util.validateCheck("");
        Assertions.assertEquals("I", result);
    }
    
  @Test
  void testvalidaDuplicidadNombreArchivo() {
  	Tuple tuple = mock(Tuple.class);
  	MonitorDeArchivosEnCursoDetallesResponse bean = new MonitorDeArchivosEnCursoDetallesResponse();
  	bean.setTotalOper(2);
  	bean.setTotalMont(BigDecimal.valueOf(12));
  	List<MonitorDeArchivosEnCursoDetallesResponse> listBean = new ArrayList<>();
  	List<?> datos = new ArrayList<>();
  	Util.validaDuplicidadNombreArchivo(datos, tuple, bean, 27126, 3723, listBean, 12, BigDecimal.valueOf(12));
  	Assertions.assertNotNull(bean);
  }
}
