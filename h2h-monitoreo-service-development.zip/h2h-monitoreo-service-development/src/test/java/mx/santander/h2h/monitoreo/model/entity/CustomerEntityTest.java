package mx.santander.h2h.monitoreo.model.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class CustomerEntityTest {

    private CustomerEntity customerEntity;

    @BeforeEach
    void setUp(){
        customerEntity = new CustomerEntity();
    }

    @Test
    void getIdCliente() {
        customerEntity.setIdCliente(1L);
        assertEquals(1L, customerEntity.getIdCliente());
    }

    @Test
    void getRazonSocial() {
        customerEntity.setRazonSocial("razonSocial");
        assertEquals("razonSocial", customerEntity.getRazonSocial());
    }

    @Test
    void getNombre() {
        customerEntity.setNombre("nombre");
        assertEquals("nombre", customerEntity.getNombre());
    }

    @Test
    void getApMaterno() {
        customerEntity.setApMaterno("apMaterno");
        assertEquals("apMaterno", customerEntity.getApMaterno());
    }

    @Test
    void getApPaterno() {
        customerEntity.setApPaterno("apPaterno");
        assertEquals("apPaterno", customerEntity.getApPaterno());
    }

    @Test
    void getBuc() {
        customerEntity.setBuc("buc");
        assertEquals("buc", customerEntity.getBuc());
    }

    @Test
    void getCondicion() {
        customerEntity.setCondicion("condicion");
        assertEquals("condicion", customerEntity.getCondicion());
    }

    @Test
    void getEjecutivo() {
        customerEntity.setEjecutivo("ejecutivo");
        assertEquals("ejecutivo", customerEntity.getEjecutivo());
    }

    @Test
    void getFecha() {
        LocalDate fecha = LocalDate.parse("2023-04-19");
        customerEntity.setFecha(fecha);
        assertEquals(fecha, customerEntity.getFecha());
    }

    @Test
    void getIdSegmento() {
        customerEntity.setIdSegmento(123);
        assertEquals(123, customerEntity.getIdSegmento());
    }

    @Test
    void getPersonalidad() {
        customerEntity.setPersonalidad("personalidad");
        assertEquals("personalidad", customerEntity.getPersonalidad());
    }

    @Test
    void getRfc() {
        customerEntity.setRfc("rfc");
        assertEquals("rfc", customerEntity.getRfc());
    }

    @Test
    void getNemonico() {
        customerEntity.setNemonico("nemonico");
        assertEquals("nemonico", customerEntity.getNemonico());
    }
}