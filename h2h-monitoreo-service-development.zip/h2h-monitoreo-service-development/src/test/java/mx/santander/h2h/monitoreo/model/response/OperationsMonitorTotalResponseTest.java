package mx.santander.h2h.monitoreo.model.response;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

import org.junit.jupiter.api.Test;

import mx.santander.h2h.monitoreo.util.JavaBeanTester;


/**
 * OperationsMonitorTotalResponseTest.
 *
 * @author Jesus Soto Aguilar
 * @since 04/05/2023
 */
class OperationsMonitorTotalResponseTest {

    @Test
    void testFields() {
        assertDoesNotThrow(() ->
                JavaBeanTester.test(OperationsMonitorTotalResponse.class)
        );
    }

}