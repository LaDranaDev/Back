package mx.santander.h2h.monitoreo.utils;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import mx.santander.h2h.monitoreo.exception.commons.BusinessException;
import mx.santander.h2h.monitoreo.model.request.MonitorArchivosEnCursoRequest;
import mx.santander.h2h.monitoreo.model.response.ParametersGetPutResponse;
import mx.santander.h2h.monitoreo.util.ContractConnectionManagementEntityManagerUtils;

@ExtendWith(MockitoExtension.class)
class ContractConnectionManagementEntityManagerUtilsTest {

	@InjectMocks
	private ContractConnectionManagementEntityManagerUtils contractConnectionManagementEntityManagerUtils;

	@Mock
	private EntityManager entityManager;

	@Mock
	private Query query;

	@BeforeEach
	public void setUp() {

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);

	}

	@Test
	void actualizarParametro() {

		contractConnectionManagementEntityManagerUtils.actualizarParametro("valorParametro", new BigDecimal(2),
				"nombre");

		verify(entityManager, times(1)).createNativeQuery(anyString());

	}

	@Test
	void insertParameters() {

		when(query.executeUpdate()).thenReturn(1);

		contractConnectionManagementEntityManagerUtils.insertParameters(2, "valorParametro", new BigDecimal(2), new BigDecimal(2),
				createParametersGetPutResponse());

		verify(entityManager, times(1)).createNativeQuery(anyString());

	}

	@Test
	void insertParametersException() {

		when(query.executeUpdate()).thenReturn(0);

		assertThrows(BusinessException.class, () -> contractConnectionManagementEntityManagerUtils.insertParameters(2,
				"valorParametro", new BigDecimal(2), new BigDecimal(2), createParametersGetPutResponse()));

		verify(entityManager, times(1)).createNativeQuery(anyString());

	}

	@Test
	void deleteParameters() {

		when(query.executeUpdate()).thenReturn(1);

		contractConnectionManagementEntityManagerUtils.deleteParameters(1260473470);

		verify(entityManager, times(1)).createNativeQuery(anyString());

	}

	@Test
	void getInsertionKeysFromParameters() {

		when(query.getResultList()).thenReturn(createListBigDecimal());

		contractConnectionManagementEntityManagerUtils.getInsertionKeysFromParameters(crearListaParametersGetPutResponse(), new HashMap<String, BigDecimal>());

		verify(entityManager, times(4)).createNativeQuery(anyString());

	}

	@Test
	void getInsertionKeysFromParametersEmptyResult() {
		getMonitorArchivosEnCursoRequest();
		
		when(query.getResultList()).thenReturn(new ArrayList<BigDecimal>());

		contractConnectionManagementEntityManagerUtils.getInsertionKeysFromParameters(crearListaParametersGetPutResponse(), new HashMap<String, BigDecimal>());

		verify(entityManager, times(4)).createNativeQuery(anyString());

	}

	private ArrayList<BigDecimal> createListBigDecimal() {

		ArrayList<BigDecimal> listaDatos = new ArrayList<>();

		listaDatos.add(new BigDecimal(2));
		listaDatos.add(new BigDecimal(4));

		return listaDatos;
	}

	private List<ParametersGetPutResponse> crearListaParametersGetPutResponse() {

		List<ParametersGetPutResponse> listaParametersGetPutResponse = new ArrayList<>();

		listaParametersGetPutResponse.add(crearParametersGetPutResponse("2", "GET"));
		listaParametersGetPutResponse.add(crearParametersGetPutResponse("2", "PUT"));
		listaParametersGetPutResponse.add(crearParametersGetPutResponse("0", "GET"));
		listaParametersGetPutResponse.add(crearParametersGetPutResponse("0", "PUT"));
		listaParametersGetPutResponse.add(crearParametersGetPutResponse("", "GET"));
		listaParametersGetPutResponse.add(crearParametersGetPutResponse("", "PUT"));

		return listaParametersGetPutResponse;
	}

	private ParametersGetPutResponse crearParametersGetPutResponse(String idValorParametro, String tipoProcesamiento) {

		ParametersGetPutResponse parametersGetPutResponse = new ParametersGetPutResponse();

		parametersGetPutResponse.setIdValorParametro(idValorParametro);
		parametersGetPutResponse.setId("2");
		parametersGetPutResponse.setTipoProcesamiento("GET");
		parametersGetPutResponse.setValorParametro("valorParametro");

		return parametersGetPutResponse;
	}

	/**
	 * @return lista con array de datos
	 */
	private ArrayList<Object[]> createListObject() {

		ArrayList<Object[]> listaDatos = new ArrayList<>();

		listaDatos.add(crearArregloObject());

		return listaDatos;
	}

	private Object[] crearArregloObject() {

		Object[] objetoArreglo = { "dato1", "dato2" };

		return objetoArreglo;
	}

	/**
	 * @return Objeto parámetro Put / GET
	 */
	private ParametersGetPutResponse createParametersGetPutResponse() {

		ParametersGetPutResponse parametersGetPutResponse = new ParametersGetPutResponse();

		parametersGetPutResponse.setId("1");
		parametersGetPutResponse.setTipoProcesamiento("PUT");
		parametersGetPutResponse.setNombreParametro("nameParam");

		return parametersGetPutResponse;
	}
	
	private MonitorArchivosEnCursoRequest getMonitorArchivosEnCursoRequest() {
		MonitorArchivosEnCursoRequest request = new MonitorArchivosEnCursoRequest();
		request.setBuc(null);
		request.setCodCliente(null);
		request.setEstatus(null);
		request.setFechaFin(null);
		request.setFechaIni(null);
		request.setIdEstatus(null);
		request.setIdProducto(null);
		request.setNomArch(null);
		request.setNombreArch(null);
		request.setNumContrato(null);
		
		request.getBuc();
		request.getCodCliente();
		request.getEstatus();
		request.getFechaFin();
		request.getFechaIni();
		request.getIdEstatus();
		request.getIdProducto();
		request.getNomArch();
		request.getNombreArch();
		request.getNumContrato();
		return request;
	}

}
