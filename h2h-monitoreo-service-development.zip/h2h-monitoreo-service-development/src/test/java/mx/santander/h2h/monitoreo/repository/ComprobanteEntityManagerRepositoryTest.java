package mx.santander.h2h.monitoreo.repository;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import jakarta.persistence.TypedQuery;
import mx.santander.h2h.monitoreo.model.response.ComprobantesOperacionResponse;
import mx.santander.h2h.monitoreo.util.ComprobanteEntityManagerHelper;
import mx.santander.h2h.monitoreo.util.UtilComprobante;

class ComprobanteEntityManagerRepositoryTest {
    @Mock
    EntityManager entityManager;
    @Mock
    Logger log;
    @InjectMocks
    ComprobanteEntityManagerRepository comprobanteEntityManagerRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        comprobanteEntityManagerRepository = spy(comprobanteEntityManagerRepository);
    }

    @Test
    void testObtenerComprobantes() {
        List<ComprobantesOperacionResponse> expected = Collections.emptyList();
        doReturn(expected).when(comprobanteEntityManagerRepository).castMapToListComprobante(any());

        when(entityManager.createNativeQuery(any(), (Class<?>) any())).thenReturn(mock(Query.class));

        try (MockedStatic<UtilComprobante> utilComprobante = mockStatic(UtilComprobante.class)) {
            utilComprobante.when(() -> UtilComprobante.obtenerQueryTabla(any(), any())).thenReturn("TABLE");

            List<ComprobantesOperacionResponse> result = comprobanteEntityManagerRepository.obtenerComprobantes(Collections.singletonList(1), Collections.singletonList("vistaProd"));
            Assertions.assertEquals(expected, result);
        }
    }

    @Test
    void testCastMapToListComprobante() {
        doReturn(true).when(comprobanteEntityManagerRepository).esDelProducto(any(), any());
        doReturn(true).when(comprobanteEntityManagerRepository).seProcesaRegistro(any());

        Tuple tuple = mock(Tuple.class);
        when(tuple.get(anyString())).thenReturn(0L);
        TypedQuery query = mock(TypedQuery.class);
        when(entityManager.createQuery(anyString(), any())).thenReturn(query);
        when(query.getSingleResult()).thenReturn("12");
        comprobanteEntityManagerRepository.castMapToListComprobante(Collections.singletonList(tuple));
        Assertions.assertTrue(true);
    }

    @Test
    void testEsDelProducto() {
        boolean result = comprobanteEntityManagerRepository.esDelProducto("AB", "ABCD");
        Assertions.assertEquals(true, result);
    }

    @Test
    void testAplicaFormatoEspecial() {
        ComprobantesOperacionResponse bean = new ComprobantesOperacionResponse();
        bean.setCuentaCargo("11111111");
        bean.setCuentaAbono("11111111");
        bean.setDivisa("MXN");
        bean.setEsPagoTDC(true);

        Assertions.assertDoesNotThrow(() ->
                ComprobanteEntityManagerHelper.aplicaFormatoEspecial(bean)
        );
    }

    @Test
    void testSeProcesaRegistro() {
        ComprobantesOperacionResponse bean = new ComprobantesOperacionResponse();
        boolean result = comprobanteEntityManagerRepository.seProcesaRegistro(bean);
        Assertions.assertEquals(true, result);

        bean.setEsOrdenPago(true);
        bean.setEstatusOp("LIQUIDADA");
        result = comprobanteEntityManagerRepository.seProcesaRegistro(bean);
        Assertions.assertEquals(true, result);
    }
    
    @Test
    void testAsignaValorrazonSoc() {
    	Tuple tuple = mock(Tuple.class);
        comprobanteEntityManagerRepository.asignaValorrazonSoc("F", tuple, new ComprobantesOperacionResponse());
        Assertions.assertTrue(true);
    }
    
    @Test
    void testAsignaValorrazonSoc1() {
    	Tuple tuple = mock(Tuple.class);
        comprobanteEntityManagerRepository.asignaValorrazonSoc("M", tuple, new ComprobantesOperacionResponse());
        Assertions.assertTrue(true);
    }
    
    @Test
    void testValidaesEspeiRefIn() {
    	Tuple tuple = mock(Tuple.class);
    	ComprobantesOperacionResponse bean = new ComprobantesOperacionResponse();
    	bean.setTipoOper("SPEI");
        comprobanteEntityManagerRepository.validaesEspeiRefIn(bean, tuple);
        Assertions.assertTrue(true);
    }

}
