package mx.santander.h2h.monitoreo.utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import mx.santander.h2h.monitoreo.model.entity.CatalogChannelEntity;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.util.GenerateVouchersValidateDateImplUtils;
import mx.santander.h2h.monitoreo.util.Util;

@ExtendWith(MockitoExtension.class)
class GenerateVouchersValidateDateImplUtilsTest {

	@InjectMocks
	GenerateVouchersValidateDateImplUtils generateVouchersValidateDateImplUtils;
	
	@InjectMocks
	Util util;
	
	@Test
	void validateDateTest() {
		OperationsMonitorQueryRequest operationsMonitorQueryRequest = new OperationsMonitorQueryRequest();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		String fechaIni = sdf.format(new Date());
		operationsMonitorQueryRequest.setFechaInicial(fechaIni);
		operationsMonitorQueryRequest.setFechaFinal(fechaIni);
		generateVouchersValidateDateImplUtils.validateDate(operationsMonitorQueryRequest);
		Assertions.assertNotNull(operationsMonitorQueryRequest);
	}
	
	@Test
	void generarFechaTest() {
		OperationsMonitorQueryRequest operationsMonitorQueryRequest = new OperationsMonitorQueryRequest();
		operationsMonitorQueryRequest.setFechaInicial("25/03/2025 12:01:15");
		operationsMonitorQueryRequest.setFechaFinal("01/04/2025 13:01:55");
		Assertions.assertNotNull(operationsMonitorQueryRequest);
		generateVouchersValidateDateImplUtils.generarFecha();
	}
	
	@Test
	void calculaInicioFinTest() {
		OperationsMonitorQueryRequest operationsMonitorQueryRequest = new OperationsMonitorQueryRequest();
		operationsMonitorQueryRequest.setFechaInicial("25/03/2025 12:01:15");
		operationsMonitorQueryRequest.setFechaFinal("01/04/2025 13:01:55");
		Assertions.assertNotNull(operationsMonitorQueryRequest);
		generateVouchersValidateDateImplUtils.calculaInicioFin(1);
	}
	
	@Test
	void calculaInicioFinTest2() {
		OperationsMonitorQueryRequest operationsMonitorQueryRequest = new OperationsMonitorQueryRequest();
		operationsMonitorQueryRequest.setFechaInicial("25/03/2025 12:01:15");
		operationsMonitorQueryRequest.setFechaFinal("01/04/2025 13:01:55");
		Assertions.assertNotNull(operationsMonitorQueryRequest);
		generateVouchersValidateDateImplUtils.calculaInicioFin(18);
	}
	
	@Test
	void filterListTest() {
		String parameter = ".xls|.jar";
		List<CatalogChannelEntity> list = new ArrayList<>();
		CatalogChannelEntity c = new CatalogChannelEntity();
		c.setDescription("test");
		c.setIdCenter(1);
		c.setIdChannel(1);
		c.setName("test");
		c.setStatus("test");
		c.setStatusSelected("test");
		util.filterList(parameter, list);
		Assertions.assertNotNull(c);
	}
	
	@Test
	void filterListTest2() {
		String parameter = "";
		List<CatalogChannelEntity> list = new ArrayList<>();
		CatalogChannelEntity c = new CatalogChannelEntity();
		c.setDescription("test");
		c.setIdCenter(1);
		c.setIdChannel(1);
		c.setName("test");
		c.setStatus("test");
		c.setStatusSelected("test");
		util.filterList(parameter, list);
		Assertions.assertNotNull(c);
	}
}
