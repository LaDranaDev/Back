package mx.santander.h2h.monitoreo.model.request;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class CancelOperationRequestTest {
    CancelOperationRequest request = new CancelOperationRequest();

    @Test
    void setCodigoClienteEnc() {
        request.setCodigoClienteEnc("79240989");
        Assertions.assertEquals("79240989", request.getCodigoClienteEnc());
    }

    @Test
    void setHdnContratoFolio() {
        request.setHdnContratoFolio("68");
        Assertions.assertEquals("68", request.getHdnContratoFolio());
    }

    @Test
    void setCatalogoEstCntr() {
        request.setCatalogoEstCntr("CANCELADA");
        Assertions.assertEquals("CANCELADA", request.getCatalogoEstCntr());
    }

    @Test
    void setCodigoCliente() {
        request.setCodigoCliente("79240989");
        Assertions.assertEquals("79240989", request.getCodigoCliente());
    }

    @Test
    void setIdRegistro() {
        request.setIdRegistro("25131268722");
        Assertions.assertEquals("25131268722", request.getIdRegistro());
    }
}