package mx.santander.h2h.monitoreo.model.response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class GenerateVouchersControllerResponseTest {

	@InjectMocks
	GenerateVouchersControllerResponse generateVouchersControllerResponse;

	@Test
	void parametros() {

		Map<String, Object> parametros = new HashMap<String, Object>();
		generateVouchersControllerResponse.setParametros(parametros);

		Map<String, Object> parametrosResponse = generateVouchersControllerResponse.getParametros();

		assertEquals(parametros, parametrosResponse);

	}

	@Test
	void listaOperaciones() {

		List<OperationsMonitorQueryResponse> listaOperaciones = new ArrayList<>();
		generateVouchersControllerResponse.setListaOperaciones(listaOperaciones);

		List<OperationsMonitorQueryResponse> listaOperacionesResponse = generateVouchersControllerResponse
				.getListaOperaciones();

		assertEquals(listaOperaciones, listaOperacionesResponse);

	}

	@Test
	void totalOperaciones() {

		generateVouchersControllerResponse.setTotalOperaciones("totalOperaciones");

		String totalOperaciones = generateVouchersControllerResponse.getTotalOperaciones();

		assertEquals("totalOperaciones", totalOperaciones);

	}

	@Test
	void listaSize() {

		generateVouchersControllerResponse.setListaSize("listaSize");

		String listaSize = generateVouchersControllerResponse.getListaSize();

		assertEquals("listaSize", listaSize);

	}

	@Test
	void limiteRegistrosExportar() {

		generateVouchersControllerResponse.setLimiteRegistrosExportar(20);

		Integer limiteRegistrosExportar = generateVouchersControllerResponse.getLimiteRegistrosExportar();

		assertEquals(20, limiteRegistrosExportar);

	}

	@Test
	void totalPaginas() {

		generateVouchersControllerResponse.setTotalPaginas(20);

		Integer totalPaginas = generateVouchersControllerResponse.getTotalPaginas();

		assertEquals(20, totalPaginas);

	}

	@Test
	void realizaCalculo() {

		generateVouchersControllerResponse.setRealizaCalculo(Boolean.TRUE);

		Boolean realizaCalculo = generateVouchersControllerResponse.getRealizaCalculo();

		assertTrue(realizaCalculo);

	}

	@Test
	void inicio() {

		generateVouchersControllerResponse.setInicio(1);

		Integer inicio = generateVouchersControllerResponse.getInicio();

		assertEquals(1, inicio);

	}

	@Test
	void fin() {

		generateVouchersControllerResponse.setFin(20);

		Integer fin = generateVouchersControllerResponse.getFin();

		assertEquals(20, fin);

	}

	@Test
	void testToString() {

		String toStringResult = generateVouchersControllerResponse.toString();

		assertEquals(
				"GenerateVouchersControllerResponse(parametros=null, listaOperaciones=null, totalOperaciones=null, listaSize=null, limiteRegistrosExportar=null, totalPaginas=null, realizaCalculo=null, inicio=null, fin=null)",
				toStringResult);

	}

}
