package mx.santander.h2h.monitoreo.model.response;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;


class ContractConnectionProtocolsResponseTest {

    private ContractConnectionProtocolsResponse response;

    @BeforeEach
    void setUp(){
        response = new ContractConnectionProtocolsResponse();
    }

    @Test
    void allArgsConstruction() {
        response = new ContractConnectionProtocolsResponse("codCliente", "idContrato", new ArrayList<>(),
                new ArrayList<>(), "nombreProtocolo", 1, "idRegistro", new ArrayList<>(),
                new ArrayList<>(), "cod", "val");

        assertNotNull(response);
    }

    @Test
    void getCodClienteP() {
        response.setCodClienteP("123");
        assertEquals("123", response.getCodClienteP());
    }

    @Test
    void getIdContratoP() {
        response.setIdContratoP("123");
        assertEquals("123", response.getIdContratoP());
    }

    @Test
    void getRespuestaProt() {
        List<ProtocolResponse> protocol = new ArrayList<>();
        response.setRespuestaProt(protocol);
        assertEquals(protocol, response.getRespuestaProt());
    }

    @Test
    void getParametros() {
        List<String> parametros = new ArrayList<>();
        response.setParametros(parametros);
        assertEquals(parametros, response.getParametros());
    }

    @Test
    void getNombreProtocolo() {
        response.setNombreProtocolo("nombre");
        assertEquals("nombre", response.getNombreProtocolo());
    }

    @Test
    void getIdProt() {
        response.setIdProt(1);
        assertEquals(1, response.getIdProt());
    }

    @Test
    void getIdRegistro() {
        response.setIdRegistro("123");
        assertEquals("123", response.getIdRegistro());
    }

    @Test
    void getParametrosGetProt() {
        List<ParametersGetPutResponse> parametersGetPutResponses = new ArrayList<>();
        response.setParametrosGet(parametersGetPutResponses);
        assertEquals(parametersGetPutResponses, response.getParametrosGet());
    }

    @Test
    void getParametrosPutProt() {
        List<ParametersGetPutResponse> parametersGetPutResponses = new ArrayList<>();
        response.setParametrosPut(parametersGetPutResponses);
        assertEquals(parametersGetPutResponses, response.getParametrosPut());
    }

    @Test
    void getCodigoOp(){
        response.setCodigoOp("codigo");
        assertEquals("codigo", response.getCodigoOp());
    }

    @Test
    void getEstadoValor() {
        response.setEstadoValor("valor");
        assertEquals("valor", response.getEstadoValor());
    }

    @Test
    void toStringTest() {
        assertNotNull(response.toString());
    }

}