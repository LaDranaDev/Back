package mx.santander.h2h.monitoreo.repository;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.RETURNS_MOCKS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

@ExtendWith(MockitoExtension.class)
class OperationsMonitorComplementEntityManagerRepositoryTest {

	@Mock
    private EntityManager entityManager;
	
	@InjectMocks
	private OperationsMonitorComplementEntityManagerRepository complementEntityManagerRepository;
	
	@Test
	public void catalogsTest() {
		Query query = mock(Query.class, RETURNS_MOCKS);
		when(entityManager.createNativeQuery(anyString(), eq(Tuple.class)))
        .thenReturn(query);
		
		when(query.getResultList()).thenReturn(Collections.emptyList());
		
		assertDoesNotThrow(() -> complementEntityManagerRepository.catalogs());
	}

}
