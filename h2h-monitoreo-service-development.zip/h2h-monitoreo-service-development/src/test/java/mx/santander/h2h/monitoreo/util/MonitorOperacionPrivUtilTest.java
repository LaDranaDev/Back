package mx.santander.h2h.monitoreo.util;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;

@ExtendWith(MockitoExtension.class)
class MonitorOperacionPrivUtilTest {

	@InjectMocks
    private MonitorOperacionPrivUtil miClase;
    
	@Mock
	private StringBuilder query;
	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
	}
	
	
	@Test
	void testGetWhereConsOpercion2() {
		OperationsMonitorQueryRequest consOperaciones = getData();
		Map<String, Object> params = new HashMap<>();
		boolean filtro =  false;
		
		MonitorOperacionPrivUtil.getWhereConsOpercion2(consOperaciones, query, params, filtro);
		assertNotNull(params);
		
		filtro =  true;
		MonitorOperacionPrivUtil.getWhereConsOpercion2(consOperaciones, query, params, filtro);
		assertNotNull(params);
	}

	@Test
	void testGetDivisa() {
		Map<String, Object> params = new HashMap<>();
		boolean filtro =  false;
		query = new StringBuilder();
		query.append("SELECT ");
		
		MonitorOperacionPrivUtil.getDivisa(query, params, "MXN", filtro);
		assertNotNull(params);
		
		MonitorOperacionPrivUtil.getDivisa(query, params, "USD", filtro);
		assertNotNull(params);
		
		filtro =  true;
		MonitorOperacionPrivUtil.getDivisa(query, params, "MXN", filtro);
		assertNotNull(params);
		
		MonitorOperacionPrivUtil.getDivisa(query, params, "USD", filtro);
		assertNotNull(params);
	}

	@Test
	void testGetPif() {
		boolean exportar = true;
		OperationsMonitorQueryRequest consOperacones = getData(); 
		query = new StringBuilder().append("SELECT"); 
		Map<String, Object> params = new HashMap<>();
		
		MonitorOperacionPrivUtil.getPif(consOperacones, query, params, exportar);
		assertNotNull(params);
	}
	
	
	
	/** Metodos Privados */
	@Test
	void getselectImpFedTest() {
		boolean exportar = false;
		String resp = "";
	    resp = MonitorOperacionPrivUtil.getselectImpFed(exportar, "TEST");
	    assertTrue( resp.length() > 0);
	    
	    resp = MonitorOperacionPrivUtil.getselectImpFed(exportar, "21");
	    assertTrue( resp.length() > 0);
	    
	    resp = MonitorOperacionPrivUtil.getselectImpFed(exportar, "22");
	    assertTrue( resp.length() > 0);
	    
	    resp = MonitorOperacionPrivUtil.getselectImpFed(exportar, "23");
	    assertTrue( resp.length() > 0);
	    
	    // Valor DIA false
	    resp = MonitorOperacionPrivUtil.getselectImpFed(!exportar, "21");
	    assertTrue( resp.length() > 0);
	    
	    resp = MonitorOperacionPrivUtil.getselectImpFed(!exportar, "22");
	    assertTrue( resp.length() > 0);
	    
	    resp = MonitorOperacionPrivUtil.getselectImpFed(!exportar, "23");
	    assertTrue( resp.length() > 0);
	}
	
	
	@Test
	void getSelectConsultaOperacionesOrdenPagoTest() {
		boolean exportar = false;
		String resp = "";
	    resp = MonitorOperacionPrivUtil.getSelectConsultaOperacionesOrdenPago(exportar, "1");
	    assertTrue( resp.length() > 0);
		    
	    resp = MonitorOperacionPrivUtil.getSelectConsultaOperacionesOrdenPago(!exportar, "21");
	    assertTrue( resp.length() > 0);
	}
	
	
	@Test
	void getQueryConsOpAltaMasivaTest() {
		boolean exportar = false;
		String resp = "";
	    resp = MonitorOperacionPrivUtil.getQueryConsOpAltaMasiva(exportar);
	    assertTrue( resp.length() > 0);
	    
	    resp = MonitorOperacionPrivUtil.getQueryConsOpAltaMasiva(!exportar);
	    assertTrue( resp.length() > 0);
	}
	
	
	@Test
	void getQueryConsOperacionesTest() {
		OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();
		Map<String, Object> params = new HashMap<>();
		boolean exportar = false;
		String resp = "";
	    resp = MonitorOperacionPrivUtil.getQueryConsOperaciones(exportar, consultaOperaciones, params);
	    assertTrue( resp.length() > 0);
	    
	    consultaOperaciones.setIdProducto("11");
	    resp = MonitorOperacionPrivUtil.getQueryConsOperaciones(exportar, consultaOperaciones, params);
	    assertTrue( resp.length() > 0);
	    
	    consultaOperaciones.setCveProveedor("0987");
	    resp = MonitorOperacionPrivUtil.getQueryConsOperaciones(exportar, consultaOperaciones, params);
	    assertTrue( resp.length() > 0);
	    
	    consultaOperaciones.setTipOperacion("1");
	    resp = MonitorOperacionPrivUtil.getQueryConsOperaciones(exportar, consultaOperaciones, params);
	    assertTrue( resp.length() > 0);
	    
	}
	
	
	@Test
	void getWhereConsultaOperacionesTest() {
		OperationsMonitorQueryRequest consultaOperaciones = getData();
		consultaOperaciones.setFechaInicial("02/02/2024");
		consultaOperaciones.setFechaFinal("12/02/2024");
		
		Map<String, Object> params = new HashMap<>();
		boolean exportar = false;
		String resp = "";
	    resp = MonitorOperacionPrivUtil.getWhereConsultaOperaciones(consultaOperaciones, exportar, params);
	    assertTrue( resp.length() > 0);
	}
	
	
	
	private OperationsMonitorQueryRequest getData() {
		OperationsMonitorQueryRequest consOperacion = new OperationsMonitorQueryRequest();
		consOperacion.setFechaInicial("27/09/2024");
		consOperacion.setFechaFinal("31/09/2024");
		consOperacion.setBuc("12345");
		consOperacion.setContrato("09876542345");
		consOperacion.setNombreArchivo("TEST.com");
		consOperacion.setIdProducto("1");
		consOperacion.setIdEstatus("A");
		consOperacion.setCuentaCargo("12354768");
		consOperacion.setCuentaAbono("52453787");
		consOperacion.setImporte("10.00");
		consOperacion.setReferencia("5643");
		consOperacion.setDivisa("MXN");
		consOperacion.setNumeroOrden("3254");
		consOperacion.setNombreBeneficiario("TEST TEST");
		consOperacion.setIdReg("101");
		consOperacion.setNumEmpleado("56245");
		consOperacion.setNumTarjeta("264573567");
		consOperacion.setSucTutora("356");
		consOperacion.setLineaCaptura("56735835245624562456");
		consOperacion.setConvenio("5234");
		consOperacion.setFolioSUA("25");
		consOperacion.setRegPat("134");
		
		return consOperacion;
	}
}
