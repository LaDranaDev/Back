/**
* Santander Tecnologia - Banco Santander Central Hispano
* Todos los derechos reservados
* UtilMonitorFncTest.java
*
* Control de versiones:
*
* Version Date/Hour                By        Company   Description
* ------- ------------------------ --------  --------- --------------
* 1.0    <2 jul. 2024 11:53:40>  Santander Santander Creacion de Clase primera fase.
*
*/
package mx.santander.h2h.monitoreo.util;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;



/**
 * Clase generada para UtilMonitorFncTest.
 *
 * @autor C320868
 * @modifico C320868
 */
class UtilMonitorFncTest {

	/**
	 * Test get query.
	 */
	@Test
	void testGetQuery() {
		String cadRsp = UtilMonitorFnc.getQuery(null);
		
		if( cadRsp == null) {
			assertNull(cadRsp);
		} else {
			assertNotNull(cadRsp);
		}
	}
	
	
	/**
	 * Test get query 2.
	 */
	@Test
	void testGetQuery2() {
		Map<String, Object> miArreglo = new HashMap<String, Object>();
		miArreglo.put("hola", "SCRIPT SQL");
		
		String cadRsp = UtilMonitorFnc.getQuery(miArreglo);
		if( cadRsp == null) {
			assertNull(cadRsp);
		} else {
			assertNotNull(cadRsp);
		}
	}
	
	
	
	/**
	 * Test get query 3.
	 */
	@Test
	void testGetQuery3() {
		Map<String, Object> miArreglo = new HashMap<String, Object>();
		miArreglo.put("query", "SCRIPT SQL");
		
		String cadRsp = UtilMonitorFnc.getQuery(miArreglo);
		if( cadRsp == null) {
			assertNull(cadRsp);
		} else {
			assertNotNull(cadRsp);
		}
	}
	

	/**
	 * Test get array.
	 */
	@Test
	void testGetArray() {
		Map<String, Object> miArreglo = new HashMap<String, Object>();
		Map<String, Object> respFnc = UtilMonitorFnc.getArray(miArreglo);
		
		if( respFnc == null) {
			assertNull(respFnc);
		} else {
			assertNotNull(respFnc);
		}
	}
	
	
	/**
	 * Test get array 2.
	 */
	@Test
	void testGetArray2() {
		Map<String, Object> miArreglo = new HashMap<String, Object>();
		miArreglo.put("query", "SCRIPT SQL");
		
		Map<String, Object> respFnc = UtilMonitorFnc.getArray(miArreglo);
		
		if( respFnc == null) {
			assertNull(respFnc);
		} else {
			assertNotNull(respFnc);
		}
	}
	
	
	/**
	 * Test get array 3.
	 */
	@Test
	void testGetArray3() {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("bd", "Ejemplo BD");
		params.put("host", "local");
		params.put("query", "Ejemplo query");
		params.put("ip", "180.0.0.0");
		
		Map<String, Object> miArreglo = new HashMap<String, Object>();
		miArreglo.put("query", "SCRIPT SQL");
		miArreglo.put("params", params);
		
		Map<String, Object> respFnc = UtilMonitorFnc.getArray(miArreglo);
		
		if( respFnc == null) {
			assertNull(respFnc);
		} else {
			assertNotNull(respFnc);
		}
	}
	

	/**
	 * Test cad divisa.
	 */
	@Test
	void testCadDivisa() {
		StringBuilder cadResp = new StringBuilder();
		Map<String, Object> params = new HashMap<>();
		boolean filtro = false;
		UtilMonitorFnc.cadDivisa(cadResp, null, null, params, filtro);
		if( filtro) {
			assertTrue(filtro);
		} else {
			assertFalse (filtro);
		}
	}

	
	/**
	 * Test cad divisa 2.
	 */
	@Test
	void testCadDivisa2() {
		StringBuilder cadResp = new StringBuilder();
		Map<String, Object> params = new HashMap<>();
		boolean filtro = false;
		UtilMonitorFnc.cadDivisa(cadResp, "MX", "MXN", params, filtro);
		if( filtro) {
			assertTrue(filtro);
		} else {
			assertFalse (filtro);
		}
	}
	
	
	@Test
	void testValDivisa() {
		Object[] objeto = {"MN", "MXP", "USD"};
		String datos = "";
		for(int i=0; i<objeto.length; i++) {
			datos = UtilMonitorFnc.valDivisa( objeto[i] );
			assertNotNull(datos);
		}
	}
	
}
