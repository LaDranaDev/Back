package mx.santander.h2h.monitoreo.model.request;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.Month;

class ArchivoTrackingRequestTest {

    ArchivoTrackingRequest archivoTrackingRequest = new ArchivoTrackingRequest();

    @Test
    void testSetFecha() {
        archivoTrackingRequest.setFecha(LocalDate.of(2020, Month.FEBRUARY, 2));
        Assertions.assertEquals(LocalDate.of(2020, Month.FEBRUARY, 2), archivoTrackingRequest.getFecha());
    }

    @Test
    void testSetCodCliente() {
        archivoTrackingRequest.setCodCliente("codCliente");
        Assertions.assertEquals("codCliente", archivoTrackingRequest.getCodCliente());
    }

    @Test
    void testSetNomArch() {
        archivoTrackingRequest.setNomArch("nomArch");
        Assertions.assertEquals("nomArch", archivoTrackingRequest.getNomArch());
    }

    @Test
    void testSetCodEstatus() {
        archivoTrackingRequest.setCodEstatus(99);
        Assertions.assertEquals(99, archivoTrackingRequest.getCodEstatus());
    }

}
