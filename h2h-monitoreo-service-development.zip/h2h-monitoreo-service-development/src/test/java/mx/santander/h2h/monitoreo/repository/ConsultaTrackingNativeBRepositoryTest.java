package mx.santander.h2h.monitoreo.repository;

import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;

import mx.santander.h2h.monitoreo.model.response.ProductoArchivoResponse;

@ExtendWith(MockitoExtension.class)
class ConsultaTrackingNativeBRepositoryTest {
	
	@InjectMocks
	private ConsultaTrackingNativeBRepository consultaTrackingNativeBRepository;
	
	@Mock
	private EntityManager entityManager;

	@Test
	void obtenerDetalleArchivosNivelArchivoTest() {
		
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);

		consultaTrackingNativeBRepository.obtenerDetalleArchivosNivelArchivo(Pageable.ofSize(1), "27/06/2023", "04158057", "archivo", 0);
		Assertions.assertTrue(true);
	}
	@Test
	void obtenerDetalleArchivosNivelArchivoTest1() {
		
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);

		consultaTrackingNativeBRepository.obtenerDetalleArchivosNivelArchivo(Pageable.ofSize(1), "27/06/2023", "04158057", "", 1);
		Assertions.assertTrue(true);
	}
	@Test
	void obtenerDetalleArchivosNivelArchivoTest2() {
		
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);

		consultaTrackingNativeBRepository.obtenerDetalleArchivosNivelArchivo(Pageable.ofSize(1), "27/06/2023", "04158057", "", 2);
		Assertions.assertTrue(true);
	}
	@Test
	void obtenerDetalleArchivosNivelArchivoTest3() {
		
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);

		consultaTrackingNativeBRepository.obtenerDetalleArchivosNivelArchivo(Pageable.ofSize(1), "27/06/2023", "04158057", "", 3);
		Assertions.assertTrue(true);
	}
	@Test
	void obtenerDetalleArchivosNivelArchivoTest4() {
		
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);

		consultaTrackingNativeBRepository.obtenerDetalleArchivosNivelArchivo(Pageable.ofSize(1), "27/06/2023", "04158057", "", 4);
		Assertions.assertTrue(true);
	}
	@Test
	void obtenerDetalleArchivosNivelArchivoTest5() {
		
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);

		consultaTrackingNativeBRepository.obtenerDetalleArchivosNivelArchivo(Pageable.ofSize(1), "27/06/2023", "04158057", "", 5);
		Assertions.assertTrue(true);
	}
	@Test
	void obtenerDetalleArchivosNivelArchivoTest6() {
		
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);

		consultaTrackingNativeBRepository.obtenerDetalleArchivosNivelArchivo(Pageable.ofSize(1), "27/06/2023", "04158057", "", 6);
		Assertions.assertTrue(true);
	}
	@Test
	void obtenerDetalleArchivosNivelArchivoTest7() {
		
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);

		consultaTrackingNativeBRepository.obtenerDetalleArchivosNivelArchivo(Pageable.ofSize(1), "27/06/2023", "04158057", "", 7);
		Assertions.assertTrue(true);
	}
	@Test
	void obtenerDetalleArchivosNivelArchivoTest8() {
		
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);

		consultaTrackingNativeBRepository.obtenerDetalleArchivosNivelArchivo(Pageable.ofSize(1), "27/06/2023", "04158057", "", 8);
		Assertions.assertTrue(true);
	}
	@Test
	void obtenerDetalleArchivosNivelArchivoTest9() {
		
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);

		consultaTrackingNativeBRepository.obtenerDetalleArchivosNivelArchivo(Pageable.ofSize(1), "27/06/2023", "04158057", "", null);
		Assertions.assertTrue(true);
	}

	@Test
	void obtenerDetalleArchivosNivelArchivoComplement() {
		List<ProductoArchivoResponse> listBean = new ArrayList<ProductoArchivoResponse>();
		
		consultaTrackingNativeBRepository.obtenerDetalleArchivosNivelArchivoComplement(1234, 12345, 1368, productoResp(), 
				new BigDecimal("0.12"), 12 ,listBean, "motivo");
		Assertions.assertTrue(true);
	}
	
	public ProductoArchivoResponse productoResp() {
		ProductoArchivoResponse prod = new ProductoArchivoResponse();
		prod.setTotalOperaciones(20);
		prod.setMonto(new BigDecimal("12.3"));
		return prod;
	}
	
	@Test
	void obtenerDetalleArchivosNivelArchivoComplement2() {
		List<ProductoArchivoResponse> listBean = new ArrayList<ProductoArchivoResponse>();
		
		consultaTrackingNativeBRepository.obtenerDetalleArchivosNivelArchivoComplement(1234, 1234, 1368, productoResp(), 
				new BigDecimal("0.12"), 12 ,listBean, "motivo");
		Assertions.assertTrue(true);
	}
	
	@Test
	void obtenerDetalleArchivosNivelArchivoComplement3() {
		List<ProductoArchivoResponse> listBean = new ArrayList<ProductoArchivoResponse>();
		
		consultaTrackingNativeBRepository.obtenerDetalleArchivosNivelArchivoComplement(0, 1234, 1368, productoResp(), 
				new BigDecimal("0.12"), 12 ,listBean, "motivo");
		Assertions.assertTrue(true);
	}
	
	@Test
	void obtenerDetalleArchivosNivelArchivoComplement4() {
		List<ProductoArchivoResponse> listBean = new ArrayList<ProductoArchivoResponse>();
		
		consultaTrackingNativeBRepository.obtenerDetalleArchivosNivelArchivoComplement(1234, 12345, 1368, productoResp(), 
				new BigDecimal("0.12"), 16 ,listBean, "motivo");
		Assertions.assertTrue(true);
	}
	
	@Test
	void obtenerDetalleArchivosNivelArchivoTest10() {
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		consultaTrackingNativeBRepository.verificarDetalleArchivos(detalleProducto(), 0);
		Assertions.assertTrue(true);
	}
	
	@Test
	void obtenerDetalleArchivosNivelArchivoTest11() {
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		consultaTrackingNativeBRepository.verificarDetalleArchivos(detalleProducto(), 16);
		Assertions.assertTrue(true);
	}
	
	@Test
	void obtenerListDetalleArchivosNivelArchivo() {
		TypedQuery query = Mockito.mock(TypedQuery.class);
		
		when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		consultaTrackingNativeBRepository.obtenerListDetalleArchivosNivelArchivo("28/06/2023", "12345678", "archivo.kh", 5);
		Assertions.assertTrue(true);
	}
	
	public List<ProductoArchivoResponse> detalleProducto(){
		List<ProductoArchivoResponse> detalle = new ArrayList<ProductoArchivoResponse>();
		
		ProductoArchivoResponse productoResponse = new ProductoArchivoResponse();
		productoResponse.setMontoFmt("12345");
		productoResponse.setIdArchivo(1234);
		productoResponse.setNombreArchivo("archivo");
		productoResponse.setFechaRecep("27/06/2023");
		productoResponse.setEstatus("5");
		productoResponse.setProducto("prod");
		productoResponse.setCanal("234");
		productoResponse.setTotalOperaciones(12);
		productoResponse.setMonto(new BigDecimal("12.3"));
		productoResponse.setIdEstatus(3);
		productoResponse.setMotRechazo("123");
		
		ProductoArchivoResponse productoResponse1 = new ProductoArchivoResponse();
		productoResponse1.setMontoFmt("12345");
		productoResponse1.setIdArchivo(1234);
		productoResponse1.setNombreArchivo("archivo");
		productoResponse1.setFechaRecep("27/06/2023");
		productoResponse1.setEstatus("5");
		productoResponse1.setProducto("TOTAL");
		productoResponse1.setCanal("234");
		productoResponse1.setTotalOperaciones(12);
		productoResponse1.setMonto(new BigDecimal("12.3"));
		productoResponse1.setIdEstatus(3);
		productoResponse1.setMotRechazo("123");
		
		ProductoArchivoResponse productoResponse2 = new ProductoArchivoResponse();
		productoResponse2.setMontoFmt("12345");
		productoResponse2.setIdArchivo(1234);
		productoResponse2.setNombreArchivo("archivo");
		productoResponse2.setFechaRecep("27/06/2023");
		productoResponse2.setEstatus("5");
		productoResponse2.setProducto("TOTAL");
		productoResponse2.setCanal("234");
		productoResponse2.setTotalOperaciones(12);
		productoResponse2.setMonto(new BigDecimal("12.3"));
		productoResponse2.setIdEstatus(3);
		productoResponse2.setMotRechazo("123");
		
		detalle.add(productoResponse);
		detalle.add(productoResponse1);
		detalle.add(productoResponse2);
		
		return detalle;
	}
}
