package mx.santander.h2h.monitoreo.utils;

import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersControllerResponse;
import mx.santander.h2h.monitoreo.model.response.GenerateVouchersDtoResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.repository.IContractConnectionManagementPutGetEntityManagerRepository;
import mx.santander.h2h.monitoreo.repository.IGenerateVouchersEntityManagerRepository;
import mx.santander.h2h.monitoreo.service.IJasperReportService;
import mx.santander.h2h.monitoreo.util.GenerateVouchersImplUtils;
import mx.santander.h2h.monitoreo.util.IGenerateVouchersValidateDateUtils;

@ExtendWith(MockitoExtension.class)
class GenerateVouchersImplUtilsTest {

	@InjectMocks
	GenerateVouchersImplUtils generateVouchersImplUtils;
	
	@Mock
	IContractConnectionManagementPutGetEntityManagerRepository iContractConnectionManagementPutGetEntityManagerRepository;
	
	@Mock
	IGenerateVouchersValidateDateUtils iGenerateVouchersValidateDateUtils;
	
	@Mock
	IGenerateVouchersEntityManagerRepository iGenerateVouchersEntityManagerRepository;
	
	@Mock
	IJasperReportService iJasperReportService;
	
	@Test
	void testfindOperations() {
		List<OperationsMonitorQueryResponse> listaOperaciones = new ArrayList<>();
		OperationsMonitorQueryRequest operationsMonitorQueryRequest = new OperationsMonitorQueryRequest();
		operationsMonitorQueryRequest.setBuc("test");
		operationsMonitorQueryRequest.setBucsSensibles("test");
		OperationsMonitorQueryResponse response = new OperationsMonitorQueryResponse();
		response.setBancoOrdenante("test");
		response.setBancoReceptor("test");
		listaOperaciones.add(response);
		GenerateVouchersControllerResponse findVouchersCdmx = new GenerateVouchersControllerResponse();
		findVouchersCdmx.setFin(1);
		findVouchersCdmx.setInicio(1);
		findVouchersCdmx.setLimiteRegistrosExportar(1);
		findVouchersCdmx.setTotalPaginas(12);
		findVouchersCdmx.setListaOperaciones(listaOperaciones);
		GenerateVouchersDtoResponse generateVouchersDtoResponse = new GenerateVouchersDtoResponse();
		generateVouchersDtoResponse.setCodError("test");
		generateVouchersDtoResponse.setTotalOperaciones("12");
		when(iContractConnectionManagementPutGetEntityManagerRepository.getParameters("NUM_REG_EXPO_MONOP")).thenReturn("12");
		generateVouchersImplUtils.findOperations(operationsMonitorQueryRequest, findVouchersCdmx, generateVouchersDtoResponse);
		Assertions.assertNotNull(response);
	}
	
	@Test
	void testFindOperationsMonitor() {
		OperationsMonitorQueryRequest operationsMonitorQueryRequest = new OperationsMonitorQueryRequest();
		operationsMonitorQueryRequest.setBuc("test");
		operationsMonitorQueryRequest.setBucsSensibles("test");
		operationsMonitorQueryRequest.setContrato("08927648127");
		GenerateVouchersControllerResponse findVouchersCdmx = new GenerateVouchersControllerResponse();
		findVouchersCdmx.setFin(1);
		findVouchersCdmx.setInicio(1);
		findVouchersCdmx.setLimiteRegistrosExportar(1);
		findVouchersCdmx.setTotalOperaciones("12");
		findVouchersCdmx.setListaSize("2");
		findVouchersCdmx.setParametros(null);
		findVouchersCdmx.setTotalPaginas(12);
		List<OperationsMonitorQueryResponse> listaOperaciones = new ArrayList<>();
		OperationsMonitorQueryResponse operationsMonitorQueryResponse = new OperationsMonitorQueryResponse();
		operationsMonitorQueryResponse.setBancoOrdenante("test");
		operationsMonitorQueryResponse.setBancoReceptor("test");
		listaOperaciones.add(operationsMonitorQueryResponse);
		findVouchersCdmx.setListaOperaciones(listaOperaciones);
		GenerateVouchersDtoResponse generateVouchersDtoResponse = new GenerateVouchersDtoResponse();
		generateVouchersDtoResponse.setCodError("test");
		generateVouchersDtoResponse.setTotalOperaciones("12");
		when(iContractConnectionManagementPutGetEntityManagerRepository.getParameters("NUM_REG_EXPO_MONOP")).thenReturn("12");
		when(iGenerateVouchersEntityManagerRepository.findOperationsCount(operationsMonitorQueryRequest)).thenReturn(generateVouchersDtoResponse);
		generateVouchersImplUtils.findOperationsMonitor(operationsMonitorQueryRequest, findVouchersCdmx);
		Assertions.assertNotNull(generateVouchersDtoResponse);
	}
	
	@Test
	void testFindOperationsMonitor2() {
		OperationsMonitorQueryRequest operationsMonitorQueryRequest = new OperationsMonitorQueryRequest();
		operationsMonitorQueryRequest.setBuc("test");
		operationsMonitorQueryRequest.setBucsSensibles("test");
		operationsMonitorQueryRequest.setContrato("08927648127");
		GenerateVouchersControllerResponse findVouchersCdmx = new GenerateVouchersControllerResponse();
		findVouchersCdmx.setFin(1);
		findVouchersCdmx.setInicio(1);
		findVouchersCdmx.setLimiteRegistrosExportar(1);
		findVouchersCdmx.setTotalOperaciones("12");
		findVouchersCdmx.setListaSize("2");
		Map<String,Object> parametros = new HashMap<>();
		parametros.put("MSG","MON_INF01");
		findVouchersCdmx.setParametros(parametros);
		findVouchersCdmx.setTotalPaginas(12);
		List<OperationsMonitorQueryResponse> listaOperaciones = new ArrayList<>();
		OperationsMonitorQueryResponse operationsMonitorQueryResponse = new OperationsMonitorQueryResponse();
		operationsMonitorQueryResponse.setBancoOrdenante("test");
		operationsMonitorQueryResponse.setBancoReceptor("test");
		listaOperaciones.add(operationsMonitorQueryResponse);
		findVouchersCdmx.setListaOperaciones(listaOperaciones);
		GenerateVouchersDtoResponse generateVouchersDtoResponse = new GenerateVouchersDtoResponse();
		generateVouchersDtoResponse.setTotalOperaciones("0");
//		when(iContractConnectionManagementPutGetEntityManagerRepository.getParameters("NUM_REG_EXPO_MONOP")).thenReturn("12");
		when(iGenerateVouchersEntityManagerRepository.findOperationsCount(operationsMonitorQueryRequest)).thenReturn(generateVouchersDtoResponse);
		generateVouchersImplUtils.findOperationsMonitor(operationsMonitorQueryRequest, findVouchersCdmx);
		Assertions.assertNotNull(generateVouchersDtoResponse);
	}
	
	@Test
	void testgetReportePdfOrXlsx() {
		when(iJasperReportService.getPdf(anyString(), anyMap(), anyList())).thenReturn(new ReportResponse());
		ReportResponse result = generateVouchersImplUtils.getReportePdfOrXlsx(".pdf", anyString(), anyMap(), anyList());
		Assertions.assertNotNull(result);
	}
	
	@Test
	public void testGetReportePdfOrXlsxFormatXls() {
		when(iJasperReportService.getXls(anyString(), anyMap(), anyList())).thenReturn(new ReportResponse());
		ReportResponse result = generateVouchersImplUtils.getReportePdfOrXlsx(".xls", anyString(), anyMap(), anyList());
		Assertions.assertNotNull(result);
	}
	
	@Test
	void testgetTypeReport() {
		Map<String, String> p = generateVouchersImplUtils.getTypeReport(".pdf");
		Assertions.assertNotNull(p);
	}
	
	@Test
	void testgetTypeReportX() {
		Map<String, String> p = generateVouchersImplUtils.getTypeReport(".xlsx");
		Assertions.assertNotNull(p);
	}
}
