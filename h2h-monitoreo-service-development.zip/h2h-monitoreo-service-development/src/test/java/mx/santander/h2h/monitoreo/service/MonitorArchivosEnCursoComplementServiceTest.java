package mx.santander.h2h.monitoreo.service;

import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import mx.santander.h2h.monitoreo.model.response.ComboDosResponse;
import mx.santander.h2h.monitoreo.model.response.ComboResponse;
import mx.santander.h2h.monitoreo.model.response.ResultTrackingResponse;
import mx.santander.h2h.monitoreo.repository.IConsultaTrackingProductoRepository;
import mx.santander.h2h.monitoreo.repository.IMonitorArchivosEnCursoNivelOperacionRepository;

class MonitorArchivosEnCursoComplementServiceTest {

	@InjectMocks
	private MonitorArchivosEnCursoComplementService archivosEnCursoComplementService;
	
	@Mock
	private IConsultaTrackingProductoRepository consultaTrackingProductoRepository;
	
	/**
	 * entityManagerOperacion
	 */
	@Mock
	private IMonitorArchivosEnCursoNivelOperacionRepository entityManagerOperacion;
	
	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	void testObtenerCatalogoProductoProd() {
		when(consultaTrackingProductoRepository.obtenerCatalogoProductos()).thenReturn(new ResultTrackingResponse());
		
		List<ComboResponse> result = archivosEnCursoComplementService.obtenerCatalogoProductoProd();
		Assertions.assertNull(result);
	}

	@Test
	void testObtenerCatalogoEstatusProd() {
		when(consultaTrackingProductoRepository.obtenerCatalogoEstatus("R")).thenReturn(new ResultTrackingResponse());
		
		List<ComboResponse> result = archivosEnCursoComplementService.obtenerCatalogoEstatusProd();
		Assertions.assertNull(result);
	}

	@Test
	void testObtenerCatalogoProducto() {
		when(entityManagerOperacion.obtenerCatalogoProductos()).thenReturn(new ResultTrackingResponse());
		
		List<ComboDosResponse> result = archivosEnCursoComplementService.obtenerCatalogoProducto();
		Assertions.assertNull(result);
	}

	@Test
	void testObtenerCatalogoEstatus() {
		when(entityManagerOperacion.obtenerCatalogoEstatus()).thenReturn(new ResultTrackingResponse());
		
		List<ComboResponse> result = archivosEnCursoComplementService.obtenerCatalogoEstatus();
		Assertions.assertNull(result);
	}
}
