package mx.santander.h2h.monitoreo.model.request;

import mx.santander.h2h.monitoreo.util.JavaBeanTester;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;


/**
 * PutGetSaveRequestTest.
 *
 * @author Jesus Soto Aguilar
 * @since 04/05/2023
 */
class PutGetSaveRequestTest {

    @Test
    void testFields() {
        assertDoesNotThrow(() ->
                JavaBeanTester.test(PutGetSaveRequest.class)
        );
    }

    @Test
    void toStringTest() {
        PutGetSaveRequest putGetSaveRequest = new PutGetSaveRequest();
        assertNotNull(putGetSaveRequest.toString());
    }
}