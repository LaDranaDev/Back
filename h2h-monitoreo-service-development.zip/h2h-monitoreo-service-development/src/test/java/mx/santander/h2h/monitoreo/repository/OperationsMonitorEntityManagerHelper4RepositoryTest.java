package mx.santander.h2h.monitoreo.repository;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import mx.santander.h2h.monitoreo.model.entity.ParameterEntity;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;

public class OperationsMonitorEntityManagerHelper4RepositoryTest {

	@Mock
    EntityManager entityManager;
	
	@Mock
	private ParameterEntity paramRepo = mock(ParameterEntity.class);
	
	@Mock
	Logger log;

	@InjectMocks
	OperationsMonitorEntityManagerHelper4Repository repo;
	
	@Mock
	OperationsMonitorEntityManagerRepository repository;
	
	@BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
	
	@Test
	void testIds() {
		Query query = mock(Query.class);
	    when(query.getResultList()).thenReturn(Collections.singletonList("3"));
	    when(entityManager.createNativeQuery(Mockito.anyString())).thenReturn(query);
		when(repository.consultaParametro("H2H_PROD_EXC_COMP")).thenReturn("9,8,6,398,23,1");
		OperationsMonitorQueryRequest request = new OperationsMonitorQueryRequest();
		request.setBuc("test");
		request.setBucsSensibles("test");
		repo.obtenerIdsComprobantes(request);
		Assertions.assertNotNull(request);
	}
	
	@Test
    void testConsultaOperacionesExpor() {
        Tuple tuple = mock(Tuple.class);
        Query query = mock(Query.class);
        when(entityManager.createNativeQuery(any(), (Class<?>) any())).thenReturn(query);
        when(query.getResultList()).thenReturn(Arrays.asList(tuple));
        OperationsMonitorQueryRequest d = new OperationsMonitorQueryRequest();
        d.setBuc("test");
        d.setBucsSensibles("test");
        d.setContrato("test");
        d.setNombreArchivo("test");
        repo.consultaOperExport(d);
        Assertions.assertNotNull(d);
    }
}
