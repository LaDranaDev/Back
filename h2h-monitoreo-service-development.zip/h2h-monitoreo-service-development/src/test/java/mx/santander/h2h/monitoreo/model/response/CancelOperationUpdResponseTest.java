package mx.santander.h2h.monitoreo.model.response;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class CancelOperationUpdResponseTest {

    CancelOperationUpdResponse responseUpd = new CancelOperationUpdResponse();

    @Test
    void setCodError() {
        responseUpd.setCodError("200");
        Assertions.assertEquals("200", responseUpd.getCodError());
    }

    @Test
    void setMsgError() {
        responseUpd.setMsgError("UPDO001");
        Assertions.assertEquals("UPDO001", responseUpd.getMsgError());
    }

    @Test
    void testToString() {
        String result = responseUpd.toString();
        Assertions.assertNotNull(result);
    }
}