package mx.santander.h2h.monitoreo.repository;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.net.MalformedURLException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import mx.isban.h2h.comprobantefiscal.BeanDatosOperMasiva;
import mx.isban.h2h.comprobantefiscal.BeanRespuestaConcepto;
import mx.isban.h2h.comprobantefiscal.BeanRespuestaGeneracion;
import mx.isban.h2h.comprobantefiscal.BeanRespuestaValidacion;
import mx.isban.h2h.comprobantefiscal.ComprobanteSelloDigitalWSFIIImpl;
import mx.isban.h2h.comprobantefiscal.ComprobanteSelloDigitalWSServiceFII;
import mx.isban.h2h.comprobantefiscal.ConsultaInfoConcepto;
import mx.isban.h2h.comprobantefiscal.ConsultaInfoConceptoResponse;
import mx.isban.h2h.comprobantefiscal.GeneraComprobante;
import mx.isban.h2h.comprobantefiscal.GeneraComprobanteResponse;
import mx.isban.h2h.comprobantefiscal.RegistraMovimiento;
import mx.isban.h2h.comprobantefiscal.RegistraMovimientoResponse;
import mx.isban.h2h.comprobantefiscal.Respuesta;
import mx.isban.h2h.comprobantefiscal.ValidaComprobante;
import mx.isban.h2h.comprobantefiscal.ValidaComprobanteResponse;
import mx.santander.h2h.monitoreo.service.ComprobanteSelloDigitalWSServiceFIIService;

class ComprobanteSelloDigitalRepositoryTest {
	@Mock
	private ComprobanteSelloDigitalWSServiceFIIService service;
	@InjectMocks
	private ComprobanteSelloDigitalRepository repository;

	@BeforeEach
	void setUp() {

		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testConsultaInfoConcepto() throws MalformedURLException {
		ComprobanteSelloDigitalWSServiceFII ws = mock(ComprobanteSelloDigitalWSServiceFII.class);
		when(service.getWSComprobanteSelloDigitalWSServiceFII(anyString())).thenReturn(ws);
		ComprobanteSelloDigitalWSFIIImpl implws = mock(ComprobanteSelloDigitalWSFIIImpl.class);
		when(ws.getComprobanteSelloDigitalWSFIIImplPort()).thenReturn(implws);
		when(service.getWSComprobanteSelloDigitalWSServiceFII(anyString()).getComprobanteSelloDigitalWSFIIImplPort()
				.consultaInfoConcepto(null, 0, null)).thenReturn(new BeanRespuestaConcepto());

		ConsultaInfoConceptoResponse result = repository.consultaInfoConcepto(new ConsultaInfoConcepto(), "url");
		Assertions.assertNotNull(result);
	}

	@Test
	void testConsultaInfoConceptoException() {
		try {
			when(service.getWSComprobanteSelloDigitalWSServiceFII(anyString()))
					.thenThrow(new MalformedURLException("error"));

			ConsultaInfoConceptoResponse result = repository.consultaInfoConcepto(new ConsultaInfoConcepto(), "url");
			Assertions.assertNotNull(result);
		} catch (Exception e) {
			Assertions.assertTrue(true);
		}
	}

	@Test
	void testRegistraMovimiento() throws MalformedURLException {
		ComprobanteSelloDigitalWSServiceFII ws = mock(ComprobanteSelloDigitalWSServiceFII.class);
		when(service.getWSComprobanteSelloDigitalWSServiceFII(anyString())).thenReturn(ws);
		ComprobanteSelloDigitalWSFIIImpl implws = mock(ComprobanteSelloDigitalWSFIIImpl.class);
		when(ws.getComprobanteSelloDigitalWSFIIImplPort()).thenReturn(implws);
		RegistraMovimiento request = new RegistraMovimiento();
		request.getMovimientos().add(new BeanDatosOperMasiva());
		when(service.getWSComprobanteSelloDigitalWSServiceFII(anyString()).getComprobanteSelloDigitalWSFIIImplPort()
				.registraMovimiento(request.getMovimientos())).thenReturn(new Respuesta());

		request.getMovimientos().add(new BeanDatosOperMasiva());
		RegistraMovimientoResponse result = repository.registraMovimiento(request, "url");
		Assertions.assertNotNull(result);
	}

	@Test
	void testRegistraMovimientoException() {
		try {
			when(service.getWSComprobanteSelloDigitalWSServiceFII(anyString()))
					.thenThrow(new MalformedURLException("error"));

			RegistraMovimiento request = new RegistraMovimiento();
			request.getMovimientos().add(new BeanDatosOperMasiva());

			RegistraMovimientoResponse result = repository.registraMovimiento(request, "url");
			Assertions.assertNotNull(result);
		} catch (Exception e) {
			Assertions.assertTrue(true);
		}
	}

	@Test
	void testValidaComprobante() throws MalformedURLException {
		ComprobanteSelloDigitalWSServiceFII ws = mock(ComprobanteSelloDigitalWSServiceFII.class);
		when(service.getWSComprobanteSelloDigitalWSServiceFII(anyString())).thenReturn(ws);
		ComprobanteSelloDigitalWSFIIImpl implws = mock(ComprobanteSelloDigitalWSFIIImpl.class);
		when(ws.getComprobanteSelloDigitalWSFIIImplPort()).thenReturn(implws);
		when(service.getWSComprobanteSelloDigitalWSServiceFII(anyString()).getComprobanteSelloDigitalWSFIIImplPort()
				.validaComprobante(null, 0.0, null, null, 0, null)).thenReturn(new BeanRespuestaValidacion());

		ValidaComprobanteResponse result = repository.validaComprobante(new ValidaComprobante(), "url");
		Assertions.assertNotNull(result);
	}

	@Test
	void testValidaComprobanteExeption() {
		try {
			when(service.getWSComprobanteSelloDigitalWSServiceFII(anyString()))
					.thenThrow(new MalformedURLException("error"));

			ValidaComprobanteResponse result = repository.validaComprobante(new ValidaComprobante(), "url");
			Assertions.assertNotNull(result);
		} catch (Exception e) {
			Assertions.assertTrue(true);
		}
	}

	@Test
	void testGeneraComprobante() throws MalformedURLException {
		ComprobanteSelloDigitalWSServiceFII ws = mock(ComprobanteSelloDigitalWSServiceFII.class);
		when(service.getWSComprobanteSelloDigitalWSServiceFII(anyString())).thenReturn(ws);
		ComprobanteSelloDigitalWSFIIImpl implws = mock(ComprobanteSelloDigitalWSFIIImpl.class);
		when(ws.getComprobanteSelloDigitalWSFIIImplPort()).thenReturn(implws);
		when(service.getWSComprobanteSelloDigitalWSServiceFII(anyString()).getComprobanteSelloDigitalWSFIIImplPort()
				.generaComprobante(null, 0.0, null, null, 0, null, null, null, null, null, null, null, null))
				.thenReturn(new BeanRespuestaGeneracion());

		GeneraComprobanteResponse result = repository.generaComprobante(new GeneraComprobante(), "url");
		Assertions.assertNotNull(result);
	}

	@Test
	void testGeneraComprobanteException() {
		try {
			when(service.getWSComprobanteSelloDigitalWSServiceFII(anyString()))
					.thenThrow(new MalformedURLException("error"));

			GeneraComprobanteResponse result = repository.generaComprobante(new GeneraComprobante(), "url");
			Assertions.assertNotNull(result);
		} catch (Exception e) {
			Assertions.assertTrue(true);
		}
	}

}
