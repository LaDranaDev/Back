package mx.santander.h2h.monitoreo.repository;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;


/**
 * Clase generada para OperationsMonitorEntityManagerHelper2RepositoryTest.
 *
 * @autor C320868
 * @modifico C320868
 */
class OperationsMonitorEntityManagerHelper2RepositoryTest {

    /** Declaracion de Logger para log. */
    @Mock
    Logger log;

    /** Declaracion de OperationsMonitorEntityManagerHelper2Repository para operationsMonitorEntityManagerHelper2Repository. */
    @InjectMocks
    OperationsMonitorEntityManagerHelper2Repository operationsMonitorEntityManagerHelper2Repository;

    /** Declaracion de Constante sdf. */
    private static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

    /**
     * Establece el up.
     */
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    /**
     * Test get query count.
     */
    @Test
    void testGetQueryCount() {
    	StringBuilder query = new StringBuilder("SQL EJEMPLO");
		
        OperationsMonitorEntityManagerHelper2Repository.getQueryCount(query.toString());
        Assertions.assertNotNull(query);
    }

    /**
     * Test get views.
     */
    @Test
    void testGetViews() {
        String today = sdf.format(new Date());

        OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();
        consultaOperaciones.setFechaInicial(today);
        consultaOperaciones.setIdProducto("81");
        String query = evalEntityManagerHelper2(consultaOperaciones);
        if( query == null) {
            assertNull(query);
        } else {
            assertNotNull(query);
        }

        consultaOperaciones.setIdProducto("93");
        query = evalEntityManagerHelper2(consultaOperaciones);
        if( query == null) {
            assertNull(query);
        } else {
            assertNotNull(query);
        }

        consultaOperaciones.setIdProducto("01");
        query = evalEntityManagerHelper2(consultaOperaciones);
        if( query == null) {
            assertNull(query);
        } else {
            assertNotNull(query);
        }

        consultaOperaciones.setFechaInicial("02/02/2020");
        consultaOperaciones.setIdProducto("81");
        query = evalEntityManagerHelper2(consultaOperaciones);
        if( query == null) {
            assertNull(query);
        } else {
            assertNotNull(query);
        }
        
        consultaOperaciones.setIdProducto("93");
        query = evalEntityManagerHelper2(consultaOperaciones);
        if( query == null) {
            assertNull(query);
        } else {
            assertNotNull(query);
        }

        consultaOperaciones.setIdProducto("01");
        query = evalEntityManagerHelper2(consultaOperaciones);
        if( query == null) {
            assertNull(query);
        } else {
            assertNotNull(query);
        }
        
        consultaOperaciones.setIdProducto("23");
        query = evalEntityManagerHelper2(consultaOperaciones);
        if( query == null) {
            assertNull(query);
        } else {
            assertNotNull(query);
        }
        
        consultaOperaciones.setIdProducto("31");
        query = evalEntityManagerHelper2(consultaOperaciones);
        if( query == null) {
            assertNull(query);
        } else {
            assertNotNull(query);
        }
        
        consultaOperaciones.setIdProducto("40");
        query = evalEntityManagerHelper2(consultaOperaciones);
        if( query == null) {
            assertNull(query);
        } else {
            assertNotNull(query);
        }
    }

    
    
    /**
     * Test para evaluar Entity Manager.
     *
     * @param consultaOperaciones para consulta operaciones
     * @return el string
     */
    private String evalEntityManagerHelper2(OperationsMonitorQueryRequest consultaOperaciones) {
    	StringBuilder query = new StringBuilder();
		Map<String, Object> params = new HashMap<String, Object>();
		
    	// Obtenemos los datos del MAPA Query y Parametros
    	OperationsMonitorEntityManagerHelper2Repository.getViews(consultaOperaciones, query, params);
        // Obtenemos el Query del Mapa de Datos
        return query.toString();
    }
    
    
    /**
     * Test get consulta exportar.
     */
    @Test
    void testGetConsultaExportar() {
    	Map<String, Object> params = new HashMap<String, Object>();
    	StringBuilder query = new StringBuilder();
		
		
        List<String> views = Arrays.asList("vista1", "vista2");
        // Obtenemos los datos del MAPA Query y Parametros
        OperationsMonitorEntityManagerHelper2Repository.getConsultaExportar(views, new OperationsMonitorQueryRequest(), query, params);
        if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}
    }

    /**
     * Test get arch temp.
     */
    @Test
    void testGetArchTemp() {
    	StringBuilder query = new StringBuilder();
    	Map<String, Object> params = new HashMap<String, Object>();
	
        OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();
        consultaOperaciones.setFechaInicial(sdf.format(new Date()));
        // Obtenemos los datos del MAPA Query y Parametros
        OperationsMonitorEntityManagerHelper2Repository.getArchTemp(consultaOperaciones, query, params);
        if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}

        consultaOperaciones.setFechaInicial("02/02/2020");
        OperationsMonitorEntityManagerHelper2Repository.getArchTemp(consultaOperaciones, query, params);
        if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}
    }

    /**
     * Test get consulta by producto.
     */
    @Test
    void testGetConsultaByProducto() {
    	Map<String, Object> params = new HashMap<String, Object>();
    	StringBuilder query = new StringBuilder();
		
        List<String> cveOperProdList = Arrays.asList(
                "H2H_PROD_TRAN", "H2H_PROD_TRAN_MISM_BANC", "H2H_PROD_NOMI_MISM_BANC", "H2H_PROD_ALTA_PAGO",
                "H2H_PROD_ORDN_PAGO", "H2H_ACTA_BENI", "H2H_PROD_ALTA_EMPL", "H2H_PROD_DOMI", "H2H_PROD_MTTO_PROV",
                "H2H_PROD_PAG_IMP_FED", "H2H_PROD_APO_OBR_PAT", "H2H_PROD_PAG_REF", "H2H_MX_PROD_PECE",
                "H2H_MX_PROD_TRAN_INTN", "H2H_MX_PROD_BANC_CAMB", "H2H_MX_PROD_PAGO_DIR", "H2H_PROD_APO_OBRE_PATR"
        );

        OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();

        for (String cveOperProd : cveOperProdList) {
            // Obtenemos los datos del MAPA Query y Parametros
             OperationsMonitorEntityManagerHelper2Repository.getConsultaByProducto(cveOperProd, consultaOperaciones, query, params);
            if( query == null) {
                assertNull(query);
            } else {
                assertNotNull(query);
            }
            
        }

        query.setLength(0);
        params.clear();
        consultaOperaciones.setIdProducto("11");
        consultaOperaciones.setCveProveedor("cveProveedor");
        // Obtenemos los datos del MAPA Query y Parametros
        OperationsMonitorEntityManagerHelper2Repository.getConsultaByProducto("cveOperProd", consultaOperaciones, query, params);
        if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}

        query.setLength(0);
        params.clear();
        consultaOperaciones.setTipOperacion("tipOperacion");
        OperationsMonitorEntityManagerHelper2Repository.getConsultaByProducto("cveOperProd", consultaOperaciones, query, params);
        if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}
    }

    /**
     * Test get correos env query.
     */
    @Test
    void testGetCorreosEnvQuery() {
        String today = sdf.format(new Date());

        OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();
        consultaOperaciones.setFechaInicial(today);
        consultaOperaciones.setIdProducto("81");
        String query = getCorreoEnvQuery(consultaOperaciones);
        if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}

        consultaOperaciones.setIdProducto("93");
        if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}

        consultaOperaciones.setIdProducto("01");
        query = getCorreoEnvQuery(consultaOperaciones);
        if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}

        consultaOperaciones.setFechaInicial("02/02/2020");
        consultaOperaciones.setIdProducto("81");
        query = getCorreoEnvQuery(consultaOperaciones);
        if( query == null) {
            assertNull(query);
        } else {
            assertNotNull(query);
        }

        consultaOperaciones.setIdProducto("93");
        query = getCorreoEnvQuery(consultaOperaciones);
        if( query == null) {
            assertNull(query);
        } else {
            assertNotNull(query);
        }

        consultaOperaciones.setIdProducto("01");
        query = getCorreoEnvQuery(consultaOperaciones);
        if( query == null) {
            assertNull(query);
        } else {
            assertNotNull(query);
        }
    }

    
    /**
     * Metodo Getter para COrreoEnvQuery.
     *
     * @param consultaOperaciones para consulta operaciones
     * @return COrreoEnvQuery c orreo env query
     */
    private String getCorreoEnvQuery(OperationsMonitorQueryRequest consultaOperaciones) {
    	Map<String, Object> params = new HashMap<String, Object>();
    	StringBuilder query = new StringBuilder();
		
    	// Obtenemos los datos del MAPA Query y Parametros
        OperationsMonitorEntityManagerHelper2Repository.getCorreosEnvQuery(consultaOperaciones, query, params);
        // Obtenemos el Query del Mapa de Datos
        return query.toString();
    }
    
    
    /**
     * Test get count archivos.
     */
    @Test
    void testGetCountArchivos() {
        String today = sdf.format(new Date());

        OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();
        consultaOperaciones.setFechaInicial(today);
        consultaOperaciones.setIdProducto("81");
        String query = getCountArchivo(consultaOperaciones);
        if( query == null) {
            assertNull(query);
        } else {
            assertNotNull(query);
        }
        
        consultaOperaciones.setIdProducto("93");
        query = getCountArchivo(consultaOperaciones);
        if( query == null) {
            assertNull(query);
        } else {
            assertNotNull(query);
        }

        consultaOperaciones.setIdProducto("01");
        query = getCountArchivo(consultaOperaciones);
        if( query == null) {
            assertNull(query);
        } else {
            assertNotNull(query);
        }

        consultaOperaciones.setFechaInicial("02/02/2020");
        consultaOperaciones.setIdProducto("81");
        query = getCountArchivo(consultaOperaciones);
        if( query == null) {
            assertNull(query);
        } else {
            assertNotNull(query);
        }
        
        consultaOperaciones.setIdProducto("93");
        query = getCountArchivo(consultaOperaciones);
        if( query == null) {
            assertNull(query);
        } else {
            assertNotNull(query);
        }

        consultaOperaciones.setIdProducto("01");
        query = getCountArchivo(consultaOperaciones);
        if( query == null) {
            assertNull(query);
        } else {
            assertNotNull(query);
        }
    }
    
    
    /**
     * Metodo Getter para countArchivo.
     *
     * @param consultaOperaciones para consulta operaciones
     * @return countArchivo count archivo
     */
    private String getCountArchivo(OperationsMonitorQueryRequest consultaOperaciones) {
    	Map<String, Object> params = new HashMap<String, Object>();
    	StringBuilder query = new StringBuilder();
		
    	// Obtenemos los datos del MAPA Query y Parametros
        OperationsMonitorEntityManagerHelper2Repository.getCountArchivos(consultaOperaciones, query, params);
        // Obtenemos el Query del Mapa de Datos
        return query.toString();
    }

    /**
     * Test get importe global query.
     */
    @Test
    void testGetImporteGlobalQuery() {
        String today = sdf.format(new Date());

        OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();
        consultaOperaciones.setFechaInicial(today);
        consultaOperaciones.setIdProducto("81");
        String query = getImporteGlobalQuery(consultaOperaciones);
        if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}

        consultaOperaciones.setIdProducto("93");
        query = getImporteGlobalQuery(consultaOperaciones);
        if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}

        consultaOperaciones.setIdProducto("01");
        query = getImporteGlobalQuery(consultaOperaciones);
        if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}

        consultaOperaciones.setFechaInicial("02/02/2020");
        consultaOperaciones.setIdProducto("81");
        query = getImporteGlobalQuery(consultaOperaciones);
        if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}
        
        consultaOperaciones.setIdProducto("93");
        query = getImporteGlobalQuery(consultaOperaciones);
        if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}

        consultaOperaciones.setIdProducto("01");
        query = getImporteGlobalQuery(consultaOperaciones);
        if( query.length() > 0 ) {
			assertTrue( ( query.length() > 0 ) );
		} else {
			assertFalse( ( query.length() > 0 ) );
		}
    }
    
    
    /**
     * Metodo Getter para importeGlobalQuery.
     *
     * @param consultaOperaciones para consulta operaciones
     * @return importeGlobalQuery importe global query
     */
    private String getImporteGlobalQuery(OperationsMonitorQueryRequest consultaOperaciones) {
    	StringBuilder query = new StringBuilder();
    	Map<String, Object> params = new HashMap<String, Object>();
    	
    	// Obtenemos los datos del MAPA Query y Parametros
        OperationsMonitorEntityManagerHelper2Repository.getImporteGlobalQuery(consultaOperaciones, query, params);
        // Obtenemos el Query del Mapa de Datos
        return query.toString();
    }
}
