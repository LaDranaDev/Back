package mx.santander.h2h.monitoreo.model.response;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class PutGetSftpCnDTOTest {

    private PutGetSftpCnDTO putGetSftpCnDTO;

    @BeforeEach
    void setUp() {
        putGetSftpCnDTO = new PutGetSftpCnDTO();
    }

    @Test
    void allArgsContructor() {
        putGetSftpCnDTO = new PutGetSftpCnDTO("profile", "knwoId", "user", "nodo", "nodo","usuario", "usuario",
                "password", "oscurece", "modo", "formato", "longitud", "modo", "parametro", "disposicion");

        assertNotNull(putGetSftpCnDTO);
    }

    @Test
    void getProfileId() {
        putGetSftpCnDTO.setProfileId("profile");
        assertEquals("profile", putGetSftpCnDTO.getProfileId());
    }

    @Test
    void getKnowIdHost() {
        putGetSftpCnDTO.setKnowIdHost("host");
        assertEquals("host", putGetSftpCnDTO.getKnowIdHost());
    }

    @Test
    void getUserIdKey() {
        putGetSftpCnDTO.setUserIdKey("user");
        assertEquals("user", putGetSftpCnDTO.getUserIdKey());
    }

    @Test
    void getNodoLocal() {
        putGetSftpCnDTO.setNodoLocal("nodo");
        assertEquals("nodo", putGetSftpCnDTO.getNodoLocal());
    }

    @Test
    void getNodoRemoto() {
        putGetSftpCnDTO.setNodoRemoto("nodo");
        assertEquals("nodo", putGetSftpCnDTO.getNodoRemoto());
    }

    @Test
    void getUsuarioLocal() {
        putGetSftpCnDTO.setUsuarioLocal("usuario");
        assertEquals("usuario", putGetSftpCnDTO.getUsuarioLocal());
    }

    @Test
    void getUsuarioRemoto() {
        putGetSftpCnDTO.setUsuarioRemoto("usuario");
        assertEquals("usuario", putGetSftpCnDTO.getUsuarioRemoto());
    }

    @Test
    void getPasswordRemoto() {
        putGetSftpCnDTO.setPasswordRemoto("password");
        assertEquals("password", putGetSftpCnDTO.getPasswordRemoto());
    }

    @Test
    void getOscurecerPwd() {
        putGetSftpCnDTO.setOscurecerPwd("T");
        assertEquals("T", putGetSftpCnDTO.getOscurecerPwd());
    }

    @Test
    void getModoBinario() {
        putGetSftpCnDTO.setModoBinario("T");
        assertEquals("T", putGetSftpCnDTO.getModoBinario());
    }

    @Test
    void getFormatoRegistro() {
        putGetSftpCnDTO.setFormatoRegistro("formato");
        assertEquals("formato", putGetSftpCnDTO.getFormatoRegistro());
    }

    @Test
    void getLongitudRegistro() {
        putGetSftpCnDTO.setLongitudRegistro("longitud");
        assertEquals("longitud", putGetSftpCnDTO.getLongitudRegistro());
    }

    @Test
    void getModoDisp() {
        putGetSftpCnDTO.setModoDisp("T");
        assertEquals("T", putGetSftpCnDTO.getModoDisp());
    }

    @Test
    void getParametroSysOpts() {
        putGetSftpCnDTO.setParametroSysOpts("parametro");
        assertEquals("parametro", putGetSftpCnDTO.getParametroSysOpts());
    }

    @Test
    void getDisposicionRegistro() {
        putGetSftpCnDTO.setDisposicionRegistro("disposicion");
        assertEquals("disposicion", putGetSftpCnDTO.getDisposicionRegistro());
    }

    @Test
    void toStringTest() {
        assertNotNull(putGetSftpCnDTO.toString());
    }
}