package mx.santander.h2h.monitoreo.util;

import java.util.Arrays;
import java.util.Collections;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class UtilOrdenesPagoAtmComprobanteTest {

    @Test
    void testObtenerQuerys() {
        String result = UtilOrdenesPagoAtmComprobante.obtenerQuerys(Collections.emptyList(), "tabla", "sqlstr");
        Assertions.assertEquals("sqlstr", result);

        result = UtilOrdenesPagoAtmComprobante.obtenerQuerys(Arrays.asList(1, 2), "H2H_MX_PROD_ORDN_PAGO_ATM", "sqlstr");
        Assertions.assertNotNull(result);
    }

    @Test
    void testEsOpAtm() {
        boolean result = UtilOrdenesPagoAtmComprobante.esOpAtm("-85-");
        Assertions.assertEquals(true, result);
    }

}
