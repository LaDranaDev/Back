package mx.santander.h2h.monitoreo.model.request;

import mx.santander.h2h.monitoreo.util.JavaBeanTester;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OperationsMonitorQueryRequestTest {

    @Test
    void testFields() {
        assertDoesNotThrow(() ->
                JavaBeanTester.test(OperationsMonitorQueryRequest.class)
        );
    }

    @Test
    void testToString() {
        OperationsMonitorQueryRequest request = new OperationsMonitorQueryRequest();
        assertNotNull(request.toString());
    }
}