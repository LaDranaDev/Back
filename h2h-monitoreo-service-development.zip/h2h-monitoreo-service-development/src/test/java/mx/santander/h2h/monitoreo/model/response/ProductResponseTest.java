package mx.santander.h2h.monitoreo.model.response;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class ProductResponseTest {

    private ProductResponse productResponse;

    @BeforeEach
    void setUp(){
        productResponse = new ProductResponse();
    }

    @Test
    void getIdProducto() {
        productResponse.setIdProducto(1L);
        assertEquals(1L, productResponse.getIdProducto());
    }

    @Test
    void getClaveProducto() {
        productResponse.setClaveProducto("clave");
        assertEquals("clave", productResponse.getClaveProducto());
    }

    @Test
    void getDescProducto() {
        productResponse.setDescProducto("descripcion");
        assertEquals("descripcion", productResponse.getDescProducto());
    }

    @Test
    void builder() {
        productResponse = ProductResponse.builder().build();
        assertNotNull(productResponse);
    }

    @Test
    void toStringTest(){
        String response = ProductResponse.builder().toString();
        assertNotNull(response);
    }
}