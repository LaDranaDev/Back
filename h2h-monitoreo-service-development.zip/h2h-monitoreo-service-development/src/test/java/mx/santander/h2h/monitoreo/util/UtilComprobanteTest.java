package mx.santander.h2h.monitoreo.util;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

class UtilComprobanteTest {

    @Test
    void testObtenerQueryTabla() {
        List<String> tables = Arrays.asList(
                "H2H_PROD_ALTA_PAGO", "H2H_PROD_TRAN", "H2H_PROD_NOMI_MISM_BANC", "H2H_PROD_ORDN_PAGO",
                "H2H_PROD_TRAN_MISM_BANC", "H2H_PROD_IMPU_FEDE", "H2H_PROD_PAGO_REFE", "H2H_MX_PROD_TRAN_INTN",
                "H2H_MX_PROD_BANC_CAMB", "H2H_PROD_APO_OBRE_PATR", "H2H_MX_PROD_PECE", "H2H_MX_PROD_SPID",
                "H2H_MX_PROD_PAGO_TDC", "H2H_MX_PROD_PAGO_DIR"
        );

        for (String table : tables) {
            String result = UtilComprobante.obtenerQueryTabla(Collections.emptyList(), table);
            Assertions.assertNotNull(result);
        }
    }

    @Test
    void testAgregaIdReg() {
        StringBuilder sql = new StringBuilder();
        UtilComprobante.agregaIdReg(Arrays.asList(1, 2), sql);
        Assertions.assertEquals(" WHERE ( r.id_reg = 1 OR r.id_reg = 2 ) ", sql.toString());
    }
}
