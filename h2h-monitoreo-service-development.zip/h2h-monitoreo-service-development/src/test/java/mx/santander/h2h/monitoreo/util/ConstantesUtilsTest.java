package mx.santander.h2h.monitoreo.util;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

class ConstantesUtilsTest {

    @Test
    void testConsultaProductos() {
        for (int cveOperProd : Arrays.asList(1, 2, 42)) {
            String result = ConstantesUtils.consultaProductos(cveOperProd);
            Assertions.assertNotNull(result);
        }
    }

    @Test
    void testConsultaProductos9848() {
        for (int cveOperProd : Arrays.asList(98, 48, 36, 99, 49, 1)) {
            String result = ConstantesUtils.consultaProductos9848(cveOperProd);
            Assertions.assertNotNull(result);
        }
    }

    @Test
    void testConsultaProductos9949() {
        for (int cveOperProd : Arrays.asList(1, 91)) {
            String result = ConstantesUtils.consultaProductos9949(cveOperProd);
            Assertions.assertNotNull(result);
        }
    }

    @Test
    void testTipoPago() {
        for (String tipoPago : Arrays.asList("", "E", "C", "A")) {
            String result = ConstantesUtils.tipoPago(tipoPago);
            Assertions.assertNotNull(result);
        }
    }

    @Test
    void testDivisaOrdenante() {
        String result = ConstantesUtils.divisaOrdenante("MN");
        Assertions.assertEquals("MXP", result);

        result = ConstantesUtils.divisaOrdenante("MXP");
        Assertions.assertEquals("MXP", result);
    }
}
