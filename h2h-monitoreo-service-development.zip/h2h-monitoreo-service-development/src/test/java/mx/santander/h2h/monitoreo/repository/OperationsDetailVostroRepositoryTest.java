package mx.santander.h2h.monitoreo.repository;

import mx.santander.h2h.monitoreo.model.entity.ParameterEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.RETURNS_MOCKS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * OperationsDetailVostroRepositoryTest.
 *
 * @author Jesus Soto Aguilar
 */
@ExtendWith(MockitoExtension.class)
class OperationsDetailVostroRepositoryTest {

    @Mock
    private EntityManager entityManager;

    @Mock
    private IParameterRepository parameterRepository;

    @InjectMocks
    private OperationsDetailVostroRepository operationsDetailVostroRepository;

    @Test
    void obtenerDetalleOperacionEmptyData() {
        Query query = mock(Query.class, RETURNS_MOCKS);
        ParameterEntity parameterEntity = mock(ParameterEntity.class);

        when(entityManager.createNativeQuery(anyString(), eq(Tuple.class)))
                .thenReturn(query);
        when(query.getResultList()).thenReturn(Collections.emptyList());
        when(parameterRepository.findByName(anyString())).thenReturn(parameterEntity);
        when(parameterEntity.getValue()).thenReturn("CVE_PROD_TRANINTCAMB");

        assertDoesNotThrow(() -> operationsDetailVostroRepository.obtenerDetalleOperacion("CVE_PROD_TRANINTCAMB", "1"));
    }

    @Test
    void obtenerDetalleOperacion_CVE_PROD_TRANINTCAMB() {
        Query query = mock(Query.class, RETURNS_MOCKS);
        Tuple data = mock(Tuple.class, RETURNS_DEEP_STUBS);
        ParameterEntity parameterEntity = mock(ParameterEntity.class);

        when(entityManager.createNativeQuery(anyString(), eq(Tuple.class)))
                .thenReturn(query);
        when(query.getResultList()).thenReturn(Arrays.asList(data));
        when(parameterRepository.findByName(anyString())).thenReturn(new ParameterEntity());
        when(parameterRepository.findByName("CVE_PROD_TRANINTCAMB")).thenReturn(parameterEntity);
        when(parameterEntity.getValue()).thenReturn("CVE_PROD_TRANINTCAMB");

        assertDoesNotThrow(() -> operationsDetailVostroRepository.obtenerDetalleOperacion("CVE_PROD_TRANINTCAMB", "1"));
    }

    @Test
    void obtenerDetalleOperacion_CVE_PROD_VOSTRO_INT() {
        Query query = mock(Query.class, RETURNS_MOCKS);
        Tuple data = mock(Tuple.class, RETURNS_DEEP_STUBS);
        ParameterEntity parameterEntity = mock(ParameterEntity.class);

        when(entityManager.createNativeQuery(anyString(), eq(Tuple.class)))
                .thenReturn(query);
        when(query.getResultList()).thenReturn(Arrays.asList(data));
        when(parameterRepository.findByName(anyString())).thenReturn(new ParameterEntity());
        when(parameterRepository.findByName("CVE_PROD_VOSTRO_INT")).thenReturn(parameterEntity);
        when(parameterEntity.getValue()).thenReturn("CVE_PROD_VOSTRO_INT");

        assertDoesNotThrow(() -> operationsDetailVostroRepository.obtenerDetalleOperacion("CVE_PROD_VOSTRO_INT", "1"));
    }

    @Test
    void obtenerDetalleOperacion_CVE_PROD_VOSTRO_MB() {
        Query query = mock(Query.class, RETURNS_MOCKS);
        Tuple data = mock(Tuple.class, RETURNS_DEEP_STUBS);
        ParameterEntity parameterEntity = mock(ParameterEntity.class);

        when(entityManager.createNativeQuery(anyString(), eq(Tuple.class)))
                .thenReturn(query);
        when(query.getResultList()).thenReturn(Arrays.asList(data));
        when(parameterRepository.findByName(anyString())).thenReturn(new ParameterEntity());
        when(parameterRepository.findByName("CVE_PROD_VOSTRO_MB")).thenReturn(parameterEntity);
        when(parameterEntity.getValue()).thenReturn("CVE_PROD_VOSTRO_MB");

        assertDoesNotThrow(() -> operationsDetailVostroRepository.obtenerDetalleOperacion("CVE_PROD_VOSTRO_MB", "1"));
    }


}