package mx.santander.h2h.monitoreo.model.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

import mx.santander.h2h.monitoreo.model.entity.ProductEntity;
import mx.santander.h2h.monitoreo.model.response.ProductResponse;

class ProductModelMappingTest {

    @Test
    void mappingEntityListToDtoList() {
        List<ProductEntity> dataProductos = Arrays.asList(getProductEntity());
        List<ProductResponse> productResponses =
                ProductModelMapping.mappingEntityListToDtoList(dataProductos);

        assertNotNull(productResponses);
        assertEquals(1, productResponses.size());
    }

    @Test
    void mappingEntityToDto() {
        ProductResponse response =
                ProductModelMapping.mappingEntityToDto(getProductEntity());

        assertNotNull(response);
    }

    @Test
    void mappingEntityToDtoNull() {
        ProductResponse response =
                ProductModelMapping.mappingEntityToDto(null);

        assertNull(response);
    }

    private ProductEntity getProductEntity(){
        ProductEntity entity = new ProductEntity();
        entity.setId(1234L);
        entity.setCveProdOper("98");
        entity.setDescripcion("TBM");

        return entity;
    }
}