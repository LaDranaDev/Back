package mx.santander.h2h.monitoreo.model.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
class SaldosReintentosEntityTest {

    private SaldosReintentosEntity saldosReintentosEntity;

    @BeforeEach
    void setUp(){
        saldosReintentosEntity = new SaldosReintentosEntity();
    }

    @Test
    void getIdSaldosReintentos() {
        saldosReintentosEntity.setIdSaldosReintentos(1L);
        assertEquals(1L, saldosReintentosEntity.getIdSaldosReintentos());
    }

    @Test
    void getNumCtaOrdenante() {
        saldosReintentosEntity.setNumCtaOrdenante("1234");
        assertEquals("1234", saldosReintentosEntity.getNumCtaOrdenante());
    }

    @Test
    void getSaldo() {
        saldosReintentosEntity.setSaldo(BigDecimal.ZERO);
        assertEquals(BigDecimal.ZERO, saldosReintentosEntity.getSaldo());
    }

    @Test
    void getFechaConsulta() {
        LocalDate fecha = LocalDate.parse("2023-04-19");
        saldosReintentosEntity.setFechaConsulta(fecha);
        assertEquals(fecha, saldosReintentosEntity.getFechaConsulta());
    }

    @Test
    void getArchivoEntity() {
        ArchivoEntity archivoEntity = mock(ArchivoEntity.class);
        saldosReintentosEntity.setArchivoEntity(archivoEntity);
        assertEquals(archivoEntity, saldosReintentosEntity.getArchivoEntity());
    }

    @Test
    void getMontoRequerido() {
        saldosReintentosEntity.setMontoRequerido(BigDecimal.ZERO);
        assertEquals(BigDecimal.ZERO, saldosReintentosEntity.getMontoRequerido());
    }

    @Test
    void getLineaCredito() {
        saldosReintentosEntity.setLineaCredito('T');
        assertEquals('T', saldosReintentosEntity.getLineaCredito());
    }

    @Test
    void getClaveProducto() {
        saldosReintentosEntity.setClaveProducto("cveProd");
        assertEquals("cveProd", saldosReintentosEntity.getClaveProducto());
    }
}