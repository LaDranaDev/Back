package mx.santander.h2h.monitoreo.model.entity;

import mx.santander.h2h.monitoreo.model.request.MessageDataBaseRequest;
import mx.santander.h2h.monitoreo.util.JavaBeanTester;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.beans.IntrospectionException;

class ParameterEntityTest {

    @Test
    void testBean() throws IntrospectionException {
        JavaBeanTester.test(ParameterEntity.class);
        ParameterEntity entity = new ParameterEntity();
        entity.toString();
    }
    
    @Test
    void testMessageDataBaseRequest() {
    	MessageDataBaseRequest d = new MessageDataBaseRequest();
    	d.setCodeOperation("test");
    	d.setQuery("select * from ");
    	d.setTypeOperation(".xls");
    	d.getCodeOperation();
    	d.getQuery();
    	d.getTypeOperation();
    	Assertions.assertNotNull(d);
    }

}
