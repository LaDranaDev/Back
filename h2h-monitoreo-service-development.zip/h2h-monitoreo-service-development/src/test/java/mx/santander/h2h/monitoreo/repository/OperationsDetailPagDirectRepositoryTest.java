package mx.santander.h2h.monitoreo.repository;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.RETURNS_MOCKS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * OperationsDetailPagDirectRepositoryTest.
 *
 * @author Jesus Soto Aguilar
 */
@ExtendWith(MockitoExtension.class)
class OperationsDetailPagDirectRepositoryTest {

    @Mock
    private EntityManager entityManager;

    @InjectMocks
    private OperationsDetailPagDirectRepository operationsDetailPagDirectRepository;

    @Test
    void obtenerDetalleOperacionNotView() {
        Query query = mock(Query.class, RETURNS_MOCKS);

        when(entityManager.createNativeQuery(anyString(), eq(Tuple.class)))
                .thenReturn(query);
        when(query.getResultList()).thenReturn(Collections.emptyList());

        assertDoesNotThrow(() -> operationsDetailPagDirectRepository.obtenerDetalleOperacion("00", "1"));
    }

    @Test
    void obtenerDetalleOperacionEmtyData() {
        Query query = mock(Query.class, RETURNS_MOCKS);

        when(entityManager.createNativeQuery(anyString(), eq(Tuple.class)))
                .thenReturn(query);
        when(query.getResultList()).thenReturn(Collections.emptyList());

        assertDoesNotThrow(() -> operationsDetailPagDirectRepository.obtenerDetalleOperacion("01", "1"));
    }

    @Test
    void obtenerDetalleOperacion() {
        Query query = mock(Query.class, RETURNS_MOCKS);
        Tuple data = mock(Tuple.class, RETURNS_DEEP_STUBS);

        when(entityManager.createNativeQuery(anyString(), eq(Tuple.class)))
                .thenReturn(query);
        when(query.getResultList()).thenReturn(Arrays.asList(data));

        assertDoesNotThrow(() -> operationsDetailPagDirectRepository.obtenerDetalleOperacion("01", "1"));
    }
}