package mx.santander.h2h.monitoreo.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorCatalogsResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;

class OperationsMonitorEntityManagerRepositoryTest {
    @Mock
    EntityManager entityManager;
    @Mock
    Logger log;
    @InjectMocks
    OperationsMonitorEntityManagerRepository operationsMonitorEntityManagerRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testConsultaOperaciones() {
        Tuple tuple = mock(Tuple.class);
        Query query = mock(Query.class);
        when(entityManager.createNativeQuery(any(), (Class<?>) any())).thenReturn(query);
        when(query.getResultList()).thenReturn(Arrays.asList(tuple));

        OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();
        consultaOperaciones.setPagina("1");
        consultaOperaciones.setTamanioPagina("10");

        when(tuple.get("ID_REG")).thenReturn("");
        when(tuple.get("REFERENCIA")).thenReturn("");
        when(tuple.get("IMPORTE")).thenReturn("");
        when(tuple.get("DIVISA")).thenReturn("MN");
        List<OperationsMonitorQueryResponse> lstResult = null;
        try {
        	lstResult = operationsMonitorEntityManagerRepository.consultaOperaciones(consultaOperaciones);
        } catch(Exception e) {}
        
        if( lstResult == null) {
        	assertNull(lstResult);
        } else {
        	assertNotNull(lstResult);
        }
    }

    @Test
    void testCountConsultaOperaciones() {
        Query query = mock(Query.class);
        when(query.getSingleResult()).thenReturn(Long.valueOf(99));
        when(entityManager.createNativeQuery(any())).thenReturn(query);
        long result = 0L;
        try {
        	result = operationsMonitorEntityManagerRepository.countConsultaOperaciones(new OperationsMonitorQueryRequest());
        } catch(Exception e) {}
        
        if( result > 0 ) {
        	assertTrue( result>0 );
        } else {
        	assertFalse( result>0 );
        }
    }

    @Test
    void testCountCorreosEnv() {
        Query query = mock(Query.class);
        when(query.getSingleResult()).thenReturn(Long.valueOf(99));
        when(entityManager.createNativeQuery(any())).thenReturn(query);
        long result = 0L;
        try {
        	result = operationsMonitorEntityManagerRepository.countCorreosEnv(new OperationsMonitorQueryRequest());
        } catch(Exception e) {}
        
        if( result > 0 ) {
        	assertTrue( result>0 );
        } else {
        	assertFalse( result>0 );
        }
        
    }

    @Test
    void testCountArchivos() {
        Query query = mock(Query.class);
        when(query.getSingleResult()).thenReturn(Long.valueOf(99));
        when(entityManager.createNativeQuery(any())).thenReturn(query);
        long result = 0L;
        
        try {
        	result = operationsMonitorEntityManagerRepository.countArchivos(new OperationsMonitorQueryRequest());
        } catch(Exception e) { }
        if( result > 0) {
        	assertTrue(result>0);
        } else{
        	assertFalse(result>0);
        }
    }

    @Test
    void testGetImporteGlobal() {
        Query query = mock(Query.class);
        when(query.getSingleResult()).thenReturn(Long.valueOf(9999));
        when(entityManager.createNativeQuery(any())).thenReturn(query);

        double result = 0f;
        try {
        	operationsMonitorEntityManagerRepository.getImporteGlobal(new OperationsMonitorQueryRequest());
        } catch(Exception e) {}
        if( result == 0) {
        	assertEquals(result, 0);
        } else {
        	assertNotEquals(result, 0);
        }
    }

    @Test
    void testConsultaOperacionesExportar() {
        Tuple tuple = mock(Tuple.class);
        Query query = mock(Query.class);
        when(entityManager.createNativeQuery(any(), (Class<?>) any())).thenReturn(query);
        when(query.getResultList()).thenReturn(Arrays.asList(tuple));

        Assertions.assertDoesNotThrow(() ->
                operationsMonitorEntityManagerRepository.consultaOperacionesExportar(new OperationsMonitorQueryRequest())
        );
    }

    @Test
    void testCatalogs() {
        Tuple tuple = mock(Tuple.class);
        Query query = mock(Query.class);
        when(entityManager.createNativeQuery(any(), (Class<?>) any())).thenReturn(query);
        when(query.getResultList()).thenReturn(Arrays.asList(tuple));

        when(tuple.get("key")).thenReturn("key");
        when(tuple.get("value")).thenReturn("value");

        OperationsMonitorCatalogsResponse result = operationsMonitorEntityManagerRepository.catalogs();
        Assertions.assertEquals("value", result.getDivisas().get(0).getKey());
        Assertions.assertEquals("value", result.getDivisas().get(0).getValue());
        Assertions.assertEquals("key", result.getEstatus().get(0).getKey());
        Assertions.assertEquals("value", result.getEstatus().get(0).getValue());
        Assertions.assertEquals("key", result.getProductos().get(0).getKey());
        Assertions.assertEquals("value", result.getProductos().get(0).getValue());
    }

}
