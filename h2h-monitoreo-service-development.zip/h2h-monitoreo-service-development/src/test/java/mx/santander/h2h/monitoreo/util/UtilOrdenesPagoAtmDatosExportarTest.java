package mx.santander.h2h.monitoreo.util;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;

class UtilOrdenesPagoAtmDatosExportarTest {

    @Test
    void testEsOrdenPago() {
        boolean result = UtilOrdenesPagoAtmDatosExportar.esOrdenPago("");
        Assertions.assertEquals(false, result);

        result = UtilOrdenesPagoAtmDatosExportar.esOrdenPago("85");
        Assertions.assertEquals(true, result);
    }

    @Test
    void testGetQuerySelectExportar() {
        StringBuilder query = new StringBuilder();
        query.append(UtilOrdenesPagoAtmDatosExportar.getQuerySelectExportar("85", new StringBuilder()));
        Assertions.assertNotNull(query.toString());
    }
    
    @Test
    void testGeneraQueryProductosOrdenPagoatm() {
    	String result = UtilOrdenesPagoAtmDatosExportar.generaQueryProductosOrdenPagoatm(true, new OperationsMonitorQueryRequest());
    	Assertions.assertNotNull(result);
    }
    
    @Test
    void testGeneraQueryProductosOrdenPagoatm1() {
    	String result = UtilOrdenesPagoAtmDatosExportar.generaQueryProductosOrdenPagoatm(false, new OperationsMonitorQueryRequest());
    	Assertions.assertNotNull(result);
    }

}
