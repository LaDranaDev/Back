package mx.santander.h2h.monitoreo.model.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
class ArchivoTranEntityTest {

    private ArchivoTranEntity archivoTranEntity;

    @BeforeEach
    void setUp(){
        archivoTranEntity = new ArchivoTranEntity();
    }

    @Test
    void getIdArchivo() {
        archivoTranEntity.setIdArchivo(123L);
        assertEquals(123L, archivoTranEntity.getIdArchivo());
    }

    @Test
    void getNombreArchivo() {
        archivoTranEntity.setNombreArchivo("nombreArchivo");
        assertEquals("nombreArchivo", archivoTranEntity.getNombreArchivo());
    }

    @Test
    void getIdLayout() {
        archivoTranEntity.setIdLayout(123L);
        assertEquals(123L, archivoTranEntity.getIdLayout());
    }

    @Test
    void getIdStatus() {
        archivoTranEntity.setIdStatus(123L);
        assertEquals(123L, archivoTranEntity.getIdStatus());
    }

    @Test
    void getContractEntity() {
        ContractEntity contractEntity = mock(ContractEntity.class);
        archivoTranEntity.setContractEntity(contractEntity);
        assertEquals(contractEntity, archivoTranEntity.getContractEntity());
    }

    @Test
    void getTamano() {
        archivoTranEntity.setTamano(123L);
        assertEquals(123L, archivoTranEntity.getTamano());
    }

    @Test
    void getBandEnrollment() {
        archivoTranEntity.setBandEnrollment('A');
        assertEquals('A', archivoTranEntity.getBandEnrollment());
    }

    @Test
    void getFechaRegistro() {
        LocalDate date = LocalDate.parse("2023-04-19");
        archivoTranEntity.setFechaRegistro(date);
        assertEquals(date, archivoTranEntity.getFechaRegistro());
    }

    @Test
    void getTotoalProductos() {
        archivoTranEntity.setTotoalProductos(123);
        assertEquals(123, archivoTranEntity.getTotoalProductos());
    }

    @Test
    void getBandFondeo() {
        archivoTranEntity.setBandFondeo('T');
        assertEquals('T', archivoTranEntity.getBandFondeo());
    }

    @Test
    void getIdCanal() {
        archivoTranEntity.setIdCanal(123);
        assertEquals(123, archivoTranEntity.getIdCanal());
    }

    @Test
    void getIdCatProcesamiento() {
        archivoTranEntity.setIdCatProcesamiento(123L);
        assertEquals(123L, archivoTranEntity.getIdCatProcesamiento());
    }

    @Test
    void getIdProcesoRegistro() {
        archivoTranEntity.setIdProcesoRegistro(123L);
        assertEquals(123L, archivoTranEntity.getIdProcesoRegistro());
    }

    @Test
    void getBandCierre() {
        archivoTranEntity.setBandCierre('A');
        assertEquals('A', archivoTranEntity.getBandCierre());
    }

    @Test
    void getBandCifrado() {
        archivoTranEntity.setBandCifrado('A');
        assertEquals('A', archivoTranEntity.getBandCifrado());
    }

    @Test
    void getTotalOperaciones() {
        archivoTranEntity.setTotalOperaciones(123);
        assertEquals(123, archivoTranEntity.getTotalOperaciones());
    }

    @Test
    void getTotalMonto() {
        archivoTranEntity.setTotalMonto(BigDecimal.ZERO);
        assertEquals(BigDecimal.ZERO, archivoTranEntity.getTotalMonto());
    }

    @Test
    void getMbxMsgId() {
        archivoTranEntity.setMbxMsgId(123);
        assertEquals(123, archivoTranEntity.getMbxMsgId());
    }

    @Test
    void getNotMsgId() {
        archivoTranEntity.setNotMsgId(123);
        assertEquals(123, archivoTranEntity.getNotMsgId());
    }

    @Test
    void getBandDispWeb() {
        archivoTranEntity.setBandDispWeb('N');
        assertEquals('N', archivoTranEntity.getBandDispWeb());
    }

    @Test
    void getIdMensaje() {
        archivoTranEntity.setIdMensaje(123);
        assertEquals(123, archivoTranEntity.getIdMensaje());
    }

    @Test
    void getBandDispWebClte() {
        archivoTranEntity.setBandDispWebClte('N');
        assertEquals('N', archivoTranEntity.getBandDispWebClte());
    }

    @Test
    void getDivisa() {
        archivoTranEntity.setDivisa('T');
        assertEquals('T', archivoTranEntity.getDivisa());
    }

    @Test
    void getNumSerieCert() {
        archivoTranEntity.setNumSerieCert("1234");
        assertEquals("1234", archivoTranEntity.getNumSerieCert());
    }

    @Test
    void getHashCifrado() {
        archivoTranEntity.setHashCifrado("hashArchivo");
        assertEquals("hashArchivo", archivoTranEntity.getHashCifrado());
    }

    @Test
    void getHashArchivo() {
        archivoTranEntity.setHashArchivo("hashArchivo");
        assertEquals("hashArchivo", archivoTranEntity.getHashArchivo());
    }

    @Test
    void getMbxMsgIdCifr() {
        archivoTranEntity.setMbxMsgIdCifr(123);
        assertEquals(123, archivoTranEntity.getMbxMsgIdCifr());
    }

    @Test
    void getMotivoRechDupl() {
        archivoTranEntity.setMotivoRechDupl("motivo");
        assertEquals("motivo", archivoTranEntity.getMotivoRechDupl());
    }

    @Test
    void getIdArchDupl() {
        archivoTranEntity.setIdArchDupl(123);
        assertEquals(123, archivoTranEntity.getIdArchDupl());
    }

    @Test
    void getEncodingArchivo() {
        archivoTranEntity.setEncodingArchivo("UTF-8");
        assertEquals("UTF-8", archivoTranEntity.getEncodingArchivo());
    }

}