package mx.santander.h2h.monitoreo.model.response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.math.BigDecimal;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class OperationsMonitorQueryResponseTest {

    private OperationsMonitorQueryResponse operationsMonitorQueryResponse;

    @BeforeEach
    void setUp() {
        operationsMonitorQueryResponse = new OperationsMonitorQueryResponse();
    }

    @Test
    void getIdOperacion() {
        operationsMonitorQueryResponse.setIdOperacion("idOperacion");
        assertEquals("idOperacion", operationsMonitorQueryResponse.getIdOperacion());
    }

    @Test
    void getCodCli() {
        operationsMonitorQueryResponse.setCodCli("codigo");
        assertEquals("codigo", operationsMonitorQueryResponse.getCodCli());
    }

    @Test
    void getCtaCargo() {
        operationsMonitorQueryResponse.setCtaCargo("cuenta");
        assertEquals("cuenta", operationsMonitorQueryResponse.getCtaCargo());
    }

    @Test
    void getCtaAbono() {
        operationsMonitorQueryResponse.setCtaAbono("cuenta");
        assertEquals("cuenta", operationsMonitorQueryResponse.getCtaAbono());
    }

    @Test
    void getNumOrden() {
        operationsMonitorQueryResponse.setNumOrden("orden");
        assertEquals("orden", operationsMonitorQueryResponse.getNumOrden());
    }

    @Test
    void getProducto() {
        operationsMonitorQueryResponse.setProducto("producto");
        assertEquals("producto", operationsMonitorQueryResponse.getProducto());
    }

    @Test
    void getNomArch() {
        operationsMonitorQueryResponse.setNomArch("nomArch");
        assertEquals("nomArch", operationsMonitorQueryResponse.getNomArch());
    }

    @Test
    void getFechaCaptura() {
        operationsMonitorQueryResponse.setFechaCaptura("fecha");
        assertEquals("fecha", operationsMonitorQueryResponse.getFechaCaptura());
    }

    @Test
    void getIntermOrd() {
        operationsMonitorQueryResponse.setIntermOrd("inter");
        assertEquals("inter", operationsMonitorQueryResponse.getIntermOrd());
    }

    @Test
    void getImporteCargo() {
        operationsMonitorQueryResponse.setImporteCargo("importe");
        assertEquals("importe", operationsMonitorQueryResponse.getImporteCargo());
    }

    @Test
    void getIntermRec() {
        operationsMonitorQueryResponse.setIntermRec("inter");
        assertEquals("inter", operationsMonitorQueryResponse.getIntermRec());
    }

    @Test
    void getNombreBenef() {
        operationsMonitorQueryResponse.setNombreBenef("beneficiario");
        assertEquals("beneficiario", operationsMonitorQueryResponse.getNombreBenef());
    }

    @Test
    void getComentario1() {
        operationsMonitorQueryResponse.setComentario1("comentario");
        assertEquals("comentario", operationsMonitorQueryResponse.getComentario1());
    }

    @Test
    void getComentario2() {
        operationsMonitorQueryResponse.setComentario2("comentario");
        assertEquals("comentario", operationsMonitorQueryResponse.getComentario2());
    }

    @Test
    void getComentario3() {
        operationsMonitorQueryResponse.setComentario3("comentario");
        assertEquals("comentario", operationsMonitorQueryResponse.getComentario3());
    }

    @Test
    void getEstatus() {
        operationsMonitorQueryResponse.setEstatus("estatus");
        assertEquals("estatus", operationsMonitorQueryResponse.getEstatus());
    }

    @Test
    void getFechaPresIni() {
        operationsMonitorQueryResponse.setFechaPresIni("fecha");
        assertEquals("fecha", operationsMonitorQueryResponse.getFechaPresIni());
    }

    @Test
    void getFechaAplic() {
        operationsMonitorQueryResponse.setFechaAplic("fecha");
        assertEquals("fecha", operationsMonitorQueryResponse.getFechaAplic());
    }

    @Test
    void getFechaLimitPago() {
        operationsMonitorQueryResponse.setFechaLimitPago("fecha");
        assertEquals("fecha", operationsMonitorQueryResponse.getFechaLimitPago());
    }

    @Test
    void getFechaOper() {
        operationsMonitorQueryResponse.setFechaOper("fecha");
        assertEquals("fecha", operationsMonitorQueryResponse.getFechaOper());
    }

    @Test
    void getNumSucursal() {
        operationsMonitorQueryResponse.setNumSucursal("sucursal");
        assertEquals("sucursal", operationsMonitorQueryResponse.getNumSucursal());
    }

    @Test
    void getBancoOrdenante() {
        operationsMonitorQueryResponse.setBancoOrdenante("banco");
        assertEquals("banco", operationsMonitorQueryResponse.getBancoOrdenante());
    }

    @Test
    void getBancoReceptor() {
        operationsMonitorQueryResponse.setBancoReceptor("banco");
        assertEquals("banco", operationsMonitorQueryResponse.getBancoReceptor());
    }

    @Test
    void getMensaje() {
        operationsMonitorQueryResponse.setMensaje("mensaje");
        assertEquals("mensaje", operationsMonitorQueryResponse.getMensaje());
    }

    @Test
    void getMensajeOrden() {
        operationsMonitorQueryResponse.setMensajeOrden("mensaje");
        assertEquals("mensaje", operationsMonitorQueryResponse.getMensajeOrden());
    }

    @Test
    void getIdEstatus() {
        operationsMonitorQueryResponse.setIdEstatus("id");
        assertEquals("id", operationsMonitorQueryResponse.getIdEstatus());
    }

    @Test
    void getIdProducto() {
        operationsMonitorQueryResponse.setIdProducto("id");
        assertEquals("id", operationsMonitorQueryResponse.getIdProducto());
    }

    @Test
    void getVistProd() {
        operationsMonitorQueryResponse.setVistProd("vista");
        assertEquals("vista", operationsMonitorQueryResponse.getVistProd());
    }

    @Test
    void getTabla() {
        operationsMonitorQueryResponse.setTabla("tabla");
        assertEquals("tabla", operationsMonitorQueryResponse.getTabla());
    }

    @Test
    void getNombreOrd() {
        operationsMonitorQueryResponse.setNombreOrd("orden");
        assertEquals("orden", operationsMonitorQueryResponse.getNombreOrd());
    }

    @Test
    void getFechaVenc() {
        operationsMonitorQueryResponse.setFechaVenc("fecha");
        assertEquals("fecha", operationsMonitorQueryResponse.getFechaVenc());
    }

    @Test
    void getReferenciaAbono() {
        operationsMonitorQueryResponse.setReferenciaAbono("referencia");
        assertEquals("referencia", operationsMonitorQueryResponse.getReferenciaAbono());
    }

    @Test
    void getReferenciaCargo() {
        operationsMonitorQueryResponse.setReferenciaCargo("referencia");
        assertEquals("referencia", operationsMonitorQueryResponse.getReferenciaCargo());
    }

    @Test
    void getCanal() {
        operationsMonitorQueryResponse.setCanal("canal");
        assertEquals("canal", operationsMonitorQueryResponse.getCanal());
    }

    @Test
    void getNumEmpleado() {
        operationsMonitorQueryResponse.setNumEmpleado("empleado");
        assertEquals("empleado", operationsMonitorQueryResponse.getNumEmpleado());
    }

    @Test
    void getBucEmpleado() {
        operationsMonitorQueryResponse.setBucEmpleado("buc");
        assertEquals("buc", operationsMonitorQueryResponse.getBucEmpleado());
    }

    @Test
    void getNombreEmpleado() {
        operationsMonitorQueryResponse.setNombreEmpleado("empleado");
        assertEquals("empleado", operationsMonitorQueryResponse.getNombreEmpleado());
    }

    @Test
    void getSucTutora() {
        operationsMonitorQueryResponse.setSucTutora("sucursal");
        assertEquals("sucursal", operationsMonitorQueryResponse.getSucTutora());
    }

    @Test
    void getNumTarjeta() {
        operationsMonitorQueryResponse.setNumTarjeta("tarjeta");
        assertEquals("tarjeta", operationsMonitorQueryResponse.getNumTarjeta());
    }

    @Test
    void getNumTarjetaAct() {
        operationsMonitorQueryResponse.setNumTarjetaAct("tarjeta");
        assertEquals("tarjeta", operationsMonitorQueryResponse.getNumTarjetaAct());
    }

    @Test
    void getRfc() {
        operationsMonitorQueryResponse.setRfc("rfc");
        assertEquals("rfc", operationsMonitorQueryResponse.getRfc());
    }

    @Test
    void getNumeroCuenta() {
        operationsMonitorQueryResponse.setNumeroCuenta("cuenta");
        assertEquals("cuenta", operationsMonitorQueryResponse.getNumeroCuenta());
    }

    @Test
    void getImporteSinFormato() {
        operationsMonitorQueryResponse.setImporteSinFormato(BigDecimal.ZERO);
        assertEquals(BigDecimal.ZERO, operationsMonitorQueryResponse.getImporteSinFormato());
    }

    @Test
    void getDescripcion() {
        operationsMonitorQueryResponse.setDescripcion("desc");
        assertEquals("desc", operationsMonitorQueryResponse.getDescripcion());
    }

    @Test
    void getNumeMovil() {
        operationsMonitorQueryResponse.setNumeMovil("num");
        assertEquals("num", operationsMonitorQueryResponse.getNumeMovil());
    }

    @Test
    void getNomProveedor() {
        operationsMonitorQueryResponse.setNomProveedor("nombre");
        assertEquals("nombre", operationsMonitorQueryResponse.getNomProveedor());
    }

    @Test
    void getTipoOperacion() {
        operationsMonitorQueryResponse.setTipoOperacion("tipo");
        assertEquals("tipo", operationsMonitorQueryResponse.getTipoOperacion());
    }

    @Test
    void getCveProveedor() {
        operationsMonitorQueryResponse.setCveProveedor("clave");
        assertEquals("clave", operationsMonitorQueryResponse.getCveProveedor());
    }

    @Test
    void getTipoPerJuridica() {
        operationsMonitorQueryResponse.setTipoPerJuridica("tipo");
        assertEquals("tipo", operationsMonitorQueryResponse.getTipoPerJuridica());
    }

    @Test
    void getNumFolio() {
        operationsMonitorQueryResponse.setNumFolio("folio");
        assertEquals("folio", operationsMonitorQueryResponse.getNumFolio());
    }

    @Test
    void getCodRegistro() {
        operationsMonitorQueryResponse.setCodRegistro("codigo");
        assertEquals("codigo", operationsMonitorQueryResponse.getCodRegistro());
    }

    @Test
    void getHorarioProg() {
        operationsMonitorQueryResponse.setHorarioProg("hora");
        assertEquals("hora", operationsMonitorQueryResponse.getHorarioProg());
    }

    @Test
    void getIdMensaje() {
        operationsMonitorQueryResponse.setIdMensaje("idMensaje");
        assertEquals("idMensaje", operationsMonitorQueryResponse.getIdMensaje());
    }

    @Test
    void getIdCliente() {
        operationsMonitorQueryResponse.setIdCliente("idCliente");
        assertEquals("idCliente", operationsMonitorQueryResponse.getIdCliente());
    }

    @Test
    void getFechaIni() {
        operationsMonitorQueryResponse.setFechaIni("fecha");
        assertEquals("fecha", operationsMonitorQueryResponse.getFechaIni());
    }

    @Test
    void getFechaFin() {
        operationsMonitorQueryResponse.setFechaFin("fecha");
        assertEquals("fecha", operationsMonitorQueryResponse.getFechaFin());
    }

    @Test
    void getDivisa() {
    	operationsMonitorQueryResponse.setDivisa("MXN");
    	assertEquals("MXN", operationsMonitorQueryResponse.getDivisa());
    }

    @Test
    void getDivisaOrd() {
    	operationsMonitorQueryResponse.setDivisaOrd("MXN");
    	assertEquals("MXN", operationsMonitorQueryResponse.getDivisaOrd());
    }

    @Test
    void getImporte() {
    	operationsMonitorQueryResponse.setImporte("100");
    	assertEquals("100", operationsMonitorQueryResponse.getImporte());
    }

    @Test
    void getNumConvenio() {
    	operationsMonitorQueryResponse.setNumConvenio("numConvenio");
    	assertEquals("numConvenio", operationsMonitorQueryResponse.getNumConvenio());
    }

    @Test
    void toStringTest() {
        assertNotNull(operationsMonitorQueryResponse.toString());
    }
}