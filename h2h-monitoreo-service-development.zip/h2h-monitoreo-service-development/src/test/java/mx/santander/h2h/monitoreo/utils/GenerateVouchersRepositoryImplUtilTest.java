package mx.santander.h2h.monitoreo.utils;

import static org.mockito.Mockito.mock;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import jakarta.persistence.Query;
import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;
import mx.santander.h2h.monitoreo.util.GenerateVouchersRepositoryImplUtil;

@ExtendWith(MockitoExtension.class)
class GenerateVouchersRepositoryImplUtilTest {

	@InjectMocks
	GenerateVouchersRepositoryImplUtil generateVouchersRepositoryImplUtil;
	
	@Test
	void testString() {
		List<String> listParams = new ArrayList<>();
		String t = "A";
		listParams.add(t);
		Query query = mock(Query.class);
		generateVouchersRepositoryImplUtil.setStringParamsInToQuery(listParams, query);
		Assertions.assertNotNull(listParams);
	}
	
	@Test
	void testgetQ() {
		List<String> listParams = new ArrayList<>();
		String t = "A";
		listParams.add(t);
		StringBuilder query = new StringBuilder();
		OperationsMonitorQueryRequest r = new OperationsMonitorQueryRequest();
		r.setBuc("test");
		r.setNombreArchivo("test");
		generateVouchersRepositoryImplUtil.getQueryTableExport(r, listParams, query);
		Assertions.assertNotNull(listParams);
	}
	
	@Test
	void testPa() {
		StringBuilder query = new StringBuilder();
		StringBuilder queryTable = new StringBuilder();
		queryTable.append("SELECT * FROM ");
		generateVouchersRepositoryImplUtil.getPaginatedQuery(query, queryTable);
		Assertions.assertNotNull(queryTable);
	}
	
	@Test
	void testQrT() {
		OperationsMonitorQueryRequest r = new OperationsMonitorQueryRequest();
		r.setBuc("test");
		r.setNombreArchivo("test");
		List<String> listParams = new ArrayList<>();
		String t = "A";
		listParams.add(t);
		StringBuilder query = new StringBuilder();
		generateVouchersRepositoryImplUtil.getQueryTable(r, listParams, query);
		Assertions.assertNotNull(listParams);
	}
	
	@Test
	void testapplyFilters() {
		StringBuilder query = new StringBuilder();
		List<String> listParams = new ArrayList<>();
		String t = "A";
		listParams.add(t);
		OperationsMonitorQueryRequest o = new OperationsMonitorQueryRequest();
		o.setBuc("test");
		o.setBucsSensibles("test");
		o.setContrato("test");
		o.setConvenio("test");
		o.setCorreo("test");
		o.setCuentaAbono("test");
		o.setCuentaCargo("test");
		o.setCveProveedor("test");
		o.setLineaCaptura("test");
		o.setIdEstatus("test");
		o.setFechaInicial("2025/03/05");
		o.setFechaFinal("2025/03/05");
		o.setIdReg("test");
		o.setTipo("test");
		generateVouchersRepositoryImplUtil.applyFilters(o, query, listParams);
		Assertions.assertNotNull(o);
	}
}
