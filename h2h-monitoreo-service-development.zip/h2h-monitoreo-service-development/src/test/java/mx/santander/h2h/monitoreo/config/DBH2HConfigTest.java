package mx.santander.h2h.monitoreo.config;

import mx.santander.h2h.monitoreo.model.entity.DBH2HConfigurationBean;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import jakarta.persistence.EntityManagerFactory;
import javax.sql.DataSource;

@ExtendWith(MockitoExtension.class)
class DBH2HConfigTest {
	/**
	 * clase a testear.
	 */
	@InjectMocks
	private DBH2HConfig dbh2hConfig;
	
	
	@Test
	void onboardingJdbcTemplateTest() {
		DataSource dataSourceH2H = Mockito.mock(DataSource.class);
		dbh2hConfig.onboardingJdbcTemplate(dataSourceH2H);
		Assertions.assertTrue(true);
	}
	
	@Test
	void onboardingTransactionManagerTest() {
		EntityManagerFactory entity = Mockito.mock(EntityManagerFactory.class);
		dbh2hConfig.onboardingTransactionManager(entity);
		Assertions.assertTrue(true);
	}
	
	@Test
	void hikariConfigTest() {
		Assertions.assertNotNull(dbh2hConfig.hikariConfig(this.createBeanConfiguration()));
	}
	
	private DBH2HConfigurationBean createBeanConfiguration() {
		DBH2HConfigurationBean bean = new DBH2HConfigurationBean();
		bean.setDriver("oracle.jdbc.driver.OracleDriver");
		bean.setUrl("jdbc:oracle:thin:@mxbrvlh2hdes001.dev.mx.corp:1680:mxh2happ");
		bean.setUsername("DEIFH2A3");
		bean.setConnectiontime("30000");
		bean.setPoolsize("24");
		bean.setPassword("deif_h2a1_desa");
		
		bean.getDriver();
		bean.getUrl();
		bean.getUsername();
		bean.getConnectiontime();
		bean.getPoolsize();
		bean.getPassword();
		
		return bean;
	}
	
}
