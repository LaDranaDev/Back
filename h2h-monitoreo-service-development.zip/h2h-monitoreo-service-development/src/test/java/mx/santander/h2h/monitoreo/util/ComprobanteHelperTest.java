package mx.santander.h2h.monitoreo.util;

import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mockConstruction;
import static org.mockito.Mockito.mockStatic;

import java.util.Collections;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.MockedConstruction;
import org.mockito.MockedStatic;

import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;

import mx.santander.h2h.monitoreo.model.response.ComprobantesOperacionResponse;

class ComprobanteHelperTest {
    @Test
    void testIsPIF() {
        ComprobantesOperacionResponse registros = new ComprobantesOperacionResponse();
        registros.setEsImpuFed(true);
        registros.setEsApoObr(true);
        registros.setEsPagRef(true);
        registros.setEstatusMov("-31-");

        boolean result = ComprobanteHelper.isPIF(registros);
        Assertions.assertEquals(true, result);

        registros.setEstatusMov("-33-");
        result = ComprobanteHelper.isPIF(registros);
        Assertions.assertEquals(true, result);

        registros.setEstatusMov("-09-");
        result = ComprobanteHelper.isPIF(registros);
        Assertions.assertEquals(true, result);
    }

    @Test
    void testEsMigrado() {
        ComprobantesOperacionResponse operacionResponse = new ComprobantesOperacionResponse();
        operacionResponse.setTipoOper("TRANSFERENCIAS BANCARIAS");

        boolean result = ComprobanteHelper.esMigrado(Collections.singletonList(operacionResponse));
        Assertions.assertEquals(true, result);
    }

    @Test
    void testEsVostro() {
        boolean result = ComprobanteHelper.esVostro("TRANSFERENCIAS VOSTRO MISMO BANCO");
        Assertions.assertEquals(true, result);
    }

    @Test
    void testEsOrdPagAtm() {
        boolean result = ComprobanteHelper.esOrdPagAtm("85");
        Assertions.assertEquals(true, result);
    }

    @Test
    void testGenerarComprobante() {
        ComprobantesOperacionResponse operacionResponse = new ComprobantesOperacionResponse();
        operacionResponse.setTipoOper("");

        try (MockedStatic<ComprobanteGenerador> comprobanteGeneradorStatic = mockStatic(ComprobanteGenerador.class)) {
            operacionResponse.setTipoOper("ADUANALES");
            Assertions.assertDoesNotThrow(() ->
                    ComprobanteHelper.generarComprobante(Collections.singletonList(operacionResponse))
            );

            operacionResponse.setTipoOper("TRANSFERENCIAS BANCARIAS");
            Assertions.assertDoesNotThrow(() ->
                    ComprobanteHelper.generarComprobante(Collections.singletonList(operacionResponse))
            );

            operacionResponse.setTipoOper("NOMINA BANCARIA");
            Assertions.assertDoesNotThrow(() ->
                    ComprobanteHelper.generarComprobante(Collections.singletonList(operacionResponse))
            );

            operacionResponse.setTipoOper("TEF");
            Assertions.assertDoesNotThrow(() ->
                    ComprobanteHelper.generarComprobante(Collections.singletonList(operacionResponse))
            );

            operacionResponse.setEsConfirming(true);
            Assertions.assertDoesNotThrow(() ->
                    ComprobanteHelper.generarComprobante(Collections.singletonList(operacionResponse))
            );

            operacionResponse.setEsPagoTDC(true);
            Assertions.assertDoesNotThrow(() ->
                    ComprobanteHelper.generarComprobante(Collections.singletonList(operacionResponse))
            );
        }
    }

    @Test
    void testValidaEsSpei() {
        ComprobantesOperacionResponse dto = new ComprobantesOperacionResponse();
        dto.setCuentaAbono("CuentaAbono");
        dto.setFolioOp(1111L);
        dto.setTipoOper("");

        String result = ComprobanteHelper.validaEsSpei(dto);
        Assertions.assertEquals("CuentaAbono_1111.pdf", result);

        dto.setTipoOper("SPEI");
        dto.setRfcProveedor("A");
        dto.setRefInterbancaria("2222");
        result = ComprobanteHelper.validaEsSpei(dto);
        Assertions.assertEquals("CuentaAbono_2222.pdf", result);
    }

    @Test
    void testConcatenarPDFs() {
        try (
                MockedConstruction<PdfReader> pdfReader = mockConstruction(PdfReader.class);
                MockedConstruction<Document> document = mockConstruction(Document.class);
                MockedStatic<PdfWriter> pdfWriter = mockStatic(PdfWriter.class, RETURNS_DEEP_STUBS)
        ) {
            Assertions.assertDoesNotThrow(() ->
                    ComprobanteHelper.concatenarPDFs(Collections.singletonList(new byte[]{}))
            );
        }
    }
}
