package mx.santander.h2h.monitoreo.model.response;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import mx.santander.h2h.monitoreo.constants.ArchivosConstants;
import mx.santander.h2h.monitoreo.constants.PropertiesConstant;

@ExtendWith(MockitoExtension.class)
class ParametroTest {
	@InjectMocks
    private Parametro parametro;
	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
	}
	

	@Test
	void testGetValor() {
		parametro.setValor("TEST");
		assertNotNull(parametro.getValor());
	}

	@Test
	void testGetNombre() {
		parametro.setNombre("TEST");
		assertNotNull(parametro.getNombre());
	}
	
	@Test
	void testArchivosConstants() throws NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Constructor<ArchivosConstants> c = ArchivosConstants.class.getDeclaredConstructor();
		c.setAccessible(true);
		c.newInstance();
		Assertions.assertNotNull(c);
	}
	
	@Test
	void test() {
		PropertiesConstant p = new PropertiesConstant();
		p.setInterceptorPath("test");
		p.getInterceptorPath();
		Assertions.assertNotNull(p);
	}

}
