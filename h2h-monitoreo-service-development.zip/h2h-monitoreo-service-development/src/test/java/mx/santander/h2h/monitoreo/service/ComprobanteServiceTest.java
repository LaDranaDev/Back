package mx.santander.h2h.monitoreo.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mockConstruction;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedConstruction;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.core.io.ClassPathResource;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.response.ComprobantesOperacionResponse;
import mx.santander.h2h.monitoreo.model.response.OperationsMonitorQueryResponse;
import mx.santander.h2h.monitoreo.repository.IComprobanteEntityManagerRepository;
import mx.santander.h2h.monitoreo.util.ComprobanteGenerador;
import mx.santander.h2h.monitoreo.util.ComprobanteGenerador2;
import mx.santander.h2h.monitoreo.util.ComprobanteHelper;

class ComprobanteServiceTest {
    @Mock
    IJasperReportService reportService;
    @Mock
    IComprobanteEntityManagerRepository entityManager;
    @Mock
    Logger log;
    @InjectMocks
    ComprobanteService comprobanteService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        comprobanteService = spy(comprobanteService);
    }

    @Test
    void testComprobantes() throws IOException {
        when(entityManager.obtenerComprobantes(any(), any())).thenReturn(Collections.emptyList());

        ReportResponse reportResponse = new ReportResponse();
        doReturn(reportResponse).when(comprobanteService).generaReporteGlobal(any());
        doReturn(reportResponse).when(comprobanteService).generaReportesPorComprobante(any());

        OperationsMonitorQueryResponse query = new OperationsMonitorQueryResponse();
        query.setIdOperacion("1");

        ReportResponse result = comprobanteService.comprobantes(Collections.singletonList(query), "pdf");
        Assertions.assertNotNull(result);

        result = comprobanteService.comprobantes(Collections.singletonList(query), "zip");
        Assertions.assertNotNull(result);
    }

    @Test
    void testGeneraReporteGlobal() throws IOException {
        doReturn(new byte[]{}).when(comprobanteService).generarFormatoPdf(any(), any(), anyBoolean());
        doReturn(Collections.emptyMap()).when(comprobanteService).obtenerModelo(any());

        ComprobantesOperacionResponse comprobante1 = new ComprobantesOperacionResponse();
        comprobante1.setTipoOper("");

        ComprobantesOperacionResponse comprobante2 = new ComprobantesOperacionResponse();
        comprobante2.setTipoOper("SPEI");

        ArrayList<ComprobantesOperacionResponse> comprobantes = new ArrayList<>();
        comprobantes.add(comprobante1);
        comprobantes.add(comprobante2);

        try (MockedStatic<ComprobanteHelper> comprobanteHelper = mockStatic(ComprobanteHelper.class)) {
            comprobanteHelper.when(() -> ComprobanteHelper.concatenarPDFs(any())).thenReturn(new byte[]{});
            Assertions.assertDoesNotThrow(() ->
                    comprobanteService.generaReporteGlobal(comprobantes)
            );
        }
    }

    @Test
    void testGeneraReportesPorComprobante() throws IOException {
        ComprobantesOperacionResponse comprobante1 = new ComprobantesOperacionResponse();

        ComprobantesOperacionResponse comprobante2 = new ComprobantesOperacionResponse();
        comprobante2.setEsPagoTDC(true);
        comprobante2.setCuentaAbono("1111111111111111");
        comprobante2.setFolioOp(2222L);

        ComprobantesOperacionResponse comprobante3 = new ComprobantesOperacionResponse();
        comprobante3.setEsPagoTDC(true);
        comprobante3.setCuentaAbono("11111111111111");
        comprobante3.setFolioOp(2222L);

        List<ComprobantesOperacionResponse> comprobantes = Arrays.asList(comprobante1, comprobante2, comprobante3);

        doReturn(new byte[]{}).when(comprobanteService).generarFormatoPdf(any(), any(), anyBoolean());
        doReturn(Collections.emptyMap()).when(comprobanteService).obtenerModelo(any());

        try (
                MockedStatic<ComprobanteHelper> comprobanteHelper = mockStatic(ComprobanteHelper.class)
        ) {
            comprobanteHelper.when(() -> ComprobanteHelper.validaEsSpei(any())).thenReturn("nomComprobante.pdf");

            Assertions.assertDoesNotThrow(() ->
                    comprobanteService.generaReportesPorComprobante(comprobantes)
            );
        }
    }

    @Test
    void testObtenerModelo() throws IOException {
        try (MockedConstruction<ClassPathResource> classPathResource = mockConstruction(ClassPathResource.class,
                (mock, context) -> when(mock.getURL()).thenReturn(new URL("file:///URL"))
        )) {
            Map<String, Object> result = comprobanteService.obtenerModelo(Collections.emptyList());
            Assertions.assertEquals(new HashMap<String, Object>() {{
                put("RUTA_IMAGEN", "file:/URL");
                put("RUTA_IMAGEN2", "file:/URL");
                put("NUM_ELEM", 0);
            }}, result);
        }
    }

    @Test
    void testGenerarFormatoPdf() {
        ComprobantesOperacionResponse registro = new ComprobantesOperacionResponse();
        List<ComprobantesOperacionResponse> registros = Collections.singletonList(registro);

        doReturn(null).when(comprobanteService).generaComprobanteporJasper(any(), any());

        try (
                MockedStatic<ComprobanteGenerador> comprobanteGenerador = mockStatic(ComprobanteGenerador.class);
                MockedStatic<ComprobanteGenerador2> comprobanteGenerador2 = mockStatic(ComprobanteGenerador2.class);
                MockedStatic<ComprobanteHelper> comprobanteHelper = mockStatic(ComprobanteHelper.class)
        ) {
            comprobanteHelper.when(() -> ComprobanteHelper.isPIF(any())).thenReturn(true);

            registro.setEstatusMov("-09-");
            Assertions.assertDoesNotThrow(() ->
                    comprobanteService.generarFormatoPdf(Collections.emptyMap(), registros, true)
            );

            registro.setEstatusMov("-33-");
            Assertions.assertDoesNotThrow(() ->
                    comprobanteService.generarFormatoPdf(Collections.emptyMap(), registros, true)
            );

            registro.setEstatusMov("-31-");
            Assertions.assertDoesNotThrow(() ->
                    comprobanteService.generarFormatoPdf(Collections.emptyMap(), registros, true)
            );

            registro.setEsPagRef(true);
            Assertions.assertDoesNotThrow(() ->
                    comprobanteService.generarFormatoPdf(Collections.emptyMap(), registros, true)
            );

            registro.setEsApoObr(true);
            Assertions.assertDoesNotThrow(() ->
                    comprobanteService.generarFormatoPdf(Collections.emptyMap(), registros, true)
            );

            registro.setEsImpuFed(true);
            Assertions.assertDoesNotThrow(() ->
                    comprobanteService.generarFormatoPdf(Collections.emptyMap(), registros, true)
            );

            registro.setCveProdOper("25");
            Assertions.assertDoesNotThrow(() ->
                    comprobanteService.generarFormatoPdf(Collections.emptyMap(), registros, false)
            );

            registro.setCveProdOper("");
            Assertions.assertDoesNotThrow(() ->
                    comprobanteService.generarFormatoPdf(Collections.emptyMap(), registros, false)
            );
        }
    }

    @Test
    void testGeneraComprobanteporJasper() {
        ReportResponse reportResponse = new ReportResponse();
        reportResponse.setData( Base64.getEncoder().encodeToString("data".getBytes(StandardCharsets.UTF_8)));
        when(reportService.getPdf(anyString(), any(), any())).thenReturn(reportResponse);

        ComprobantesOperacionResponse registro = new ComprobantesOperacionResponse();
        List<ComprobantesOperacionResponse> registros = Collections.singletonList(registro);

        registro.setTipoOper("");

        try (
                MockedStatic<ComprobanteGenerador> comprobanteGenerador = mockStatic(ComprobanteGenerador.class);
                MockedStatic<ComprobanteGenerador2> comprobanteGenerador2 = mockStatic(ComprobanteGenerador2.class);
                MockedStatic<ComprobanteHelper> comprobanteHelper = mockStatic(ComprobanteHelper.class)
        ) {
            Assertions.assertDoesNotThrow(() ->
                    comprobanteService.generaComprobanteporJasper(registros, Collections.emptyMap())
            );

            comprobanteHelper.when(() -> ComprobanteHelper.esOrdPagAtm(any())).thenReturn(true);
            Assertions.assertDoesNotThrow(() ->
                    comprobanteService.generaComprobanteporJasper(registros, Collections.emptyMap())
            );

            comprobanteHelper.when(() -> ComprobanteHelper.esVostro(any())).thenReturn(true);
            Assertions.assertDoesNotThrow(() ->
                    comprobanteService.generaComprobanteporJasper(registros, Collections.emptyMap())
            );

            registro.setEstatusMov("40");
            Assertions.assertDoesNotThrow(() ->
                    comprobanteService.generaComprobanteporJasper(registros, Collections.emptyMap())
            );

            registro.setTipoOper("ORDEN DE PAGO");
            Assertions.assertDoesNotThrow(() ->
                    comprobanteService.generaComprobanteporJasper(registros, Collections.emptyMap())
            );

            registro.setTipoOper("NOMINA INTERBANCARIA");
            Assertions.assertDoesNotThrow(() ->
                    comprobanteService.generaComprobanteporJasper(registros, Collections.emptyMap())
            );

            comprobanteHelper.when(() -> ComprobanteHelper.esMigrado(any())).thenReturn(true);
            Assertions.assertDoesNotThrow(() ->
                    comprobanteService.generaComprobanteporJasper(registros, Collections.emptyMap())
            );

            registro.setTipoOper("SPEI");
            Assertions.assertDoesNotThrow(() ->
                    comprobanteService.generaComprobanteporJasper(registros, Collections.emptyMap())
            );
        }
    }
}
