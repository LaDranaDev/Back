package mx.santander.h2h.monitoreo.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import mx.santander.h2h.monitoreo.model.response.ProtocolResponse;
import mx.santander.h2h.monitoreo.model.response.PutGetServiceResponse;
import mx.santander.h2h.monitoreo.service.ContractConnectionManagementPutGetFindDataService;
import mx.santander.h2h.monitoreo.util.ContractConnectionManagementPutGetMapping;

@ExtendWith(MockitoExtension.class)
class ContractConnectionManagementPutGetMappingTest {

	private static final int INT_VALUE_ONE = 1;

	@InjectMocks
	ContractConnectionManagementPutGetMapping contractConnectionManagementPutGetMapping;

	@Mock
	ContractConnectionManagementPutGetFindDataService contractConnectionManagementPutGetFindDataUtils;

	@Test
	void mapFromPutGetResponseToPutGetServiceResponse() {

		ArrayList<Object[]> putGetResponse = createObjectArray(INT_VALUE_ONE, "value");

		PutGetServiceResponse putGetServiceResponse = contractConnectionManagementPutGetMapping.mapFromPutGetResponseToPutGetServiceResponse(putGetResponse, new PutGetServiceResponse());

		assertNotNull(putGetServiceResponse);
		assertEquals(putGetServiceResponse.getIdProtocolo(), "value");

	}

	@Test
	void mapFromPutGetResponseToPutGetServiceResponseBuscarDatosdeSFTP() {

		ArrayList<Object[]> putGetResponse = createObjectArray(INT_VALUE_ONE, "1");

		PutGetServiceResponse putGetServiceResponse = contractConnectionManagementPutGetMapping.mapFromPutGetResponseToPutGetServiceResponse(putGetResponse, new PutGetServiceResponse());

		assertNotNull(putGetServiceResponse);
		assertEquals(putGetServiceResponse.getIdProtocolo(), "1");

	}

	@Test
	void mapFromPutGetResponseToPutGetServiceResponseBuscarDatosdeCD() {

		ArrayList<Object[]> putGetResponse = createObjectArray(INT_VALUE_ONE, "2");

		PutGetServiceResponse putGetServiceResponse = contractConnectionManagementPutGetMapping.mapFromPutGetResponseToPutGetServiceResponse(putGetResponse, new PutGetServiceResponse());

		assertNotNull(putGetServiceResponse);
		assertEquals(putGetServiceResponse.getIdProtocolo(), "2");

	}

	@Test
	void mapFromPutGetResponseToPutGetServiceResponseBuscarDatosdeWS() {

		ArrayList<Object[]> putGetResponse = createObjectArray(INT_VALUE_ONE, "5");

		PutGetServiceResponse putGetServiceResponse = contractConnectionManagementPutGetMapping.mapFromPutGetResponseToPutGetServiceResponse(putGetResponse, new PutGetServiceResponse());

		assertNotNull(putGetServiceResponse);
		assertEquals(putGetServiceResponse.getIdProtocolo(), "5");

	}

	@Test
	void mapFromListProtocolsToListProtocolsResponse() {

		ArrayList<Object[]> listProtocols = createObjectArray(INT_VALUE_ONE, "value");

		List<ProtocolResponse> listProtocolResponse = contractConnectionManagementPutGetMapping.mapFromListProtocolsToListProtocolsResponse(listProtocols);

		assertNotNull(listProtocolResponse);
		assertEquals(listProtocolResponse.get(0).getIdProtocolo(), 1);

	}

	@Test
	void mapFromPutGetFilesResponseToPutGetServiceResponse() {

		ArrayList<Object[]> listPutGetResponse = createObjectArray(INT_VALUE_ONE, "value");

		PutGetServiceResponse putGetServiceResponse = contractConnectionManagementPutGetMapping.mapFromPutGetFilesResponseToPutGetServiceResponse(listPutGetResponse);

		assertNotNull(putGetServiceResponse);
		assertEquals(putGetServiceResponse.getIdProtocolo(), "value");

	}

	/**
	 * @return
	 */
	private ArrayList<Object[]> createObjectArray(Integer intValue, String value) {

		ArrayList<Object[]> putGetResponse = new ArrayList<>();

		Object[] object = { intValue, "value", value, "value", "value", "value", "value", "value", "value", "value",
				"value", "value", "value" };

		putGetResponse.add(object);

		return putGetResponse;
	}

}
