package mx.santander.h2h.monitoreo.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import mx.santander.h2h.monitoreo.model.report.response.ReportResponse;
import mx.santander.h2h.monitoreo.model.request.HistorialOperacionesRequest;
import mx.santander.h2h.monitoreo.repository.IOperationsDetailRepository;
import mx.santander.h2h.monitoreo.util.IGenerateVouchersUtils;
import net.sf.jasperreports.engine.JRException;

@ExtendWith(MockitoExtension.class)
class GenerateVouchersOperacionesServiceTest {

	@InjectMocks
	GenerateVouchersOperacionesService generateVouchersOperacionesService;
	
	/**
	 * detailRepository
	 */
	@Mock
    private IOperationsDetailRepository detailRepository;
	
	/**
	 * iGenerateVouchersUtils
	 */
	@Mock
	private IGenerateVouchersUtils iGenerateVouchersUtils;
	
	/**
	 * Servicio genérico 
	 * de reportería
	 */
	@Mock
	private IJasperReportService iJasperReportService;
	
	@Test
	void exportarHistorialOperacionesXlsx() throws JRException {

		ReportResponse exportarOperacionesXlsx = generateVouchersOperacionesService
				.exportarHistorialOperacionesXlsx(new HistorialOperacionesRequest());

		assertTrue(true);

	}

	private ReportResponse crearReportResponse() {

		ReportResponse reportResponse = new ReportResponse();

		reportResponse.setData("data");
		reportResponse.setLength(123456);
		reportResponse.setName("nameFileReport");
		reportResponse.setType("xlsx");

		return reportResponse;
	}
}
