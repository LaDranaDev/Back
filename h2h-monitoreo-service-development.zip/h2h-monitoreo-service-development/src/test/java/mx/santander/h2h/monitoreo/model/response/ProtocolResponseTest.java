package mx.santander.h2h.monitoreo.model.response;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
class ProtocolResponseTest {

    private ProtocolResponse protocolResponse;

    @BeforeEach
    void setUp() {
        protocolResponse = new ProtocolResponse();
    }

    @Test
    void allArgsContructor() {
        protocolResponse = new ProtocolResponse(1, "nombre", "estatus", new ArrayList<>(),
                new ArrayList<>(), new ArrayList<>(), 1);

        assertNotNull(protocolResponse);
    }

    @Test
    void agregarParametroGet() {
        ParametersGetPutResponse parametro = mock(ParametersGetPutResponse.class);
        protocolResponse.agregarParametroGet(parametro);
        protocolResponse.agregarParametroGet(parametro);

        assertEquals(2, protocolResponse.getParametrosGet().size());

    }

    @Test
    void agregarParametroPut() {
        ParametersGetPutResponse parametro = mock(ParametersGetPutResponse.class);
        protocolResponse.agregarParametroPut(parametro);
        protocolResponse.agregarParametroPut(parametro);

        assertEquals(2, protocolResponse.getParametrosPut().size());
    }

    @Test
    void getIdProtocolo() {
        protocolResponse.setIdProtocolo(1);
        assertEquals(1, protocolResponse.getIdProtocolo());
    }

    @Test
    void getNombre() {
        protocolResponse.setNombre("nombre");
        assertEquals("nombre", protocolResponse.getNombre());
    }

    @Test
    void getActivo() {
        protocolResponse.setActivo("estatus");
        assertEquals("estatus", protocolResponse.getActivo());
    }

    @Test
    void getParametrosGet() {
        List<ParametersGetPutResponse> parametrosGet = new ArrayList<>();
        protocolResponse.setParametrosGet(parametrosGet);
        assertEquals(parametrosGet, protocolResponse.getParametrosGet());
    }

    @Test
    void getParametrosPut() {
        List<ParametersGetPutResponse> parametrosPut = new ArrayList<>();
        protocolResponse.setParametrosPut(parametrosPut);
        assertEquals(parametrosPut, protocolResponse.getParametrosPut());
    }

    @Test
    void getNombreParametros() {
        List<String> nombreParametros = new ArrayList<>();
        protocolResponse.setNombreParametros(nombreParametros);
        assertEquals(nombreParametros, protocolResponse.getNombreParametros());
    }

    @Test
    void getIdRegistro() {
        protocolResponse.setIdRegistro(1);
        assertEquals(1, protocolResponse.getIdRegistro());
    }

    @Test
    void toStringTest() {
        assertNotNull(protocolResponse.toString());
    }
}