package mx.santander.h2h.monitoreo.controller;

import static org.mockito.ArgumentMatchers.any;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import mx.santander.h2h.monitoreo.service.IConsultaTrackingOperacionHistService;
import mx.santander.h2h.monitoreo.service.IConsultaTrackingOperacionService;

class ArchivoTrackingComplementControllerTest {
	@Mock
	private IConsultaTrackingOperacionService consultaTrackingOperacionService;

	@Mock
	private IConsultaTrackingOperacionHistService consultaTrackingOperacionHistService;

	@InjectMocks
	private ArchivoTrackingComplementController controller;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testIniciaNivelOperacion() {
		Assertions.assertNotNull(this.controller.iniciaNivelOperacion(any()));
	}

	@Test
	void testObtenerDetalleArchivosNivelOperacion() {
		Assertions.assertNotNull(this.controller.obtenerDetalleArchivosNivelOperacion(any(), any()));
	}

	@Test
	void testGetReportXlsNivelOperacion() {
		Assertions.assertNotNull(this.controller.getReportXlsDetalleNivelOperacionHist(any(), any()));
	}

	@Test
	void testIniciaNivelOperacionHistorica() {
		Assertions.assertNotNull(this.controller.iniciaNivelOperacionHistorica(any()));
	}

	@Test
	void testObtenerDetalleArchivosNivelOperacionHist() {
		Assertions.assertNotNull(this.controller.obtenerDetalleArchivosNivelOperacionHist(any(), any()));
	}

	@Test
	void testGetReportXlsDetalleNivelOperacionHist() {
		Assertions.assertNotNull(this.controller.getReportXlsNivelOperacion(any(), any()));
	}

}
