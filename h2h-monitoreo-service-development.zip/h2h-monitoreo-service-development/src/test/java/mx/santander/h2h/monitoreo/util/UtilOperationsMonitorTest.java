package mx.santander.h2h.monitoreo.util;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import mx.santander.h2h.monitoreo.model.request.OperationsMonitorQueryRequest;

class UtilOperationsMonitorTest {

    @Test
    void testAgrega01y97y02() {
        StringBuilder query = new StringBuilder();
        UtilOperationsMonitor.agrega01y97y02(query);
        Assertions.assertNotNull(query.toString());
    }

    @Test
    void testAgrega80y81() {
        StringBuilder query = new StringBuilder();
        UtilOperationsMonitor.agrega80y81(query);
        Assertions.assertNotNull(query.toString());
    }

    @Test
    void testAgrega40() {
        StringBuilder query = new StringBuilder();
        UtilOperationsMonitor.agrega40(query);
        Assertions.assertNotNull(query.toString());
    }

    @Test
    void testAgrega95y96() {
        StringBuilder query = new StringBuilder();
        UtilOperationsMonitor.agrega95y96(query);
        Assertions.assertNotNull(query.toString());
    }

    @Test
    void testAgrega9y99() {
        StringBuilder query = new StringBuilder();
        UtilOperationsMonitor.agrega9y99(query);
        Assertions.assertNotNull(query.toString());
    }

    @Test
    void testAgregaTIconsulta() {
        StringBuilder query = new StringBuilder();
        UtilOperationsMonitor.agregaTIconsulta(query, "cveOperProd");
        Assertions.assertNotNull(query.toString());

        UtilOperationsMonitor.agregaTIconsulta(query, "33");
        Assertions.assertNotNull(query.toString());
    }

    @Test
    void testAgregaPifconsulta() {
        StringBuilder query = new StringBuilder();
        UtilOperationsMonitor.agregaPifconsulta(query, "cveOperProd");
        Assertions.assertNotNull(query.toString());

        UtilOperationsMonitor.agregaPifconsulta(query, "23");
        Assertions.assertNotNull(query.toString());
    }

    
    @Test
    void testAgregaPifconsulta2() {
        StringBuilder query = new StringBuilder();
        UtilOperationsMonitor.agregaPifconsulta(query, "cveOperProd");
        Assertions.assertNotNull(query.toString());

        UtilOperationsMonitor.agregaPifconsulta(query, "23");
        Assertions.assertNotNull(query.toString());
    }
    
    
    @Test
    void testCompletaQueryProducto919330() {
    	StringBuilder query = new StringBuilder();
        for (String cveOperProd : Arrays.asList("91", "93", "30", "29")) {
            UtilOperationsMonitor.completaQueryProducto919330(query, cveOperProd, true);
            String result = query.toString();
            Assertions.assertNotNull(result);
        }
    }

    @Test
    void testCompletaConsultaByProducto() {
    	StringBuilder querySQL = new StringBuilder();
        Map<String, Object> params = new HashMap<>();
        OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();

        consultaOperaciones.setIdProducto("11");
        consultaOperaciones.setCveProveedor("cveProveedor");
        consultaOperaciones.setTipOperacion("tipOperacion");

        for (String cveOperProd : Arrays.asList("01", "97", "02", "95", "96", "98", "99")) {
        	// Obtenemos los datos del mapa
            UtilOperationsMonitor.completaConsultaByProducto(cveOperProd, consultaOperaciones, querySQL, params);
    		
            Assertions.assertNotNull(querySQL);
        }
    }

    
    @Test
    void testCompletaConsultaByProducto2() {
    	StringBuilder querySQL = new StringBuilder();
        Map<String, Object> params = new HashMap<>();
        OperationsMonitorQueryRequest consultaOperaciones = new OperationsMonitorQueryRequest();

        consultaOperaciones.setIdProducto("11");
        consultaOperaciones.setCveProveedor("cveProveedor");
        consultaOperaciones.setTipOperacion("tipOperacion");

        for (String cveOperProd : Arrays.asList("01", "97", "02", "95", "96", "98", "99")) {
        	// Obtenemos los datos del mapa
            UtilOperationsMonitor.completaConsultaByProducto(cveOperProd, consultaOperaciones, querySQL, params);
    		
            Assertions.assertNotNull(querySQL);
        }
    }
    
    
    @Test
    void testGetselectTransfInter() {
    	StringBuilder querySQL = new StringBuilder();
        
        for (String idcntr : Arrays.asList("29", "31", "33")) {
            UtilOperationsMonitor.getselectTransfInter(true, querySQL, idcntr);
            Assertions.assertNotNull(querySQL);

            UtilOperationsMonitor.getselectTransfInter(false, querySQL, idcntr);
            Assertions.assertNotNull(querySQL);
        }
    }

}
