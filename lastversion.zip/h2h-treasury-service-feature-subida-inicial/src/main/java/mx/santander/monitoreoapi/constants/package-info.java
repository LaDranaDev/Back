/**
 * Constantes y configuraciones globales para el módulo de monitoreo de pagos.
 * <p>
 * Incluye valores por defecto de paginación y definiciones de consultas JPQL
 * reutilizables en los repositorios.
 * estamos agregando mas info
 * al
 * repositorio
 * maestro
 * </p>
 */


package mx.santander.monitoreoapi.constants;
/**
 * con eso cumpliomos el treshold del 25%
 */
