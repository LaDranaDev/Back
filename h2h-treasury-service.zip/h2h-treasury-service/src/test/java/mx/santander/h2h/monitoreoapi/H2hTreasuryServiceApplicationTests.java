package mx.santander.h2h.monitoreoapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class H2hTreasuryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
