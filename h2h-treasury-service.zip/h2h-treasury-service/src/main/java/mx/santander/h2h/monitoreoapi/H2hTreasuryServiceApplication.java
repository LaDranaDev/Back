package mx.santander.h2h.monitoreoapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class H2hTreasuryServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(H2hTreasuryServiceApplication.class, args);
	}

}
